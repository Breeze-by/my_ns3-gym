import collections, gzip, hashlib, json, os
from pathlib import Path
from datetime import datetime, timezone

root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
base=r/'log/p2c/20261009_p2c_v38';paths=list(base.glob('*/summary.json'));assert len(paths)==1
p=paths[0];s=json.loads(p.read_text());z=s['result'];freeze='56de2b91ca9f20c6608983a5c09a05a938a10d36'
assert s['git_commit']==freeze and s['case']=='dev_forced2' and not z['success']
assert z['collision_events']==0 and z['failed_robots']==['tb1']
assert s['runner_returncode']==s['observer_returncode']==0
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
closure={}
for key in ('owner_pid','observer_pid'):
 try:os.kill(s[key],0)
 except ProcessLookupError:closure[key]=dict(pid=s[key],closed=True)
 else:raise AssertionError(('live',key))
closure['checked_at_utc']=datetime.now(timezone.utc).isoformat()
(r/'log/p2c_v38_closed_before_edit.json').write_text(json.dumps(closure,indent=2)+'\n')
for name,digest in s['evidence_sha256'].items():assert sha(p.parent/name)==digest
gate=json.loads((r/'log/p2c_v38_dev_forced2_gate.json').read_text());assert gate['status']=='FAIL'
audits=json.loads((r/'log/p2c_v38_independent_audits.json').read_text())
assert len(audits['dev_forced2'])==12 and all(v['status']=='PASS' for v in audits['dev_forced2'].values())
rows=[json.loads(line) for line in (p.parent/'ledger.jsonl').open()]
leases=collections.Counter(e['stage'] for e in rows if e.get('event')=='coordinator_planning_lease_expired')
snapshot_binding={}
snapshots=[r/'log/p2c_v38_native_no_route_snapshot.json', r/'log/p2c_v38_rally_assignment_input.json']
for q in snapshots:
 e=json.loads(q.read_text())
 if 'ledger_index' in e:
  assert any(x==e for x in rows)
  snapshot_binding[q.name]=dict(snapshot_sha256=sha(q),original_ledger_sha256=sha(p.parent/'ledger.jsonl'),ledger_index=e['ledger_index'])
 else:
  native_rows=[json.loads(line) for line in (p.parent/'safety_events.jsonl').open()]
  matched=[]
  for i,x in enumerate(native_rows):
   d=x.get('data')
   if isinstance(d,str):
    try:d=json.loads(d)
    except json.JSONDecodeError:continue
   if d==e:matched.append(i)
  assert len(matched)==1,matched
  snapshot_binding[q.name]=dict(snapshot_sha256=sha(q),original_safety_sha256=sha(p.parent/'safety_events.jsonl'),safety_row_index=matched[0])
files=[q for q in base.rglob('*') if q.is_file() and q.suffix!='.pyc']+snapshots
files += [r/'log'/name for name in ['check_p2c_v38_freeze.py','p2c_v38_freeze_check.json',
  'p2c_v38_dev_forced2_runner.log','p2c_v38_dev_forced2_gate.log','p2c_v38_dev_forced2_gate.json',
  'audit_p2c_v38_independent.py','p2c_v38_independent_audits.json','p2c_v38_independent_audits.log',
  'peek_p2c_v38_tasks.py','p2c_v38_closed_before_edit.json','prepare_p2c_v38_failure.py']]
assert all(q.exists() for q in files)
destination=report/'20261009_p2c_v38_artifacts';assert not destination.exists();destination.mkdir();artifacts=[]
for q in sorted(set(files)):
 a=destination/('__'.join(q.relative_to(r).parts)+'.gz');a.write_bytes(gzip.compress(q.read_bytes(),compresslevel=6,mtime=0))
 assert gzip.decompress(a.read_bytes())==q.read_bytes()
 artifacts.append(dict(source=str(q.relative_to(root)),source_sha256=sha(q),archive=str(a.relative_to(report)),archive_sha256=sha(a)))
out=dict(status='FAIL',scope='First required forced-development original failed; other3 development/formal17/physical2/917 not invoked',
 task_stack_frozen_commit=freeze,original=s,first_required_gate=gate,independent_audits=audits,
 all_owned_closed=closure,planning_lease_aborts=dict(leases),exact_snapshot_binding=snapshot_binding,
 task_retries=0,artifacts=artifacts)
(report/'20261009_p2c_v38_failed_development.json').write_text(json.dumps(out,indent=2)+'\n')

text=f"""# P2C.1 v38 首强制原任务 FAIL

冻结56de2b91ca9f20c6608983a5c09a05a938a10d36；原任务262.8s PARTIAL_COMPLETE，success=false、termination=partial_task_complete、failed_robots=[tb1]。这不是完整任务成功；失败的时间惩罚仍按300s计算，不能把262.8s作为完成时间收益。目标172.7s确认/174.3s进入RALLY；两机各充电一次、最低8.900475326498496，零接触/耗尽/任务期基础设施失败/任务重试，但存在一个正电量原生FAILED。owner/observer exit0且关闭，全strict FAIL；12独立原始审计PASS不能抵消安全与完整任务失败。其余3开发/17正式/2物理/917未调用。

v38接触航段修复确实被原任务执行：tb2在2254.582s派发已预算目标(.583278076,.573438465)，2263.782s收到STATUS_SUCCEEDED，2263.882s return_finished且cancellation_count=0。这证明这条实际航段未在接触半径处被提前取消，不能证明不同async轨迹间的任务因果收益。

tb1在2339.282s由no_known_route开始返航保护，位置(-4.193660045,2.812412719)、电量62.24770868502587；新鲜local2337.990/fused2338.182均保持原占用与未知保护，原30s无法恢复后FAILED。其最终电量仍约60.90，不是耗尽。准确native原输入逐字绑定safety原行，AP原集合输入逐字绑定ledger。只读重建发现当前local/fused单元都是0，当前固定净空安全，但完整已知净空返路均不存在；原始自由格四连通仍有充电区路径，0.35m安全图在门洞断开。不能清除占用、放宽净空、改TTL或延长原期限来放行。

地图中的部分占用与静态SDF不一致仅是未配准的诊断线索，可能还含SLAM/位姿偏差；原任务未保存原始LaserScan，不能确认占用由同伴唯一造成。暂未引入SLAM机器人回波过滤或Gazebo真值输入。下一候选比较原72/外圈可见边界局部加密/均匀216/完整分层方案，仍仅使用当前AP交付输入、原完整返路/预算/可见性/0.45m端点/0.8m间距约束。离线风险或计算改善不等于原轨迹回放、因果任务收益或最坏保证。

全部原始结果、源码/环境/命令/图/账本/安全输入SHA、严格traceback、12独立审计和关闭证据见JSON/gzip。P2C.1未通过；P3C.5已验收，无P4/ns-3/Wi-Fi/RL。
"""
(report/'20261009_p2c_v38_failed_development.md').write_text(text)
heading='## 2026-10-09 P2C.1 v38 首强制开发原任务 FAIL'
assert heading not in (w/'log.md').read_text()
with (w/'log.md').open('a') as f:
 f.write('\n\n'+heading+'\n\n56de2b commit/push0，check_p2c_v38_freeze.py PASS；Humble+install/PYTHONNOUSERSITE1/FastDDS UDPv4清profiles，taskset -c 0-79 /usr/bin/python3 scripts/run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v38 --domain 210 --gazebo-port 20290 > log/p2c_v38_dev_forced2_runner.log 2>&1。原launch/observer/config/case/sourceSHA保留。\n\n')
 f.write(f"PARTIAL_COMPLETE{z['elapsed_sim_time_sec']:.1f}s，success=false/partial_completion/failed tb1；检测172.7/RALLY174.3s，各charge1/min{z['battery_minimum_energy']}、0contacts/exhaustion/task-time infra/retry；tb1正电量约60.90 FAILED。owner{s['owner_pid']}/observer{s['observer_pid']} exit0/0閉合，所有原件SHA保持。check_p2c_gate.py --run-root log/p2c/20261009_p2c_v38 --development --cases dev_forced2 --output log/p2c_v38_dev_forced2_gate.json exit1/FAIL；audit_p2c_v38_independent.py 12PASS。其他3dev/17formal/2physical/917未调用。\n\n")
 f.write('tb2原2254.582接触腿→2263.782SUCCEEDED→2263.882return_finished/cancel0；不作跨原轨迹因果。2339.282 tb1在当前自由/安全单元仍无全known清空返路，原30s保护后FAILED；完整source snapshot逐字safety绑定、AP集合输入逐字ledger绑定。diagnose_p2c_v39_native_route.py首错误调用不存在API只读失败保留，改用existing charging_route_field/known_return_route重建local/fused均None；plot_p2c_v39_return_connectivity.py自由图连通/0.35净空断开。SDF未配准占用比较仅诊断、不证明同伴回波原因、不作安全地图或AP输入。后续原集合采样加密候选需新freeze及原任务，不放宽任何硬门。\n')
print(json.dumps(dict(status='FAIL',originals=1,audits=12,artifacts=len(artifacts),owned_closed=True)))
