import collections, gzip, hashlib, json, os
from pathlib import Path
from datetime import datetime, timezone

root = Path('/home/zhuyulab/ns3-workspace')
r = root / 'ros2_ws/ros2-multi-robot-automap'
w = root / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
report = w / 'report'
base = r / 'log/p2c/20261009_p2c_v35'
freeze = '7d9709b907f2f38f1252eee8ae4fb53c42f3cc13'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

originals, closures, leases, snapshots = {}, {}, {}, {}
for p in sorted(base.glob('*/summary.json')):
    s = json.loads(p.read_text()); c = s['case']; z = s['result']
    assert s['git_commit'] == freeze
    assert z['collision_events'] == 0 and not z['failed_robots']
    assert s['runner_returncode'] == s['observer_returncode'] == 0
    closures[c] = {}
    for key in ('owner_pid', 'observer_pid'):
        try:
            os.kill(s[key], 0)
        except ProcessLookupError:
            closures[c][key] = dict(pid=s[key], closed=True)
        else:
            raise AssertionError(('owned process still live', c, key))
    for name, digest in s['evidence_sha256'].items():
        assert sha(p.parent / name) == digest
    counts = collections.Counter()
    snapshot_path = r / f'log/p2c_v35_{c}_expired_snapshot.json'
    snapshot = json.loads(snapshot_path.read_text()) if snapshot_path.exists() else None
    found = False
    for line in (p.parent / 'ledger.jsonl').open():
        e = json.loads(line)
        if e.get('event') == 'coordinator_planning_lease_expired':
            counts[e['stage']] += 1
        if snapshot is not None and e == snapshot:
            found = True
    if snapshot is not None:
        assert found, (c, 'snapshot must be exact original ledger row')
        snapshots[c] = dict(snapshot_sha256=sha(snapshot_path), original_ledger_sha256=sha(p.parent/'ledger.jsonl'),
                            ledger_index=snapshot['ledger_index'], stage=snapshot['stage'])
    originals[c] = s; leases[c] = dict(counts)
assert len(originals) == 4
assert [c for c, s in originals.items() if s['result']['success']] == ['dev_forced2']
closures['checked_at_utc'] = datetime.now(timezone.utc).isoformat()
(r/'log/p2c_v35_closed_before_next_tasks.json').write_text(json.dumps(closures, indent=2)+'\n')
gate = json.loads((r/'log/p2c_v35_development_gate.json').read_text())
forced = json.loads((r/'log/p2c_v35_dev_forced2_gate.json').read_text())
audits = json.loads((r/'log/p2c_v35_independent_audits.json').read_text())
assert gate['status'] == 'FAIL' and forced['status'] == 'PASS'
assert len(audits) == 4 and all(len(a)==12 and all(v['status']=='PASS' for v in a.values()) for a in audits.values())
names = ['check_p2c_v35_freeze.py', 'p2c_v35_freeze_check.json',
         'p2c_v35_development_gate.json', 'p2c_v35_development_gate.log',
         'p2c_v35_dev_forced2_gate.json', 'p2c_v35_dev_forced2_gate.log',
         'audit_p2c_v35_independent.py', 'p2c_v35_independent_audits.json', 'p2c_v35_independent_audits.log',
         'peek_p2c_v35_tasks.py', 'p2c_v35_closed_before_next_tasks.json',
         'prepare_p2c_v35_failure.py', 'profile_p2c_v35_expired.py',
         'p2c_v35_expired_profiles.json', 'p2c_v35_expired_profiles.log']
files = [p for p in base.rglob('*') if p.is_file() and p.suffix != '.pyc']
files += [r/'log'/name for name in names]
files += list((r/'log').glob('p2c_v35_dev*_runner.log'))
files += list((r/'log').glob('p2c_v35_dev*_expired_snapshot.json'))
files += list((r/'log').glob('p2c_v35_dev*_expired_profile.txt'))
assert all(p.exists() for p in files)
destination = report/'20261009_p2c_v35_artifacts'
assert not destination.exists(); destination.mkdir()
artifacts = []
for p in sorted(set(files)):
    q = destination/('__'.join(p.relative_to(r).parts)+'.gz')
    q.write_bytes(gzip.compress(p.read_bytes(), compresslevel=6, mtime=0))
    assert gzip.decompress(q.read_bytes()) == p.read_bytes()
    artifacts.append(dict(source=str(p.relative_to(root)), source_sha256=sha(p),
                          archive=str(q.relative_to(report)), archive_sha256=sha(q)))
profiles = json.loads((r/'log/p2c_v35_expired_profiles.json').read_text())
out = dict(status='FAIL', scope='Four same-freeze development originals; formal17/physical2/917 not invoked',
           task_stack_frozen_commit=freeze, originals=originals, strict_gate=gate,
           first_forced_gate=forced, independent_audits=audits, owned_closed=closures,
           planning_lease_aborts=leases, conditional_expired_input_profiles=profiles,
           exact_ledger_snapshot_binding=snapshots, task_retries=0, artifacts=artifacts)
(report/'20261009_p2c_v35_failed_development.json').write_text(json.dumps(out, indent=2)+'\n')
text = '# P2C.1 v35 四开发原任务 FAIL\n\n'
text += '冻结7d9709b907f2f38f1252eee8ae4fb53c42f3cc13，control SHA8687306f698d83b121d9dbbe8d39147b4a112f5cf07d0f18916bf3d84cf6938d。首强制strict/native PASS并关闭后才调用后三格，同源四个owner/observer均自然exit0；原任务全部保留，无重试回填。正式17/物理2/917均未调用。\n\n'
text += '| 原格 | 原生结果与秒数 | 检测/集合秒 | Nav2 | 总charge | min energy |\n|---|---|---|---|---|---|\n'
for c, s in originals.items():
    z = s['result']
    text += f"| {c} | {z['task_phase']} {z['termination_reason']} {z['elapsed_sim_time_sec']:.1f} | {z['time_to_detect_sec']}/{z['time_to_rally_sec']} | {z['nav_goal_count']} | {z['battery_total_charges']} | {z['battery_minimum_energy']:.10f} |\n"
text += '\n四格0接触/耗尽/failed机器人/infra/retry。forced两机各charge1，真实5.0秒保持/51样本/最大间隔.1秒；独立48项返航/能量/来源/探索/集合/进程审计PASS，不能代替完整开发门禁。严格开发checker因后三格success=false而FAIL。\n\n'
text += 'lease弃置次数/阶段：'+json.dumps(leases, ensure_ascii=False)+'。\n\n'
text += '首次保存了不可逆弃置时的完整冻结输入；三份诊断逐字等于原ledger行，绑定ledger SHA和index。固定来源时刻条件重建完整计算的三次cold：lab约2.35–2.41s、rooms3.47–3.61s、corr2.24–2.46s，原剩余租约约1.34/1.59/1.41s；每轮约270/561/243路线调用、1950/4554/2026返航预算查找。主要支出是大量候选的完整预算、局部障碍veto和同伴价格，随后路线前缀才拒绝。上述是条件计算剖析，并非历史实时回放、端到端因果或最坏时限。\n\n'
text += '保留原300s/2–5–60s来源TTL/5s真实保持、原生安全储备与所有历史失败。P2C.1仍未完成，P3C.5已验收，无P4/ns-3/Wi-Fi/RL。原始命令/source/evidence/owner哈希在JSON和gzip旁证中。\n'
(report/'20261009_p2c_v35_failed_development.md').write_text(text)
heading = '## 2026-10-09 P2C.1 v35 四开发原任务 FAIL'
assert heading not in (w/'log.md').read_text()
entry = '\n\n'+heading+'\n\n'
entry += '7d9709b commit/push0和check_p2c_v35_freeze.py PASS之后：Humble+install、PYTHONNOUSERSITE=1、FastDDS UDPv4、清旧profiles；taskset -c 0-79 /usr/bin/python3 scripts/run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v35 --domain 210 --gazebo-port 20290 > log/p2c_v35_dev_forced2_runner.log 2>&1。首强制strict checker PASS并关闭后，后三格同环境/同run-id/同freeze，case/domain/port分别dev_lab101/211/20291、dev_rooms202/212/20292、dev_corridors303/213/20293，各重定向log/p2c_v35_<case>_runner.log。完整launch/observer/configuration命令与参数在各原summary/manifest及归档JSON。\n\n'
for c, s in originals.items():
    z = s['result']
    entry += f"{c}: {z['task_phase']}/{z['termination_reason']} elapsed={z['elapsed_sim_time_sec']:.1f}, completion={z['completion_time_sec']}, detect={z['time_to_detect_sec']}, rally={z['time_to_rally_sec']}, Nav2={z['nav_goal_count']}, charges={z['battery_total_charges']}, min={z['battery_minimum_energy']}, owner={s['owner_pid']}/observer={s['observer_pid']} exit0/0; lease={leases[c]}。\n\n"
entry += '全部原任务/owner/observer关闭后继续修改；4格0接触耗尽failed/infra/retry。check_p2c_gate.py --run-root log/p2c/20261009_p2c_v35 --development --output log/p2c_v35_development_gate.json exit1/FAIL，audit_p2c_v35_independent.py exit0/48PASS，来源是7d9709b对应当前helper，在任何v36生产修改前执行。profile_p2c_v35_expired.py exit0：精确原弃置输入、固定来源epoch/条件goal sink，cold3次lab2.346/2.409/2.378、rooms3.540/3.468/3.611、corr2.412/2.238/2.457s；原租约slack1.344/1.591/1.406s。条件剖析不是原实时/轨迹/任务因果证据。无formal17/physical2/917，不能复用forced200.7s填新freeze。报告20261009_p2c_v35_failed_development.md/.json。\n'
with (w/'log.md').open('a') as f:
    f.write(entry)
print(json.dumps(dict(status='FAIL', artifacts=len(artifacts), originals=4, audits=48, owned_closed=True)))
