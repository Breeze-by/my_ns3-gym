import ast,gzip,hashlib,json,re,subprocess
from pathlib import Path
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap';w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
parent='67264507420969a9ae9ea3ffe74aa00d69573853'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def old(p):return subprocess.check_output(['git','show',f'{parent}:{p.relative_to(root)}'],cwd=root)
def archive(paths,name):
 destination=report/name;destination.mkdir();rows=[]
 for p in sorted(set(paths)):
  out=destination/('__'.join(p.relative_to(r).parts)+'.gz');assert not out.exists()
  out.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0));assert gzip.decompress(out.read_bytes())==p.read_bytes()
  rows.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(out.relative_to(report)),archive_sha256=sha(out)))
 return rows
base=r/'log/p2c/20261009_p2c_v26';paths=sorted(base.glob('*/summary.json'));assert len(paths)==4
originals={};processes={};graphs={}
from check_p2c_gate import launch_process_audit
from p2c_native_graph import native_tf_ingress_audit
for p in paths:
 s=load(p);case=s['case'];originals[case]=s;d=s['result'];assert s['git_commit']==parent
 assert s['runner_returncode']==s['observer_returncode']==0 and d['collision_events']==0 and not d['failed_robots']
 assert all(v['battery_minimum_energy']>0 for v in d['robots'].values())
 for name,h in s['evidence_sha256'].items():assert sha(p.parent/name)==h
 processes[case]=launch_process_audit(p.parent);graphs[case]=native_tf_ingress_audit(load(p.parent/'native_graph.json'),s['config']['cases'][case]['robot_count'],True)
assert sum(s['result']['success'] for s in originals.values())==2
gate=load(r/'log/p2c_v26_development_gate.json');assert gate['status']=='FAIL' and {e['case'] for e in gate['errors']}=={'dev_lab101','dev_corridors303'}
independent=load(r/'log/p2c_v26_independent_audits.json');assert all(v['status']=='PASS' for row in independent.values() for k,v in row.items() if k!='native_vs_gateway_frame_samples')
aggregate={key:sum(row[section][key] for row in independent.values()) for section,key in (
 ('native_return','return_triggers'),('native_return','map_budget_reconstructions'),('native_return','pose_lease_reconstructions'),('native_return','local_legs'),('native_return','charger_returns'),('native_energy','snapshots'),('exploration_travel','executed_frontier_witnesses'),('exploration_travel','initial_visual_witnesses'),('exploration_travel','resumed_frontier_witnesses'),('exploration_travel','relative_travel_discounts'),('exploration_travel','spatial_diversity_witnesses'),('target_survey','target_information_survey_witnesses'),('ap_return_veto','delivered_return_vetoes'),('rally_assignment','failed_assignments_rebuilt'),('rally_assignment','chosen_assignments_rebuilt'),('lookahead','two_frontier_charge_decisions'))}
frames={case:{name:dict(samples=len(rows),initial_missing=sum(v['native_age_sec'] is None for v in rows),stale=sum(v['native_age_sec'] is not None and v['native_age_sec']>2. for v in rows),maximum_valid_age_sec=max(v['native_age_sec'] for v in rows if v['native_age_sec'] is not None)) for name,rows in row['native_vs_gateway_frame_samples'].items()} for case,row in independent.items()}
headings=load(r/'log/p2c_v26_heading_age_diagnostic.json');counts=dict(healthy=0,lapsed=0)
for row in headings:
 for e in row['heading_requests']:
  age=e['target_lease']['age_sec'];assert age>=0;counts['healthy' if age<=5. else 'lapsed']+=1
assert counts==dict(healthy=4,lapsed=3)
files=[p for p in base.rglob('*') if p.is_file() and p.suffix!='.pyc']
files += [r/'log'/n for n in ('check_p2c_v26_freeze.py','p2c_v26_freeze_check.json','p2c_v26_dev_forced2_gate.json','p2c_v26_dev_forced2_gate.log','p2c_v26_development_gate.json','p2c_v26_development_gate.log','audit_p2c_v26_independent.py','p2c_v26_independent_audits.json','p2c_v26_independent_audits.log','p2c_v26_heading_age_diagnostic.json')]
files += list((r/'log').glob('p2c_v26_dev_*_runner.log'))
failure=dict(status='FAIL',scope='All4 frozen development originals',task_stack_frozen_commit=parent,originals=originals,strict_gate=gate,independent_audits=independent,aggregate=aggregate,native_tf_sample_summary=frames,launch_process_audits=processes,native_graph_audits=graphs,
 task_time_infrastructure_failures=0,task_retries=0,all_owned_closed_before_edits=True,healthy_heading_source_age_diagnostic=headings,heading_requests=counts,
 limitations='Original task trajectories stay unchanged. Four requests have original delivered confirmation source age0.5..1s; a new policy would suppress those same call conditions, not recreate a task-time counterfactual. Three lapsed requests remain legitimate recovery. No charge-order counterfactual trial was run; corridor has only one unfunded rally robot after its peer already charged.',
 commentary_erratum='Room native completion211.5s; earlier209.4 commentary was incorrect and corrected from immutable summary.',
 unrun=['17 formal','both physical','917 first exposure'],artifacts=archive(files,'20261009_p2c_v26_artifacts'))
(report/'20261009_p2c_v26_failed_development.json').write_text(json.dumps(failure,indent=2)+'\n')
(report/'20261009_p2c_v26_failed_development.md').write_text('''# P2C.1 v26 四原开发 FAIL

冻结67264507420969a9ae9ea3ffe74aa00d69573853的all4：forced原生COMPLETE241.9秒/检测145.3/RALLY147.3、两机各charge1；rooms原生COMPLETE211.5秒/检测93.3/RALLY113.4、零charge；lab检测106.1/RALLY147.3、300.2秒timeout/两机charge1；corr检测109.0/RALLY132.1、300.1秒timeout/两机charge1。四格零接触/耗尽/failed机器人/任务期子进程崩溃，四owner与observer0，所有owned关闭后才编辑。Lab末三机位置误差0.02248/0.00940/0.01822米但缺完整native五秒保持；corr一机仍距2.51246米，不能判成功。房间209.4秒中间口头记录有误，以原211.5秒更正；未改任何原结果。

四份同冻结原summary/源码/环境/命令/图/账本/metrics/关闭记录与SHA保留；strict full开发FAIL（仅lab/corr native success断言），无任务重试/回填/阈值放宽。新17正式/两受控物理与917未调用。

四格八类独立审计全部PASS：16闭合返航触发/16map预算/28pose租约、12local腿/6charger returns、590能量快照、53探索（11已知空间补查）/18接续/4相对偏好/53局部可见偏好、3真实目标信息勘察（lab2/rooms1）、10AP返路否决、3失败/4成功集合分配、1两前沿提前充电与全部native图/任务期进程审计。这些本地腿不是预声明远端断网双格的替代。新目标信息勘察已有真实Nav2派发，仍不等同整任务通过或因果收益。

发现后实际原记录显示7次target_observation_heading：corr两次的目标源龄1.0/.7秒，rooms一次.6秒，lab一次.5秒；另三次lab6.6/5.4/5.3秒为正常确认间断。原restore_observer_heading在健康确认时仍允许居中转向，会抢占FOUND勘察和RALLY预充电回调。现有RALLY纠正已使用>5秒确认间断，下一候选将前段统一；不改当前所存原轨迹，不从七条记录推断节省几秒。查看充电顺序前提时发现corr正式集合只余一台未funded，另台已经charged，未运行也未采用充电排列反事实试验。

P3C.5已验收，P2C.1仍进行，无P4/ns-3/Wi-Fi/RL。
''')
m=re.search(r'(\d+) passed in ([\d.]+)s',(r/'log/p2c_v27_full_components.log').read_text());assert m
b=re.search(r'4 packages finished \[([\d.]+)s\]',(r/'log/p2c_v27_build.log').read_text());assert b
source=load(r/'log/p2c_v27_source.json');runtime=load(r/'log/p2c_v27_visual_runtime.json');assert source['status']==runtime['status']=='PASS'
assert runtime['observer_heading_audit']['quiet_holds']==runtime['observer_heading_audit']['heading_turns']==1
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py';assert runtime['control_sha256']==sha(control)
def methods(data):
 cl=next(n for n in ast.parse(data).body if isinstance(n,ast.ClassDef) and n.name=='HeadquartersControl')
 return {n.name:ast.dump(n,include_attributes=False) for n in cl.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
before=methods(old(control));after=methods(control.read_bytes());changed=[k for k,v in before.items() if after[k]!=v];assert changed==['restore_observer_heading']
pure=lambda data:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(data).body if isinstance(n,ast.FunctionDef)}
assert pure(old(control))==pure(control.read_bytes())
unchanged={}
for rel in ('src/multi_robot_exploration/multi_robot_exploration/battery_manager.py','src/multi_robot_exploration/multi_robot_exploration/tf_ingress_sampler.py','src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py','scripts/observe_p3b5.py','scripts/p2c_native_graph.py'):
 p=r/rel;assert old(p)==p.read_bytes();unchanged[rel]=sha(p)
for n,cfg in (('p2c_v27_manifest.json','p2c_integration_manifest.json'),('p2c_v27_blackout_manifest.json','p2c_blackout_manifest.json')):assert load(r/'log'/n)['config']==load(r/'scripts'/cfg)
qa=[r/'log'/n for n in ('p2c_v27_directed.log','p2c_v27_full_components.log','p2c_v27_build.log','p2c_v27_source.json','p2c_v27_source.log','p2c_v27_manifest.json','p2c_v27_blackout_manifest.json','p2c_v27_visual_runtime.json','p2c_v27_visual_runtime.log','prepare_p2c_v27_evidence.py')]
components=dict(status='PASS',scope='Prospective original5s observer heartbeat in all waiting-heading paths, not mission success',parent_commit=parent,functional_checks=int(m[1]),component_wall_sec=float(m[2]),directed_checks=94,build_wall_sec=float(b[1]),control_sha256=sha(control),source_audit=source,actual_ros_dds=runtime,
 changed_central_methods=changed,preserved_central_methods=len(before)-1,all_pure_functions_ast_preserved=True,unchanged_from_parent=unchanged,
 algorithm='With original eligibility/body/route/energy/lease conditions, do not recenter a waiting observer while its delivered target confirmation is at most5s old. Record a throttled private quiet witness. Beyond5s, the original within60s lease turning recovery remains. New audit reconstructs confirmation ages/pose leases and rejects healthy turns or forged quiet witnesses.',
 limitations='Fresh confirmation is delivered evidence, not a guarantee of later visibility. Synthetic action-client real DDS proof is not physical motion. Original traces classify4 avoidable calls but do not prove task-time or energy savings.',
 unrun=['new all4 development','new17 formal','new2 physical','917 first exposure'],artifacts=archive(qa,'20261009_p2c_healthy_confirmation_artifacts'))
(report/'20261009_p2c_healthy_confirmation_components.json').write_text(json.dumps(components,indent=2)+'\n')
(report/'20261009_p2c_healthy_confirmation_components.md').write_text(f'''# P2C.1 v27 健康确认时安静保持组件 PASS

v26同冻结all4为2COMPLETE（forced241.9/rooms211.5）与2RALLYtimeout（lab300.2/corr300.1），零接触/耗尽/failed/task期infra，原始完整失败保持。53探索/590能量/16closed return与四份八类审计PASS，3目标信息勘察真实执行，不能替代原生任务成功。

七次实际朝向请求中四次目标确认源龄只有0.5..1秒，原等待-observer居中转向与既有RALLY的>5秒确认间断条件不一致，会阻塞勘察/预充电回调。新候选仅统一该已有窗口：原输入、相机几何、身体/路线/完整返航和能源保护满足后，仍有≤5秒有效确认就不发转向；超过5秒且60秒lease仍有效仍走原实际恢复。每5秒最多一条私有quiet记录，不新增模型应用包；独立读者核验源龄、姿态源、几何与不平移，拒绝健康时转向、失效quiet、源/朝向/范围篡改。原四条调用的抑制条件成立，不是原任务反事实或已测量节时。

{int(m[1])}完整功能PASS{float(m[2]):.2f}秒、94定向PASS7.02秒、四包{float(b[1]):.2f}秒、171保护/4授权/54协议、两声明和actual DDS/domain215 PASS。DDS真实发布quiet1与lapsed转向1，前者无action call，后者经过原实际selector/planner/recorder但动作客户端为synthetic；原79已知候选数值与旧int64故障复现、目标勘察检查一并保留。仅一个中央方法修改，其余{len(before)-1}及全部纯函数AST、native battery/sampler/launch/observer/native图字节保持；300秒/5秒native保持/全部TTL与安全/物理/任务重试规则未改。

新all4/17/2须clean pushed freeze；917未暴露。P3C.5已验收，无P4/ns-3/Wi-Fi/RL。
''')
note=f'2026-10-09 P2C.1 v27健康确认安静保持组件PASS、待新冻结：v26 all4为forced241.9/rooms211.5原生COMPLETE和lab300.2/corr300.1 RALLYtimeout，四格零接触耗尽failed与task期infra、外层0，原FAIL保留不回填。53探索11补查/590能量/16closed返航/3真实目标信息勘察与四份八类独立审计PASS，不替代远端断网或native成功。7原heading请求中4源龄.5..1s；新统一原5s heartbeat，健康确认安静，>5s且60s lease有效仍按原保护恢复，私有quiet与独立读者/DDS验证。{int(m[1])}功能/94定向/四包{float(b[1]):.2f}s/171保护4授权54协议/actual DDS两manifest PASS，其余72中央方法及全部纯函数/native源/300s/5s/TTL/硬预算/几何保持。新4开发/17正式/2物理需clean pushed freeze，917未暴露，P3C.5已验收，无P4/ns-3/Wi-Fi/RL。报告20261009_p2c_healthy_confirmation_components.md及20261009_p2c_v26_failed_development.md。'
for p in (w/'AGENTS.md',w/'RESEARCH_PLAN.md',w/'IMPLEMENTATION_PLAN.md',r/'user_guide.md',r/'launch_commands.md'):
 first,rest=p.read_text().split('\n',1);p.write_text(first+'\n\n'+note+'\n'+rest)
p=root/'AGENTS.md';p.write_text(p.read_text().replace('## Current Handoff\n','## Current Handoff\n\n'+note+'\n',1))
with (w/'log.md').open('a') as f:
 f.write('\n\n## 2026-10-09 P2C.1 v26四原开发失败及v27健康确认窗口\n\n'+note+'\n\n')
 f.write('6726450推送后独立check_p2c_v26_freeze.py PASS，source Humble+install/PYTHONNOUSERSITE=1/FastRTPS-UDPv4/taskset -c0-79，run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v26 --domain 210 --gazebo-port 20290。原native241.9/各charge1/5.8s保持，严格--development --cases dev_forced2 PASS，检查源码/上游仍同freeze、其他三格未启动后同run-id并行--case dev_lab101 --domain211 --gazebo-port20291、dev_rooms202/domain212/20292、dev_corridors303/domain213/20293，各首次原owner及observer0全部自然结束后才修改。全--development --output log/p2c_v26_development_gate.json FAIL仅lab/corr原生超时，audit_p2c_v26_independent.py八类四格PASS，完整原始/命令/config/environment/sourceSHA/native图/失败/关闭记录归档；17正式/两物理/917未启动，无任务重试。\n\n')
 f.write('房间209.4秒中间commentary有误，原summary native211.5秒已纠正，不改任何输入/输出。只读解析七个coordinator_navigation_decision/target_observation_heading并另存p2c_v26_heading_age_diagnostic.json，四健康源龄.5..1秒与三间断>5秒；原条件变更不称反事实任务收益。查看充电优先顺序时corr集合只余一个unfunded robot，未运行或采用新的排序试验。\n\n')
 f.write('v27 pytest -q test_observer_healthy_confirmation.py/test_rally_observation_recovery.py/test_target_information_survey.py94 PASS7.02秒；完整pytest功能三lint ignore1162 PASS85.13秒；colcon build四包5.54秒；check_p2c_source --output log/p2c_v27_source.json；run_p2c_tasks --case dev_forced2 --run-id 20261009_p2c_v27 --domain210 --gazebo-port20290 --validate-only和physical_fault/--manifest scripts/p2c_blackout_manifest.json/20261009_p2c_v27_physical/domain219/20299 validate-only；check_p2c_visual_runtime --output log/p2c_v27_visual_runtime.json在domain215实际DDS quiet无action1/lapsed按原保护synthetic action1/原candidate与survey检查PASS。精确argv/输出/源码SHA见压缩原件，全部源/实验/文档须同session提交推送后新4/17/2，无P4/ns-3/Wi-Fi/RL。\n')
print(json.dumps(dict(originals=4,failure_artifacts=len(failure['artifacts']),component_artifacts=len(components['artifacts']),aggregate=aggregate,functional_checks=int(m[1]),build_sec=float(b[1]),heading_counts=counts)))
