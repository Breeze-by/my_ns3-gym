import bisect,json,hashlib
from pathlib import Path
from check_p2c_gate import return_audit,energy_audit
p=Path("log/p2c/20261009_p2c_v15/20261009_p2c_v15_dev_forced2")
s=json.loads((p/"summary.json").read_text()); gateway={}
for line in (p/"ledger.jsonl").open():
 e=json.loads(line)
 if e.get("event")=="accepted" and e.get("message_type")=="frame_state":
  gateway.setdefault(e["sender"],[]).append((e["event_time"],e["source_time"]))
rows=[]
for line in (p/"safety_events.jsonl").open():
 e=json.loads(line); d=e.get("data")
 if not isinstance(d,dict) or d.get("event")!="energy_accounting":continue
 t=d["sim_time"]; frames=gateway.get(d["robot"],[]); i=bisect.bisect_right(frames,(t,float("inf")))-1
 rows.append(dict(robot=d["robot"],sim_time=t,mode=d["mode"],native_frame_source=d["frame_source_time"],native_frame_age=None if d["frame_source_time"] is None else t-d["frame_source_time"],latest_gateway_source=frames[i][1] if i>=0 else None,latest_gateway_source_age=t-frames[i][1] if i>=0 else None))
try:native=return_audit(p/"safety_events.jsonl",True,True)
except Exception as error:native=dict(status="FAIL",error=repr(error))
energy=energy_audit(p/"safety_events.jsonl",s["result"],True)
stale=[r for r in rows if r["native_frame_age"] is not None and r["native_frame_age"]>2]
result=dict(scope="Read-only pairing of native saved source ages and preceding original gateway accepts; not native callback receipt latency",source_commit=s["git_commit"],native_return_audit=native,native_energy_audit=energy,snapshots=len(rows),stale_native_snapshots=len(stale),stale_native_with_gateway_age_at_most_1_sec=sum(r["latest_gateway_source_age"] is not None and r["latest_gateway_source_age"]<=1 for r in stale),native_frame_age_max=max(r["native_frame_age"] for r in rows if r["native_frame_age"] is not None),gateway_delivery_source_age_max=max(when-source for frames in gateway.values() for when,source in frames),rows=rows)
out=Path("log/p2c_v15_native_tf_diagnosis.json");assert not out.exists();out.write_text(json.dumps(result,indent=2)+"\n");print(json.dumps({k:v for k,v in result.items() if k not in ("rows","native_energy_audit")}))
