import ast,hashlib,json,subprocess
from pathlib import Path
root=Path('/home/zhuyulab/ns3-workspace');relative=Path('ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/multi_robot_exploration/control.py')
source=subprocess.check_output(['git','show','d70b277c853cc736c40b535a9d3551a0c99b0950:'+str(relative)],cwd=root,text=True)
parts=[]
for node in ast.parse(source).body:
 if isinstance(node,ast.FunctionDef) and node.name in ('assign_rally_poses','_assign_rally_poses'):parts.append(ast.get_source_segment(source,node))
original='\n\n'.join(parts)+'\n'
cases=[];specs=[('20261009_p2c_v40','dev_forced2','failed','first'),('20261009_p2c_v40','dev_forced2','failed','last'),('20261009_p2c_v38','dev_forced2','chosen','first'),('20261009_p2c_v14','dev_forced2','chosen','first'),('20261009_p2c_v14','dev_lab101','chosen','first'),('20261009_p2c_v14','dev_rooms202','chosen','first'),('20261009_p2c_v14','dev_corridors303','chosen','first'),('20261009_p2c_v26','dev_corridors303','chosen','first')]
for run,case,status,where in specs:
 ledger=Path('log/p2c')/run/(run+'_'+case)/'ledger.jsonl'
 assert ledger.exists(),ledger
 matches=[e for line in ledger.open() if (e:=json.loads(line)).get('event')=='coordinator_rally_assignment_'+status]
 assert matches,(run,case,status)
 e=matches[0 if where=='first' else -1]
 cases.append(dict(name=run+'_'+case+'_'+where,original_ledger=str(ledger),ledger_sha256=hashlib.sha256(ledger.read_bytes()).hexdigest(),ledger_index=e['ledger_index'],event=e))
out=dict(reference_commit='d70b277c853cc736c40b535a9d3551a0c99b0950',reference_source_sha256=hashlib.sha256(source.encode()).hexdigest(),reference_functions=original,reference_functions_sha256=hashlib.sha256(original.encode()).hexdigest(),cases=cases,scope='Same fixed epochs and original delivered grids for exact proposal equivalence, not original trajectory replay')
p=Path('src/multi_robot_exploration/test/fixtures/p2c_v40_rally_computation_reference.json');assert not p.exists();p.write_text(json.dumps(out,separators=(',',':'))+'\n')
print([e['name'] for e in cases])

