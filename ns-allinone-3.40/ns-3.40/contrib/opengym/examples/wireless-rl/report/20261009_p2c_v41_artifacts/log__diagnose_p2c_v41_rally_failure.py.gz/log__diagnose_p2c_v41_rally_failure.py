import base64,collections,cProfile,hashlib,json,pstats,time,zlib
from pathlib import Path
import numpy as np
from multi_robot_exploration import control as c
p=Path('log/p2c/20261009_p2c_v40/20261009_p2c_v40_dev_forced2/ledger.jsonl')
events=[json.loads(x) for x in p.open()]
failed=[e for e in events if e.get('event')=='coordinator_rally_assignment_failed']
def decode(s):return dict(data=np.frombuffer(zlib.decompress(base64.b64decode(s['grid'])),dtype='<i2').reshape(s['shape']),resolution=s['resolution'],origin=s['origin'])
out=[]
for e in (failed[0],failed[-1]):
    m=decode(e['planning_map']);raw=m['data'];res=m['resolution'];origin=m['origin'];local={n:decode(s) for n,s in e['return_maps'].items()}
    candidates=c.rally_pose_candidates(raw,res,origin,e['target'],adaptive_outer=True)
    row=dict(ledger_index=e['ledger_index'],event_time=e['event_time'],original_wall_sec=e['computation_wall_sec'],
        original_completion=e['computation_completed_at_sec'],source_ages={n:d['age_sec'] for n,d in e['inputs'].items()},candidate_count=len(candidates),robots={})
    for n,pos in e['current_positions'].items():
        st=e['battery_states'][n];home=(st['charge_x'],st['charge_y']);cache={}
        current=c.qualified_return_candidates(raw,res,origin,pos,home,st['charge_radius_m'],local.get(n),cache)
        contacts=[c.qualified_return_candidates(raw,res,origin,(v.x,v.y),home,st['charge_radius_m'],local.get(n),cache) for v in candidates]
        row['robots'][n]=dict(position=pos,mode=st['mode'],energy=st['energy'],
            current_contact=[{k:x[k] for k in ('source','path_distance_m','qualified')} for x in current],
            candidate_contacts=collections.Counter(x['source'] for options in contacts for x in options if x['qualified']))
    start=time.perf_counter()
    surveys=c.target_survey_candidates(raw,res,origin,e['current_positions'],{n:s['mode'] for n,s in e['battery_states'].items()},e['target'],3.,.35)
    row['survey_candidate_wall_sec']=time.perf_counter()-start;row['survey_candidates']=len(surveys)
    row['survey_first']=[{k:v for k,v in s.items() if k not in ('source_map','map','grid')} for s in surveys[:4]]
    out.append(row)
last=failed[-1];m=decode(last['planning_map'])
args=dict(raw_grid=m['data'],resolution=m['resolution'],origin=m['origin'],robot_positions=last['robot_positions'],target=last['target'],objective=last['objective'],battery_states=last['battery_states'],observer_robot=last['observer_robot'],current_positions=last['current_positions'],hold_sec=last['hold_sec'],return_maps={n:decode(x) for n,x in last['return_maps'].items()})
samples=[]
for _ in range(3):
 start=time.perf_counter();answer=c.assign_rally_poses(**args);samples.append(time.perf_counter()-start);assert not answer
prof=cProfile.Profile();prof.runcall(c.assign_rally_poses,**args)
with Path('log/p2c_v41_rally_failure_profile.txt').open('w') as f:pstats.Stats(prof,stream=f).strip_dirs().sort_stats('cumulative').print_stats(32)
result=dict(scope='Original abandoned/failed AP inputs, fixed epoch; no native hidden map or future perception',original_ledger_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),inputs=out,cold_rally_wall_sec=samples,original_assignment_failures=len(failed),actual_survey_commands=sum(e.get('event')=='coordinator_navigation_decision' and 'survey' in e.get('kind','') for e in events))
Path('log/p2c_v41_rally_failure_diagnosis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))

