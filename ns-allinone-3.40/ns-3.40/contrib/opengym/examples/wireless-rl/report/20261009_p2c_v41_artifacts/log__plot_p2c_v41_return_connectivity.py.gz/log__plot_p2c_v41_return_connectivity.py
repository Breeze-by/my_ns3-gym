import base64,hashlib,json,zlib
from pathlib import Path
import numpy as np
from scipy.ndimage import label
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from multi_robot_exploration import control as c
p=Path('log/p2c_v41_native_no_route_snapshot.json');e=json.loads(p.read_text());maps=[e['map_evidence'],*[r['map_evidence'] for r in e['map_evidence']['route_candidates'] if r.get('map_evidence')]]
sources={m['source']:m for m in maps};names=['local','delivered_fused','constrained_fused']
fig,axes=plt.subplots(1,3,figsize=(14.5,5.5));out={}
for ax,name in zip(axes,names):
 m=sources[name];g=np.frombuffer(zlib.decompress(base64.b64decode(m['grid'])),dtype='<i2').reshape(m['shape']);res=m['resolution'];origin=m['origin'];pos=e['position'];home=e['home'];rad=e['charge_radius_m'];cell=c.world_to_grid(*pos,res,*origin)
 safe,distances,_=c.charging_route_field(g,res,origin,home,rad,{})
 components,_=label(safe);display=np.zeros((*g.shape,3));display[g<0]=(.55,.55,.55);display[g==0]=(.94,.94,.94);display[safe]=(.72,.84,.96);display[np.isfinite(distances)]=(.15,.75,.38)
 if not np.isfinite(distances[cell]):display[(components==components[cell])&safe]=(.22,.47,.88)
 extent=(origin[0],origin[0]+g.shape[1]*res,origin[1],origin[1]+g.shape[0]*res)
 ax.imshow(display,origin='lower',extent=extent)
 distance,route=c.known_return_route(g,res,origin,pos,home,rad,{},True)
 if route:
  a=np.asarray(route);ax.plot(a[:,0],a[:,1],color='#9a36be',lw=2,label='Fused geometric path (vetoed)')
 ax.scatter(*pos,c='red',marker='x',s=65,label='tb2 no-route start');ax.scatter(*home,c='orange',s=65,label='tb2 charge center');ax.add_patch(plt.Circle(home,rad,color='orange',fill=False))
 ax.set_xlim(-2.2,5.5);ax.set_ylim(-1.4,5.5);ax.set_aspect('equal');ax.set_xlabel('Map x (m)')
 ax.set_title({'local':'Original local map: disconnected','delivered_fused':'Delivered fused: local veto rejects','constrained_fused':'Constrained fused: disconnected'}[name],fontsize=10)
 ax.legend(loc='lower left',fontsize=8)
 out[name]=dict(source_time=m['source_time'],current_cell_value=int(g[cell]),current_safe=bool(safe[cell]),geometric_contact_distance_m=distance,qualified=None if name=='delivered_fused' else distance is not None)
axes[0].set_ylabel('Map y (m)')
fig.suptitle('Native tb2 input at sim2238.082, energy64.5441; 0.35 m path clearance unchanged',fontsize=12)
fig.text(.5,.01,'Green: charger-reachable safe cells   Blue: disconnected start component   Gray: unknown   Black: occupied\nOriginal delivered inputs only; no world truth, sensor correction or causal diagnosis',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.075,1,.93));destination=Path('log/p2c_v41_return_connectivity.png');assert not destination.exists();fig.savefig(destination,dpi=140);plt.close(fig)
result=dict(scope='Read-only original native map illustration; disconnected complete return, not a sensor fault diagnosis',snapshot_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),png_sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),sources=out)
Path('log/p2c_v41_return_connectivity.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(out))

