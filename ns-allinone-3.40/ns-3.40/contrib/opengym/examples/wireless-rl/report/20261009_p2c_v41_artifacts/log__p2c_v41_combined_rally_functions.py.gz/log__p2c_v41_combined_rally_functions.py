def assign_rally_poses(
    raw_grid, resolution, origin, robot_positions, target, objective="minimax",
    battery_states=None, observer_robot=None, current_positions=None,
    hold_sec=RALLY_HOLD_SEC, return_maps=None,
):
    """Find a fully funded separated assignment with progressive candidates.

    Refine visible outer-ring boundaries in the original three sampled rings.
    If that bounded tier cannot assign all robots, expand to the existing
    angular boundary samples.
    Each level keeps the full return, charge/wait and body-cost optimizer;
    stopping at the first feasible level trades global soft-cost optimality
    for less computation. Actual navigation still requires fresh admission.
    """
    geometry_cache = {}  # Private to this one complete proposal.
    for stratified in (False, True):
        result = _assign_rally_poses(raw_grid, resolution, origin, robot_positions,
            target, objective, battery_states, observer_robot, current_positions,
            hold_sec, return_maps, stratified, geometry_cache)
        if result:
            return result
    return {}

def _assign_rally_poses(
    raw_grid,
    resolution,
    origin,
    robot_positions,
    target,
    objective="minimax",
    battery_states=None,
    observer_robot=None,
    current_positions=None,
    hold_sec=RALLY_HOLD_SEC,
    return_maps=None,
    stratified=True,
    geometry_cache=None,
):
    """Assign separated visible poses, accounting for serial charge waits.

    With delivered batteries, preserve an ACTIVE observer when feasible, then
    minimize predicted charges, soft narrow-return exposure and serial time, then compare
    its remaining budget headroom before the chosen path objective. Extra
    observer surplus must not force a funded peer to charge or take a detour.
    These estimates never authorize a navigation or return.
    """
    if objective not in ("minimax", "total_path"):
        raise ValueError(f"unknown rally assignment objective: {objective}")
    names = sorted(robot_positions)
    candidates = rally_pose_candidates(
        raw_grid, resolution, origin, target, False, stratified,
        adaptive_outer=not stratified,
    )
    if len(candidates) < len(names):
        return {}

    geometry_cache = {} if geometry_cache is None else geometry_cache
    if "traversable" not in geometry_cache:
        geometry_cache["traversable"] = traversable_grid(
            raw_grid, resolution, clearance_m=RALLY_PATH_CLEARANCE_M)
    traversable = geometry_cache["traversable"]
    approach_fields = geometry_cache.setdefault("approach_fields", {})
    options = {}
    for name in names:
        position = robot_positions[name]
        if name not in approach_fields:
            start = world_to_grid(
                position[0], position[1], resolution, origin[0], origin[1]
            )
            # Unknown and occupied starts remain rejected; only a known-free pose
            # may use the bounded clearance escape above.
            start, escape_route = navigation_start_route(
                raw_grid,
                traversable,
                start,
                max(1, math.ceil(0.6 / resolution)),
            )
            distances = path_distance_grid(traversable, start)
            escape_distance = 0.0
            for first, second in zip(escape_route, escape_route[1:]):
                escape_distance += math.dist(first, second)
            approach_fields[name] = (distances, escape_distance)
        distances, escape_distance = approach_fields[name]
        reachable = []
        for index, pose in enumerate(candidates):
            row, column = world_to_grid(
                pose.x, pose.y, resolution, origin[0], origin[1]
            )
            distance = distances[row, column]
            if np.isfinite(distance):
                reachable.append((float(distance + escape_distance), index))
        reachable.sort()
        if not reachable:
            return {}
        options[name] = reachable

    energy_options, modes, charge_times, charge_targets = {}, {}, {}, {}
    return_exposures = {}
    if battery_states is not None:
        current_positions = current_positions or robot_positions
        try:
            if not math.isfinite(hold_sec) or hold_sec < 0:
                return {}
            def local_known_options(name):
                # Ordering only: local unknown cells do not veto fused routes.
                geometry = (return_maps or {}).get(name)
                if geometry is None:
                    return len(options[name]), name
                try:
                    known = 0
                    for _, index in options[name]:
                        pose = candidates[index]
                        cell = world_to_grid(pose.x, pose.y, geometry["resolution"], *geometry["origin"])
                        grid = geometry["data"]
                        known += (0 <= cell[0] < grid.shape[0] and 0 <= cell[1] < grid.shape[1]
                                  and grid[cell] == 0)
                    return known, name
                except (KeyError, TypeError, ValueError, ZeroDivisionError, AttributeError):
                    return len(options[name]), name
            for name in sorted(names, key=local_known_options):
                state = battery_states[name]
                mode = state["mode"]
                energy = float(state["energy"])
                home = (float(state["charge_x"]), float(state["charge_y"]))
                speed = float(state.get("nominal_speed_mps", .18))
                idle = float(state.get("idle_cost_per_sec", .02))
                move = float(state.get("move_cost_per_m", 1.))
                factor = float(state.get("return_path_factor", 2.))
                margin = float(state.get("return_safety_margin", 8.))
                duration = float(state.get("charge_duration_sec", 6.))
                capacity = float(state["capacity"])
                fraction = float(state["charge_target_fraction"])
                values = (*home, energy, speed, idle, move, factor, margin,
                          duration, capacity, fraction, *current_positions[name])
                if (not all(math.isfinite(v) for v in values)
                        or mode not in ("ACTIVE", "RETURNING", "CHARGING")
                        or min(energy, idle, move, margin, duration) < 0
                        or speed <= 0 or capacity <= 0 or factor < 1
                        or not 0 < fraction <= 1):
                    return {}
                home_fields = geometry_cache.setdefault("home_fields", {})
                if name not in home_fields:
                    home_start, escape = navigation_start_route(
                        raw_grid, traversable, world_to_grid(*home, resolution, *origin),
                        max(1, math.ceil(.6 / resolution)))
                    home_distances = path_distance_grid(traversable, home_start)
                    home_escape = sum(math.dist(a, b) for a, b in zip(escape, escape[1:]))
                    home_fields[name] = (home_distances, home_escape)
                home_distances, home_escape = home_fields[name]
                modes[name] = mode
                charge_times[name] = duration
                return_cache = geometry_cache.setdefault("return_caches", {}).setdefault(name, {})
                clearance_fields = geometry_cache.setdefault("clearance_fields", {}).setdefault(name, {})
                return_exposures[name] = {}
                local_map = (return_maps or {}).get(name)
                if mode != "CHARGING":
                    current_routes = qualified_return_candidates(raw_grid, resolution, origin,
                        current_positions[name], home, float(state.get('charge_radius_m', .8)),
                        local_map, return_cache)
                    current_home = min((r['path_distance_m'] for r in current_routes if r['qualified']), default=None)
                    if current_home is None:
                        if mode != 'RETURNING':
                            return {}
                        # Conditional post-charge assignment only. A missing
                        # delivered route is not priced as a feasible return;
                        # peers reserve the bounded local failure/return wait.
                        charge_times[name] += float(state.get('return_timeout_sec', 180.))
                    else:
                        charge_times[name] += current_home * factor / speed + float(
                            state.get('return_recovery_wait_sec', RETURN_RECOVERY_WAIT_SEC))
                charge_targets[name] = capacity * fraction
                energy_options[name] = {}
                for distance, index in options[name]:
                    pose = candidates[index]
                    cell = world_to_grid(pose.x, pose.y, resolution, *origin)
                    home_distance = (home_distances[cell] + home_escape) * resolution
                    if not math.isfinite(home_distance):
                        continue
                    contact_routes = qualified_return_candidates(raw_grid, resolution, origin,
                        (pose.x, pose.y), home, float(state.get('charge_radius_m', .8)),
                        local_map, return_cache)
                    contact = min((r for r in contact_routes if r['qualified']),
                        key=lambda r: (r['path_distance_m'], r['source'] != 'local'), default=None)
                    if contact is None:
                        continue
                    contact_distance = contact['path_distance_m']
                    source = contact['source']
                    geometry = local_map if source == 'local' else dict(
                        data=raw_grid if source == 'delivered_fused' else return_cache['constrained_map']['grid'],
                        resolution=resolution, origin=origin)
                    if source not in clearance_fields:
                        known = geometry['data'] == 0
                        clearance_fields[source] = (np.full(known.shape, np.inf) if np.all(known)
                            else ndimage.distance_transform_edt(known, sampling=geometry['resolution']))
                    exposure = return_route_clearance_exposure(contact['route'], geometry['resolution'],
                        geometry['origin'], clearance_fields[source])
                    if not math.isfinite(exposure):
                        continue
                    return_exposures[name][index] = exposure
                    required = battery_assignment_required_energy(
                        distance * resolution, contact_distance, move, idle, factor, speed, margin,
                        float(state.get('return_recovery_wait_sec', RETURN_RECOVERY_WAIT_SEC))) + idle * hold_sec
                    travel = distance * resolution / speed
                    after_charge = home_distance / speed
                    energy_options[name][index] = (required, travel, after_charge)
                options[name] = [(distance, index) for distance, index in options[name]
                                 if index in energy_options[name]]
                if not options[name]:
                    return {}
        except (KeyError, TypeError, ValueError, ZeroDivisionError):
            return {}

    # Resolve the leading observer budget first so its monotone bound
    # prunes peer combinations before expensive complete energy closures.
    search_order = sorted(names, key=lambda name: (
        battery_states is not None and observer_robot in names and name != observer_robot,
        len(options[name])))
    best = {}
    best_score = (float("inf"),) * (8 if battery_states is not None else 3)
    selected_indices = {}
    minimum_energy_options = {
        name: tuple(min(values[column] for values in choices.values()) for column in range(3))
        for name, choices in energy_options.items()
    }
    minimum_return_exposures = {name: min(values.values())
                                for name, values in return_exposures.items()}
    parked_route_caches = {}
    parked_detour_costs = {}

    def parked_peer_delay(needed):
        # Any funded peer may park before a charged robot comes back from home.
        # Sum single-body detour costs, reusing fields by body pose/home source.
        # Combined-body interactions are still checked at actual dispatch;
        # this nominal additive preference never authorizes a navigation leg.
        delay = 0.0
        for parked in names:
            if parked in needed or modes[parked] != 'ACTIVE':
                continue
            parked_index = selected_indices[parked]
            body = candidates[parked_index]
            for name in names:
                if name not in needed:
                    continue
                index = selected_indices[name]
                key = (parked_index, name, index)
                if key not in parked_detour_costs:
                    state = battery_states[name]
                    _, route = plan_rally_leg(
                        candidates[index], raw_grid, resolution, origin,
                        (float(state["charge_x"]), float(state["charge_y"])),
                        blocked_positions=[(body.x, body.y)],
                        route_cache=parked_route_caches.setdefault((parked_index, name), {}),
                    )
                    speed = float(state.get("nominal_speed_mps", .18))
                    full_route = ((float(state['charge_x']), float(state['charge_y'])), *route)
                    cost = (sum(math.dist(a, b) for a, b in zip(full_route, full_route[1:])) / speed
                            - energy_options[name][index][2]) if route else RALLY_GOAL_TIMEOUT_SEC
                    # Missing masked paths keep the finite recovery preference,
                    # not a false infeasibility proof. Partial bounds omit this
                    # nonnegative term and remain optimistic.
                    parked_detour_costs[key] = max(0.0, cost)
                delay += parked_detour_costs[key]
        return delay

    def search(
        assignments,
        used_indices,
        separation_penalty,
        cost,
        longest_path,
    ):
        nonlocal best, best_score
        score = (
            (longest_path, separation_penalty, cost)
            if objective == "minimax"
            else (separation_penalty, cost, longest_path)
        )
        if battery_states is not None:
            # Independent per-column minima may refer to different candidates;
            # that only makes this an optimistic, admissible partial bound.
            # At a complete leaf every entry is the actual selected option.
            estimates = {name: energy_options[name][selected_indices[name]]
                         if name in selected_indices else minimum_energy_options[name]
                         for name in names}
            requirements, _ = rally_wait_requirements(
                {name: values[0] for name, values in estimates.items()},
                battery_states, modes,
                {name: values[1] for name, values in estimates.items()}, charge_times)
            needed = {name for name in names if modes[name] != "ACTIVE"
                      or float(battery_states[name]["energy"]) <= requirements[name]}
            if any(requirements[name] > charge_targets[name] for name in needed):
                return
            observer_headroom = (max(0., float(battery_states[observer_robot]["energy"])
                                     - requirements[observer_robot])
                                 if modes.get(observer_robot) == "ACTIVE" else 0.)
            complete = len(assignments) == len(search_order)
            time_bound = sum(charge_times[name] + values[2] if name in needed
                             else values[1] if complete
                             else min(values[1], charge_times[name] + values[2])
                             for name, values in estimates.items())
            # Positive soft costs preserve the optimistic partial bound and
            # cannot override observer protection, charge count or feasibility.
            exposure_bound = sum(return_exposures[name][selected_indices[name]]
                if name in selected_indices else minimum_return_exposures[name] for name in names)
            observer_charge = int(observer_robot in needed and modes.get(observer_robot) == "ACTIVE")
            score = (observer_charge, len(needed), exposure_bound, time_bound, -observer_headroom, *score)
        if score >= best_score:
            return
        if len(assignments) == len(search_order):
            if battery_states is not None:
                score = (*score[:3], score[3] + parked_peer_delay(needed), *score[4:])
                if score >= best_score:
                    return
            best = assignments.copy()
            best_score = score
            return
        name = search_order[len(assignments)]
        for distance, candidate_index in options[name]:
            if candidate_index in used_indices:
                continue
            pose = candidates[candidate_index]
            if any(
                math.dist((pose.x, pose.y), (other.x, other.y))
                < RALLY_MIN_SEPARATION_M
                for other in assignments.values()
            ):
                continue
            assignments[name] = pose
            used_indices.add(candidate_index)
            selected_indices[name] = candidate_index
            added_penalty = sum(
                max(
                    0.0,
                    RALLY_PREFERRED_SEPARATION_M
                    - math.dist((pose.x, pose.y), (other.x, other.y)),
                )
                for other_name, other in assignments.items()
                if other_name != name
            )
            search(
                assignments,
                used_indices,
                separation_penalty + added_penalty,
                cost + distance,
                max(longest_path, distance),
            )
            used_indices.remove(candidate_index)
            del assignments[name]
            del selected_indices[name]

    search({}, set(), 0.0, 0.0, 0.0)
    if not best:
        return {}
    return {name: best[name] for name in names}
