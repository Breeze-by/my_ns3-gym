import base64,hashlib,json,zlib
from pathlib import Path
import numpy as np
from scipy.ndimage import distance_transform_edt
from multi_robot_exploration import control as c
base=Path('log/p2c/20261009_p2c_v41/20261009_p2c_v41_dev_forced2')
native=[]
for index,line in enumerate((base/'safety_events.jsonl').open()):
 try:
  e=json.loads(line);d=e.get('data');d=json.loads(d) if isinstance(d,str) else d
 except json.JSONDecodeError:continue
 if isinstance(d,dict) and d.get('robot')=='tb2' and d.get('event')=='return_started' and d.get('reason')=='no_known_route':native.append((index,d))
assert len(native)==1;index,e=native[0]
snapshot=Path('log/p2c_v41_native_no_route_snapshot.json');assert not snapshot.exists();snapshot.write_text(json.dumps(e,indent=2)+'\n')
out={}
for m in [e['map_evidence'],*[x.get('map_evidence',{}) for x in e['map_evidence'].get('route_candidates',[])]]:
 if not m.get('grid'):continue
 g=np.frombuffer(zlib.decompress(base64.b64decode(m['grid'])),dtype='<i2').reshape(m['shape']);p=c.world_to_grid(*e['position'],m['resolution'],*m['origin'])
 field=c.charging_route_field(g,m['resolution'],m['origin'],e['home'],e['charge_radius_m'],{})
 distance,route=c.known_return_route(g,m['resolution'],m['origin'],e['position'],e['home'],e['charge_radius_m'],{},True)
 out[m['source']]=dict(initial_cell=p,initial_value=int(g[p]),initial_safe=None if field is None else bool(field[0][p]),full_distance_m=distance,source_time=m['source_time'],clearance_m=float((distance_transform_edt(g<=0)*m['resolution'])[p]),shape=m['shape'],origin=m['origin'])
events=[json.loads(line) for line in (base/'ledger.jsonl').open()]
goals=[x for x in events if x.get('event')=='coordinator_navigation_decision' and x.get('robot')=='tb2' and x['event_time']<e['sim_time']]
result=dict(scope='Read-only exact original native return input plus separately bound earlier AP commands; no replacement of native sources with AP or later maps',native_input=snapshot.name,native_input_sha256=hashlib.sha256(snapshot.read_bytes()).hexdigest(),original_safety_sha256=hashlib.sha256((base/'safety_events.jsonl').read_bytes()).hexdigest(),original_safety_row_index=index,native_sources=out,earlier_ap_goals=[{k:x.get(k) for k in ('ledger_index','event_time','kind','requested_position','requested_yaw','delivered_input_snapshot')} for x in goals[-5:]])
Path('log/p2c_v41_native_no_route_diagnosis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))

