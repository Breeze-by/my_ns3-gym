import gzip,hashlib,json,os,shutil
from datetime import datetime,timezone
from pathlib import Path

root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
freeze='723a844e54e6f28501d59fc4ed2785f5f2d65592'
def load(p):return json.loads(p.read_text())
def sha(p):
    value=hashlib.sha256()
    with p.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):value.update(block)
    return value.hexdigest()

def archive(name,run,extra):
    summaries=sorted(run.glob('*/summary.json'));originals=[];closed=[]
    for p in summaries:
        row=load(p);assert row['git_commit']==freeze
        for key in ('owner_pid','observer_pid','physics_pid','staging_pid'):
            if key not in row:continue
            assert not Path('/proc',str(row[key])).exists(),('live original',key,row[key])
            closed.append(dict(case=row['case'],kind=key,pid=row[key],closed=True))
        for path,digest in row['evidence_sha256'].items():assert sha(p.parent/path)==digest
        originals.append(row)
    destination=report/(name+'_artifacts');assert not destination.exists();destination.mkdir()
    files=[p for p in run.rglob('*') if p.is_file()]+extra+[Path(__file__)]
    artifacts=[]
    for p in sorted(set(files)):
        assert p.is_file()
        q=destination/('__'.join(p.relative_to(r).parts)+'.gz')
        with p.open('rb') as source,q.open('wb') as target:
            with gzip.GzipFile(fileobj=target,mode='wb',mtime=0,compresslevel=6) as packed:shutil.copyfileobj(source,packed)
        restored=hashlib.sha256()
        with gzip.open(q,'rb') as stream:
            for block in iter(lambda:stream.read(1024*1024),b''):restored.update(block)
        assert restored.hexdigest()==sha(p)
        artifacts.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),
            archive=str(q.relative_to(report)),archive_sha256=sha(q)))
    return dict(status='FAIL',task_stack_frozen_commit=freeze,originals=originals,
        closure=dict(checked_at_utc=datetime.now(timezone.utc).isoformat(),processes=closed),
        task_retries=0,artifacts=artifacts)

main_extra=[p for p in (r/'log').glob('*p2c_v41*') if p.is_file()
    and p.name not in ('prepare_p2c_v41_and_return_failures.py','p2c_v41_and_return_archive.log')]
main=archive('20261009_p2c_v41',r/'log/p2c/20261009_p2c_v41',main_extra)
assert len(main['originals'])==1
z=main['originals'][0]['result'];assert z['task_phase']=='PARTIAL_COMPLETE' and not z['success']
main.update(scope='First required forced-development original failed; other3 development/formal17/main physical2/917 not invoked',
    strict_gate=load(r/'log/p2c_v41_dev_forced2_gate.json'),independent_audits=load(r/'log/p2c_v41_independent_audits.json'),
    no_route_diagnosis=load(r/'log/p2c_v41_native_no_route_diagnosis.json'))
assert main['strict_gate']['status']=='FAIL'
assert len(main['independent_audits']['dev_forced2'])==12
assert all(v['status']=='PASS' for v in main['independent_audits']['dev_forced2'].values())
(report/'20261009_p2c_v41_failed_development.json').write_text(json.dumps(main,indent=2)+'\n')
shutil.copy2(r/'log/p2c_v41_return_connectivity.png',report/'20261009_p2c_v41_return_connectivity.png')
(report/'20261009_p2c_v41_failed_development.md').write_text('''# P2C.1 v41 首强制原任务 FAIL

冻结723a844e54e6f28501d59fc4ed2785f5f2d65592，2026-10-09T12:07:45.321295到12:14:06.322338 UTC。原生PARTIAL_COMPLETE279.1秒，success=false，tb2在正电量下因no_known_route失效；目标247.0秒发现、257.0秒RALLY。两机各charge1，最低16.366306239008143，零接触/耗尽/任务期基础设施失败/任务重试。owner721454/observer721474自然exit0/0并已关闭。12独立审计通过，不替代首强制完整任务门禁。余3开发/17正式/主门2物理/917未调用；另行两格安全表征见独立报告，不能回填本失败。

原始completion_time_sec=279.1和原生5.3秒保持证明均保留；保持只覆盖健康tb1，不是两机全任务完成。完整任务指标按失败惩罚300秒，不能将原始partial字段改为空或计为成功。

失路时2238.082秒，tb2位置(2.9926104632,2.9793562650)，能量64.54412442084852。准确本地/融合输入当前单元均已知自由且满足净空。原本地图完整接触路径不存在；融合几何路径3.725689879米违反本地已知障碍veto；保守融合搜索也没有完整路径。原预算/停止/30秒后明确失败正确执行，但暴露出任务过程中地图返航连通性丢失。不能将其误判为当前位置占用、低电量、无线延迟或已证明的SLAM/传感器因果问题。不能为通过而清除已知障碍、用欧氏距离冒充路径或放宽源TTL。

原始安全行SHA/行号、三份准确原地图、先前AP指令单独绑定和图示见JSON与gzip附件。![原生返航连通性](20261009_p2c_v41_return_connectivity.png)

P3C.5用户已验收。P2C.1完整任务集成未通过；原300秒/.35米/.05米每秒/.1弧度每秒/5秒、源TTL不变，无P4/ns-3/Wi-Fi/RL，917仍未暴露。
''')

extra=[p for p in (r/'log').glob('*p2c_return_characterization*') if p.is_file()]
extra += [r/'log/p2c_return_null_reader_tests.log']
pair=archive('20261009_p2c_return_characterization_failed',r/'log/p2c/20261009_p2c_return_characterization',extra)
assert len(pair['originals'])==2
pair.update(scope='Independent supplemental safety characterization; excluded from mission success/TDI',
    pair_gate=load(r/'log/p2c_return_characterization_final_reader_gate.json'),
    fault_independent=load(r/'log/p2c_return_characterization_fault_final.json'))
assert pair['pair_gate']['status']=='FAIL' and pair['fault_independent']['status']=='PASS'
(report/'20261009_p2c_return_characterization_failed.json').write_text(json.dumps(pair,indent=2)+'\n')
(report/'20261009_p2c_return_characterization_failed.md').write_text('''# P2C.1 独立返航表征原两格 FAIL

与v41主失败分开预声明，冻结723a844；两原格全部保留，不计入完整任务成功或TDI。命令为taskset -c 0-79 /usr/bin/python3 scripts/run_p2c_tasks.py --manifest scripts/p2c_blackout_manifest.json --case physical_ideal/physical_fault --run-id 20261009_p2c_return_characterization，理想domain218/port20298、故障219/20299。完整argv、时间和命令/source/env/ledger/图/原生物理SHA见JSON。

理想格原生COMPLETE211.2秒、每机charge1/min20.97300534492981、零接触/耗尽/机器人失效，但远端准备在首条Nav2动作立即ABORTED，staging exit1；因此严格安全对子FAIL。任务后来的成功不能代替远端准备证据。启动日志显示实际Nav2仍使用不覆盖负坐标准备位的默认代价地图范围；这是待验证的准备就绪缺口，不作所有abort的确定因果归因。原任务算法/安全没有修改。

故障格EXPLORE timeout300.1秒、每机charge1/min12.332414691017467，原生返航/实际Nav2运动通过独立严格审核；此处只证明受控60..250秒断网中的本地返航/充电，非任务成功。两owner与全部观察器/准备器关闭，理想仅staging1，故障全部0；无升级清理/重试/回填。

第一只读读者对未检测目标的null相机元数据执行radians触发TypeError；修复为保留null，只有真实朝向witness才要求有限正值。第二读者将相对run-root与原始绝对physics_command比较而失败；修复为canonical路径。27项读者检查通过，修复后的同一原数据为故障独立PASS/整体FAIL。所有初始失败读者输出和traceback保留，未改写任何原任务输入或结果。

后续仅增加独立准备器边界适配：等待实际Nav2全局代价地图新鲜、同map坐标且覆盖声明准备位置，仍执行原已知自由短腿/原50秒准备期限/原断网62..248秒物理验证窗口。必须另冻结并运行两份新原格，不得覆盖或替换本对子。
''')
with (w/'log.md').open('a') as f:
    f.write('\n\n## 2026-10-09 P2C.1 v41 首强制原任务 FAIL\n\n')
    f.write('723a844 clean pushed freeze；taskset -c 0-79 /usr/bin/python3 scripts/run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v41 --domain 210 --gazebo-port 20290 > log/p2c_v41_dev_forced2_runner.log 2>&1。12:07:45.321295–12:14:06.322338 UTC，owner721454/observer721474 exit0/0。PARTIAL_COMPLETE279.1/successfalse/tb2正电量no_known_route FAILED；detect247/RALLY257/每机charge1/min16.366306239008143/0contact/exhaustion/task-time infra/retry。check_p2c_gate首强制FAIL、12独立审计PASS；其余3/17/主门2/917未调用。准确安全行89/SHA地图均current free且safe，但local/constrained无完整返路，融合3.72569m受local已知障碍veto。首次诊断脚本强求仅一个失路事件失败、改为准确末事件只读重审，初错误保留；map PNG已视检，不作传感器因果归因。原partial completion/proof保留，完整任务失败惩罚300秒。\n')
    f.write('\n## 2026-10-09 P2C.1 独立受控返航两原格 FAIL\n\n')
    f.write('相同723a844独立预声明，check_p2c_return_characterization_freeze.py PASS。Humble+install/PYTHONNOUSERSITE1/FastDDS UDPv4清profiles，taskset -c 0-79 /usr/bin/python3 scripts/run_p2c_tasks.py --manifest scripts/p2c_blackout_manifest.json --case physical_ideal --run-id 20261009_p2c_return_characterization --domain 218 --gazebo-port 20298；fault改case physical_fault/domain219/port20299，各输出log/p2c_return_characterization_*_runner.log。12:23:51开始，ideal12:29:05.722392关闭、fault12:30:35.435229关闭；所有owner/stager/physics/observer闭合。ideal native211.2COMPLETE但首staging Nav2ABORTED/exit1，故strict pairFAIL；fault nativeEXPLOREtimeout300.1但实际62..248窗口原生Nav2返航/两机每charge1独立严格PASS。两格0contact/exhaustion/failed/retry，min20.9730/12.3324。\n\n')
    f.write('check_p2c_blackout读者原null camera TypeError和相对run-root/absolute physics argv绑定FAIL全部保留；仅修复读者，27PASS1.26s，后同原数据fault independent PASS、pair仍FAIL。最新适配/读者68定向PASS1.65s（后续完整/actual DDS另录），实际任务/native/TTL/刺激未改；prepared实际Nav2默认地图bounds不覆盖负准备位，新就绪适配需独立freeze和新两原格，不能回填。\n')
print(json.dumps(dict(main_originals=1,physical_originals=2,main_artifacts=len(main['artifacts']),physical_artifacts=len(pair['artifacts']),both_status='FAIL')))
