import gzip,hashlib,json,re,subprocess
from pathlib import Path
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
parent='f0fe12ca4396be79979296ebf2f72aeaff69216f'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def old(p):return subprocess.check_output(['git','show',f'{parent}:{p.relative_to(root)}'],cwd=root)
assert not (r/'log/p2c/20261009_p2c_v29').exists()
clock=load(r/'log/p2c_v30_shared_clock_runtime.json');visual=load(r/'log/p2c_v30_visual_runtime_final.json')
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py'
native=load(r/'log/p2c_v30_shared_native_runtime.json');native_scope=load(r/'log/p2c_v30_native_ast_scope.json')
assert clock['status']==visual['status']==native['status']=='PASS'
assert native['current_source_sha256']==sha(r/'src/multi_robot_exploration/multi_robot_exploration/battery_manager.py')
assert native['action_dispatcher_sha256']==clock['action_dispatcher_sha256']==sha(r/'src/multi_robot_exploration/multi_robot_exploration/action_callbacks.py')
assert clock['control_sha256']==visual['control_sha256']==sha(control)
rows={x['label']:x for x in clock['cases']}
assert rows['clock_only_two']['action_state_concurrent'] and not rows['current_two']['action_state_concurrent']
assert rows['clock_only_two']['end_sim_time']==rows['current_two']['end_sim_time']==4.1
assert all(not row['normal_state_concurrent'] for row in rows.values())
correction=dict(status='REJECTED_BEFORE_TASKS',unused_candidate_commit=parent,task_invocations=0,
 cause='Installed Humble Future._schedule_or_invoke_done_callbacks uses executor.create_task, outside node callback groups. Original v29 clock/normal-state DDS proof did not cover Future state callbacks; the serialization claim was too broad.',
 counterexample=rows['clock_only_two'],counterexample_source_sha256=clock['clock_only_control_sha256'],
 original_component_checks='Clock/QoS/source-expiry and serialized normal subscription checks remain valid; original1207 tests and build PASS are retained. They do not establish action-response serialization.',
 response='All8 mission response/result callbacks now enqueue completed futures and use an original-state-group guard to drain. Clock alone remains independent.',
 no_task_retries=True,unrun=['v29 all4 development','v29 all17 formal','v29 both physical','917'])
(report/'20261009_p2c_v29_concurrency_correction.json').write_text(json.dumps(correction,indent=2)+'\n')
(report/'20261009_p2c_v29_concurrency_correction.md').write_text('''# P2C.1 v29 冻结后、任务前并发复查勘误

f0fe12ca4396be79979296ebf2f72aeaff69216f已正常推送，但没有启动任何Gazebo任务。最终执行器复查发现，Humble rclpy Future完成回调通过executor.create_task调度，不必经过Node互斥回调组。此前clock DDS证明和1207功能PASS只覆盖时钟、普通状态订阅与租约，不足以支持“动作状态也串行”这个更宽判断；该候选在任务前拒绝。

使用同一实际DDS阻塞状态回调、真实rclpy Future/执行器的四变体复现：旧single时钟停1.1/动作不并发；旧只加two workers时钟仍1.1但动作并发；f0 clock-only two时钟到4.1但动作并发；新队列guard two时钟到4.1且普通状态与动作状态都不并发。f0源码SHA5a088f7b49703e70430f387adafa5038f30598460d2a2c5896f8883f0ab7ee92，原始源码/报告保留在Git f0提交；这是组件真实Future证明，不是实际Nav2任务成功、CPU上界或无线测量。

新修复仅把8处中央动作response/result完成回调送到一个私有标准库SimpleQueue，并触发原default callback group的guard。Future线程不改任务owner；队列接收顺序一次处理，关闭后不收晚到future，context仍活动的guard错误保持可见。guard不建立DDStopic或应用包，原TTL/能量/native/物理参数保持。新同clean pushed freeze的开发与完整集成仍待。
''')
previous=report/'20261009_p2c_live_clock_components.json';doc=load(previous)
doc['post_review_correction']=correction;doc['original_status']=doc['status'];doc['status']='PARTIAL_PASS_REJECTED_CANDIDATE'
previous.write_text(json.dumps(doc,indent=2)+'\n')
q=report/'20261009_p2c_live_clock_components.md';first,rest=q.read_text().split('\n',1)
q.write_text(first+'\n\n勘误：该候选在任务前被拒绝，未执行任何原任务。原clock/普通状态/租约组件PASS仍有效，但不涵盖Humble Future动作完成回调，原串行判断过宽。详见[并发勘误](20261009_p2c_v29_concurrency_correction.md)。原版本保留在Git f0fe12c。\n'+rest)
m=re.search(r'(\d+) passed in ([\d.]+)s',(r/'log/p2c_v30_full_components_final.log').read_text());assert m
b=re.search(r'4 packages finished \[([\d.]+)s\]',(r/'log/p2c_v30_build_final.log').read_text());assert b
source=load(r/'log/p2c_v30_source_final.json');assert source['status']=='PASS' and source['central_future_registrations_deferred']==8
for name,cfg in (('p2c_v30_manifest_shared.json','p2c_integration_manifest.json'),('p2c_v30_blackout_manifest_shared.json','p2c_blackout_manifest.json')):
 assert load(r/'log'/name)['config']==load(r/'scripts'/cfg)
 now=load(r/'scripts'/cfg);before=json.loads(old(r/'scripts'/cfg))
 assert now['cases']==before['cases']
 for key in ('duration_sec','coverage_threshold','owner_shutdown_timeout_sec','native_pose_contract','ap_pose_budget_contract'):
  assert now[key]==before[key]
 if 'return_staging' in before:assert now['return_staging']==before['return_staging']
unchanged={}
for rel in ('src/multi_robot_exploration/multi_robot_exploration/tf_ingress_sampler.py','src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py','scripts/observe_p3b5.py','scripts/p2c_native_graph.py','scripts/ros_smoke_test.py','src/multi_robot_exploration/package.xml'):
 p=r/rel;assert old(p)==p.read_bytes();unchanged[rel]=sha(p)
dest=report/'20261009_p2c_action_serial_artifacts';dest.mkdir();artifacts=[]
files=[p for p in (r/'log').glob('p2c_v30_*') if p.is_file() and p.suffix!='.pyc']+[r/'log/prepare_p2c_v30_evidence.py']
for p in sorted(files):
 q=dest/('__'.join(p.relative_to(r).parts)+'.gz');q.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0))
 assert gzip.decompress(q.read_bytes())==p.read_bytes()
 artifacts.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(q.relative_to(report)),archive_sha256=sha(q)))
components=dict(status='PASS',scope='Prospective corrected central Future serialization and live clock; no task success claim',
 parent_commit=parent,control_sha256=sha(control),correction=correction,functional_checks=int(m[1]),
 component_wall_sec=float(m[2]),directed_checks=329,directed_wall_sec=21.34,build_wall_sec=float(b[1]),
 source_audit=source,actual_dds_clock_and_future=clock,actual_native_future=native,native_ast_scope=native_scope,actual_dds_visual_survey=visual,
 unchanged_from_parent=unchanged,artifacts=artifacts,unrun=['new4 development','new17 formal','new2 physical','917'],
 preserved_fixture_failure='Initial322PASS/1FAIL late goal-acceptance fixture invoked new queued callback without dispatcher fields. Static fixture supplies queue and immediate single-thread drain, original cancellation/late-acceptance assertions preserved; actual DDS verifies real grouped drain.',
 limitations='Controlled blocked callback and actual rclpy Future are component evidence, not real Nav2/Gazebo motion, CPU latency upper bound, mission efficiency, PHY airtime or radio joules. All original native/horizon/source/fault/stimulus criteria remain.')
(report/'20261009_p2c_action_serial_components.json').write_text(json.dumps(components,indent=2)+'\n')
(report/'20261009_p2c_action_serial_components.md').write_text(f'''# P2C.1 v30 动作完成回调串行化组件 PASS

v29 f0在任务前被拒绝，0任务调用；原clock证据没有覆盖Future回调，串行结论已勘误。实际DDS/真实Future四变体严格复现并发反例，新two worker方案同时保持clock更新和中央状态串行。8处中央response/result回调只入标准库SimpleQueue并触发原state组guard，任务状态仅由该guard回调修改。停止新准入后晚到完成不入队；context活动时guard错误仍可见；不新增DDStopic或应用流。

329定向PASS21.34秒，{int(m[1])}全功能PASS{float(m[2]):.2f}秒，四包{float(b[1]):.2f}秒，171保护/4授权/54协议/8中央/2native完成注册审计、两manifest、实际DDS clock/Future/camera/survey/quiet/lapsed PASS。初322PASS/1FAIL仅晚到动作夹具未提供dispatcher字段，原取消/late acceptance断言保留。native新增两处Future同一共享派发器及关闭标志；原生能源/路径纯函数与其余方法AST保持，真实native Future已验证旧owner并发清除反例、新guard按序修改。模型、TF sampler、launch/observer/native graph、JSON reader及package相对f0字节一致；300秒/5秒/所有TTL/2physical stimulus未改。原v28四任务失败保持，不将native2COMPLETE或componentPASS当正式验收。

新4开发→17正式/2物理必须新同clean pushed freeze；917未暴露。该DDS使用合成地图/受控阻塞与真实Future，不声称实际Nav2执行、任务改善、CPU最坏界或Wi-Fi测量。P3C.5已验收，P2C.1仍进行，无P4/ns-3/Wi-Fi/RL。
''')
note=f'2026-10-09 P2C.1 v30 action Future串行组件PASS待新冻结：v29 f0已push但0任务调用，Humble Future executor task绕过callback group，原clock proof不能支持动作状态串行，已勘误并任务前拒绝。实际DDS/真实Future四变体证明旧single/旧two/f0 clock-only/new queue guard，新方案clock1.1→4.1且普通state/动作state均不并发。8中央与2native response/result通过同一private SimpleQueue+各自原state group guard，关闭/晚到/错误保持；无新增应用流。329定向/{int(m[1])}全功能/四包{float(b[1]):.2f}s/171保护4授权54协议/8注册/两声明/实际DDS PASS，原夹具失败及初native AST脚本误写dispatch_return_goal(实际send_return_goal)断言失败保留，不是任务。v28四原FAIL保留，native/300s/5s/TTL/所有case与physical刺激不变；新4/17/2须同clean pushed freeze，917未暴露。报告20261009_p2c_action_serial_components.md及20261009_p2c_v29_concurrency_correction.md。P3C.5已验收，无P4/ns-3/Wi-Fi/RL。'
for q in (w/'AGENTS.md',w/'RESEARCH_PLAN.md',w/'IMPLEMENTATION_PLAN.md',r/'user_guide.md',r/'launch_commands.md'):
 first,rest=q.read_text().split('\n',1);q.write_text(first+'\n\n'+note+'\n'+rest)
q=root/'AGENTS.md';q.write_text(q.read_text().replace('## Current Handoff\n','## Current Handoff\n\n'+note+'\n',1))
with (w/'log.md').open('a') as f:
 f.write('\n\n## 2026-10-09 P2C.1 v29任务前并发勘误及v30 Future串行化\n\n'+note+'\n\n')
 f.write('v29 git commit f0fe12c/push exit0，但等待push完成后的最终执行器read-only复查在/opt/ros/humble/local/lib/python3.10/dist-packages/rclpy/task.py确认Future._schedule_or_invoke_done_callbacks/add_done_callback直接executor.create_task；没有运行freeze check或任何task。之前实际DDS仅普通String与clock，不足证明动作Future不并发，候选任务前拒绝。/log/p2c/20261009_p2c_v29不存在，0重试/0回填，组件原报告标PARTIAL_PASS_REJECTED_CANDIDATE并保留f0原提交。\n\n')
 f.write(f'新8中央+2native future注册全部defer并共用action_callbacks.py，queue/guard只由各自原default group drain；/usr/bin/python3 scripts/check_p2c_clock_runtime.py --output log/p2c_v30_clock_action_runtime.json 首oldsingle/oldtwo/new2 PASS，再加入f0实际旧源为four variants --output log/p2c_v30_shared_clock_runtime.json domain216/FastDDS UDPv4 PASS。定向test_control.py/test_target_information_survey.py初322PASS/1FAIL20.87s late scan夹具缺shutdown字段，补真实queue+单线程即时drain后加test_serial_action_callbacks.py 329PASS21.34s。完整pytest三lintignore{int(m[1])}PASS{float(m[2]):.2f}s；四包colcon build{float(b[1]):.2f}s；check_p2c_source.py --output log/p2c_v30_source_final.json171/4/54/8 PASS；check_p2c_visual_runtime.py --output log/p2c_v30_visual_runtime_final.json domain215 DDS PASS。两run_p2c_tasks --validate-only dev_forced2/v30/domain210/20290与physical_fault/v30_physical/domain219/20299的exactcommands/config/SHA均归档，新all4/17/2仍未启动；917未暴露。\n')
print(json.dumps(dict(functional_checks=int(m[1]),build_sec=float(b[1]),component_artifacts=len(artifacts),v29_tasks=0)))
