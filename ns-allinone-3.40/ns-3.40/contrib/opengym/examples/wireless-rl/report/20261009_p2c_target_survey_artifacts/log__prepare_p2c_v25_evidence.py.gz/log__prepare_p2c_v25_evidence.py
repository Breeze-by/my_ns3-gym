import ast,gzip,hashlib,json,re,subprocess
from pathlib import Path
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
parent='8bd34917d37ec44c0920e56e98a861a42ccd66d0'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def old(p):return subprocess.check_output(['git','show',f'{parent}:{p.relative_to(root)}'],cwd=root)
def archive(paths,name):
    destination=report/name;destination.mkdir();rows=[]
    for p in sorted(set(paths)):
        out=destination/('__'.join(p.relative_to(r).parts)+'.gz');assert not out.exists()
        out.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0))
        assert gzip.decompress(out.read_bytes())==p.read_bytes()
        rows.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),
            archive=str(out.relative_to(report)),archive_sha256=sha(out)))
    return rows
base=r/'log/p2c/20261009_p2c_v24';paths=list(base.glob('*/summary.json'));assert len(paths)==1
original=load(paths[0]);assert original['git_commit']==parent and original['case']=='dev_forced2'
assert original['runner_returncode']==original['observer_returncode']==0
assert not any(v for k,v in original.items() if k.endswith('_forced_shutdown'))
result=original['result'];assert not result['success'] and result['task_phase']=='RALLY'
assert result['collision_events']==0 and not result['failed_robots']
assert all(v['battery_charge_count']==1 and v['battery_minimum_energy']>0 for v in result['robots'].values())
for name,h in original['evidence_sha256'].items():assert sha(paths[0].parent/name)==h
gate=load(r/'log/p2c_v24_dev_forced2_gate.json');assert gate['status']=='FAIL'
independent=load(r/'log/p2c_v24_independent_audits.json')
assert all(v['status']=='PASS' for k,v in independent['dev_forced2'].items() if k!='native_vs_gateway_frame_samples')
from check_p2c_gate import launch_process_audit
from p2c_native_graph import native_tf_ingress_audit
processes=launch_process_audit(paths[0].parent)
graph=native_tf_ingress_audit(load(paths[0].parent/'native_graph.json'),2,True)
frames=independent['dev_forced2']['native_vs_gateway_frame_samples']
tf_stats={name:dict(samples=len(rows),initial_missing=sum(v['native_age_sec'] is None for v in rows),
    stale=sum(v['native_age_sec'] is not None and v['native_age_sec']>2. for v in rows),
    maximum_valid_age_sec=max(v['native_age_sec'] for v in rows if v['native_age_sec'] is not None))
    for name,rows in frames.items()}
frontier=load(r/'log/p2c_v24_survey_admission_diagnostic.json')
dense=load(r/'log/p2c_v24_dense_survey_admission_diagnostic.json')
assert frontier['status']==dense['status']=='PASS'
assert frontier['original_survey_prefix']['requested_position']==frontier['proposed_survey_prefix']['requested_position']
files=[p for p in base.rglob('*') if p.is_file() and p.suffix!='.pyc']
files += [r/'log'/n for n in ('p2c_v24_freeze_check.json','check_p2c_v24_freeze.py','p2c_v24_dev_forced2_runner.log',
    'p2c_v24_dev_forced2_gate.json','p2c_v24_dev_forced2_gate.log','audit_p2c_v24_independent.py',
    'p2c_v24_independent_audits.json','p2c_v24_independent_audits.log',
    'p2c_v24_rally_contexts.json','p2c_v24_rally_contexts_original.json','p2c_v24_rally_maps.png',
    'probe_p2c_v24_survey.py','p2c_v24_survey_diagnostic.json','p2c_v24_survey_diagnostic.log',
    'compare_p2c_v24_survey_admission.py','p2c_v24_survey_admission_diagnostic.json','p2c_v24_survey_admission_diagnostic.log',
    'probe_p2c_v24_dense_survey.py','p2c_v24_dense_survey_diagnostic.json','p2c_v24_dense_survey_diagnostic.log',
    'compare_p2c_v24_dense_survey_admission.py','p2c_v24_dense_survey_admission_diagnostic.json','p2c_v24_dense_survey_admission_diagnostic.log')]
failure=dict(status='FAIL',scope='First forced development original only',task_stack_frozen_commit=parent,
    original=original,strict_gate=gate,independent_audits=independent,launch_process_audit=processes,
    native_tf_graph_audit=graph,native_tf_sample_summary=tf_stats,
    task_time_infrastructure_failures=0,task_retries=0,all_owned_closed_before_edits=True,
    frontier_only_conditional_trial=frontier,frontier_only_trial_adopted=False,
    dense_known_view_conditional_trial=dense,
    unrun=['other3 development','17 formal','both physical','917 first exposure'],
    artifacts=archive(files,'20261009_p2c_v24_artifacts'))
(report/'20261009_p2c_v24_failed_development.json').write_text(json.dumps(failure,indent=2)+'\n')
(report/'20261009_p2c_v24_failed_development.md').write_text('''# P2C.1 v24 首个强制原任务 FAIL

冻结 `8bd34917d37ec44c0920e56e98a861a42ccd66d0` 的dev_forced2：183.4秒确认检测、225.8秒进入RALLY、300.1秒原生超时，无完整5秒保持。两机最终误差约0.00556/0.00624米，但到位后的角速度波动破坏保持；末次合格位置或中央安静状态不能替代原生证明。两机各充电一次，最低16.592320，零接触/耗尽/机器人失效/任务期子进程崩溃；外层owner/observer自然0，任务后实际子进程清理退出另记。其余三开发、17正式、两物理及917没有调用，零任务重试/回填，原FAIL与完整输入保持。

七类独立检查PASS：4闭合返航触发/4pose租约/2charger return，120原生能量样本；这些返航发生在接触区附近，本格0本地返航腿，不能称真实远端返航证明。19探索/8已知空间补查/7接续/2相对折扣/19空间偏好重建，3失败集合与1成功集合分配，2AP返路否决、完整native graph、task-time进程审计PASS。两机各60TF样本，各1初始缺失，118有效样本零超2秒，最大0.202/0.121秒。

发现后约42.4秒勘察：近端探测者先走一条已知可见短腿，随后因没有更近的已知点而使用远端同伴的两条勘察腿。四份原交付地图中目标格前三份仍unknown，第四份才free；图像仅展示这些记录，未改SLAM/物理/检测。只读前沿信息排序的首条实际准入短腿与旧算法完全相同，因此不采用该前沿-only版本、不声称省时。密集安全自由格版本在第二个真实保存状态得到另一条近端0.517414米、完整预算17.676113的合格短腿、目标邻域预期unknown gain108；用原图/身体/位姿/模型/源龄与真实派发函数及synthetic action client核验。它不是原任务反事实轨迹，也不保证获得这些信息或完成更快。

首只读上下文抽取误以为coordinator事件被包装在data内而读到0项，空输出保留，按真实顶层schema另存四项；一次未source环境的只读导入ModuleNotFoundError没有启动任务，后续命令均source ROS。所有任务、读取、比较和失败原样归档。P3C.5已验收，无P4/ns-3/Wi-Fi/RL。
''')
checks=(r/'log/p2c_v25_final_full_components.log').read_text()
m=re.search(r'(\d+) passed in ([\d.]+)s',checks);assert m and 'FAILED' not in checks
b=re.search(r'4 packages finished \[([\d.]+)s\]',(r/'log/p2c_v25_final_build.log').read_text());assert b
source=load(r/'log/p2c_v25_final_source.json');assert source['status']=='PASS'
runtime=load(r/'log/p2c_v25_dense_visual_runtime.json');assert runtime['status']=='PASS'
assert runtime['target_survey_audit']['target_information_survey_witnesses']==1
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py'
assert runtime['control_sha256']==sha(control)==dense['control_sha256']
def methods(text):
    node=next(n for n in ast.parse(text).body if isinstance(n,ast.ClassDef) and n.name=='HeadquartersControl')
    return {n.name:ast.dump(n,include_attributes=False) for n in node.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
before=methods(old(control));after=methods(control.read_bytes())
changed=[name for name,value in before.items() if value!=after[name]]
assert set(changed)=={'update_mission','send_survey_goal','record_navigation_decision'},changed
assert set(after)-set(before)=={'survey_target_frontiers'}
old_functions={n.name:ast.dump(n) for n in ast.parse(old(control)).body if isinstance(n,ast.FunctionDef)}
new_functions={n.name:ast.dump(n) for n in ast.parse(control.read_bytes()).body if isinstance(n,ast.FunctionDef)}
assert all(value==new_functions[name] for name,value in old_functions.items())
unchanged={}
for rel in ('src/multi_robot_exploration/multi_robot_exploration/battery_manager.py',
    'src/multi_robot_exploration/multi_robot_exploration/tf_ingress_sampler.py',
    'src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py','scripts/observe_p3b5.py','scripts/p2c_native_graph.py'):
    p=r/rel;assert p.read_bytes()==old(p);unchanged[rel]=sha(p)
for n,cfg in (('p2c_v25_final_manifest.json','p2c_integration_manifest.json'),('p2c_v25_final_blackout_manifest.json','p2c_blackout_manifest.json')):
    assert load(r/'log'/n)['config']==load(r/'scripts'/cfg)
qa=[r/'log'/n for n in ('p2c_v25_directed.log','p2c_v25_full_components.log','p2c_v25_build.log',
    'p2c_v25_source.json','p2c_v25_source.log','p2c_v25_manifest.json','p2c_v25_blackout_manifest.json',
    'p2c_v25_visual_runtime.json','p2c_v25_visual_runtime.log','p2c_v25_dense_directed.log',
    'p2c_v25_final_directed.log','p2c_v25_final_full_components.log','p2c_v25_final_build.log',
    'p2c_v25_final_source.json','p2c_v25_final_source.log','p2c_v25_final_manifest.json','p2c_v25_final_blackout_manifest.json',
    'p2c_v25_dense_visual_runtime.json','p2c_v25_dense_visual_runtime.log','prepare_p2c_v25_evidence.py')]
components=dict(status='PASS',scope='Prospective target-area active mapping components, not task completion',parent_commit=parent,
    functional_checks=int(m[1]),component_wall_sec=float(m[2]),build_wall_sec=float(b[1]),control_sha256=sha(control),source_audit=source,
    changed_central_methods=changed,new_central_method='survey_target_frontiers',preserved_central_methods=len(before)-len(changed),
    all_existing_pure_functions_ast_preserved=True,unchanged_from_parent=unchanged,actual_ros_dds=runtime,
    algorithm='In FOUND only, coarse .25m lattice of currently known-free .45m-clear endpoints within delivered target range minus original position tolerance; body-masked whole known approaches, target-neighborhood predicted unknown ray gain/(1+distance), top2 per robot, original actual visible-prefix/full-return/lease guards and legacy fallback.',
    limitations='Optimistic unknown information is not observed target/SLAM gain. Coarse sampling and bounded candidate count are not complete or optimal. Synthetic action-client DDS proof is not actual Nav2/task evidence.',
    hard_constraints='Native300s/5s/TTLs/current obstacles/reservations/full qualified return/energy/charge safety/Nav2/physics and physical stimulus unchanged.',
    unrun=['new all4 development','new17 formal','new2 physical','917 first exposure'],
    artifacts=archive(qa,'20261009_p2c_target_survey_artifacts'))
(report/'20261009_p2c_target_survey_components.json').write_text(json.dumps(components,indent=2)+'\n')
(report/'20261009_p2c_target_survey_components.md').write_text(f'''# P2C.1 v25 目标邻域主动勘察组件 PASS

v24首原forced在183.4秒发现但300.1秒无原生完整保持，FAIL保持。只读前沿信息排序在首状态仍被原可见性保护裁成与旧算法同一短腿，未采用；第二状态的密集已知安全格版本获得近端0.517414米、完整去返预算17.676113、预期unknown gain108的实际准入候选，仍是条件组件，不是原任务反事实收益。

新候选仅在FOUND且原完整集合位不能分配时执行：在交付目标距离范围扣原位置余量内，以0.25米栅格步长抽样当前已知自由、0.45米终点净空的视点；每机使用原实际起点/有界已知逃离/身体屏蔽的完整距离场。按目标邻域预期unknown射线信息/(1+行程)排序，每机最多两个候选，再逐项走原可见短腿/预约/当前和终点完整合格返航/源TTL/活动handle检查；目标朝向只基于已有有效交付确认。无合格项保留原靠近目标与连接勘察回退。未知格不开放为路线，不读取真值或未来，不改本地battery或原任务完成。

所有实际新勘察私有记录保存地图/源图/原始leases/身体/模型/目标/评分/实际prefix/预约/完整预算；独立reader重建排名、身体安全prefix和已知完整返航费用，拒绝伪造gain/path/cost/endpoint/source/半径/位置门限。新全范围门禁还要求有实际新算法记录，不能靠从未执行的组件代码称集成验证。

最终{int(m[1])}功能PASS{float(m[2]):.2f}秒、29新定向PASS6.10秒，旧与密集定向各73 PASS，四包{float(b[1]):.2f}秒，171保护/4已授权/54协议、两预声明及实际DDS合成输入的新selector/planner/record+独立reader PASS。DDS动作客户端是synthetic，不宣称Nav2/物理成功。前沿-only全1136/旧DDS等原输出保留，最终以新源码证据为准。新增一个中央方法，变更3方法，其他{len(before)-len(changed)}中央方法及全部原纯几何/集合函数AST保持；native battery/sampler/launch/native图工具字节保持，原AP50快照/TF重投影证据按同constructor/callback AST保留。

新4开发/17正式/两物理须clean pushed freeze后开始；917未暴露。粗采样/预期信息/有界候选不是最优或最坏时间保证；本轮尚未取得新任务收益。P3C.5已验收，无P4/ns-3/Wi-Fi/RL。
''')
note=f'2026-10-09 P2C.1 v25目标邻域勘察组件PASS、待新冻结任务：v24首forced检测183.4/RALLY225.8/timeout300.1，位置已近但无完整native保持；两机各charge1/min16.592320/零接触耗尽机器人失效任务期infra，原FAIL保持。19探索8补查19空间偏好/120能量/4闭合近充电区return与图审计PASS，不能称远返证明；118有效TF零过期。前沿-only首prefix与旧相同，未采用；最终以已知自由0.45m端点/0.25m采样/原body完整路径/目标邻域预期unknown信息每距离择点，近端条件0.517414m/预算17.676113，不是任务反事实。{int(m[1])}功能/29新定向/四包{float(b[1]):.2f}s/171保护4授权54协议/actual DDS两声明PASS，原native battery/sampler/launch/所有既有纯几何集合/300s/5s/TTL/硬派发保护保持。新4开发/17正式/两物理须clean pushed freeze，917未暴露，P3C.5已验收，无P4/ns-3/Wi-Fi/RL。报告20261009_p2c_target_survey_components.md及20261009_p2c_v24_failed_development.md。'
for p in (w/'AGENTS.md',w/'RESEARCH_PLAN.md',w/'IMPLEMENTATION_PLAN.md',r/'user_guide.md',r/'launch_commands.md'):
    first,rest=p.read_text().split('\n',1);p.write_text(first+'\n\n'+note+'\n'+rest)
p=root/'AGENTS.md';p.write_text(p.read_text().replace('## Current Handoff\n','## Current Handoff\n\n'+note+'\n',1))
with (w/'log.md').open('a') as f:
    f.write('\n\n## 2026-10-09 P2C.1 v24原失败与v25目标邻域信息勘察\n\n'+note+'\n\n')
    f.write('环境系统Python3/source Humble+install/PYTHONNOUSERSITE=1/FastRTPS-UDPv4/taskset -c0-79。8bd3491推送后独立check_p2c_v24_freeze.py PASS，run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v24 --domain 210 --gazebo-port 20290；原RALLYtimeout300.1/owner及observer0/无任务retry，全部owned自然关闭后才编辑。check_p2c_gate --run-root log/p2c/20261009_p2c_v24 --development --cases dev_forced2 --output log/p2c_v24_dev_forced2_gate.json strict FAIL；audit_p2c_v24_independent.py七类PASS。完整原summary/config/commands/source/environment/evidenceSHA和失败trace归档，不将near-position/中央状态当5秒native完成。\n\n')
    f.write('只读probe_p2c_v24_survey.py/compare_p2c_v24_survey_admission.py比较前沿信息版本，首实际prefix相同，未采用；probe_p2c_v24_dense_survey.py/compare_p2c_v24_dense_survey_admission.py第二原AP状态0.517414m/17.676113/108预期unknown条件准入PASS，synthetic action client且无counterfactual任务时间。地图PNG实际查看；首误以data包装抽取0项空文件保留并另存正确4项，一未source导入ModuleNotFoundError只读失败，未启动任务。\n\n')
    f.write('v25前沿-only首73定向/1136全/8.33s构建/DDS/domain215原输出保持；最终密集版本73定向5.91s、补局部无法直线靠近和位置门限篡改后29定向6.10s，完整pytest功能范围三lint ignore、四包colcon build、check_p2c_source、普通/physical validate-only和check_p2c_visual_runtime --output log/p2c_v25_dense_visual_runtime.json actual DDS+synthetic action client PASS。所有精确argv/源码SHA/输出见机读组件归档；新all4/17/2原任务与917尚未调用，无P4/ns-3/Wi-Fi/RL。\n')
print(json.dumps(dict(failure_artifacts=len(failure['artifacts']),component_artifacts=len(components['artifacts']),checks=int(m[1]),build_sec=float(b[1]),preserved_methods=components['preserved_central_methods'])))
