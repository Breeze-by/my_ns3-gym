import json,traceback
from pathlib import Path
from check_p2c_gate import (return_audit,energy_audit,lookahead_audit,ap_return_veto_audit,
 rally_assignment_audit,rally_repair_audit,exploration_travel_audit)
base=Path('log/p2c/20261009_p2c_v19');outputs={}
for p in sorted(base.glob('*/summary.json')):
 row=json.loads(p.read_text());d=p.parent;records=[json.loads(line) for line in (d/'ledger.jsonl').open()]
 calls={'native_return':lambda:return_audit(d/'safety_events.jsonl',True,True),
 'native_energy':lambda:energy_audit(d/'safety_events.jsonl',row['result'],True),
 'lookahead':lambda:lookahead_audit(records,True),'ap_return_veto':lambda:ap_return_veto_audit(records),
 'rally_assignment':lambda:rally_assignment_audit(records),'rally_repair':lambda:rally_repair_audit(records),
 'exploration_travel':lambda:exploration_travel_audit(records,True,True)}
 out={}
 for name,call in calls.items():
  try:out[name]=call()
  except Exception as error:out[name]=dict(status='FAIL',error=repr(error),traceback=traceback.format_exc())
 frames=[]
 for e in records:
  if e.get('event')=='generated' and e.get('message_type')=='frame_state':frames.append(e)
 stats={}
 for line in (d/'safety_events.jsonl').open():
  data=json.loads(line).get('data')
  if isinstance(data,str):
   try:data=json.loads(data)
   except json.JSONDecodeError:continue
  if not isinstance(data,dict) or data.get('event')!='energy_accounting':continue
  robot=data['robot'];now=data['sim_time'];source=data.get('frame_source_time')
  native_age=None if source is None else now-source
  ap=next((e for e in reversed(frames) if e['sender']==robot and e['event_time']<=now),None)
  stats.setdefault(robot,[]).append(dict(sim_time=now,native_age_sec=native_age,
      gateway_age_sec=None if ap is None else now-ap['source_time'],native_relevant_receipts=data.get('relevant_frame_receipts'),mode=data['mode']))
 out['native_vs_gateway_frame_samples']=stats;outputs[row['case']]=out
Path('log/p2c_v19_independent_audits.json').write_text(json.dumps(outputs,indent=2)+'\n')
print(json.dumps({c:{n:{k:v for k,v in e.items() if k not in ('returns','robots','computation_wall_sec')} for n,e in out.items() if n!='native_vs_gateway_frame_samples'} for c,out in outputs.items()}))
