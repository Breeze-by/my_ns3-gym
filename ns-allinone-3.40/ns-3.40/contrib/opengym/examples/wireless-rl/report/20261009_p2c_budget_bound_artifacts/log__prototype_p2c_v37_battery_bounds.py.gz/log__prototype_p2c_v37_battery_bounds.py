import json, sys, types
from pathlib import Path
from multi_robot_exploration import control
import test_exploration_resume as fixtures

source=Path(control.__file__).read_text()
needle='''        search_gain_cache = {}  # One immutable map/visit mask per admission batch.
'''
replacement='''        battery_bounds = {}
        for name in idle_positions:
            required = (HeadquartersControl.exploration_required_energy(self, name, 0.,
                self.robot_positions[name], planning_started) if self.enable_battery else None)
            energy = float(self.battery_states[name].get('energy', 0.)) if self.enable_battery else 0.
            battery_bounds[name] = (.25 * energy / required
                if required is not None and required > 0 and 0 <= energy <= required else 1.)
        search_gain_cache = {}  # One immutable map/visit mask per admission batch.
'''
assert source.count(needle)==1;source=source.replace(needle,replacement)
needle='''                if scoring_aborted or robot_name in plans:
                    return None
'''
replacement='''                if (scoring_aborted or robot_name in plans
                        or robot_name in charge_candidates and battery_bounds[robot_name] < 1.):
                    return None
'''
assert source.count(needle)==2;source=source.replace(needle,replacement)
needle='''                if battery_factor <= 0:
                    return None
'''
replacement='''                if not lease_current('candidate_budget'):
                    scoring_aborted = True
                    return None
                if battery_factor <= 0:
                    return None
'''
start=source.index('    def assign_idle_robots(self):');assert source[start:].count(needle)==1
source=source[:start]+source[start:].replace(needle,replacement)
needle='''                lambda item: frontier_scheduling_score(item[3].utility,
                    not search and interrupted_frontier_is_useful(
                        item[3], resume_intents.get(item[1]), 1.0)),
'''
replacement='''                lambda item: frontier_scheduling_score(item[3].utility * battery_bounds[item[1]],
                    battery_bounds[item[1]] == 1. and not search and interrupted_frontier_is_useful(
                        item[3], resume_intents.get(item[1]), 1.0)),
'''
assert source.count(needle)==1;source=source.replace(needle,replacement)
module=types.ModuleType('multi_robot_exploration.p2c_v37_battery_bound_prototype')
module.__package__='multi_robot_exploration';sys.modules[module.__name__]=module
exec(compile(source,'<current hold reserve bound>', 'exec'),module.__dict__)
fixtures.control=module
script=Path('log/profile_p2c_v37_forced_inputs.py').read_text().replace('from multi_robot_exploration import control','')
script=script.replace('p2c_v37_forced_profile_', 'p2c_v37_battery_bound_')
exec(compile(script,'<conditional saved three charging inputs>', 'exec'),{'control':module})
old=json.loads(Path('log/p2c_v37_forced_profile_expired_profiles.json').read_text())
new=json.loads(Path('log/p2c_v37_battery_bound_expired_profiles.json').read_text())
for case in old:
    assert old[case]['result']['sent']==new[case]['result']['sent'],case
    assert old[case]['result']['choices']==new[case]['result']['choices'],case
    assert old[case]['result']['requests']==new[case]['result']['requests'],case
print('Exact original tasks/charge intents/headings/preferences/full required budgets match')
