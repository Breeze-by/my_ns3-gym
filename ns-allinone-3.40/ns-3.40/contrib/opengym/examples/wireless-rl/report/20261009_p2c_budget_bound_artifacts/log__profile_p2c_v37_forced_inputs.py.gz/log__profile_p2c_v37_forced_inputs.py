import cProfile, dataclasses, hashlib, json, pstats, time
from pathlib import Path
import test_exploration_resume as fixtures
from multi_robot_exploration import control

output = {}
for case in ('candidate_generation', 'candidate_budget', 'route_admission'):
    path = Path(f'log/p2c_v36_dev_forced2_{case}_last_explore_snapshot.json')
    expired = json.loads(path.read_text())
    d = expired['diagnostic_inputs']
    e = {**d, 'inputs': expired['inputs_at_start'],
         'event_time': expired['planning_started_at_sec']}
    def run():
        node, sent = fixtures.conditional_snapshot_node(e, d['exploration_resume_intents'].copy())
        node.robot_states = d['robot_states'].copy()
        from types import SimpleNamespace
        requests=[]
        node.exploration_charge_budgets={}
        node.charge_request_publishers={n:SimpleNamespace(publish=lambda msg: requests.append(json.loads(msg.data))) for n in d['battery_states']}
        node.battery_modes = d['battery_modes'].copy()
        node.active_exclusions = lambda: d['exclusions']
        node.enable_rally = d['enable_rally']
        node.initial_search_next = d['initial_search_next'].copy()
        node.initial_search_visits = dict(enumerate(d['initial_search_visits']))
        node.initial_search_views = dict(enumerate(d['initial_search_views']))
        node.target_search_visits = d['target_search_visits'].copy()
        node.successful_exploration_legs = d['successful_exploration_legs'].copy()
        node.rally_charge_requested = d['rally_charge_requested'].copy()
        node.goal_routes = d['goal_routes'].copy()
        node.goal_targets = {n: None if a is None else control.Assignment(
            **{**a, 'viewpoint': control.Viewpoint(**a['viewpoint'])})
            for n, a in d['goal_targets'].items()}
        counters = {}
        functions = ('visible_unknown_gain', 'known_search_view', 'known_return_route',
                     'qualified_return_route', 'dijkstra_distance_field',
                     'robot_candidate_assignments', 'known_space_search_candidates',
                     'plan_rally_leg', 'local_route_return_veto', 'resolve_search_gain')
        originals = {name: getattr(control, name) for name in functions if hasattr(control, name)}
        def wrapper(name, original):
            def call(*args, **kwargs):
                counters[name] = counters.get(name, 0) + 1
                return original(*args, **kwargs)
            return call
        for name, original in originals.items():
            setattr(control, name, wrapper(name, original))
        try:
            control.HeadquartersControl.assign_idle_robots(node)
        finally:
            for name, original in originals.items():
                setattr(control, name, original)
        return dict(sent=json.loads(json.dumps(sent, default=dataclasses.asdict)),
                    requests=requests, counts=counters, choices=node.exploration_travel_choices,
                    budget_times=getattr(node, 'exploration_budget_times', {}))
    samples = []
    for _ in range(3):
        control.visibility_ray_projections.cache_clear()
        control.known_search_sector_table.cache_clear()
        start = time.perf_counter(); result = run(); samples.append(time.perf_counter()-start)
    profile = cProfile.Profile(); profile.runcall(run)
    with Path(f'log/p2c_v37_forced_profile_{case}_expired_profile.txt').open('w') as f:
        pstats.Stats(profile, stream=f).strip_dirs().sort_stats('cumulative').print_stats(45)
    output[case] = dict(scope='Saved abandoned callback inputs; fixed source epoch and conditional transport only, not original trajectory or clock replay',
        snapshot_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        original_stage=expired['stage'], original_slack_sec=expired['source_deadline_sec']-expired['planning_started_at_sec'],
        cold_wall_sec=samples, result=result)
    print(case, samples, result['counts'], [(n, a['x'], a['y']) for n, a in result['sent']], flush=True)
Path('log/p2c_v37_forced_profile_expired_profiles.json').write_text(json.dumps(output, indent=2)+'\n')
