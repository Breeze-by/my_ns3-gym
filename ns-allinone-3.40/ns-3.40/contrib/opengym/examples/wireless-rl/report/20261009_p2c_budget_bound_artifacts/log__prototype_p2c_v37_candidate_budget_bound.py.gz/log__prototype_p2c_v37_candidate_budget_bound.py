import json, sys, types
from pathlib import Path
from multi_robot_exploration import control
import test_exploration_resume as fixtures

helper='''
def exploration_battery_factor_bound(state, position, distance, destination, map_age, pose_age):
    """Computational upper bound only; never a feasible return or command."""
    try:
        energy=float(state['energy']);home=(float(state['charge_x']),float(state['charge_y']))
        radius=float(state.get('charge_radius_m',.8));move=float(state.get('move_cost_per_m',1.))
        idle=float(state.get('idle_cost_per_sec',.02));factor=float(state.get('return_path_factor',2.))
        speed=float(state.get('nominal_speed_mps',.18));margin=float(state.get('return_safety_margin',8.))
        wait=float(state.get('return_recovery_wait_sec',RETURN_RECOVERY_WAIT_SEC))
        values=(energy,*home,*position,distance,*destination,radius,move,idle,factor,speed,margin,wait,map_age,pose_age)
        if (not all(math.isfinite(v) for v in values) or min(energy,distance,move,idle,margin,wait,map_age,pose_age)<0
                or radius<=.2 or speed<=0 or factor<1 or map_age>5. or pose_age>2.):
            return 1.
        def price(approach, point):
            contact_lower_bound=max(0.,math.dist(point,home)-radius)
            return battery_assignment_required_energy(approach,contact_lower_bound,move,idle,factor,speed,
                margin,wait,map_age,pose_age)
        required=max(price(distance,destination),price(0.,position))
        return .25*energy/required if required>0 and energy<=required else 1.
    except (KeyError, TypeError, ValueError, ZeroDivisionError):
        return 1.
'''
source=Path(control.__file__).read_text()+helper
needle='''            def refine_candidate_gain(raw):
'''
replacement='''            factor_bounds = {}
            for _, name, _, a in raw_candidates:
                bound = 1.
                if self.enable_battery:
                    try:
                        map_age = max(planning_started-self.map_received_at,
                            planning_started-self.robot_map_received_at[name])
                        pose_age = HeadquartersControl.delivered_pose_age(self,name,planning_started)
                        bound = exploration_battery_factor_bound(self.battery_states[name],
                            self.robot_positions[name],a.path_distance_m,(a.x,a.y),map_age,pose_age)
                    except (KeyError, TypeError, ValueError):
                        pass
                factor_bounds[name,a.x,a.y,a.path_distance_m]=bound
            unfunded_only = {name for name in idle_positions if any(r[1]==name for r in raw_candidates)
                and all(factor_bounds[name,r[3].x,r[3].y,r[3].path_distance_m]<1.
                        for r in raw_candidates if r[1]==name)}
            resolved_charges = set()

            def refine_candidate_gain(raw):
'''
assert source.count(needle)==1;source=source.replace(needle,replacement)
needle='''                if scoring_aborted or robot_name in plans:
                    return None
'''
replacement='''                if scoring_aborted or robot_name in plans or robot_name in resolved_charges:
                    return None
'''
assert source.count(needle)==2;source=source.replace(needle,replacement)
needle='''                if battery_factor <= 0:
                    return None
'''
replacement='''                if not lease_current('candidate_budget'):
                    scoring_aborted = True
                    return None
                if battery_factor <= 0:
                    return None
'''
start=source.index('    def assign_idle_robots(self):');assert source[start:].count(needle)==1
source=source[:start]+source[start:].replace(needle,replacement)
needle='''                lambda item: frontier_scheduling_score(item[3].utility,
                    not search and interrupted_frontier_is_useful(
                        item[3], resume_intents.get(item[1]), 1.0)),
'''
replacement='''                lambda item: frontier_scheduling_score(item[3].utility * factor_bounds[
                    item[1],item[3].x,item[3].y,item[3].path_distance_m],
                    item[1] not in unfunded_only and not search and interrupted_frontier_is_useful(
                        item[3], resume_intents.get(item[1]), 1.0)),
'''
assert source.count(needle)==1;source=source.replace(needle,replacement)
needle='''                    continue  # One best feasible charge intent per idle peer.
'''
replacement='''                    if name in unfunded_only:resolved_charges.add(name)
                    continue  # One best feasible charge intent per idle peer.
'''
assert source.count(needle)==1;source=source.replace(needle,replacement)
needle='''                        charge_candidates[name] = assignment
                    continue
'''
replacement='''                        charge_candidates[name] = assignment
                        if name in unfunded_only:resolved_charges.add(name)
                    continue
'''
assert source.count(needle)==1;source=source.replace(needle,replacement)
module=types.ModuleType('multi_robot_exploration.p2c_v37_candidate_budget_bound_prototype')
module.__package__='multi_robot_exploration';sys.modules[module.__name__]=module
exec(compile(source,'<candidate geometric budget upper bound>', 'exec'),module.__dict__)
fixtures.control=module
script=Path('log/profile_p2c_v37_forced_inputs.py').read_text().replace('from multi_robot_exploration import control','')
script=script.replace('p2c_v37_forced_profile_', 'p2c_v37_candidate_budget_bound_')
exec(compile(script,'<conditional frozen charging cases>', 'exec'),{'control':module})
old=json.loads(Path('log/p2c_v37_forced_profile_expired_profiles.json').read_text())
new=json.loads(Path('log/p2c_v37_candidate_budget_bound_expired_profiles.json').read_text())
for case in old:
    assert old[case]['result']['sent']==new[case]['result']['sent'],case
    assert old[case]['result']['choices']==new[case]['result']['choices'],case
    assert old[case]['result']['requests']==new[case]['result']['requests'],case
print('Exact original tasks/charge intents/headings/preferences/full required budgets match')
