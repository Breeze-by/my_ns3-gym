import hashlib,json,math,time
from pathlib import Path
import rclpy
from rclpy.node import Node
from rclpy.executors import SingleThreadedExecutor
from std_msgs.msg import String
from geometry_msgs.msg import PoseStamped
from multi_robot_exploration import control
from test_lazy_search_gain import late_visual_node
from check_p2c_gate import exploration_travel_audit,planning_lease_audit

rclpy.init(args=['--ros-args','-p','robot_count:=2','-p','use_sim_time:=true',
    '-p','enable_battery:=true','-p','enable_rally:=true','-p','auto_save_map:=false'])
coordinator=receiver=None;executor=SingleThreadedExecutor();received=[];selected=[]
try:
    coordinator=control.HeadquartersControl();receiver=Node('p2c_lazy_visual_witness_receiver')
    for timer in coordinator.timers:timer.cancel()
    executor.add_node(coordinator);executor.add_node(receiver)
    receiver.create_subscription(String,coordinator.consumed_publisher.topic_name,
        lambda message:received.append(json.loads(message.data)),10)
    deadline=time.monotonic()+10.
    while coordinator.consumed_publisher.get_subscription_count()!=1 and time.monotonic()<deadline:
        executor.spin_once(timeout_sec=.02)
    assert coordinator.consumed_publisher.get_subscription_count()==1
    fixture,_=late_visual_node()
    for key,value in vars(fixture).items():
        if key not in ('consumed_publisher','get_logger','send_goal'):
            setattr(coordinator,key,value)
    def goal_sink(name,assignment):
        assert type(assignment) is control.Assignment
        assert type(assignment.viewpoint) is control.Viewpoint
        selected.append((name,assignment))
        pose=PoseStamped();pose.pose.position.x=assignment.navigation_x;pose.pose.position.y=assignment.navigation_y
        yaw=assignment.navigation_yaw or 0.
        pose.pose.orientation.z=math.sin(yaw/2.);pose.pose.orientation.w=math.cos(yaw/2.)
        coordinator.record_navigation_decision(name,'initial_visual_search' if coordinator.initial_search_goals.get(name,False) else 'exploration',pose)
    coordinator.send_goal=goal_sink
    control.HeadquartersControl.assign_idle_robots(coordinator)
    assert selected
    deadline=time.monotonic()+10.
    while len(received)<len(selected) and time.monotonic()<deadline:executor.spin_once(timeout_sec=.02)
    assert len(received)==len(selected)
    Path('log/p2c_v37_lazy_visual_received.json').write_text(json.dumps(received,indent=2)+'\n')
    audit=exploration_travel_audit(received,True,True,True,True,True,True,True)
    leases=planning_lease_audit(received)
    for e in received:
        w=e['travel_preference'];cell=control.world_to_grid(*w['target'],coordinator.resolution,*coordinator.origin)
        interest=control.camera_search_interest(coordinator.map_data,coordinator.resolution,
            coordinator.origin,list(coordinator.initial_search_views.values()))
        gain,yaw=control.known_search_view(coordinator.map_data,cell,
            control.INFORMATION_RADIUS_M/coordinator.resolution,interest)
        assert w['information_gain']==gain and math.isclose(e['requested_yaw'],yaw,abs_tol=1e-8)
    source=Path('src/multi_robot_exploration/multi_robot_exploration/control.py')
    output=dict(status='PASS',scope='Actual ROS node central admission and isolated DDS producer/consumer; fixed retained input maps and synthetic goal sink, no Nav2/Gazebo motion or clock-bound claim',
        control_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),actual_normal_assignments=len(selected),
        independent_received_witness_audit=audit,leases=leases,received_events=received)
    Path('log/p2c_v37_lazy_visual_dds.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({k:v for k,v in output.items() if k!='received_events'}))
finally:
    executor.shutdown()
    for node in (coordinator,receiver):
        if node is not None:node.destroy_node()
    rclpy.shutdown()
