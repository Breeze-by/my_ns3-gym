import gzip, hashlib, json, re, subprocess
from pathlib import Path
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
parent='7a7fde63f0be9e75ce6e3f59899c956c709dd0b2'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py'
comparison=load(r/'log/p2c_v37_final_comparisons.json')
assert comparison['status']=='PASS' and comparison['control_sha256']==sha(control)
source=load(r/'log/p2c_v37_source_final.json');assert source['status']=='PASS'
full=re.search(r'(\d+) passed in ([\d.]+)s',(r/'log/p2c_v37_full_tests_final.log').read_text())
assert full and int(full[1])==1408
build=re.search(r'4 packages finished \[([\d.]+)s\]',(r/'log/p2c_v37_build_final.log').read_text());assert build
runtime={k:load(r/'log'/n) for k,n in [
 ('clock','p2c_v37_clock_runtime.json'),('native_future','p2c_v37_native_future_runtime.json'),
 ('visual','p2c_v37_visual_runtime.json'),('mapping_dds','p2c_v37_lazy_gain_dds.json'),
 ('visual_gain_dds','p2c_v37_lazy_visual_dds.json'),('rally_dds','p2c_v37_rally_dds.json'),
 ('expired_inputs_dds','p2c_v37_expired_dds.json'),('charge_dds','p2c_v37_charge_dds.json')]}
assert all(v['status']=='PASS' for v in runtime.values())
for k,v in runtime.items():
 if k!='native_future':assert v['control_sha256']==sha(control),(k,'source binding')
reaudit=load(r/'log/p2c_v37_previous_original_audits.json')
assert reaudit==load(r/'log/p2c_v36_independent_audits.json')
assert all(len(rows)==12 and all(v['status']=='PASS' for v in rows.values()) for rows in reaudit.values())
for saved,name in [('p2c_v37_manifest.json','p2c_integration_manifest.json'),('p2c_v37_blackout_manifest.json','p2c_blackout_manifest.json')]:
 current=load(r/'scripts'/name);assert load(r/'log'/saved)['config']==current
 old=json.loads(subprocess.check_output(['git','show',parent+':'+str((r/'scripts'/name).relative_to(root))],cwd=root))
 for key in ('cases','duration_sec','coverage_threshold','fault_seed','owner_shutdown_timeout_sec'):assert old[key]==current[key],key
unchanged={}
for rel in ('src/multi_robot_exploration/multi_robot_exploration/battery_manager.py','src/multi_robot_exploration/multi_robot_exploration/action_callbacks.py','src/multi_robot_exploration/multi_robot_exploration/tf_ingress_sampler.py','src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py','scripts/observer_lifetime.py','scripts/observe_p3b5.py','scripts/p2c_native_graph.py','scripts/check_p2c_gate.py','scripts/ros_smoke_test.py','scripts/check_p2c_visual_runtime.py'):
 p=r/rel;assert subprocess.check_output(['git','show',parent+':'+str(p.relative_to(root))],cwd=root)==p.read_bytes();unchanged[rel]=sha(p)
files=[p for p in (r/'log').glob('*p2c_v37*') if p.is_file() and p.suffix!='.pyc']
files += [r/'src/multi_robot_exploration/test/fixtures/p2c_v36_charge_pricing_reference.json']
destination=report/'20261009_p2c_budget_bound_artifacts';assert not destination.exists();destination.mkdir();artifacts=[]
for p in sorted(set(files)):
 q=destination/('__'.join(p.relative_to(r).parts)+'.gz');q.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0))
 assert gzip.decompress(q.read_bytes())==p.read_bytes()
 artifacts.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(q.relative_to(report)),archive_sha256=sha(q)))
errors=[
 'Initial profile fixture omitted exploration_charge_budgets; failed before any task; original transport attributes then supplied.',
 'Position-only hold-budget prototype retained exact selection but left all upper bounds neutral and gave no reduction; rejected.',
 'Initial new test used duplicate energy keyword in dict; targeted95PASS/1FAIL. Test construction corrected, production unchanged; new32PASS.',
 'First full1390PASS/18FAIL113.17s: new direct enable_battery attribute lookup broke existing minimal controller fixtures. Production now uses established optional-switch semantics via getattr False, original tests unchanged.',
 'Initial source-bound DDS/comparison outputs retained under initial names; all eight ROS checks, paired comparisons, full suite, build and source audit repeated for final source.'
]
out=dict(status='PASS',scope='Prospective P2C.1 budget-factor ranking bound components; no mission acceptance',
 parent_commit=parent,control_sha256=sha(control),functional_checks=int(full[1]),functional_wall_sec=float(full[2]),
 build_wall_sec=float(build[1]),source_audit=source,actual_ros=runtime,fixed_source_comparison=comparison,
 previous_original_reaudit=reaudit,unchanged_from_parent=unchanged,preparation_errors=errors,
 unrun=['new4 development','new17 formal','new2 physical','917'],
 limits='Fixed exact saved abandoned inputs and epochs; paired CPU and isolated DDS are not original full-history/live-clock replay, worst-case latency, causal mission gain or Wi-Fi evidence.',artifacts=artifacts)
(report/'20261009_p2c_budget_bound_components.json').write_text(json.dumps(out,indent=2)+'\n')
text="""# P2C.1 v37 预算评分上界组件 PASS

v36冻结7a7fde6首forced原任务FAIL：249.9s检测、251.7s进入RALLY、300.4s超时；两机各充电一次、最低能量6.940767563292112、零接触/耗尽/failed/任务期infra/retry，12独立审计PASS不能替代任务成功。owner/observer关闭后修改；两个post-task Nav2 lifecycle manager被SIGKILL/-9，不能称所有子进程优雅关闭。原始失败和严格检查保留在20261009_p2c_v36_failed_development.md/.json。其他三dev、17formal、2physical、917从未调用。

三份准确弃置EXPLORE输入中有87视场历史，两机器人idle，约73/8单位电量。固定原epoch完整计算会请求tb2充电、所需预算约15.29/15.35，但原条件计算约2.4秒超过1.31–1.51秒剩余来源租约。只按当前位置hold预算的首原型没有改善，已保留并拒绝。最终采用当前模型和原source ages下的接触圆盘直线距离，分别作为完整任务+返航以及当前返航储备的能量下界，从而给准确battery factor一个更紧的上界。该直线下界只决定计算顺序，不证明路线可用、不替代已知地图完整接触区路线或真实能量准入。

每个原refinement pass只有全部raw options都被证明unfunded时，准确找到最高可行充电意图后，才可停止该机器人更低优先级选项的预算计算；任何可能funded的替代、下一refinement以及完整raw充电lookahead池仍保留。昂贵价格结束后立即再检查原租约，过期则撤销全部暂定计划。原公平串行充电、body/accepted reservation/完整距离/源TTL/派发保持。

32项新增检查独立使用冻结7a原assign源码/SHA；三份原输入的预算、充电对象、原stamp、临时搜索选择逐项一致；三种改变电量的条件反例覆盖funded替代不丢失。12种种子各80组模型/曲线/更晚source ages证明计算factor上界；无效或缺失模型/过期年龄给中性上界1；未知地图仍不能准入；计算中来源过期即使返回高价也不进入heap或请求。第一次full18失败源于直接读取电池开关破坏原精简fixtures，修正生产入口getattr后原测试保持，不放宽门限。

| 保存输入 | v36中位wall秒 | v37中位wall秒 | 原来源剩余秒 |
|---|---|---|---|
"""
for name,row in comparison['comparisons'].items():
 text+=f"| {name} | {row['timing']['frozen_v36']['median_wall_sec']:.5f} | {row['timing']['candidate_v37']['median_wall_sec']:.5f} | {row['original_lease_slack_sec']:.5f} |\n"
text+=f"""
五次交错cold、新缓存/固定原epoch，各完整选择相同。三份充电样本明显减算，三个早期样本略有开销或近似相同，完整数据保留；不是完整history/现场clock回放，也不保证最坏延迟或任务因果收益。

最终{int(full[1])}功能PASS/{float(full[2]):.2f}s、四包build{float(build[1]):.2f}s、171保护/4既授权/54static与8中央+2native Future注册PASS。八项实际ROS包括时钟/Future/视场、mapping/visual/rally、三份弃置输入和三次真实central charge publisher/独立DDS reader；均绑定最终SHA。真实请求与独立旧算法的充电对象、预算和原stamp相同，但隔离fixed epoch不含native battery/Nav2运动。旧v36十二原审计详细判断保持、strict仍FAIL。

AST只有assign_idle_robots改变、增加纯计算上界助手；native battery/dispatcher/TF/launch/observer/strict reader字节保持。所有原300s/.35/.05/.1/5s、2/5/60s TTL、SLAM/Nav2/physics/cases与真实断网刺激保持。新clean pushed freeze先forced原生且每机charge≥1，再另三dev；全四格通过才17formal+2physical，917最后首次暴露。P2C.1尚未完成；P3C.5已验收，无P4/ns-3/Wi-Fi/RL。
"""
(report/'20261009_p2c_budget_bound_components.md').write_text(text)
note=f'2026-10-09 P2C.1 v37预算计算上界组件PASS待新原任务：v36 7a7fde6首forced RALLYtimeout300.4/检测249.9/两机各charge1/min6.94077，0接触耗尽failed任务期infra/retry，12审计PASS不替代任务成功；两个post-task Nav2 lifecycle -9保留。三份实际弃置输入采用模型能量下界→评分上界，仅证明全部unfunded后保留最高准确充电意图，原完整已知返路与TTL/硬预算不变。{int(full[1])}功能/四包{float(build[1]):.2f}s/171保护54协议/八实际ROS PASS；六份准确保存输入选择/预算/原stamp同，充电计算cold中位约2.4–2.6→.90–.96秒；原型无益和首18测试失败保留修正，非任务因果/实时最坏界。新4→17+2同clean pushed freeze待验证，917未暴露；P3C.5已验收，无P4/ns3/Wi-Fi/RL。报告20261009_p2c_budget_bound_components.md与20261009_p2c_v36_failed_development.md；旧pending说明为历史。'
for p in (w/'AGENTS.md',w/'RESEARCH_PLAN.md',w/'IMPLEMENTATION_PLAN.md',r/'user_guide.md',r/'launch_commands.md'):
 lines=p.read_text().splitlines();assert lines[2].startswith('2026-10-09 P2C.1 v36');lines[2]=note;p.write_text('\n'.join(lines)+'\n')
p=root/'AGENTS.md';s=p.read_text();start=s.index('2026-10-09 P2C.1 v36');end=s.index('\n',start);p.write_text(s[:start]+note+s[end:])
with (w/'log.md').open('a') as f:
 f.write('\n\n## 2026-10-09 P2C.1 v37 预算计算上界组件\n\n'+note+'\n\n')
 f.write('Humble+install/PYTHONNOUSERSITE=1/FastDDS UDPv4清profiles，taskset -c 0-79；profile_p2c_v37_forced_inputs.py原准确ledger输入profile，position-only prototype_p2c_v37_battery_bounds.py未改善拒绝；prototype_p2c_v37_candidate_budget_bound.py预算上界/全部unfunded最高意图证明有效。初profile属性错误和新test dict重复energy错误保留；32新checksPASS21.13s。首full1390PASS18FAIL113.17s，由新增直接enable_battery读取破坏旧fixtures，改生产getattr保持原tests；最终 /usr/bin/python3 -m pytest -q src/multi_robot_exploration/test scripts --ignore=src/multi_robot_exploration/test/test_copyright.py --ignore=src/multi_robot_exploration/test/test_flake8.py --ignore=src/multi_robot_exploration/test/test_pep257.py '+str(int(full[1]))+'PASS/'+str(float(full[2]))+'s。\n\n')
 f.write('colcon build --symlink-install --packages-select multi_robot_interfaces multi_robot_exploration merge_map multi_robot '+str(float(build[1]))+'s；check_p2c_source.py --output log/p2c_v37_source_final.json PASS171/4/54。八实际ROS scripts/check_p2c_clock_runtime.py(domain220),native_future_runtime.py(221),visual_runtime.py(215)分别--output log/p2c_v37_{clock,native_future,visual}_runtime.json；log/check_p2c_v37_{lazy_gain_dds214,lazy_visual_dds216,rally_dds217,expired_dds218,charge_dds219}.py均exit0/source绑定。第一轮SHA检查保留_initial，最终SHA全部重跑。compare_p2c_v37_components.py六输入五交错cold全部选择相同、速度详见JSON；固定epoch组件非原history/实时保证。audit_p2c_v37_previous_originals.py旧v36一原12详情相同；run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v37 --domain 210 --gazebo-port 20290 --validate-only及--manifest scripts/p2c_blackout_manifest.json --case physical_fault --run-id 20261009_p2c_v37_physical --domain 219 --gazebo-port 20299 --validate-only PASS，无task开始。原期限/TTL/安全/原case和physical刺激保持，下一clean pushed freeze新4→17+2待验证，917未暴露，domain222/master11345未操作。\n')
print(json.dumps(dict(status='PASS',checks=int(full[1]),artifacts=len(artifacts),control_sha256=sha(control))))

