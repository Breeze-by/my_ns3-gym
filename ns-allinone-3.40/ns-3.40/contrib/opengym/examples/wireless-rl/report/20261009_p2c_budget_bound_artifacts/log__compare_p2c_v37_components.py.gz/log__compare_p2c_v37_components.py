import ast, hashlib, json, statistics, subprocess, time
from pathlib import Path
from multi_robot_exploration import control
from test_candidate_battery_bound import REFERENCE as charge_reference, conditional_charge, reference_assign
from test_exploration_route_bound import REFERENCE as travel_reference, conditional_assignment

old=reference_assign();output={}
cases=[('charging_'+name,event,conditional_charge) for name,event in charge_reference['snapshots'].items()]
cases += [(name,event,conditional_assignment) for name,event in travel_reference['snapshots'].items()]
for name,event,conditional in cases:
    samples={'frozen_v36':[],'candidate_v37':[]};expected=None
    for repeat in range(5):
        sequence=[('frozen_v36',old),('candidate_v37',control.HeadquartersControl.assign_idle_robots)]
        if repeat%2:sequence.reverse()
        for label,assign in sequence:
            control.visibility_ray_projections.cache_clear();control.known_search_sector_table.cache_clear()
            start=time.perf_counter();actual=conditional(event,assign);samples[label].append(time.perf_counter()-start)
            if expected is None:expected=actual
            assert actual==expected,(name,label,'original tasks/charges/headings/preferences/budgets differ')
    output[name]=dict(exact_conditional_selection_equal=True,
        input_sha256=hashlib.sha256(json.dumps(event,sort_keys=True).encode()).hexdigest(),
        original_lease_slack_sec=event['source_deadline_sec']-event['planning_started_at_sec'],
        timing={k:dict(cold_wall_sec=v,median_wall_sec=statistics.median(v)) for k,v in samples.items()})
    print(name,{k:statistics.median(v) for k,v in samples.items()},flush=True)
root=Path('/home/zhuyulab/ns3-workspace');path=Path(control.__file__)
source=path.read_text();before=subprocess.check_output(['git','show',charge_reference['commit']+':'+str(path.relative_to(root))],cwd=root,text=True)
def definitions(s):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=definitions(before),definitions(source);changed=[n for n in a if a[n]!=b[n]];added=[n for n in b if n not in a]
assert changed==['HeadquartersControl'] and added==['exploration_battery_factor_bound'],(changed,added)
classes=[next(n for n in ast.parse(s).body if isinstance(n,ast.ClassDef) and n.name=='HeadquartersControl') for s in (before,source)]
methods=[{n.name:ast.dump(n,include_attributes=False) for n in cls.body if isinstance(n,ast.FunctionDef)} for cls in classes]
changed_methods=[n for n in methods[0] if methods[0][n]!=methods[1][n]]
assert list(methods[0])==list(methods[1]) and changed_methods==['assign_idle_robots']
out=dict(status='PASS',parent_commit=charge_reference['commit'],control_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
    scope='Six exact retained abandoned inputs; paired five cold fixed epochs and conditional transport only; no original-history/live-clock/worst-case/mission causal claim',
    changed_pure=[],added=added,changed_methods=changed_methods,comparisons=output)
Path('log/p2c_v37_final_comparisons.json').write_text(json.dumps(out,indent=2)+'\n')
