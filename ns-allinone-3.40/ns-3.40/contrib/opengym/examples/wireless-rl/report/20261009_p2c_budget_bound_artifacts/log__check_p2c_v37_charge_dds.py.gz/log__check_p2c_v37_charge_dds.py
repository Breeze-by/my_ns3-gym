import hashlib, json, time
from pathlib import Path
import rclpy
from rclpy.node import Node
from rclpy.executors import SingleThreadedExecutor
from std_msgs.msg import String
from multi_robot_exploration import control
from test_candidate_battery_bound import REFERENCE, conditional_charge, reference_assign
from check_p2c_gate import planning_lease_audit

rclpy.init(args=['--ros-args','-p','robot_count:=2','-p','use_sim_time:=true',
    '-p','enable_battery:=true','-p','enable_rally:=true','-p','auto_save_map:=false'])
coordinator=receiver=None;executor=SingleThreadedExecutor();received=[];requests=[];results={}
try:
    coordinator=control.HeadquartersControl();receiver=Node('p2c_charge_bound_independent_receiver')
    for timer in coordinator.timers:timer.cancel()
    executor.add_node(coordinator);executor.add_node(receiver)
    receiver.create_subscription(String,coordinator.consumed_publisher.topic_name,
        lambda message:received.append(json.loads(message.data)),20)
    for publisher in coordinator.charge_request_publishers.values():
        receiver.create_subscription(String,publisher.topic_name,
            lambda message:requests.append(json.loads(message.data)),10)
    deadline=time.monotonic()+10.
    while (coordinator.consumed_publisher.get_subscription_count()!=1
           or any(p.get_subscription_count()!=1 for p in coordinator.charge_request_publishers.values())) and time.monotonic()<deadline:
        executor.spin_once(timeout_sec=.02)
    assert coordinator.consumed_publisher.get_subscription_count()==1
    assert all(p.get_subscription_count()==1 for p in coordinator.charge_request_publishers.values())
    for stage,event in REFERENCE['snapshots'].items():
        expected=conditional_charge(event,reference_assign());first=len(requests);first_event=len(received)
        def admit(fixture):
            for key,value in vars(fixture).items():
                if key not in ('consumed_publisher','get_logger','send_goal','charge_request_publishers'):
                    setattr(coordinator,key,value)
            coordinator.return_distance_caches={};coordinator.return_map_veto_at={}
            coordinator.exploration_travel_choices={};coordinator.frontier_geometry_cache=None
            coordinator.send_goal=lambda *args: (_ for _ in ()).throw(AssertionError('expected charging, no Nav2 goal'))
            control.HeadquartersControl.assign_idle_robots(coordinator)
            fixture.exploration_travel_choices=coordinator.exploration_travel_choices
        conditional_charge(event,admit)
        deadline=time.monotonic()+10.
        while (len(requests)==first or not any(e.get('event')=='coordinator_charge_decision' for e in received[first_event:])) and time.monotonic()<deadline:
            executor.spin_once(timeout_sec=.02)
        actual=requests[first:];events=received[first_event:]
        assert actual==expected['requests']
        charge=[e for e in events if e.get('event')=='coordinator_charge_decision'];assert len(charge)==1
        assert charge[0]['required_energy']==actual[0]['required_energy']
        assert actual[0]['stamp_sec']==event['planning_started_at_sec']
        leases=planning_lease_audit(events)
        results[stage]=dict(status='PASS',same_as_independently_frozen_full_search=True,
            original_source_epoch=event['planning_started_at_sec'],actual_dds_request=actual[0],
            actual_received_events=events,leases=leases)
    out=dict(status='PASS',control_sha256=hashlib.sha256(Path(control.__file__).read_bytes()).hexdigest(),
        scope='Actual isolated central node and independent DDS charge-request/audit receivers; exact saved original inputs at fixed epoch, no gateway/native battery/Nav2 motion or original latency claim',cases=results)
    Path('log/p2c_v37_charge_dds.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({n:{k:v for k,v in e.items() if k!='actual_received_events'} for n,e in results.items()}))
finally:
    executor.shutdown()
    for node in (coordinator,receiver):
        if node is not None:node.destroy_node()
    rclpy.shutdown()
