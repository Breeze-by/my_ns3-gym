import base64,hashlib,json,time,zlib
from pathlib import Path
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.executors import SingleThreadedExecutor
from std_msgs.msg import String
from multi_robot_exploration import control
from check_p2c_gate import rally_assignment_audit

rclpy.init(args=['--ros-args','-p','robot_count:=3','-p','use_sim_time:=true',
    '-p','enable_battery:=true','-p','enable_rally:=true','-p','auto_save_map:=false'])
coordinator=receiver=None;executor=SingleThreadedExecutor();received=[];outputs=[]
try:
    coordinator=control.HeadquartersControl();receiver=Node('p2c_progressive_rally_witness_receiver')
    for timer in coordinator.timers:timer.cancel()
    executor.add_node(coordinator);executor.add_node(receiver)
    receiver.create_subscription(String,coordinator.consumed_publisher.topic_name,
        lambda message:received.append(json.loads(message.data)),10)
    deadline=time.monotonic()+10.
    while coordinator.consumed_publisher.get_subscription_count()!=1 and time.monotonic()<deadline:
        executor.spin_once(timeout_sec=.02)
    assert coordinator.consumed_publisher.get_subscription_count()==1
    for case in ('dev_lab101','dev_corridors303'):
        p=Path('log/p2c_v34_'+case+'_rally_snapshot.json');e=json.loads(p.read_text());geometry={}
        for key,s in [('planning',e['planning_map']),('source',e['source_map']),*e['return_maps'].items()]:
            geometry[key]=dict(data=np.frombuffer(zlib.decompress(base64.b64decode(s['grid'])),dtype='<i2').reshape(s['shape']),
                resolution=s['resolution'],origin=s['origin'])
        grid=geometry.pop('planning');source=geometry.pop('source')
        coordinator.map_data=grid['data'];coordinator.source_map_data=source['data']
        coordinator.resolution=grid['resolution'];coordinator.origin=grid['origin']
        coordinator.map_received_at=e['planning_map']['source_time'];coordinator.map_self_return_cells=e['self_return_cells']
        coordinator.robot_positions=e['current_positions'];coordinator.battery_states=e['battery_states']
        coordinator.target=e['target'];coordinator.target_observing_robot=e['observer_robot']
        coordinator.rally_assignment_objective=e['objective'];coordinator.rally_hold_sec=e['hold_sec']
        coordinator.robot_map_received_at={n:s['source_time'] for n,s in e['return_maps'].items()}
        coordinator.now=lambda:e['event_time'];coordinator.input_freshness_details=lambda:e['inputs']
        begin=time.perf_counter()
        assignment=control.assign_rally_poses(grid['data'],grid['resolution'],grid['origin'],e['robot_positions'],e['target'],
            objective=e['objective'],battery_states=e['battery_states'],observer_robot=e['observer_robot'],
            current_positions=e['current_positions'],hold_sec=e['hold_sec'],return_maps=geometry)
        wall=time.perf_counter()-begin
        assert len(assignment)==3 and all(type(p) is control.RallyPose for p in assignment.values())
        coordinator.record_rally_assignment(e['robot_positions'],geometry,wall,assignment,e['event_time'])
        deadline=time.monotonic()+10.
        while len(received)<len(outputs)+1 and time.monotonic()<deadline:executor.spin_once(timeout_sec=.02)
        assert len(received)==len(outputs)+1
        audit=rally_assignment_audit([received[-1]])
        assert audit['chosen_assignments_rebuilt']==1
        outputs.append(dict(case=case,snapshot_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),audit=audit))
    output=dict(status='PASS',scope='Actual ROS producer/independent DDS consumer with two retained fixed inputs; progressive complete assignment witnesses, no motion, real clock-bound or original-history replay',
        control_sha256=hashlib.sha256(Path(control.__file__).read_bytes()).hexdigest(),cases=outputs,received_events=received)
    Path('log/p2c_v37_rally_dds.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({k:v for k,v in output.items() if k!='received_events'}))
finally:
    executor.shutdown()
    for node in (coordinator,receiver):
        if node is not None:node.destroy_node()
    rclpy.shutdown()
