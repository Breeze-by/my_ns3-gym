import gzip,hashlib,json,re,statistics,subprocess
from pathlib import Path
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py'
comparison=load(r/'log/p2c_v31_geometry_comparison.json');assert comparison['status']=='PASS' and comparison['control_sha256']==sha(control)
source=load(r/'log/p2c_v31_source_final.json');assert source['status']=='PASS'
runtime={name:load(r/f'log/p2c_v31_{name}_runtime_final.json') for name in ('clock','native_future','visual')}
assert all(v['status']=='PASS' for v in runtime.values())
assert runtime['clock']['control_sha256']==runtime['visual']['control_sha256']==sha(control)
full=re.search(r'(\d+) passed in ([\d.]+)s',(r/'log/p2c_v31_full_components_final.log').read_text());assert full and int(full[1])==1238
build=re.search(r'4 packages finished \[([\d.]+)s\]',(r/'log/p2c_v31_build_final.log').read_text());assert build
assert '1 failed, 24 deselected' in (r/'log/p2c_v31_mutable_route_negative.log').read_text()
assert all(load(r/'log'/name)['config']==load(r/'scripts'/manifest) for name,manifest in (
    ('p2c_v31_manifest.json','p2c_integration_manifest.json'),('p2c_v31_blackout_manifest.json','p2c_blackout_manifest.json')))
old=load(r/'log/p2c_v28_independent_audits.json');reaudit=load(r/'log/p2c_v31_previous_original_audits.json')
for case,rows in reaudit.items():
    for name,data in rows.items():
        if name!='native_vs_gateway_frame_samples':assert data['status']==old[case][name]['status']
unchanged={}
for rel in ('src/multi_robot_exploration/multi_robot_exploration/battery_manager.py','src/multi_robot_exploration/multi_robot_exploration/action_callbacks.py',
    'src/multi_robot_exploration/multi_robot_exploration/tf_ingress_sampler.py','src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py',
    'scripts/observe_p3b5.py','scripts/p2c_native_graph.py','scripts/check_p2c_gate.py','scripts/ros_smoke_test.py'):
    p=r/rel;before=subprocess.check_output(['git','show','c12db66cf666779978dd74b315a9e92b080f4a11:'+str(p.relative_to(root))],cwd=root)
    assert before==p.read_bytes();unchanged[rel]=sha(p)
files=[p for p in (r/'log').glob('*p2c_v31*') if p.is_file() and p.suffix!='.pyc']
files += [r/'log/p2c_v30_planning_snapshot.json']
destination=report/'20261009_p2c_geometry_performance_artifacts';destination.mkdir();artifacts=[]
for p in sorted(set(files)):
    q=destination/('__'.join(p.relative_to(r).parts)+'.gz');q.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0))
    assert gzip.decompress(q.read_bytes())==p.read_bytes()
    artifacts.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(q.relative_to(report)),archive_sha256=sha(q)))
outputs=dict(status='PASS',scope='Prospective exact geometry optimization components, not mission acceptance',
    parent_commit='c12db66cf666779978dd74b315a9e92b080f4a11',control_sha256=sha(control),functional_checks=int(full[1]),
    functional_wall_sec=float(full[2]),directed_checks=115,directed_wall_sec=18.20,build_wall_sec=float(build[1]),
    source_audit=source,actual_ros=runtime,geometry_comparison=comparison,previous_original_reaudit=reaudit,
    unchanged_from_parent=unchanged,negative_reproduction='Initial route memo retained list-position alias: one deliberately adversarial test FAIL before immutable route-point copy; no task ran this intermediate code',
    unrun=['new4 development','new17 formal','new2 physical','917'],
    limits='Same integer disk and static delivered return geometry; original sources and real clock remain. Five fixed-snapshot CPU timings are not a worst-case bound, causal mission improvement or Wi-Fi bottleneck. Native battery file byte-identical but shared pure geometry code changed and requires new physical/task integration.',artifacts=artifacts)
(report/'20261009_p2c_geometry_performance_components.json').write_text(json.dumps(outputs,indent=2)+'\n')
before=statistics.median(comparison['timing']['frozen_v30']['cold_wall_sec']);after=statistics.median(comparison['timing']['candidate_v31']['cold_wall_sec'])
(report/'20261009_p2c_geometry_performance_components.md').write_text(f'''# P2C.1 v31 等价几何优化组件 PASS

v30冻结c12db66首强制任务300.2秒EXPLORE timeout，仅一次导航/零charge；130次计算因原source+TTL到期而弃置。所有owned自然关闭后归档原FAIL，后3开发/17正式/2受控物理/917未调用。本候选不放宽原2秒位姿/5秒地图电池/300秒horizon/5秒原生保持；先减少同一几何的重复计算。

圆盘膨胀改为已有SciPy欧氏距离变换<=原整数半径；无occupied格特判全false，避免EDT域外虚拟零点成为假墙。12随机种子×5矩形/单行列尺寸×4密度×8半径，加3-4-5与5-12-13精确边界，逐格与旧binary_dilation闭圆盘相同。原unknown/free/occupied阈值、端点/.35/.45净空、角点与路线函数保持。

已有qualified_return_candidates几何缓存增加最多128位置的结果表，仅当fused与consulted local map均由不可变底层内存支持；按原图对象/各geometry/home/radius/位置绑定，任一源替换或几何改变即清空，可写底层的readonly别名跳过结果复用。仅缓存完整路线与local障碍否决结果，不缓存energy/age/lease。独立结果dict与不可变路径点避免调用者污染memo。初版只浅复制dict，列表position可修改缓存route的反例1FAIL已保留，补路径点tuple后通过；中间版本未进任务。

取v30唯一实际导航事件的211×253原交付地图，在固定原source/evaluation epoch且两机均idle的条件夹具内，五次完整调度冷计算中位数{before:.5f}→{after:.5f}秒；全部选择、路径/旅行偏好及预算数值相同。该只读组件不含原任务全历史、实际计算期间clock或真实Nav2派发，不是任务反事实/最坏延迟保证。当前coordinator类AST完全相同，只改两个纯函数。v28四份旧原始数据重新用新几何审核，原状态保持：corridors原未闭合返航FAIL，其余返航与各预算/目标/探索重建PASS；不把旧cohort改作新通过。

最终1238功能PASS{float(full[2]):.2f}秒、四包{float(build[1]):.2f}秒、171保护/4授权/54静态协议/8中央+2native deferred Future注册、两manifest PASS。实际ROS DDS clock+真实Future串行、native Future保护、visual79数值/旧JSON错误复现、相机兴趣/target survey/healthy quiet和lapsed turn均绑定最终源SHA PASS。native battery/sampler/action helper/launch/observer/严格gate/result reader相对c12字节保持，但native调用的shared geometry已变化，所以新任务和两受控物理原格仍必须验。两份声明case及physical刺激不变。

组件PASS，P2C.1尚未通过。新4开发→17正式+2物理须同clean pushed freeze，917仍未暴露。P3C.5已验收；无P4/ns-3/Wi-Fi/RL。
''')
note=f'2026-10-09 P2C.1 v31等价几何组件PASS待新冻结：v30 c12首强制原EXPLORE300.2timeout/1导航/0charge/130原租约弃置，12独立检查PASS但任务FAIL；全部原始保留，后3/17/2/917未调用。仅2纯函数：同整数闭圆盘EDT逐格等价、immutable fused/local完整返路结果有界128点复用；不缓存预算/源龄，不续租，中央类AST与native文件保持。列表路径点污染反例1FAIL已修成immutable点、无中间任务。1238功能/四包{float(build[1]):.2f}s/171保护4授权54协议/实际ROS/两manifest PASS；原交付图条件完整调度中位{before:.3f}→{after:.3f}s且选择预算一致，非任务反事实或最坏保证。v28四原只读重审保留corridors未闭合return FAIL。新4/17/2需同clean pushed freeze；P3C.5已验收，无P4/ns-3/Wi-Fi/RL。报告20261009_p2c_geometry_performance_components.md与20261009_p2c_v30_failed_development.md。'
for p in (w/'AGENTS.md',w/'RESEARCH_PLAN.md',w/'IMPLEMENTATION_PLAN.md',r/'user_guide.md',r/'launch_commands.md'):
    first,rest=p.read_text().split('\n',1);p.write_text(first+'\n\n'+note+'\n'+rest)
p=root/'AGENTS.md';p.write_text(p.read_text().replace('## Current Handoff\n','## Current Handoff\n\n'+note+'\n',1))
with (w/'log.md').open('a') as f:
    f.write('\n\n## 2026-10-09 P2C.1 v31 等价几何计算优化\n\n'+note+'\n\n')
    f.write('Humble+in-repo install/PYTHONNOUSERSITE=1；pytest -q test_geometry_performance.py/test_return_geometry_optimization.py/test_return_budget.py/test_constrained_return_search.py/test_ap_return_consistency.py/test_live_planning_clock.py115 PASS18.20s；初版全pytest三lint ignore1237 PASS73.44s、四包/source/两声明/actualROS PASS。复查列表position→returned route引用，pytest -q test_geometry_performance.py -k caller_cannot_mutate 1FAIL/24 deselected1.19s实际重现，保存初版control SHA40a50586及负例日志；只缓存不可变tuple点后完整1238 PASS72.15s。无中间任务。\n\n')
    f.write(f'最终colcon build --symlink-install --packages-select multi_robot_interfaces multi_robot_exploration merge_map multi_robot4包{float(build[1]):.2f}s；check_p2c_source.py --output log/p2c_v31_source_final.json171/4/54与8+2 PASS；FastDDS UDPv4/unset旧profiles：ROS_DOMAIN_ID220 check_p2c_clock_runtime.py --output log/p2c_v31_clock_runtime_final.json，221 check_p2c_native_future_runtime.py --output log/p2c_v31_native_future_runtime_final.json，215 check_p2c_visual_runtime.py --output log/p2c_v31_visual_runtime_final.json全部最终bytes PASS。compare_p2c_v31_geometry.py冻c12 vs当前，5次cold固定地图/源/epoch/两idle条件组件，.568→.213s且选择预算一致；profile与源/输入有SHA，不称真实Nav2或最坏保证。audit_p2c_v31_previous_originals.py只读重审原v28四份不改raw，原corridors未闭合返航仍FAIL，其他类别原状态保持。\n\n')
    f.write('run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v31 --domain210 --gazebo-port20290 --validate-only；--case physical_fault --manifest scripts/p2c_blackout_manifest.json --run-id 20261009_p2c_v31_physical --domain219 --gazebo-port20299 --validate-only，均只验证声明。新4/17/2尚未运行，917未暴露。raw git diff --check、git add -n .须检查每个exit0，完成commit/push0后独立cleanfreeze才能首强制真实任务；domain222/master11345未操作。\n')
print(json.dumps(dict(status='PASS',functional_checks=1238,component_archives=len(artifacts),cold_median_before=before,cold_median_after=after,build_sec=float(build[1]))))
