import ast,base64,dataclasses,hashlib,json,pstats,cProfile,subprocess,sys,time,types,zlib
from pathlib import Path
import numpy as np
import test_exploration_resume as fixtures
from multi_robot_exploration import control

root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
path=r/'src/multi_robot_exploration/multi_robot_exploration/control.py'
source=subprocess.check_output(['git','show','c12db66cf666779978dd74b315a9e92b080f4a11:'+str(path.relative_to(root))],cwd=root,text=True)
baseline=types.ModuleType('multi_robot_exploration.p2c_v30_profile_baseline');baseline.__package__='multi_robot_exploration';baseline.__file__=str(path)
sys.modules[baseline.__name__]=baseline;exec(compile(source,str(path),'exec'),baseline.__dict__)
e=json.loads((r/'log/p2c_v30_planning_snapshot.json').read_text())['event']
def serial(value):
    return json.loads(json.dumps(value,default=lambda x:dataclasses.asdict(x) if dataclasses.is_dataclass(x) else x.tolist()))
def conditional(module):
    fixtures.control=module
    node,sent=fixtures.conditional_snapshot_node(e,{})
    node.robot_states={name:'idle' for name in node.robot_states};node.enable_rally=True
    node.initial_search_next={};node.initial_search_visits={};node.initial_search_views={};node.target_search_visits=[]
    node.exploration_travel_choices={};node.frontier_charge_lookahead=None
    module.HeadquartersControl.assign_idle_robots(node)
    return serial(dict(sent=sent,choices=node.exploration_travel_choices,budget_times=node.exploration_budget_times))
outputs={};reference=None
for label,module in [('frozen_v30',baseline),('candidate_v31',control)]:
    wall=[]
    for repeat in range(5):
        start=time.perf_counter();result=conditional(module);wall.append(time.perf_counter()-start)
        if reference is None:reference=result
        assert result==reference,(label,'assignment/budget evidence changed')
    profile=cProfile.Profile();result=profile.runcall(conditional,module)
    with (r/f'log/p2c_v31_{label}_profile.txt').open('w') as f:pstats.Stats(profile,stream=f).strip_dirs().sort_stats('cumulative').print_stats(35)
    outputs[label]=dict(cold_wall_sec=wall,assignment_and_budget_equal=True)
fixtures.control=control
before=ast.parse(source);after=ast.parse(path.read_text())
functions=lambda tree:{n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=functions(before),functions(after);changed=[name for name in a if a[name]!=b[name]]
assert changed==['inflated_obstacle_mask','qualified_return_candidates'],changed
output=dict(status='PASS',scope='Fixed original delivered snapshot CPU computation only, no real dispatch or causal task result',
    baseline_commit='c12db66cf666779978dd74b315a9e92b080f4a11',control_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
    changed_pure_functions=changed,central_class_ast_unchanged=True,original_snapshot='log/p2c_v30_planning_snapshot.json',
    timing=outputs,comparison_result=reference)
(r/'log/p2c_v31_geometry_comparison.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({k:v for k,v in output.items() if k!='comparison_result'}))
