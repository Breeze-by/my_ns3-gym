import gzip,hashlib,json,re,statistics,subprocess
from pathlib import Path
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py'
comparison=load(r/'log/p2c_v32_lookup_comparison.json');assert comparison['status']=='PASS' and comparison['control_sha256']==sha(control)
source=load(r/'log/p2c_v32_source.json');assert source['status']=='PASS'
runtime={name:load(r/'log'/file) for name,file in (
    ('clock','p2c_v32_clock_runtime.json'),('native_future','p2c_v32_native_future_runtime.json'),('visual','p2c_v32_visual_runtime_numeric.json'))}
assert all(v['status']=='PASS' for v in runtime.values())
assert runtime['clock']['control_sha256']==runtime['visual']['control_sha256']==sha(control)
assert runtime['visual']['numeric_ray_and_view_checks']==20 and runtime['visual']['candidates_compared']==79
full=re.search(r'(\d+) passed in ([\d.]+)s',(r/'log/p2c_v32_full_components.log').read_text());assert full and int(full[1])==1260
build=re.search(r'4 packages finished \[([\d.]+)s\]',(r/'log/p2c_v32_build.log').read_text());assert build
assert all(load(r/'log'/name)['config']==load(r/'scripts'/manifest) for name,manifest in (
    ('p2c_v32_manifest.json','p2c_integration_manifest.json'),('p2c_v32_blackout_manifest.json','p2c_blackout_manifest.json')))
old=load(r/'log/p2c_v31_independent_audits.json');reaudit=load(r/'log/p2c_v32_previous_original_audits.json')
for name,data in reaudit['dev_forced2'].items():assert data['status']==old['dev_forced2'][name]['status']
unchanged={}
for rel in ('src/multi_robot_exploration/multi_robot_exploration/battery_manager.py','src/multi_robot_exploration/multi_robot_exploration/action_callbacks.py',
    'src/multi_robot_exploration/multi_robot_exploration/tf_ingress_sampler.py','src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py',
    'scripts/observe_p3b5.py','scripts/p2c_native_graph.py','scripts/check_p2c_gate.py','scripts/ros_smoke_test.py'):
    p=r/rel;before=subprocess.check_output(['git','show','f455c2ee299501a61301318d61a4fd3ce8ad9fb2:'+str(p.relative_to(root))],cwd=root)
    assert before==p.read_bytes();unchanged[rel]=sha(p)
files=[p for p in (r/'log').glob('*p2c_v32*') if p.is_file() and p.suffix!='.pyc']
files += [r/'log/p2c_v31_actual_planning_snapshot.json',r/'src/multi_robot_exploration/test/fixtures/p2c_v31_visual_computation.json']
destination=report/'20261009_p2c_visibility_lookup_artifacts';destination.mkdir();artifacts=[]
for p in sorted(set(files)):
    q=destination/('__'.join(p.relative_to(r).parts)+'.gz');q.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0))
    assert gzip.decompress(q.read_bytes())==p.read_bytes()
    artifacts.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(q.relative_to(report)),archive_sha256=sha(q)))
outputs=dict(status='PASS',scope='Prospective identical visibility math and lazy mapping preparation components; no mission acceptance',
    parent_commit='f455c2ee299501a61301318d61a4fd3ce8ad9fb2',control_sha256=sha(control),functional_checks=int(full[1]),
    functional_wall_sec=float(full[2]),directed_checks=116,directed_wall_sec=10.14,build_wall_sec=float(build[1]),
    source_audit=source,actual_ros=runtime,late_geometry_comparison=comparison,previous_original_reaudit=reaudit,
    unchanged_from_parent=unchanged,read_only_visual_validator_sha256=sha(r/'scripts/check_p2c_visual_runtime.py'),
    validation_failure='First actual DDS validator stopped before rclpy init at an old source-AST equality assertion. Corrected to independently compile original frozen math and compare cells/gain/yaw/79 candidates before actual DDS; original failed invocation retained, no task.',
    unrun=['new4 development','new17 formal','new2 physical','917'],
    limits='Fixed delivered-map CPU samples are not a worst-case bound, actual callback latency or causal mission effect. No map/age/budget values are cached in visibility tables. All eventual task/physical originals require same new freeze.',artifacts=artifacts)
(report/'20261009_p2c_visibility_lookup_components.json').write_text(json.dumps(outputs,indent=2)+'\n')
before=statistics.median(comparison['timing']['frozen_v31']['cold_wall_sec']);after=statistics.median(comparison['timing']['candidate_v32']['cold_wall_sec'])
(report/'20261009_p2c_visibility_lookup_components.md').write_text(f'''# P2C.1 v32 视场查表与按需前沿准备组件 PASS

v31首强制原任务300.3秒EXPLORE timeout/3导航/1charge/135原租约弃置，strict FAIL完整保留，后3/17/2/917未调用。后期212×253交付图/14视场历史的条件计算1.222秒，包含265射线、89视觉候选；早期.213秒样本不是此负载的时限界。没有执行器饥饿或Wi-Fi瓶颈的证明。本候选仍保持原真实clock、source/2秒位姿/5秒地图电池/native300秒/5秒与完整预算。

将原角度×步长浮点投影按radius缓存成最多8个bytes-backed不可变表，仍先加实际row/column再np.rint，保留半偶舍入与大整数坐标浮点行为。以平面bool hit mask代替flat cell排序去重，sorted cells与gain逐项相同。把整数相对格上原16yaw的atan2(sin,cos)/inclusive FOV谓词预计算为最多8个不可变radius/FOV表；不是cos近似、角度阈值放宽或未知空间可见化。每次实际地图、当前遮挡与历史interest仍重算，没有地图/header/age/energy缓存或新应用流。

只改两个纯计算函数、增加两个纯lookup，并修改assign_idle_robots一处准备顺序：完整mapping前沿仅在该分支需要时生成；原traversable/.35净空travel field保持，visual为空仍回原mapping，所有route/body/预约/完整budget/source/charge/dispatch门限保持。原mapping策略、目标选择与计划优先级没有改变。保存后期实际交付夹具验证不执行unused mapping rays且同导航点，空visual仍真实生成并使用mapping候选。固定原source/epoch/eligible tb2与pending tb1的五次cold条件完整调度中位{before:.5f}→{after:.5f}秒，所有选择/旅行偏好/预算值相同；前期只lookup约1.096→.944秒，按需准备进一步降低开销。这些均无真实机器人派发、原始全历史反事实或最坏界。

12种子/单行列与矩形地图/边界/七个整数和临界浮点radius/unknown与occupied遮挡，原sorted cell集/计数/yaw逐项一致；所有整数offset及1/2/5/20/40/41半径、3种FOV谓词与tie、百万坐标平移、不可写底层/有界内存检查通过。116定向PASS10.14秒；最终1260功能PASS{float(full[2]):.2f}秒、四包{float(build[1]):.2f}秒、171保护/4授权/54静态协议/8+2 Future注册/两声明PASS。native battery/action helper/TF sampler/launch/observer/严格gate/result reader字节相对f455保持。

首actual ROS validator在旧pure function AST必须相同处停止、未init DDS；该要求不适用于明确授权的等价算法优化。改为独立编译89ee853原visible_unknown_gain/known_search_interest/known_search_view/known_space_search_candidates，20组sorted rays与gain/yaw、79候选数值相同，并继续复现旧int64 JSON错误/新实际DDS发布及独立消费；原相机history、target survey、healthy quiet/lapsed checks PASS，clock与真实Future/native保护也绑定最终source PASS。只读v31原样重审12子门仍PASS且任务FAIL，不回填。

组件PASS，P2C.1未通过。新4开发→17正式+2物理必须同clean pushed freeze；917未暴露。P3C.5已验收，无P4/ns-3/Wi-Fi/RL。
''')
note=f'2026-10-09 P2C.1 v32视场lookup/按需准备组件PASS待新冻结：v31 f455首强制300.3EXPLOREtimeout/3nav/1charge/135原lease弃置，12子门PASS但任务FAIL全部保留，其余3/17/2/917未调用。后期实际交付图265射线/89视觉候选，纯投影与16yaw整数谓词最多8不可变表、flat bool去重保持原单元/gain/yaw；visual无需unused mapping rays，空visual仍原mapping。只2纯修改+2新增/1中央准备方法，其余native/硬预算/TTL/300s/5s保持。1260功能/116定向/四包{float(build[1]):.2f}s/171保护4授权54协议/实际ROS20原math+79候选与消费者PASS。原AST读者FAIL已改为独立冻原数值比较，失败保留无task。后期固定条件cold中位{before:.3f}→{after:.3f}s，非回放/最坏界。新4/17/2待同clean pushed freeze；P3C.5验收，无P4/ns-3/Wi-Fi/RL。报告20261009_p2c_visibility_lookup_components.md与20261009_p2c_v31_failed_development.md。'
for p in (w/'AGENTS.md',w/'RESEARCH_PLAN.md',w/'IMPLEMENTATION_PLAN.md',r/'user_guide.md',r/'launch_commands.md'):
    first,rest=p.read_text().split('\n',1);p.write_text(first+'\n\n'+note+'\n'+rest)
p=root/'AGENTS.md';p.write_text(p.read_text().replace('## Current Handoff\n','## Current Handoff\n\n'+note+'\n',1))
with (w/'log.md').open('a') as f:
    f.write('\n\n## 2026-10-09 P2C.1 v32 视场lookup/按需mapping前沿\n\n'+note+'\n\n')
    f.write('Humble+install/PYTHONNOUSERSITE=1；pytest -q test_visibility_lookup.py/test_camera_aware_search.py/test_initial_known_search.py/test_mission_search_diversity.py/test_live_planning_clock.py114 PASS9.29s；加入test_lazy_frontier_preparation.py后116 PASS10.14s；完整pytest src/multi_robot_exploration/test scripts三lint ignore1260 PASS75.14s，新增数据来自v31实际2165.882s私有交付几何，固定条件eligible tb2/pending tb1，没有实际Nav2。compare_p2c_v32_lookup.py冻f455 vs当前，纯lookup5 cold1.096→.944s，再按需准备5 cold1.114→.608s，最后QA同时运行时1.160→.619s，选择预算逐项一致；全部输出/源SHA保留，非任务/最坏界。\n\n')
    f.write(f'colcon build --symlink-install --packages-select multi_robot_interfaces multi_robot_exploration merge_map multi_robot4包{float(build[1]):.2f}s；check_p2c_source.py --output log/p2c_v32_source.json171/4/54/8+2 PASS；run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v32 --domain210 --gazebo-port20290 --validate-only，以及--case physical_fault --manifest scripts/p2c_blackout_manifest.json --run-id 20261009_p2c_v32_physical --domain219 --gazebo-port20299 --validate-only PASS，case/physics刺激不变。FastDDS UDPv4/清旧profiles：domain220 check_p2c_clock_runtime.py --output log/p2c_v32_clock_runtime.json、221 check_p2c_native_future_runtime.py --output log/p2c_v32_native_future_runtime.json PASS。domain215 first check_p2c_visual_runtime.py --output log/p2c_v32_visual_runtime.json在旧AST equality处exit1未rclpy.init，改为编译完整89ee853旧math及79候选独立比较后--output log/p2c_v32_visual_runtime_numeric.json PASS20math/79numeric/旧JSON错误/实际发布消费/camera/survey/quiet/lapsed。新只读脚本py_compile0，无task。\n\n')
    f.write('audit_p2c_v32_previous_originals.py原v31 raw不改，12子门仍PASS/strict任务仍FAIL。新4/17/2/917未启动；commit/push exit0与独立clean freeze后才首强制，失败原件不重跑回填，native300秒/5秒与TTL不放宽，domain222/master11345未操作。\n')
print(json.dumps(dict(status='PASS',functional_checks=1260,component_archives=len(artifacts),cold_median_before=before,cold_median_after=after,build_sec=float(build[1]))))
