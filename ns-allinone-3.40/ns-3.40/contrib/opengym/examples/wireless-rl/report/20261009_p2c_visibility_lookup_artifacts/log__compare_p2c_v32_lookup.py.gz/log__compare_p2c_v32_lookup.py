import ast,cProfile,dataclasses,hashlib,json,pstats,subprocess,sys,time,types
from pathlib import Path
import test_exploration_resume as fixtures
from multi_robot_exploration import control

root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
path=r/'src/multi_robot_exploration/multi_robot_exploration/control.py'
source=subprocess.check_output(['git','show','f455c2ee299501a61301318d61a4fd3ce8ad9fb2:'+str(path.relative_to(root))],cwd=root,text=True)
baseline=types.ModuleType('multi_robot_exploration.p2c_v31_lookup_baseline');baseline.__package__='multi_robot_exploration';baseline.__file__=str(path)
sys.modules[baseline.__name__]=baseline;exec(compile(source,str(path),'exec'),baseline.__dict__)
e=json.loads((r/'log/p2c_v31_actual_planning_snapshot.json').read_text())['event']
def serial(value):
    return json.loads(json.dumps(value,default=lambda x:dataclasses.asdict(x) if dataclasses.is_dataclass(x) else x.tolist()))
def conditional(module):
    fixtures.control=module;node,sent=fixtures.conditional_snapshot_node(e,{})
    node.input_robot_names=lambda:e['travel_preference']['eligible_robot_names'];node.robot_maps.setdefault('tb1',None)
    node.robot_states={name:'idle' for name in node.robot_states};node.enable_rally=True
    node.initial_search_next={e['robot']:True};node.rally_charge_requested={'tb1':e['event_time']}
    node.initial_search_visits={i:v for i,v in enumerate(e['travel_preference']['initial_search_visits'])}
    node.initial_search_views={i:v for i,v in enumerate(e['travel_preference']['initial_search_views'])}
    node.successful_exploration_legs={e['robot']:1};node.target_search_visits=[]
    node.exploration_travel_choices={};node.frontier_charge_lookahead=None
    module.HeadquartersControl.assign_idle_robots(node)
    return serial(dict(sent=sent,choices=node.exploration_travel_choices,budget_times=node.exploration_budget_times))
outputs={};reference=None
for label,module in [('frozen_v31',baseline),('candidate_v32',control)]:
    wall=[]
    for repeat in range(5):
        if label=='candidate_v32':
            control.visibility_ray_projections.cache_clear();control.known_search_sector_table.cache_clear()
        start=time.perf_counter();result=conditional(module);wall.append(time.perf_counter()-start)
        if reference is None:reference=result
        assert result==reference,(label,'assignment/budget evidence changed')
    profile=cProfile.Profile();result=profile.runcall(conditional,module)
    with (r/f'log/p2c_v32_{label}_profile.txt').open('w') as f:pstats.Stats(profile,stream=f).strip_dirs().sort_stats('cumulative').print_stats(35)
    outputs[label]=dict(cold_wall_sec=wall,assignment_and_budget_equal=True)
fixtures.control=control
functions=lambda tree:{n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=functions(ast.parse(source)),functions(ast.parse(path.read_text()))
changed=[name for name in a if a[name]!=b[name]];added=[name for name in b if name not in a]
assert changed==['visible_unknown_gain','known_search_view','HeadquartersControl'] and added==['visibility_ray_projections','known_search_sector_table'],(changed,added)
old_class=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='HeadquartersControl')
new_class=next(n for n in ast.parse(path.read_text()).body if isinstance(n,ast.ClassDef) and n.name=='HeadquartersControl')
a_methods={n.name:ast.dump(n,include_attributes=False) for n in old_class.body if isinstance(n,ast.FunctionDef)}
b_methods={n.name:ast.dump(n,include_attributes=False) for n in new_class.body if isinstance(n,ast.FunctionDef)}
assert list(a_methods)==list(b_methods) and [name for name in a_methods if a_methods[name]!=b_methods[name]]==['assign_idle_robots']
output=dict(status='PASS',scope='Late original delivered map/history fixed-source computation only, no real dispatch or causal task result',
    baseline_commit='f455c2ee299501a61301318d61a4fd3ce8ad9fb2',control_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
    changed_pure_functions=[name for name in changed if name!='HeadquartersControl'],added_pure_functions=added,changed_central_methods=['assign_idle_robots'],
    original_snapshot='log/p2c_v31_actual_planning_snapshot.json',timing=outputs,comparison_result=reference)
(r/'log/p2c_v32_lookup_comparison.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({k:v for k,v in output.items() if k!='comparison_result'}))
