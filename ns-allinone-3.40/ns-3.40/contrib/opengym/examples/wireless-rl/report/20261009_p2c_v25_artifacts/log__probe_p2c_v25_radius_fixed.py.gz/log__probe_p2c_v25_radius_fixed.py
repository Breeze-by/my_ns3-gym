import base64,json,math,zlib
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from multi_robot_exploration import control as c

path=next(Path('log/p2c/20261009_p2c_v25').glob('*/ledger.jsonl'))
events=[e for line in path.open() if (e:=json.loads(line)).get('event')=='coordinator_navigation_decision' and e.get('kind')=='exploration']
outputs=[]
fixtures=[]
for selection in (5,8,10,12,14):
 event=events[selection]
 fixtures.append(event)
 def decode(s):return dict(data=np.frombuffer(zlib.decompress(base64.b64decode(s['grid'])),dtype='<i2').reshape(s['shape']),resolution=s['resolution'],origin=s['origin'])
 maps={key:decode(s) for key,s in [('planning',event['planning_map']),('source',event['source_map']),*event['return_maps'].items()]}
 g=maps['planning'];states=event['battery_states'];f=event['travel_preference'];name=event['robot'];visits=f['mission_spatial_diversity']['visits']
 node=SimpleNamespace(enable_battery=True,enable_rally=True,now=lambda:event['event_time'],map_data=g['data'],resolution=g['resolution'],origin=g['origin'],
     map_received_at=event['planning_map']['source_time'],source_map_data=maps['source']['data'],map_self_return_cells=event['self_return_cells'],
     robot_positions=event['robot_positions'],battery_states=states,battery_modes={n:s['mode'] for n,s in states.items()},
     robot_maps={n:maps[n] for n in event['return_maps']},robot_map_received_at={n:s['source_time'] for n,s in event['return_maps'].items()},
     robot_odom_received_at={n:event['inputs'][n+'/pose_state']['source_time'] for n in f['eligible_robot_names']},
     robot_tf_received_at={n:event['inputs'][n+'/frame_state']['source_time'] for n in f['eligible_robot_names']},initial_search_visits={i:v for i,v in enumerate(visits)})
 mask=c.traversable_grid(g['data'],g['resolution'],c.PATH_CLEARANCE_M)
 fields={n:c.exploration_distance_field(g['data'],mask,g['resolution'],g['origin'],event['robot_positions'][n]) for n in f['eligible_robot_names']}
 blocked=[p for n,p in event['robot_positions'].items() if n!=name and p is not None]
 actual=c.exploration_distance_field(g['data'],c.block_dynamic_positions(mask,g['resolution'],g['origin'],blocked),g['resolution'],g['origin'],event['current_position'])
 results=[]
 original_radius=c.VIEWPOINT_SEARCH_RADIUS_M
 try:
  for radius in (.8,1.4,2.):
     c.VIEWPOINT_SEARCH_RADIUS_M=radius
     pool,stats=c.robot_candidate_assignments(g['data'],g['resolution'],g['origin'],name,event['current_position'],f['excluded_targets'],blocked_positions=blocked)
     rows=[];routes={}
     for utility,n,group,a in pool:
         cell=c.world_to_grid(a.x,a.y,g['resolution'],*g['origin']);distance=float(actual[cell])
         if not math.isfinite(distance):continue
         cost=c.HeadquartersControl.exploration_required_energy(node,name,distance,(a.x,a.y))
         plan=c.plan_rally_leg(c.RallyPose(a.x,a.y,a.navigation_yaw or 0.),g['data'],g['resolution'],g['origin'],event['current_position'],c.MAX_NAVIGATION_LEG_M,blocked_positions=blocked,clearance_m=c.PATH_CLEARANCE_M,visible_only=True,route_cache=routes)
         if cost is None or cost>=states[name]['energy'] or plan is None or plan[0] is None:continue
         preference=c.HeadquartersControl.frontier_travel_preference(node,name,a,fields)
         resume=c.interrupted_frontier_is_useful(a,f.get('resume_intent'),1.)
         factor=preference['factor']*preference.get('mission_spatial_diversity',{}).get('factor',1.)
         score=c.frontier_scheduling_score(utility*factor,resume)
         rows.append(dict(target=[a.x,a.y],gain=a.viewpoint.information_gain,group_size=a.viewpoint.group_size,required_energy=cost,planned_distance_m=distance,score=score,resume=resume))
     results.append(dict(radius=radius,stats=stats,funded_body_route_candidates=len(rows),best=sorted(rows,key=lambda r:-r['score'])[:5]))
 finally:c.VIEWPOINT_SEARCH_RADIUS_M=original_radius
 outputs.append(dict(event_time=event['event_time'],robot=name,current_position=event['current_position'],original_target=f['target'],results=results))
Path('log/p2c_v25_radius_fixed_input.json').write_text(json.dumps(fixtures,indent=2)+'\n')
out=dict(status='PASS',scope='Five unchanged original mapping decisions. In-memory frontier radius trials; complete known body paths and funded budgets, without original in-flight reservations. Conditional candidates, not task/causal benefit.',decisions=outputs)
Path('log/p2c_v25_radius_fixed_diagnostic.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
