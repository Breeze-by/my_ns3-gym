import base64,json,math,zlib
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from multi_robot_exploration import control as c

path=next(Path('log/p2c/20261009_p2c_v25').glob('*/ledger.jsonl'))
event=[e for line in path.open() if (e:=json.loads(line)).get('event')=='coordinator_navigation_decision' and e.get('kind')=='initial_visual_search'][2]
fixture=Path('log/p2c_v25_competition_input_2.json');assert not fixture.exists();fixture.write_text(json.dumps(event,indent=2)+'\n')
def decode(s):return dict(data=np.frombuffer(zlib.decompress(base64.b64decode(s['grid'])),dtype='<i2').reshape(s['shape']),resolution=s['resolution'],origin=s['origin'])
maps={key:decode(s) for key,s in [('planning',event['planning_map']),('source',event['source_map']),*event['return_maps'].items()]}
g=maps['planning'];states=event['battery_states'];f=event['travel_preference'];name=event['robot'];visits=f['initial_search_visits']
node=SimpleNamespace(enable_battery=True,enable_rally=True,now=lambda:event['event_time'],map_data=g['data'],resolution=g['resolution'],origin=g['origin'],
    map_received_at=event['planning_map']['source_time'],source_map_data=maps['source']['data'],map_self_return_cells=event['self_return_cells'],
    robot_positions=event['robot_positions'],battery_states=states,battery_modes={n:s['mode'] for n,s in states.items()},
    robot_maps={n:maps[n] for n in event['return_maps']},robot_map_received_at={n:s['source_time'] for n,s in event['return_maps'].items()},
    robot_odom_received_at={n:event['inputs'][n+'/pose_state']['source_time'] for n in f['eligible_robot_names']},
    robot_tf_received_at={n:event['inputs'][n+'/frame_state']['source_time'] for n in f['eligible_robot_names']},initial_search_visits={i:v for i,v in enumerate(visits)})
mask=c.traversable_grid(g['data'],g['resolution'],c.PATH_CLEARANCE_M)
fields={n:c.exploration_distance_field(g['data'],mask,g['resolution'],g['origin'],event['robot_positions'][n]) for n in f['eligible_robot_names']}
blocked=[p for n,p in event['robot_positions'].items() if n!=name and p is not None]
actual=c.exploration_distance_field(g['data'],c.block_dynamic_positions(mask,g['resolution'],g['origin'],blocked),g['resolution'],g['origin'],event['current_position'])
rows=[];routes={}
known=c.known_space_search_candidates(g['data'],g['resolution'],g['origin'],name,event['current_position'],
        [*[v['position'] for v in visits],*[p for p in event['robot_positions'].values() if p is not None]],f['excluded_targets'],blocked,face_interest=True)
frontiers,_=c.robot_candidate_assignments(g['data'],g['resolution'],g['origin'],name,event['current_position'],f['excluded_targets'],blocked_positions=blocked)
for kind,pool in (('known_space',known),('mapping',frontiers)):
 for utility,n,group,a in pool:
    cell=c.world_to_grid(a.x,a.y,g['resolution'],*g['origin']);distance=float(actual[cell])
    if not math.isfinite(distance):continue
    cost=c.HeadquartersControl.exploration_required_energy(node,name,distance,(a.x,a.y))
    plan=c.plan_rally_leg(c.RallyPose(a.x,a.y,a.navigation_yaw or 0.),g['data'],g['resolution'],g['origin'],event['current_position'],
        c.MAX_NAVIGATION_LEG_M,blocked_positions=blocked,clearance_m=c.PATH_CLEARANCE_M,visible_only=True,route_cache=routes)
    if cost is None or cost>=states[name]['energy'] or plan is None or plan[0] is None:continue
    preference=c.HeadquartersControl.frontier_travel_preference(node,name,a,fields)
    resume=c.interrupted_frontier_is_useful(a,f.get('resume_intent'),1.)
    factor=preference['factor']*preference.get('mission_spatial_diversity',{}).get('factor',1.)
    score=c.frontier_scheduling_score(utility*factor,resume)
    common=c.exploration_utility(a.viewpoint.information_gain,a.viewpoint.group_size,a.path_distance_m)
    rows.append(dict(kind=kind,target=[a.x,a.y],gain=a.viewpoint.information_gain,required_energy=cost,planned_distance_m=distance,
        original_score=score,shared_score=c.frontier_scheduling_score(common*factor,resume),factor=factor))
assert rows
out=dict(status='PASS',scope='Saved first actual visual-search decision, current delivered grids/models/exclusions/body paths; missing original in-flight route reservations. Conditional ranking, no original-task counterfactual.',
    event_time=event['event_time'],current_position=event['current_position'],current_energy=states[name]['energy'],original_selected=f['target'],
    visits=len(visits),funded_body_route_candidates=len(rows),
    original_known_only=sorted([r for r in rows if r['kind']=='known_space'],key=lambda r:-r['original_score'])[:4],
    shared_pool=sorted(rows,key=lambda r:-r['shared_score'])[:4])
Path('log/p2c_v25_competition_diagnostic_2.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
