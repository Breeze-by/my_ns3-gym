import gzip,hashlib,json,re,statistics,subprocess
from pathlib import Path

root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
parent='0972eec6561b92efb55b195a07b0716d3aca114b'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py'
comparison=load(r/'log/p2c_v33_lookup_comparison.json');assert comparison['status']=='PASS' and comparison['control_sha256']==sha(control)
source=load(r/'log/p2c_v33_source.json');assert source['status']=='PASS'
runtime={key:load(r/'log'/name) for key,name in [('clock','p2c_v33_clock_runtime.json'),('native_future','p2c_v33_native_future_runtime.json'),('visual','p2c_v33_visual_runtime.json')]}
assert all(v['status']=='PASS' for v in runtime.values())
assert runtime['clock']['control_sha256']==runtime['visual']['control_sha256']==sha(control)
full=re.search(r'(\d+) passed in ([\d.]+)s',(r/'log/p2c_v33_full_components.log').read_text());assert full and int(full[1])==1280
build=re.search(r'4 packages finished \[([\d.]+)s\]',(r/'log/p2c_v33_build.log').read_text());assert build
for saved,name in [('p2c_v33_manifest.json','p2c_integration_manifest.json'),('p2c_v33_blackout_manifest.json','p2c_blackout_manifest.json')]:
    current=load(r/'scripts'/name);assert load(r/'log'/saved)['config']==current
    old=json.loads(subprocess.check_output(['git','show',parent+':'+str((r/'scripts'/name).relative_to(root))],cwd=root))
    for key in ('cases','duration_sec','coverage_threshold','fault_seed','owner_shutdown_timeout_sec'):
        assert old[key]==current[key],key
old=load(r/'log/p2c_v32_independent_audits.json');reaudit=load(r/'log/p2c_v33_previous_original_audits.json')
for name,data in reaudit['dev_forced2'].items():assert data['status']==old['dev_forced2'][name]['status']=='PASS'
unchanged={}
for rel in ('src/multi_robot_exploration/multi_robot_exploration/battery_manager.py','src/multi_robot_exploration/multi_robot_exploration/action_callbacks.py',
    'src/multi_robot_exploration/multi_robot_exploration/tf_ingress_sampler.py','src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py',
    'scripts/observe_p3b5.py','scripts/p2c_native_graph.py','scripts/check_p2c_gate.py','scripts/ros_smoke_test.py','scripts/check_p2c_visual_runtime.py'):
    p=r/rel;before=subprocess.check_output(['git','show',parent+':'+str(p.relative_to(root))],cwd=root)
    assert before==p.read_bytes();unchanged[rel]=sha(p)
files=[p for p in (r/'log').glob('*p2c_v33*') if p.is_file() and p.suffix!='.pyc']
files.append(r/'src/multi_robot_exploration/test/fixtures/p2c_v31_visual_computation.json')
destination=report/'20261009_p2c_lazy_priority_artifacts';destination.mkdir();artifacts=[]
for p in sorted(set(files)):
    q=destination/('__'.join(p.relative_to(r).parts)+'.gz');q.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0))
    assert gzip.decompress(q.read_bytes())==p.read_bytes()
    artifacts.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(q.relative_to(report)),archive_sha256=sha(q)))
timing=comparison['timing'];before=statistics.median(timing['frozen_v32']['cold_wall_sec']);after=statistics.median(timing['candidate_v33']['cold_wall_sec'])
output=dict(status='PASS',scope='Prospective exact lazy scoring components; no mission acceptance',parent_commit=parent,
    control_sha256=sha(control),functional_checks=int(full[1]),functional_wall_sec=float(full[2]),build_wall_sec=float(build[1]),
    directed_checks=116,additional_bound_and_expiry_checks=26,source_audit=source,actual_ros=runtime,
    fixed_source_comparison=comparison,previous_original_reaudit=reaudit,unchanged_from_parent=unchanged,
    preparation_errors=['First helper patch had no matching old signature; tool rejected before edit.',
        'First central transform assertion failed before file write; corrected newline index, no task.',
        'First directed command misspelled existing test_exploration_charging.py; pytest exit4/no tests, corrected.',
        'First archive preparation read a nonexistent lazy_comparison.json; actual lookup_comparison.json name corrected before writes.'],
    unrun=['new4 development','new17 formal','new2 physical','917'],
    limits='Bounded score proof applies to fixed candidate/source values. Actual budgets still use true current clock. No CPU worst-case, task improvement, hidden-state AP input, extra application traffic or Wi-Fi bottleneck claim.',artifacts=artifacts)
(report/'20261009_p2c_lazy_priority_components.json').write_text(json.dumps(output,indent=2)+'\n')
note=f'2026-10-09 P2C.1 v33原优先级惰性核验组件PASS待新冻结：0972 v32首强制300.0EXPLOREtimeout/6nav/两机各charge1/125原lease弃置(96budget)，strict FAIL原件保留，余3/17/2/917未调用。新lazy heap使用原utility与可能2x接续上界，只有完成原budget/relative/diversity评分并超过全部未核验上界后才进入原route/body/full-budget；稳定tie、充电完整raw lookahead池与原TTL保持，后续过期撤销全部暂定计划。1280功能/四包{float(build[1]):.2f}s/171保护4授权54协议/实际ROS PASS。固定后期交付样本预算90→2、cold中位{before:.3f}→{after:.3f}s且导航/偏好/预算证据相同，非真实回放或最坏界。新4→17+2同clean pushed freeze仍待验证；917未暴露，P3C.5已验收，无P4/ns-3/Wi-Fi/RL。报告20261009_p2c_lazy_priority_components.md与20261009_p2c_v32_failed_development.md。'
(report/'20261009_p2c_lazy_priority_components.md').write_text(f'''# P2C.1 v33 原优先级惰性核验组件 PASS

v32第一强制原任务在冻结0972下EXPLORE timeout300.0秒，六个实际Nav2 goal、两机各充电一次、零接触/耗尽/failed机器人；strict FAIL、125次原lease弃置（96次预算阶段）完整保留。其余3开发/17正式/2物理/917均未运行。全部owned关闭后才编辑。

新增一个纯heap迭代器，只修改中央assign_idle_robots候选评分执行顺序：原utility和满足当前接续几何/信息门限时的最多2x倍率作上界；原电池完整路线因子、相对同伴旅行因子、历史空间分散因子均不大于1。未评分候选保留上界，已评分候选按真实分数重新入heap；只有其真实分数高于所有未评分上界时才送入原greedy路线核验。原输入索引保留稳定tie顺序。已暂定选择机器人的其他候选不再价格计算（原route循环同样跳过）；每台原始候选全集仍保留给原充电lookahead。未负担候选仍检查可行充电意图，不能因未计算预算而获准行动。

原生成/每次预算/路线/派发都使用真实clock与原source TTL；后续lazy评分过期会撤销先前暂定计划，不留下导航、charge请求或live owner。原完整body/在途预约/已知往返预算保持。非有限上界、非有限分数或超过声明上界直接失败，未核验动作不会yield。诊断candidate_assignments现为已评分数，generated_candidate_assignments为生成总数；不改变实际任务与原native300秒/.35m/.05mps/.1radps/5秒。

十二随机种子的200候选全量惰性顺序与完整稳定排序逐项相同（含tie、跳过、倍率与分数降低）。高优先级早停不计算无用低分候选；分数降低必须先核验竞争上界；非法界失败。实际后期212×253交付map/14相机历史、eligible tb2/pending tb1的五cold固定条件计算中位{before:.5f}→{after:.5f}秒，预算调用90→2，所有导航点/旅行偏好/预算证据相同；这不代表实际callback延迟、任务因果收益或最坏时界。

116定向PASS5.48秒，追加边界与后续过期撤销26PASS1.36秒；最终1280功能PASS{float(full[2]):.2f}秒，四包{float(build[1]):.2f}秒，171保护/4授权/54静态协议/8+2 Future注册、两清单原case和刺激同父版本PASS。实际隔离ROS DDS clock/中央state串行、真实native Future、原视场20数值/79候选/发布消费、camera/survey/quiet/lapsed均绑定最终source PASS。Native battery、共享Future helper、TF sampler、launch、观察器、严格checker/result读者、视场validator相对0972字节不变。只读v32原始十二子门仍PASS、strict任务仍FAIL，不回填。

首helper patch签名不匹配被拒；首中央转换newline索引assert在write前失败；首定向命令拼错test文件pytest exit4无测试。归档首读取错comparison文件名在任何write前失败，改为实际lookup_comparison.json。均为准备错误，无新原任务；修正后完整证据及命令保留。

组件PASS，P2C.1未完成。新4开发→17正式+2物理需要同一clean pushed freeze；首先强制双机真实native完成且各charge≥1。917未暴露；P3C.5已验收，无P4/ns-3/Wi-Fi/RL。
''')
for p in (w/'AGENTS.md',w/'RESEARCH_PLAN.md',w/'IMPLEMENTATION_PLAN.md',r/'user_guide.md',r/'launch_commands.md'):
    first,rest=p.read_text().split('\n',1);p.write_text(first+'\n\n'+note+'\n'+rest)
p=root/'AGENTS.md';p.write_text(p.read_text().replace('## Current Handoff\n','## Current Handoff\n\n'+note+'\n',1))
with (w/'log.md').open('a') as f:
    f.write('\n\n## 2026-10-09 P2C.1 v33 原候选优先级惰性核验\n\n'+note+'\n\n')
    f.write('Humble+install/PYTHONNOUSERSITE=1、FastDDS UDPv4清旧profiles；首helper patch旧签名不匹配被拒、central脚本split newline index assert在write前exit1、首pytest命令错test_exploration_charge.py exit4无测试，归档首读错lazy_comparison.json exit1于write前，改实际lookup_comparison.json；改正确charging.py后116PASS5.48s，新增bound/expiry26PASS1.36s；完整pytest src/multi_robot_exploration/test scripts三lint ignore1280PASS73.37s。compare_p2c_v33_lazy.py独立编译0972原central、固定v31后期交付map/epoch，五cold选择/偏好/预算相同，调用90→2；cold约.625→.317秒，无真实Nav2/因果/最坏界。\n\n')
    f.write(f'colcon build四包{float(build[1]):.2f}s；check_p2c_source.py --output log/p2c_v33_source.json171/4/54/8+2 PASS；run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v33 --domain210 --gazebo-port20290 --validate-only与physical_fault --manifest scripts/p2c_blackout_manifest.json --run-id 20261009_p2c_v33_physical --domain219 --gazebo-port20299 --validate-only PASS。ROS_DOMAIN_ID220 check_p2c_clock_runtime.py --output log/p2c_v33_clock_runtime.json、221 check_p2c_native_future_runtime.py --output log/p2c_v33_native_future_runtime.json、215 check_p2c_visual_runtime.py --output log/p2c_v33_visual_runtime.json均PASS绑定最终bytes；audit_p2c_v33_previous_originals.py只读v32十二子门仍PASS，任务FAIL保留。新4/17/2/917未启动，commit/push exit0后独立clean freeze再首强制；不续租/降低native或物理门限、不回填失败、domain222/master11345未操作。\n')
print(json.dumps(dict(status='PASS',functional_checks=int(full[1]),archives=len(artifacts),before=before,after=after,control_sha256=sha(control))))
