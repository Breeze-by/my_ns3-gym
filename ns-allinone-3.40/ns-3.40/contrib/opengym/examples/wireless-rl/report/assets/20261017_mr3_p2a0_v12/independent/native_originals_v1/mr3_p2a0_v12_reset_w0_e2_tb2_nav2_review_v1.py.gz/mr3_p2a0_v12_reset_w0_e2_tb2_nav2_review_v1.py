"""Read-only logs/config/input inventory. No ROS calls, simulator or controller replay."""
import collections
import datetime
import hashlib
import json
from pathlib import Path
import re
import urllib.request
import xml.etree.ElementTree as ET

import yaml

ROOT = Path('/home/zhuyulab/ns3-workspace')
ROS = ROOT / 'ros2_ws/ros2-multi-robot-automap'
EP = ROS / 'log/mr3_p2a0/mr3_p2a0_20261017_v12_reset/worker0/episode002_open_101'
OUT = Path('/tmp/mr3_p2a0_v12_reset_w0_e2_tb2_nav2_review_v1.json')
SELECTED = Path('/tmp/mr3_p2a0_v12_reset_w0_e2_tb2_nav2_review_originals_v1')
SELECTED.mkdir(exist_ok=False)
FREEZE = '6b1b4a0108351f5bfb70ec0c96ba895248d4f7a8'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


proof = {}


def capture(path, selected=None):
    path = Path(path)
    raw = path.read_bytes()
    proof[str(path)] = {'sha256': sha(raw), 'bytes': len(raw)}
    if selected:
        destination = SELECTED / selected
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open('xb') as stream:
            stream.write(raw)
    return raw


metadata = json.loads(capture(EP / 'metadata.json'))
assert metadata['freeze'] == FREEZE
launch = capture(EP / 'launch.log').decode()
adapter = [json.loads(line) for line in capture(EP / 'adapter.jsonl').splitlines()]
processes = []
for line in launch.splitlines():
    marker = 'MR3_ORDERED_SHUTDOWN '
    if marker not in line:
        continue
    row = json.loads(line.split(marker, 1)[1])
    if row.get('event') == 'process_started' and '__ns:=/tb2' in row.get('argv', []):
        processes.append(row)
node_names = ('controller_server', 'planner_server', 'behavior_server',
              'bt_navigator', 'velocity_smoother')
node_logs, arguments = {}, {}
for process in processes:
    name = Path(process['argv'][0]).name
    if name not in node_names:
        continue
    argv = process['argv']
    arguments[name] = {'pid': process['pid'], 'argv': argv}
    node_logs[name] = []
    for path in sorted(Path('/home/zhuyulab/.ros/log').glob('*_' + str(process['pid']) + '_*.log')):
        raw = capture(path, 'rclcpp_logs/' + path.name)
        node_logs[name].append({'path': str(path), 'sha256': sha(raw), 'bytes': len(raw),
                               'text': raw.decode(errors='replace')})
params_path = Path(arguments['controller_server']['argv'][
    arguments['controller_server']['argv'].index('--params-file') + 1])
params = yaml.safe_load(capture(params_path, 'actual_tb2_controller_argv_params.yaml'))
active = params['/tb2']
source_path = ROS / 'src/multi_robot/params/nav2_params_tb2_0.yaml'
canonical = yaml.safe_load(capture(source_path, 'canonical_nav2_params_tb2_0.yaml'))
controller = active['controller_server']['ros__parameters']
assert controller == canonical['controller_server']['ros__parameters']
interface = json.loads(capture(ROS / ('log/mr3_p2a0/mr3_p2a0_20261017_v12_interface/'
                                     'worker0/episode001_open_101/actual_nav2_parameters.json')))
assert interface['passed'] is True and interface['freeze'] == FREEZE
logs = [line for line in launch.splitlines()
        if any('[' + 'tb2.' + node + ']' in line for node in node_names)]
warning_lines = [line for line in logs if '[WARN]' in line]
error_lines = [line for line in logs if '[ERROR]' in line or '[FATAL]' in line]
goal_lifecycle = []
for index, row in enumerate(adapter, 1):
    value = row['payload']
    wanted = (row['kind'] in ('native_send', 'native_cancel', 'protocol')
              and value.get('robot') == 'tb2')
    if row['kind'] == 'delivery':
        envelope = value
        value = envelope.get('payload', {})
        wanted = (envelope.get('stream') == 'receipt' and value.get('robot') == 'tb2')
    if wanted:
        goal_lifecycle.append({'line': index, 'row': row})
versions = {}
for package in ('dwb_core', 'dwb_plugins', 'dwb_critics', 'nav2_controller',
                'nav2_velocity_smoother', 'nav2_rotation_shim_controller'):
    path = Path('/opt/ros/humble/share') / package / 'package.xml'
    if path.exists():
        versions[package] = ET.fromstring(capture(path)).findtext('version')
header = Path('/opt/ros/humble/include/dwb_plugins/one_d_velocity_iterator.hpp')
capture(header, 'installed_one_d_velocity_iterator.hpp')
publisher_header = Path('/opt/ros/humble/include/dwb_core/publisher.hpp')
capture(publisher_header, 'installed_dwb_publisher.hpp')
base_url = 'https://raw.githubusercontent.com/ros-navigation/navigation2/1.1.20/'
primary = []
paths = [
    'nav2_dwb_controller/dwb_plugins/include/dwb_plugins/one_d_velocity_iterator.hpp',
    'nav2_dwb_controller/dwb_plugins/src/standard_traj_generator.cpp',
    'nav2_dwb_controller/dwb_plugins/src/xy_theta_iterator.cpp',
    'nav2_dwb_controller/dwb_core/src/dwb_local_planner.cpp',
    'nav2_dwb_controller/dwb_core/src/publisher.cpp',
    'nav2_dwb_controller/dwb_critics/src/rotate_to_goal.cpp',
    'nav2_controller/src/controller_server.cpp',
    'nav2_velocity_smoother/src/velocity_smoother.cpp',
]
for relative in paths:
    url = base_url + relative
    raw = urllib.request.urlopen(url, timeout=20).read()
    destination = SELECTED / 'upstream_1_1_20' / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open('xb') as stream:
        stream.write(raw)
    primary.append({'url': url, 'selected': str(destination), 'sha256': sha(raw),
                    'scope': 'version-matched official upstream source; not a claim of '
                             'whole installed .so binary equality'})
assert (SELECTED / 'upstream_1_1_20' / paths[0]).read_bytes() == header.read_bytes()
received = [entry['row']['payload']['payload'] for entry in goal_lifecycle
            if entry['row']['kind'] == 'delivery']
report = {
    'schema': 'mr3-nav2-stall-source-inventory-v1', 'observation_complete': True,
    'unique_critic_cause_proven': False, 'freeze': FREEZE, 'epoch': metadata['epoch'],
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Read-only closed-episode log/config/input inventory. No native/ROS/GPU run, '
             'no new controller evaluation, no source/parameter changes or gate relaxation.',
    'node_logs': node_logs, 'actual_process_arguments': arguments,
    'tb2_nav2_launch_warning_lines': warning_lines,
    'tb2_nav2_launch_error_or_fatal_lines': error_lines,
    'diagnostic_logging_limits': {'actual_log_level': 'warn',
                                 'FollowPath.debug_trajectory_details': False,
                                 'no_original_critic_scores_or_plan_publication_archive': True},
    'actual_temp_parameter_capture': {'path': str(params_path),
        'scope': 'Input file named by actual closed-process argv, still present when read; '
                 'controller section equals frozen canonical source. Not a new e2 GetParameters call.'},
    'active_controller_parameters': controller,
    'same_freeze_actual_nine_node_readback': {'path': interface['episode_directory'],
        'passed': interface['passed'], 'epoch': interface['epoch'], 'nodes': interface['nodes'],
        'scope': 'Actual interface-phase nine-node query; not incorrectly relabeled as reset-e2 readback'},
    'installed_versions': versions, 'goal_lifecycle': goal_lifecycle,
    'actual_goal_receipt_counts': dict(collections.Counter((v.get('type'), str(v.get('value')))
                                                         for v in received)),
    'confirmed_findings': [
        'Two accepted tb2 native goals were later deliberately cancelled by WAIT; both terminal '
        'results are CANCELED. No ABORTED/FAILED controller result is saved for these goals.',
        'The independent rclcpp planner/behavior/BT/smoother files are empty. Controller file '
        'contains only the matching once-only default goal-checker selection warning.',
        'Controller frequency is10Hz, DWB horizon1.2s, vx/vtheta samples20, v range0..0.26, '
        'theta range-0.8..0.8, min_speed_theta0; progress radius0.15m/time15s. OPEN_LOOP smoother20Hz.',
        'Installed exact OneDVelocityIterator matches official1.1.20 header and inserts exact0 '
        'when a sample interval crosses zero. An even20 theta grid does not remove zero. '
        'Observed±0.0421053 is consistent with the closest nonzero full-range grid samples, '
        'but does not identify the rejecting/scoring critic.',
    ],
    'inferences_not_proofs': [
        'The two commands lasted10s and15s before intentional cancellation. This alone does not '
        'establish a missed15s progress-checker abort or a progress-checker implementation fault.',
        'The late stalled guard input is after the smoother. Without cmd_vel_nav original bytes, '
        'the exact pre-smoother/controller command cannot be reconstructed from it alone.',
        'No original per-critic evaluation/internal state establishes RotateToGoal, PathAlign, '
        'GoalAlign or any other particular critic as the unique cause.',
    ],
    'saved_inputs': [
        'Accepted map-frame goal XY/yaw/IDs, received accept/cancel/result receipts and sim stamps.',
        'Full raw own odometry and map->odom samples with source/receipt clocks; actual guard '
        'requests/outputs and stored driver target provenance.',
        'Published full local/global master costmaps at recorded publication times; candidate '
        'agent separately verified48 task maps and their current-seed/goal/free connectivity.',
        'Actual launch parameter input file, frozen canonical controller configuration, installed '
        'version/header identities and the interface actual9-node parameter query.',
    ],
    'missing_for_unique_original_dwb_replay': [
        'Exact controller-received global plan and each setPlan/reset occurrence; a newly '
        'computed BFS/path is counterfactual and cannot replace this missing original.',
        'Original transformed/pruned global plan, selected local plan, LocalPlanEvaluation '
        'and per-trajectory critic scores/rejection evidence.',
        'Original cmd_vel_nav before smoothing; Nav2 controller/behavior publisher identity '
        'and callback order must be distinguished from post-smoother requests.',
        'Exact pose, thresholded current velocity, internal master-costmap generation and '
        'critic history consumed at each controller call. Published costmap snapshots and '
        'sensor samples do not identify every10Hz in-process consumption tuple.',
    ],
    'minimum_new_passive_observation': [
        {'topic': '/tbN/cmd_vel_nav', 'type': 'geometry_msgs/msg/Twist',
         'purpose': 'Bind original pre-smoother requests/graph identity/source and receipt clock.'},
        {'topic': '/tbN/received_global_plan', 'type': 'nav_msgs/msg/Path',
         'purpose': 'Actual DWB setPlan input, not a re-created planner result.'},
        {'topic': '/tbN/transformed_global_plan', 'type': 'nav_msgs/msg/Path',
         'purpose': 'Actual transformed/pruned path used for critic preparation.'},
        {'topic': '/tbN/local_plan', 'type': 'nav_msgs/msg/Path',
         'purpose': 'Selected trajectory geometry.'},
        {'topic': '/tbN/evaluation', 'type': 'dwb_msgs/msg/LocalPlanEvaluation',
         'purpose': 'Real scored trajectories and best_index; existing publish_evaluation '
                    'defaultTrue plus a real subscriber activates recording. debug_trajectory_details '
                    'is a separate logging option; short-circuit nonwinning scores may be partial.'},
    ],
    'general_repair_options_conditional_on_new_evidence': [
        'First add passive native observability and replay the exact installed DWB library only '
        'when original plan/pose/velocity/costmap/critic state is adequately identified. Otherwise '
        'label real-library free-space/behind-goal fixtures as bounded counterfactual CPU models.',
        'If actual scores prove a path-heading alignment stall, an installed Nav2 rotation-shim '
        'controller is a mature local-controller mechanism to assess under the same received path '
        'and unchanged final safety/actuator bounds; this is not yet an evidence-backed chosen fix.',
        'Do not infer missing zero samples, blindly change critic weights/switch RPP, replace '
        'the original route by a new BFS, relax the0.05m activity gate, or call this a PPO failure.',
    ],
    'primary_sources': primary, 'input_proof': proof,
}
# JSON object keys must be strings; retain type/value counts as explicit entries.
report['actual_goal_receipt_counts'] = [
    {'type': key[0], 'value': key[1], 'count': count}
    for key, count in collections.Counter((v.get('type'), str(v.get('value')))
                                          for v in received).items()]
report['all_captured_inputs_unchanged'] = all(
    sha(Path(path).read_bytes()) == entry['sha256'] for path, entry in proof.items())
with OUT.open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({'output': str(OUT), 'unique_critic_cause_proven': False,
                  'all_captured_inputs_unchanged': report['all_captured_inputs_unchanged'],
                  'receipt_counts': report['actual_goal_receipt_counts']}))
