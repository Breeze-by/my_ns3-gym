import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path

OUT = Path(__file__).parent
ENDPOINT = Path('/tmp/mr3_p2a0_v19_endpoint_pose_diagnostic_v1/diagnostic_v1.py')
EXPECTED_ENDPOINT = 'e5e75f14be7c6f727bc5acae0a46779d1581ef1b55553596dce6db0167188f3f'
assert hashlib.sha256(ENDPOINT.read_bytes()).hexdigest() == EXPECTED_ENDPOINT
spec = importlib.util.spec_from_file_location('sealed_endpoint', ENDPOINT)
BASE = importlib.util.module_from_spec(spec)
spec.loader.exec_module(BASE)
TARGETS = [200000000, 400000000, 600000000, 1000000000, 2000000000, 3000000000]


def ref(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': BASE.sha(raw)}


def ray_prediction(sample):
    q = sample['base']['world_pose']['quaternion_wxyz']
    p = sample['base']['world_pose']['position_xyz']
    offset = BASE.rotate(q, [-0.064, 0., 0.121])
    origin = [a+b for a,b in zip(p,offset)]
    x = BASE.rotate(q,[1.,0.,0.]);y=BASE.rotate(q,[0.,1.,0.])
    down = math.hypot(x[2],y[2])
    return {'origin_xyz':origin,'max_downward_ray_vertical_unit':down,
            'min_z_at_declared10m_range':origin[2]-10*down,
            'ground_intersection_range_m':origin[2]/down if down else None,
            'scope':'Source-declared rigid ray frame prediction from base pose, not actual scan or observed base_scan pose.'}


def main():
    results=[]
    for stage in ('baseline','iters150'):
        formal_path=Path('/tmp/mr3_p2a0_v19_'+stage+'_observer_review.json')
        formal=json.loads(formal_path.read_bytes())
        assert formal['passed'] is True and formal['consumer_sha256']=='e61ce4e00907ab35e196f7abe9fadfd9da099af3542f98dc773d593c33ca2b65'
        manifest_path=Path('/tmp/mr3_p2a0_v19_selected_native_v1')/stage/'manifest.json'
        manifest=json.loads(manifest_path.read_bytes())
        inventory={row['source']:row for row in manifest['files']}
        for robot in ('tb1','tb2','tb3'):
            path=Path(formal['episode_directory'])/('physics_'+robot+'.jsonl')
            evidence=formal['inputs'][str(path)];stored=inventory[str(path)]
            assert evidence['sha256']==stored['raw_sha256']==evidence['decoded_sha256']
            assert evidence['bytes']==stored['raw_bytes']
            before=BASE.identity(path.stat())
            assert before==stored['source_stat_final']
            selected={};samples=[]
            with path.open('rb',buffering=0) as stream:
                assert BASE.identity(os.fstat(stream.fileno()))==before
                reader=BASE.BoundedReader(stream)
                config_raw=reader.line();config=json.loads(config_raw)
                first=[]
                for _ in range(2):
                    offset=stream.tell();raw=reader.line();row=json.loads(raw)
                    first.append(row);selected[offset]=(raw,row)
                assert {row['phase'] for row in first}=={BASE.PRE,BASE.POST}
                assert first[0]['sim_time_ns']==first[1]['sim_time_ns']
                assert first[0]['pair_sequence']==first[1]['pair_sequence']==1
                samples.append({'name':'first_pair','clock_ns':first[0]['sim_time_ns'],
                                'available':True,'samples':[BASE.derive(row) for row in first]})
                for clock in TARGETS:
                    if clock<first[0]['sim_time_ns']:
                        samples.append({'name':'fixed_startup_clock','clock_ns':clock,'available':False,
                                        'reason':'clock_before_observer_first_pair',
                                        'first_pair_clock_ns':first[0]['sim_time_ns']})
                        continue
                    located,seek=reader.locate(clock-1000000,evidence['bytes'])
                    exact=[(offset,raw,row) for offset,raw,row in located if row['sim_time_ns']==clock]
                    assert len(exact)==2 and {row['phase'] for _,_,row in exact}=={BASE.PRE,BASE.POST}
                    assert exact[0][2]['pair_sequence']==exact[1][2]['pair_sequence']
                    assert exact[0][2]['record_sequence']+1==exact[1][2]['record_sequence']
                    for offset,raw,row in exact: selected[offset]=(raw,row)
                    samples.append({'name':'fixed_startup_clock','clock_ns':clock,
                                    'available':True,'seek':seek,
                                    'samples':[BASE.derive(row) for _,_,row in exact]})
                after_fd=BASE.identity(os.fstat(stream.fileno()))
                io={'read_bytes_including_seek_probes':reader.read_bytes,'readline_calls':reader.readline_calls,
                    'seek_calls':reader.seek_calls,'whole_raw_rescan':False}
            after=BASE.identity(path.stat());assert before==after_fd==after
            for sample in samples:
                if sample['available']:
                    for item in sample['samples']:
                        item['declared_ray_frame_prediction']=ray_prediction(item)
            chosen_path=OUT/(stage+'_'+robot+'_selected_rows.jsonl')
            chosen_path.write_bytes(b''.join(selected[offset][0] for offset in sorted(selected)))
            config_path=OUT/(stage+'_'+robot+'_configuration.jsonl');config_path.write_bytes(config_raw)
            results.append({'stage':stage,'robot':robot,'epoch':formal['epoch'],
                            'formal':ref(formal_path),'custody_manifest':ref(manifest_path),
                            'source':str(path),'full_raw_sha256':evidence['sha256'],
                            'full_raw_sha_scope':'Inherited completed e61c and custody proof, not rehashed by this bounded extraction.',
                            'full_raw_bytes':evidence['bytes'],'stat_before_fd_and_path':before,
                            'stat_after_fd':after_fd,'stat_after_path':after,
                            'configuration':ref(config_path),'configuration_clock_ns':config['sim_time_ns'],
                            'selected':ref(chosen_path),
                            'selected_rows':[{'offset_bytes':offset,'raw_bytes_including_newline':len(selected[offset][0]),
                                              'raw_sha256':BASE.sha(selected[offset][0]),
                                              'record_sequence':selected[offset][1]['record_sequence'],
                                              'clock_ns':selected[offset][1]['sim_time_ns'],
                                              'phase':selected[offset][1]['phase']} for offset in sorted(selected)],
                            'io':io,'samples':samples})
    report={'schema':'mr3-v19-bounded-startup-pose-description-v1','passed':True,
            'pass_scope':'Extraction/provenance only; no formal physical, sensor causality or matrix credit.',
            'fixed_clock_targets_ns':TARGETS,'results':results,
            'total_large_raw_bytes_read':sum(row['io']['read_bytes_including_seek_probes'] for row in results),
            'endpoint_helper':ref(ENDPOINT),
            'limitations':['Records before each observer/model birth are explicitly unavailable.',
                           'These fixed samples do not measure all startup extrema or actual scans.',
                           'Sensor prediction assumes the source-declared rigid sensor transform; base_scan pose itself not captured.',
                           'No task/actor/candidate/safety input or gate was changed.']}
    output=OUT/'review_v1.json';output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'review':ref(output),'total_large_raw_bytes_read':report['total_large_raw_bytes_read'],
                      'summary':[{'stage':r['stage'],'robot':r['robot'],'read_bytes':r['io']['read_bytes_including_seek_probes'],
                                  'samples':[{'clock':s['clock_ns'],'available':s['available'],
                                              'post_z':s['samples'][-1]['base']['world_pose']['position_xyz'][2] if s['available'] else None,
                                              'post_rpy_deg':s['samples'][-1]['base']['rpy_degrees'] if s['available'] else None,
                                              'ground_intersection_range_m':s['samples'][-1]['declared_ray_frame_prediction']['ground_intersection_range_m'] if s['available'] else None} for s in r['samples']]} for r in results]},indent=2))


if __name__=='__main__':
    main()
