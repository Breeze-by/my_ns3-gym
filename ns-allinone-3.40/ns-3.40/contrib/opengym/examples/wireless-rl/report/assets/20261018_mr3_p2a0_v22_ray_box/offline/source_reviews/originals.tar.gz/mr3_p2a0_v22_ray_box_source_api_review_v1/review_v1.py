#!/usr/bin/python3
"""Independent readonly source/API review. Does not execute ODE/native tests."""
import hashlib
import json
from pathlib import Path
import time

D = Path('/tmp/mr3_p2a0_v22_ray_box_source_api_review_v1')
S = Path('/tmp/mr3_p2a0_v21_native_box_transform_source_review_v1')
R = Path('/tmp/mr3_p2a0_v22_ray_box_cpu_reproduction_v1')
INPUTS = {}
RAW = {}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def ident(stat):
    return [stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns]


def read(path):
    path = Path(path)
    before = path.stat()
    raw = path.read_bytes()
    assert ident(before) == ident(path.stat())
    INPUTS[str(path)] = {'sha256': sha(raw), 'bytes': len(raw), 'stat': ident(before)}
    RAW[str(path)] = raw
    return raw


def main():
    start = time.monotonic()
    official = json.loads(read(S / 'official_sources_v1.json'))
    primary = {}
    for name in ['ode_ray_11.10.2.cpp', 'ode_collision_kernel_11.10.2.cpp',
                 'ode_collision_kernel_11.10.2.h']:
        raw = read(S / name)
        row, = [row for row in official if row['path'] == str(S / name)]
        assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
        primary[name] = {'url': row['url'], 'sha256': row['sha256']}
    ray = RAW[str(S / 'ode_ray_11.10.2.cpp')].decode()
    kernel = RAW[str(S / 'ode_collision_kernel_11.10.2.cpp')].decode()
    headers = {}
    for name in ['collision.h', 'odemath.h']:
        headers[name] = read('/usr/include/gazebo-11/gazebo/ode/' + name).decode()
    plugin_header = read('/usr/include/gazebo-11/gazebo/common/Plugin.hh').decode()
    multiray_path = Path('/tmp/mr3_p2a0_v20_sensor_ray_geometry_source_review_v1/inputs/ODEMultiRayShape_11.10.2.cc')
    read(multiray_path)
    assert 'if (!_dequal(v[i], 0.0))' in ray
    assert '(s[2] < -h[2] && v[2] <= 0)' in ray
    assert 'if (alpha < 0 || alpha > ray->length) return 0;' in ray
    assert 'const double &_epsilon = 1e-6' in headers['odemath.h']
    assert 'return std::fabs(_a - _b) <= _epsilon;' in headers['odemath.h']
    assert 'colliders[j][i].reverse = 1;' in kernel
    assert 'dIASSERT( colliders_initialized );' in kernel
    assert 'ODE_API void dSetColliderOverride' in headers['collision.h']
    assert '// dlclose(this->dlHandle);' in plugin_header
    exports = read(D / 'exports.stdout').decode()
    read(D / 'exports.stderr')
    packages = read(D / 'package.stdout').decode()
    read(D / 'package.stderr')
    commands = json.loads(read(D / 'commands_v1.json'))
    assert ' dSetColliderOverride' in exports and ' dCollide' in exports
    assert 'dCollideRayBox' not in exports
    assert '11.10.2+dfsg-1' in packages
    library = Path('/lib/x86_64-linux-gnu/libgazebo_ode.so.11')
    lib = read(library)
    assert sha(lib) == 'a94a424df0b3af9d8a04c58ef1562734cc81728253bcedd25c7705330289c258'
    reproduction = json.loads(read(R / 'reproduction_stdout_v1.json'))
    read(R / 'reproduce.cpp')
    read(R / 'compile_execution_v1.json')  # Initial SDK-Werror failure kept.
    read(R / 'compile_execution_v2.json')
    read(R / 'run_execution_v1.json')
    assert len(reproduction['cases']) == 15
    assert reproduction['false_positive_cases'] == 6
    assert reproduction['defect_reproduced'] is True
    assert reproduction['actual_dCollide_library'] == str(library)
    assert reproduction['actual_dSetColliderOverride_library'] == str(library)
    cases = {row['name']: row for row in reproduction['cases']}
    case = cases['above_tiny_negative_1e9']
    assert case['original_ode_contact_count'] == 1 and case['analytic_slab_hit'] is False
    assert cases['above_exact_parallel']['original_ode_contact_count'] == 0
    assert cases['above_tiny_positive']['original_ode_contact_count'] == 0
    assert cases['above_negative_beyond_epsilon']['original_ode_contact_count'] == 0
    assert cases['valid_inside_exit_nearparallel']['original_ode_contact_count'] == 1
    # Static arithmetic interpretation only; no new C++/ODE invocation.
    gap = 0.073 - 0.089 / 2
    entry_t = gap / abs(case['native_normalized_direction'][2])
    assert entry_t > reproduction['max_ray_length']
    findings = [
        {'topic': 'Confirmed source inconsistency',
         'status': 'confirmed source + reviewed actual-library CPU evidence',
         'evidence': 'ray.cpp288-309 mirrors negative local directions, then tests outside/away axes with exact v<=0;319 skips any abs(v)<=1e-6 slab. For a tiny direction toward an outside slab, both conditions discard that slab.333-345 may then accept another axis within finite ray length.',
         'numeric_example': {'source_case': 'above_tiny_negative_1e9',
             'outside_z_gap_m': gap, 'true_z_entry_t': entry_t,
             'finite_ray_length': reproduction['max_ray_length'],
             'false_accepted_depth': case['original_depth']}},
        {'topic': 'Minimum mathematical correction',
         'status': 'recommendation, not an implemented-source or native PASS',
         'evidence': 'Every finite nonzero box-local direction must constrain the slab interval; only exact zero may be treated as parallel. Keep the original finite alpha interval, inside-origin exit convention, face/edge ordering and contact normal/side/g1/g2 contracts. Do not replace this by rejecting all small-angle outside rays.'},
        {'topic': 'True small-angle intersection counterexample requirement',
         'status': 'source-derived test recommendation, not run here',
         'evidence': 'For box265x265x89mm, origin(0,0,hZ+1e-10), direction(0,-1,-1e-9), L9.88, the true z entry is approximately0.1 before y exit0.1325. Preserve the hit and correct first depth/normal using actual normalized binary64 inputs. This prevents an outside-and-tiny blanket MISS from hiding a false-negative regression.'},
        {'topic': 'Ray flags and finite/contact ABI',
         'status': 'confirmed source/header',
         'evidence': 'RayBox257-258 ignores flags/skip and returns at most one hit. Installedcollision.h1075-1081 documents ray flags as currently noticed only by trimesh; preserve Box behavior for FirstContact/BackfaceCull/ClosestHit combinations. dCollide293-337 requires positive contact slots and performs inverse-call normal/g1/g2/side reversal. Register ray-first only; do not double-swap in the override.'},
        {'topic': 'Public dispatch override API',
         'status': 'confirmed local declaration/export/source',
         'evidence': 'collision.h1488-1514 declares dColliderFn/dSetColliderOverride. kernel276-285 writes the ray/box and reverse box/ray entries and requires initialized colliders. Local ELF exports dCollide/dSetColliderOverride but not private dCollideRayBox, so public-ABI direct delegation is unavailable; invoking dCollide inside the override would recurse.'},
        {'topic': 'Registration and code-pointer lifetime',
         'status': 'necessary implementation review boundary',
         'evidence': 'The dispatch table is process-global and its updates are unguarded. Register exactly once after ODE initialization and before any scan/collision thread can dispatch; do not infer thread-safety merely from public API visibility. SDKPlugin.hh87-94 leaves dlclose disabled, supporting process-lifetime callback code, but actual new plugin lifecycle/order remains to be reviewed from its eventual source and admission evidence.'},
        {'topic': 'Geometry and scientific scope',
         'status': 'preserved limitation',
         'evidence': 'The fix must apply to geometric ray-box intersection itself, not filter raw ranges, clear occupancy, ignore all own collisions or change shape/physics/task thresholds. Direct dCollide CPU reproduction establishes the narrowphase defect, not the complete original-world broadphase/cast timing or sole cause of every V21 return. Ray.computeAABB60-92 and Gazebo multiray broadphase/cached-current-pose scopes still exist.'},
    ]
    for path, raw in RAW.items():
        assert Path(path).read_bytes() == raw
        assert ident(Path(path).stat()) == INPUTS[path]['stat']
    output = {'schema': 'mr3-v22-independent-ray-box-source-api-review-v1',
              'passed': True, 'pass_scope': 'Source/API/custody review supports a narrow collider correction; no new build, CPU collision suite, native experiment or physics acceptance.',
              'primary_sources': primary,
              'actual_local_library': {'path': str(library), 'resolved': str(library.resolve()),
                  'bytes': len(lib), 'sha256': sha(lib),
                  'dCollideRayBox_exported': False, 'public_override_exported': True},
              'reviewed_rt_cpu_evidence': {'cases': 15, 'false_positives': 6,
                  'reviewed_only_not_reexecuted': True,
                  'source': str(R / 'reproduction_stdout_v1.json'),
                  'sha256': INPUTS[str(R / 'reproduction_stdout_v1.json')]['sha256']},
              'findings': findings,
              'proposed_required_regression_scope': [
                  'All six frozen false positives -> MISS with actual installed ODE callbacks.',
                  'Inside exits, on-surface/tangent/edge/corner hits, outside entries, finite length just below/at/above depth, true small nonzero-angle entries and all axis/sign permutations.',
                  'Translated and rotated boxes/rays, ray-first and box-first dCollide, reversed normal/g1/g2/side semantics, and all ray flags without adding Box-specific culling.',
                  'Unrelated collision classes unchanged; no own-self/name-based ignore path, new recast or raw-map filtering.',
                  'Actual initialized-before-scan registration, exact new source/ELF/table-admission evidence and fresh same-freeze matrix retain original task/body/physical/coverage gates.'
              ],
              'input_bindings': INPUTS, 'inputs_stable': True,
              'local_symbol_metadata_commands': commands,
              'no_ode_api_calls_by_review': True, 'no_build_native_or_formal': True,
              'source_sha256': sha(Path(__file__).read_bytes()),
              'wall_seconds': time.monotonic() - start,
              'writer_state': 'STOP; future candidate-source review must be a separate version.'}
    destination = D / 'review_v1.json'
    with destination.open('x') as stream:
        json.dump(output, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'passed': True, 'output': str(destination),
                      'sha256': sha(destination.read_bytes()), 'inputs': len(INPUTS),
                      'scope': 'source/API review only'}))


if __name__ == '__main__':
    main()
