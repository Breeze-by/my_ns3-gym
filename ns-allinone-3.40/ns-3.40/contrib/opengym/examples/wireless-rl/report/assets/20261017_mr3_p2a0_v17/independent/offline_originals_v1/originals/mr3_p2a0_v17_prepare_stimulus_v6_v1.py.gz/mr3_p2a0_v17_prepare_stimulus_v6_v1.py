"""Prepare a /tmp-only proposal; canonical files are read only."""
from pathlib import Path
import hashlib
import json

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
P = Path('/tmp/mr3_p2a0_v17_stimulus_v6_proposal')
P.mkdir(exist_ok=False)
sha = lambda value: hashlib.sha256(value).hexdigest()
originals = {}
for name, relative in (('benchmark.py', 'mr3_learning/benchmark.py'),
                       ('audit_preparation.py', 'mr3_learning/audit_preparation.py'),
                       ('test_preparation_comparison.py', 'mr3_learning/tests/test_preparation_comparison.py')):
    raw = (W / relative).read_bytes()
    (P / ('old_' + name)).write_bytes(raw)
    (P / name).write_bytes(raw)
    originals[relative] = sha(raw)

f = P / 'benchmark.py'
s = f.read_text()
s = s.replace('PREPARATION_PROBE_V5 = "mr3-p2a0-outward-cancel-v5"',
              'PREPARATION_PROBE_V5 = "mr3-p2a0-outward-cancel-v5"\n'
              'PREPARATION_PROBE_V6 = "mr3-p2a0-outward-cancel-v6"')
s = s.replace('def probe_action_v4(snapshot, diagnostics, *, nonapproaching_goals=False):',
              'def probe_action_v4(snapshot, diagnostics, *, nonapproaching_goals=False,\n'
              '                    late_goal_window=False):')
s = s.replace('    goal_window = elapsed < 1.5 or 13. <= elapsed < 15.\n',
              '    late_goal = late_goal_window and 15. <= elapsed < 26.\n'
              '    goal_window = elapsed < 1.5 or 13. <= elapsed < 15. or late_goal\n')
s = s.replace('    ranked = probe_action_v3(filtered, diagnostics)\n'
              '    if nonapproaching_goals and goal_window:\n',
              '    if late_goal:\n'
              '        ranked = min((action for action, valid in enumerate(legal) if valid),\n'
              '                     key=lambda action: _probe_goal_order(snapshot, action, True))\n'
              '        diagnostics.setdefault("late_goal_decisions", []).append({\n'
              '            "snapshot_sequence": snapshot.get("sequence"),\n'
              '            "task_elapsed_sec": elapsed, "action": ranked,\n'
              '            "late_goal_window_sec": [15., 26.],\n'
              '            "max_legal_goal_components": sum(choice < 8 for choice in\n'
              '                                              (ranked // 100, ranked // 10 % 10, ranked % 10)),\n'
              '            "original_joint_allowed_actions": sum(valid is True for valid\n'
              '                                                  in snapshot["joint_action_mask"]),\n'
              '            "filtered_stimulus_allowed_actions": sum(legal),\n'
              '            "new_goal_filter": ("received_straight_nonapproach_v1"\n'
              '                                if nonapproaching_goals else None),\n'
              '            "scope": ("external late-window outward ranking on original received time; "\n'
              '                      "counts refer to fixture subset, not actor interface availability; "\n'
              '                      "no reverse preference or actual motion/stop credit"),\n'
              '        })\n'
              '    else:\n'
              '        ranked = probe_action_v3(filtered, diagnostics)\n'
              '    if nonapproaching_goals and goal_window and not late_goal:\n')
old = '\n\ndef _new_preparation_abort():'
assert s.count(old) == 1
s = s.replace(old, '\n\ndef probe_action_v6(snapshot, diagnostics):\n'
              '    """V5 lifecycle with a bounded received-only late new-GOAL opportunity."""\n'
              '    return probe_action_v4(snapshot, diagnostics, nonapproaching_goals=True,\n'
              '                           late_goal_window=True)\n' + old)
s = s.replace('(PREPARATION_PROBE_V3, PREPARATION_PROBE_V4, PREPARATION_PROBE_V5)',
              '(PREPARATION_PROBE_V3, PREPARATION_PROBE_V4, PREPARATION_PROBE_V5, PREPARATION_PROBE_V6)')
s = s.replace('                    probe = (probe_action_v5 if args.preparation_probe_version\n',
              '                    probe = (probe_action_v6 if args.preparation_probe_version\n'
              '                             == PREPARATION_PROBE_V6 else probe_action_v5\n'
              '                             if args.preparation_probe_version\n')
s = s.replace('                        PREPARATION_PROBE_V4, PREPARATION_PROBE_V5):',
              '                        PREPARATION_PROBE_V4, PREPARATION_PROBE_V5, PREPARATION_PROBE_V6):')
s = s.replace('                                 PREPARATION_PROBE_V4, PREPARATION_PROBE_V5),',
              '                                 PREPARATION_PROBE_V4, PREPARATION_PROBE_V5, PREPARATION_PROBE_V6),')
f.write_text(s)
f = P / 'audit_preparation.py'
s = f.read_text().replace('PREPARATION_PROBE_V5 = "mr3-p2a0-outward-cancel-v5"',
              'PREPARATION_PROBE_V5 = "mr3-p2a0-outward-cancel-v5"\n'
              'PREPARATION_PROBE_V6 = "mr3-p2a0-outward-cancel-v6"')
s = s.replace('v2/v3/v4/v5 fixtures', 'v2/v3/v4/v5/v6 fixtures')
s = s.replace('PREPARATION_PROBE_V4, PREPARATION_PROBE_V5)',
              'PREPARATION_PROBE_V4, PREPARATION_PROBE_V5, PREPARATION_PROBE_V6)')
f.write_text(s)
f = P / 'test_preparation_comparison.py'
s = f.read_text().replace('PREPARATION_PROBE_V4, PREPARATION_PROBE_V5,',
                         'PREPARATION_PROBE_V4, PREPARATION_PROBE_V5, PREPARATION_PROBE_V6,')
start = s.index('    def test_v5_only_excludes_exact_32_step_workload_and_keeps_all_episode_gates')
end = s.index('    def test_unknown_v4_like_probe_keeps_real_legacy_rejection', start)
addition = s[start:end].replace('test_v5_', 'test_v6_').replace('PREPARATION_PROBE_V5', 'PREPARATION_PROBE_V6')
s = s[:end] + addition + s[end:]
s = s.replace('"mr3-p2a0-outward-cancel-v40", "mr3-p2a0-outward-cancel-v6"',
              '"mr3-p2a0-outward-cancel-v40", "mr3-p2a0-outward-cancel-v7"')
f.write_text(s)
assets = P / 'assets'
assets.mkdir()
for version in ('v3', 'v4'):
    (assets / ('20261017_mr3_p2a0_' + version)).symlink_to(
        W / ('report/assets/20261017_mr3_p2a0_' + version), target_is_directory=True)
new = assets / '20261017_mr3_p2a0_v17/independent'
new.mkdir(parents=True)
old = W / 'report/assets/20261017_mr3_p2a0_v16/independent'
for name in ('mr3_independent_angular_reset_matrix_v16.py', 'mr3_independent_physics_matrix_v16.py',
             'mr3_independent_reset_wrappers_v16_tests.py'):
    raw = (old / name).read_bytes()
    changed = raw.decode().replace('v16', 'v17').replace('v5', 'v6')
    # Test constants bind the exact new wrapper source bytes, not previous-version SHA.
    if 'tests' in name:
        for stem in ('mr3_independent_angular_reset_matrix', 'mr3_independent_physics_matrix'):
            previous_sha = sha((old / (stem + '_v16.py')).read_bytes())
            changed = changed.replace(previous_sha, sha((new / (stem + '_v17.py')).read_bytes()))
        # The new wrapper must reject its immediate V5 predecessor, keeping older rejections.
        insertion = changed.index('    def test_physical_requires_exact33_raw_records')
        added = changed[changed.index('    def test_old_v4_metadata_is_not_accepted_as_new_v6'):insertion]
        added = added.replace('test_old_v4_', 'test_old_v5_').replace('cancel-v4', 'cancel-v5')
        changed = changed[:insertion] + added + changed[insertion:]
    (new / name.replace('v16', 'v17')).write_text(changed)
with (P / 'base_sources_v1.json').open('x') as handle:
    json.dump(originals, handle, indent=2)
print(str(P))
