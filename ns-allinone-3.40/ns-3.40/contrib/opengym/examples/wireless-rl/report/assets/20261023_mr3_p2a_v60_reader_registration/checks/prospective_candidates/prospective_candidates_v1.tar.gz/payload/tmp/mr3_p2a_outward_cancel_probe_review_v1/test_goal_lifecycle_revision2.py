"""Synthetic protocol/mask counterexamples; no native inputs or physics audit."""
import ast
import copy
import hashlib
import json
import math
from pathlib import Path
import sys
import unittest

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
P = ROOT / 'ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration'
sys.path.insert(0, str(P))
from multi_robot_exploration.mr3_protocol import GoalDispatcher
from multi_robot_exploration.mr3_observation import _action_masks

# Import the actual protocol and mask modules. Compile the unchanged selector
# function source in isolation because system SciPy and learner Gymnasium belong
# to separate environments. No production module or global is patched.
source = (W / 'mr3_learning/benchmark.py').read_text()
names = {'_probe_goal_order', 'probe_action_v3', 'probe_action_v4',
         '_probe_nonapproaching_goal_action', 'probe_action_v6',
         'record_probe_v4_submission'}
segments = [ast.get_source_segment(source, node) for node in ast.parse(source).body
            if isinstance(node, ast.FunctionDef) and node.name in names]
assert len(segments) == len(names)
selector = {'math':math}
exec(compile('\n\n'.join(segments), '<unchanged benchmark selectors>', 'exec'), selector)
choose, submitted = selector['probe_action_v6'], selector['record_probe_v4_submission']
NAMES = ('tb1', 'tb2', 'tb3')
LONG_DISTANCE_LOWER_BOUND = .25 + .20 * (5. + 1.)


class Lifecycle:
    def __init__(self):
        self.events = []
        self.clock = 0.
        self.dispatcher = GoalDispatcher('synthetic-lifecycle', self.events.append)

    def advance(self, when):
        while self.clock < when:
            self.clock = min(when, self.clock + .25)
            for name, state in self.dispatcher.states.items():
                if state.goal_id is not None and not state.cancel_requested:
                    self.dispatcher.renew(name, state.goal_id, self.dispatcher.epoch,
                                          self.clock, self.clock + 1.5)
            self.dispatcher.tick(self.clock)

    def snapshot(self, when, *, x=0., speed=0., path=0., long_available=True):
        self.advance(when)
        nav = self.dispatcher.navigation(when)
        robots = [dict(name=name, x=x, y=float(index * 4), yaw=0.,
            fresh=True, valid=True, v=speed, w=0., epoch=self.dispatcher.epoch,
            source_stamp=when, odom_source_stamp=when, path_map_available=True,
            activity={'estimated_path_m':path, 'path_observation_complete':True},
            navigation=nav[name]) for index, name in enumerate(NAMES)]
        candidates = []
        for index in range(8):
            owner = index % 3
            distance = .8 if index < 3 else 1.6
            candidates.append(dict(index=index, x=distance, y=float(owner * 4),
                valid=index < 6 and (index < 3 or long_available),
                reachable=[robot == owner for robot in range(3)],
                path_distances_m=[distance if robot == owner else None for robot in range(3)]))
        per, joint, reasons = _action_masks(robots, candidates, when)
        return dict(epoch=self.dispatcher.epoch, sequence=round(when*10)+1,
            digest='synthetic-'+str(when), task_elapsed_sec=when, robots=robots,
            candidates=candidates, per_robot_action_mask=per, joint_action_mask=joint,
            mask_reasons=reasons)

    def apply(self, snapshot, action):
        assert snapshot['joint_action_mask'][action]
        statuses = []
        for index, choice in enumerate((action//100, action//10%10, action%10)):
            goal = snapshot['candidates'][choice] if choice < 8 else None
            statuses.append(self.dispatcher.submit(NAMES[index],
                'GOAL' if choice < 8 else 'KEEP' if choice == 8 else 'WAIT',
                self.clock, snapshot['sequence'], snapshot['sequence'], self.clock+1.5,
                goal=None if goal is None else {'x':goal['x'], 'y':goal['y']},
                command_epoch=self.dispatcher.epoch, created_at=self.clock))
        return {'command':dict(epoch=snapshot['epoch'], observation_sequence=snapshot['sequence'],
            observation_digest=snapshot['digest'], action=action, command_id=snapshot['sequence']),
            'synthetic_dispatch_status':statuses}

    def accept_all(self, when=.1):
        self.advance(when)
        for name, state in self.dispatcher.states.items():
            self.dispatcher.on_accept(name, state.goal_id, True, when)

    def complete_all(self, status, when):
        self.advance(when)
        for name, state in self.dispatcher.states.items():
            self.dispatcher.on_result(name, state.goal_id, status, when)


def select_long_goal_precondition(snapshot):
    """Prototype stimulus subset only; not an installed new probe implementation."""
    legal = []
    for action, allowed in enumerate(snapshot['joint_action_mask']):
        if not allowed:
            continue
        choices = (action//100, action//10%10, action%10)
        if not all(choice < 8 and math.hypot(
                snapshot['candidates'][choice]['x']-snapshot['robots'][i]['x'],
                snapshot['candidates'][choice]['y']-snapshot['robots'][i]['y'])
                > LONG_DISTANCE_LOWER_BOUND for i,choice in enumerate(choices)):
            continue
        if selector['_probe_nonapproaching_goal_action'](snapshot, action):
            legal.append(action)
    if not legal:
        raise ValueError('bounded stimulus coverage unavailable; never choose a shorter goal')
    return min(legal, key=lambda action:selector['_probe_goal_order'](snapshot, action, True))


class IntegratedGoalLifecycleTests(unittest.TestCase):
    def test_real_commitment_mask_and_success_preempt_submitted_wait(self):
        life, diagnostics = Lifecycle(), {}
        initial = life.snapshot(0.)
        action = choose(initial, diagnostics)
        self.assertEqual(action, 12)  # Outward tie selects shorter original paths.
        submitted(diagnostics, life.apply(initial, action))
        life.accept_all()
        moving = life.snapshot(1., x=.2, speed=.2, path=.2)
        self.assertTrue(all(not mask[9] for mask in moving['per_robot_action_mask']))
        self.assertTrue(all('minimum_commitment' in row for row in moving['mask_reasons']['per_robot']))
        keep = choose(moving, diagnostics)
        self.assertEqual(keep, 888)
        submitted(diagnostics, life.apply(moving, keep))
        # Synthetic straight .8m goal is within the unchanged .25m native
        # tolerance after .55m. A real SUCCEEDED callback closes ownership.
        life.complete_all(4, 3.9)
        deadline = life.snapshot(10., x=.55, speed=0., path=.55)
        self.assertTrue(all(r['navigation']['last_terminal']=='SUCCEEDED' for r in deadline['robots']))
        action = choose(deadline, diagnostics)
        self.assertEqual(action, 999)
        submitted(diagnostics, life.apply(deadline, action))
        self.assertEqual(set(diagnostics['v4_stimulus']['rounds']['initial']['waits']), set(NAMES))
        self.assertEqual([e for e in life.events if e['type']=='cancel_goal'], [])
        self.assertTrue(life.dispatcher.closed)

    def test_long_original_legal_goal_survives_to_first_legal_moving_wait_in_model(self):
        life, diagnostics = Lifecycle(), {}
        initial = life.snapshot(0.)
        action = select_long_goal_precondition(initial)
        self.assertEqual(action, 345)
        # This is the proposal's synthetic initial choice, not a claim that v6
        # chose it. Subsequent unchanged moving-WAIT logic uses the exact
        # received initial path baseline; no action receipt is fabricated.
        life.apply(initial, action)
        diagnostics['v4_stimulus'] = {'rounds':{'initial':{'waits':{},
            'baseline_path_m':{r['name']:r['activity']['estimated_path_m']
                               for r in initial['robots']}}},'decisions':[]}
        life.accept_all()
        for when in (1.,2.,3.,4.,5.):
            snap = life.snapshot(when, x=.2*when, speed=.2, path=.2*when)
            self.assertTrue(all(not row[9] for row in snap['per_robot_action_mask']))
            keep = choose(snap, diagnostics)
            self.assertEqual(keep, 888)
            submitted(diagnostics, life.apply(snap, keep))
        snap = life.snapshot(6., x=1.2, speed=.2, path=1.2)
        self.assertTrue(all(row[9] for row in snap['per_robot_action_mask']))
        self.assertTrue(all(r['navigation']['phase']=='active' and r['navigation']['owned'] for r in snap['robots']))
        goals = {name:state.goal_id for name,state in life.dispatcher.states.items()}
        action = choose(snap, diagnostics)
        self.assertEqual(action, 999)
        submitted(diagnostics, life.apply(snap, action))
        cancels = [event for event in life.events if event['type']=='cancel_goal']
        self.assertEqual(len(cancels), 3)
        self.assertEqual({e['robot']:e['goal_id'] for e in cancels}, goals)
        self.assertFalse(life.dispatcher.closed)  # Submission is not completion.
        life.advance(6.05)
        for name, goal in goals.items():
            life.dispatcher.on_cancel_response(name, goal, True, 6.05)
        self.assertFalse(life.dispatcher.closed)  # Acceptance is not terminal.
        life.complete_all(5, 6.1)
        done = life.snapshot(7., x=1.21, speed=0., path=1.21)
        self.assertTrue(all(r['navigation']['last_terminal']=='CANCELED'
            and r['navigation']['last_goal_id']==goals[r['name']] for r in done['robots']))
        self.assertTrue(life.dispatcher.closed)

    def test_short_only_candidates_never_fall_back_or_override_original_mask(self):
        life = Lifecycle()
        short = life.snapshot(0., long_available=False)
        with self.assertRaisesRegex(ValueError, 'coverage unavailable'):
            select_long_goal_precondition(short)
        original = copy.deepcopy(short)
        self.assertEqual(short, original)
        life = Lifecycle()
        snap = life.snapshot(0.)
        snap['joint_action_mask'] = [index == 888 for index in range(1000)]
        with self.assertRaisesRegex(ValueError, 'coverage unavailable'):
            select_long_goal_precondition(snap)

    def test_distance_boundary_is_strict_and_uses_original_received_geometry(self):
        life = Lifecycle()
        snap = life.snapshot(0.)
        for goal in snap['candidates'][3:6]:
            goal['x'] = LONG_DISTANCE_LOWER_BOUND
        with self.assertRaisesRegex(ValueError, 'coverage unavailable'):
            select_long_goal_precondition(snap)
        for goal in snap['candidates'][3:6]:
            goal['x'] = math.nextafter(LONG_DISTANCE_LOWER_BOUND, math.inf)
        before = copy.deepcopy(snap)
        self.assertEqual(select_long_goal_precondition(snap), 345)
        self.assertEqual(snap, before)


if __name__ == '__main__':
    unittest.main(verbosity=2)
