import importlib.util,pathlib,unittest
F=pathlib.Path('/tmp/mr3_p2a0_v17_matrix_mechanical_checks_v1/fakecanonical')
p=F/"ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v17/independent/mr3_p2a0_v17_plan_launcher_tests_v1.py"
spec=importlib.util.spec_from_file_location("v17_isolated_launcher",p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.ROOT=F;m.OLD=F/"ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v8"
suite=unittest.defaultTestLoader.loadTestsFromModule(m);assert suite.countTestCases()==14
r=unittest.TextTestRunner(verbosity=2).run(suite);raise SystemExit(0 if r.wasSuccessful() else 1)
