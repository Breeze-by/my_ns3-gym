"""Offline expected-value CDR/profile/source forensics; does not initialize ROS."""
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import urllib.request
import xml.etree.ElementTree as ET

ROOT = Path('/home/zhuyulab/ns3-workspace')
ASSETS = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets'
OUT = Path('/tmp/mr3_p2a0_v13_parameter_reply_forensics_v1')
OUT.mkdir(exist_ok=False)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


from rclpy.serialization import serialize_message
from rcl_interfaces.srv import GetParameters
from rcl_interfaces.msg import ParameterValue

old_path = ASSETS / '20261017_mr3_p2a0_v4/independent/mr3_actual_nav2_parameters_v4.py'
new_path = ASSETS / '20261017_mr3_p2a0_v13/independent/mr3_actual_nav2_parameters_v13.py'
old, new = load('old', old_path), load('new', new_path)
records = []
for label, script, path in [('old_v4', old, old_path), ('new_v13', new, new_path)]:
    for kind, expected in script.EXPECTED.items():
        names = list(expected)
        request = GetParameters.Request(names=names)
        values = []
        for name, (type_id, value) in expected.items():
            parameter = ParameterValue(type=type_id)
            setattr(parameter, script.TYPE_FIELDS[type_id], value)
            values.append(parameter)
        response = GetParameters.Response(values=values)
        payloads = {}
        for role, message in [('request', request), ('expected_response', response)]:
            raw = serialize_message(message)
            selected = OUT / f'{label}_{kind}_{role}.cdr.gz'
            encoded = gzip.compress(raw, mtime=0)
            selected.write_bytes(encoded)
            assert gzip.decompress(selected.read_bytes()) == raw
            payloads[role] = {'cdr_bytes': len(raw), 'cdr_sha256': sha(raw),
                              'path': str(selected), 'encoded_sha256': sha(encoded)}
        records.append({'version': label, 'node_kind': kind, 'names': names,
                        'parameter_count': len(names), 'source': str(path),
                        'source_sha256': sha(path.read_bytes()), 'payloads': payloads})
ns = {'p': 'http://www.eprosima.com/XMLSchemas/fastRTPS_Profiles'}
profile = ROOT / 'ros2_ws/ros2-multi-robot-automap/src/multi_robot/config/mr3_fastdds_loopback_udp.xml'
raw = profile.read_bytes()
document = ET.fromstring(raw)
profiles = []
for item in document.findall('p:publisher', ns):
    profiles.append({'name': item.get('profile_name'),
                     'seconds': int(item.findtext('p:qos/p:reliability/p:max_blocking_time/p:sec', namespaces=ns)),
                     'nanoseconds': int(item.findtext('p:qos/p:reliability/p:max_blocking_time/p:nanosec', namespaces=ns))})
expected_reply_names = [f'rr/{robot}/{kind}/get_parametersReply'
                        for robot in ('tb1', 'tb2', 'tb3')
                        for kind in ('controller_server', 'behavior_server', 'velocity_smoother')]
assert not set(expected_reply_names) & {item['name'] for item in profiles}
# Proposal is a separate /tmp XML: only the exact nine readonly parameter reply profiles added.
ET.register_namespace('', ns['p'])
for name in expected_reply_names:
    publisher = ET.SubElement(document, '{' + ns['p'] + '}publisher', {'profile_name': name})
    qos = ET.SubElement(publisher, '{' + ns['p'] + '}qos')
    reliability = ET.SubElement(qos, '{' + ns['p'] + '}reliability')
    ET.SubElement(reliability, '{' + ns['p'] + '}kind').text = 'RELIABLE'
    duration = ET.SubElement(reliability, '{' + ns['p'] + '}max_blocking_time')
    ET.SubElement(duration, '{' + ns['p'] + '}sec').text = '1'
    ET.SubElement(duration, '{' + ns['p'] + '}nanosec').text = '0'
proposal = OUT / 'parameter_reply_candidate.xml'
ET.ElementTree(document).write(proposal, encoding='utf-8', xml_declaration=True)
source_rows = []
for relative in ['rmw_fastrtps_shared_cpp/src/rmw_response.cpp', 'rmw_fastrtps_cpp/src/rmw_service.cpp']:
    url = 'https://raw.githubusercontent.com/ros2/rmw_fastrtps/6.2.10/' + relative
    payload = urllib.request.urlopen(url, timeout=30).read()
    selected = OUT / Path(relative).name
    selected.write_bytes(payload)
    source_rows.append({'url': url, 'path': str(selected), 'sha256': sha(payload)})
result = {'schema': 'mr3-v13-parameter-reply-forensics-v1', 'scope': 'Offline system ROS CDR serialization only; no rclpy.init/Node/DDS/native process. New expected response bytes are synthetic expected-value serialization, not actual observed reply wire bytes.',
          'serialization': records, 'profile': {'path': str(profile), 'sha256': sha(raw), 'publisher_profiles': profiles,
          'missing_exact_parameter_reply_profiles': expected_reply_names}, 'proposal': {'path': str(proposal), 'sha256': sha(proposal.read_bytes()),
          'change': 'Only nine exact GetParameters response writer matching/write max_blocking_time=1s; no default/fallback, client30s/45s, node motion or task gates changed. Proposal only; not applied or native-tested.'},
          'official_matching_version_sources': source_rows}
(OUT / 'serialization_profile_sources.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'output': str(OUT), 'payload_bytes': [{ 'version': item['version'], 'kind': item['node_kind'], 'count': item['parameter_count'], 'request': item['payloads']['request']['cdr_bytes'], 'expected_response': item['payloads']['expected_response']['cdr_bytes']} for item in records]}, indent=2))
