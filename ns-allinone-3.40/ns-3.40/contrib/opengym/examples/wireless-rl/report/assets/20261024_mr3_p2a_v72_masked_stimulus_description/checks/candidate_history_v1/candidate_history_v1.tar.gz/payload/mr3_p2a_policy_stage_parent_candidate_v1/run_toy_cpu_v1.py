"""Fixed stdlib artificial tests only; never imports or invokes PPO/ROS/readers."""
import importlib.util
import json
from pathlib import Path
import sys
import time
import unittest
import xml.etree.ElementTree as ET

BASE = Path(__file__).resolve().parent
OUT = BASE/'cpu_attempt_v1'


class Results(unittest.TextTestResult):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.records=[]
    def startTest(self,test):
        super().startTest(test);self.started=time.monotonic();self.status='passed';self.detail=''
    def addFailure(self,test,error):
        super().addFailure(test,error);self.status='failure';self.detail=self._exc_info_to_string(error,test)
    def addError(self,test,error):
        super().addError(test,error);self.status='error';self.detail=self._exc_info_to_string(error,test)
    def addSkip(self,test,reason):
        super().addSkip(test,reason);self.status='skipped';self.detail=reason
    def stopTest(self,test):
        self.records.append(dict(id=test.id(),status=self.status,detail=self.detail,seconds=time.monotonic()-self.started))
        super().stopTest(test)


def main():
    spec=importlib.util.spec_from_file_location('fixed_stage_parent_tests',BASE/'test_stage_parent_v1.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    suite=unittest.defaultTestLoader.loadTestsFromModule(module)
    result=unittest.TextTestRunner(verbosity=2,resultclass=Results).run(suite)
    counts=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped))
    passed=result.wasSuccessful() and counts==dict(tests=11,failures=0,errors=0,skipped=0)
    root=ET.Element('testsuite',name='fixed_stage_parent_artificial',**{k:str(v) for k,v in counts.items()})
    for row in result.records:
        child=ET.SubElement(root,'testcase',name=row['id'],time=str(row['seconds']))
        if row['status']!='passed':ET.SubElement(child,row['status']).text=row['detail']
    with (OUT/'junit.xml').open('xb') as stream:ET.ElementTree(root).write(stream,encoding='utf-8',xml_declaration=True)
    with (OUT/'test_result_v1.json').open('x') as stream:
        json.dump(dict(schema='mr3-fixed-stage-parent-artificial-tests-v1',passed=passed,counts=counts,
            test_argv=sys.argv,artificial_only=True,World_started=False,PPO_started=False,
            original_scientific_inputs_read=False,records=result.records),stream,indent=2);stream.write('\n')
    return 0 if passed else 1


if __name__=='__main__':raise SystemExit(main())
