"""Independent mechanical/static review; never imports or invokes coordinators."""
import ast
import hashlib
import json
from pathlib import Path


ROOT = Path("/home/zhuyulab/ns3-workspace")
W = ROOT / "ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl"
DRAFT = Path("/tmp/mr3_p2a0_v20_matrix_draft_v2")
OLD = W / "report/assets/20261017_mr3_p2a0_v17/predeclared_plan_v17.json"
REF = W / "report/assets/20261018_mr3_p2a0_v19/predeclared_plan_v19.json"
V1 = Path("/tmp/mr3_p2a0_v20_matrix_draft_v1")
inputs = {}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    raw = path.read_bytes()
    inputs[str(path)] = {"sha256": sha(raw), "bytes": len(raw)}
    return raw


def same(a, b):
    return json.dumps(a, sort_keys=True, allow_nan=False) == json.dumps(
        b, sort_keys=True, allow_nan=False)


def inverse(value):
    if isinstance(value, dict):
        return {key: inverse(item) for key, item in value.items()}
    if isinstance(value, list):
        return [inverse(item) for item in value]
    if isinstance(value, str):
        return value.replace("20261018_mr3_p2a0_v20", "20261017_mr3_p2a0_v17").replace(
            "mr3_p2a0_20261018_v20", "mr3_p2a0_20261017_v17").replace(
            "V20", "V17").replace("v20", "v17")
    return value


plan = json.loads(read(DRAFT / "predeclared_plan_v20.json"))
old = json.loads(read(OLD))
reference = json.loads(read(REF))
pending = json.loads(read(DRAFT / "source_bindings_pending_v1.json"))
summary = json.loads(read(DRAFT / "summary_v1.json"))
author_checks = json.loads(read(DRAFT / "static_checks_v1.json"))
manifest = json.loads(read(DRAFT / "manifest_v1.json"))
for item in manifest["files"]:
    raw = read(DRAFT / item["path"])
    assert sha(raw) == item["sha256"] and len(raw) == item["bytes"]
assert manifest["no_canonical_mutation"] is True
assert manifest["no_native_or_formal_execution"] is True
assert len(author_checks["checks"]) == 39
assert all(row["passed"] is True for row in author_checks["checks"])
preserved_fields = [
    "robots_per_environment", "gpu_calls", "optimizer_steps",
    "max_api_records", "max_submitted_script_decisions", "max_total_wall_seconds",
    "api_budget_breakdown", "pilot_budget_unchanged", "unchanged_gates", "scope_limits",
    "physical_response_criteria", "angular_interface_criteria", "angular_reset_criteria",
    "settled_turn_criteria", "capacity_scope", "transport_readback_scope", "drive_contract",
    "full_execution_model_failfast", "drive_command_cap_audit", "navigation_profile",
    "external_probe_v6", "navigation_peer_geometry_repair", "parameter_reply_wait",
    "information_selection_audit", "controlled_execution_audit",
]
assert all(same(plan[key], old[key]) for key in preserved_fields)
assert [row["stage"] for row in plan["stages"]] == [
    "interface", "terminal", "reset", "deadline"]
assert (plan["max_api_records"], plan["max_submitted_script_decisions"],
        plan["max_total_wall_seconds"]) == (608, 596, 18000)
stage_results = []
for new, prior in zip(plan["stages"], old["stages"]):
    normalized = inverse(new)
    for option in ("--base-domain", "--base-port"):
        at = normalized["command"].index(option) + 1
        normalized["command"][at] = prior["command"][prior["command"].index(option) + 1]
    for actual, previous in zip(normalized["worker_bindings"], prior["worker_bindings"]):
        actual["domain"], actual["port"] = previous["domain"], previous["port"]
    assert same(normalized, prior)
    stage_results.append({"stage": new["stage"], "all_fields_equal_after_exact_identity_changes": True,
                          "mandatory_receipts": len(new["required_audit_receipts"])})
assert [row["mandatory_receipts"] for row in stage_results] == [10, 7, 10, 7]
assert sum(row["mandatory_receipts"] for row in stage_results) == 34
assert plan["readiness"]["status"] == "draft_not_native_admission"
assert plan["readiness"]["freeze"] is None
assert plan["readiness"]["pending_bindings"]
assert plan["native_admission_granted"] is False
assert len(plan["new_source_bindings_pending"]) == 6
assert len(pending["runtime_source_proof"]["bindings"]) == 103
assert len(plan["independent_source_bindings"]) == 155
assert same(plan["independent_source_bindings"], reference["independent_source_bindings"])
assert same(plan["independent_source_bindings"], pending["independent_reference"]["bindings"])
assert pending["status"] == "reference_only_not_future_freeze_approval"
assert pending["runtime_source_proof"]["freeze"] == "72d0465ddd1bbee09af117cfd9d89b7e729f8578"
assert plan["v20_preparation"]["future_physics_repair"]["status"] == "pending_not_selected"
assert plan["v20_preparation"]["future_physics_repair"]["iterations"] is None
assert "no V18/V19 diagnostic profile is implicitly enabled" in plan[
    "v20_preparation"]["future_physics_repair"]["diagnostic_environment_use"]
coordinators = []
guard_results = []
for item in plan["new_source_bindings_pending"]:
    current_raw = read(Path(item["draft_path"]))
    previous_raw = read(Path(item["base_source"]))
    assert sha(current_raw) == item["draft_sha256"]
    assert sha(previous_raw) == item["base_sha256"]
    assert inverse(current_raw.decode()).encode() == previous_raw
    tree = ast.parse(current_raw)
    main = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "main")
    guard = next((node.test for node in ast.walk(main)
        if isinstance(node, ast.Assert) and "'readiness'" in ast.unparse(node.test)), None)
    if guard is None:
        candidates = [node.args[0] for node in ast.walk(main) if isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name) and node.func.id == "require" and node.args
            and "'readiness'" in ast.unparse(node.args[0])]
        guard = candidates[0] if candidates else None
    if guard is not None:
        # Evaluate only the isolated pure Boolean expression, never the entrypoint.
        assert eval(compile(ast.Expression(guard), "<isolated-readiness-expression>", "eval"),
                    {"plan": plan, "STAGES": ("interface", "terminal", "reset", "deadline")}) is False
        guard_results.append(Path(item["draft_path"]).name)
    coordinators.append({"draft_path": item["draft_path"], "draft_sha256": item["draft_sha256"],
                         "base_source": item["base_source"], "base_sha256": item["base_sha256"],
                         "inverse_mechanical_bytes_equal": True})
assert len(guard_results) == 5  # closure is a read-only consumer, not native admission.
watch_name = "mr3_p2a0_v20_cross_stage_mapping_monitor_v1.py"
watch_v1 = read(V1 / "independent" / watch_name).decode()
watch_v2 = read(DRAFT / "independent" / watch_name).decode()
old_run, new_run = "mr3_p2a0_20261017_v17_{stage}", "mr3_p2a0_20261018_v20_{stage}"
assert watch_v1.count(old_run) == 2 and watch_v2.count(old_run) == 0
assert watch_v2.count(new_run) == 2
assert watch_v1.replace(old_run, new_run) == watch_v2
v1_manifest = read(V1 / "manifest_v1.json")
assert sha(v1_manifest) == summary["initial_draft_diagnostic"]["manifest_sha256"]
assert summary["initial_draft_diagnostic"]["native_or_formal_execution"] is False
assert all(sha(Path(path).read_bytes()) == proof["sha256"] for path, proof in inputs.items())
result = {
    "schema": "mr3-v20-matrix-draft-independent-review-v1",
    "review_only": True, "mechanical_draft_review_completed": True,
    "native_admission_granted": False,
    "source_inputs_stable_before_after": inputs,
    "preserved_whole_fields": preserved_fields, "stages": stage_results,
    "mandatory_receipts_total": 34, "coordinators": coordinators,
    "isolated_readiness_expression_rejected_pending": guard_results,
    "pending_references": {"runtime": 103, "independent": 155,
        "new_coordinators": 6, "future_approved_total": None,
        "scope": "Reference identities only, not future-freeze approval or automatic authorization to refresh hashes."},
    "original_gate_scope": {
        "physical": "Interface original2516 A OR B per robot; reset at least one credited A OR B per robot across exact8 reset episodes, with all raw/closure and every eligible observed violation enforced. Per-episode missing retained, no added A AND B.",
        "angular": "Interface each robot signspan plus aggregate +/- and >=1 same-robot dual; reset every-episode sampled_bounds only, coverage false retained.",
        "terminal_deadline": "Original short/zero-tail semantics and300KEEP deadline, strict shutdown/owned absence; no stimulus-pool or95% credit.",
        "settled_execution_activity": "Original whole active segment/source/actualstorage and all actual information/peer/guard/native/map/activity gates unchanged.",
        "research": "No PPO/optimizer/GPU, no policy95% credit or cross-freeze matrix assembly; user acceptance remains separate."
    },
    "initial_checker_limitation_preserved": {
        "old_manifest_path": str(V1 / "manifest_v1.json"), "old_manifest_sha256": sha(v1_manifest),
        "fact": "V1's inverse-normalization checks did not notice2 unchanged V17 BASE run identifiers inside the prospective V20 watcher; draft-only, no native/formal execution.",
        "v2_exact_correction": "Only these2 run identifiers change in watcher; all6 complete source files now invert byte-for-byte to V17 and direct runid checks also hold.",
        "not_a_new_gate": True
    },
    "remaining_before_any_run": [
        "Actual V19 outcomes and a separately selected justified physical repair; no choice is inferred by this draft.",
        "Review exact future runtime/independent/physical source and library changes, restricted W7 compatibility if selected, then bind actual new dependencies.",
        "Promote reviewed plan/source/docs, required CPU/build checks, clean pushed exact40 freeze and its source/installed/binary preflight.",
        "Current pending plan stays closed; don't simply flip readiness or reuse reference proof as future approval."
    ],
    "native_formal_ros_dds_calls": 0,
    "active_v19_raw_or_stage_receipts_read": False,
    "canonical_or_proposal_mutations": 0,
}
target = Path("/tmp/mr3_p2a0_v20_matrix_draft_independent_review_v1.json")
target.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
print(json.dumps({"review": str(target), "sha256": sha(target.read_bytes()),
                  "coordinators": len(coordinators), "mandatory": 34,
                  "native_admission": False}))
