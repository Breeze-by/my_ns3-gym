"""Read-only review of root's merged canonical proposal, no build or native."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT=Path('/home/zhuyulab/ns3-workspace')
PACKAGE=ROOT/'ros2_ws/ros2-multi-robot-automap/src/multi_robot'
CANDIDATE=Path('/tmp/mr3_p2a0_v18_driver_diagnostic_proposal_v5')


def sha(data):
    return hashlib.sha256(data).hexdigest()


files={}
def read(path):
    data=path.read_bytes()
    files[str(path)]=sha(data)
    return data

observer=read(PACKAGE/'src/mr3_stop_response_observer.cpp')
checks={'observer_exact_candidate_v5':observer==read(CANDIDATE/'mr3_stop_response_observer.cpp')}
old=json.loads(read(CANDIDATE/'checks_v1.json'))
for item in old['canonical_unchanged_bindings']:
    if item['source'].endswith('CMakeLists.txt'):
        continue
    checks['original_driver_source_unchanged:'+Path(item['source']).name]=sha(read(Path(item['source'])))==item['sha256']
cmake=read(PACKAGE/'CMakeLists.txt').decode()
restored=cmake
spans=[]
for marker,finish in [('# Opt-in diagnostic observer only.',
                      'install(TARGETS mr3_stop_response_observer DESTINATION lib)'),
                     ('# Diagnostic-only opt-in SystemPlugin.',
                      'install(TARGETS mr3_physics_diagnostic_profile DESTINATION lib)')]:
    begin=restored.index(marker)
    end=restored.index('\n',restored.index(finish,begin))+1
    if restored[end:end+1]=='\n':
        end+=1
    spans.append(restored[begin:end])
    restored=restored[:begin]+restored[end:]
checks['only_two_added_cmake_target_blocks']=restored.encode()==read(CANDIDATE/'sourceproof/CMakeLists.txt')
checks['profile_source_expected']=sha(read(PACKAGE/'src/mr3_physics_diagnostic_profile.cpp'))=='26952e1cb8b17239a61b75ee98466daad65bafe116864557bbe92cc0b7fed7c0'
for path,expected in files.items():
    assert sha(Path(path).read_bytes())==expected,'read source changed: '+path
result={'schema':'mr3-v18-observer-canonical-merge-readonly-v1',
        'passed':all(checks.values()),'checks':checks,'input_bindings':files,
        'added_cmake_blocks':spans,'utc':datetime.now(timezone.utc).isoformat(),
        'scope':'Read-only byte and CMake restricted-delta review. No new build, native, formal audit, actor/control/physics or source edits. Root is separately running canonical build.',
        'script_sha256':sha(Path(__file__).read_bytes())}
output=Path('/tmp/mr3_p2a0_v18_observer_canonical_merge_review_v1.json')
with output.open('x') as stream:
    json.dump(result,stream,indent=2)
    stream.write('\n')
print(json.dumps({'passed':result['passed'],'output':str(output),
                  'sha256':sha(output.read_bytes()),'checks':checks},indent=2))
raise SystemExit(0 if result['passed'] else 1)
