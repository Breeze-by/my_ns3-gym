"""Verify stable diagnostic bytes only; no ROS, source edit or formal stage audit."""
import collections
import gzip
import hashlib
import json
from pathlib import Path
import time

sha = lambda b: hashlib.sha256(b).hexdigest()
result = {'schema':'mr3-passive-nav2-custody-v1','freeze':'6b1b4a0108351f5bfb70ec0c96ba895248d4f7a8','scope':'Full late passive diagnostic data custody, not formal safety/task or earlier failed-episode evidence','passed':False,'errors':[],'domains':[]}
began=time.monotonic()
try:
 for domain in (134,135):
  base=Path(f'/tmp/mr3_p2a0_v12_passive_nav2_domain{domain}_v6')
  ledger=base/'receipts.jsonl';raw_ledger=ledger.read_bytes();rows=[json.loads(line) for line in raw_ledger.splitlines()]
  samples=[r for r in rows if r['kind']=='raw_cdr_received'];references={};counts=collections.Counter()
  for row in samples:
   relative=Path(row['payload'])
   assert not relative.is_absolute() and '..' not in relative.parts
   target=base/relative
   assert target.stem==row['raw_cdr_sha256']+'.cdr'
   descriptor={'path':str(target),'raw_sha256':row['raw_cdr_sha256'],'raw_bytes':row['raw_cdr_bytes'],'encoded_sha256':row['payload_proof']['encoded_sha256'],'encoded_bytes':row['payload_proof']['encoded_bytes']}
   assert str(relative) not in references or references[str(relative)]==descriptor
   references[str(relative)]=descriptor
   counts[row['topic']]+=1
  for descriptor in references.values():
   target=Path(descriptor['path']);encoded=target.read_bytes();decoded=gzip.decompress(encoded)
   assert sha(encoded)==descriptor['encoded_sha256'] and len(encoded)==descriptor['encoded_bytes']
   assert sha(decoded)==descriptor['raw_sha256'] and len(decoded)==descriptor['raw_bytes']
   assert target.read_bytes()==encoded
  assert {str(p.relative_to(base)) for p in base.rglob('*.cdr.gz')}==set(references)
  summary=base/'observer_summary.json';summaryraw=summary.read_bytes();sv=json.loads(summaryraw)
  assert sv['completed'] is True and sv['failure'] is None and dict(counts)==sv['counts']
  assert sv['cleanup']['executor_shutdown'] is True and sv['cleanup']['context_shutdown'] is True
  assert not Path('/proc/'+str(sv['identity']['pid'])).exists()
  assert ledger.read_bytes()==raw_ledger and summary.read_bytes()==summaryraw
  result['domains'].append({'domain':domain,'ledger':str(ledger),'ledger_sha256':sha(raw_ledger),'ledger_bytes':len(raw_ledger),'summary':str(summary),'summary_sha256':sha(summaryraw),'raw_cdr_records':len(samples),'topic_counts':dict(counts),'unique_payloads':len(references),'encoded_payload_bytes':sum(v['encoded_bytes'] for v in references.values()),'decoded_payload_bytes':sum(v['raw_bytes'] for v in references.values()),'payloads':list(references.values()),'checked_bytes_unchanged':True})
 result['passed']=True
except Exception as error:
 result['errors'].append(repr(error))
result['wall_sec']=time.monotonic()-began
output=Path('/tmp/mr3_p2a0_v12_passive_nav2_custody_manifest_v1.json');output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'output':str(output),'sha256':sha(output.read_bytes()),'passed':result['passed'],'errors':result['errors'],'domains':[{k:v for k,v in d.items() if k!='payloads'} for d in result['domains']],'wall_sec':result['wall_sec']}))
raise SystemExit(0 if result['passed'] else 1)
