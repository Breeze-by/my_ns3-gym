import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
R=Path('/home/zhuyulab/ns3-workspace');T=Path('/tmp')
helper=T/'mr3_p2a0_v17_pack_native_v1.py'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(helper)=='86e3e49e69077ba9ca212910a93190a088e25e779fd45ac2fdec0d29e8270569'
env=dict(os.environ,PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONPATH',None)
for stage in ('interface','terminal','reset'):
 out=T/('mr3_p2a0_v17_pack_'+stage+'_execution_v1.json');console=T/('mr3_p2a0_v17_pack_'+stage+'_v1.log')
 assert not out.exists() and not console.exists()
 start=time.monotonic();utc=datetime.datetime.now(datetime.timezone.utc).isoformat();cmd=['/usr/bin/python3',str(helper),stage]
 with console.open('x') as f:ret=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
 v=dict(argv=cmd,cwd=str(R),env=dict(PYTHONPATH='unset',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1'),started_utc=utc,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),wall_seconds=time.monotonic()-start,returncode=ret.returncode,source_sha256=sha(helper),console=str(console),console_sha256=sha(console))
 with out.open('x') as f:f.write(json.dumps(v,indent=2)+'\n')
 print(json.dumps(dict(stage=stage,**v)),flush=True)
 if ret.returncode:sys.exit(ret.returncode)
 m=json.loads((T/'mr3_p2a0_v17_selected_native'/stage/'manifest.json').read_text())
 maximum=max(x['selected_bytes'] for x in m['files']);print(json.dumps(dict(stage=stage,maximum_selected_bytes=maximum,under_100000000=maximum<100000000)),flush=True)
 assert maximum<100000000
