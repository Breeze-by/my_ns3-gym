import hashlib,json,os
from pathlib import Path
import subprocess

ROOT=Path('/home/zhuyulab/ns3-workspace')
W=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A=Path(__file__).resolve().parent
C=A/'candidate'/W.relative_to(ROOT)/'mr3_learning'
PY='/home/zhuyulab/miniconda3/envs/ns3gym/bin/python'


def main():
    out=A/'checks/targeted_cpu_v1';out.mkdir(parents=True,exist_ok=False);snapshots=out/'source_snapshots';snapshots.mkdir()
    sources=sorted(set([*C.rglob('*.py'),A/'conftest.py',Path(__file__),*(W/'mr3_learning').glob('*.py'),
        *(W/'mr3_learning/tests').glob('*.py'),
        *(ROOT/'ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/multi_robot_exploration').glob('*.py'),
        *(ROOT/'ros2_ws/ros2-multi-robot-automap/scripts').glob('*.py'),Path(PY).resolve()]))
    rows=[]
    for ordinal,path in enumerate(sources):
        raw=path.read_bytes();sha=hashlib.sha256(raw).hexdigest();snapshot=snapshots/(f'{ordinal:03d}_{sha}.bin')
        snapshot.open('xb').write(raw);rows.append(dict(path=str(path),bytes=len(raw),sha256=sha,snapshot=str(snapshot)))
    tests=sorted(str(p) for p in (C/'tests').glob('test_*.py'))
    command=[PY,'-B','-m','pytest','-q','-p','no:cacheprovider','--rootdir='+str(A),*tests,
        '-k','not actual_system_child_replays_artificial_frozen_observation_and_scipy_without_poison',
        '--junitxml',str(out/'junit.xml')]
    (out/'source_recovery_v1.json').open('x').write(json.dumps(dict(sources=rows,actual_test_argv=command,
        private_fixture_lookup=True,production_modules_are_canonical=True,
        source_closure_one_line_candidate_requires_canonical_install_before_real_isolated_system_case=True,
        formal_fresh_credit=False,scientific_credit=False),indent=2)+'\n')
    argv=[PY,'-B','-m','mr3_learning.reach_execution','--scope','cpu','--output',str(out/'actual')]
    for path in sources:argv.extend(['--source',str(path)])
    env=dict(os.environ,PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONPATH',None);env.pop('PYTHONHOME',None)
    return subprocess.call([*argv,'--',*command],cwd=W,env=env)


if __name__=='__main__':raise SystemExit(main())
