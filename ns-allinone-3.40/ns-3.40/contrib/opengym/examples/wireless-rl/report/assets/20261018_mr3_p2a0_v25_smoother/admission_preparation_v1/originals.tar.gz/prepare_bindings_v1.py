"""Generate TMP proposals from already built canonical files; never build or write Git."""
import hashlib
import importlib.util
import json
from pathlib import Path

D = Path(__file__).parent
spec = importlib.util.spec_from_file_location('smoother', D / 'mr3_v25_smoother_custody_v1.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
source = m.ROS / 'src/nav2_velocity_smoother'
files = {}
for name, digest in m.SOURCE_SHA.items():
    raw = (source / name).read_bytes()
    assert m.sha(raw) == digest
    files[name] = {'sha256': digest, 'bytes': len(raw)}
m.inverse_cpp((source / 'src/velocity_smoother.cpp').read_bytes())
manifest = {'schema': 'mr3-v25-smoother-source-manifest-v1',
    'upstream_repository': 'https://github.com/ros-navigation/navigation2',
    'upstream_commit': m.UPSTREAM_COMMIT, 'upstream_tag': '1.1.20',
    'source_root': str(source), 'files': files,
    'projected_upstream_cpp_sha256': m.UPSTREAM_CPP_SHA,
    'scope': 'Official nine files plus explicit MR3 provenance. Only CPP header and two fixed timer factories change; exact inverse checked.'}
raw = (json.dumps(manifest, sort_keys=True, indent=2) + '\n').encode()
(D / 'source_manifest_v1.json').write_bytes(raw)
receipt_path = m.ASSET / 'build_evidence/selected_elf_manifest_v1.json'
receipt = json.loads(receipt_path.read_bytes())
installed = {}
for name, expected in m.expected_installed().items():
    row = next(x for x in receipt['outputs'] if x['path'] == expected['path'])
    installed[name] = {key: row[key] for key in ('path', 'resolved', 'sha256', 'bytes')}
binding = {'schema': 'mr3-v25-smoother-binding-v1', 'status': 'ready',
    'readiness_scope': 'Exact already built file/archive/source identity, not actual native admission or per-episode loaded proof',
    'monitor': {'path': str(m.MONITOR), 'sha256': m.MONITOR_SHA},
    'source_manifest': {'path': str(m.ASSET / 'source_manifest_v1.json'), 'sha256': hashlib.sha256(raw).hexdigest()},
    'binary_receipt': {'path': str(receipt_path), 'sha256': m.sha(receipt_path.read_bytes())},
    'installed': installed}
(D / 'mr3_v25_smoother_binding_v1.json').write_text(json.dumps(binding, sort_keys=True, indent=2) + '\n')
print(json.dumps({'source_manifest_sha256': m.sha(raw),
    'binding_sha256': m.sha((D / 'mr3_v25_smoother_binding_v1.json').read_bytes()),
    'installed': installed}, sort_keys=True))
