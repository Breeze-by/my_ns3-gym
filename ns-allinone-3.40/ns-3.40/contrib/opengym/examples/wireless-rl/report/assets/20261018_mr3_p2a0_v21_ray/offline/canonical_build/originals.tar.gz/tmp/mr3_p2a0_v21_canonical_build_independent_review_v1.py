"""Read actual canonical build artifacts and existing logs; execute no build/test."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import sys
import time


RECEIPT = Path('/tmp/mr3_p2a0_v21_canonical_build_v1/execution.json')
OUTPUT = Path('/tmp/mr3_p2a0_v21_canonical_build_independent_review_v1.json')
EXPECTED_SOURCE = '65b1c1db64861366811266580daf8cf43bcf565fc856a405f473b02bdefd082c'
EXPECTED_CMAKE = '170eb49947c4daa61d30f45ab8fde637aa12766182dddfda15c9ca6453d0cc0d'
EXPECTED_LIBRARY = 'b76138132ae7dbb35936c2e0971e909f688189d240de3910516157b3553d57b8'
EXPECTED_OLD = {
    'libmr3_gazebo_diff_drive.so': 'a014f2c618e38fc8a306d76c100083d952606333045a2e35bffce6f8b25b10c8',
    'libmr3_stop_response_observer.so': '9a1d76b0d9a6585bb2d40fb348bc5636bdd256838291e8ea605d1d05b18806bf',
    'libmr3_physics_diagnostic_profile.so': '09321ea65a2c893d2e65316f43d5ee54d5dda7014a5d40e2186b6b720055fcc1'}
INPUTS = {}


def identity(value):
    return [value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns]


def capture(path):
    path = Path(path)
    before = path.stat()
    with path.open('rb') as stream:
        assert identity(os.fstat(stream.fileno())) == identity(before)
        raw = stream.read()
        assert identity(os.fstat(stream.fileno())) == identity(before)
    assert identity(path.stat()) == identity(before)
    value = {'path': str(path), 'resolved': str(path.resolve()), 'bytes': len(raw),
             'sha256': hashlib.sha256(raw).hexdigest(), 'stat': identity(before)}
    if str(path) in INPUTS:
        assert value == INPUTS[str(path)]
    INPUTS[str(path)] = value
    return raw


def declared(row):
    raw = capture(row['path'])
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
    assert str(Path(row['path']).resolve()) == row['resolved']
    return raw


def main():
    began = time.monotonic()
    source_self = capture(__file__)
    receipt = json.loads(capture(RECEIPT))
    assert receipt['passed'] is True
    source = declared(receipt['source_before'])
    assert declared(receipt['source_after']) == source
    assert hashlib.sha256(source).hexdigest() == EXPECTED_SOURCE
    cmake = declared(receipt['cmake_before'])
    assert declared(receipt['cmake_after']) == cmake
    assert hashlib.sha256(cmake).hexdigest() == EXPECTED_CMAKE
    assert b'GZ_REGISTER_SENSOR_PLUGIN(RayProvenanceObserver)' in source
    assert b'target_compile_features(mr3_ray_provenance_observer PRIVATE cxx_std_17)' in cmake
    flags = declared(receipt['new_target_flags'])
    assert b'MR3_RAY_PROVENANCE_SOURCE_SHA256=' in flags and EXPECTED_SOURCE.encode() in flags
    assert b'MR3_RAY_PROVENANCE_CPU_TEST' not in flags
    link = declared(receipt['new_target_link'])
    assert b'libmr3_ray_provenance_observer.so' in link
    assert b'mr3_ray_provenance_observer.cpp.o' in link
    library = declared(receipt['installed_new_library'])
    installed = Path(receipt['installed_new_library']['path'])
    built = Path(receipt['installed_new_library']['resolved'])
    assert installed.is_symlink() and os.path.samefile(installed, built)
    assert capture(built) == library
    assert library.startswith(b'\x7fELF') and len(library) == 463272
    assert hashlib.sha256(library).hexdigest() == EXPECTED_LIBRARY
    assert EXPECTED_SOURCE.encode() in library
    old = {}
    for name, expected in EXPECTED_OLD.items():
        before = receipt['old_libraries_before'][name]
        after = receipt['old_libraries_after'][name]
        assert before == after and before['sha256'] == expected
        raw = declared(after)
        assert os.path.samefile(after['path'], after['resolved'])
        assert capture(after['resolved']) == raw
        old[name] = {'sha256': expected, 'bytes': len(raw), 'before_after_and_current_exact': True}
    commands = {row['label']: row for row in receipt['commands']}
    assert set(commands) == {'colcon', 'factory', 'ldd'}
    assert all(row['exit_code'] == 0 for row in commands.values())
    logs = {}
    for label, row in commands.items():
        logs[label] = declared(row['stdout']) + declared(row['stderr'])
    assert commands['factory']['argv'][1] == str(installed)
    assert commands['ldd']['argv'] == ['/usr/bin/ldd', '-r', str(installed)]
    assert b'GetType==SENSOR_PLUGIN' in logs['factory']
    assert b'no Load/ROS/Gazebo initialization' in logs['factory']
    assert b'not found' not in logs['ldd'] and b'undefined symbol' not in logs['ldd']
    assert b'Building CXX object CMakeFiles/mr3_ray_provenance_observer.dir/src/mr3_ray_provenance_observer.cpp.o' in logs['colcon']
    assert b'Built target mr3_ray_provenance_observer' in logs['colcon']
    factory = Path(commands['factory']['argv'][0])
    capture(factory)
    for value in list(INPUTS.values()):
        capture(value['path'])
    result = {'schema': 'mr3-v21-canonical-build-independent-readonly-review-v1',
              'passed': True, 'scope': 'Existing canonical build/actual binary/recorded factory and ldd evidence only; no recompile, factory, ldd, ROS, DDS, native or formal run.',
              'argv': sys.argv, 'environment_selected': {key: os.environ.get(key) for key in
                ('PATH', 'PYTHONNOUSERSITE', 'PYTHONDONTWRITEBYTECODE', 'LANG', 'LC_ALL', 'TZ')},
              'cwd': os.getcwd(), 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'checks': {'source65b1_cmake170e_exact': True,
                         'source_macro_flags_and_elf_exact': True,
                         'new_library_b761_install_symlink_build_bytes_exact': True,
                         'old3_before_after_current_bytes_exact': True,
                         'recorded_actual_factory_sensor_type_pass': True,
                         'recorded_actual_ldd_no_missing_or_undefined': True,
                         'canonical_target_optimized_pic_not_cpu_test_macro': True,
                         'all_inputs_read_and_final_stat_hash_stable': True},
              'old_libraries': old, 'canonical_library': receipt['installed_new_library'],
              'build_wall_seconds_original': receipt['wall_seconds'],
              'native_library_scope': 'Canonical b761/463272B is distinct from earlier TMP Debug SDK a48a/7927440B; no TMP ELF substituted.',
              'inputs': list(INPUTS.values()), 'source_sha256': hashlib.sha256(source_self).hexdigest(),
              'review_wall_seconds': time.monotonic() - began, 'writers': 'STOP'}
    with OUTPUT.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'passed': True, 'review': str(OUTPUT),
                      'sha256': hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),
                      'inputs': len(INPUTS), 'wall_seconds': result['review_wall_seconds']}))


if __name__ == '__main__':
    main()
