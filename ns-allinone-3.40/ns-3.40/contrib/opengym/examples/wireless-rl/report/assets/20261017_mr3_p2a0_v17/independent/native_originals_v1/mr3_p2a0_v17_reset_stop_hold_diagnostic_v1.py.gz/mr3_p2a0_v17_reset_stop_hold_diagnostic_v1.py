"""Small original physical JSON and 2 complete returned snapshot ledgers only."""
import ast
import hashlib
import json
import math
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
SOURCE = W / 'mr3_learning/benchmark.py'
PHYSICS_SOURCE = W / ('report/assets/20261017_mr3_p2a0_v3/independent/'
                      'mr3_independent_physics_review.py')
PHYSICS = Path('/tmp/mr3_p2a0_v17_reset_physical_per_episode_v1.json')
BASE = ROOT / ('ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/'
               'mr3_p2a0_20261017_v17_reset/worker1')
OUTPUT = Path('/tmp/mr3_p2a0_v17_reset_stop_hold_diagnostic_v1.json')
FREEZE = 'eee6b2f90f697b28a1c20a2af5d1a6d2f044465e'
INPUTS = {}


def sha(payload):
    return hashlib.sha256(payload).hexdigest()


def read(path):
    payload = path.read_bytes()
    INPUTS[str(path)] = sha(payload)
    return payload


started = time.monotonic()
result = {'schema': 'mr3-v17-reset-stop-hold-small-input-diagnostic-v1', 'passed': False,
          'scope': 'Diagnostic integrity/exact pure replay only. Original physical FAIL remains '
                   'FAIL. Only small physical JSON plus2 closed returned ledgers and frozen '
                   'source read; no large raw scan, formal rerun, ROS/native/action/source changes.',
          'freeze': FREEZE, 'native_gate_verdict': 'FAIL preserved'}
try:
    code = read(SOURCE)
    frozen = subprocess.check_output(['git', 'show', FREEZE + ':' + SOURCE.relative_to(ROOT).as_posix()], cwd=ROOT)
    if code != frozen:
        raise ValueError('benchmark differs from episode freeze')
    reader = read(PHYSICS_SOURCE)
    if sha(reader) != '2516e394f60eac5dd24fd66b51c4c48fc37245090eb1626ebe1c7a3a23f8bafb':
        raise ValueError('immutable physical consumer changed')
    physical = json.loads(read(PHYSICS))
    selected = {'_probe_goal_order', 'probe_action', 'probe_action_v3', 'probe_action_v4',
                'probe_action_v5', 'probe_action_v6', '_probe_nonapproaching_goal_action',
                'record_probe_v4_submission'}
    functions = [node for node in ast.parse(code).body
                 if isinstance(node, ast.FunctionDef) and node.name in selected]
    module = {'math': math}
    exec(compile(ast.Module(body=functions, type_ignores=[]), str(SOURCE), 'exec'), module)
    episodes = []
    for name in ('episode002_open_101', 'episode003_rooms_101'):
        episode = BASE / name
        metadata = json.loads(read(episode / 'metadata.json'))
        if metadata['freeze'] != FREEZE:
            raise ValueError('episode freeze differs')
        payload = read(episode / 'transitions.jsonl')
        if not payload.endswith(b'\n'):
            raise ValueError('incomplete returned ledger')
        rows = [json.loads(line) for line in payload.splitlines()]
        if len(rows) != 33 or rows[-1]['truncated'] is not True:
            raise ValueError('episode not complete32-step external truncation')
        diagnostic = {}
        commands = []
        snapshots = []
        for index, row in enumerate(rows):
            snap = row['snapshot']
            robot = snap['robots'][0]
            nav = robot['navigation']
            snapshots.append({'elapsed': snap['task_elapsed_sec'], 'clock': snap['source_stamp'],
                              'snapshot_sequence': snap['sequence'], 'x': robot['x'], 'y': robot['y'],
                              'received_scalar_v': robot['v'], 'received_scalar_w': robot['w'],
                              'fresh': robot['fresh'], 'valid': robot['valid'],
                              'navigation_phase': nav['phase'], 'owned': nav['owned'],
                              'goal_id': nav.get('goal_id'), 'last_goal_id': nav.get('last_goal_id'),
                              'accepted_goal_count': nav.get('accepted_goal_count'),
                              'commitment_remaining_sec': nav.get('commitment_remaining_sec'),
                              'last_terminal': nav.get('last_terminal'),
                              'received_path_m': robot['activity']['estimated_path_m']})
            if index == 32:
                continue
            chosen = module['probe_action_v6'](snap, diagnostic)
            info = rows[index + 1]['info']
            command = info['command']
            if chosen != command['action']:
                raise ValueError('V6 pure replay differs from actual returned command')
            pending = dict(diagnostic['v4_stimulus']['pending_submission'])
            module['record_probe_v4_submission'](diagnostic, info)
            commands.append({'input_elapsed': snap['task_elapsed_sec'],
                             'input_snapshot_sequence': snap['sequence'],
                             'command_id': command['command_id'], 'created_at': command['created_at'],
                             'action': chosen, 'tb1_component': chosen // 100,
                             'tb1_original_mask_allowed': snap['per_robot_action_mask'][0][chosen // 100],
                             'joint_mask_allowed': snap['joint_action_mask'][chosen],
                             'reason': pending['reasons'].get('tb1'),
                             'typed_submission_verified': True})
        report = next(item for item in physical['episodes'] if item['directory'] == str(episode))
        tb1 = report['robots']['tb1']
        bad_a = [item for item in tb1['stop_responses'] if item['status'] != 'sampled_response_within_declared_bounds']
        bad_b = [item for item in tb1['cancel_stop_responses'] if item['status'] != 'sampled_response_within_declared_bounds']
        if len(bad_a) != 1 or len(bad_b) != 1:
            raise ValueError('unexpected original failed A/B shape')
        event = bad_b[0]
        matched_wait = next(item for item in commands
                            if round(item['created_at'] * 1e9) == event['cancel_clock_ns'])
        if matched_wait['tb1_component'] != 9:
            raise ValueError('native cancel does not align actual WAIT input')
        after = [item for item in commands if item['created_at'] >= matched_wait['created_at']]
        post_snapshots = [item for item in snapshots if item['clock'] > matched_wait['created_at']]
        if not after or not all(item['tb1_component'] == 9 for item in after):
            raise ValueError('TB1 original action stream did not hold WAIT')
        if event['new_goal_clock_ns'] is not None:
            raise ValueError('physical reader reports a later new GOAL')
        if not all(item['accepted_goal_count'] == 2 and item['navigation_phase'] == 'idle'
                   and item['last_goal_id'] == event['goal_id'] for item in post_snapshots):
            raise ValueError('received ownership/count changed after cancel')
        first = post_snapshots[0]
        last = post_snapshots[-1]
        episodes.append({'directory': str(episode), 'epoch': metadata['epoch'],
                         'release_clock': snapshots[0]['clock'], 'end_clock': snapshots[-1]['clock'],
                         'all32_actions_equal_actual_typed_commands': True,
                         'actual_tb1_GOAL_commands': [item for item in commands if item['tb1_component'] < 8],
                         'matched_failed_native_cancel_and_actual_WAIT': {'native_B': event,
                                                                          'actual_WAIT': matched_wait,
                                                                          'failed_A': bad_a[0]},
                         'WAIT_commands_through_end': after,
                         'second_round_tb1_latch': diagnostic['v4_stimulus']['rounds']['second']['waits']['tb1'],
                         'post_cancel_received_snapshots': post_snapshots,
                         'no_new_GOAL_commands_or_accepted_goals_after_failed_cancel': True,
                         'post_first_return_to_end_pose_chord_m': math.hypot(last['x'] - first['x'], last['y'] - first['y']),
                         'post_first_return_to_end_received_activity_increment_m': last['received_path_m'] - first['received_path_m'],
                         'physical_original_summary': {key: tb1[key] for key in (
                             'physical_evidence_complete', 'hard_zero_evidence_complete',
                             'cancel_end_to_end_evidence_complete', 'bound_violation_counts',
                             'eligible_stop_events', 'credited_sampled_stop_events',
                             'eligible_cancel_stop_events', 'credited_cancel_stop_events')},
                         'conclusion': 'Actual command19/t18 WAIT is submitted and latched through '
                                       'command32, not replaced by a late GOAL. Received navigation '
                                       'is idle with same goal14 identity and acceptedCount2. '
                                       'Original B has real cancel/result and no newGoal cutoff. '
                                       'Thus a later GOAL/reassigned ownership does not explain '
                                       'the original delayed/missing physical rest.'})
    stable = all(sha(Path(path).read_bytes()) == digest for path, digest in INPUTS.items())
    if not stable:
        raise ValueError('inputs changed during diagnostic')
    result.update(passed=True, episodes=episodes, source_before_after_stable=True,
                  measurement_limitations=[
                      'WAIT is high-level input. This diagnostic does not independently reread '
                      'all finalguard/native actuation raw rows, so does not newly prove every '
                      '20ms driver target or physical wheel output stayed zero.',
                      'The existing physical reader A uses final-linear-zero and limits its '
                      'response window at next nonzero final linear output; resumed-before-rest '
                      'would be labelled separately. These failures are observed_bound_violation '
                      'or missing_rest_evidence, not resumed_before_proven_rest.',
                      'Snapshot v is a scalar forward component. Small received v or position '
                      'chord does not prove full raw planar norm<=.01, and cannot invalidate '
                      'the original rest-latency failure. No noise/false-positive claim.'])
except Exception as error:
    result['passed'] = False
    result['error'] = type(error).__name__ + ': ' + str(error)
result['input_sha256'] = INPUTS
result['tool_sha256'] = sha(Path(__file__).read_bytes())
result['wall_seconds'] = time.monotonic() - started
with OUTPUT.open('x') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
print(json.dumps({'output': str(OUTPUT), 'sha256': sha(OUTPUT.read_bytes()),
                  'passed': result['passed'], 'error': result.get('error'),
                  'episodes': [{'epoch': item['epoch'],
                                'WAIT_command_id': item['matched_failed_native_cancel_and_actual_WAIT']['actual_WAIT']['command_id'],
                                'WAIT_created_at': item['matched_failed_native_cancel_and_actual_WAIT']['actual_WAIT']['created_at'],
                                'WAIT_count_through_end': len(item['WAIT_commands_through_end']),
                                'last_goal_id': item['matched_failed_native_cancel_and_actual_WAIT']['native_B']['goal_id'],
                                'no_later_GOAL': item['no_new_GOAL_commands_or_accepted_goals_after_failed_cancel'],
                                'final_pose_chord_from_first_postcancel_return': item['post_first_return_to_end_pose_chord_m']}
                               for item in result.get('episodes', [])]}, indent=2))
raise SystemExit(0 if result['passed'] else 1)
