"""Mechanical V19 byte-custody entry point derivation; old helper stays immutable."""
import ast
import hashlib
import json
from pathlib import Path

OLD = Path('/tmp/mr3_p2a0_v18_pack_closed_baseline_v1.py')
NEW = Path('/tmp/mr3_p2a0_v19_pack_closed_baseline_v1.py')
TEST_OLD = Path('/tmp/mr3_p2a0_v18_pack_closed_baseline_tests_v1.py')
TEST_NEW = Path('/tmp/mr3_p2a0_v19_pack_closed_baseline_tests_v1.py')
OUT = Path('/tmp/mr3_p2a0_v19_pack_closed_baseline_derivation_v1.json')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    original, old_tests = OLD.read_bytes(), TEST_OLD.read_bytes()
    text = original.decode()
    changes = []

    def replace(before, after, count=1):
        nonlocal text
        assert text.count(before) == count, before
        text = text.replace(before, after)
        changes.append({'before': before, 'after': after, 'occurrences': count})

    replace('v18', 'v19', text.count('v18'))
    replace('WORKERS = 3', 'WORKERS = 2')
    replace("    assert execution['passed'] is False, 'original V18 stageFAIL must not be relabeled'",
            "    assert execution['passed'] is True, 'closed V19 baseline must retain its actual PASS'")
    anchor = "    assert type(execution['freeze']) is str and len(execution['freeze']) == 40\n"
    closed = '''    assert execution['errors'] == [] and execution['returncode'] == 0
    artifacts = []
    consumers = execution['diagnostic_consumers']
    assert [row['label'] for row in consumers] == ['observer_1ms', 'original_physical']
    for row in consumers:
        assert row['passed'] is True and row['returncode'] == 0 and row['errors'] == []
        artifact_path = Path(row['output']['path'])
        artifact_raw = artifact_path.read_bytes()
        assert sha(artifact_raw) == row['output']['sha256']
        assert json.loads(artifact_raw)['passed'] is True
        artifacts.append({'source': str(artifact_path), 'sha256': sha(artifact_raw),
                          'bytes': len(artifact_raw), 'original_passed': True})
'''
    replace(anchor, anchor + closed)
    anchor = "    assert summary_path.read_bytes() == summary_raw, 'closed benchmark summary changed'\n"
    replace(anchor, anchor + "    for artifact in artifacts:\n        assert sha(Path(artifact['source']).read_bytes()) == artifact['sha256'], 'closed consumer artifact changed'\n")
    replace("'pass_scope': 'Lossless byte custody and codec/stat verification only; original stage is FAIL.'",
            "'pass_scope': 'Lossless byte custody and codec/stat verification only; stage results copied from completed original.'")
    replace("'original_stage_passed': False", "'original_stage_passed': execution['passed']")
    replace("        'followup_iters150_originally_skipped': True,\n",
            "        'closed_consumer_artifacts': artifacts,\n")
    derived = text.encode()
    tests = old_tests.decode().replace('v18', 'v19').encode()
    inverse = text
    for change in reversed(changes):
        assert inverse.count(change['after']) == change['occurrences']
        inverse = inverse.replace(change['after'], change['before'])
    assert inverse.encode() == original
    old_tree, new_tree = ast.parse(original), ast.parse(derived)
    unchanged_functions = []
    for node in old_tree.body:
        if not isinstance(node, ast.FunctionDef) or node.name == 'main':
            continue
        other = next(row for row in new_tree.body
                     if isinstance(row, ast.FunctionDef) and row.name == node.name)
        assert ast.get_source_segment(original.decode(), node) == ast.get_source_segment(text, other)
        unchanged_functions.append(node.name)
    assert OLD.read_bytes() == original and TEST_OLD.read_bytes() == old_tests
    for path, raw in ((NEW, derived), (TEST_NEW, tests)):
        with path.open('xb') as stream:
            stream.write(raw)
    receipt = {'passed': True, 'source_old': {'path': str(OLD), 'sha256': sha(original)},
               'source_new': {'path': str(NEW), 'sha256': sha(derived)},
               'tests_old': {'path': str(TEST_OLD), 'sha256': sha(old_tests)},
               'tests_new': {'path': str(TEST_NEW), 'sha256': sha(tests)},
               'old_sources_unchanged': True, 'whole_source_inverse_exact': True,
               'core_functions_byte_identical': unchanged_functions, 'changes': changes,
               'scope': 'Custody-only source derivation. No native/formal execution or active counterpart evidence read.'}
    with OUT.open('x') as stream:
        json.dump(receipt, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'passed': True, 'source_new_sha256': sha(derived),
                      'unchanged_core_functions': unchanged_functions}))


if __name__ == '__main__':
    main()
