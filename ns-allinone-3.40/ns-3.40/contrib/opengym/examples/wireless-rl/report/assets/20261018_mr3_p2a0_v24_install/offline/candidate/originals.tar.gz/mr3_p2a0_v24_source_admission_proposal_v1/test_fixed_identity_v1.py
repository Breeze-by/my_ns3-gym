"""New method-level fixed identity checks; only Git I/O is substituted, no full loader."""
from pathlib import Path
import ast
import copy
import gzip
import hashlib
import json
import subprocess
import unittest
from unittest.mock import patch

B = Path(__file__).resolve().parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
SOURCE = B / 'audit_ppo.proposed_v24.py'
FUNCTIONS = {'require', 'sha', 'verify_frozen_pins', 'verify_environment_appendix', 'verify_ray_box_library'}
CONSTANTS = {'WIRELESS', 'ROS', 'ENV_DOCUMENT_SHA256', 'ENV_NORMATIVE_FREEZE', 'ENV_NORMATIVE_SHA256',
             'ENV_EXECUTION_APPENDIX_SHA256', 'ENV_EXECUTION_APPENDIX_BYTES', 'RAY_BOX_SOURCE_PINS', 'RAY_BOX_LIBRARY_SPEC'}
selected = []
for node in ast.parse(SOURCE.read_bytes()).body:
    if (isinstance(node, ast.FunctionDef) and node.name in FUNCTIONS or
        isinstance(node, ast.Assign) and len(node.targets) == 1 and
        isinstance(node.targets[0], ast.Name) and node.targets[0].id in CONSTANTS):
        selected.append(copy.deepcopy(node))
ns = dict(Path=Path, hashlib=hashlib, gzip=gzip, json=json, subprocess=subprocess)
exec(compile(ast.Module(body=selected, type_ignores=[]), str(SOURCE), 'exec'), ns)

class FixedIdentity(unittest.TestCase):
    def call(self, function, mutate_environment=None, mutate_library=None, repin_environment=False):
        original_git, original_read = subprocess.check_output, Path.read_bytes
        env = ROOT / ns['WIRELESS'] / 'MR3_ENV_CONTRACT.md'
        proposed = (B / 'MR3_ENV_CONTRACT.proposed_pending_v3.md').read_bytes()
        if mutate_environment is not None:
            proposed = mutate_environment(proposed)
        library = ROOT / ns['RAY_BOX_LIBRARY_SPEC']['library']['path']
        def read(path):
            if path == env:
                return proposed
            raw = original_read(path)
            return mutate_library(raw) if path == library and mutate_library is not None else raw
        def git(command, **kwargs):
            if command[:2] == ['git', 'show'] and command[2].startswith('a'*40+':'):
                return read(ROOT / command[2].split(':', 1)[1])
            return original_git(command, **kwargs)
        expected = ns['ENV_DOCUMENT_SHA256']
        if repin_environment:
            ns['ENV_DOCUMENT_SHA256'] = hashlib.sha256(proposed).hexdigest()
        try:
            with patch.object(Path, 'read_bytes', read), patch.object(subprocess, 'check_output', git):
                return ns[function](ROOT, 'a'*40)
        finally:
            ns['ENV_DOCUMENT_SHA256'] = expected

    def test_actual_A24_782d_and_full_append_only_environment(self):
        proof = self.call('verify_ray_box_library')
        self.assertEqual(len(proof), 3)
        row = proof[ns['RAY_BOX_LIBRARY_SPEC']['receipt']['path']]
        self.assertEqual(row['installed_library_sha256'],
                         '782d388fea8df3646524e54f41d71de5f53480b9d04cc0ea1c453c70e2c1f7d8')
        self.assertEqual(row['compiled_source_sha256'][ns['ROS']+'src/multi_robot/src/mr3_ray_box_corrector.cpp'],
                         'f82646c8434b77c42f585ac1828eda84640bac873f70cc7de6848cfbd6493473')
        self.assertTrue(self.call('verify_environment_appendix')['append_only_normative_prefix_exact'])

    def test_actual_elf_bad_bytes_are_rejected(self):
        with self.assertRaisesRegex(ValueError, 'actual installed ELF differs'):
            self.call('verify_ray_box_library', mutate_library=lambda raw: raw[:-1]+bytes([raw[-1]^1]))

    def test_environment_prefix_cannot_be_changed_even_repinned(self):
        with self.assertRaisesRegex(ValueError, 'normative whole prefix'):
            self.call('verify_environment_appendix',
                      mutate_environment=lambda raw: bytes([raw[0]^1])+raw[1:], repin_environment=True)

    def test_exact_five_constant_inverse_restores_all_functions_and_bytes(self):
        proof = json.loads((B / 'auditor_identity_handoff_v1.json').read_bytes())
        self.assertEqual({row['constant'] for row in proof['changed_constants']},
                         {'ENV_DOCUMENT_SHA256', 'ENV_EXECUTION_APPENDIX_SHA256',
                          'ENV_EXECUTION_APPENDIX_BYTES', 'RAY_BOX_SOURCE_PINS', 'RAY_BOX_LIBRARY_SPEC'})
        text = SOURCE.read_text()
        for row in reversed(proof['changed_constants']):
            self.assertEqual(text.count(row['after']), 1)
            text = text.replace(row['after'], row['before'], 1)
        old = (B / 'baseline_auditor.py').read_bytes()
        self.assertEqual(text.encode(), old)
        self.assertEqual(ast.dump(ast.parse(text)), ast.dump(ast.parse(old)))

if __name__ == '__main__':
    unittest.main(verbosity=2)
