"""CPU-only actual ELF/link/install and deterministic archive custody."""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import time

ROOT=Path('/home/zhuyulab/ns3-workspace')
WS=ROOT/'ros2_ws/ros2-multi-robot-automap'
OUT=Path('/tmp/mr3_p2a0_v18_binary_custody_v1')
CANONICAL=Path('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v18/build')
INPUTS={}
COMMANDS=[]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ident(value):
    return {key:getattr(value,key) for key in ('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns')}


def capture(path):
    with path.open('rb') as stream:
        before=ident(os.fstat(stream.fileno()))
        data=stream.read()
        after=ident(os.fstat(stream.fileno()))
    linked=ident(path.stat())
    if before!=after or after!=linked or len(data)!=after['st_size']:
        raise ValueError('input changed while captured: '+str(path))
    INPUTS[str(path)]={'sha256':sha(data),'bytes':len(data),'stat':after}
    return data


def encode(data):
    buffer=io.BytesIO()
    with gzip.GzipFile(filename='',mode='wb',fileobj=buffer,mtime=0,compresslevel=9) as compressed:
        compressed.write(data)
    return buffer.getvalue()


def archive(data,name):
    encoded=encode(data)
    if encoded!=encode(data) or gzip.decompress(encoded)!=data:
        raise ValueError('deterministic gzip/decoded roundtrip mismatch')
    path=OUT/name
    with path.open('xb') as output:
        output.write(encoded)
    return {'prepared_path':str(path),'canonical_path':str(CANONICAL/name),
            'encoding':'gzip','raw_sha256':sha(data),'raw_bytes':len(data),
            'encoded_sha256':sha(encoded),'encoded_bytes':len(encoded),
            'decoded_sha256':sha(gzip.decompress(encoded)),
            'deterministic_reencode_equal':True}


def command(argv,name):
    start=time.monotonic()
    utc=datetime.now(timezone.utc).isoformat()
    result=subprocess.run(argv,cwd=WS,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    target=OUT/(name+'.log')
    with target.open('xb') as output:
        output.write(result.stdout)
    receipt={'argv':argv,'cwd':str(WS),'start_utc':utc,
             'end_utc':datetime.now(timezone.utc).isoformat(),
             'wall_sec':time.monotonic()-start,'exit_code':result.returncode,
             'stdout':str(target),'stdout_sha256':sha(result.stdout)}
    COMMANDS.append(receipt)
    return receipt,result.stdout


def main():
    OUT.mkdir()
    start=time.monotonic()
    errors=[]
    libraries={}
    build_path=Path('/tmp/mr3_p2a0_v18_build_execution_v1.json')
    build_data=capture(build_path)
    build=json.loads(build_data)
    if build.get('passed') is not True or build.get('returncode')!=0 or build.get('sources_stable') is not True:
        errors.append('upstream canonical CPU build did not pass/source stable')
    if build.get('original_driver_before')!='a014f2c618e38fc8a306d76c100083d952606333045a2e35bffce6f8b25b10c8' or build.get('original_driver_after')!=build.get('original_driver_before'):
        errors.append('original driver identity changed')
    original_receipts=[]
    for path in (build_path,Path(build['console']),Path('/tmp/mr3_p2a0_v18_build_v1.py')):
        raw=build_data if path==build_path else capture(path)
        original_receipts.append(dict(source=str(path),**archive(raw,path.name+'.gz')))
    compile_path=WS/'build/multi_robot/compile_commands.json'
    compile_bytes=capture(compile_path)
    compile_commands=json.loads(compile_bytes)
    original_receipts.append(dict(source=str(compile_path),**archive(compile_bytes,'compile_commands.json.gz')))
    for role,stem,macro in [
        ('observer','mr3_stop_response_observer','MR3_OBSERVER_SOURCE_SHA256'),
        ('profile','mr3_physics_diagnostic_profile','MR3_PHYSICS_DIAGNOSTIC_SOURCE_SHA256')]:
        try:
            source=WS/'src/multi_robot/src'/(stem+'.cpp')
            source_bytes=capture(source)
            source_sha=sha(source_bytes)
            if build['source_after'].get(str(source))!=source_sha:
                raise ValueError('source does not match canonical build receipt')
            library=WS/'build/multi_robot'/('lib'+stem+'.so')
            installed=WS/'install/multi_robot/lib'/library.name
            raw=capture(library)
            installed_bytes=capture(installed)
            if not raw.startswith(b'\x7fELF'):
                raise ValueError('not an ELF library')
            if raw!=installed_bytes or library.resolve()!=installed.resolve():
                raise ValueError('build/install library identity differs')
            entries=[r for r in compile_commands if r['file']==str(source)]
            if len(entries)!=1:
                raise ValueError('no unique actual compiler command')
            args=entries[0].get('arguments') or shlex.split(entries[0]['command'])
            definitions=[a.split('=',1)[1].strip('"') for a in args if a.startswith('-D'+macro+'=')]
            if definitions!=[source_sha] or source_sha.encode() not in raw:
                raise ValueError('compiler macro or actual ELF embedded source digest mismatch')
            dependency,depbytes=command(['/usr/bin/ldd','-r',str(library)],role+'_ldd_r_v1')
            headers,headerbytes=command(['/usr/bin/readelf','-h',str(library)],role+'_readelf_h_v1')
            dependency_text=depbytes.decode(errors='replace')
            unresolved=bool(re.search(r'undefined symbol|not found',dependency_text,re.IGNORECASE))
            elf_dyn=bool(re.search(r'Type:\s+DYN\b',headerbytes.decode(errors='replace')))
            if dependency['exit_code']!=0 or unresolved or headers['exit_code']!=0 or not elf_dyn:
                errors.append(role+': ELF dependency or DYN check failed')
            preserved=archive(raw,library.name+'.gz')
            libraries[role]={
                'source_path':str(source.relative_to(ROOT)),'source_sha256':source_sha,
                'library_path':str(library),'installed_path':str(installed),
                'installed_is_symlink':installed.is_symlink(),
                'installed_symlink_target':os.readlink(installed) if installed.is_symlink() else None,
                'installed_resolved_path':str(installed.resolve()),
                'library_sha256':sha(raw),'library_bytes':len(raw),
                'archived_library_gzip':preserved['canonical_path'],
                'archived_library_encoded_sha256':preserved['encoded_sha256'],
                'prepared_archive_path':preserved['prepared_path'],
                'archived_library_encoded_bytes':preserved['encoded_bytes'],
                'decoded_library_sha256':preserved['decoded_sha256'],
                'gzip_deterministic_roundtrip':True,'build_install_exact_bytes':True,
                'source_macro':macro,'actual_compile_definition_sha256':definitions[0],
                'actual_compile_command':entries[0],
                'embedded_source_sha_occurrences':raw.count(source_sha.encode()),
                'elf_dynamically_linked_library':elf_dyn,
                'ldd_r':dependency,'undefined_or_missing_dependency':unresolved,
                'readelf_h':headers}
        except Exception as exc:
            errors.append(role+': '+repr(exc))
    for path,binding in INPUTS.items():
        current=Path(path)
        # Exact source/content and path identity are rechecked after dependency work.
        if ident(current.stat())!=binding['stat'] or sha(current.read_bytes())!=binding['sha256']:
            errors.append('input changed before final seal: '+path)
    selected_env={k:os.environ.get(k) for k in ('PATH','LD_LIBRARY_PATH','AMENT_PREFIX_PATH',
        'CMAKE_PREFIX_PATH','COLCON_PREFIX_PATH','PYTHONPATH','PYTHONNOUSERSITE',
        'PYTHONDONTWRITEBYTECODE','ROS_DISTRO','ROS_VERSION','RMW_IMPLEMENTATION')}
    if selected_env['ROS_DISTRO']!='humble' or selected_env['PYTHONNOUSERSITE']!='1':
        errors.append('not declared system Humble environment')
    receipt={'schema':'mr3-stop-observer-binary-build-receipt-v1',
        'passed':not errors and set(libraries)=={'observer','profile'},'errors':errors,
        'libraries':libraries,'build_execution':{'source':str(build_path),'sha256':sha(build_data),
            'upstream_passed':build.get('passed'),'build_wall_sec':build.get('wall_seconds')},
        'original_driver_before_sha256':build.get('original_driver_before'),
        'original_driver_after_sha256':build.get('original_driver_after'),
        'original_build_artifacts':original_receipts,'input_bindings':INPUTS,
        'commands':COMMANDS,'environment':selected_env,'wall_sec':time.monotonic()-start,
        'end_utc':datetime.now(timezone.utc).isoformat(),
        'helper_source_sha256':sha(Path(__file__).read_bytes()),
        'scope':'CPU-only actual ELF/link/install/source and deterministic gzip custody. No plugin load, Gazebo/native, formal audit, control publisher or parameter setter. Archives are prepared in /tmp for subsequent root copying; canonical archive paths are prospective.'}
    target=OUT/'build_receipt_v1.json'
    with target.open('x') as output:
        json.dump(receipt,output,indent=2)
        output.write('\n')
    print(json.dumps({'passed':receipt['passed'],'errors':errors,'receipt':str(target),
                      'receipt_sha256':sha(target.read_bytes()),'wall_sec':receipt['wall_sec'],
                      'libraries':{k:{x:r[x] for x in ('source_sha256','library_sha256','library_bytes',
                        'archived_library_encoded_sha256','archived_library_encoded_bytes')}
                                   for k,r in libraries.items()}},indent=2))
    return 0 if receipt['passed'] else 1


if __name__=='__main__':
    sys.exit(main())
