"""Only read /proc and native files; invoke frozen read-only observer every35s."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT=Path('/home/zhuyulab/ns3-workspace')
FREEZE='631d8c35c43fdb7ed45e984376543e55395066ef'
SCRIPT=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v10/independent/mr3_readonly_v10_drive_process_monitor.py'
SHA='7126969f615d768c5b8fe18039ffd5e0f9d090941e7a857e75b2c44436fb3d13'
LAUNCH=Path('/tmp/mr3_p2a0_v10_interface_launch.json')
BINARY=Path('/tmp/mr3_p2a0_v10_binaryproof.json')
RUN=ROOT/'ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261017_v10_interface'
CALLS=Path('/tmp/mr3_p2a0_v10_interface_monitor_calls_v1.jsonl')
assert not CALLS.exists()
started=time.monotonic()
index=1
last=None
with CALLS.open('x')as calls:
 while time.monotonic()-started<2400:
  launch=json.loads(LAUNCH.read_bytes())if LAUNCH.exists()else None
  state=launch.get('status')if launch else 'awaiting_launch'
  if launch and 'benchmark_parent'in launch and BINARY.exists():
   assert launch['freeze']==FREEZE
   assert hashlib.sha256(SCRIPT.read_bytes()).hexdigest()==SHA
   output=Path(f'/tmp/mr3_p2a0_v10_interface_process_monitor_{index:03d}.json')
   console=Path(f'/tmp/mr3_p2a0_v10_interface_process_monitor_{index:03d}.console.log')
   assert not output.exists()and not console.exists()
   cmd=['/usr/bin/python3',str(SCRIPT),str(RUN),'--launch',str(LAUNCH),'--binary-proof',str(BINARY),'--output',str(output)]
   with console.open('x')as f:
    proc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1'),timeout=30)
   result=json.loads(output.read_bytes())if output.exists()else {}
   good=[g for g in result.get('gazebo_mapped_libraries',[])if g['new_drive_mapped']and not g['old_system_drive_mapped']and g['identity_still_same_after_maps']and g['mappings']and all(x['matches_declared_binary']for x in g['mappings'])]
   item={'capture':index,'status':state,'argv':cmd,'returncode':proc.returncode,'output':str(output),'sha256':hashlib.sha256(output.read_bytes()).hexdigest()if output.exists()else None,'owned_current':len(result.get('owned_current_processes',[])),'mapped_gz_identities':[g['identity']for g in good],'errors':result.get('errors',[]),'episode_directories':[e['directory']for e in result.get('episodes',[])],'wall_monotonic_ns':time.monotonic_ns()}
   calls.write(json.dumps(item)+'\n');calls.flush();print(json.dumps(item),flush=True)
   index+=1
   if state in('completed','failed'):
    break
  elif state!=last:
   print(json.dumps({'status':state,'read_only':True,'wall_monotonic_ns':time.monotonic_ns()}),flush=True)
  last=state
  time.sleep(35)
print(json.dumps({'monitor_loop_finished':True,'captures':index-1,'wall_seconds':time.monotonic()-started,'no_process_control':True}),flush=True)
