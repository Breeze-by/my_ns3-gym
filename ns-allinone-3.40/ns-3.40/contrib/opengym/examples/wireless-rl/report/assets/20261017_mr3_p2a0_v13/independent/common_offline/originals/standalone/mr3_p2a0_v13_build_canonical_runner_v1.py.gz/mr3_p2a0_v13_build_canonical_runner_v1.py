import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time


ROOT = Path('/home/zhuyulab/ns3-workspace')
WS = ROOT / 'ros2_ws/ros2-multi-robot-automap'
OUT = Path('/tmp/mr3_p2a0_v13_build_canonical_v1')
OUT.mkdir(exist_ok=False)
PACKAGE = WS / 'src/multi_robot'
SOURCE_REL = [
    'src/mr3_gazebo_diff_drive.cpp',
    'include/multi_robot/mr3_gazebo_diff_drive.hpp',
    'include/multi_robot/paired_wheel_slew.hpp',
    'include/multi_robot/mr3_drive_target.hpp',
    'test/test_paired_wheel_slew.cpp',
    'test/test_drive_target.cpp',
    'CMakeLists.txt',
    'package.xml',
]
MACROS = dict(zip([
    'MR3_DRIVE_SOURCE_SHA256', 'MR3_DRIVE_HEADER_SHA256',
    'MR3_DRIVE_HELPER_SHA256', 'MR3_DRIVE_TARGET_SHA256',
], SOURCE_REL[:4]))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def hashes():
    return {str(PACKAGE / rel): sha((PACKAGE / rel).read_bytes()) for rel in SOURCE_REL}


def save_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def run(name, argv, env):
    start = time.monotonic()
    with (OUT / (name + '.log')).open('xb') as stream:
        result = subprocess.run(argv, cwd=WS, env=env, stdout=stream, stderr=subprocess.STDOUT)
    item = {'argv': argv, 'cwd': str(WS), 'returncode': result.returncode,
            'wall_seconds': time.monotonic() - start,
            'stdout_file': str(OUT / (name + '.log')),
            'stdout_sha256': sha((OUT / (name + '.log')).read_bytes())}
    save_json(OUT / (name + '.json'), item)
    print(json.dumps(item), flush=True)
    return item


started = time.monotonic()
base = os.environ.copy()
removed = {}
for key in list(base):
    if key.startswith('CONDA') or key in {'PYTHONPATH', 'PYTHONHOME', 'VIRTUAL_ENV', 'AMENT_PREFIX_PATH', 'COLCON_PREFIX_PATH', 'CMAKE_PREFIX_PATH'}:
        removed[key] = base.pop(key)
base['PATH'] = '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
base['PYTHONNOUSERSITE'] = '1'
env_argv = ['/bin/bash', '--noprofile', '--norc', '-c',
            'source /opt/ros/humble/setup.bash\nexec /usr/bin/python3 -c "import json,os;print(json.dumps(dict(os.environ)))"']
env_result = subprocess.run(env_argv, cwd=WS, env=base, capture_output=True, check=True, text=True)
ros_env = json.loads(env_result.stdout)
env_keys = ['PATH', 'PYTHONPATH', 'PYTHONHOME', 'PYTHONNOUSERSITE', 'CONDA_PREFIX',
            'CONDA_DEFAULT_ENV', 'AMENT_PREFIX_PATH', 'COLCON_PREFIX_PATH',
            'CMAKE_PREFIX_PATH', 'LD_LIBRARY_PATH', 'ROS_DISTRO', 'ROS_VERSION',
            'ROS_PYTHON_VERSION', 'RMW_IMPLEMENTATION', 'ROS_DOMAIN_ID', 'GAZEBO_PLUGIN_PATH']
save_json(OUT / 'environment.json', {
    'setup_argv': env_argv,
    'removed_inherited_variable_names': sorted(removed),
    'selected_actual_build_environment': {key: ros_env.get(key) for key in env_keys},
    'system_python_realpath': str(Path('/usr/bin/python3').resolve()),
    'conda_path_absent': 'conda' not in ros_env['PATH'].lower(),
})
before = hashes()
save_json(OUT / 'source_before.json', before)
argv = ['/usr/bin/python3', '/usr/bin/colcon', 'build', '--symlink-install',
        '--allow-overriding', 'nav2_bringup', '--packages-select',
        'multi_robot', 'multi_robot_exploration', '--cmake-force-configure',
        '--cmake-args', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']
build = run('colcon_build', argv, ros_env)
result = {'schema': 'mr3-p2a0-v13-canonical-build-checks-v1',
          'scope': 'system ROS canonical build and two C++ CPU test groups; no simulator or training',
          'build': build, 'source_before': before,
          'extra_cmake_flag_scope': 'compile command evidence export only',
          'checks': {}, 'passed': False}
if build['returncode'] == 0:
    cmake_build = WS / 'build/multi_robot'
    commands = cmake_build / 'compile_commands.json'
    flags = cmake_build / 'CMakeFiles/mr3_gazebo_diff_drive.dir/flags.make'
    shutil.copyfile(commands, OUT / 'compile_commands.json')
    shutil.copyfile(flags, OUT / 'drive_flags.make')
    compile_commands = json.loads(commands.read_text())
    driver_commands = [value for value in compile_commands
                       if Path(value['file']).name == 'mr3_gazebo_diff_drive.cpp']
    save_json(OUT / 'drive_compile_commands.json', driver_commands)
    flag_text = flags.read_text()
    compiled = {}
    for macro, rel in MACROS.items():
        matches = re.findall(macro + r'=\\?"([0-9a-f]{64})\\?"', flag_text)
        if len(matches) != 1:
            raise RuntimeError('expected exactly one compiled macro: ' + macro)
        compiled[macro] = {'compiled_sha256': matches[0], 'source_path': str(PACKAGE / rel),
                           'actual_sha256': sha((PACKAGE / rel).read_bytes())}
    library = WS / 'install/multi_robot/lib/libmr3_gazebo_diff_drive.so'
    resolved = library.resolve(strict=True)
    binary = resolved.read_bytes()
    result['library'] = {'installed_path': str(library), 'is_symlink': library.is_symlink(),
                         'symlink_target': os.readlink(library) if library.is_symlink() else None,
                         'resolved_path': str(resolved), 'bytes': len(binary), 'sha256': sha(binary),
                         'samefile_as_build': os.path.samefile(library, cmake_build / library.name),
                         'compiled_sources': compiled}
    result['checks']['four_macro_sources_match'] = all(
        value['compiled_sha256'] == value['actual_sha256'] for value in compiled.values())
    result['checks']['four_source_hashes_embedded_in_binary'] = all(
        value['actual_sha256'].encode() in binary for value in compiled.values())
    result['checks']['single_driver_compile_command'] = len(driver_commands) == 1
    result['checks']['installed_symlink_targets_canonical_build'] = (
        library.is_symlink() and result['library']['samefile_as_build'] and
        resolved == cmake_build / library.name)
    test = run('canonical_cpp_ctest', ['/usr/bin/ctest', '--test-dir', str(cmake_build),
               '-R', '^(test_paired_wheel_slew|test_drive_target)$', '--output-on-failure'], ros_env)
    result['tests'] = test
    result['checks']['canonical_two_cpp_groups_passed'] = test['returncode'] == 0
    xml = {}
    for name in ['test_paired_wheel_slew', 'test_drive_target']:
        path = cmake_build / 'test_results/multi_robot' / (name + '.gtest.xml')
        if path.exists():
            shutil.copyfile(path, OUT / path.name)
            xml[name] = {'path': str(path), 'sha256': sha(path.read_bytes())}
    result['gtest_xml'] = xml
    result['checks']['both_canonical_gtest_xml_present'] = len(xml) == 2
after = hashes()
result['source_after'] = after
result['checks']['owned_sources_unchanged_during_build'] = before == after
result['wall_seconds'] = time.monotonic() - started
result['passed'] = build['returncode'] == 0 and all(result['checks'].values())
save_json(OUT / 'checks.json', result)
print(json.dumps({'receipt': str(OUT / 'checks.json'), 'sha256': sha((OUT / 'checks.json').read_bytes()),
                  'passed': result['passed'], 'wall_seconds': result['wall_seconds']}), flush=True)
raise SystemExit(0 if result['passed'] else 1)
