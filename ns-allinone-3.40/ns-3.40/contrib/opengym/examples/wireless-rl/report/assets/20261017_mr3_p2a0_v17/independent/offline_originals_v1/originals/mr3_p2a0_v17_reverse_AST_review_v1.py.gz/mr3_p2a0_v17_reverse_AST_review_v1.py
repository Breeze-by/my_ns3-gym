import pathlib,json,ast,hashlib,subprocess
R=pathlib.Path("/home/zhuyulab/ns3-workspace");D=pathlib.Path("/tmp/mr3_p2a0_v17_matrix_draft_v1");C=pathlib.Path("/tmp/mr3_p2a0_v17_matrix_mechanical_checks_v1");sha=lambda raw:hashlib.sha256(raw).hexdigest()
g=json.loads((D/"generation_v1.json").read_bytes());rows=[]
for r in g["files"]:
 old=(subprocess.check_output(["git","show",r["source_git"]],cwd=R) if "source_git" in r else pathlib.Path(r["source"]).read_bytes());raw=pathlib.Path(r["draft"]).read_bytes();reverse=raw.replace(b"v17",b"v16").replace(b"V17",b"V16")
 assert sha(old)==r["source_sha256"] and sha(raw)==r["draft_sha256"]
 assert reverse==old and ast.dump(ast.parse(reverse),include_attributes=False)==ast.dump(ast.parse(old),include_attributes=False)
 rows.append(dict(path=r["draft"],sha256=sha(raw),reverse_bytes_and_AST_equal=True))
assert len(rows)==11 and len(g["extra_reset_tool_literals"])==4
P=R/"ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v16/predeclared_plan_v16.json";old=json.loads(P.read_bytes());plan=json.loads((D/"predeclared_plan_v17.json").read_bytes())
assert plan["independent_source_bindings"]==old["independent_source_bindings"] and len(plan["independent_source_bindings"])==134
assert len(plan["authorized_current_binding_refresh_pending"])==4 and {pathlib.Path(x).name for x in plan["authorized_current_binding_refresh_pending"]}=={"benchmark.py","test_preparation_comparison.py","audit_preparation.py","audit_ppo.py"}
for k in ["unchanged_gates","settled_turn_criteria","angular_interface_criteria","full_execution_model_failfast","pilot_budget_unchanged","max_api_records","max_submitted_script_decisions","max_total_wall_seconds"]:assert plan[k]==old[k],k
for k,allowed in [("physical_response_criteria",["matrix_consumer","matrix_eligibility"]),("angular_reset_criteria",["matrix_consumer","exact_workload"])]:
 assert {n:v for n,v in old[k].items() if n not in allowed}=={n:v for n,v in plan[k].items() if n not in allowed}
 assert "20261017_mr3_p2a0_v17/" in plan[k]["matrix_consumer"]["path"] and plan[k]["matrix_consumer"]["sha256"] is None
for a,b in zip(old["stages"],plan["stages"]):
 expected=[x.replace("v16","v17").replace("V16","V17") for x in a["command"]]
 if b["stage"] in ("interface","reset"):expected[expected.index("--preparation-probe-version")+1]="mr3-p2a0-outward-cancel-v6"
 assert expected==b["command"]
 assert a["required_audits"]==b["required_audits"] and a["wall_ceiling_seconds"]==b["wall_ceiling_seconds"]
reset=next(x for x in plan["stages"] if x["stage"]=="reset")
for k in ["angular_matrix_audit_command_template","physics_matrix_audit_command_template"]:assert "20261017_mr3_p2a0_v17/" in reset[k][1]
assert plan["readiness"]["status"]=="draft_pending_root_final_review" and plan["readiness"]["pending_bindings"] and plan["native_admission_granted"] is False
result=dict(passed=True,files=rows,extra_reset_tool_literals=g["extra_reset_tool_literals"],whole_reverse_bytes_and_AST_equal=True,source_bindings_pending_historical=134,authorized_current_refresh_count=4,required_other_old_unchanged=130,final_count_not_guessed=True,active_reset_templates_and_matrix_metadata_A17_V6=True,all_numerical_hard_gates_preserved=True,budget=[608,596,18000],plan_sha256=sha((D/"predeclared_plan_v17.json").read_bytes()),scope="Read-only temporary mechanical source/draft plan proof. No canonical promotion, source/actor/safety edits, real native/formal or final admission.")
output=C/"reverse_AST_v1.json"
with output.open("x") as f:json.dump(result,f,indent=2);f.write("\n")
print(json.dumps({k:v for k,v in result.items() if k!="files"},indent=2));print("OUTPUT_SHA",sha(output.read_bytes()))
