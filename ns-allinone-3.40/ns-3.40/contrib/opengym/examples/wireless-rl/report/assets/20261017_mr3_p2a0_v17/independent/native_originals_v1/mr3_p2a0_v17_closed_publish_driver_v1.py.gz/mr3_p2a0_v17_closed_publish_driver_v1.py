import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
R=Path('/home/zhuyulab/ns3-workspace');T=Path('/tmp');helper=T/'mr3_p2a0_v17_archive_closed_v1.py';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(helper)=='1904fdaa42e22c47a335e7118ed16c395b9453353567baeb5a29d624fdabbdde'
console=T/'mr3_p2a0_v17_closed_publish_v1.log';receipt=T/'mr3_p2a0_v17_closed_publish_execution_v1.json';assert not console.exists() and not receipt.exists()
env=dict(os.environ,PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONPATH',None)
cmd=['/usr/bin/python3',str(helper),'--publish','--mode','stopped','--stop-stage','reset'];start=time.monotonic();utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
with console.open('x') as f:ret=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
v=dict(argv=cmd,cwd=str(R),env=dict(PYTHONPATH='unset',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1'),started_utc=utc,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),returncode=ret.returncode,wall_seconds=time.monotonic()-start,source_sha256=sha(helper),console=str(console),console_sha256=sha(console))
with receipt.open('x') as f:f.write(json.dumps(v,indent=2)+'\n')
print(json.dumps(v),flush=True);sys.exit(ret.returncode)
