"""Exclusive two-root TMP custody, sequential groups and two compression workers."""
import datetime
import hashlib
import json
from pathlib import Path
import resource
import subprocess
import time


ROOT = Path('/home/zhuyulab/ns3-workspace')
TMP = Path('/tmp')
HELPER = TMP / 'mr3_p2a0_v20_sensor_pack_closed_v1.py'
EXECUTION = TMP / 'mr3_p2a0_v20_sensor_execution_v1.json'
TARGET = TMP / 'mr3_p2a0_v20_sensor_selected_native_v1'
PROSPECTIVE = 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v20_sensor'
ENV = {'PATH': '/usr/bin:/bin', 'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1',
       'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'TZ': 'UTC'}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def store(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def main():
    started = time.monotonic()
    start_utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
    execution_raw = EXECUTION.read_bytes()
    execution = json.loads(execution_raw)
    assert execution['status'] == 'completed'
    original_workload = execution['actual_workload']
    metadata_path = Path(original_workload['protocol']['path']).parent / 'metadata.json'
    metadata_raw = metadata_path.read_bytes()
    metadata = json.loads(metadata_raw)
    assert metadata['freeze'] == execution['freeze']
    assert not TARGET.exists(), 'never overwrite/retry an earlier custody attempt'
    TARGET.mkdir()
    helper_before = HELPER.read_bytes()
    cpu_before = resource.getrusage(resource.RUSAGE_CHILDREN)
    jobs = [('native', ROOT / 'ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261018_v20_sensor_iters150',
             TARGET / 'native/iters150', PROSPECTIVE + '/native/iters150'),
            ('sensor_capture', TMP / 'mr3_p2a0_v20_sensor_capture_v1',
             TARGET / 'sensor_capture', PROSPECTIVE + '/sensor_capture')]
    rows, manifests = [], []
    for kind, source, target, prospective in jobs:
        argv = ['/usr/bin/python3', '-B', str(HELPER), '--source', str(source),
                '--target', str(target), '--source-kind', kind,
                '--prospective-prefix', prospective, '--execution', str(EXECUTION)]
        output = TMP / ('mr3_p2a0_v20_sensor_custody_' + kind + '_execution_v1.stdout.log')
        began = time.monotonic()
        with output.open('x') as stream:
            result = subprocess.run(argv, cwd=ROOT, env=ENV, stdout=stream, stderr=subprocess.STDOUT)
        row = {'source_kind': kind, 'argv': argv, 'cwd': str(ROOT), 'environment_exact': ENV,
               'exit_code': result.returncode, 'wall_seconds': time.monotonic() - began,
               'stdout': str(output), 'stdout_sha256': digest(output.read_bytes())}
        manifest_path = target / 'manifest.json'
        if manifest_path.exists():
            raw = manifest_path.read_bytes()
            manifest = json.loads(raw)
            row['manifest'] = {'path': str(manifest_path), 'sha256': digest(raw), 'bytes': len(raw)}
            assert manifest['original_execution']['sha256'] == digest(execution_raw)
            manifests.append(manifest)
        rows.append(row)
        print(json.dumps({'group': kind, 'exit_code': result.returncode,
                          'wall_seconds': row['wall_seconds'], 'manifest': row.get('manifest')}), flush=True)
    cpu_after = resource.getrusage(resource.RUSAGE_CHILDREN)
    stable = HELPER.read_bytes() == helper_before and EXECUTION.read_bytes() == execution_raw
    stable = stable and metadata_path.read_bytes() == metadata_raw
    passed = stable and len(manifests) == 2 and all(row['exit_code'] == 0 for row in rows)
    value = {'schema': 'mr3-v20-sensor-two-root-custody-association-v1',
             'passed': passed, 'pass_scope': 'Lossless byte custody only; original capture/task/physical verdicts retained.',
             'freeze': execution['freeze'], 'plan_sha256': execution['plan_sha256'],
             'original_execution': {'path': str(EXECUTION), 'sha256': digest(execution_raw)},
             'original_metadata': {'path': str(metadata_path), 'sha256': digest(metadata_raw)},
             'original_actual_workload': original_workload,
             'original_capture_process_completed': execution['capture_process_completed'],
             'original_physical_passed': execution['original_physical_passed'],
             'original_strict_native_closure_passed': execution['strict_native_closure_passed'],
             'original_e61c': execution['e61c'],
             'native_wall_seconds_original_charged_once': execution['native_wall_seconds'],
             'groups': rows, 'groups_share_exact_closed_execution': True,
             'source_files': sum(row['source_files'] for row in manifests),
             'raw_bytes': sum(row['raw_bytes'] for row in manifests),
             'selected_bytes': sum(row['selected_bytes'] for row in manifests),
             'selected_parts': sum(row['selected_parts'] for row in manifests),
             'largest_encoded_part_bytes': max((row['largest_encoded_part_bytes'] for row in manifests), default=None),
             'helper_sha256_before': digest(helper_before), 'helper_sha256_after': digest(HELPER.read_bytes()),
             'all_helper_execution_metadata_sources_stable': stable,
             'raw_chunk_bytes': 32 * 1024 * 1024, 'compression_workers_per_group': 2,
             'start_utc': start_utc, 'end_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'wall_seconds': time.monotonic() - started,
             'child_user_cpu_seconds': cpu_after.ru_utime - cpu_before.ru_utime,
             'child_system_cpu_seconds': cpu_after.ru_stime - cpu_before.ru_stime,
             'no_new_native_formal_or_canonical_write': True}
    store(TARGET / 'association_manifest_v1.json', value)
    store(TMP / 'mr3_p2a0_v20_sensor_closed_custody_execution_v1.json', value)
    print(json.dumps({'passed': passed, 'association': str(TARGET / 'association_manifest_v1.json'),
                      'sha256': digest((TARGET / 'association_manifest_v1.json').read_bytes()),
                      'raw_bytes': value['raw_bytes'], 'selected_bytes': value['selected_bytes'],
                      'files': value['source_files'], 'parts': value['selected_parts'],
                      'largest_encoded_part_bytes': value['largest_encoded_part_bytes'],
                      'wall_seconds': value['wall_seconds']}), flush=True)
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
