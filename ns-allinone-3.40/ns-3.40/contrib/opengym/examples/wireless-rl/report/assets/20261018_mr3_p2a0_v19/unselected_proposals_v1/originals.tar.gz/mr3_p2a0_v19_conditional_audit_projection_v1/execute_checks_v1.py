"""Capture conditional integration checks without Git/native/ROS/DDS calls."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
AUDIT = ROOT / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
                'mr3_learning/audit_ppo.py')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    before = AUDIT.read_bytes()
    commands = [
        ['rtk', 'proxy', '/usr/bin/python3', '-B', str(HERE / 'projection_tests_v1.py')],
        ['rtk', 'proxy', '/usr/bin/python3', '-B', '-m', 'flake8', '--select=E9,F63,F7,F82',
         str(HERE / 'proposed_audit_ppo.py'), str(HERE / 'projection_tests_v1.py'),
         str(HERE / 'prepare_proposal_v1.py'), str(HERE / 'execute_checks_v1.py')],
    ]
    env = dict(os.environ, PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1')
    records = []
    started = time.monotonic()
    for index, argv in enumerate(commands):
        wall = time.monotonic()
        result = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True)
        for suffix, raw in [('stdout', result.stdout), ('stderr', result.stderr)]:
            with (HERE / f'checks_{index:02d}.{suffix}').open('xb') as stream:
                stream.write(raw)
        records.append({'argv': argv, 'cwd': str(ROOT),
                        'environment_overrides': {'PYTHONNOUSERSITE': '1',
                                                  'PYTHONDONTWRITEBYTECODE': '1'},
                        'exit_code': result.returncode, 'wall_seconds': time.monotonic() - wall,
                        'stdout_sha256': sha(result.stdout), 'stderr_sha256': sha(result.stderr)})
        if result.returncode:
            break
    receipt = {'schema': 'mr3-conditional-audit-projection-cpu-checks-v1',
               'passed': len(records) == len(commands) and all(
                   row['exit_code'] == 0 for row in records) and AUDIT.read_bytes() == before,
               'conditional_only': True, 'tests': 12, 'commands': records,
               'wall_seconds': time.monotonic() - started,
               'canonical_source_before_sha256': sha(before),
               'canonical_source_after_sha256': sha(AUDIT.read_bytes()),
               'canonical_unchanged': AUDIT.read_bytes() == before,
               'proposed_source_sha256': sha((HERE / 'proposed_audit_ppo.py').read_bytes()),
               'scope': 'Exact proposed helper AST and whole-auditor inverse-AST check; '
                        'only unavailable future Git object I/O is substituted with sealed actual W7/proposed bytes. '
                        'No whole runtime/native audit was invoked.',
               'git_commands_executed': 0, 'native_calls': 0, 'ros_dds_calls': 0,
               'env_document_pin': 'unchanged pending actual future document update; not ready'}
    with (HERE / 'checks_v1.json').open('x') as stream:
        json.dump(receipt, stream, indent=2)
        stream.write('\n')
    print(json.dumps(receipt))
    raise SystemExit(0 if receipt['passed'] else 1)


if __name__ == '__main__':
    main()
