"""Build versioned orchestration drafts in /tmp only, preserving immutable A13 sources."""
import ast
import copy
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A13 = W / 'report/assets/20261017_mr3_p2a0_v13'
A14 = W / 'report/assets/20261017_mr3_p2a0_v14'
DRAFT = Path('/tmp/mr3_p2a0_v14_coord_draft_v1')
FILES = (
    'mr3_p2a0_v13_launch_stage.py', 'mr3_p2a0_v13_audit_stage.py',
    'mr3_p2a0_v13_buildproof_preflight.py',
    'mr3_p2a0_v13_cross_stage_mapping_monitor_v1.py',
    'mr3_v13_multiepoch_closure_binary_review_v1.py',
    'mr3_p2a0_v13_plan_launcher_tests_v1.py',
    'mr3_p2a0_v13_audit_stage_tests_v1.py',
    'mr3_v13_nested_closure_read_tests_v1.py',
)
READER = A13 / 'independent/mr3_v13_shim_mapping_review_v1.py'
READER_SHA = '775a5f012e6098f7083735cd2064e1963d855a9c5b5356af99eebd21e4737282'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def replace_once(source, old, new):
    require(source.count(old) == 1, 'not unique replacement: ' + old[:80])
    return source.replace(old, new)


def main():
    DRAFT.mkdir(exist_ok=False)
    independent = DRAFT / 'independent'
    independent.mkdir()
    old_plan = json.loads((A13 / 'predeclared_plan_v13.json').read_bytes())
    originals, produced = {}, {}
    names = {name: name.replace('v13', 'v14') for name in FILES}
    for name, new_name in names.items():
        original = (A13 / 'independent' / name).read_bytes()
        originals[name] = {'bytes': len(original), 'sha256': sha(original)}
        source = original.decode().replace('v13', 'v14').replace('V13', 'V14')
        if name == 'mr3_p2a0_v13_audit_stage.py':
            source = source.replace('20261017_mr3_p2a0_v14/independent/mr3_independent_drive_trace_v6.py',
                                    '20261017_mr3_p2a0_v13/independent/mr3_independent_drive_trace_v6.py')
        if name == 'mr3_p2a0_v13_buildproof_preflight.py':
            source = replace_once(source,
                'monitor_path = ASSET / "independent/mr3_readonly_v14_drive_shim_process_monitor_v2.py"',
                'monitor_path = WIRELESS / "report/assets/20261017_mr3_p2a0_v13/independent/'
                'mr3_readonly_v13_drive_shim_process_monitor_v2.py"')
        if name == 'mr3_p2a0_v13_cross_stage_mapping_monitor_v1.py':
            source = replace_once(source,
                "OBSERVER=Path(__file__).with_name('mr3_readonly_v14_drive_shim_process_monitor_v2.py')",
                "OBSERVER=ROOT/'" + str((A13 / 'independent/'
                    'mr3_readonly_v13_drive_shim_process_monitor_v2.py').relative_to(ROOT)) + "'")
            source = replace_once(source,
                "SHIM_BINDING=Path(__file__).with_name('mr3_v14_shim_binding_v1.json')",
                "SHIM_BINDING=ROOT/'" + str((A13 / 'independent/'
                    'mr3_v13_shim_binding_v1.json').relative_to(ROOT)) + "'")
        if name == 'mr3_v13_multiepoch_closure_binary_review_v1.py':
            source = replace_once(source, '\n\ndef main():', '''

def load_checked_shim(read):
    """Reuse immutable A13 reader bytes and its original MONITOR/BINDING rules."""
    root = Path('/home/zhuyulab/ns3-workspace')
    relative = ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
                'report/assets/20261017_mr3_p2a0_v13/independent/'
                'mr3_v13_shim_mapping_review_v1.py')
    plan_path = root / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
                        'report/assets/20261017_mr3_p2a0_v14/predeclared_plan_v14.json')
    plan = json.loads(read(plan_path))
    pins = {row['path']: row['sha256'] for row in plan['independent_source_bindings']}
    reader_path = root / relative
    raw = read(reader_path)
    expected = '775a5f012e6098f7083735cd2064e1963d855a9c5b5356af99eebd21e4737282'
    if pins.get(relative) != expected or hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError('immutable A13 Shim reader source/plan SHA differs')
    spec = importlib.util.spec_from_file_location('shim_review', reader_path)
    result = importlib.util.module_from_spec(spec)
    exec(compile(raw, str(reader_path), 'exec'), result.__dict__)
    return result


def call_shim_review(supplement, run, prefix, freeze, read):
    """Only the new binary-proof CLI path changes; strict reader math is reused."""
    original = supplement.BINARY
    if original != Path('/tmp/mr3_p2a0_v13_binaryproof.json'):
        raise ValueError('immutable A13 Shim reader binary-proof default differs')
    try:
        supplement.BINARY = Path('/tmp/mr3_p2a0_v14_binaryproof.json')
        return supplement.review(run, prefix, freeze, read)
    finally:
        supplement.BINARY = original


def main():''')
            block = '''    supplement_path = Path(__file__).with_name('mr3_v14_shim_mapping_review_v1.py')
    read(supplement_path)
    supplement_spec = importlib.util.spec_from_file_location('shim_review', supplement_path)
    supplement = importlib.util.module_from_spec(supplement_spec)
    supplement_spec.loader.exec_module(supplement)
'''
            source = replace_once(source, block, '    supplement = load_checked_shim(read)\n')
            source = replace_once(source,
                'shim_review = supplement.review(a.run, prefix, a.freeze, read)',
                'shim_review = call_shim_review(supplement, a.run, prefix, a.freeze, read)')
        if name == 'mr3_p2a0_v13_audit_stage_tests_v1.py':
            source = source.replace(
                'OLD_PLAN=ROOT/\'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v14/predeclared_plan_v14.json\'',
                "OLD_PLAN=Path(__file__).resolve().parent.parent/'predeclared_plan_v14.json'")
        if name == 'mr3_p2a0_v13_plan_launcher_tests_v1.py':
            old_test_start = source.index('    def test_preflight_keeps_old_checks_and_requires_information_ready(self):')
            old_test_end = source.index("\n\n\n\nif __name__", old_test_start)
            source = source[:old_test_start] + '''    def test_preflight_keeps_old_checks_and_requires_information_ready(self):
        import ast
        old_path = ROOT / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
                           'report/assets/20261017_mr3_p2a0_v13/independent/'
                           'mr3_p2a0_v13_buildproof_preflight.py')
        old_tree = ast.parse(old_path.read_text())
        new = (DRAFT / 'mr3_p2a0_v14_buildproof_preflight.py').read_text()
        self.assertIn('shim = check_shim(plan, freeze)', new)
        self.assertIn('mr3_readonly_v13_drive_shim_process_monitor_v2.py', new)
        self.assertIn("plan['readiness']['status'] == 'ready'", new)
        tree = ast.parse(new.replace('v14', 'v13').replace('V14', 'V13'))
        old_shim = next(n for n in old_tree.body if isinstance(n, ast.FunctionDef)
                        and n.name == 'check_shim')
        tree.body = [old_shim if isinstance(n, ast.FunctionDef) and n.name == 'check_shim'
                     else n for n in tree.body]
        self.assertEqual(ast.dump(tree, include_attributes=False),
                         ast.dump(old_tree, include_attributes=False))
''' + source[old_test_end:]
        if name == 'mr3_v13_nested_closure_read_tests_v1.py':
            source = replace_once(source,
                '            module.Path = selected_path\n',
                '''            module.Path = selected_path
            def explicit_read_callback_stub(read):
                stub = types.ModuleType('nested_callback_fixture_only')
                stub.BINARY = Path('/tmp/mr3_p2a0_v13_binaryproof.json')
                exec(compile(helper.read_bytes(), str(helper), 'exec'), stub.__dict__)
                return stub
            module.load_checked_shim = explicit_read_callback_stub
''')
        ast.parse(source)
        (independent / new_name).write_text(source)
        produced[new_name] = {'bytes': len(source.encode()), 'sha256': sha(source.encode())}

    # Only names/paths belonging to the new orchestrators, new native runs and
    # their /tmp outputs change. Immutable A13 algorithm/readback/observer files
    # and compiled binary receipt remain referenced in place.
    def convert(value):
        if isinstance(value, dict):
            return {key: convert(item) for key, item in value.items()}
        if isinstance(value, list):
            return [convert(item) for item in value]
        if not isinstance(value, str):
            return value
        value = value.replace('mr3_p2a0_20261017_v13_', 'mr3_p2a0_20261017_v14_')
        value = value.replace('/tmp/mr3_p2a0_v13_', '/tmp/mr3_p2a0_v14_')
        value = value.replace('mr3-p2a0-predeclaration-v13', 'mr3-p2a0-predeclaration-v14')
        for old_name, new_name in names.items():
            old_path = str(A13 / 'independent' / old_name)
            new_path = str(A14 / 'independent' / new_name)
            value = value.replace(old_path, new_path)
            value = value.replace(str(Path(old_path).relative_to(ROOT)),
                                  str(Path(new_path).relative_to(ROOT)))
        return value

    plan = convert(copy.deepcopy(old_plan))
    plan['independent_source_bindings'] = copy.deepcopy(old_plan['independent_source_bindings'])
    for new_name, row in produced.items():
        plan['independent_source_bindings'].append({
            'path': str((A14 / 'independent' / new_name).relative_to(ROOT)),
            'sha256': row['sha256']})
    plan['source_binding'] = 'PENDING one reviewed new clean pushed V14 exact40 source freeze'
    plan['readiness'] = {
        'status': 'draft_pending_root_final_review', 'freeze': None,
        'pending_bindings': ['authorized nine exact parameter reply writer profiles and audit_ppo '
                             'source pin refresh', 'root review of V14 path adapter and coordinator '
                             'drafts', 'final source/static/offline archive and clean pushed preflight'],
        'no_native_or_formal_authorized_by_this_template': True,
        'scope': 'Versioned /tmp preparation only. All old gates and actual native requirements '
                 'remain; root must finalize source/plan before any new launch.'}
    plan['revision_reasons'].append(
        'V13 first GetParameters response failed exact rmw response-reader matching timeout; '
        'proposed only nine exact RELIABLE response writer max_blocking_time1s, client30s unchanged; '
        'new freeze required and sufficiency remains unproven.')
    plan['historical_bindings_scope'] = (
        'All96 frozen A13 bindings are retained. Only the authorized current audit_ppo source '
        'pin may be refreshed after nine response-profile changes; append new V14 coordinator '
        'and fixture paths without editing any immutable A13 source/evidence. No native credit transfers.')
    plan['shim_reader_binary_path_adapter'] = {
        'immutable_reader': str(READER.relative_to(ROOT)), 'immutable_reader_sha256': READER_SHA,
        'original_binaryproof_path': '/tmp/mr3_p2a0_v13_binaryproof.json',
        'new_binaryproof_path': '/tmp/mr3_p2a0_v14_binaryproof.json',
        'scope': 'New closure verifies original reader bytes against fixed SHA and plan, compiles '
                 'checked bytes, then temporarily changes only BINARY during review and restores '
                 'it in finally. MONITOR/BINDING remain A13. No math/argv/type/map/worker relaxation.'}
    (DRAFT / 'predeclared_plan_v14.json').write_text(json.dumps(plan, indent=2) + '\n')
    manifest = {'schema': 'mr3-v14-coordinator-draft-builder-v1', 'scope': '/tmp draft only, not ready',
                'source_plan': str(A13 / 'predeclared_plan_v13.json'),
                'source_plan_sha256': sha((A13 / 'predeclared_plan_v13.json').read_bytes()),
                'source_files': originals, 'new_files': produced,
                'old_bindings_retained': len(old_plan['independent_source_bindings']),
                'new_bindings_current': len(plan['independent_source_bindings']),
                'immutable_reused': ['A13 drivev6', 'A13 Shim monitor/reader/binding',
                                     'A13 actual parameter hook', 'A13 a014 buildreceipt/SO'],
                'ready': False, 'new_native': 0}
    (DRAFT / 'builder_manifest_v1.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'draft': str(DRAFT), 'files': len(produced), 'ready': False}))


if __name__ == '__main__':
    main()
