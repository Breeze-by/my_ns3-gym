import hashlib
import json
from pathlib import Path
import subprocess
import time
ROOT = Path("/home/zhuyulab/ns3-workspace")
ROS = ROOT / "ros2_ws/ros2-multi-robot-automap"
files = [ROS/"src/multi_robot_exploration/multi_robot_exploration/peer_obstacles.py",
         ROS/"src/multi_robot_exploration/test/test_peer_phase.py"]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
before = {str(p): sha(p) for p in files}
commands = [
 ("ros_tests_final", ROS, ["bash", "-c", "source /opt/ros/humble/setup.bash; source install/setup.bash; export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1; /usr/bin/python3 -m pytest src/multi_robot_exploration/test/test_peer_obstacles.py src/multi_robot_exploration/test/test_peer_phase.py -q"]),
 ("style_final", ROOT, ["/usr/bin/python3", "-m", "flake8", *[str(p) for p in files], "--max-line-length=99"])]
results=[]
for label, cwd, argv in commands:
 start=time.monotonic();r=subprocess.run(argv,cwd=cwd,capture_output=True,text=True)
 output=Path("/tmp/mr3_p2a0_v10_peer_"+label+"_v1.log")
 output.write_text(r.stdout+r.stderr)
 results.append({"label":label,"cwd":str(cwd),"argv":argv,"exit_code":r.returncode,
                 "wall_seconds":time.monotonic()-start,"stdout_stderr":str(output),"sha256":sha(output)})
result={"schema":"mr3-v10-peer-offline-checks-v1","passed":all(r["exit_code"]==0 for r in results),
        "source_before":before,"source_after":{str(p):sha(p) for p in files},"checks":results,
        "history":[str(p) for p in sorted(Path("/tmp").glob("mr3_p2a0_v10_peer*tests_*.log"))]
                  +[str(p) for p in sorted(Path("/tmp").glob("mr3_p2a0_v10_peer_phase_style_*.log"))],
        "history_notes":["Tests01/03 include invocation cwd mistakes, not native failures.",
                         "Test02 caught an invalid CDR byte equality assertion: CDR padding is unstable; corrected to actual ROS fields and cloud.data SHA.",
                         "Style01..04 initial lint failures retained; final style passing."]}
assert result["source_before"]==result["source_after"]
Path("/tmp/mr3_p2a0_v10_peer_checks_v1.json").write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
print(json.dumps(result,sort_keys=True))
