def ray_availability(episode, epoch, expected):
    """Single raw-stream pass after native closure; basic measurement integrity only."""
    result = {'passed': True, 'robots': {}, 'errors': [],
              'scope': 'Configuration+connected+at least one complete360 cached-ray scan per robot; no ray/CDR equality, physical, map or task acceptance.'}
    for robot in ('tb1', 'tb2', 'tb3'):
        path = Path(episode) / ('ray_' + robot + '.jsonl')
        report = {'passed': False, 'path': str(path), 'configuration': 0,
                  'sensor_connected': 0, 'scans': 0, 'diagnostic_errors': [], 'errors': []}
        digest = hashlib.sha256(); byte_count = 0; pid = None; last_measurement = -1
        try:
            with path.open('rb') as stream:
                before = os.fstat(stream.fileno())
                for sequence, line in enumerate(stream, 1):
                    digest.update(line); byte_count += len(line)
                    try:
                        require(line.endswith(b'\n'), 'partial ray JSONL line')
                        value = json.loads(line, parse_constant=lambda text: (_ for _ in ()).throw(ValueError('nonfinite JSON constant')))
                        require(value.get('schema') == 'mr3-ray-provenance-audit-v1'
                                and value.get('epoch') == epoch and value.get('robot') == robot,
                                'ray stream identity differs')
                        require(type(value.get('record_sequence')) is int and value['record_sequence'] == sequence,
                                'ray record sequence differs')
                        current_pid = value.get('process_id')
                        require(type(current_pid) is int and current_pid > 0 and current_pid == expected['process_id'] and (pid is None or pid == current_pid),
                                'ray stream PID differs')
                        pid = current_pid; kind = value.get('kind')
                        if kind == 'configuration':
                            require(sequence == 1 and value.get('plugin_type') == 'SensorPlugin'
                                    and value.get('compiled_source_sha256') == expected['source_sha256']
                                    and value.get('loaded_library_path') == expected['installed_resolved_path'],
                                    'ray configuration source/type/path differs')
                            report['configuration'] += 1
                        elif kind == 'sensor_connected':
                            require(value.get('sensor_parent') and value.get('sensor_scoped_name'),
                                    'connected sensor identity unavailable')
                            require(type(value.get('ray_count')) is int and value['ray_count'] == 360,
                                    'connected ray count differs')
                            report['sensor_connected'] += 1
                        elif kind == 'scan':
                            require(type(value.get('scan_sequence')) is int
                                    and value['scan_sequence'] == report['scans'] + 1, 'scan sequence differs')
                            stamp = value.get('measurement_time_ns')
                            require(type(stamp) is int and last_measurement < stamp
                                    and 0 <= stamp <= 300000000000, 'ray measurement clock differs')
                            last_measurement = stamp
                            rays = value.get('rays')
                            require(type(value.get('ray_count')) is int and value['ray_count'] == 360
                                    and type(value.get('range_count')) is int and value['range_count'] == 360
                                    and value.get('final_range_one_to_one') is True
                                    and type(rays) is list and len(rays) == 360
                                    and all(type(ray) is dict and type(ray.get('index')) is int
                                            and ray['index'] == index
                                            and {'cached_length', 'geometry_range', 'current_shortened_ray',
                                                 'cached_collision_name', 'collision_name_current_hit_valid',
                                                 'relative_start', 'relative_end_after_collision',
                                                 'global_cast_start', 'global_cast_end_before_collision',
                                                 'final_sensor_range'} <= set(ray)
                                            for index, ray in enumerate(rays)),
                                    'incomplete360 ray scan')
                            report['scans'] += 1
                        elif kind == 'diagnostic_error':
                            report['diagnostic_errors'].append(value)
                        else:
                            raise ValueError('unknown ray record kind')
                    except Exception as error:
                        report['errors'].append({'line': sequence, 'error': repr(error)})
                after = os.fstat(stream.fileno())
            linked = path.stat()
            def identity(stat):
                return stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns
            require(identity(before) == identity(after) == identity(linked), 'ray stream changed during audit')
            report.update(sha256=digest.hexdigest(), bytes=byte_count, records=sequence if byte_count else 0,
                          process_id=pid, stat_stable=True)
            require(report['configuration'] == 1 and report['sensor_connected'] == 1
                    and report['scans'] >= 1 and not report['diagnostic_errors'] and not report['errors'],
                    'required ray measurement missing or diagnostic_error')
            report['passed'] = True
        except Exception as error:
            report['errors'].append(repr(error))
            report.setdefault('sha256_read_prefix', digest.hexdigest())
            report.setdefault('bytes_read', byte_count)
        result['robots'][robot] = report
        if not report['passed']:
            result['passed'] = False
            result['errors'].append(robot + ': basic ray measurement failed')
    return result
