"""Actual proposed ENV verifier AST with only fixed Git I/O substituted."""
import ast
import copy
import hashlib
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest

D=Path(__file__).parent
TREE=ast.parse((D/'proposed_audit_ppo.py').read_text())
NAMES={'WIRELESS','ENV_DOCUMENT_SHA256','ENV_NORMATIVE_FREEZE','ENV_NORMATIVE_SHA256',
       'ENV_EXECUTION_APPENDIX_SHA256','ENV_EXECUTION_APPENDIX_BYTES'}
BODY=[n for n in TREE.body if (isinstance(n,ast.FunctionDef) and n.name in ('require','sha','verify_environment_appendix')) or (isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in NAMES for t in n.targets))]

class EnvAppendix(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.freeze='d'*40
        self.old=(D/'MR3_ENV_CONTRACT.original.md').read_bytes();self.actual=(D/'MR3_ENV_CONTRACT.proposed.md').read_bytes()
        self.ns={'Path':Path,'hashlib':hashlib,'subprocess':SimpleNamespace(check_output=self.git)}
        exec(compile(ast.Module(body=copy.deepcopy(BODY),type_ignores=[]),'proposed_env_verifier','exec'),self.ns)
        self.relative=self.ns['WIRELESS']+'MR3_ENV_CONTRACT.md';self.path=self.root/self.relative
        self.path.parent.mkdir(parents=True);self.path.write_bytes(self.actual)
    def git(self,argv,cwd):
        self.assertEqual(Path(cwd),self.root);revision,relative=argv[2].split(':',1)
        self.assertEqual(relative,self.relative)
        return self.old if revision==self.ns['ENV_NORMATIVE_FREEZE'] else self.actual
    def verify(self):return self.ns['verify_environment_appendix'](self.root,self.freeze)
    def repin(self,raw):
        self.actual=raw;self.path.write_bytes(raw);self.ns['ENV_DOCUMENT_SHA256']=hashlib.sha256(raw).hexdigest()
    def test_exact_fixed_appendix_and_normative_prefix(self):
        result=self.verify();self.assertTrue(result['append_only_normative_prefix_exact'])
        self.assertEqual(result['normative_sha256'],hashlib.sha256(self.old).hexdigest())
        self.assertNotEqual(self.ns['ENV_DOCUMENT_SHA256'],result['normative_sha256'])
    def test_old_prefix_edit_rejected_even_with_refreshed_actual_pin(self):
        self.repin(b'X'+self.actual[1:])
        with self.assertRaises(ValueError):self.verify()
    def test_missing_duplicate_extra_or_changed_appendix_rejected(self):
        original=self.actual;appendix=original[len(self.old):]
        for raw in (self.old,self.old+appendix+appendix,original+b'\nextra',original[:-1]+b'X'):
            self.repin(raw)
            with self.subTest(bytes=len(raw)),self.assertRaises(ValueError):self.verify()
    def test_worktree_and_frozen_identity_must_match(self):
        self.path.write_bytes(self.old)
        with self.assertRaises(ValueError):self.verify()
        self.path.write_bytes(self.actual);self.actual=self.old
        with self.assertRaises(ValueError):self.verify()
    def test_normative_git_blob_cannot_be_replaced(self):
        self.old=b'changed normative source'
        with self.assertRaises(ValueError):self.verify()

if __name__=='__main__':unittest.main()
