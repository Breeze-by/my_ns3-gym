"""Isolated actual SDK compile and pure helper CPU execution; no native init."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


HERE = Path(__file__).parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    started = time.monotonic()
    files = [HERE / 'mr3_ray_provenance_observer.cpp', HERE / 'CMakeLists.txt']
    before = {str(path): sha(path) for path in files}
    for path in files:
        snapshot = HERE / (path.name + '.build02_original')
        with snapshot.open('xb') as stream:
            stream.write(path.read_bytes())
    receipt = {'schema': 'mr3-v21-ray-observer-sdk-build-v1',
               'start_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'environment_exact': dict(os.environ), 'cwd': str(HERE),
               'source_before': before, 'commands': [],
               'scope': 'Actual installed Gazebo SDK compilation and pure helper assertions; no Gazebo/ROS init, participant, or native run.'}
    for label, argv in [
        ('configure02', ['/usr/bin/cmake', '-S', str(HERE), '-B', str(HERE / 'build'), '-DCMAKE_BUILD_TYPE=Debug']),
        ('build02', ['/usr/bin/cmake', '--build', str(HERE / 'build'), '-j2']),
        ('cpu02', [str(HERE / 'build/mr3_ray_provenance_cpu')]),
        ('ldd02', ['/usr/bin/ldd', '-r', str(HERE / 'build/libmr3_ray_provenance_observer.so')]),
    ]:
        began = time.monotonic()
        output = subprocess.run(argv, cwd=HERE, env=os.environ, capture_output=True)
        refs = {}
        for channel, raw in [('stdout', output.stdout), ('stderr', output.stderr)]:
            path = HERE / (label + '.' + channel + '.log')
            with path.open('xb') as stream:
                stream.write(raw)
            refs[channel] = {'path': str(path), 'sha256': sha(path), 'bytes': len(raw)}
        receipt['commands'].append({'argv': argv, 'exit_code': output.returncode,
                                    'wall_seconds': time.monotonic() - began, **refs})
        if output.returncode:
            break
    receipt['source_after'] = {str(path): sha(path) for path in files}
    receipt['passed'] = receipt['source_before'] == receipt['source_after'] and len(receipt['commands']) == 4 and all(row['exit_code'] == 0 for row in receipt['commands'])
    receipt['wall_seconds'] = time.monotonic() - started
    path = HERE / 'build_checks_v2.json'
    with path.open('x') as stream:
        json.dump(receipt, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'passed': receipt['passed'], 'receipt': str(path), 'sha256': sha(path),
                      'wall_seconds': receipt['wall_seconds'],
                      'commands': [(row['argv'][0], row['exit_code']) for row in receipt['commands']]}))
    return 0 if receipt['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
