"""Conditional configuration proposal, CPU parsing and immutable-byte checks only."""
import datetime
import difflib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
ROS = ROOT / 'ros2_ws/ros2-multi-robot-automap'
W7 = 'cdb1f5947302a0b3a071b78a9077e61b8e6b6a7a'
MODULE_SPEC = importlib.util.spec_from_file_location('projection', HERE / 'world_projection_proposal.py')
P = importlib.util.module_from_spec(MODULE_SPEC)
MODULE_SPEC.loader.exec_module(P)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    started = time.monotonic()
    env = dict(os.environ, PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1')
    commands = []

    def run(argv, label):
        start = time.monotonic()
        result = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True)
        for suffix, raw in [('stdout', result.stdout), ('stderr', result.stderr)]:
            with (HERE / (label + '.' + suffix)).open('xb') as stream:
                stream.write(raw)
        commands.append({'argv': argv, 'cwd': str(ROOT), 'label': label,
                         'environment_overrides': {'PYTHONNOUSERSITE': '1',
                                                   'PYTHONDONTWRITEBYTECODE': '1'},
                         'exit_code': result.returncode, 'wall_seconds': time.monotonic() - start,
                         'stdout_sha256': sha(result.stdout), 'stderr_sha256': sha(result.stderr)})
        if result.returncode:
            raise RuntimeError('CPU command failed: ' + label)
        return result.stdout

    old_worlds, new_worlds, old_configs, new_configs = {}, {}, {}, {}
    sources = {}
    for scene in ('open', 'rooms', 'corridors'):
        world = P.WORLD_PREFIX + 'p1c_' + scene + '.world'
        config = P.CONFIG_PREFIX + scene + '.json'
        before = (ROOT / world).read_bytes()
        contract = (ROOT / config).read_bytes()
        for relative, raw in ((world, before), (config, contract)):
            normative = run(['git', 'show', W7 + ':' + relative], scene + '_' + Path(relative).suffix[1:] + '_w7')
            if raw != normative:
                raise RuntimeError('current source differs from normative W7: ' + relative)
            sources[relative] = sha(raw)
        if before.count(P.ANCHOR) != 1 or b'<ode>' in before:
            raise RuntimeError('unexpected existing world physics source')
        after = before.replace(P.ANCHOR, P.ANCHOR + P.ODE_BLOCK, 1)
        old_worlds[world], new_worlds[world] = before, after
        old_digest, new_digest = sha(before), sha(after)
        old_field = ('  "world_sha256": "' + old_digest + '",\n').encode()
        new_field = ('  "world_sha256": "' + new_digest + '",\n').encode()
        if contract.count(old_field) != 1:
            raise RuntimeError('unexpected task world SHA declaration')
        new_contract = contract.replace(old_field, new_field, 1)
        old_configs[config], new_configs[config] = contract, new_contract
        for label, raw in [('old', before), ('proposed', after)]:
            output = HERE / label / 'worlds' / Path(world).name
            output.parent.mkdir(parents=True, exist_ok=True)
            with output.open('xb') as stream:
                stream.write(raw)
            physics = ET.fromstring(raw).find('world/physics')
            minimal = ('<sdf version="1.7"><world name="cpu_only">' +
                       ET.tostring(physics, encoding='unicode') + '</world></sdf>\n')
            with (HERE / (scene + '_' + label + '_physics.sdf')).open('x') as stream:
                stream.write(minimal)
        for label, raw in [('old', contract), ('proposed', new_contract)]:
            output = HERE / label / 'config' / Path(config).name
            output.parent.mkdir(parents=True, exist_ok=True)
            with output.open('xb') as stream:
                stream.write(raw)
    world_pins = {key: sha(raw) for key, raw in new_worlds.items()}
    config_pins = {key: sha(raw) for key, raw in new_configs.items()}
    for relative, raw in new_worlds.items():
        assert P.projected_world(relative, old_worlds[relative], raw, world_pins) == old_worlds[relative]
    for relative, raw in new_configs.items():
        scene = Path(relative).stem
        world = P.WORLD_PREFIX + 'p1c_' + scene + '.world'
        assert P.projected_task_metadata(relative, old_configs[relative], raw, config_pins,
                                         sha(old_worlds[world]), sha(new_worlds[world])) == old_configs[relative]

    flags = shlex.split(run(['pkg-config', '--cflags', 'sdformat9'], 'sdformat_cflags').decode())
    libs = shlex.split(run(['pkg-config', '--libs', 'sdformat9'], 'sdformat_libs').decode())
    version = run(['pkg-config', '--modversion', 'sdformat9'], 'sdformat_version').decode().strip()
    executable = HERE / 'normalize_physics_cpu'
    run(['/usr/bin/g++', '-std=c++17', '-Wall', '-Wextra', '-Werror',
         str(HERE / 'normalize_physics.cpp'), '-o', str(executable)] + flags + libs, 'compile_parser')
    physics_rows = []
    for scene in ('open', 'rooms', 'corridors'):
        values = {}
        for label in ('old', 'proposed'):
            raw = run([str(executable), str(HERE / (scene + '_' + label + '_physics.sdf'))],
                      scene + '_' + label + '_normalize')
            values[label] = ET.fromstring(raw)
        def flatten(node, prefix=''):
            path = prefix + '/' + node.tag
            rows = {path + '/@' + key: value for key, value in node.attrib.items()}
            if node.text and node.text.strip():
                rows[path] = node.text.strip()
            for child in node:
                rows.update(flatten(child, path))
            return rows
        old, new = flatten(values['old']), flatten(values['proposed'])
        differences = {key: [old.get(key), new.get(key)] for key in sorted(set(old) | set(new))
                       if old.get(key) != new.get(key)}
        if differences != {'/physics/ode/solver/iters': ['50', '150']}:
            raise RuntimeError('normalized effective physics difference was not solely iters: ' + repr(differences))
        physics_rows.append({'scene': scene, 'normalized_parameters': len(old),
                             'differences': differences, 'complete_old': old, 'complete_proposed': new})

    # Use actual pure task/geometry code, without importing or initializing ROS.
    sys.path.insert(0, str(ROS / 'src/multi_robot_exploration'))
    from multi_robot_exploration.mr3_task_contract import load_task_contract, load_contract_truth
    import numpy as np
    geometry = []
    for scene in ('open', 'rooms', 'corridors'):
        old_world = HERE / 'old/worlds' / ('p1c_' + scene + '.world')
        new_world = HERE / 'proposed/worlds' / old_world.name
        old_config = HERE / 'old/config' / (scene + '.json')
        new_config = HERE / 'proposed/config' / old_config.name
        try:
            load_task_contract(old_config, new_world)
        except ValueError as error:
            old_reject = str(error)
        else:
            raise RuntimeError('old task SHA unexpectedly accepted modified world')
        before = load_contract_truth(old_world, load_task_contract(old_config, old_world))
        after = load_contract_truth(new_world, load_task_contract(new_config, new_world))
        if not np.array_equal(before.occupied, after.occupied):
            raise RuntimeError('task geometry raster changed')
        geometry.append({'scene': scene, 'shape': list(before.occupied.shape),
                         'occupied_cells': int(np.count_nonzero(before.occupied)),
                         'free_cells': int(before.occupied.size - np.count_nonzero(before.occupied)),
                         'mask_sha256': sha(before.occupied.tobytes()),
                         'mask_identical': True, 'old_contract_with_new_world_rejected': old_reject,
                         'actual_new_truth_world_sha256': after.world_sha256,
                         'expected_new_world_sha256': sha(new_world.read_bytes())})

    mutations = []
    world = P.WORLD_PREFIX + 'p1c_open.world'
    config = P.CONFIG_PREFIX + 'open.json'
    world_cases = {
        'additional_solver_parameter': new_worlds[world].replace(b'<iters>150</iters>',
                                      b'<iters>150</iters><sor>1.4</sor>'),
        'geometry_change': new_worlds[world].replace(b'12.2 0.2 2', b'12.3 0.2 2', 1),
        'duplicate_ode_block': new_worlds[world].replace(P.ODE_BLOCK, P.ODE_BLOCK * 2),
        'changed_physics_step': new_worlds[world].replace(b'>0.001<', b'>0.002<', 1),
    }
    for label, raw in world_cases.items():
        pins = dict(world_pins, **{world: sha(raw)})
        try:
            P.projected_world(world, old_worlds[world], raw, pins)
        except ValueError as error:
            mutations.append({'case': label, 'rejected': True, 'error': str(error)})
        else:
            raise RuntimeError('world mutation accepted: ' + label)
    old_world_sha, new_world_sha = sha(old_worlds[world]), sha(new_worlds[world])
    config_cases = {
        'task_threshold_change': new_configs[config].replace(b'0.95', b'0.94', 1),
        'wrong_actual_world_sha': new_configs[config].replace(new_world_sha.encode(), b'0' * 64, 1),
        'duplicate_world_sha_field': new_configs[config].replace(
            b'  "world_sha256":', b'  "world_sha256": "' + new_world_sha.encode() + b'",\n  "world_sha256":', 1),
        'roi_change': new_configs[config].replace(b'-6.1', b'-6.2', 1),
    }
    for label, raw in config_cases.items():
        pins = dict(config_pins, **{config: sha(raw)})
        try:
            P.projected_task_metadata(config, old_configs[config], raw, pins,
                                      old_world_sha, new_world_sha)
        except ValueError as error:
            mutations.append({'case': label, 'rejected': True, 'error': str(error)})
        else:
            raise RuntimeError('task mutation accepted: ' + label)
    patch = ''
    for before, after in ((old_worlds, new_worlds), (old_configs, new_configs)):
        for relative in before:
            patch += ''.join(difflib.unified_diff(
                before[relative].decode().splitlines(True), after[relative].decode().splitlines(True),
                fromfile='a/' + relative, tofile='b/' + relative))
    with (HERE / 'review_only.patch').open('x') as stream:
        stream.write(patch)
    for relative, digest in sources.items():
        if sha((ROOT / relative).read_bytes()) != digest:
            raise RuntimeError('canonical source changed during CPU check')
    receipt = {'schema': 'mr3-conditional-world-iters150-cpu-proposal-v1', 'passed': True,
               'conditional_only': True, 'v19_formal_result_consumed': False,
               'sdformat_version': version, 'physics': physics_rows, 'geometry': geometry,
               'projection_positive_worlds': 3, 'projection_positive_task_metadata': 3,
               'projection_mutations': mutations, 'original_sources_before_after': sources,
               'prospective_world_pins': world_pins, 'prospective_task_metadata_pins': config_pins,
               'commands': commands, 'wall_seconds': time.monotonic() - started,
               'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'scope': 'Only a prospective six-file patch and pure CPU SDFormat/task-geometry checks; '
                        'no Gazebo/ROS/DDS initialization, production rebuild, native/formal run or canonical mutation.'}
    with (HERE / 'checks_v1.json').open('x') as stream:
        json.dump(receipt, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'passed': True, 'normalized_physics_differences':
                      [row['differences'] for row in physics_rows],
                      'geometry_masks_identical': True, 'rejected_mutations': len(mutations),
                      'wall_seconds': receipt['wall_seconds']}))


if __name__ == '__main__':
    main()
