#!/usr/bin/python3
"""One read-only review of already closed synthetic component probe outputs."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import math
import os
import time

D = Path(__file__).parent
PAIR = Path('/tmp/mr3_p2a0_v25_actual_probe_pair_v1')


def ident(s):
    return [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns]


def bound(path):
    before = path.stat()
    raw = path.read_bytes()
    assert ident(before) == ident(path.stat())
    return raw, {'path': str(path), 'resolved': str(path.resolve()), 'bytes': len(raw),
                 'sha256': hashlib.sha256(raw).hexdigest(), 'stat': ident(before)}


def parse_identity(raw):
    head, tail = raw.rsplit(') ', 1)
    fields = tail.split()
    return {'pid': int(head.split(' ', 1)[0]), 'start_ticks': int(fields[19]), 'state': fields[0]}


def main():
    started = time.monotonic()
    basepaths = [Path(__file__), PAIR / 'execution_v1.json', PAIR / 'stock_probe.json', PAIR / 'fixed_probe.json']
    captured = [bound(p) for p in basepaths]
    execution = json.loads(captured[1][0])
    assert execution['passed'] is True and execution['errors'] == []
    assert len(execution['children']) == 2
    libraries = {}
    binding_rows = []
    for row in execution['bindings']:
        path = Path(row['path'])
        raw, current = bound(path)
        assert current['sha256'] == row['sha256'] and current['stat'] == row['stat']
        binding_rows.append((path, current))
        if path.name == 'libvelocity_smoother_core.so':
            libraries['stock' if str(path).startswith('/opt/ros/') else 'fixed'] = current
    assert libraries['stock']['sha256'] == '3581b317ef094f77b6bdab8df122c438ff7a8f8d09154eed7cc5f736e10576cf'
    assert libraries['fixed']['sha256'] == 'ceedf1b35cc501e9caa655c5b0a66f538395893664ec683a6290760f37d60b52'
    reviews = {}
    for index,mode in enumerate(('stock', 'fixed'),2):
        raw, report_binding = captured[index]
        value = json.loads(raw)
        child = next(x for x in execution['children'] if x['mode'] == mode)
        assert child['result']['sha256'] == report_binding['sha256']
        assert value['mode'] == mode and value['passed'] is True and value['normal_cleanup'] is True
        assert value['final_lifecycle_state'] == 1 and child['returncode'] == 0
        assert value['process_id'] == child['identity_at_spawn']['pid']
        assert value['wall_seconds'] <= 15 and child['wall_seconds'] <= 15
        assert value['timer_is_steady_after_activate'] is (mode == 'stock')
        assert value['timer_is_steady_after_frequency_change'] is (mode == 'stock')
        assert os.path.samefile(value['loaded_library_path'], libraries[mode]['path'])
        initial = parse_identity(value['process_stat_at_start'])
        final = parse_identity(value['process_stat_at_end'])
        saved = child['identity_at_spawn']
        assert initial['pid'] == final['pid'] == saved['pid']
        assert initial['start_ticks'] == final['start_ticks'] == saved['start_ticks']
        current_stat_path = Path('/proc') / str(saved['pid']) / 'stat'
        try:
            fresh = parse_identity(current_stat_path.read_text())
        except FileNotFoundError:
            fresh = None
        assert fresh is None or fresh['start_ticks'] != saved['start_ticks']
        mapped = {}
        library = libraries[mode]
        for name in ('process_maps_at_start', 'process_maps_at_end'):
            lines = []
            for line in value[name].splitlines():
                fields = line.split(None, 5)
                if len(fields) != 6 or not fields[5].startswith('/'):
                    continue
                path = Path(fields[5])
                if path.exists() and os.path.samefile(path, library['path']):
                    device = fields[3].split(':')
                    assert int(fields[4]) == library['stat'][1]
                    assert int(device[0],16) == os.major(library['stat'][0])
                    assert int(device[1],16) == os.minor(library['stat'][0])
                    lines.append(line)
            assert lines
            mapped[name] = lines
        samples = value['samples']
        gids = set()
        for sample in samples:
            assert type(sample['component_clock_ns']) is int
            assert type(sample['wall_elapsed_ns']) is int
            assert type(sample['linear_x']) in (int,float) and math.isfinite(sample['linear_x'])
            assert type(sample['angular_z']) in (int,float) and math.isfinite(sample['angular_z'])
            assert abs(sample['linear_x']) <= .20 and abs(sample['angular_z']) <= .8
            gid = sample['publisher_gid']
            assert type(gid) is str and len(gid) == 48 and set(gid) <= set('0123456789abcdef')
            assert any(x != '0' for x in gid)
            gids.add(gid)
        assert len(gids) == 1
        assert all(a['wall_elapsed_ns'] < b['wall_elapsed_ns'] for a,b in zip(samples,samples[1:]))
        counts = dict(Counter(x['phase'] for x in samples))
        if mode == 'stock':
            assert counts == {'paused_20hz': 7, 'advance_20hz': 9, 'paused_10hz': 3, 'advance_10hz': 5}
            assert all(x['component_clock_ns'] == 1000000000 for x in samples if x['phase'] == 'paused_20hz')
            assert all(x['component_clock_ns'] == 1450000000 for x in samples if x['phase'] == 'paused_10hz')
        else:
            assert counts == {'advance_20hz': 9, 'advance_10hz': 5}
        assert value['paused_20hz_output_count'] == counts.get('paused_20hz',0)
        assert value['paused_10hz_output_count'] == counts.get('paused_10hz',0)
        reviews[mode] = {'report': report_binding, 'library': library, 'actual_maps': mapped,
                         'identity': saved, 'fresh_identity_after_review': fresh, 'same_identity_gone': True,
                         'returncode': child['returncode'], 'normal_cleanup': True, 'final_lifecycle_state': 1,
                         'child_wrapper_wall_seconds': child['wall_seconds'], 'reported_component_wall_seconds': value['wall_seconds'],
                         'phase_counts': counts, 'publisher_gid': next(iter(gids)),
                         'steady_after_activation_and_dynamic': [value['timer_is_steady_after_activate'], value['timer_is_steady_after_frequency_change']],
                         'actual_parameters': value['actual_configured_parameters'], 'samples': samples,
                         'caps_strictly_passed': True}
    assert reviews['stock']['publisher_gid'] != reviews['fixed']['publisher_gid']
    fixed = reviews['fixed']['samples']
    increments = []
    for a,b in zip(fixed, fixed[1:]):
        frequency = 20 if b['phase'] == 'advance_20hz' else 10
        period = 50000000 if frequency == 20 else 100000000
        linear_bound, angular_bound = (.025,.16) if frequency == 20 else (.05,.32)
        assert b['component_clock_ns'] - a['component_clock_ns'] == period
        dv = abs(b['linear_x'] - a['linear_x'])
        dw = abs(b['angular_z'] - a['angular_z'])
        linear_tolerance = 4 * math.ulp(linear_bound)
        angular_tolerance = 4 * math.ulp(angular_bound)
        assert dv <= linear_bound + linear_tolerance
        assert dw <= angular_bound + angular_tolerance
        increments.append({'from_clock_ns': a['component_clock_ns'], 'to_clock_ns': b['component_clock_ns'],
                           'phase': b['phase'], 'frequency_hz': frequency,
                           'absolute_dv': dv, 'absolute_dw': dw,
                           'linear_bound': linear_bound, 'angular_bound': angular_bound,
                           'linear_4ulp_tolerance': linear_tolerance, 'angular_4ulp_tolerance': angular_tolerance,
                           'dv_excess_above_binary64_bound': max(0.,dv-linear_bound),
                           'dw_excess_above_binary64_bound': max(0.,dw-angular_bound)})
    assert len(increments) == 13
    summary = {}
    for frequency in (20,10):
        selected = [x for x in increments if x['frequency_hz'] == frequency]
        summary[str(frequency)] = {'adjacent_observed_callback_pairs': len(selected),
                                   'max_abs_dv': max(x['absolute_dv'] for x in selected),
                                   'max_abs_dw': max(x['absolute_dw'] for x in selected),
                                   'passed_with_declared_binary64_tolerance': True}
    assert summary['20']['adjacent_observed_callback_pairs'] == 8
    assert summary['10']['adjacent_observed_callback_pairs'] == 5
    for path,record in binding_rows:
        assert bound(path)[1] == record
    assert captured == [bound(path) for path in basepaths]
    result = {'schema': 'mr3-v25-real-probe-independent-sample-review-v1', 'passed': True,
              'scope': 'Independent read-only check of actual closed synthetic ROS component probe records, ELF maps/identity and adjacent observed callback increments only; no native, body, continuous-time, exploration or matrix credit.',
              'input_bindings': [x[1] for x in captured],
              'actual_execution_source_library_bindings_rechecked': [x[1] for x in binding_rows],
              'actual_execution_passed': execution['passed'], 'pair_wall_seconds': execution['wall_seconds'],
              'sum_actual_child_wrapper_wall_seconds': execution['actual_probe_child_wall_seconds'],
              'modes': reviews, 'fixed_observed_adjacent_increments': increments, 'fixed_increment_summary': summary,
              'floating_tolerance_contract': 'Exactly4*math.ulp of each binary64 increment bound, only for subtraction/nominal-increment roundoff in this descriptive callback comparison. Commandcap checks remain exact. No task/physical gate or data changed.',
              'first_fixed_sample_without_observed_zero_predecessor': fixed[0],
              'first_sample_scope': 'No virtual zero callback fabricated.20Hz comparison has8 actual adjacent pairs;10Hz has5 including actual1.45-to1.55 frequency-boundary pair.',
              'conclusions_zh': ['Stock在不变ROSclock实际发布7次/3次并推进输出；fixed两暂停段均0次，两次timer均非steady。',
                                  'Fixed恢复时9个20Hz与5个10Hz实际输出存在，实际相邻13对增量在声明4ULP减法容差内符合.025/.16及.05/.32。',
                                  '每个child实际loaded库、inode/device/maps、GID和PID/start闭合一致；两child均正常回到unconfigured、exit0、fresh同身份gone。',
                                  '本次机制验证不能覆盖V24真实body1.20619失败，也不能证明V25完整矩阵/连续身体界或95%策略出口。'],
              'all_inputs_end_stable': True, 'build_probe_or_native_executed_by_reviewer': False,
              'review_wall_seconds': time.monotonic() - started}
    out = D / 'review_v1.json'
    assert not out.exists()
    out.write_text(json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    print(json.dumps({'review': str(out), 'sha256': hashlib.sha256(out.read_bytes()).hexdigest(),
                      'passed': True, 'fixed_increment_summary': summary, 'inputs_end_stable': True}))

if __name__ == '__main__':
    main()
