"""Copy sealed V20 bytes without changing any original research result."""
import hashlib
import json
from pathlib import Path
import shutil
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
SOURCE = Path('/tmp/mr3_p2a0_v20_sensor_selected_native_v1')
TARGET = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v20_sensor'
started = time.monotonic()
files = sorted(p for p in SOURCE.rglob('*') if p.is_file())
assert len(files) == 189, len(files)
assert sum(p.name.endswith(".gz") for p in files) == 184
rows = []
for source in files:
    relative = source.relative_to(SOURCE)
    destination = TARGET / relative
    assert not destination.exists(), destination
    before = source.stat()
    raw = source.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    assert hashlib.sha256(destination.read_bytes()).hexdigest() == digest
    after = source.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns,
            before.st_ctime_ns) == (after.st_dev, after.st_ino, after.st_size,
                                    after.st_mtime_ns, after.st_ctime_ns)
    rows.append({'source': str(source), 'canonical': str(destination.relative_to(ROOT)),
                 'bytes': len(raw), 'sha256': digest})
result = {'schema': 'mr3-v20-closed-canonical-copy-v1', 'passed': True,
          'freeze': 'b33ff70084be6419edc3d0d91a26d6db3936ff45',
          'scope': 'Exact copy of sealed custody; physical False and e61c SKIP unchanged.',
          'files': rows, 'file_count': len(rows),
          'total_bytes': sum(row['bytes'] for row in rows),
          'wall_seconds': time.monotonic() - started}
(TARGET / 'closed_canonical_copy_v1.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('passed', 'file_count', 'total_bytes', 'wall_seconds')}))
