"""Pure counterexample: old V5 filter swallowed one NaN margin; no native run."""
import ast
import hashlib
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
FILES = ('checks_v2_source_benchmark.py', 'benchmark.py')
result = {"schema": "mr3-v16-nonapproach-overflow-redgreen-v1", "native_credit": False,
          "source_snapshot": {}, "observations": {}}
snapshot = {"robots": [{"x": 0., "y": 0., "fresh": True, "valid": True},
                       {"x": 0., "y": 1., "fresh": True, "valid": True},
                       {"x": -1e308, "y": 0., "fresh": True, "valid": True}],
            "candidates": [{"x": 1e308, "y": 0., "path_distances_m": [1., 1., 1.]}]}
for name in FILES:
    path = HERE / name
    raw = path.read_bytes()
    result["source_snapshot"][name] = hashlib.sha256(raw).hexdigest()
    defs = [node for node in ast.parse(raw).body if isinstance(node, ast.FunctionDef)
            and node.name in ('_probe_goal_order', '_probe_nonapproaching_goal_action')]
    namespace = {"math": math}
    exec(compile(ast.Module(body=defs, type_ignores=[]), str(path), 'exec'), namespace)
    result["observations"][name] = namespace['_probe_nonapproaching_goal_action'](snapshot, 88)
result["passed"] = (result["observations"][FILES[0]] is True
                    and result["observations"][FILES[1]] is False)
output = HERE / 'overflow_redgreen_v1.json'
with output.open('x') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
print(json.dumps(result, indent=2, allow_nan=False))
raise SystemExit(0 if result['passed'] else 1)
