"""Exact-Fraction checks of frozen and proposed compiled headers; no ROS/native."""
import ctypes
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
import random
import time

ROOT=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
lib=ctypes.CDLL(str(ROOT/'probe.so'));lib.replay.argtypes=[ctypes.c_int,ctypes.POINTER(ctypes.c_double),ctypes.POINTER(ctypes.c_double)]
f=lambda x:F.from_float(float(x))
def replay(values, old):
    inputs=(ctypes.c_double*6)(*values);out=(ctypes.c_double*3)();lib.replay(old,inputs,out);return list(out)
def check(values, outputs):
    c=values[:2];d=values[2:4];a,dt=values[4:];applied=outputs[:2];alpha=outputs[2]
    if a==0:return {'disabled_exact':applied==d and alpha==1.}
    if dt==0:return {'zero_dt_exact':applied==c and alpha==0.}
    budget=f(a)*f(dt);largest=max(abs(f(y)-f(x)) for x,y in zip(c,d));nominal=F(1) if largest<=budget else budget/largest
    return {'finite':all(math.isfinite(v) for v in outputs),
            'alpha_range':0<=alpha<=1,
            'exact_inward_alpha':f(alpha)<=nominal,
            'exact_wheel_budget':all(abs(f(v)-f(x))<=budget for x,v in zip(c,applied)),
            'exact_convex_segment':all(min(f(x),f(y))<=f(v)<=max(f(x),f(y)) for x,y,v in zip(c,d,applied)),
            'native_math_gate':True if max(map(abs,c+d))>1. or a!=1. or dt!=.034 else all(abs(v-(x+alpha*(y-x)))<=1e-12 for x,y,v in zip(c,d,applied)),
            'native_nominal_closeness':True if max(map(abs,c+d))>1. or a!=1. or dt!=.034 else abs(float(nominal)-alpha)<=1e-12}
source=Path('/tmp/mr3_p2a0_v12_drive_alpha_original_rows_v1.json');captured=source.read_bytes();real=json.loads(captured)
cases=[]
for item in real['items']:
 row=next(v['row'] for v in item['context'] if v['line']==item['requested_line'])
 cases.append(('actual_frozen_line_'+str(item['requested_line']),row['current_rim_mps']+row['desired_rim_mps']+[row['max_acceleration_mps2'],row['dt_sec']]))
cases += [('tiny_fastpath',[-1e-300,0.,.034,0.,1.,.034]),('tiny_within_budget',[-1e-300,0.,.2,0.,1.,.034]),('tiny_opposite',[1e-300,0.,-.034,0.,1.,.034]),('disabled',[.1,-.2,.3,-.4,0.,.034]),('zero_dt',[.1,-.2,.3,-.4,1.,0.])]
for e in (-1022,-500,-100,-60,-54,-53,-52,-40,-1,0,40,500,1000):
 b=math.ldexp(1.,e);tiny=math.ldexp(1.,max(-1074,e-100))
 for sign in (-1.,1.):
  for endpoint in (math.nextafter(b,0.),b,math.nextafter(b,math.inf)):
   cases.append(('near_equality',[sign*tiny,0.,-sign*endpoint,0.,b,1.]))
rng=random.Random(20261017)
for index in range(20000):
 c=[rng.uniform(-.5,.5),rng.uniform(-.5,.5)];d=[rng.uniform(-.5,.5),rng.uniform(-.5,.5)]
 if index%17==0:d=[0.,0.]
 cases.append(('native_scale',c+d+[1.,.034]))
for index in range(10000):
 draw=lambda:math.ldexp(rng.uniform(.5,1.),rng.randint(-1073,1023))
 c=[draw()*rng.choice((-1.,1.)),draw()*rng.choice((-1.,1.))];d=[draw()*rng.choice((-1.,1.)),draw()*rng.choice((-1.,1.))]
 cases.append(('scale_random',c+d+[draw(),draw()]))
began=time.monotonic();old_fail={};new_fail={};examples=[];actual=[]
for index,(kind,values) in enumerate(cases):
 old=replay(values,1);new=replay(values,0);oc=check(values,old);nc=check(values,new)
 for key,val in oc.items():
  if not val:old_fail[key]=old_fail.get(key,0)+1
 for key,val in nc.items():
  if not val:new_fail[key]=new_fail.get(key,0)+1
 if index<7:actual.append({'kind':kind,'inputs':values,'original_outputs':old,'proposed_outputs':new,'original_checks':oc,'proposed_checks':nc})
 if not all(nc.values()) and len(examples)<20:examples.append({'index':index,'kind':kind,'inputs':values,'outputs':new,'checks':nc})
result={'schema':'mr3-paired-wheel-directed-numeric-proposal-checks-v1','scope':'Pure finite CPU model on this host, not native plant or universal arbitrary-FPU proof; production and old formal reader unchanged','passed':not new_fail,'original_failures':old_fail,'proposed_failures':new_fail,'proposed_counterexamples':examples,'explicit_cases':actual,'case_count':len(cases),'case_groups':{'actual':2,'tiny_or_disabled_or_zero':5,'near_equality':78,'native_scale_random':20000,'wide_scale_random':10000},'seed':20261017,'long_double_digits':lib.long_double_digits(),'rounding_mode':lib.rounding_mode(),'FE_TONEAREST_value':0,'wall_sec':time.monotonic()-began,'bindings':{str(p):sha(p.read_bytes()) for p in [ROOT/'original.hpp',ROOT/'proposed.hpp',ROOT/'probe.cpp',ROOT/'probe.so',Path(__file__),source]},'original_rows_unchanged':source.read_bytes()==captured,'compiler_argv':['g++','-std=c++17','-O2','-Wall','-Wextra','-Werror','-pedantic','-shared','-fPIC',str(ROOT/'probe.cpp'),'-o',str(ROOT/'probe.so')],'run_argv':['python3',str(Path(__file__))],'original_formal_FAIL_preserved':True}
output=ROOT/'checks_v1.json';output.write_text(json.dumps(result,indent=2)+'
');print(json.dumps({k:v for k,v in result.items() if k not in ('bindings','explicit_cases')},indent=2));raise SystemExit(0 if result['passed'] else 1)
