"""Actual provisional CPU wait; all link fixture scientific facts are artificial."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

BASE=Path(__file__).resolve().parent
OUT=BASE/"checks/provisional_contract_cpu_v2"

def identity(pid):
    try:
        fields=(Path("/proc")/str(pid)/"stat").read_text().rsplit(")",1)[1].split()
        return {"pid":pid,"parent":int(fields[1]),"start_ticks":int(fields[19]),"state":fields[0]}
    except FileNotFoundError:return None

def digest(path):
    raw=path.read_bytes();return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}

def dump(path,value):
    with path.open("x") as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write("\n")

OUT.mkdir(parents=True,exist_ok=False)
paths=sorted([*BASE.glob("candidate/**/*.py"),*BASE.glob("tests/*.py"),Path(__file__).resolve()])
before={str(path):digest(path) for path in paths};dump(OUT/"sources_before_v1.json",before)
env=dict(os.environ,PYTHONNOUSERSITE="1",PYTHONDONTWRITEBYTECODE="1")
for key in ("PYTHONPATH","PYTHONHOME"):env.pop(key,None)
argv=["/usr/bin/python3","-B",str(BASE/"tests/test_link_contract_v1.py")]
receipt={"schema":"mr3-provisional-exact-seed-link-contract-cpu-v1","qualification_credit":False,
    "scientific_facts_artificial":True,"reader_native_raw_executed":False,"argv":argv,"cwd":str(BASE),
    "runner_identity":identity(os.getpid()),"parent_identity":identity(os.getppid()),"child_identity":None,
    "started_monotonic_ns":time.monotonic_ns(),"actual_waited":False,"returncode":None,"errors":[]}
child=None
with (OUT/"console.log").open("xb") as stream:
    try:
        child=subprocess.Popen(argv,cwd=BASE,env=env,stdout=stream,stderr=subprocess.STDOUT)
        receipt["child_identity"]=identity(child.pid)
        if receipt["child_identity"] is None:raise ValueError("actual CPU child start not captured")
    except BaseException as error:receipt["errors"].append(repr(error))
    finally:
        if child is not None:
            while True:
                try:receipt["returncode"]=child.wait();receipt["actual_waited"]=True;break
                except BaseException as error:receipt["errors"].append(repr(error))
receipt["ended_monotonic_ns"]=time.monotonic_ns()
receipt["actual_wall_seconds"]=(receipt["ended_monotonic_ns"]-receipt["started_monotonic_ns"])/1e9
after={str(path):digest(path) for path in paths};dump(OUT/"sources_after_v1.json",after)
receipt["sources_unchanged"]=before==after
receipt["child_after_wait"]=None if child is None else identity(child.pid)
receipt["passed"]=receipt["returncode"]==0 and not receipt["errors"] and receipt["sources_unchanged"] and receipt["child_after_wait"] is None
receipt["console"]=digest(OUT/"console.log")
dump(OUT/"actual_receipt_v1.json",receipt)
print(json.dumps({"passed":receipt["passed"],"returncode":receipt["returncode"],"wall_seconds":receipt["actual_wall_seconds"],"output":str(OUT)}))
raise SystemExit(0 if receipt["passed"] else 1)
