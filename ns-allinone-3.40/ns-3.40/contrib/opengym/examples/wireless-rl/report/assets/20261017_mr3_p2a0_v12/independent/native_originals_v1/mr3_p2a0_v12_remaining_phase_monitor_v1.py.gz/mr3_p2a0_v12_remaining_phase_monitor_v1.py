"""Bounded read-only live facts; never a formal native PASS or control client."""
import datetime
import hashlib
import json
from pathlib import Path
import time

RUN = Path('/home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261017_v12_interface')
LAUNCH = Path('/tmp/mr3_p2a0_v12_interface_launch.json')
OUT = Path('/tmp/mr3_p2a0_v12_interface_phase_monitor_v2.jsonl')
FREEZE = '6b1b4a0108351f5bfb70ec0c96ba895248d4f7a8'


def read_json(path):
    try:
        return json.loads(path.read_bytes())
    except (OSError, ValueError) as error:
        return {'observer_unavailable': str(error)}


def rows(path, head=False, maximum=512 * 1024):
    try:
        size = path.stat().st_size
        with path.open('rb') as stream:
            start = 0 if head else max(0, size - maximum)
            stream.seek(start)
            raw = stream.read(maximum)
        lines = raw.splitlines()
        if start and lines:
            lines = lines[1:]
        result = []
        for line in lines:
            try:
                result.append(json.loads(line))
            except ValueError:
                continue
        return result
    except OSError:
        return []


def identity(saved):
    if not saved:
        return None
    try:
        raw = Path('/proc/' + str(saved['pid']) + '/stat').read_text()
        values = raw[raw.rfind(')') + 2:].split()
        actual = {'pid': saved['pid'], 'start_ticks': int(values[19]), 'state': values[0]}
        return {**actual, 'same_identity': actual['start_ticks'] == saved['start_ticks']}
    except (OSError, ValueError, KeyError):
        return {'pid': saved.get('pid'), 'same_identity': False, 'absent_or_unreadable': True}


def compact_control(row):
    result = {key: row[key] for key in ['kind', 'component', 'worker_clock_ns',
              'worker_physical_ns', 'wall_monotonic_ns'] if key in row}
    value = row.get('ack', row.get('request', row.get('status', {})))
    result['payload'] = {key: value[key] for key in ['operation', 'request_id', 'ok', 'error',
                         'clock_ns', 'target_time_ns', 'phase_kind', 'ready'] if key in value}
    if isinstance(value.get('status'), dict):
        result['status'] = {key: value['status'].get(key) for key in
                            ['clock_ns', 'phase_kind', 'ready', 'decision_sequences']}
    return result


def observe():
    launch = read_json(LAUNCH)
    snapshot = {'schema': 'mr3-v12-readonly-live-facts-v1', 'freeze': FREEZE,
                'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'wall_monotonic_ns': time.monotonic_ns(), 'launch_status': launch.get('status'),
                'launch_returncode': launch.get('returncode'),
                'parent': identity(launch.get('benchmark_parent')),
                'scope': 'Live observations only; no PASS, completed audits or physical credit',
                'episodes': []}
    for episode in sorted(RUN.glob('worker*/episode*')):
        if not episode.is_dir():
            continue
        metadata = read_json(episode / 'metadata.json')
        item = {'directory': str(episode), 'epoch': metadata.get('epoch'),
                'files': {name: (episode / name).stat().st_size for name in
                    ['control_phase_worker.jsonl', 'transitions.jsonl', 'physics.jsonl',
                     'peer_phase.jsonl', 'information_states.jsonl', 'motion_safety.jsonl']
                    if (episode / name).is_file()}}
        transition = []
        try:
            with (episode / 'transitions.jsonl').open('rb') as stream:
                for line in stream:
                    try:
                        transition.append(json.loads(line))
                    except ValueError:
                        pass
        except OSError:
            pass
        item['actual_recorded_steps'] = sum(row.get('kind') == 'step' for row in transition)
        item['actual_recorded_resets'] = sum(row.get('kind') == 'reset' for row in transition)
        first = rows(episode / 'transitions.jsonl', head=True, maximum=1024 * 1024)
        item['reset_recorded'] = bool(first and first[0].get('kind') == 'reset')
        if transition:
            final = transition[-1]
            item['last_transition'] = {key: final.get(key) for key in
                                      ['kind', 'sequence', 'action', 'terminated', 'truncated']}
            item['last_snapshot_sequence'] = final.get('snapshot', {}).get('sequence')
        controls = rows(episode / 'control_phase_worker.jsonl')
        item['last_control_records'] = [compact_control(row) for row in controls[-4:]]
        prefix = rows(episode / 'control_phase_worker.jsonl', head=True, maximum=1024 * 1024)
        commits = [row for row in prefix if row.get('kind') == 'ack_consumed'
                   and row.get('component') == 'motion' and row.get('ack', {}).get('ok') is True
                   and row.get('ack', {}).get('operation') == 'commit']
        if commits:
            item['first_motion_commit_actual_receipt'] = compact_control(commits[0])
        physical = rows(episode / 'physics.jsonl')
        if physical:
            item['last_physics'] = physical[-1]
        for name in ['infrastructure_failure.json', 'infrastructure_cleanup.json',
                     'failed_sample.json', 'native_stop.json', 'nav2_shutdown.json', 'summary.json']:
            if (episode / name).exists():
                item[name] = read_json(episode / name)
        log = episode / 'worker.log'
        if log.exists():
            text = log.read_text(errors='replace')
            item['worker_log_bytes'] = len(text.encode())
            item['worker_log_tail'] = text.splitlines()[-4:]
        snapshot['episodes'].append(item)
    return snapshot



PLAN = Path('/home/zhuyulab/ns3-workspace/ns-allinone-3.40/ns-3.40/contrib/opengym/'
            'examples/wireless-rl/report/assets/20261017_mr3_p2a0_v12/predeclared_plan_v12.json')
PLAN_SHA = '264a9c5aa996938691a335f9f00c7102cfce8863b21bd5fe3b1191472d8aecbf'
LEDGER = Path('/tmp/mr3_p2a0_v12_remaining_matrix_v1.jsonl')
OUT = Path('/tmp/mr3_p2a0_v12_remaining_phase_monitor_v1.jsonl')
assert hashlib.sha256(PLAN.read_bytes()).hexdigest() == PLAN_SHA
STAGES = [stage for stage in json.loads(PLAN.read_text())['stages']
          if stage['stage'] in ('terminal', 'reset', 'deadline')]


def collect_identities(value, origin, found):
    if isinstance(value, dict):
        if type(value.get('pid')) is int and type(value.get('start_ticks')) is int:
            key = value['pid'], value['start_ticks']
            entry = found.setdefault(key, {'identity': value, 'origins': []})
            entry['origins'].append(origin)
        for key, child in value.items():
            collect_identities(child, origin + '.' + str(key), found)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            collect_identities(child, origin + '[' + str(index) + ']', found)


def final_facts(stage, run, launch_path):
    launch = read_json(launch_path)
    sources = [launch_path, *sorted(run.glob('worker*/*.json')),
               *sorted(run.glob('worker*/episode*/*.json'))]
    identities, proof = {}, {}
    for path in sources:
        raw = path.read_bytes()
        proof[str(path)] = hashlib.sha256(raw).hexdigest()
        collect_identities(json.loads(raw), str(path), identities)
    checked = []
    for item in identities.values():
        actual = identity(item['identity'])
        checked.append({**item, 'actual': actual,
                        'saved_identity_gone': not actual['same_identity']})
    episodes = []
    for directory in sorted(run.glob('worker*/episode*')):
        if not directory.is_dir():
            continue
        summary = read_json(directory / 'summary.json')
        nav = read_json(directory / 'nav2_shutdown.json')
        stop = read_json(directory / 'native_stop.json')
        transition = []
        path = directory / 'transitions.jsonl'
        if path.exists():
            transition = [json.loads(line) for line in path.open() if line.strip()]
        episodes.append({
            'directory': str(directory), 'epoch': summary.get('epoch'),
            'reset_records': sum(row['kind'] == 'reset' for row in transition),
            'step_records': sum(row['kind'] == 'step' for row in transition),
            'sampled_dt_sec': sum(row['info']['dt'] for row in transition if row['kind'] == 'step'),
            'native_stop': stop, 'nav2_shutdown_success': nav.get('success'),
            'managed_nodes_finalized': sum(node.get('state', {}).get('id') == 4
                                           for robot in nav.get('robots', [])
                                           for node in robot.get('states', [])),
            'closed': summary.get('closed'), 'native_failures': summary.get('native_failures'),
            'launch_returncode': summary.get('launch_returncode'),
            'worker_log_empty': (directory / 'worker.log').exists()
                                and (directory / 'worker.log').stat().st_size == 0,
        })
    return {'schema': 'mr3-v12-independent-phase-observation-final-v1', 'freeze': FREEZE,
            'stage': stage, 'observation_complete': True,
            'scope': 'Saved final facts and fresh dynamic identity absence only; '
                     'not a formal closure/FIFO/physics/source or overall stage verdict',
            'plan_sha256': PLAN_SHA, 'launch_returncode': launch.get('returncode'),
            'owned_identity_union_count': len(checked), 'no_fixed_identity_count_gate': True,
            'identity_checks': checked, 'all_saved_identities_gone': bool(checked)
            and all(item['saved_identity_gone'] for item in checked),
            'identity_checked_wall_monotonic_ns': time.monotonic_ns(), 'episodes': episodes,
            'source_proof': proof,
            'source_bytes_unchanged_during_observation': all(
                hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest
                for path, digest in proof.items())}


finished = set()
began = time.monotonic()
with OUT.open('x', buffering=1) as output:
    while time.monotonic() - began <= 20000:
        observation = {'schema': 'mr3-v12-remaining-readonly-live-v1', 'freeze': FREEZE,
                       'wall_monotonic_ns': time.monotonic_ns(), 'plan_sha256': PLAN_SHA,
                       'scope': 'Observer only; no control or audits or stage PASS', 'stages': []}
        for stage in STAGES:
            name = stage['stage']
            RUN = Path(stage['run_directory'])
            LAUNCH = Path('/tmp/mr3_p2a0_v12_' + name + '_launch.json')
            if not LAUNCH.exists():
                observation['stages'].append({'stage': name, 'observed_launch': False})
                continue
            value = observe()
            value['stage'] = name
            observation['stages'].append(value)
            if value['launch_status'] in ('completed', 'failed') and name not in finished:
                final = final_facts(name, RUN, LAUNCH)
                path = Path('/tmp/mr3_p2a0_v12_' + name + '_phase_observer_final_v1.json')
                with path.open('x') as stream:
                    json.dump(final, stream, indent=2)
                    stream.write('\n')
                finished.add(name)
        ledger = rows(LEDGER)
        observation['orchestration_last_event'] = ledger[-1].get('event') if ledger else None
        output.write(json.dumps(observation, sort_keys=True) + '\n')
        print(json.dumps({'wall_monotonic_ns': observation['wall_monotonic_ns'],
                          'stages': [{'stage': row['stage'],
                                      'launch': row.get('launch_status'),
                                      'episodes': [(episode.get('actual_recorded_resets'),
                                                    episode.get('actual_recorded_steps'))
                                                   for episode in row.get('episodes', [])]}
                                     for row in observation['stages']],
                          'orchestration_last_event': observation['orchestration_last_event']}),
              flush=True)
        if observation['orchestration_last_event'] in (
                'matrix_complete', 'version_failed_later_stages_skip'):
            break
        time.sleep(120.)
