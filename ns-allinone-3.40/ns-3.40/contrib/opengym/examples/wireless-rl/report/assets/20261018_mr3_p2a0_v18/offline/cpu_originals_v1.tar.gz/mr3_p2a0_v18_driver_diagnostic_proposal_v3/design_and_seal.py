"""Finalize a proposal/custody description only; no canonical writes."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import urllib.request

OUT=Path(__file__).parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


url='https://raw.githubusercontent.com/gazebosim/gazebo-classic/gazebo11_11.10.2/gazebo/physics/ode/ODEJoint.cc'
data=urllib.request.urlopen(url,timeout=20).read()
(OUT/'ODEJoint_11.10.2.cc').write_bytes(data)
check=json.loads((OUT/'checks_v1.json').read_bytes())
assert check['passed'] is True
design={
    'schema':'mr3-v18-read-only-stop-diagnostic-proposal-v1',
    'status':'candidate_only_not_promoted_not_executed',
    'baseline_freeze':'eee6b2f90f697b28a1c20a2af5d1a6d2f044465e',
    'recommended':'Separate opt-in read-only ModelPlugin. Existing a014 driver and all four compiled driver sources remain byte-for-byte unchanged.',
    'prospective_files':['src/multi_robot/src/mr3_stop_response_observer.cpp',
                         'src/multi_robot/CMakeLists.txt (only additional independent target)'],
    'default_behavior':'No plugin entry in the normal model or launch. Only a separately declared generated diagnostic SDF adds the observer; no production SDF/launch edits are included in this patch.',
    'alternatives':[
        {'method':'independent ModelPlugin','advantage':'No driver source, binary, control function, ROS QoS/topic or actuator phase changes. Two native Gazebo event subscriptions and one dedicated file only.',
         'cost':'One additional small shared library and explicit diagnostic-SDF plugin entry. Desired/private cmd sequence must be bound offline to unchanged original driver trace; GetParam(vel/fmax) is actual motor-parameter readback.'},
        {'method':'optional hooks inside existing driver','advantage':'Can directly snapshot private command and actuation sequence under its existing lock; no second library.',
         'cost':'Changes compiled driver source and .so, introduces instrumentation into the actuator owner, and requires repinning/rebuilding the driver. Original algorithm functions could remain text-identical but this gives weaker binary isolation.'},
        {'method':'existing 30Hz odometry or ROS GetEntityState polling','advantage':'No plugin development.',
         'cost':'Existing trace has one sample per34ms and cannot resolve intra-step velocity/pose behavior; service or DDS receipt timing does not guarantee paired pre/post1ms physics samples. Insufficient for the observed discrepancy.'}
    ],
    'events':{
        'before':'Events::ConnectBeforePhysicsUpdate(UpdateInfo), after collision detection and before PhysicsEngine::UpdatePhysics.',
        'after':'Events::ConnectWorldUpdateEnd(), after physics, dirtyPose propagation and contact publication.',
        'pairing':'Same actual world clock, explicit pair_sequence and before_record_sequence. Labels are event phases, not an invented elapsed time of zero. Pose before→after belongs to that physics update; spacing between successive pairs and actual GetMaxStepSize establish its duration.',
        'cadence':'Every native physics-update callback inside an explicit inclusive start_ns/end_ns capture window. The observer does not set step size; expected1ms must be checked against actual GetMaxStepSize and successive pair clocks in the future declared diagnostic.'},
    'records':{
        'configuration':['epoch/robot', 'loaded observer library path/compiled source SHA',
            'actual engine type/max step size/gravity',
            'typed GetParam readbacks: solver_type/cfm/erp/precon_iters/iters/sor/contact_max_correcting_vel/contact_surface_layer/max_contacts/max_step_size/sor_lcp_tolerance/use_dynamic_moi_rescaling/friction_model/world_step_solver',
            'canonical and explicit base_link names, window and flush policy'],
        'sample':['actual callback sim_time_ns/world_iterations/steady wall time and phase/pair identity',
            'model world pose/WorldLinearVel/WorldAngularVel',
            'canonical and explicit base_link world pose/CoG pose/origin WorldLinearVel/WorldCoGLinearVel/WorldAngularVel',
            'right/left joint position, feedback velocity, actual GetParam(vel) motor target, actual fmax and GetForce axis readback',
            'world-scoped typed rms_error/constraint_residual/num_contacts getters'],
        'no_false_identity':'No per-packet Twist or private driver sequence is invented. Native desired/applied/cmd/target sequence continues to come from original mr3-drive-actuation-v2 trace, joined by actual epoch/clock/order and compared with motor GetParam(vel).',
        'unknowns':'Unsupported physics GetParam/type is explicitly available=false, never zero. Joint GetForce is labeled as that API, not claimed to be the motor or solver reaction wrench.'},
    'future_analysis_no_gate_change':[
        'Compare model versus canonical origin versus base_link/CoG linear velocities at each phase, and test v_origin = v_cog - omega cross (CoGpos-originpos) as a coordinate/point diagnostic.',
        'Compare before→after1ms center displacement, pre/post velocity signs and their integral across34ms original odometry intervals. This can expose a phase-sampled residual versus sustained drift; finite differences remain sampled quantities and do not replace original .01/3sample/.78/.144 gates.',
        'Check actual motor velocity target0 alongside unchanged original driver applied0 and joint feedback. Correlate step-local velocity/pose changes with world solver residual/contact count; world residuals are not per-robot causal attribution.',
        'Original V17 physical failure remains original failure. Any new instrumentation run is a newly frozen bounded diagnostic and cannot supply retrospectively spliced V17 PASS or policy/training credit.'
    ],
    'effects_and_limits':[
        'Read-only getters and no publishers/setters preserve actuator code and equations, but synchronous getters/JSON/file I/O introduce real wall-time and callback-load effects. It is not zero overhead or a cross-process timing-equivalence claim.',
        'This candidate flushes each completed pre/post pair: nominal3000flush calls/sec for three robots at1kHz, plus writes. The future native budget must account for measured overhead; no performance or runtime correctness claim follows from syntax-only compilation.',
        'Any diagnostic write/pair/clock error throws and invalidates that diagnostic run. It may interrupt the engine, so failure must be retained as infrastructure failure; it is not silently ignored or labeled harmless.',
        'No actual collision-surface mu/contact-parameter getter is collected in this minimal patch. The effective diagnostic SDF/world/ground/robot must be archived and separately bound; this patch makes no claim that SDF-predicted friction was measured at runtime.',
        'The explicit observer base_link tag must be base_link for the current MR3 model, while canonical is independently queried. No fallback to base_footprint hides the distinct rigid-body point.',
        'No enabling SDF/launch patch, experiment command, new step/torque/friction/solver value, control-cap change, or stop-bound relaxation is provided or executed.'
    ],
    'offline_evidence':{'final_syntax_check':str(OUT/'checks_v1.json'),
        'final_syntax_exit':check['commands'][0]['exit_code'],
        'final_syntax_wall_sec':check['commands'][0]['wall_sec'],
        'earlier_failure':'../mr3_p2a0_v18_driver_diagnostic_proposal_v1/checks_v1.json: actual SDFormat9 Get<int64_t> template failure retained with original source and stdout; v2/v3 use strict decimal string→stoll.',
        'coverage_limit':'No shared library build/load, plugin factory/lifetime exercise, physics run, formal audit, data publication or parameter set. Future admission still needs these appropriate CPU checks and an explicit new bounded native declaration.'},
    'primary_sources':[
        {'url':'https://raw.githubusercontent.com/gazebosim/gazebo-classic/gazebo11_11.10.2/gazebo/physics/World.cc','selected':str(OUT/'World_11.10.2.cc'),'sha256':sha((OUT/'World_11.10.2.cc').read_bytes()),'scope':'official installed-version hook order'},
        {'url':url,'selected':str(OUT/'ODEJoint_11.10.2.cc'),'sha256':sha(data),'scope':'official GetParam vel/fmax maps to ODE motor parameters; GetForce scope limitations'}],
    'source_bindings':check['canonical_unchanged_bindings'],
    'utc':datetime.now(timezone.utc).isoformat()
}
with (OUT/'design_v1.json').open('x') as output:
    json.dump(design,output,indent=2)
    output.write('\n')
files=[]
for directory in sorted(OUT.parent.glob('mr3_p2a0_v18_driver_diagnostic_proposal_v*')):
    for path in sorted(directory.rglob('*')):
        if path.is_file() and path.name!='manifest_final_v1.json':
            data=path.read_bytes()
            files.append({'path':str(path),'bytes':len(data),'sha256':sha(data)})
manifest={'schema':'mr3-v18-diagnostic-proposal-custody-v1','files':files,'count':len(files),
          'bytes':sum(r['bytes'] for r in files),'candidate_patch':str(OUT/'review_only.patch'),
          'candidate_patch_sha256':sha((OUT/'review_only.patch').read_bytes()),
          'scope':'/tmp candidates and original CPU failures only; no canonical/native/formal changes. Writers stop after this manifest.'}
with (OUT/'manifest_final_v1.json').open('x') as output:
    json.dump(manifest,output,indent=2)
    output.write('\n')
print(json.dumps({'manifest':str(OUT/'manifest_final_v1.json'),
                  'manifest_sha256':sha((OUT/'manifest_final_v1.json').read_bytes()),
                  'design_sha256':sha((OUT/'design_v1.json').read_bytes()),
                  'count':manifest['count'],'bytes':manifest['bytes']},indent=2))
