#!/usr/bin/python3
"""Finite read-only coordinator/API/plan consistency review, no child or test execution."""
from pathlib import Path
import hashlib
import json
import time

D=Path(__file__).parent
RT=Path('/tmp/mr3_p2a0_v25_matrix_proposal_v1')
ROOT=Path('/home/zhuyulab/ns3-workspace')
W=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A=W/'report/assets/20261018_mr3_p2a0_v25_smoother'
OLD=W/'report/assets/20261018_mr3_p2a0_v24_install/predeclared_plan_v24.json'


def bound(path):
    def ident(s):return [s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
    s=path.stat();raw=path.read_bytes();assert ident(s)==ident(path.stat())
    return raw,{'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'stat':ident(s)}


def main():
    started=time.monotonic()
    paths=[Path(__file__),RT/'handoff_final_v1.json',RT/'predeclared_plan_v25.draft.json',
           A/'predeclared_plan_v25.json',A/'root_preparation/final_plan_receipt_v1.json',OLD,RT/'checks_v2/checks.json']
    captured=[bound(p) for p in paths]
    handoff,draft,final,receipt,old,checks=[json.loads(raw) for raw,row in captured[1:]]
    assert captured[1][1]['sha256']=='e48512228966c98ed2adf040135f672ac756a1630c4b3497d13a208ea5a7692e'
    assert captured[2][1]['sha256']==receipt['draft_sha256']=='198f6132bbe1fefdba8930f20f356cc71e1d6d2a4a6b431fb033473bf9d015f1'
    assert captured[3][1]['sha256']==receipt['final_sha256']=='27a5027c930e2d805187ea9e7d53fd16e797ab395c0931c4b76f707a1f6ae051'
    whitelist=['authorization','source_binding','scope_limits','new_execution_contracts','revision_reasons','readiness',
               'new_source_bindings_pending','authorized_current_binding_refresh_pending','v24_installation_revision',
               'v25_smoother_clock_revision','smoother_runtime_custody']
    changed=[k for k in draft.keys()|final.keys() if draft.get(k)!=final.get(k)]
    assert set(changed)==set(whitelist)==set(receipt['changed_top_keys'])
    assert final['stages']==draft['stages'] and final['independent_source_bindings']==draft['independent_source_bindings']
    ec_changed=[k for k in draft['new_execution_contracts'].keys()|final['new_execution_contracts'].keys()
                if draft['new_execution_contracts'].get(k)!=final['new_execution_contracts'].get(k)]
    assert ec_changed==['nav2_smoother_timer']
    unchanged=['unchanged_gates','physical_response_criteria','angular_interface_criteria','angular_reset_criteria',
               'settled_turn_criteria','full_execution_model_failfast','pilot_budget_unchanged','max_api_records',
               'max_submitted_script_decisions','max_total_wall_seconds','native_ray_box_correction']
    for key in unchanged:assert final[key]==old[key]
    assert [final[k] for k in ('max_api_records','max_submitted_script_decisions','max_total_wall_seconds')]==[608,596,18000]
    assert final['native_admission_granted'] is False and final['readiness']['status']=='ready'
    assert final['readiness']['pending_bindings']==[]
    before={r['path']:r['sha256'] for r in old['independent_source_bindings']}
    now={r['path']:r['sha256'] for r in final['independent_source_bindings']}
    assert len(before)==210 and len(now)==222 and before.keys()<=now.keys()
    delta={p:{'old':before[p],'new':now[p]} for p in before if before[p]!=now[p]}
    auditor=str((W/'mr3_learning/audit_ppo.py').relative_to(ROOT))
    assert delta=={auditor:{'old':'cc467064ab66e04507ed4d4e805a4e23cdf09b3716fd85517ebb34fe7b2de521',
                            'new':'7d1a1a70761115b2582d7c08315e42cce97ddacdae067e066fa1e5487853294d'}}
    newpaths=sorted(now.keys()-before.keys());assert len(newpaths)==12
    current=[]
    for p in newpaths+[auditor]:
        raw,binding=bound(ROOT/p);assert binding['sha256']==now[p];current.append((ROOT/p,binding))
    six=[]
    for row in handoff['files']:
        if not row['source'].endswith('.py'):continue
        raw,binding=bound(Path(row['source']));assert binding['sha256']==row['sha256']
        canonical,b2=bound(ROOT/row['path']);assert canonical==raw
        six.extend([(Path(row['source']),binding),(ROOT/row['path'],b2)])
    assert len(six)==12
    stage_rows=[]
    domains=[(208,13801),(210,13811),(212,13821),(216,13831)]
    for index,(a,b) in enumerate(zip(old['stages'],final['stages'])):
        assert a['stage']==b['stage'] and a['wall_ceiling_seconds']==b['wall_ceiling_seconds']
        command=list(b['command'])
        for flag in ('--base-domain','--base-port','--run-id'):
            assert command.count(flag)==a['command'].count(flag)==1
            command[command.index(flag)+1]=a['command'][a['command'].index(flag)+1]
        assert command==a['command']
        assert [x.replace('mr3_p2a0_v25_','mr3_p2a0_v24_') for x in b['required_audit_receipts']]==a['required_audit_receipts']
        argv=b['command'];workers=int(argv[argv.index('--workers')+1]);domain=int(argv[argv.index('--base-domain')+1]);port=int(argv[argv.index('--base-port')+1])
        assert (domain,port)==domains[index]
        expected=[{'worker_id':i,'robots':['tb1','tb2','tb3'],'domain':domain+i,'port':port+i} for i in range(workers)]
        assert b['worker_bindings']==expected
        stage_rows.append({'stage':b['stage'],'actual_command':argv,'worker_bindings':expected,
                           'wall_ceiling_seconds':b['wall_ceiling_seconds'],'mandatory_count':len(b['required_audit_receipts'])})
    assert [r['mandatory_count'] for r in stage_rows]==[10,7,10,7]
    cost=final['prior_engineering_cost']
    assert cost['wall_seconds']==569.733696886804+3.201879216823727==572.9355761036277
    assert cost['opening_remaining_wall_seconds']==18000-cost['wall_seconds']==17427.064423896372
    # Inspect actual coordinator text at the exact sealed sources, without invoking them.
    text={Path(row['source']).name:Path(row['source']).read_text() for row in handoff['files'] if row['source'].endswith('.py')}
    for name in ('mr3_p2a0_v25_buildproof_preflight.py','mr3_p2a0_v25_launch_stage.py','mr3_p2a0_v25_run_matrix_v1.py'):
        assert 'validate_worker_bindings' in text[name]
    watcher=text['mr3_p2a0_v25_cross_stage_mapping_monitor_v1.py']
    closure=text['mr3_v25_multiepoch_closure_binary_review_v1.py']
    assert 'module.observe(monitor, binding, FREEZE, read)' in watcher
    assert "'self_identity':identity(os.getpid())" in watcher
    assert 'smoother_module.review(a.run, prefix, a.freeze, smoother_binding, read)' in closure
    assert "check(smoother_review.get('passed') is True" in closure
    assert 'read(smoother_output)' in closure
    assert final['v24_installation_revision']['fixed_current_auditor_sha256']=='cc467064ab66e04507ed4d4e805a4e23cdf09b3716fd85517ebb34fe7b2de521'
    assert final['v25_smoother_clock_revision']['current_auditor_sha256']==now[auditor]
    result={'schema':'mr3-v25-matrix-source-plan-independent-review-v1','verdict':'no_identified_blocker_for_exact_promotion_and_fresh_preflight',
            'input_bindings':[row for raw,row in captured],'canonical_new_and_current_inputs':[row for path,row in current],
            'six_exact_promoted_source_bindings':[row for path,row in six],
            'final_plan_sha256':captured[3][1]['sha256'],'root_final_changed_keys':changed,
            'only_new_execution_contract_delta':ec_changed,'old_math_fields_exact':unchanged,
            'source_bindings':{'old':210,'same_old':209,'current_refresh':delta,'new_paths':newpaths,'total':222},
            'stages':stage_rows,'carried_wall_seconds':cost['wall_seconds'],'opening_remaining_wall_seconds':cost['opening_remaining_wall_seconds'],
            'source_API_review':[
                'Declared direct script CLIs make same-directory workerhelper import available. Parent additionally binds helperSHA; preflight and launcher already verify complete plan sourcebindings. Every stage metadata derives actual workers/base-domain/base-port argv.',
                'Shared fixed loader supplies real systemROS package/executable/ldd resolution at admission. New preflight adds source-bound load_binding/Reader.finish and preserves alloldsource/binary checks.',
                'Watcher uses original unchangedA13 monitor then separately checked smoother.observe with matching4args. First/duplicate/final bytes are bound before writing proof; sameworker closing classification is supplied by reviewedCIv3.',
                'Closed wrapper calls complete original closure+Shim+corrector checks, then requires smoother.review with correct5args; new failure appends to same errors, and output is bound/rechecked before finalverdict. Noold34job replaced or counted twice.',
                'Watcher START/SUMMARY actual ownPID/start facilitate closure union; no watcherprocess control or native/formal launch added. Old20scadence/monitor rules remain.',
                'Root11field finalization is readiness/source/status/description only; stages,222bindings,hardcriteria,budget unchanged. nav2_smoother_timer is the sole executioncontract description addition, not a changed physical gate.',
                'HistoricalV24cc467/f1e0 are explicitly historicalclosedFAIL; currentV25auditor7d1/ENV41fe are separate currentpins. Nolegacy PASS credited.'],
            'author_checks_scope':'Read existing RTstatic sixAST/mechanicalinverse/fatallint receipt1.36s only; reviewer did not repeat tests/preflight/consumer/ROS/build/native.',
            'remaining_admission':'Planready is conditional sourcepreparation only. Native_admission_granted remainsfalse; cleanpush exact40 source/ELF/preflight and passivewatcherSTART precede anynewnative.',
            'canonical_source_reads_STOP':True,'all_inputs_end_stable':True,'review_wall_seconds':time.monotonic()-started}
    assert captured==[bound(p) for p in paths]
    assert all(bound(p)[1]==row for p,row in current+six)
    out=D/'review_v1.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'review':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'verdict':result['verdict'],'final_plan_sha256':captured[3][1]['sha256']}))

if __name__=='__main__':main()
