#!/usr/bin/python3
"""One-pass postmortem only. Missing live admission is never repaired here."""
import argparse
import ctypes
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import time


CORE = Path("/home/zhuyulab/ns3-workspace/ns-allinone-3.40/ns-3.40/contrib/opengym/examples/"
            "wireless-rl/report/assets/20261018_mr3_p2a0_v18/independent/"
            "mr3_independent_stop_observer_v1.py")
CORE_SHA = "e61ce4e00907ab35e196f7abe9fadfd9da099af3542f98dc773d593c33ca2b65"
assert hashlib.sha256(CORE.read_bytes()).hexdigest() == CORE_SHA
SPEC = importlib.util.spec_from_file_location("frozen_capture_low_level", CORE)
C = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(C)
LIBM = ctypes.CDLL("libm.so.6")
for fn in (LIBM.cosf, LIBM.sinf):
    fn.argtypes = [ctypes.c_float]
    fn.restype = ctypes.c_float


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def ident(stat):
    return {name: getattr(stat, name) for name in
            ("st_dev", "st_ino", "st_size", "st_mtime_ns")}


def stream(path, evidence):
    """Exactly one full sequential read per large raw input, hashing as consumed."""
    digest = hashlib.sha256()
    count = size = 0
    with path.open("rb") as f:
        before = ident(os.fstat(f.fileno()))
        for raw in f:
            digest.update(raw)
            size += len(raw)
            count += 1
            if not raw.endswith(b"\n"):
                raise ValueError("incomplete raw line: " + str(path))
            yield count, raw, C.decode(raw)
        after = ident(os.fstat(f.fileno()))
    final = ident(path.stat())
    if before != after or after != final or size != before["st_size"]:
        raise ValueError("source changed: " + str(path))
    evidence[str(path)] = {"sha256": digest.hexdigest(), "bytes": size, "records": count,
                           "stat_before": before, "stat_after": after, "stat_final": final,
                           "full_sequential_passes": 1}


def small(path, evidence):
    raw = path.read_bytes()
    evidence[str(path)] = {"sha256": sha(raw), "bytes": len(raw)}
    return C.decode(raw)


class Residual:
    def __init__(self):
        self.n = 0
        self.maximum_abs = [0.0] * 3
        self.squares = [0.0] * 3
        self.sum = [0.0] * 3

    def add(self, value):
        C.vector(value, "derived_residual")
        self.n += 1
        for i, item in enumerate(value):
            self.maximum_abs[i] = max(self.maximum_abs[i], abs(item))
            self.squares[i] += item * item
            self.sum[i] += item

    def result(self):
        return {"samples": self.n, "maximum_abs_xyz": self.maximum_abs,
                "rms_xyz": [math.sqrt(v / self.n) if self.n else None for v in self.squares],
                "sum_xyz": self.sum}


def difference(a, b):
    return [x - y for x, y in zip(a, b)]


def add(a, b):
    return [x + y for x, y in zip(a, b)]


def yaw(quaternion):
    w, x, y, z = quaternion
    return math.atan2(2.0 * (w * z + x * y), 1.0 - 2.0 * (y * y + z * z))


def odom_index(path, epoch, start, end, evidence):
    result = {robot: {} for robot in C.ROBOTS}
    counts = {robot: 0 for robot in C.ROBOTS}
    for line, raw, row in stream(path, evidence):
        if row.get("kind") != "own_odom":
            continue
        if row.get("epoch") != epoch:
            raise ValueError("motion epoch mismatch")
        payload = row["payload"]
        robot = payload["robot"]
        msg = payload["message"]
        stamp = msg["header"]["stamp"]
        source = stamp["sec"] * 1000000000 + stamp["nanosec"]
        if start <= source <= end:
            counts[robot] += 1
            result[robot].setdefault(source, []).append({"line": line, "raw": raw,
                "input_sequence": payload["input_sequence"], "message": msg})
    return result, counts


class Diagnostic(C.CaptureReplay):
    def __init__(self, robot, epoch, start, end, native, odom, output, source):
        self.raw_pre = None
        self.raw_current = None
        self.line_current = None
        self.odom = odom
        self.output = output
        self.source = source
        self.keys = {}
        self.extra = {}
        self.post_integral = {}
        self.post_displacement = {}
        self.zero = None
        self.windows = []
        self.joined = 0
        self.unmatched_odom = set(odom)
        self.raw_header = None
        def expected(header):
            C.native_values(header["native_ode"], native)
            return {"canonical": header["canonical_name"], "base": header["base_name"],
                    "joints": [robot + "::wheel_right_joint", robot + "::wheel_left_joint"],
                    "native_values": native}
        super().__init__(robot, epoch, start, end, expected)

    def note(self, label, vector):
        self.extra.setdefault(label, Residual()).add(vector)

    def key(self, label, metric, row=None, raw=None, line=None):
        if label not in self.keys or metric > self.keys[label]["metric"]:
            row = self.current if row is None else row
            self.keys[label] = {"metric": metric, "source": str(self.source),
                "line": self.line_current if line is None else line,
                "record_sequence": row["record_sequence"], "sim_time_ns": row["sim_time_ns"],
                "raw": self.raw_current if raw is None else raw}

    def feed(self, line, raw, row):
        self.line_current, self.raw_current, self.current = line, raw, row
        if row["kind"] == "configuration":
            self.raw_header = raw
        if row.get("phase") == C.PRE:
            self.raw_pre = raw
            self.pre_line = line
        self.record(row)

    def finish_zero(self):
        if self.zero is not None:
            self.windows.append(self.zero)
            self.zero = None

    def observe(self, pre, post, pv, qv):
        super().observe(pre, post, pv, qv)
        t = post["sim_time_ns"]
        for phase, row, values in (("pre", pre, pv), ("post", post, qv)):
            canonical, base = row["canonical"], row["base"]
            p0 = canonical["world_pose"]["position_xyz"]
            p1 = base["world_pose"]["position_xyz"]
            omega = canonical["world_angular_velocity_xyz"]
            predicted = add(canonical["world_origin_linear_velocity_xyz"], C.cross(omega, difference(p1, p0)))
            fixed = difference(base["world_origin_linear_velocity_xyz"], predicted)
            self.note(phase + ".fixed_base_origin_velocity_minus_canonical_rigid_prediction", fixed)
            self.note(phase + ".fixed_base_angular_minus_canonical", difference(base["world_angular_velocity_xyz"], omega))
            self.note(phase + ".model_velocity_minus_canonical_origin", difference(values["model"][1], values["canonical_origin"][1]))
            self.note(phase + ".model_velocity_minus_canonical_cog", difference(values["model"][1], values["canonical_cog"][1]))
            self.key(phase + ".fixed_link_velocity_residual", math.hypot(*fixed), row,
                     self.raw_pre if phase == "pre" else self.raw_current,
                     self.pre_line if phase == "pre" else self.line_current)
        # WORLD odom is sampled at Begin before this T's solve, not at post.
        for original in self.odom.get(t, []):
            self.joined += 1
            self.unmatched_odom.discard(t)
            msg = original["message"]
            pose = msg["pose"]["pose"]
            p = [pose["position"][key] for key in ("x", "y", "z")]
            self.note("own_odom.position_minus_same_T_pre_model", difference(p, pv["model"][0]))
            velocity = msg["twist"]["twist"]
            measured = [velocity["linear"][key] for key in ("x", "y")]
            world = pv["model"][1]
            angle = yaw(pre["model"]["world_pose"]["quaternion_wxyz"])
            cs, sn = LIBM.cosf(ctypes.c_float(angle)), LIBM.sinf(ctypes.c_float(angle))
            predicted = [cs * world[0] + sn * world[1], cs * world[1] - sn * world[0]]
            residual = [measured[0] - predicted[0], measured[1] - predicted[1],
                velocity["angular"]["z"] - pre["model"]["world_angular_velocity_xyz"][2]]
            self.note("own_odom.xy_wz_minus_same_T_pre_float_yaw_projection", residual)
            metric = math.hypot(*residual)
            self.key("own_odom_pre_projection_residual", metric, pre, self.raw_pre, self.pre_line)
            if self.keys["own_odom_pre_projection_residual"]["metric"] == metric:
                self.keys["own_odom_pre_projection_residual"]["own_odom_raw"] = original["raw"]
                self.keys["own_odom_pre_projection_residual"]["own_odom_line"] = original["line"]
            self.note("own_odom_vs_same_T_pre_planar_norm_difference",
                      [math.hypot(*measured) - math.hypot(*world[:2]), 0.0, 0.0])
        if t == self.start:
            return
        dt = .001
        both_zero = all(joint["motor_velocity_target_radps"] == 0
                        for row in (pre, post) for joint in row["joints_right_left"])
        if both_zero and self.zero is None:
            self.zero = {"start_ns": t - C.TICK_NS, "end_ns": t, "intervals": 0,
                "maximum_model_planar_speed": 0.0, "maximum_cog_planar_speed": 0.0,
                "maximum_abs_feedback_joint_radps": 0.0, "model_planar_path_m": 0.0,
                "canonical_cog_planar_path_m": 0.0, "post_velocity_integral_xyz": {},
                "pose_displacement_xyz": {}, "post_velocity_integral_residual_xyz": {}}
        if not both_zero:
            self.finish_zero()
        if self.zero is not None:
            self.zero["end_ns"] = t
            self.zero["intervals"] += 1
            self.zero["maximum_abs_feedback_joint_radps"] = max(
                self.zero["maximum_abs_feedback_joint_radps"],
                *(abs(joint["velocity_radps"]) for row in (pre, post) for joint in row["joints_right_left"]))
        for name, value in qv.items():
            if name.endswith("residual"):
                continue
            delta = difference(value[0], pv[name][0])
            integral = [v * dt for v in value[1]]
            residual = difference(delta, integral)
            self.note(name + ".pre_post_pose_delta_minus_post_velocity_dt", residual)
            self.note(name + ".pre_post_pose_speed_minus_post_velocity", [r / dt for r in residual])
            self.post_integral[name] = add(self.post_integral.get(name, [0.0] * 3), integral)
            self.post_displacement[name] = add(self.post_displacement.get(name, [0.0] * 3), delta)
            if self.zero is not None:
                for key, datum in (("post_velocity_integral_xyz", integral), ("pose_displacement_xyz", delta),
                                   ("post_velocity_integral_residual_xyz", residual)):
                    self.zero[key][name] = add(self.zero[key].get(name, [0.0] * 3), datum)
                for prefix, entity in (("model", "model"), ("canonical_cog", "canonical_cog")):
                    if name == entity:
                        self.zero[prefix + "_planar_path_m"] += math.hypot(*delta[:2])
                if name in ("model", "canonical_cog"):
                    speed = max(math.hypot(*pv[name][1][:2]), math.hypot(*value[1][:2]))
                    field = "maximum_model_planar_speed" if name == "model" else "maximum_cog_planar_speed"
                    self.zero[field] = max(self.zero[field], speed)
                    self.key("zero_motor." + name + ".planar_speed", speed)
                    self.key("zero_motor." + name + ".post_velocity_pose_residual_speed", math.hypot(*residual) / dt)

    def result(self):
        self.finish_zero()
        result = self.finish()
        result["extra_residuals"] = {key: value.result() for key, value in self.extra.items()}
        result["post_velocity_integral_xyz"] = self.post_integral
        result["post_velocity_pose_integral_residual_xyz"] = {
            key: difference(self.post_displacement[key], value) for key, value in self.post_integral.items()}
        result["own_odom_same_T_pre_join"] = {"joined_rows": self.joined,
            "unmatched_source_ns": sorted(self.unmatched_odom),
            "scope": "Exact integer raw odom header stamps joined to Begin/pre-solve model, never post. Projection repeats original float yaw/cosf/sinf arithmetic for explanation only."}
        result["zero_motor_windows"] = {"count": len(self.windows),
            "intervals": sum(row["intervals"] for row in self.windows),
            "at_least_point1_sec": sum(row["intervals"] >= 100 for row in self.windows),
            "at_least_point78_sec": sum(row["intervals"] >= 780 for row in self.windows),
            "longest_ten": sorted(self.windows, key=lambda row: row["intervals"], reverse=True)[:10],
            "highest_model_speed_ten": sorted(self.windows, key=lambda row: row["maximum_model_planar_speed"], reverse=True)[:10],
            "scope": "Both pre/post motor velocity GetParam targets exactly0 throughout included1ms intervals. This is not a new stop verdict, not driver-private ACK and not proof of zero joint/world velocity."}
        selected = {}
        for label, item in self.keys.items():
            row = {key: value for key, value in item.items() if key not in ("raw", "own_odom_raw")}
            name = self.robot + "_" + label.replace(".", "_")
            target = self.output / (name + ".jsonl")
            target.write_bytes(item["raw"])
            row.update({"selected_raw_path": str(target), "selected_raw_sha256": sha(item["raw"])})
            if "own_odom_raw" in item:
                target = self.output / (name + "_own_odom.jsonl")
                target.write_bytes(item["own_odom_raw"])
                row.update({"own_odom_raw_path": str(target), "own_odom_raw_sha256": sha(item["own_odom_raw"])})
            selected[label] = row
        header_path = self.output / (self.robot + "_configuration.jsonl")
        header_path.write_bytes(self.raw_header)
        result["selected_original_raw_rows"] = selected
        result["configuration_original_raw"] = {"path": str(header_path), "sha256": sha(self.raw_header)}
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("episode", type=Path)
    parser.add_argument("--output-directory", required=True, type=Path)
    args = parser.parse_args()
    args.output_directory.mkdir(exist_ok=False)
    evidence = {}
    started = time.monotonic()
    metadata = small(args.episode / "metadata.json", evidence)
    binding = small(args.episode / "physics_diagnostic_binding.json", evidence)
    profile = list(stream(args.episode / "physics_profile.jsonl", evidence))[0][2]
    transitions = [row for _, _, row in stream(args.episode / "transitions.jsonl", evidence)]
    interval = C.transition_interval(transitions, metadata["epoch"])
    start, end = interval["start_ns"], interval["end_ns"]
    odom, counts = odom_index(args.episode / "motion_safety.jsonl", metadata["epoch"], start, end, evidence)
    results, errors = [], []
    for robot in C.ROBOTS:
        source = args.episode / ("physics_" + robot + ".jsonl")
        replay = Diagnostic(robot, metadata["epoch"], start, end, profile["after"]["native_ode"],
                            odom[robot], args.output_directory, source)
        try:
            for line, raw, row in stream(source, evidence):
                replay.feed(line, raw, row)
            results.append(replay.result())
        except Exception as error:
            errors.append({"robot": robot, "exception": type(error).__name__, "message": str(error),
                           "line": replay.line_current, "clock_ns": replay.current.get("sim_time_ns")})
        print(json.dumps({"robot": robot, "done": True, "errors": errors,
                          "wall_seconds": time.monotonic() - started}), flush=True)
    result = {"schema": "mr3-v18-closed-observer-postmortem-v1", "observation_only": True,
        "v18_result_unchanged": "FAIL", "live_admission_proof_available": False,
        "not_a_retroactive_formal_verdict": True, "diagnostic_processing_completed": len(results) == 3,
        "capture_validation_errors": errors, "episode_directory": str(args.episode),
        "metadata_freeze": metadata["freeze"], "epoch": metadata["epoch"], "actual_interval": interval,
        "original_transitions_records": len(transitions), "raw_own_odom_rows_in_task": counts,
        "profile_ledger": profile, "runtime_binding": binding, "robots": results, "inputs": evidence,
        "wall_seconds": time.monotonic() - started, "consumer_low_level_source": {"path": str(CORE), "sha256": CORE_SHA},
        "this_source_sha256": sha(Path(__file__).read_bytes()),
        "limitations": ["Actual observer data are reviewed without the required live admission proof; no V18 FAIL is replaced or repaired.",
            "Original2516 and strictclose results remain their original separate verdicts. No altered .01/three-sample/.78/.144 or task gate is used here.",
            "1ms body pose/velocity/current contact getters are explanatory sampled evidence, not a continuous solver theorem or per-robot causal force attribution.",
            "No physical dynamics parameter or proposed repair is inferred from correlation alone; missing retained contacts do not establish no support/contact force.",
            "All three observer files and the motion raw input are each read once sequentially and SHA-bound during that pass; file identity/mtime/size are checked before/after."]}
    destination = args.output_directory / "diagnostic.json"
    destination.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"diagnostic_processing_completed": result["diagnostic_processing_completed"],
                      "errors": errors, "output": str(destination), "sha256": sha(destination.read_bytes()),
                      "wall_seconds": result["wall_seconds"]}), flush=True)
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
