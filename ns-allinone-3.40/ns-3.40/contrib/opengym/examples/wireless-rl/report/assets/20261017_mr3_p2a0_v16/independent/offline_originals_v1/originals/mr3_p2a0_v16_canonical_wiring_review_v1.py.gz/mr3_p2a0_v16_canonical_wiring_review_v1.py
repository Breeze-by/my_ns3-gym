"""Read-only canonical promotion/source-gate review, without importing runtime or auditors."""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
ASSETS = W / 'report/assets'
OUTPUT = Path('/tmp/mr3_p2a0_v16_canonical_wiring_review_v1.json')
inputs = {}


def raw(path):
    payload = path.read_bytes()
    digest = hashlib.sha256(payload).hexdigest()
    key = str(path)
    if key in inputs and inputs[key] != digest:
        raise ValueError('input changed across reads: ' + key)
    inputs[key] = digest
    return payload


def digest(payload):
    return hashlib.sha256(payload).hexdigest()


def git_source(relative):
    return subprocess.check_output(['git', 'show', 'HEAD:' + relative], cwd=ROOT)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def ast_dump(source):
    return ast.dump(ast.parse(source), include_attributes=False)


started = time.monotonic()
result = {'schema': 'mr3-v16-independent-canonical-wiring-review-v1', 'passed': False,
          'scope': 'Source/AST/current-pin review only. No runtime import, no CPU suite rerun, '
                   'no ROS/native/formal audit, no task or learned-policy credit.',
          'source_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT,
                                                  text=True).strip()}
try:
    handoff = json.loads(raw(Path('/tmp/mr3_p2a0_v16_stimulus_v5_proposal/handoff_v2.json')))
    promoted = []
    for item in handoff['files']:
        path = ROOT / item['proposed_canonical_path']
        payload = raw(path)
        require(digest(payload) == item['sha256'], 'canonical promotion SHA mismatch: ' + str(path))
        promoted.append({'path': str(path.relative_to(ROOT)), 'sha256': digest(payload)})
    result['seven_promoted_sources'] = promoted

    wrappers = []
    for stem in ('mr3_independent_angular_reset_matrix', 'mr3_independent_physics_matrix'):
        base = ASSETS / '20261017_mr3_p2a0_v8/independent' / (stem + '_v8.py')
        new = ASSETS / '20261017_mr3_p2a0_v16/independent' / (stem + '_v16.py')
        old_text, new_text = raw(base).decode(), raw(new).decode()
        normalized = new_text.replace('v16', 'v8').replace('v5', 'v3')
        require(normalized == old_text, 'unexpected wrapper text delta: ' + stem)
        require(ast_dump(normalized) == ast_dump(old_text), 'wrapper normalized AST differs')
        require(raw(base) == git_source(base.relative_to(ROOT).as_posix()),
                'old A8 source differs from Git')
        wrappers.append({'new': str(new.relative_to(ROOT)), 'old': str(base.relative_to(ROOT)),
                         'only_inverse_labels': {'v16': 'v8', 'v5': 'v3'},
                         'normalized_text_equal': True, 'normalized_ast_equal': True})
    result['wrapper_equivalence'] = wrappers

    physics = ASSETS / '20261017_mr3_p2a0_v3/independent/mr3_independent_physics_review.py'
    angular = ASSETS / '20261017_mr3_p2a0_v4/independent/mr3_independent_angular_interface_v1.py'
    physical_bytes, angular_bytes = raw(physics), raw(angular)
    require(digest(physical_bytes) == '2516e394f60eac5dd24fd66b51c4c48fc37245090eb1626ebe1c7a3a23f8bafb',
            'immutable physical reader changed')
    require(digest(angular_bytes) == '7a472ba7efdd55addc710b98c66c89feff7f5092f214f76fd76cd4ca526343d0',
            'immutable angular reader changed')
    physical_tree = ast.parse(physical_bytes)
    complete_expr = [node.values[index] for node in ast.walk(physical_tree)
                     if isinstance(node, ast.Dict)
                     for index, key in enumerate(node.keys)
                     if isinstance(key, ast.Constant) and key.value == 'physical_evidence_complete'
                     and isinstance(node.values[index], ast.BoolOp)]
    require(any('bool(credited or cancel_credited)' in ast.unparse(value)
                for value in complete_expr), 'A-or-B criterion missing')
    angular_text = angular_bytes.decode()
    for value in ('covered = all(row["sign_spans"] for row in robots.values()) and not missing',
                  'if not positive:', 'if not negative:', 'if not bidirectional:',
                  'if {span["sign"] for span in row["sign_spans"]} == {-1, 1}'):
        require(value in angular_text, 'angular gate differs: ' + value)
    result['immutable_gate_semantics'] = {
        'physical': {'sha256': digest(physical_bytes),
                     'criterion': 'Per robot bool(credited_A or credited_B), with no errors, '
                                  'bounds violations or observed nonrest horizon violation. '
                                  'All robots required; A and B reported separately.'},
        'angular': {'sha256': digest(angular_bytes),
                    'criterion': 'Each robot at least one qualifying sign span; aggregate '
                                 'positive and negative; at least one same robot has both signs. '
                                 'Every robot reverse is not required.'}}
    for path in (physics, angular):
        require(raw(path) == git_source(path.relative_to(ROOT).as_posix()),
                'old immutable source differs from Git')
    changed_assets = subprocess.check_output(
        ['git', 'diff', '--name-only', 'HEAD', '--', str(ASSETS.relative_to(ROOT))],
        cwd=ROOT, text=True).splitlines()
    old_changes = []
    for value in changed_assets:
        parts = Path(value).parts
        versions = [re.fullmatch(r'20261017_mr3_p2a0_v(\d+)', part) for part in parts]
        if any(match and int(match.group(1)) < 16 for match in versions):
            old_changes.append(value)
    require(not old_changes, 'old assets modified: ' + repr(old_changes))
    result['older_assets_changed_vs_HEAD'] = old_changes

    ppo = W / 'mr3_learning/audit_ppo.py'
    current = raw(ppo)
    previous = git_source(ppo.relative_to(ROOT).as_posix())
    require(digest(current) == 'b34556bdf1e2bcb07907f7c8489ca2a268aabe460c816d2aa4d432253e648f67',
            'unexpected current PPO auditor bytes')
    def env_literal(source):
        return next(ast.literal_eval(node.value) for node in ast.parse(source).body
                    if isinstance(node, ast.Assign) and len(node.targets) == 1
                    and isinstance(node.targets[0], ast.Name)
                    and node.targets[0].id == 'ENV_DOCUMENT_SHA256')
    old_env, new_env = env_literal(previous), env_literal(current)
    require(new_env == '58633e6dc8c6722f4ed4428b1a1f8987b5aba8f62e16d61f53229bfb24d0525b',
            'new ENV literal differs')
    require(current.count(new_env.encode()) == 1 and previous.count(old_env.encode()) == 1,
            'ambiguous ENV replacement')
    inverse = current.replace(new_env.encode(), old_env.encode())
    require(inverse == previous and ast_dump(inverse) == ast_dump(previous),
            'PPO delta is not exactly one ENV digest literal')
    env = W / 'MR3_ENV_CONTRACT.md'
    require(digest(raw(env)) == new_env, 'current ENV bytes do not match pin')
    result['ppo_only_env_delta'] = {'before_sha256': digest(previous),
                                    'after_sha256': digest(current), 'old_ENV': old_env,
                                    'new_ENV': new_env, 'inverse_bytes_and_ast_equal': True}

    namespace = {}
    permitted = (ast.Constant, ast.Dict, ast.BinOp, ast.Add, ast.Name, ast.Load)
    for node in ast.parse(current).body:
        if (isinstance(node, ast.Assign) and len(node.targets) == 1
                and isinstance(node.targets[0], ast.Name)
                and all(isinstance(item, permitted) for item in ast.walk(node.value))):
            try:
                namespace[node.targets[0].id] = eval(
                    compile(ast.Expression(node.value), str(ppo), 'eval'),
                    {'__builtins__': {}}, namespace)
            except NameError:
                pass
    pin_names = ('EVALUATOR_PHASE_PINS', 'CURRENT_AUDITOR_PINS', 'PREPARATION_RUNTIME_PINS',
                 'SLAM_RUNTIME_PINS', 'EXECUTION_CONFIG_PINS')
    pin_proof = {}
    for name in pin_names:
        mapping = namespace[name]
        rows = []
        for relative, expected in mapping.items():
            actual = digest(raw(ROOT / relative))
            require(actual == expected, name + ' mismatch ' + relative)
            rows.append({'path': relative, 'expected': expected, 'actual': actual})
        pin_proof[name] = {'count': len(rows), 'passed': True, 'sources': rows}
    runtime36 = sum(pin_proof[name]['count'] for name in
                    ('CURRENT_AUDITOR_PINS', 'PREPARATION_RUNTIME_PINS', 'SLAM_RUNTIME_PINS'))
    require(runtime36 == 36, 'runtime36 pin set cardinality differs')
    result['current_pin_verification'] = {'runtime36_count': runtime36,
                                          'all_explicit_mapping_count': sum(
                                              item['count'] for item in pin_proof.values()),
                                          'groups': pin_proof}
    require(all(digest(Path(path).read_bytes()) == expected for path, expected in inputs.items()),
            'review input changed before verdict')
    result['passed'] = True
except Exception as error:
    result['error'] = type(error).__name__ + ': ' + str(error)
result['inputs_sha256'] = inputs
result['wall_seconds'] = time.monotonic() - started
result['tool_sha256'] = digest(Path(__file__).read_bytes())
with OUTPUT.open('x') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
print(json.dumps({'path': str(OUTPUT), 'passed': result['passed'],
                  'sha256': digest(OUTPUT.read_bytes()), 'error': result.get('error'),
                  'pin_count': result.get('current_pin_verification', {}).get(
                      'all_explicit_mapping_count')}, indent=2))
raise SystemExit(0 if result['passed'] else 1)
