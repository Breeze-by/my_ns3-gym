"""Select the pre-reviewed fixed150 engineering candidate, not a PASS claim."""
import hashlib
import json
from pathlib import Path

ROOT=Path('/home/zhuyulab/ns3-workspace')
PKG=ROOT/'ros2_ws/ros2-multi-robot-automap/src/multi_robot'
P=Path('/tmp/mr3_p2a0_v19_conditional_world_iters150_proposal_v1/attempt02')
EXPECTED={
 'open':('ed3fcd526d7367e8e0eb5245c365ba60631a6f4a6d725c64134221217ddc4846','e4a3c25374bb482a0104530f1765f17b807377e0a5c85bc42d6645a63bfc5487'),
 'rooms':('92ac7dff82bdf03b9f1ce3e9f075a3f59ca07df23c2f89fca654b3f423742768','c4ddca59d8b955f5410a0e639736263c750d6e819a864020c3e4e6da783a811e'),
 'corridors':('7e15f3ba716fd2f6cdc55310ab3064e61c8d0d34c4f8cba79a964260a8dac051','44cc8593cf69206a36b3a7bf82b2008957d5454caaa040dc4b3ac815e1b778a6')}
addition=b'      <ode>\n        <solver>\n          <type>quick</type>\n          <iters>150</iters>\n        </solver>\n      </ode>\n'
rows=[]
for scene,(world_sha,task_sha) in EXPECTED.items():
    old=(P/f'old/worlds/p1c_{scene}.world').read_bytes()
    new=(P/f'proposed/worlds/p1c_{scene}.world').read_bytes()
    destination=PKG/f'worlds/p1c_{scene}.world'
    assert destination.read_bytes()==old
    assert new.count(addition)==1 and new.replace(addition,b'',1)==old
    assert hashlib.sha256(new).hexdigest()==world_sha
    oldtask=(P/f'old/config/{scene}.json').read_bytes()
    newtask=(P/f'proposed/config/{scene}.json').read_bytes()
    task=PKG/f'config/mr3_p1a/{scene}.json'
    assert task.read_bytes()==oldtask
    oldworldsha=hashlib.sha256(old).hexdigest()
    assert newtask.count(world_sha.encode())==1 and newtask.replace(world_sha.encode(),oldworldsha.encode(),1)==oldtask
    assert json.loads(newtask)['world_sha256']==world_sha
    assert hashlib.sha256(newtask).hexdigest()==task_sha
    for path,raw,prior in ((destination,new,old),(task,newtask,oldtask)):
        path.write_bytes(raw); assert path.read_bytes()==raw
        installed=ROOT/'ros2_ws/ros2-multi-robot-automap/install/multi_robot/share/multi_robot'/path.relative_to(PKG)
        assert installed.read_bytes()==raw
        rows.append({'canonical':str(path.relative_to(ROOT)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),
            'prior_sha256':hashlib.sha256(prior).hexdigest(),'installed_same_bytes':True})
result={'schema':'mr3-v22-selected-world-configuration-v1','scope':'Fixed150 trial candidate for complete same-freeze P2A.0 matrix; no physics/task/95% acceptance, no runtime physics setter.',
 'files':rows,'world_inverse_whole_bytes':True,'task_only_world_sha_inverse_whole_bytes':True,
 'geometry_and_all_task_threshold_bytes_unchanged':True,'native_calls':0}
Path('/tmp/mr3_p2a0_v22_selected_world_configuration_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print('Selected six fixed world/task files; exact inverse and installed bytes verified; no native')
