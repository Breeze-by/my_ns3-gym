import os,json,hashlib,pathlib,subprocess,time,datetime
root=pathlib.Path("/home/zhuyulab/ns3-workspace");temp=pathlib.Path("/tmp")
helper=temp/"mr3_p2a0_v15_archive_closed_v1.py";sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(helper)=="17c4badcc7b251ff15262c5f35fcbe6317d08a82656d6dab7cdf55ae0cb6bd74"
argv=["/usr/bin/python3",str(helper),"--publish","--mode","stopped","--stop-stage","interface"]
console=temp/"mr3_p2a0_v15_closed_archive_publish_v1.log";receipt=temp/"mr3_p2a0_v15_closed_archive_publish_v1.json"
assert not console.exists() and not receipt.exists()
env=os.environ.copy();env.pop("PYTHONPATH",None);env.update(PYTHONNOUSERSITE="1",PYTHONDONTWRITEBYTECODE="1")
start=datetime.datetime.now(datetime.timezone.utc).isoformat();begin=time.monotonic()
with console.open("xb") as stream:result=subprocess.run(argv,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT,check=False)
record=dict(argv=argv,cwd=str(root),env={"PYTHONPATH":"unset","PYTHONNOUSERSITE":"1","PYTHONDONTWRITEBYTECODE":"1"},started_utc=start,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),returncode=result.returncode,wall_seconds=time.monotonic()-begin,console=str(console),console_sha256=sha(console),source_sha256=sha(helper))
with receipt.open("x") as stream:json.dump(record,stream,indent=2);stream.write("\n")
print(json.dumps(record,indent=2));print(console.read_text())
raise SystemExit(result.returncode)
