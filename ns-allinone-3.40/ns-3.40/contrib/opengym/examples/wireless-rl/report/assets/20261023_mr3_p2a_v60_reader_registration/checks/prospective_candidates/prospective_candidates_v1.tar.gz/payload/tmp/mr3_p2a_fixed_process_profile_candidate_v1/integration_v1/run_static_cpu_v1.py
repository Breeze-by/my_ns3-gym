"""One fixed profiler-fixture CPU run, source bound; no native roles imported."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A = Path(__file__).resolve().parent


def main():
    spec_path = A / 'static_cpu_spec_v1.json'
    spec = json.loads(spec_path.read_text())
    sources = sorted(set([*(W/'mr3_learning').glob('*.py'), *A.glob('*.py'), spec_path, A/'base_source_pins_v1.json', A.parent/'fixed_process_profile_v1.py', ROOT/'ros2_ws/ros2-multi-robot-automap/scripts/mr3_env_worker.py', ROOT/'ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/multi_robot_exploration/mr3_adapter.py']))
    freeze = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    if freeze != spec['repository_source_freeze']:
        raise ValueError('fixed repository source freeze differs')
    snapshots = A / 'static_cpu_source_snapshots_v1'
    snapshots.mkdir(exist_ok=False)
    rows = []
    for path in sources:
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        row = dict(path=str(path), bytes=len(raw), sha256=digest)
        if path.is_relative_to(ROOT):
            relative = str(path.relative_to(ROOT))
            if subprocess.check_output(['git', 'show', freeze+':'+relative], cwd=ROOT) != raw:
                raise ValueError('repository CPU source changed')
            row.update(kind='git_blob', freeze=freeze, relative_path=relative)
        else:
            target = snapshots / (digest+'_'+path.name)
            target.open('xb').write(raw)
            row.update(kind='snapshot', snapshot=str(target))
        rows.append(row)
    (A/'static_cpu_source_recovery_v1.json').open('x').write(
        json.dumps(dict(source_freeze=freeze, sources=rows), indent=2)+'\n')
    argv = [sys.executable, '-B', '-m', 'mr3_learning.reach_execution', '--scope', 'cpu',
            '--output', str(A/'static_cpu_v1')]
    for source in sources:
        argv.extend(['--source', str(source)])
    argv.extend(['--', *spec['actual_argv']])
    env = dict(os.environ, PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1')
    env.pop('PYTHONPATH', None)
    env.pop('PYTHONHOME', None)
    return subprocess.call(argv, cwd=W, env=env)


if __name__ == '__main__':
    raise SystemExit(main())
