"""Canonical-only fake-process fixture runner; no /tmp path substitution."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time
import unittest

ROOT = Path('/home/zhuyulab/ns3-workspace')
A14 = ROOT / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
              'report/assets/20261017_mr3_p2a0_v14')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    plan_path = A14 / 'predeclared_plan_v14.json'
    plan = json.loads(plan_path.read_bytes())
    paths = [ROOT / row['path'] for row in plan['independent_source_bindings']]
    paths += [plan_path, ROOT / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/'
                               'wireless-rl/MR3_ENV_CONTRACT.md'), ROOT /
              'ros2_ws/ros2-multi-robot-automap/src/multi_robot/config/mr3_fastdds_loopback_udp.xml']
    before = {str(path): sha(path) for path in paths}
    names = ['mr3_p2a0_v14_plan_launcher_tests_v1.py', 'mr3_p2a0_v14_audit_stage_tests_v1.py',
             'mr3_v14_nested_closure_read_tests_v1.py', 'mr3_v14_shim_path_adapter_tests_v1.py']
    suite = unittest.TestSuite()
    for index, name in enumerate(names):
        path = A14 / 'independent' / name
        spec = importlib.util.spec_from_file_location('canonical_v14_fixture_' + str(index), path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
    began = time.monotonic()
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    wall = time.monotonic() - began
    after = {str(path): sha(path) for path in paths}
    output = Path('/tmp/mr3_p2a0_v14_canonical_coord_checks_v1.json')
    report = {'schema': 'mr3-v14-canonical-coordinator-checks-v1',
              'passed': result.wasSuccessful() and before == after,
              'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
              'wall_sec': wall, 'source_before': before, 'source_after': after,
              'sources_stable': before == after,
              'scope': 'Canonical-only original14launcher+9scheduler+3nested+4path-adapter '
                       'fakeprocess fixtures. No draft path monkeypatch and no ROS/service/native '
                       'process, no repeat full ROS/conda suite. Thirty overlapping unit cases '
                       'are not independent native experiments.'}
    with output.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k: report[k] for k in ('passed', 'tests', 'failures', 'errors', 'wall_sec')}))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
