"""Record a read-only review and archive explicit offline runner fixtures."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT=Path('/home/zhuyulab/ns3-workspace')
A10=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v10'
CHECKS=Path('/tmp/mr3_p2a0_v10_audit_runner_fixtures_checks_v1.json')
checks=json.loads(CHECKS.read_text())
help_path=Path('/tmp/mr3_p2a0_v10_audit_cli_help_v1/receipt.json')
help_checks=json.loads(help_path.read_text())
review={
 'schema':'mr3-v10-independent-audit-stage-source-review-v1',
 'passed':checks['passed'] and help_checks['passed'],
 'source_freeze':'pending',
 'runner_sha256':checks['source_sha256'], 'reviewed_plan_sha256':checks['plan_sha256'],
 'fixture_cases':len(checks['cases']), 'real_cli_help_cases':len(help_checks['commands']),
 'findings':[{'id':'drive_binary_proof_required','initial_runner_sha256':'26acec7b048a5da0f7c1382b81428a6230eae88ea6a06839b1b5e4fa4984c47f','status':'fixed_before_fixture_execution','evidence':'V5 argparse requires --binary-proof; original runner omitted it. Root added fixed /tmp/mr3_p2a0_v10_binaryproof.json, then real runner main fixtures verified this exact argument.'}],
 'verified_scopes':[
  'Interface and reset immutable input CLI uses --episode/--output only; immutable angular/physical CLIs get no unsupported --freeze; newer aggregate wrappers get --freeze.',
  'Every planned mandatory receipt output name matches runner actual output; terminal/deadline do not gain movement/braking/input coverage credit.',
  'Reset raw per-episode physics rc1/passedFalse remains visible and nonmandatory alone; required pooled physics wrapper receives the exact original report and a pooled FAIL makes overall FAIL.',
  'Reset eight original input leaves are retained, one bad leaf makes aggregate and overall FAIL; no interface pooling.',
  'Nonzero consumer exit, passed integer1, missing output and wrong mandatory freeze cannot become PASS; Git source/hash rejection happens before subprocess dispatch.',
  'FIFO episodeNNN output labels match closure reader lookup; FIFO is a telemetry observer and does not replace actual three-storage/unique bootstrap/stop authorization from mandatory drive/control readers.',
  'Current FIFO task target-age/rejection statistics are release<=sim_time_ns<=final; full tail remains available to fixed drive complete identity/math verification.'
 ],
 'limits':[
  'Plan snapshot still contained old33 independent bindings and pending final pins at read time; root is finalizing it. This review does not claim a frozen or clean native matrix.',
  'Fixtures execute unchanged runner main, while Git outputs and consumer subprocess.run are deliberate test doubles. Synthetic paths and source hashes are confined to /tmp; no native consumer audit result is implied.',
  'CLI help invokes actual Python argparse only; no simulation, ROS runtime, training, stage acceptance, 95% or learned-policy credit.'
 ],
 'checks':str(CHECKS),'cli_help_receipt':str(help_path),
 'native_starts':0,
}
out=Path('/tmp/mr3_p2a0_v10_audit_runner_review_v1.json')
with out.open('x')as f:f.write(json.dumps(review,indent=2)+'\n')
files=[Path(__file__),out,CHECKS,Path('/tmp/mr3_p2a0_v10_audit_runner_fixtures_checks_v1.log'),Path('/tmp/mr3_p2a0_v10_audit_runner_review_fixtures_v1.py')]
for directory in (Path(checks['fixture_root']),Path('/tmp/mr3_p2a0_v10_audit_runner_review_sources_v1'),help_path.parent):
 files.extend(p for p in directory.rglob('*') if p.is_file())
archive=A10/'independent/runner_offline';archive.mkdir(exist_ok=False)
entries=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
for src in sorted(set(files)):
 raw=src.read_bytes();rel=src.relative_to('/tmp');dst=archive/(str(rel)+'.gz');dst.parent.mkdir(parents=True,exist_ok=True)
 encoded=gzip.compress(raw,mtime=0)
 with dst.open('xb')as f:f.write(encoded)
 decoded=gzip.decompress(dst.read_bytes());assert decoded==raw
 entries.append({'source':str(src),'selected_path':str(dst.relative_to(ROOT)),'raw_sha256':sha(raw),'selected_encoded_sha256':sha(encoded),'selected_decoded_sha256':sha(decoded),'raw_bytes':len(raw),'selected_bytes':len(encoded),'decoded_equals_raw':True})
manifest={'schema':'mr3-v10-stage-runner-offline-originals-v1','passed':all(e['decoded_equals_raw']for e in entries),'count':len(entries),'source_freeze':'pending','native_starts':0,'scope':'Actual runner main and real argparse-help checks; all Git/source binding, subprocess outputs and consumer result fixtures are explicit mocks/synthetic and confer no native/stage/task credit. Old plan snapshot with pending pins retained unchanged.','runner_sha256':checks['source_sha256'],'reviewed_plan_sha256':checks['plan_sha256'],'entries':entries}
p=archive/'manifest.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'review':str(out),'review_sha256':sha(out.read_bytes()),'manifest':str(p),'manifest_sha256':sha(p.read_bytes()),'entries':len(entries)}))
