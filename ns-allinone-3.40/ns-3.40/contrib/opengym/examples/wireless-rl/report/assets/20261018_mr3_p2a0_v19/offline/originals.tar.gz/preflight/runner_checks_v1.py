"""CPU subprocess counterexamples for consumer exception and FAIL preservation."""
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import time
import unittest

path = Path(__file__).resolve().parent / 'runner_v19_draft_snapshot.py'
spec = importlib.util.spec_from_file_location('runner', path)
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)


class ConsumerExecution(unittest.TestCase):
    def invoke(self, directory, body):
        out = Path(directory) / 'result.json'
        job = {'label': 'cpu_counterexample', 'output': str(out), 'required_capture_success': True}
        return r.run_consumer(job, ['/usr/bin/python3', '-B', '-c', body, str(out)],
                              dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), Path(directory) / 'console.log')

    def test_actual_pass_receipt(self):
        with tempfile.TemporaryDirectory() as directory:
            record, value = self.invoke(directory, 'import pathlib,sys;pathlib.Path(sys.argv[1]).write_text(\'{"passed":true}\\n\')')
            self.assertTrue(record['passed'])
            self.assertEqual(record['errors'], [])
            self.assertIs(value['passed'], True)

    def test_actual_fail_is_preserved_without_infrastructure_error(self):
        with tempfile.TemporaryDirectory() as directory:
            record, value = self.invoke(directory, 'import pathlib,sys;pathlib.Path(sys.argv[1]).write_text(\'{"passed":false}\\n\');sys.exit(1)')
            self.assertFalse(record['passed'])
            self.assertEqual(record['errors'], [])
            self.assertIs(value['passed'], False)
            self.assertEqual(record['returncode'], 1)

    def test_bad_json_keeps_actual_nonzero_exit_and_original_hash(self):
        with tempfile.TemporaryDirectory() as directory:
            record, value = self.invoke(directory, 'import pathlib,sys;pathlib.Path(sys.argv[1]).write_text("{bad\\n");sys.exit(3)')
            self.assertFalse(record['passed'])
            self.assertEqual(record['returncode'], 3)
            self.assertTrue(record['errors'])
            self.assertEqual(record['output']['sha256'], r.sha(b'{bad\n'))

    def test_actual_spawn_error_still_yields_failed_receipt(self):
        with tempfile.TemporaryDirectory() as directory:
            record, value = r.run_consumer({'label': 'missing', 'output': str(Path(directory) / 'missing.json'),
                'required_capture_success': True}, ['/tmp/no-such-predeclared-cpu-consumer'],
                os.environ, Path(directory) / 'console.log')
            self.assertFalse(record['passed'])
            self.assertIsNone(record['returncode'])
            self.assertEqual(len(record['errors']), 2)


if __name__ == '__main__':
    started = time.monotonic()
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ConsumerExecution))
    output = Path(__file__).resolve().parent / 'runner_checks_v1.json'
    with output.open('x') as stream:
        stream.write(json.dumps({'passed': result.wasSuccessful(), 'tests': result.testsRun,
            'failures': len(result.failures), 'errors': len(result.errors), 'wall_seconds': time.monotonic() - started,
            'source_sha256': r.sha(path.read_bytes()), 'test_sha256': r.sha(Path(__file__).read_bytes()),
            'scope': 'CPU subprocess/receipt counterexamples; no native simulator or training'}, indent=2) + '\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
