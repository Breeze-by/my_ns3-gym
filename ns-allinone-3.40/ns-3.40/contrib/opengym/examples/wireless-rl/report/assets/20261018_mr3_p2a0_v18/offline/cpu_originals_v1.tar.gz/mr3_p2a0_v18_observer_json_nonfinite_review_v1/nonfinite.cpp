#include <nlohmann/json.hpp>
#include <limits>
#include <iostream>
int main(){nlohmann::json row{{"available",true},{"cpp_type","double"},{"value",std::numeric_limits<double>::quiet_NaN()}};std::cout<<row.dump()<<"\n";}
