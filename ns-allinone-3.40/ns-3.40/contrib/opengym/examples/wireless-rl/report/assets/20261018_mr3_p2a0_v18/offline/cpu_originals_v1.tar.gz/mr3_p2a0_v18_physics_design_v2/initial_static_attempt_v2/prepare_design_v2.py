#!/usr/bin/env python3
"""Static, prospective wiring proposal. Does not start or configure a simulator."""
import ast
import copy
import gzip
import hashlib
import json
import os
from pathlib import Path
import tempfile
from unittest.mock import patch
from xml.etree import ElementTree as ET
from xml.sax.saxutils import escape

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
ROS = ROOT / 'ros2_ws/ros2-multi-robot-automap'
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
OLD = Path('/tmp/mr3_p2a0_v18_physics_design_v1')
KEY = 'MR3_PHYSICS_DIAGNOSTIC_CONFIG_FILE'
LAUNCH = ROS / 'src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py'
MODEL = ROS / 'src/multi_robot/models/turtlebot3_waffle/model.sdf'
SUPERVISOR = W / 'mr3_learning/supervisor.py'
WORKER = ROS / 'scripts/mr3_env_worker.py'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write_json(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def stat_hash(path):
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns)
    if identity(before) != identity(after):
        raise ValueError('source changed while read')
    return {'path': str(path), 'sha256': sha(raw), 'bytes': len(raw),
            'stat': list(identity(after))}


def extract(path, name, namespace):
    tree = ast.parse(path.read_bytes())
    function = next(item for item in tree.body
                    if isinstance(item, ast.FunctionDef) and item.name == name)
    exec(compile(ast.Module(body=[function], type_ignores=[]), str(path), 'exec'), namespace)
    return namespace[name]


def append_observer(raw, robot, epoch, output):
    """Proposal-only in-memory hook before the existing exclusive SDF write."""
    root = ET.fromstring(raw)
    model = root.find('model')
    if root.tag != 'sdf' or model is None or len(root.findall('model')) != 1:
        raise ValueError('one top-level model required')
    if raw.count(b'</model>') != 1:
        raise ValueError('one unambiguous model closing tag required')
    name = 'mr3_stop_response_observer_' + robot
    if model.find("plugin[@name='" + name + "']") is not None:
        raise ValueError('observer already present')
    for required in ('base_link',):
        if model.find("link[@name='" + required + "']") is None:
            raise ValueError('explicit diagnostic base_link missing')
    block = ("  <plugin name='" + name + "' filename='libmr3_stop_response_observer.so'>\n"
             '    <epoch>' + escape(epoch) + '</epoch>\n'
             '    <robot>' + robot + '</robot>\n'
             '    <output_path>' + escape(str(output)) + '</output_path>\n'
             '    <base_link>base_link</base_link>\n'
             '    <right_joint>wheel_right_joint</right_joint>\n'
             '    <left_joint>wheel_left_joint</left_joint>\n'
             # Tiny synthetic window is only an XML fixture, not a native declaration.
             '    <start_ns>0</start_ns><end_ns>5000000</end_ns>\n'
             '  </plugin>\n').encode()
    result = raw.replace(b'</model>', block + b'</model>', 1)
    if result.replace(block, b'', 1) != raw:
        raise ValueError('original model bytes changed')
    parsed = ET.fromstring(result)
    node = parsed.find("model/plugin[@name='" + name + "']")
    parsed.find('model').remove(node)
    if ET.tostring(parsed) != ET.tostring(root):
        raise ValueError('model content changed outside observer')
    return result, block


def main():
    old_manifest = OLD / 'manifest_v1.json'
    old_receipt = json.loads(old_manifest.read_bytes())
    old_sources = [Path(item['path']) for item in old_receipt['files']] + [old_manifest]
    inputs = [LAUNCH, MODEL, SUPERVISOR, WORKER,
              ROS / 'src/multi_robot/src/mr3_gazebo_step_plugin.cpp',
              ROS / 'src/multi_robot/worlds/p1c_open.world',
              Path('/usr/include/gazebo-11/gazebo/common/Plugin.hh'),
              Path('/usr/include/gazebo-11/gazebo/physics/ode/ODEPhysics.hh'),
              Path('/usr/include/gazebo-11/gazebo/ode/objects.h')]
    before = [stat_hash(p) for p in inputs + old_sources]
    for item in old_receipt['files']:
        if sha(Path(item['path']).read_bytes()) != item['sha256']:
            raise ValueError('old v1 bytes no longer match manifest')
    design = json.loads((OLD / 'prospective_diagnostic_design_v1.json').read_bytes())
    design['schema'] = 'mr3-v18-prospective-physics-diagnostic-design-v2'
    design['supersedes_only'] = {
        'path': str(OLD / 'prospective_diagnostic_design_v1.json'),
        'sha256': 'aaffbe25b9b18eafc648b24089986f85ff1a77785927a85bade17fe2600b554c',
        'correction': 'A native reset is one API call. Each run has 1 reset+32 step=33 API calls; two runs have66, not64 API calls. Preserve old v1 unchanged.'}
    design['readiness'] = 'root_specific_predeclaration_review_clean_pushed_freeze_then_GO_required'
    design['authorization_scope'] = (
        'The user already authorized completing P2A.0. Root may decide a necessary bounded '
        'engineering diagnosis within that work. This artifact does not grant native admission: '
        'root must concretely predeclare and review the inputs, conditional branch and budgets, '
        'then clean/commit/push the exact sources and give GO. No new user question is required '
        'by this proposal; elapsed time or no reply is never treated as authorization.')
    baseline = design['minimum_recommended_first_run']
    baseline.update(reset_API_calls=1, step_API_calls=32, total_API_calls=33,
                    returned_records_including_reset=33)
    baseline.pop('policy_API_steps')
    contrast = design.pop('optional_separately_authorized_contrast')
    contrast.pop('API_steps')
    contrast.update(reset_API_calls=1, step_API_calls=32, total_API_calls=33,
                    returned_records_including_reset=33)
    contrast['admission'] = (
        'Optional conditional branch must be declared and reviewed before baseline starts. '
        'It may execute at most once only after a complete baseline capture reproduces the '
        'predeclared nonrest observation and root confirms the declared branch. No reproduction '
        'or missing/invalid capture means skip, never retry or search for a favorable case. '
        'If not declared initially, a new concrete review/freeze/GO is needed before any contrast.')
    design['optional_root_predeclared_contrast'] = contrast
    totals = design.pop('maximum_if_both_authorized')
    totals.pop('policy_API_steps')
    totals.update(reset_API_calls=2, step_API_calls=64, total_API_calls=66)
    design['maximum_if_both_predeclared_and_admitted'] = totals
    design['source_note'] = (
        'V17 remains historical evidence. New passive logger and diagnostic-only launch/profile '
        'selection require a reviewed clean pushed source freeze. All proposed readiness/admission '
        'is false here. No simulation, ROS participant or physics setter has run.')
    design['wiring_proposal'] = 'diagnostic_wiring_v2.json'
    write_json(HERE / 'prospective_diagnostic_design_v2.json', design)

    wiring = {
        'schema': 'mr3-v18-diagnostic-wiring-proposal-v2',
        'native_admission_granted': False,
        'scope': 'Proposal and CPU XML/AST tests only, not production implementation or loaded-library proof.',
        'minimum_recommended_change': {
            'only_production_python_file_if_approved': str(LAUNCH),
            'selection': KEY + ' unset means the existing launch/model/argv behavior is byte-for-byte unchanged.',
            'parent_invocation': 'Use env KEY=reviewed_input_config once for the one benchmark process; never persistent shell export. Existing V6/32 benchmark is unchanged.',
            'environment_path': 'Supervisor ros_environment copies os.environ except a named conda/path removal list. This exact key is preserved; worker and ros2 launch inherit it. No benchmark/Supervisor/worker option is needed.',
            'fail_closed_selection': [
                'Strict schema/unknown-key/type/finite/absolute-path checks and reviewed config/source/library SHA.',
                'Only execution_mode adapter, stepped true, robot_count3, nonempty actual epoch and real audit directory.',
                'Exact allowed diagnostic run root AND episode-relative path/world/seed; reject other training/evaluation runs if key accidentally persists.',
                'Never derive arbitrary library path or execute a command from unchecked JSON. Review and freeze an exact source/library allowlist.',
                'Read the config once as bound bytes with stat/hash consistency. Preserve it as evidence; fail if inputs change.',
                'Generate exclusive per-episode binding from actual launch epoch/audit parent plus original template SHA. Supervisor epochs include a random UUID suffix, so do not fabricate one in the parent template.',
                'All evidence/SDF/output files are exclusive creates; duplicate selection or existing output fails. No silent fallback to an uninstrumented run.'
            ],
            'bounded_output': 'Root must predeclare exact capture start/end and prove task release/final physics lie within coverage. Synthetic XML fixtures here use only a5ms toy window; this is not an actual run setting.'
        },
        'model_plugin': {
            'type': 'ModelPlugin, registered with GZ_REGISTER_MODEL_PLUGIN',
            'hook': 'In drive_spawn_model, after existing3 drive-tag substitutions and before its exclusive write, append exactly one observer plugin before the unique top-level </model>. Do not reserialize XML.',
            'spawn': 'Keep actual spawn_entity -file pointing to the sole archived drive_model_tbN.sdf, including observer. No later rewrite or alternate hidden spawn file.',
            'identity': 'Explicit base_link=base_link, same right/left joint names as original drive; unique per-robot output and actual epoch. Observer filename/source/actual mappedSO/config SHA retained.',
            'unchanged_proof': 'Removing exactly the known inserted byte block must restore the effective original driver SDF bytes; all links/collisions/inertial/drive parameters and remaining XML must match.',
            'does_not_add': 'No ROS/Gazebo publication, no actor/guard/map/candidate input, no Set operation. Passive IO still has wall/load cost; report it.'
        },
        'physics_properties_services': {
            'installed_messages': 'GetPhysicsProperties.srv and SetPhysicsProperties.srv exist in gazebo_msgs3.9.0.',
            'actual_implementation': 'Official gazebo_ros_pkgs3.9.0 gazebo_ros_properties.cpp includes both headers but creates neither service and implements neither physics callback. Installed libgazebo_ros_properties.so has no such callback symbol; current MR3 worlds load gazebo_ros_state only.',
            'conclusion': 'Do not call an assumed ROS1 service or infer availability from .srv files. Adding general Get/Set ROS services is unnecessary surface and would set an entire struct; prefer one exact diagnostic key below.'
        },
        'physics_profile_system_plugin': {
            'type': 'Separate explicitly named SystemPlugin with GZ_REGISTER_SYSTEM_PLUGIN. -s cannot load WorldPlugin or ModelPlugin directly.',
            'injection': 'Add -s <reviewed absolute profileSystemPluginSO> as separate argv tokens before --ros-args/--, beside the existing unchanged step SystemPlugin. Bind its per-episode config through gzserver additional_env only.',
            'baseline': 'observe_only: no SetParam or World setter; record reads and unchanged invariants.',
            'contrast': 'iters150: one SetParam("iters", boost::any(int(150))) only. This is a declared world configuration intervention, never labeled a read-only observer.',
            'startup_order': 'WorldCreated occurs at World::Load end after engine Load, but before World::Init PresetManager may reapply original physics. Register a one-shot first WorldUpdateBegin callback from WorldCreated; act only after initialization and before first ODE UpdatePhysics, requiring world identity, iteration1 and sim_ns1000000. Reject missed first boundary; do not set late or retry.',
            'one_shot': 'On first exact boundary, read before, validate full expected baseline, optionally set only iters once, read after, compare every unchanged field, append exclusive ledger, disconnect mutation callback. No stepping, pause toggling, pose/velocity setter or runtime retuning.',
            'double_read': 'GetParam("iters") returns engine SDF. Additionally dynamic_pointer_cast<ODEPhysics> and public GetWorldId(), then dWorldGetQuickStepNumIterations() for actual ODE value, before and after. Do not call two SDF getters independent native reads.',
            'unchanged_readback': 'Record engine GetParam/full SDF plus actual ODE native getters where available: iterations, W, CFM, ERP, contact max correction/surface layer; max step/target real-time/update rate/gravity/model surface identities and all reviewed invariants. Missing/unsupported required getter is missing evidence, not0.',
            'second_checkpoint': 'Actual per-robot observer Load readback after robot spawn must agree with applied profile; optional passive task-start/end readbacks must show no later config drift. Original world on-disk SHA remains exact; engine runtime SDF changes iters by declaration.',
            'world_plugin_alternative': 'An appended WorldPlugin in an effective world copy would load after PresetManager and before physics but changes full world bytes/SHA; a SystemPlugin could explicitly call public World::LoadPlugin with a WorldPlugin too, but adds a second layer. Neither is as small as the one-shot SystemPlugin. Such diagnostic-only copies cannot borrow old task whole-world SHA acceptance.',
            'forbidden_shortcuts': 'No -s WorldPlugin; no --iters=150 (that CLI controls simulation iteration count, not ODE quick-step solver iterations); no copying150/SOR1.4/20ms old world block; no mutation of original world/actor geometry.'
        },
        'actual_run_proofs_required': [
            'Clean pushed exact source/binary/config/plan and actual argv/env marker selection.',
            'Original world hash, all3 actual spawn-file SDFs, raw block equality and loaded observer/profile library proc-maps custody.',
            'Before/after nativeODE+engine parameter ledger and subsequent3 observer configuration checkpoints.',
            'Original control/driver/physics/sensor/rest ledgers and complete new1ms capture with strict closure; record any missingness without upgrading credit.'
        ],
        'source_caveat': 'Official11.10.2 source and installed headers establish design/API expectations only. No live service discovery, native load, setter call, parser world load, or production patch was performed.'
    }
    write_json(HERE / 'diagnostic_wiring_v2.json', wiring)

    checks = []
    env_function = extract(SUPERVISOR, 'ros_environment', {'os': os})
    with patch.dict(os.environ, {KEY: '/tmp/synthetic-diagnostic-input.json',
                                 'CONDA_PREFIX': '/tmp/never-used', 'PYTHONPATH': '/tmp/never-used'}, clear=True):
        env = env_function(200, 12801)
    assert env[KEY] == '/tmp/synthetic-diagnostic-input.json'
    assert 'CONDA_PREFIX' not in env and 'PYTHONPATH' not in env
    checks.append({'name': 'actual_AST_extracted_ros_environment_preserves_exact_key', 'passed': True})
    spawn = extract(LAUNCH, 'drive_spawn_model', {'os': os, 'tempfile': tempfile, 'escape': escape})
    base = HERE / 'synthetic_xml_base'
    proposed = HERE / 'synthetic_xml_proposed'
    base.mkdir()
    proposed.mkdir()
    examples = []
    for robot in ('tb1', 'tb2', 'tb3'):
        original = Path(spawn(str(MODEL), robot, str(base / 'adapter.jsonl'),
                              'synthetic_diag_epoch_not_native', True))
        raw = original.read_bytes()
        target = proposed / ('drive_model_' + robot + '.sdf')
        modified, block = append_observer(raw, robot, 'synthetic_diag_epoch_not_native',
                                          proposed / ('physics_' + robot + '.jsonl'))
        with target.open('xb') as stream:
            stream.write(modified)
        assert modified.replace(block, b'', 1) == raw
        try:
            append_observer(modified, robot, 'synthetic', target)
        except ValueError:
            pass
        else:
            raise AssertionError('duplicate observer accepted')
        examples.append({'robot': robot, 'base': stat_hash(original), 'proposed': stat_hash(target),
                         'inserted_block_sha256': sha(block), 'bytes_restored_exact': True,
                         'scope': 'CPU synthetic SDF only. No spawn or Gazebo parse/load.'})
    checks.append({'name': 'actual_drive_spawn_model_then_append_only_3SDF_byte_and_XML_equality', 'passed': True})
    checks.append({'name': 'duplicate_observer_rejected', 'passed': True})
    assert totals['total_API_calls'] == totals['reset_API_calls'] + totals['step_API_calls'] == 66
    assert baseline['total_API_calls'] == contrast['total_API_calls'] == 33
    checks.append({'name': 'reset_inclusive_API_accounting_33_each_66_pair', 'passed': True})

    official = HERE / 'sourceproof'
    props = (official / 'gazebo_ros_properties.cpp').read_text()
    assert '#include <gazebo_msgs/srv/get_physics_properties.hpp>' in props
    assert 'create_service<gazebo_msgs::srv::GetPhysicsProperties>' not in props
    assert 'create_service<gazebo_msgs::srv::SetPhysicsProperties>' not in props
    world = (official / 'World.cc').read_text()
    assert world.index('event::Events::worldCreated(this->Name());') < world.index('void World::Init()')
    update = world[world.index('void World::Update()'):]
    assert update.index('event::Events::worldUpdateBegin(') < update.index('physicsEngine->UpdatePhysics()')
    assert 'new PresetManager(this->dataPtr->physicsEngine' in world
    native_header = Path('/usr/include/gazebo-11/gazebo/physics/ode/ODEPhysics.hh').read_text()
    assert 'public: dWorldID GetWorldId();' in native_header
    native_functions = Path('/usr/include/gazebo-11/gazebo/ode/objects.h').read_text()
    assert 'dWorldGetQuickStepNumIterations (dWorldID)' in native_functions
    checks.append({'name': 'official_service_absence_and_startup/native_getter_source_anchors', 'passed': True,
                   'scope': 'static source/header checks; no participant, library load or setter'})
    after = [stat_hash(p) for p in inputs + old_sources]
    assert before == after
    checks.append({'name': 'canonical_sources_and_all_v1_files_stat_sha_before_after_stable', 'passed': True})
    write_json(HERE / 'static_checks_v2.json', {'schema': 'mr3-v18-design-static-checks-v2',
               'passed': True, 'native_executed': False, 'checks': checks, 'sources': before,
               'synthetic_xml': examples,
               'limitations': 'Pure AST function/XML construction and source consistency. Not native behavior, timing, sensor delivery, physics sensitivity, or accepted P2A.0 evidence.'})
    print(json.dumps({'passed': True, 'checks': len(checks), 'source_bindings': len(before),
                      'reset_API_per_run': 1, 'step_API_per_run': 32, 'total_API_per_run': 33,
                      'maximum_total_API': 66, 'native_executed': False}, sort_keys=True))


if __name__ == '__main__':
    main()
