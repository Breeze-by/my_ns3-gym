Outward-cancel-v2 shadow: uninstalled review candidate

Exact E basis:935b466bd076002afdfe161b55a508938de2a8b0. Every original target byte
still equals that Git commit; no repository file was edited. E_baseline_manifest_v1
and shadow_manifest_v1.json provide the exact per-file E and shadow SHA256 values.

The authoritative implementation is shadow/, six modified files:

- mr3_learning/benchmark.py: separate fixed v2 selector, real step-submission
  recorder and32-step finalizer. Existing v1/v4/v6 selector ASTs are unchanged.
- mr3_learning/supervisor.py: explicit v2 identity validation and v2-only reset
  request declaration. Legacy and old v1 request/metadata shapes stay unchanged.
- scripts/mr3_env_worker.py: reject unknown/mixed v2 requests and record the v2
  identity in actual worker metadata. Only initialization/metadata are touched.
- mr3_learning/audit_reach_reset_workload.py: fixed v1/v2 producer/reader pairs,
  unique immutable version inverse, actual episode metadata check and readiness.
- mr3_learning/audit_reach_preparation.py: plan-selected full-reader version
  projection, matching actual v2 episode declarations for motion-probe roles.
  Terminal/deadline/normal PPO episodes do not gain scripted-probe requirements.
- mr3_learning/reach_preparation.py: explicit profile selection in builder,
  complete plan validation, interface/reset argv and both reset audit commands.

The selector uses existing legal candidates, original per-robot/joint masks and
received state. It screens endpoint distance strictly above1.45m, then prioritizes
longer existing path distances within the outward ranking. This is a nominal
stimulus choice, neither a necessary condition nor actual physical sufficiency.
There is no WorldPose/truth query, raw motor target, configurable threshold or
override of the5s commitment.

Each robot has at most one published GOAL and one scientific moving WAIT per
round. Published commands are recorded as attempts, never promoted to acceptance
or cancellation by an RPC return. A real matching active/owned accepted goal and
the first legal moving WAIT are required. Completion requires the matching
received CANCELED terminal with actual dispatcher stop_reason=wait. A successful
cancel response or an unrelated external stop is insufficient. New goals wait
for matching terminal, three fresh increasing-source rest observations and the
fixed3simsecond handoff. The two rounds and32 steps remain fixed; missing coverage
is an explicit failure and no short fallback/retry is inserted.32 steps are not
guaranteed to complete two meaningful rounds under all legal protocol delays.

The candidate requires both declared rounds' lifecycle coverage. That is a new
stimulus-quality requirement, not a modification of any independent physical
predicate. Real native-cancel events, all physical responses and every observed
violation remain subject to the unchanged independent readers. In particular,
this does not fix, explain away or replace V60 tb2's real3.031s/.259m B violation.

review_all.patch is the unified review artifact. Its first portion is core.patch,
which passes git apply --check against exact E. Its remaining portion uses
__NEXT_ACTIVITY__/ placeholders deliberately. The five activity_templates files
(prepare, preflight, readiness, entry fixture and scope) must be migrated into a
new activity directory. Never apply them to executed V60 assets. They show the
fixed v2 pair, true selected-reader readiness and new builder argument. The root
must supply the later actual closure ledger, budget, renamed activity identity,
fresh source proof and new exact freeze; no formal plan was generated here.

Potential merge areas are benchmark/supervisor and the two small worker regions.
No adapter, GoalDispatcher, observation/mask, motion_safety, cancellation-chain,
encoder helper, C++, CMake, solver or native library source is changed. A future
typed cancellation fix may touch worker startup/control code; combine under one
new source freeze and rerun canonical validation. Do not claim a new native build
for these Python-only stimulus changes; the actual build/source gate still owns
the unchanged real A59 native evidence.

Provisional verification only

All six core sources and four Python templates parse as AST; the scope parses as
JSON. The two final small artificial groups passed13 cases: real GoalDispatcher
and real action masks cover two rounds/all three owners/exact32 submissions,
natural completion, cancel acceptance versus terminal, external-stop cause
binding, failed submissions, old selector ASTs, fixed reader inverse, explicit
full-reader selection and non-probe-role isolation. No native telemetry, old raw
stream, old scientific audit, World or formal plan was consumed/generated.

Final system group:9PASS, tool68446 actual rc0,1.393746531s. Final learner group:
4PASS, tool48316 actual rc0,5.037947348s. Each sealed19 sources before/after/current.
All12 saved CPU PID/start pairs across the provisional history are freshgone;
provisional_complete_v1.json lists every actual result and source recovery.
An intermediate system fixture correctly failed because an already confirmed
first-round terminal was rechecked using second-round state. Its rc1 receipt,
console and exact source version are preserved. The correction checks only a
not-yet-confirmed terminal. Earlier PASS receipts are historical and do not
supply current-source credit. The original eight lifecycle fixtures and their
setup-failure artifacts remain byte-identical to their prior13-file manifest.

These checks compile shadow source in private namespaces; canonical base paths
are used only to locate unchanged immutable definition dependencies. They do not
claim canonical CPU admission, a deployed profile, actual goal availability,
physical response, qualification, learning or95% success. Engineering fee is0.
Before application: review with the separately evidenced cancellation fix, map
the new activity templates, run complete fresh canonical CPU/readiness/admission,
seal a new source/binding/plan and perform all12EP/30 roles plus the original
minimum/pilot/final gates. V60 and every older FAIL remain unchanged.
