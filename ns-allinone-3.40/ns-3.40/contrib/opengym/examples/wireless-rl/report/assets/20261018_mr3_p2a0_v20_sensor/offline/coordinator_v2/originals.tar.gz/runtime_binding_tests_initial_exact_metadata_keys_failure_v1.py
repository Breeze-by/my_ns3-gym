"""Real 941 preflight shape at actual main, with no process admission or child."""
import contextlib
import copy
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch


HERE = Path(__file__).parent
OLD = Path('/tmp/mr3_p2a0_v20_sensor_coordinator_proposal_v1')
FIXTURE = HERE / 'source_preflight_941ae862_original.json'
PLAN = HERE / 'ready_plan_941ae862_original.json'


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class RealRuntimeBindingTests(unittest.TestCase):
    def exercise(self, parent_directory, mutate=None):
        module = load(parent_directory / 'mr3_p2a0_v20_sensor_run_v1.py',
                      'runtime_binding_parent')
        pre = load(HERE / 'mr3_p2a0_v20_sensor_preflight_v1.py',
                   'runtime_binding_preflight')
        original, _ = module.read(FIXTURE)
        value = copy.deepcopy(original)
        if mutate:
            mutate(value)
        plan = json.loads(PLAN.read_bytes())
        self.assertEqual(len(original['source_bindings']), 103)
        self.assertEqual(len(plan['independent_source_bindings']), 160)
        self.assertTrue(all(set(row) == {'sha256', 'git_source', 'worktree_sha256'}
                            for row in original['source_bindings'].values()))
        self.assertEqual(module.sha(PLAN.read_bytes()), original['plan_sha256'])
        original_read, original_load = module.read, module.load
        captured = []

        def read(path):
            if str(path) == '/tmp/mr3_p2a0_v20_sensor_source_preflight_v1.json':
                _, proof = original_read(FIXTURE)
                return value, proof
            return original_read(path)

        def load_dependency(path, name):
            if Path(path).name == 'mr3_p2a0_v20_sensor_preflight_v1.py':
                return SimpleNamespace(validate_sensor_plan=pre.validate_sensor_plan,
                                       check_unused_resources=lambda: None)
            return original_load(path, name)

        def git(command, **kwargs):
            if command in (['git', 'rev-parse', 'HEAD'],
                           ['git', 'rev-parse', '@{u}']):
                return original['freeze'] + '\n'
            self.assertEqual(command, ['git', 'status', '--porcelain'])
            return b''

        def capture(actual_plan, freeze, plan_path, proof, unchanged, live):
            closure = dict(zip(unchanged.__code__.co_freevars,
                               (cell.cell_contents for cell in unchanged.__closure__)))
            bindings = closure['bindings']
            expected = [{'path': path, 'sha256': row['sha256']}
                        for path, row in original['source_bindings'].items()]
            self.assertEqual(bindings[:160], plan['independent_source_bindings'])
            self.assertEqual(bindings[160:], expected)
            self.assertEqual(len(bindings), 263)
            unchanged()  # All actual 263 file SHA checks remain active.
            captured.append(bindings)
            return {'passed': True, 'capture_process_completed': True, 'errors': [],
                    'original_physical_passed': False, 'measurement_availability': {}}

        with tempfile.TemporaryDirectory(prefix='mr3_sensor_binding_cpu_') as directory:
            fake_a = Path(directory)
            (fake_a / 'predeclared_plan_v20_sensor.json').write_bytes(PLAN.read_bytes())
            with contextlib.ExitStack() as stack:
                stack.enter_context(patch.object(module, 'A', fake_a))
                stack.enter_context(patch.object(module, 'PREFIX', fake_a / 'cpu_parent'))
                stack.enter_context(patch.object(module, 'read', read))
                stack.enter_context(patch.object(module, 'load', load_dependency))
                stack.enter_context(patch.object(module.subprocess, 'check_output', git))
                child = stack.enter_context(patch.object(
                    module.subprocess, 'Popen', side_effect=AssertionError('CPU must not launch a child')))
                stack.enter_context(patch.object(module, 'execute_capture', capture))
                stack.enter_context(patch.object(sys, 'argv', [module.__file__, original['freeze']]))
                output = stack.enter_context(contextlib.redirect_stdout(io.StringIO()))
                try:
                    result = module.main()
                finally:
                    child.assert_not_called()
            return result, captured, json.loads(output.getvalue())

    def test_original_main_reproduces_real_dict_list_typeerror(self):
        with self.assertRaisesRegex(TypeError, 'concatenate list'):
            self.exercise(OLD)

    def test_corrected_main_checks_all_real_103_runtime_plus_160_independent(self):
        result, captured, output = self.exercise(HERE)
        self.assertEqual(result, 0)
        self.assertEqual(len(captured), 1)
        self.assertIs(output['passed'], True)
        self.assertIs(output['original_physical_passed'], False)

    def test_corrected_main_rejects_guessed_list_shape(self):
        def change(value):
            value['source_bindings'] = [
                {'path': path, 'sha256': row['sha256']}
                for path, row in value['source_bindings'].items()]
        with self.assertRaisesRegex(AttributeError, 'items'):
            self.exercise(HERE, change)


if __name__ == '__main__':
    unittest.main()
