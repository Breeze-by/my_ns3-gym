import hashlib
import math
import random
import struct
from multi_robot_exploration.peer_obstacles import body_points


def pure(peers):
    result = bytearray()
    for x, y, age in peers:
        radius = .25 + .04 + .26 * (max(0., age) + .55)
        start, stop, step = -radius, radius + .025, .025
        count = math.ceil((stop - start) / step)
        actual_step = (start + step) - start
        offsets = [start + i * actual_step for i in range(count)]
        for dy in offsets:
            for dx in offsets:
                if dx * dx + dy * dy <= radius * radius:
                    result.extend(struct.pack('<fff', x + dx, y + dy, 0.))
    return bytes(result)


rng = random.Random(101)
cases = [[(1., 0., 0.)], [(0., 1., .5)], [(2.1, -3.4, .1), (-4., .3, .499)]]
cases += [[(rng.uniform(-20, 20), rng.uniform(-20, 20), rng.random() * .5)
           for _ in range(2)] for _ in range(100)]
for index, values in enumerate(cases):
    actual = body_points(values).tobytes()
    expected = pure(values)
    assert actual == expected, (index, hashlib.sha256(actual).hexdigest(),
                                hashlib.sha256(expected).hexdigest())
print({'passed': True, 'cases': len(cases), 'scope': 'CPU exact-byte conformance only'})
