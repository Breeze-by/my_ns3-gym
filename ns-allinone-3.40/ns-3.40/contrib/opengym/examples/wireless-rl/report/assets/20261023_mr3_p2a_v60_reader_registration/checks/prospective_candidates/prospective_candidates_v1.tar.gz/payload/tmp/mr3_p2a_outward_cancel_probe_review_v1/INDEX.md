Read [review_revision_v2.md](review_revision_v2.md) and
[proposal_v2_revision2.json](proposal_v2_revision2.json) for the current source-only
recommendation:1.45m nominal screen, genuine goal lifecycle, unchanged masks,
bounded32 steps and explicit coverage failures. Its14-point wiring checklist and
21-source AST inventory cover both producer and every reader/admission edge.

The initial2.65m proposal is preserved as history and superseded. Neither version
is installed. No actual goal availability, physical response or P2A qualification
is claimed. The separate observed tb2 B-bound violation remains unresolved here.

The final revised four-case synthetic lifecycle CPU used real GoalDispatcher and
real masks: tool27731 actually reaped rc0, child wait.771016846s, nine listed sources
stable/eight repository sources exact E, two saved identities freshgone. The
preceding source-path setup failure is retained separately; no child ran there.
Full details and hashes are in handoff_manifest_v1.json. No repository file, World,
old scientific reader or scientific input stream was touched.
