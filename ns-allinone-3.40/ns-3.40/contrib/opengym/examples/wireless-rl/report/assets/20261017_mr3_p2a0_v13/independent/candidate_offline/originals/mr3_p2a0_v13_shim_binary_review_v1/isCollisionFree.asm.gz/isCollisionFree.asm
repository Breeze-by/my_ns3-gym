<nav2_rotation_shim_controller::RotationShimController::isCollisionFree(geometry_msgs::msg::TwistStamped_<std::allocator<void> > const&, double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&)@plt>:
    ffa0:	f3 0f 1e fa          	endbr64 
    ffa4:	f2 ff 25 f5 72 03 00 	bnd jmp *0x372f5(%rip)        # 472a0 <nav2_rotation_shim_controller::RotationShimController::isCollisionFree(geometry_msgs::msg::TwistStamped_<std::allocator<void> > const&, double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&)@@Base+0x2f110>
    ffab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
