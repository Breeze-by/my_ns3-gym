from pathlib import Path
import json

ROOT=Path('/home/zhuyulab/ns3-workspace')
W=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
ROS=ROOT/'ros2_ws/ros2-multi-robot-automap'
old='V21_ray冻结099a8eea已自然闭合三机open101普通4step来源诊断，原生219.82827906589955墙秒，39进程exit0、48保存身份消失。三机实际近身回波均命中自身base_collision；原物理因tb1/tb2缺停车刺激保持FAIL，150尚未选用，P2A.0未完成。累计诊断2938.48922518407930/3600墙秒，无PPO或四阶段信用。'
new='V22准备修复已用实际ODE库CPU复现的Ray×Box近零方向误命中，stepped adapter加载独立碰撞回调。最终canonical库7be79c7f/389312B、动态实际库CPU与独立生命周期审查通过；三研究world/task选择quick/150单一工程候选，原门不变。尚待新冻结完整四阶段，P2A.0未完成；无新native/PPO，pilot余额未动。'
for path in (W/'RESEARCH_PLAN.md',W/'IMPLEMENTATION_PLAN.md',W/'AGENTS.md',ROS/'user_guide.md',ROS/'launch_commands.md'):
    text=path.read_text(); assert text.count(old)==1,path
    text=text.replace(old,new)
    text=text.replace('[V21](report/20261018_mr3_p2a0_v21_ray.md)','[V22](report/20261018_mr3_p2a0_v22_ray_box.md)',1)
    text=text.replace('[V21](../../ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/20261018_mr3_p2a0_v21_ray.md)','[V22](../../ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/20261018_mr3_p2a0_v22_ray_box.md)',1)
    path.write_text(text)
old_en='2026-10-18: V21_ray freeze099a8eea naturally closed ordinary4/open101/three-robot source capture: native219.82827906589955wall,39native exits0,48saved identities gone. Actual near raw returns hit each own base_collision; physical FAIL retained for tb1/tb2 missing stimulation. Diagnostic cumulative2938.48922518407930/3600wall. No150 production selection/P2A.0 completion/PPO or matrix credit. See wireless-rl/report/20261018_mr3_p2a0_v21_ray.md.'
new_en='2026-10-18: V22 prepares a public-API native RayBox finite-slab correction after actual ODE CPU false-hit reproduction. Final canonical SO7be79c7f/389312B and actual-library CPU/lifetime review pass. Fixed quick150 worlds/tasks are an unproven stopping candidate; original gates remain. Full new same-freeze fourstage matrix/preflight pending; P2A.0 incomplete, no new native/PPO. Old failures/pilot balance retained. See wireless-rl/report/20261018_mr3_p2a0_v22_ray_box.md.'
for path in (ROOT/'AGENTS.md',ROS/'AGENTS.md'):
    text=path.read_text(); assert text.count(old_en)==1,path
    path.write_text(text.replace(old_en,new_en))
path=W/'report/README.md'
text=path.read_text()
row='| [P2A.0 V22 RayBox修正准备](20261018_mr3_p2a0_v22_ray_box.md) | 实际ODE误求交CPU复现、原生碰撞回调修正及实际库构建 | CPU/SDK准备通过；150工程候选，完整新四阶段待执行，无训练信用 |\n'
assert row not in text
path.write_text(text.replace('| [P2A.0 V21 实际射线来源闭合]',row+'| [P2A.0 V21 实际射线来源闭合]',1))
path=W/'report/ARCHIVE_INDEX.json'
d=json.loads(path.read_text())
d['clarifications'].append({'recorded_date':'2026-10-18','review_base_commit':'ba34efb122a15ceea0fa28319bb16b5fc1469364',
 'report':str((W/'report/20261018_mr3_p2a0_v22_ray_box.md').relative_to(ROOT)),
 'affected_reports':[str((W/'report/20261018_mr3_p2a0_v19.md').relative_to(ROOT)),str((W/'report/20261018_mr3_p2a0_v21_ray.md').relative_to(ROOT))],
 'scope':'V22 selects the previously unselected fixed150 world/task source as one new engineering candidate and fixes a separately CPU-reproduced native RayBox false intersection using public ODE API. V19/V21 original outcomes, source freezes, scope and failures remain unchanged. Final actual library7be79 differs from SDK44263/first canonical f9a252. No native/matrix/PPO/95% or stopping-repair credit before complete new same-freeze validation.'})
path.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
# Replace a path abbreviation with its exact already-recorded original argv.
path=W/'log.md'
text=path.read_text(); token='--episode [canonicalROS]/log/mr3_p2a0/mr3_p2a0_20261018_v21_ray/worker0/episode001_open_101'
assert text.count(token)==1
path.write_text(text.replace(token,'--episode /home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261018_v21_ray/worker0/episode001_open_101',1))
print('V22 preparation navigation updated; old dated evidence retained')
