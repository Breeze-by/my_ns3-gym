"""Prospective exact-byte projection, not installed in any current auditor."""
from pathlib import PurePosixPath

WORLD_PREFIX = 'ros2_ws/ros2-multi-robot-automap/src/multi_robot/worlds/'
WORLD_PATHS = frozenset(WORLD_PREFIX + 'p1c_' + scene + '.world'
                        for scene in ('open', 'rooms', 'corridors'))
CONFIG_PREFIX = 'ros2_ws/ros2-multi-robot-automap/src/multi_robot/config/mr3_p1a/'
CONFIG_PATHS = frozenset(CONFIG_PREFIX + scene + '.json'
                       for scene in ('open', 'rooms', 'corridors'))
ODE_BLOCK = (b'      <ode>\n'
             b'        <solver>\n'
             b'          <type>quick</type>\n'
             b'          <iters>150</iters>\n'
             b'        </solver>\n'
             b'      </ode>\n')
ANCHOR = b'      <real_time_update_rate>1000</real_time_update_rate>\n'


def projected_world(relative, normative_w7, actual, explicit_world_pins):
    """Only this fixed block on exactly three pre-pinned worlds is permitted."""
    import hashlib
    if relative not in WORLD_PATHS or set(explicit_world_pins) != WORLD_PATHS:
        raise ValueError('only the three explicit p1c world pins are permitted')
    if str(PurePosixPath(relative)) != relative:
        raise ValueError('noncanonical relative world path')
    if hashlib.sha256(actual).hexdigest() != explicit_world_pins[relative]:
        raise ValueError('new explicit solver world SHA differs')
    if normative_w7.count(ANCHOR) != 1 or b'<ode>' in normative_w7:
        raise ValueError('normative W7 physics anchor differs')
    expected = normative_w7.replace(ANCHOR, ANCHOR + ODE_BLOCK, 1)
    if actual != expected or actual.count(ODE_BLOCK) != 1:
        raise ValueError('actual world is not exactly the sole approved block insertion')
    projected = actual.replace(ODE_BLOCK, b'', 1)
    if projected != normative_w7:
        raise ValueError('world did not project byte-for-byte to original W7')
    return projected


def projected_task_metadata(relative, normative_w7, actual, explicit_config_pins,
                            old_world_sha, new_world_sha):
    """Preserve task bytes except its required actual-world SHA binding."""
    import hashlib
    if relative not in CONFIG_PATHS or set(explicit_config_pins) != CONFIG_PATHS:
        raise ValueError('only the three explicit task metadata pins are permitted')
    if hashlib.sha256(actual).hexdigest() != explicit_config_pins[relative]:
        raise ValueError('new explicit task metadata SHA differs')
    before = ('  "world_sha256": "' + old_world_sha + '",\n').encode()
    after = ('  "world_sha256": "' + new_world_sha + '",\n').encode()
    if normative_w7.count(before) != 1 or actual.count(after) != 1:
        raise ValueError('task world SHA field count/identity differs')
    expected = normative_w7.replace(before, after, 1)
    if actual != expected or actual.replace(after, before, 1) != normative_w7:
        raise ValueError('task metadata did not project byte-for-byte to W7')
    return normative_w7
