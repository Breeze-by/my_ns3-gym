import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


ROOT = Path('/home/zhuyulab/ns3-workspace')
OUT = Path(__file__).resolve().parent
SOURCES = [Path('/tmp/mr3_p2a0_v13_run_matrix_v1.py'),
           Path('/tmp/mr3_p2a0_v13_run_matrix_v1_tests.py')]
ENV = dict(os.environ, PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1')
CHECKS = [
    ('fake_cli_final_v2', ['/usr/bin/python3', str(SOURCES[1])]),
    ('style_final_v2', ['/usr/bin/python3', '-m', 'flake8', '--max-line-length=100',
                     '--ignore=E128,E129,W503,W504', *map(str, SOURCES)]),
]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def hashes():
    return {str(path): sha(path.read_bytes()) for path in SOURCES}


before = hashes()
checks = []
for label, argv in CHECKS:
    started = time.monotonic()
    path = OUT / (label + '.log')
    with path.open('xb') as stream:
        process = subprocess.run(argv, cwd=ROOT, env=ENV,
                                 stdout=stream, stderr=subprocess.STDOUT)
    checks.append({'label': label, 'argv': argv, 'cwd': str(ROOT),
                   'returncode': process.returncode, 'wall_seconds': time.monotonic() - started,
                   'stdout': str(path), 'stdout_sha256': sha(path.read_bytes())})
    print(json.dumps(checks[-1]), flush=True)
after = hashes()
for path in SOURCES:
    with (OUT / ('final_v2_' + path.name)).open('xb') as stream:
        stream.write(path.read_bytes())
watcher = ROOT / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
                  'report/assets/20261017_mr3_p2a0_v13/independent/'
                  'mr3_p2a0_v13_cross_stage_mapping_monitor_v1.py')
watcher_bytes = watcher.read_bytes()
compatible = ('mr3_p2a0_v13_remaining_matrix_v1.jsonl' in watcher_bytes.decode()
              and 'mr3_p2a0_v13_remaining_matrix_v1.jsonl' in SOURCES[0].read_text())
syntax = {}
for path in SOURCES:
    syntax[str(path)] = ast.dump(ast.parse(path.read_bytes()), include_attributes=False)
artifacts = {}
for path in sorted(OUT.rglob('*')):
    if path.is_file():
        raw = path.read_bytes()
        artifacts[str(path.relative_to(OUT))] = {'bytes': len(raw), 'sha256': sha(raw)}
result = {'schema': 'mr3-p2a0-v13-parent-controller-checks-v1',
          'passed': before == after and compatible and all(item['returncode'] == 0 for item in checks),
          'source_before': before, 'source_after': after, 'checks': checks,
          'environment': {key: ENV[key] for key in ('PYTHONNOUSERSITE', 'PYTHONDONTWRITEBYTECODE')},
          'unique_test_methods': 7,
          'scope': 'Real finite fake Python CLI children in temporary local Git fixtures only; '
                   'no native, ROS, formal consumer or training execution',
          'watcher': {'path': str(watcher), 'sha256': sha(watcher_bytes),
                      'ledger_path_compatible': compatible,
                      'ledger': '/tmp/mr3_p2a0_v13_remaining_matrix_v1.jsonl',
                      'failure_event': 'version_failed_later_stages_skip',
                      'identity': 'every row freeze exact40; started.controller_identity; '
                                  'child_spawned/command_completed.child_identity PID/start_ticks'},
          'initial_checks_scope': 'Development direct tool execution: 7 PASS in5.484s; '
                                  'initial style exit1 with8 findings; original source bytes saved. '
                                  'Direct tool chunks retained separately, not claimed as execve trace.',
          'artifacts': artifacts,
          'actual_native_cli_template': ['/home/zhuyulab/miniconda3/envs/ns3gym/bin/python',
                                        str(SOURCES[0]), 'EXACT40'],
          'native_admission_granted': False}
path = OUT / 'checks_final_v2.json'
with path.open('x') as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({'passed': result['passed'], 'receipt': str(path),
                  'receipt_sha256': sha(path.read_bytes()), 'source_final': after}), flush=True)
raise SystemExit(0 if result['passed'] else 1)
