import ast
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
ROOT=Path('/home/zhuyulab/ns3-workspace')
BASE=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v10/independent'
spec=importlib.util.spec_from_file_location('consumer_tests',BASE/'mr3_independent_control_phase_v1_tests.py')
tests=importlib.util.module_from_spec(spec);spec.loader.exec_module(tests)
f=tests.Fixture();M=tests.M
stop_index=next(i for i,r in enumerate(f.worker) if r['kind']=='request' and r['request']['operation']=='stop')
stop_wall=f.worker[stop_index]['wall_monotonic_ns'];target=1_040_000_000
request={'schema':'mr3-state-phase-request-v1','epoch':f.epoch,'request_id':'abandoned_state',
         'operation':'commit','target_time_ns':target}
row={'schema':'mr3-controlled-execution-phase-v1','kind':'request','epoch':f.epoch,
     'worker_physical_ns':target,'worker_clock_ns':target,'wall_monotonic_ns':stop_wall-2,
     'component':'state','request':request}
f.worker.insert(stop_index,row)
f.info.append({'kind':'state_phase_request','epoch':f.epoch,'clock_ns':target,
               'wall_monotonic_ns':stop_wall-1,'payload':{'request':request,'duplicate':False}})
ack=f.ack('state','commit',target,'abandoned_state',error='state_phase_target_passed')
ack.update(ok=False,clock_ns=1_060_000_000)
f.iack(ack)
f.wrow('ack_received',1_060_000_000,component='state',ack=ack)
result={'schema':'mr3-v10-readonly-sticky-negative-review-v1','native_starts':0,
        'consumer_sha256':hashlib.sha256(Path(M.__file__).read_bytes()).hexdigest(),
        'synthetic_scope':'Completed zero stop followed by actual logged nonterminal negative ACK of an abandoned state request; no native credit'}
try:
 result['independent_reader_result']=f.replay();result['independent_reader_passed']=True
except (ValueError,KeyError,TypeError) as e:
 result['independent_reader_passed']=False;result['independent_reader_error']=str(e)
worker_path=ROOT/'ros2_ws/ros2-multi-robot-automap/scripts/mr3_env_worker.py'
tree=ast.parse(worker_path.read_text())
node=next(n for c in tree.body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,ast.FunctionDef) and n.name=='receive_control_phase')
module=ast.Module(body=[node],type_ignores=[]);namespace={'canonical':lambda value:json.dumps(value,sort_keys=True)}
exec(compile(ast.fix_missing_locations(module),str(worker_path),'exec'),namespace)
worker=SimpleNamespace(epoch=f.epoch,_trace_control_phase=lambda *a,**k:None)
try:
 namespace['receive_control_phase'](worker,'state',ack)
 result['production_worker_rejected']=False
except RuntimeError as e:
 result['production_worker_rejected']=True;result['production_worker_error']=str(e)
result['production_worker_sha256']=hashlib.sha256(worker_path.read_bytes()).hexdigest()
result['interface_mismatch']=result['independent_reader_passed'] and result['production_worker_rejected']
result['limitation']='Original full native/motion audits separately reject real callback failures; this tests the standalone new control reader exact sticky-negative criterion only.'
out=Path('/tmp/mr3_p2a0_v10_reader_sticky_negative_review_v1.json');out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,sort_keys=True))
