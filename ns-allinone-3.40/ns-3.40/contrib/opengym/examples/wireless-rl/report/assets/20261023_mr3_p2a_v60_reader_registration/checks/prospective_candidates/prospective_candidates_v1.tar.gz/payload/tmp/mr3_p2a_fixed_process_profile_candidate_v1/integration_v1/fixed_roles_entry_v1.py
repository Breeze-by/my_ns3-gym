"""Fixed source/thread hooks followed by the already CPU-tested core."""
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import fixed_process_profile_v1 as core
from fixed_integration_v1 import install_role, require


def main():
    import hashlib
    require(hashlib.sha256(Path(core.__file__).read_bytes()).hexdigest()
            == 'bef68fb65d28edc24689e22b576c5b727fc179c67dde3e7c0b53d7eeac0073e7',
            'the once-tested core bytes differ')
    command = list(sys.argv[1:])
    roles = [role for role, path in core.PROGRAMS.items() if command and command[0] == str(path)]
    require(len(roles) == 1, 'target is outside the fixed three-role whitelist')
    role = roles[0]
    profiles = core.OWNED_EPISODE / 'profiles'
    profiles.mkdir(exist_ok=True)
    require(profiles == profiles.resolve(strict=True), 'owned profile directory has a symlink component')
    install_role(core, role)
    # Match normal `python original_script.py ...` sibling-import semantics.
    sys.path[0] = str(core.PROGRAMS[role].parent)
    core.run_role(role, command)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
