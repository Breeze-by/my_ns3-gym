from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import time
ROOT=Path('/home/zhuyulab/ns3-workspace')
BASE=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v11/independent'
reader=BASE/'mr3_independent_control_phase_v2.py';tests=BASE/'mr3_independent_control_phase_v2_tests.py'
spec=importlib.util.spec_from_file_location('new67',tests);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
fixture,_=module.abandoned_negative()
case=Path('/tmp/mr3_p2a0_v11_control_sticky_counterexample_v1');case.mkdir(exist_ok=True)
module.write_fixture(case,fixture)
metadata=json.loads((case/'metadata.json').read_text());metadata['synthetic_validation_only']=True
(case/'metadata.json').write_text(json.dumps(metadata,sort_keys=True)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
tracked=[reader,tests,module.V2.OLD_PATH,module.OLD_TEST]
before={str(p):sha(p)for p in tracked}
raw_before={str(p):sha(p)for p in case.iterdir()if p.is_file()}
red=Path('/tmp/mr3_p2a0_v11_control_sticky_old_reader_red_v1.json')
green=Path('/tmp/mr3_p2a0_v11_control_sticky_new_reader_green_v1.json')
commands=[('mutation_tests_final',0,['env','PYTHONDONTWRITEBYTECODE=1','/usr/bin/python3',str(tests),'-v']),
 ('style_final',0,['/usr/bin/python3','-m','flake8',str(reader),str(tests),'--max-line-length=99']),
 ('syntax_final',0,['/usr/bin/python3','-c',"from pathlib import Path;import sys;[compile(Path(p).read_text(),p,'exec')for p in sys.argv[1:]]",str(reader),str(tests)]),
 ('counterexample_red_old_cli',0,['env','PYTHONDONTWRITEBYTECODE=1','/usr/bin/python3',str(module.V2.OLD_PATH),str(case),'--freeze','synthetic-freeze','--output',str(red)]),
 ('counterexample_green_new_cli',1,['env','PYTHONDONTWRITEBYTECODE=1','/usr/bin/python3',str(reader),str(case),'--freeze','synthetic-freeze','--output',str(green)])]
results=[]
for label,expected,argv in commands:
 start=time.monotonic();r=subprocess.run(argv,cwd=ROOT,capture_output=True,text=True)
 out=Path('/tmp/mr3_p2a0_v11_control_'+label+'_v1.log');out.write_text(r.stdout+r.stderr)
 results.append({'label':label,'cwd':str(ROOT),'argv':argv,'exit_code':r.returncode,'expected_exit_code':expected,'matched_expected':r.returncode==expected,'wall_seconds':time.monotonic()-start,'stdout_stderr':str(out),'sha256':sha(out)})
red_result=json.loads(red.read_text());green_result=json.loads(green.read_text())
after={str(p):sha(p)for p in tracked}
raw_after={str(p):sha(p)for p in case.iterdir()if p.is_file()}
assert before==after and raw_before==raw_after
result={'schema':'mr3-v11-sticky-control-offline-checks-v1','passed':all(v['matched_expected']for v in results)and red_result['passed']is True and green_result['passed']is False,
 'native_starts':0,'source_before':before,'source_after':after,'raw_counterexample_inputs_before':raw_before,'raw_counterexample_inputs_after':raw_after,'checks':results,
 'counterexample':{'old_v1_passed':red_result['passed'],'new_v2_passed':green_result['passed'],'new_errors':green_result['episodes'][0]['errors'],'old_receipt':str(red),'new_receipt':str(green)},
 'history':['/tmp/mr3_p2a0_v11_control_consumer_tests_01.log','/tmp/mr3_p2a0_v11_control_consumer_style_01.log','/tmp/mr3_p2a0_v11_control_consumer_style_02.log'],
 'scope':'All58 original causal tests rerun with the subclass plus9 new sticky/typed/terminal/red-green tests. Red old-reader PASS intentionally demonstrates the gap, not native acceptance.',
 'limits':['No original reader, mathematical, body, latency or task gate changed.','Peer-only keeps its original component scope; sticky worker-prefix gate applies only full control.','Only actual matching state terminal cancellation remains exempt through unchanged original notice/source/ACK checks.','No native experiment, training, PPO, physical or95percent credit.']}
out=Path('/tmp/mr3_p2a0_v11_control_consumer_checks_v1.json');out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'passed':result['passed'],'receipt':str(out),'receipt_sha256':sha(out),'source':before,'counterexample':result['counterexample']}))
