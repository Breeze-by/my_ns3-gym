"""Run the unchanged four status-document assertions with their revised narrow fixture.
Production load_native_gates, ENV/machine helpers execute from the exact proposed AST.
Original dependency-loaded component boundary remains mocked as in the original tests.
"""
import ast
import copy
import hashlib
from functools import partial
import json
from pathlib import Path
import subprocess
import types
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
source = (HERE / 'proposed_audit_ppo.py').read_text()
tree = ast.parse(source)
functions = {'require', 'sha', 'verify_machine_task_file', 'verify_environment_appendix', 'load_native_gates'}
body = [node for node in tree.body if isinstance(node, ast.Assign) or (
    isinstance(node, ast.FunctionDef) and node.name in functions)]
audit_ppo = types.ModuleType('fixture_actual_proposed_auditor')
audit_ppo.__dict__.update(Path=Path, hashlib=hashlib, subprocess=subprocess,
                          load_pinned=lambda *a: None, load_compatible_components=lambda *a: None)
exec(compile(ast.Module(body=copy.deepcopy(body), type_ignores=[]),
             str(HERE / 'proposed_audit_ppo.py'), 'exec'), audit_ppo.__dict__)
audit_ppo.__dict__.update(SimpleNamespace=SimpleNamespace, partial=partial, audit_scalar=SimpleNamespace(
    ORIGINAL_SCALAR_SHA256=audit_ppo.SCALAR_SHA256, audit_episode=lambda *a, **k: None))
tests = ast.parse((HERE / 'proposed_test_audit_ppo.py').read_text())
status_class = next(node for node in tests.body if isinstance(node, ast.ClassDef)
                    and node.name == 'NativeBindingTests')
exec(compile(ast.Module(body=[status_class], type_ignores=[]),
             str(HERE / 'proposed_test_audit_ppo.py'), 'exec'), globals())

if __name__ == '__main__':
    unittest.main(verbosity=2)
