"""Independent complete-prefix CDR diagnosis; no ROS init, publishers or control."""
import argparse
import ast
import collections
import gzip
import hashlib
import json
import math
from pathlib import Path

from dwb_msgs.msg import LocalPlanEvaluation
from geometry_msgs.msg import Twist
from nav_msgs.msg import Path as ROSPath
from rclpy.serialization import deserialize_message

EXPECTED=('RotateToGoal','Oscillation','BaseObstacle','GoalAlign','PathAlign','PathDist','GoalDist')
TYPES={'cmd_vel_nav':Twist,'evaluation':LocalPlanEvaluation,'received_global_plan':ROSPath,
       'transformed_global_plan':ROSPath,'local_plan':ROSPath}


def digest(raw):return hashlib.sha256(raw).hexdigest()

def score(t,index=None):
 return dict(index=index,velocity=dict(x=t.traj.velocity.x,y=t.traj.velocity.y,theta=t.traj.velocity.theta),
  total=float(t.total),full_critic_list=tuple(s.name for s in t.scores)==EXPECTED,
  scores=[dict(name=s.name,raw_score=float(s.raw_score),scale=float(s.scale),
               weighted=float(s.raw_score)*float(s.scale))for s in t.scores],
  weighted_sum=sum(float(s.raw_score)*float(s.scale)for s in t.scores),
  traj_poses=len(t.traj.poses),first_pose=dict(x=t.traj.poses[0].x,y=t.traj.poses[0].y,theta=t.traj.poses[0].theta)if t.traj.poses else None,
  last_pose=dict(x=t.traj.poses[-1].x,y=t.traj.poses[-1].y,theta=t.traj.poses[-1].theta)if t.traj.poses else None)


def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--revision',required=True);args=parser.parse_args()
 out=Path('/tmp/mr3_p2a0_v12_passive_nav2_critic_review_'+args.revision)
 out.mkdir(exist_ok=False)
 result=dict(schema='mr3-post-failure-passive-nav2-critic-review-v1',
  scope='Late post-known-FAIL actual partial corridor observations, additional observer publication/CPU/DDS load. No formal/PASS credit; cannot reconstruct previous open w0/e2. Frozen receipt prefixes and immutable CDR only.',
  reviewer_source_sha256=digest(Path(__file__).read_bytes()),domains=[])
 for domain in(134,135):
  directory=Path('/tmp/mr3_p2a0_v12_passive_nav2_domain'+str(domain)+'_v6');p=directory/'receipts.jsonl';capture=p.read_bytes();end=capture.rfind(b'\n')+1;raw=capture[:end]
  prefix=out/('domain'+str(domain)+'_complete_prefix.jsonl');prefix.write_bytes(raw)
  rows=[(n,json.loads(line))for n,line in enumerate(raw.splitlines(),1)if line.strip()]
  source_proof=dict(path=str(p),prefix_bytes=len(raw),prefix_sha256=digest(raw),
                    snapshot_original_bytes=len(capture),incomplete_tail_bytes_ignored=len(capture)-end,
                    snapshot=str(prefix),scope='Complete prefix at read time; live file may append, not final-run hash')
  payloads={};messages=[]
  for line,row in rows:
   if row.get('kind')!='raw_cdr_received':continue
   path=directory/row['payload'];encoded=path.read_bytes();actual=gzip.decompress(encoded)
   assert digest(encoded)==row['payload_proof']['encoded_sha256']and len(encoded)==row['payload_proof']['encoded_bytes']
   assert digest(actual)==row['raw_cdr_sha256']and len(actual)==row['raw_cdr_bytes']
   assert path.read_bytes()==encoded
   payloads[str(path)]=dict(encoded_bytes=len(encoded),encoded_sha256=digest(encoded),raw_bytes=len(actual),raw_sha256=digest(actual))
   m=deserialize_message(actual,TYPES[row['topic'].rsplit('/',1)[1]])
   messages.append((line,row,m))
  bytopic=collections.defaultdict(list)
  for line,row,m in messages:bytopic[row['topic']].append((line,row,m))
  def path_summary(entry):
   if entry is None:return None
   line,row,m=entry
   return dict(line=line,topic=row['topic'],topic_sequence=row['topic_sequence'],
    record_sequence=row['record_sequence'],raw_cdr_sha256=row['raw_cdr_sha256'],
    header=row['header'],observer_clock_ns=row['observer_clock_ns'],wall_monotonic_ns=row['wall_monotonic_ns'],
    poses=len(m.poses),first=dict(x=m.poses[0].pose.position.x,y=m.poses[0].pose.position.y)if m.poses else None,
    last=dict(x=m.poses[-1].pose.position.x,y=m.poses[-1].pose.position.y)if m.poses else None,
    pose_xy=[[q.pose.position.x,q.pose.position.y]for q in m.poses])
  evals=[]
  for line,row,m in messages:
   if not isinstance(m,LocalPlanEvaluation):continue
   if not m.twists or m.best_index>=len(m.twists):
    evals.append(dict(line=line,topic=row['topic'],invalid_best_index=True,raw_cdr_sha256=row['raw_cdr_sha256']));continue
   winner=m.twists[m.best_index];win=score(winner,m.best_index)
   positive=[(i,t)for i,t in enumerate(m.twists)if t.traj.velocity.x>0]
   positive_complete=[(i,t)for i,t in positive if t.total>=0 and tuple(s.name for s in t.scores)==EXPECTED]
   pos=min(positive_complete,key=lambda pair:pair[1].total)if positive_complete else None
   pc=score(pos[1],pos[0])if pos else None
   if pc and win['full_critic_list']:
    deltas=[dict(name=a['name'],best_weighted=a['weighted'],positive_weighted=b['weighted'],
      positive_minus_best=b['weighted']-a['weighted'])for a,b in zip(win['scores'],pc['scores'])]
   else:deltas=None
   robot=row['topic'].split('/')[1];paths={}
   for suffix in('received_global_plan','transformed_global_plan','local_plan'):
    candidates=[e for e in bytopic['/'+robot+'/'+suffix]if e[0]<line]
    paths[suffix]=path_summary(candidates[-1])if candidates else None
   local_candidates=[e for e in bytopic['/'+robot+'/local_plan']if e[1]['header']==row['header']]
   matches=[]
   winner_xy=[[q.x,q.y]for q in winner.traj.poses]
   for entry in local_candidates:
    if [[q.pose.position.x,q.pose.position.y]for q in entry[2].poses]==winner_xy:
     matches.append(dict(line=entry[0],raw_cdr_sha256=entry[1]['raw_cdr_sha256'],
                         received_before_evaluation=entry[0]<line))
   same_best_twists=[dict(line=l,topic_sequence=r['topic_sequence'],wall_monotonic_ns=r['wall_monotonic_ns'],
     observer_clock_ns=r['observer_clock_ns'],raw_cdr_sha256=r['raw_cdr_sha256'])
      for l,r,t in bytopic['/'+robot+'/cmd_vel_nav']if t.linear.x==winner.traj.velocity.x
      and t.angular.z==winner.traj.velocity.theta and abs(r['wall_monotonic_ns']-row['wall_monotonic_ns'])<=200_000_000]
   evals.append(dict(line=line,topic=row['topic'],record_sequence=row['record_sequence'],
    topic_sequence=row['topic_sequence'],source_header=row['header'],observer_clock_ns=row['observer_clock_ns'],
    wall_monotonic_ns=row['wall_monotonic_ns'],epoch_context=row['epoch_context'],
    raw_cdr_sha256=row['raw_cdr_sha256'],payload=str(directory/row['payload']),
    graph_endpoints=row['graph_endpoints'],trajectories=len(m.twists),winner=win,
    positive_trajectory_count=len(positive),positive_full_nonnegative_count=len(positive_complete),
    positive_partial_or_illegal_count=len(positive)-len(positive_complete),
    best_positive_full=pc,positive_minus_best_critic_deltas=deltas,
    positive_minus_best_stored_total=float(pos[1].total)-float(winner.total)if pos else None,
    exact_stored_total_tie_positive_indices=[i for i,t in positive_complete if t.total==winner.total],
    preceding_received_plans=paths,
    same_header_local_plan_matching_selected_xy=matches,
    nearby_cmd_vel_nav_equal_selected_value=same_best_twists,
    relation_scope='Actual callback-order prefix and same-header/value matches, not per-packet or exact computation-cycle ACK. Headerless Twist has receipt time only. Plans may be replaced or callback reordered across topics; do not assume prior plan is the controller computation input.'))
  botstats={}
  for robot in('tb1','tb2','tb3'):
   es=[e for e in evals if e['topic']=='/'+robot+'/evaluation'and'winner'in e]
   zeros=[e for e in es if e['winner']['velocity']['x']==0]
   botstats[robot]=dict(evaluations=len(es),zero_best=len(zeros),
    first_source_ns=es[0]['source_header']['stamp_ns']if es else None,last_source_ns=es[-1]['source_header']['stamp_ns']if es else None,
    full_zero_winner_count=sum(e['winner']['full_critic_list']for e in zeros),
    zero_with_nonzero_valid_full_candidate=sum(e['positive_full_nonnegative_count']>0 for e in zeros),
    zero_with_equal_total_positive=sum(bool(e['exact_stored_total_tie_positive_indices'])for e in zeros),
    zero_examples=[e for e in zeros[::max(1,len(zeros)//6)]][:7])
  for e in evals:
   # All per-evaluation records retain critic scores; path coordinates are redundant elsewhere.
   for v in e.get('preceding_received_plans',{}).values():
    if v:v.pop('pose_xy',None)
  with p.open('rb')as stream:assert stream.read(len(raw))==raw
  domain_result=dict(domain=domain,receipt_prefix=source_proof,raw_messages=len(messages),payload_files=len(payloads),
   payload_proofs=payloads,topic_counts={k:len(v)for k,v in bytopic.items()},
   parameters=[dict(line=n,row=r)for n,r in rows if r.get('kind')=='actual_parameter_response'],
   robot_statistics=botstats,evaluations=evals,
   partial_score_policy='Only complete ordered seven-critic nonnegative trajectories are compared. Partial/illegal candidates counted separately, never imputed0. Stored totals and double weighted sums retained separately due float32 rounding.')
  result['domains'].append(domain_result)
 observer=Path('/tmp/mr3_p2a0_v12_passive_nav2_observer_v4.py');source=observer.read_bytes();tree=ast.parse(source)
 forbidden=[dict(line=n.lineno,attribute=n.func.attr)for n in ast.walk(tree)if isinstance(n,ast.Call)
            and isinstance(n.func,ast.Attribute)and n.func.attr in('create_publisher','publish','set_parameters','set_parameters_atomically')]
 result['observer_readonly_review']=dict(source=str(observer),sha256=digest(source),forbidden_control_calls=forbidden,
  uses_only_GetParameters_service=True,CDR_is_raw_subscription_bytes=True,
  graph_identity_is_not_packet_identity=True,epoch_context_is_not_per_message_epoch=True,
  timing_caveat='Row wall and observer_clock are captured by write() after synchronous compression/deserialization, not at receive_raw entry. Native ROS source headers remain exact. Treat rowwall as postprocessing receipt bound; no exact callback latency calculation.',
  qos_caveat='Actual endpoint graph reports RELIABLE/VOLATILE but UNKNOWN history/depth0 on this RMW; do not rewrite it as actual known KEEP_LAST1. Requested reader QoS is separately explicit.')
 target=out/'review.json';target.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
 print(json.dumps(dict(output=str(target),sha256=digest(target.read_bytes()),
  domains=[dict(domain=d['domain'],raw_messages=d['raw_messages'],
    robots={r:{k:v for k,v in b.items()if k!='zero_examples'}for r,b in d['robot_statistics'].items()})for d in result['domains']]),indent=2))


if __name__=='__main__':main()
