# Insert after the frozen live-witness module is loaded as witness_module.
# This is a prelaunch executable/entity/SHA check only; no Gazebo execution.
gazebo_executable = witness_module.declared_gazebo_executable(plan["gazebo_executable"])
# Preserve gazebo_executable in the output preflight receipt.
