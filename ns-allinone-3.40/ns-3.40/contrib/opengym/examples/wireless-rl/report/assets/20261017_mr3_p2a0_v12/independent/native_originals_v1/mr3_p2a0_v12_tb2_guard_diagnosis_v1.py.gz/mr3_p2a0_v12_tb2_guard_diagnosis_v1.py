"""Read-only actual decision/goal causality summary; no counterfactual or acceptance."""
import collections,hashlib,json,math
from pathlib import Path
EP=Path("/home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261017_v12_reset/worker0/episode002_open_101")
OUT=Path("/tmp/mr3_p2a0_v12_reset_w0e2_tb2_guard_diagnosis_v1.json")
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
trans=[json.loads(l)for l in (EP/"transitions.jsonl").read_text().splitlines()if l.strip()]
release=trans[0]["info"]["release_time_ns"]; end=round(trans[-1]["snapshot"]["source_stamp"]*1e9)
events=[];goals=[];inputs={}
for name in ["metadata.json","transitions.jsonl","adapter.jsonl"]:inputs[name]={"path":str(EP/name),"sha256":sha(EP/name)}
for l in (EP/"adapter.jsonl").open():
 r=json.loads(l);p=r.get("payload",{})
 if r["kind"] in ["native_send","native_cancel"] and p.get("robot")=="tb2":
  events.append(r)
  if r["kind"]=="native_send":goals.append((round(r["stamp"]*1e9),p["pose"]))
 if r["kind"]=="delivery" and p.get("source")=="tb2" and p.get("payload",{}).get("type") in ["accept","result"]:events.append(r)
records=[];model_failures=[];digest=hashlib.sha256();line_no=0
with (EP/"motion_safety.jsonl").open("rb") as stream:
 for l in stream:
  digest.update(l);line_no+=1
  if not l.strip():continue
  r=json.loads(l);p=r.get("payload",{})
  if r["kind"]=="settled_turn_model_failure":model_failures.append(r)
  if r["kind"]!="decision" or p.get("robot")!="tb2" or not release<=p["clock_ns"]<=end:continue
  own=p["own_state"];d=p["decision"];req=p["request"] or {};clock=p["clock_ns"];cert=own.get("settled_turn");active_goal=max((g for g in goals if g[0]<=clock),default=None)
  goal=active_goal[1]if active_goal else None
  bearing=math.atan2(goal["y"]-own["y"],goal["x"]-own["x"])if goal else None
  err=math.atan2(math.sin(bearing-own["yaw"]),math.cos(bearing-own["yaw"]))if goal else None
  cf=d.get("component_filter");rc=cf.get("rotation_check")if cf else None
  records.append({"raw_line":line_no,"record_sequence":r["record_sequence"],"task_sec":(clock-release)/1e9,"clock_ns":clock,"request_v":req.get("v"),"request_w":req.get("w"),"output":d["output"],"reason":d["reason"],"allow":d["allow"],"x":own["x"],"y":own["y"],"yaw":own["yaw"],"own_v":own["v"],"own_w":own["w"],"full_planar":own["planar_speed_mps"],"goal":goal,"direct_goal_distance":math.hypot(goal["x"]-own["x"],goal["y"]-own["y"])if goal else None,"direct_goal_bearing_error":err,"body_margin_m":d.get("body_margin_m"),"minimum_margin_m":d.get("minimum_margin_m"),"near_peer_checks":d.get("near_peer_checks"),"certificate_present":cert is not None,"certificate":cert,"rotation_check_reason":rc.get("reason")if rc else None})
inputs["motion_safety.jsonl"]={"path":str(EP/"motion_safety.jsonl"),"sha256":digest.hexdigest()}
for v in inputs.values():assert sha(Path(v["path"]))==v["sha256"]
def summarize(values):
 counts=collections.Counter(r["reason"]for r in values)
 return {"decisions":len(values),"reasons":dict(counts),"positive_request_v":sum((r["request_v"]or 0)>0 for r in values),"nonzero_request_v":sum((r["request_v"]or 0)!=0 for r in values),"nonzero_final_v":sum(r["output"][0]!=0 for r in values),"nonzero_final_w":sum(r["output"][1]!=0 for r in values),"certificate_present":sum(r["certificate_present"]for r in values),"certificate_with_margin_below_0_1518":sum(r["certificate_present"]and r["body_margin_m"] is not None and r["body_margin_m"]<.1518 for r in values),"min_body_margin_m":min((r["body_margin_m"]for r in values if r["body_margin_m"] is not None),default=None),"max_body_margin_m":max((r["body_margin_m"]for r in values if r["body_margin_m"] is not None),default=None),"min_abs_direct_goal_bearing_error":min((abs(r["direct_goal_bearing_error"])for r in values if r["direct_goal_bearing_error"]is not None),default=None),"max_abs_direct_goal_bearing_error":max((abs(r["direct_goal_bearing_error"])for r in values if r["direct_goal_bearing_error"]is not None),default=None)}
bins=[]
for t in range(32):
 values=[r for r in records if t<=r["task_sec"]<t+1]
 if values:bins.append({"from_task_sec":t,**summarize(values),"first":values[0],"last":values[-1]})
windows={label:summarize([r for r in records if a<=r["task_sec"]<b])for label,a,b in [("first_goal_0_10",0,10),("WAIT_10_13",10,13),("second_goal_13_28",13,28),("WAIT_28_32",28,32)]}
selected=[]
for t in [0,1,1.52,2,3,4,5,6,7,8,9,10,13,14,15,16,18,20,22,24,26,28,30,32]:
 selected.append(min(records,key=lambda r:abs(r["task_sec"]-t)))
report={"scope":"Read-only actual records and direct-goal bearing diagnostic; direct bearing is not a Nav2 path/heading contract, no counterfactual, no proof of all geometric conservatism and no formal gate replacement","inputs":inputs,"release_ns":release,"end_ns":end,"events":events,"overall":summarize(records),"windows":windows,"per_second":bins,"selected_actual_records":selected,"model_failures":model_failures,"last_activity":next(r["activity"]for r in trans[-1]["snapshot"]["robots"]if r["name"]=="tb2")}
with OUT.open("x")as f:json.dump(report,f,indent=2,allow_nan=False);f.write("\n")
print(json.dumps({"output":str(OUT),"overall":report["overall"],"windows":windows,"selected":[{k:r[k]for k in ["task_sec","request_v","request_w","output","reason","yaw","direct_goal_bearing_error","body_margin_m","certificate_present"]}for r in selected],"model_failures":model_failures}))
