"""Metadata/helper tests only. No native, formal CLI or canonical archive execution."""
import copy
import gzip
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

SPEC = importlib.util.spec_from_file_location(
    'archive_helper', '/tmp/mr3_p2a0_v15_archive_closed_v1.py')
H = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(H)


class FinalStateTests(unittest.TestCase):
    def setUp(self):
        H.FREEZE = 'a' * 40
        H.PLAN_SHA = 'b' * 64
        self.plan = {'stages': []}
        self.values = {}
        for stage in H.STAGES:
            spec = {'stage': stage, 'run_directory': '/fake/run/' + stage,
                    'required_audit_receipts': ['/fake/' + stage + '.json']}
            self.plan['stages'].append(spec)
            self.values[str(self.path(stage, 'launch.json'))] = dict(
                status='completed', freeze=H.FREEZE, plan_sha256=H.PLAN_SHA, passed=True)
            self.values[str(self.path(stage, 'audit_execution_v1.json'))] = dict(
                freeze=H.FREEZE, plan_sha256=H.PLAN_SHA, all_submitted_jobs_finished=True,
                passed=True, receipts=[dict(path=spec['required_audit_receipts'][0])])

    def path(self, stage, suffix):
        return H.TEMP / (H.PREFIX + '_' + stage + '_' + suffix)

    def load(self, path):
        return copy.deepcopy(self.values[str(path)])

    def exists(self, path):
        return str(path) in self.values

    def validate(self, mode='complete', stop=None):
        return H.validate_final_states(self.plan, mode, stop, self.load, self.exists)

    def stopped(self):
        for stage in H.STAGES[2:]:
            self.values.pop(str(self.path(stage, 'launch.json')))
            self.values.pop(str(self.path(stage, 'audit_execution_v1.json')))
        self.values[str(self.path('terminal', 'audit_execution_v1.json'))]['passed'] = False

    def test_complete_all_four(self):
        self.assertEqual([r['status'] for r in self.validate()], ['PASS'] * 4)

    def test_stopped_keeps_real_fail_and_skips(self):
        self.stopped()
        self.assertEqual([r['status'] for r in self.validate('stopped', 'terminal')],
                         ['PASS', 'FAIL', 'SKIPPED_after_terminal_failure',
                          'SKIPPED_after_terminal_failure'])

    def test_interface_failure_preserves_failed_launch_and_real_skips(self):
        for stage in H.STAGES[1:]:
            self.values.pop(str(self.path(stage, 'launch.json')))
            self.values.pop(str(self.path(stage, 'audit_execution_v1.json')))
        launch = self.values[str(self.path('interface', 'launch.json'))]
        launch.update(status='failed', passed=False)
        self.values[str(self.path('interface', 'audit_execution_v1.json'))]['passed'] = False
        result = self.validate('stopped', 'interface')
        self.assertEqual([r['status'] for r in result],
                         ['FAIL'] + ['SKIPPED_after_interface_failure'] * 3)
        self.assertEqual(result[0]['launch']['status'], 'failed')
        self.assertIs(result[0]['launch']['passed'], False)
        with self.assertRaises(AssertionError):
            self.validate()

    def test_live_and_unfinished_jobs_rejected(self):
        for key, value in [('status', 'running'), ('passed', None)]:
            with self.subTest(key=key):
                original = self.values[str(self.path('reset', 'launch.json'))].copy()
                self.values[str(self.path('reset', 'launch.json'))][key] = value
                with self.assertRaises(AssertionError):
                    self.validate()
                self.values[str(self.path('reset', 'launch.json'))] = original
        self.values[str(self.path('reset', 'audit_execution_v1.json'))][
            'all_submitted_jobs_finished'] = False
        with self.assertRaises(AssertionError):
            self.validate()

    def test_failed_stage_never_complete(self):
        self.values[str(self.path('terminal', 'audit_execution_v1.json'))]['passed'] = False
        with self.assertRaises(AssertionError):
            self.validate()

    def test_earlier_fail_and_fake_stop_rejected(self):
        self.stopped()
        self.values[str(self.path('interface', 'launch.json'))]['passed'] = False
        with self.assertRaises(AssertionError):
            self.validate('stopped', 'terminal')
        self.values[str(self.path('interface', 'launch.json'))]['passed'] = True
        self.values[str(self.path('terminal', 'audit_execution_v1.json'))]['passed'] = True
        with self.assertRaises(AssertionError):
            self.validate('stopped', 'terminal')

    def test_later_run_receipt_or_pack_not_hidden(self):
        self.stopped()
        for path in [self.path('reset', 'launch.json'), Path('/fake/run/reset'),
                     H.TEMP / (H.PREFIX + '_selected_native/reset')]:
            with self.subTest(path=str(path)):
                self.values[str(path)] = {}
                with self.assertRaises(AssertionError):
                    self.validate('stopped', 'terminal')
                self.values.pop(str(path))

    def test_freeze_plan_and_exact_mandatory_set_rejected(self):
        for key in ['freeze', 'plan_sha256', 'receipts']:
            original = self.values[str(self.path('reset', 'audit_execution_v1.json'))].copy()
            self.values[str(self.path('reset', 'audit_execution_v1.json'))][key] = (
                [] if key == 'receipts' else 'bad')
            with self.assertRaises(AssertionError):
                self.validate()
            self.values[str(self.path('reset', 'audit_execution_v1.json'))] = original

    def test_safe_paths_and_exclusive_outputs(self):
        for value in ('../escape', '/absolute'):
            with self.assertRaises(ValueError):
                H.safe_relative(value)
        with tempfile.TemporaryDirectory(prefix='mr3_v15_archive_metadata_test_') as tmp:
            path = Path(tmp) / 'new.json'
            H.new_json(path, {'original': True})
            with self.assertRaises(FileExistsError):
                H.new_json(path, {'replacement': True})
            self.assertEqual(H.read(path), {'original': True})


class PreflightBindingTests(unittest.TestCase):
    def setUp(self):
        self.plan = dict(schema='mr3-p2a0-predeclaration-v15',
                         readiness=dict(status='ready', pending_bindings=[]),
                         stages=[dict(stage=stage) for stage in H.STAGES],
                         independent_source_bindings=[dict(path='actual/new.py', sha256='c' * 64)])
        self.raw = json.dumps(self.plan).encode()
        self.preflight = dict(passed=True, freeze='d' * 40, plan_sha256=H.sha(self.raw),
                              independent_source_bindings=self.plan['independent_source_bindings'])

    def test_actual_freeze_and_plan_are_dynamic(self):
        freeze, digest, plan = H.bind_preflight(self.preflight, self.raw, self.raw)
        self.assertEqual(freeze, 'd' * 40)
        self.assertEqual(digest, H.sha(self.raw))
        self.assertEqual(plan, self.plan)

    def test_bad_freeze_pass_source_or_independent_binding_rejected(self):
        for field, value in [('freeze', 'historical'), ('freeze', True), ('passed', False),
                             ('passed', 1), ('plan_sha256', '0' * 64),
                             ('independent_source_bindings', [])]:
            with self.subTest(field=field, value=value):
                bad = copy.deepcopy(self.preflight)
                bad[field] = value
                with self.assertRaises(AssertionError):
                    H.bind_preflight(bad, self.raw, self.raw)
        with self.assertRaises(AssertionError):
            H.bind_preflight(self.preflight, self.raw, self.raw + b' ')

    def test_pending_plan_cannot_be_used(self):
        self.plan['readiness']['pending_bindings'] = ['approval']
        raw = json.dumps(self.plan).encode()
        self.preflight['plan_sha256'] = H.sha(raw)
        with self.assertRaises(AssertionError):
            H.bind_preflight(self.preflight, raw, raw)

    def test_new_101_sources_and_121_independent_bindings_are_not_old_counts(self):
        self.plan['independent_source_bindings'] = [
            dict(path='source' + str(index), sha256='c' * 64) for index in range(121)]
        raw = json.dumps(self.plan).encode()
        self.preflight.update(plan_sha256=H.sha(raw),
                              independent_source_bindings=self.plan['independent_source_bindings'])
        self.assertEqual(len(H.bind_preflight(self.preflight, raw, raw)[2][
            'independent_source_bindings']), 121)
        expected = {'old/' + str(index) for index in range(100)} | {'current/profile.xml'}
        preflight = dict(source_bindings={path: {} for path in expected})
        proof = dict(files=[dict(path=path) for path in expected])
        self.assertEqual(len(H.verify_sourcepack_paths(preflight, proof, expected)), 101)
        preflight['source_bindings'].pop('current/profile.xml')
        with self.assertRaises(AssertionError):
            H.verify_sourcepack_paths(preflight, proof, expected)
        bad = copy.deepcopy(self.preflight)
        bad['independent_source_bindings'] = bad['independent_source_bindings'][:96]
        with self.assertRaises(AssertionError):
            H.bind_preflight(bad, raw, raw)

    def test_sourcepack_duplicate_or_missing_file_cannot_have_credit(self):
        expected = {'runtime/one', 'runtime/two'}
        preflight = dict(source_bindings={path: {} for path in expected})
        for values in [['runtime/one'], ['runtime/one', 'runtime/one'],
                       ['runtime/one', 'runtime/two', 'runtime/one']]:
            with self.subTest(values=values), self.assertRaises(AssertionError):
                H.verify_sourcepack_paths(preflight, dict(files=[dict(path=v) for v in values]),
                                          expected)

    def test_closed_old_git_source_does_not_become_later_authorized_worktree(self):
        with tempfile.TemporaryDirectory(prefix='mr3_v15_closed_old_git_test_') as tmp:
            root = Path(tmp)
            frozen = b'old actual frozen source\n'
            (root / 'source.py').write_bytes(b'new authorized post-native source\n')
            bindings = [dict(path='source.py', sha256=H.sha(frozen))]
            with patch.object(H, 'ROOT', root), patch.object(H, 'git_bytes', return_value=frozen):
                current = H.verify_independent_git_bindings(bindings)
                self.assertIs(current[0]['equals_frozen_git'], False)
                self.assertEqual(current[0]['current_sha256'], H.sha(
                    (root / 'source.py').read_bytes()))
            with patch.object(H, 'ROOT', root), patch.object(H, 'git_bytes', return_value=b'bad'):
                with self.assertRaises(AssertionError):
                    H.verify_independent_git_bindings(bindings)


class DeduplicationTests(unittest.TestCase):
    def test_only_exact_canonical_raw_bytes_are_reused(self):
        with tempfile.TemporaryDirectory(prefix='mr3_v15_archive_dedup_test_') as tmp:
            root = Path(tmp)
            source, selected, manifest = root / 'raw.py', root / 'old.py.gz', root / 'manifest.json'
            raw = b'actual original bytes\n'
            selected.write_bytes(gzip.compress(raw, mtime=0))
            index = {str(source): [dict(selected=selected, raw_sha256=H.sha(raw),
                                        manifest=manifest)]}
            with patch.object(H, 'ROOT', root):
                found = H.canonical_duplicate(source, raw, index)
                self.assertEqual(found['canonical_path'], 'old.py.gz')
                self.assertIsNone(H.canonical_duplicate(source, raw + b'changed', index))
                selected.write_bytes(gzip.compress(raw + b'corrupted', mtime=0))
                with self.assertRaises(AssertionError):
                    H.canonical_duplicate(source, raw, index)

    def test_identity_gzip_is_original_encoded_bytes_not_its_inner_payload(self):
        with tempfile.TemporaryDirectory(prefix='mr3_v15_archive_identity_test_') as tmp:
            root = Path(tmp)
            source, selected = root / 'raw.jsonl.gz', root / 'selected.jsonl.gz'
            raw = gzip.compress(b'inner original\n', mtime=0)
            selected.write_bytes(raw)
            index = {str(source): [dict(selected=selected, raw_sha256=H.sha(raw),
                                        manifest=root / 'manifest.json', encoding='identity',
                                        selected_sha256=H.sha(raw))]}
            with patch.object(H, 'ROOT', root):
                found = H.canonical_duplicate(source, raw, index)
                self.assertEqual(found['canonical_encoded_sha256'], H.sha(raw))
                self.assertIsNone(H.canonical_duplicate(source, gzip.decompress(raw), index))

    def test_current_offline_manifest_keeps_old_a13_identity_mapping(self):
        with tempfile.TemporaryDirectory(prefix='mr3_v15_archive_index_test_') as tmp:
            root = Path(tmp)
            asset = root / 'a14'
            directory = asset / 'independent/offline_originals_v1'
            directory.mkdir(parents=True)
            prior = root / 'a13/manifest.json'
            prior.parent.mkdir()
            prior.write_text('{}')
            selected = root / 'a13/selected.gz'
            raw = gzip.compress(b'old encoded original', mtime=0)
            selected.write_bytes(raw)
            source = root / 'new-prefix-original.gz'
            value = dict(entries=[], deduplicated_A13=[dict(
                source=str(source), raw_sha256=H.sha(raw), already_A13=dict(
                    manifest=str(prior), manifest_sha256=H.sha(prior.read_bytes()),
                    selected=str(selected), selected_encoded_sha256=H.sha(raw),
                    encoding='identity'))])
            (directory / 'manifest.json').write_text(json.dumps(value))
            with patch.object(H, 'ROOT', root), patch.object(H, 'A', asset):
                index = H.prior_original_index()
                self.assertIsNotNone(H.canonical_duplicate(source, raw, index))
                prior.write_text('{"changed":true}')
                with self.assertRaises(AssertionError):
                    H.prior_original_index()

    def test_mutable_root_state_and_self_active_output_are_excluded(self):
        with tempfile.TemporaryDirectory(prefix='mr3_v15_archive_exclude_test_') as tmp:
            root = Path(tmp)
            names = [H.PREFIX + '_root_continuation_state_v1.json',
                     H.PREFIX + '_active_state.json', H.PREFIX + '_closed_archive_publish_v1.log']
            for name in names:
                (root / name).write_bytes(b'currently mutable')
            with patch.object(H, 'TEMP', root):
                included, excluded = H.support_paths([])
            self.assertFalse({root / name for name in names}.intersection(included))
            self.assertEqual({row['path'] for row in excluded}, {str(root / n) for n in names})


class V15CustodyRegressionTests(unittest.TestCase):
    def test_new_prior_mapping_reuses_exact_identity_gzip(self):
        with tempfile.TemporaryDirectory(prefix='mr3_v15_archive_prior_test_') as tmp:
            root = Path(tmp)
            asset = root / 'a15'
            directory = asset / 'independent/offline_originals_v1'
            directory.mkdir(parents=True)
            prior = root / 'a14/manifest.json'
            prior.parent.mkdir()
            prior.write_text('{}')
            selected = prior.parent / 'identity.gz'
            raw = gzip.compress(b'encoded original', mtime=0)
            selected.write_bytes(raw)
            source = root / 'same-raw.gz'
            value = dict(entries=[], deduplicated_prior=[dict(
                source=str(source), raw_sha256=H.sha(raw), already_canonical=dict(
                    manifest=str(prior), manifest_sha256=H.sha(prior.read_bytes()),
                    selected=str(selected), selected_encoded_sha256=H.sha(raw),
                    encoding='identity'))])
            (directory / 'manifest.json').write_text(json.dumps(value))
            with patch.object(H, 'ROOT', root), patch.object(H, 'A', asset):
                index = H.prior_original_index()
                self.assertIsNotNone(H.canonical_duplicate(source, raw, index))
                self.assertIsNone(H.canonical_duplicate(source, gzip.decompress(raw), index))
                selected.write_bytes(gzip.compress(b'changed', mtime=0))
                with self.assertRaises(AssertionError):
                    H.canonical_duplicate(source, raw, index)

    def test_mock_leaf_exclusion_keeps_actual_invocation_and_error_console(self):
        with tempfile.TemporaryDirectory(prefix='mr3_v15_archive_policy_test_') as tmp:
            root = Path(tmp)
            top = root / (H.PREFIX + '_tests')
            runtime = top / 'fixtures/case/runtime'
            runtime.mkdir(parents=True)
            keep = runtime / (H.PREFIX + '_interface_controller_launch.log')
            keep.write_text('actual fakeCLI error retained')
            omit = runtime / 'fake_actual.json'
            omit.write_text('{}')
            mock = top / 'fake_assets/source.py'
            mock.parent.mkdir()
            mock.write_text('fake source')
            (root / (H.PREFIX + '_old_symlink')).symlink_to(top, target_is_directory=True)
            with patch.object(H, 'TEMP', root):
                included, excluded = H.support_paths([])
            self.assertIn(keep, included)
            self.assertNotIn(omit, included)
            self.assertNotIn(mock, included)
            self.assertIn('symlink_tree_not_followed', {r['reason'] for r in excluded})

    def test_stable_read_rejects_real_inode_swap_and_symlink(self):
        with tempfile.TemporaryDirectory(prefix='mr3_v15_archive_fd_test_') as tmp:
            root = Path(tmp)
            path, replacement = root / 'source.json', root / 'replacement.json'
            path.write_bytes(b'original')
            replacement.write_bytes(b'replacement')
            original_open = Path.open

            class ReplacingReader:
                def __enter__(self):
                    self.stream = original_open(path, 'rb')
                    return self

                def fileno(self):
                    return self.stream.fileno()

                def read(self):
                    data = self.stream.read()
                    replacement.replace(path)
                    return data

                def __exit__(self, *args):
                    self.stream.close()

            def swapped_open(target, *args, **kwargs):
                return ReplacingReader() if target == path else original_open(
                    target, *args, **kwargs)

            with patch.object(Path, 'open', swapped_open):
                with self.assertRaises(AssertionError):
                    H.stable(path)
            self.assertEqual(path.read_bytes(), b'replacement')
            link = root / 'link.json'
            link.symlink_to(path)
            with self.assertRaises(AssertionError):
                H.stable(link)


if __name__ == '__main__':
    unittest.main(verbosity=2)
