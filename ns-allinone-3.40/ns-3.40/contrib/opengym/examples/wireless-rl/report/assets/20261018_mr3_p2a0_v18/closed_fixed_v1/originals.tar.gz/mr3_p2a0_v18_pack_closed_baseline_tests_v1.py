#!/usr/bin/env python3
"""Tiny CPU codec fixtures, never edits or scans native evidence."""
import gzip
import importlib.util
import json
from pathlib import Path
import tempfile

PATH = Path('/tmp/mr3_p2a0_v18_pack_closed_baseline_v1.py')
spec = importlib.util.spec_from_file_location('custody_candidate', PATH)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)


def main():
    with tempfile.TemporaryDirectory(prefix='mr3_p2a0_v18_custody_cpu_') as name:
        root = Path(name)
        source = root / 'source'
        target = root / 'selected'
        source.mkdir()
        target.mkdir()
        empty = source / 'empty'
        empty.write_bytes(b'')
        original_gzip = source / 'already.gz'
        original_gzip.write_bytes(gzip.compress(b'original raw gzip wrapper retained', mtime=17))
        large = source / 'large'
        with large.open('wb') as stream:
            for _ in range(32):
                stream.write(b'x' * helper.COPY_BYTES)
            stream.write(b'final123bytes' + b'y' * 110)
        rows = []
        for index, path in enumerate((empty, original_gzip, large)):
            rows.append(helper.pack_file(index, path, source, target,
                helper.identity(path.stat()), 'prospective/native/baseline'))
        assert rows[0]['empty_original'] and len(rows[0]['parts']) == 1
        assert rows[0]['parts'][0]['selected_bytes'] > 0
        outer_decoded = gzip.decompress((target / rows[1]['parts'][0]['selected']).read_bytes())
        assert outer_decoded == original_gzip.read_bytes()
        assert gzip.decompress(outer_decoded) == b'original raw gzip wrapper retained'
        assert len(rows[2]['parts']) == 2
        assert rows[2]['parts'][0]['raw_bytes'] == helper.RAW_CHUNK_BYTES
        assert rows[2]['parts'][1]['raw_offset'] == helper.RAW_CHUNK_BYTES
        assert rows[2]['verification']['decoded_bytes'] == large.stat().st_size
        corrupted = target / rows[2]['parts'][1]['selected']
        raw = corrupted.read_bytes()
        corrupted.write_bytes(raw[:-1] + bytes([raw[-1] ^ 1]))
        try:
            helper.verify_file(rows[2], target)
        except AssertionError:
            pass
        else:
            raise AssertionError('encoded-byte mutation accepted')
        print(json.dumps({'passed': True, 'groups': 4,
            'checks': ['empty file retained', 'original.gz exact original bytes retained',
                       'fixed32MiB chunk offsets and exact full reconstruction',
                       'encoded mutation rejected'],
            'scope': 'CPU serialization fixtures only; no native/formal source or evidence altered'}))


if __name__ == '__main__':
    main()
