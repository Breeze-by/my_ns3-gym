// Actual shared-object factory type, without calling Load or initializing Gazebo.
#include <gazebo/common/Plugin.hh>
#include <cassert>
#include <dlfcn.h>
#include <iostream>
#include <memory>
#include <stdexcept>

int main(int argc, char **argv) {
  if (argc != 2) throw std::runtime_error("one actual SDK library path required");
  void *handle = dlopen(argv[1], RTLD_NOW | RTLD_LOCAL);
  if (!handle) throw std::runtime_error(dlerror());
  auto factory = reinterpret_cast<gazebo::SensorPlugin *(*)()>(dlsym(handle, "RegisterPlugin"));
  if (!factory) throw std::runtime_error("RegisterPlugin unavailable");
  std::unique_ptr<gazebo::SensorPlugin> plugin(factory());
  assert(plugin && plugin->GetType() == gazebo::SENSOR_PLUGIN);
  plugin.reset();
  assert(dlclose(handle) == 0);
  std::cout << "PASS actual .so RegisterPlugin GetType==SENSOR_PLUGIN; no Load/ROS/Gazebo initialization\n";
}
