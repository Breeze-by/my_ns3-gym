"""CPU CDR/queue tests; no rclpy.init, DDS, Gazebo, native launch or control."""
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

from dwb_msgs.msg import LocalPlanEvaluation, TrajectoryScore
from geometry_msgs.msg import PoseStamped, Twist
from nav_msgs.msg import Path as ROSPath
from rclpy.serialization import deserialize_message

SPEC = importlib.util.spec_from_file_location(
    'navigation_archive_draft', '/tmp/mr3_p2a0_v13_native_navigation_archive_draft_v1.py')
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)


class FakeNode:
    def get_publishers_info_by_topic(self, topic):
        return []


class CDRTests(unittest.TestCase):
    def test_twist_frozen_headerless_dedup(self):
        with tempfile.TemporaryDirectory(prefix='mr3_v13_archive_cpu_') as directory:
            clock = [100]
            errors = []
            archive = M.NativeNavigationArchive(FakeNode(), directory, 'epoch',
                                                lambda: clock[0], errors.append)
            message = Twist()
            message.linear.x = .1
            message.angular.z = -.2
            archive.record('tb2', '/tb2/cmd_vel_nav', 'geometry_msgs/msg/Twist', message)
            message.linear.x = 9.
            clock[0] = 200
            duplicate = Twist()
            duplicate.linear.x = .1
            duplicate.angular.z = -.2
            archive.record('tb2', '/tb2/cmd_vel_nav', 'geometry_msgs/msg/Twist', duplicate)
            archive.close()
            self.assertEqual(errors, [])
            rows = [json.loads(s) for s in (Path(directory) / 'native_navigation.jsonl')
                    .read_text().splitlines()]
            self.assertEqual([r['received_clock_ns'] for r in rows], [100, 200])
            self.assertEqual([r['topic_sequence'] for r in rows], [1, 2])
            self.assertEqual(rows[0]['payload_sha256'], rows[1]['payload_sha256'])
            self.assertIsNone(rows[0]['source_header'])
            self.assertIn('receipt_time_only', rows[0]['source_time_scope'])
            self.assertEqual(len(list(Path(directory).rglob('*.cdr.gz'))), 1)
            raw = gzip.decompress((Path(directory) / rows[0]['artifact']).read_bytes())
            self.assertEqual(hashlib.sha256(raw).hexdigest(), rows[0]['payload_sha256'])
            self.assertEqual(deserialize_message(raw, Twist).linear.x, .1)

    def test_path_and_evaluation_headers_and_full_fields(self):
        with tempfile.TemporaryDirectory(prefix='mr3_v13_archive_cpu_') as directory:
            archive = M.NativeNavigationArchive(FakeNode(), directory, 'epoch',
                                                lambda: 999, self.fail)
            path = ROSPath()
            path.header.frame_id = 'map'
            path.header.stamp.sec = 12
            path.header.stamp.nanosec = 345
            pose = PoseStamped()
            pose.pose.position.x = 1.23
            path.poses = [pose]
            archive.record('tb1', '/tb1/received_global_plan', 'nav_msgs/msg/Path', path)
            evaluation = LocalPlanEvaluation()
            evaluation.header.frame_id = 'odom'
            evaluation.header.stamp.sec = 13
            score = TrajectoryScore()
            score.traj.velocity.x = .123
            score.total = 4.5
            evaluation.twists = [score]
            evaluation.best_index = 0
            archive.record('tb1', '/tb1/evaluation', 'dwb_msgs/msg/LocalPlanEvaluation',
                           evaluation)
            path.poses[0].pose.position.x = 888.
            evaluation.twists.clear()
            archive.close()
            rows = [json.loads(s) for s in (Path(directory) / 'native_navigation.jsonl')
                    .read_text().splitlines()]
            for row, kind in zip(rows, (ROSPath, LocalPlanEvaluation)):
                raw = gzip.decompress((Path(directory) / row['artifact']).read_bytes())
                original = deserialize_message(raw, kind)
                self.assertEqual(original.header.frame_id, row['source_header']['frame_id'])
                if kind is ROSPath:
                    self.assertEqual(original.poses[0].pose.position.x, 1.23)
                    self.assertEqual(row['source_header']['stamp']['nanosec'], 345)
                else:
                    self.assertEqual(len(original.twists), 1)
                    self.assertEqual(original.twists[0].traj.velocity.x, .123)

    def test_overflow_is_explicit_never_silent(self):
        with tempfile.TemporaryDirectory(prefix='mr3_v13_archive_cpu_') as directory:
            archive = M.NativeNavigationArchive(FakeNode(), directory, 'epoch',
                                                lambda: 0, self.fail, max_pending_bytes=1)
            with self.assertRaisesRegex(RuntimeError, 'overflow'):
                archive.record('tb1', '/tb1/cmd_vel_nav', 'geometry_msgs/msg/Twist', Twist())
            archive.close()
            self.assertEqual((Path(directory) / 'native_navigation.jsonl').read_text(), '')


if __name__ == '__main__':
    unittest.main(verbosity=2)
