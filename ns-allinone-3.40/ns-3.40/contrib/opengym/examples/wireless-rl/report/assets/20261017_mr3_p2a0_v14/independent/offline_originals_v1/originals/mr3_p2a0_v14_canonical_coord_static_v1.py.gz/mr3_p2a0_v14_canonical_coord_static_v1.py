"""Static path-only/adapter provenance checks for V14 drafts, no source imports."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A13 = W / 'report/assets/20261017_mr3_p2a0_v13'
A14 = W / 'report/assets/20261017_mr3_p2a0_v14'
DRAFT = A14


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def dump(source):
    return ast.dump(ast.parse(source), include_attributes=False)


def main():
    old_plan = json.loads((A13 / 'predeclared_plan_v13.json').read_bytes())
    plan = json.loads((DRAFT / 'predeclared_plan_v14.json').read_bytes())
    bindings = plan['independent_source_bindings']
    old_bindings = {r['path']: r['sha256'] for r in old_plan['independent_source_bindings']}
    current_bindings = {r['path']: r['sha256'] for r in bindings}
    changed = [k for k in old_bindings if old_bindings[k] != current_bindings[k]]
    assert sorted(changed) == sorted(str((W / 'mr3_learning' / n).relative_to(ROOT)) for n in (
        'audit_ppo.py', 'tests/test_audit_ppo.py'))
    assert all(k in current_bindings for k in old_bindings)
    assert len(bindings) == len({b['path'] for b in bindings}) == 105
    for row in bindings:
        path = ROOT / row['path']
        if path.is_relative_to(A14):
            path = DRAFT / path.relative_to(A14)
        assert sha(path.read_bytes()) == row['sha256']
    for key in ('unchanged_gates', 'pilot_budget_unchanged', 'max_api_records',
                'max_submitted_script_decisions', 'max_total_wall_seconds',
                'physical_response_criteria', 'angular_interface_criteria',
                'angular_reset_criteria', 'settled_turn_criteria'):
        assert plan[key] == old_plan[key], key
    assert plan['readiness']['status'] in ('draft_pending_root_final_review', 'ready')
    preserved = {}
    pairs = [
        ('mr3_p2a0_v13_launch_stage.py', 'literal version/path only'),
        ('mr3_p2a0_v13_audit_stage.py', 'reuse original A13 drivev6'),
        ('mr3_p2a0_v13_buildproof_preflight.py', 'reuse original A13 Shim monitor'),
        ('mr3_p2a0_v13_cross_stage_mapping_monitor_v1.py', 'reuse original A13 observer/binding'),
        ('mr3_v13_multiepoch_closure_binary_review_v1.py', 'checked immutable reader/path adapter'),
    ]
    for old_name, scope in pairs:
        new_name = old_name.replace('v13', 'v14')
        old_raw = (A13 / 'independent' / old_name).read_text()
        current = (DRAFT / 'independent' / new_name).read_text()
        restored = current.replace('v14', 'v13').replace('V14', 'V13')
        if 'audit_stage' in old_name:
            # All references become old version on reverse rename already.
            pass
        elif 'buildproof_preflight' in old_name:
            old_tree, new_tree = ast.parse(old_raw), ast.parse(restored)
            old_function = next(n for n in old_tree.body if isinstance(n, ast.FunctionDef)
                                and n.name == 'check_shim')
            new_tree.body = [copy.deepcopy(old_function) if isinstance(n, ast.FunctionDef)
                             and n.name == 'check_shim' else n for n in new_tree.body]
            restored = ast.unparse(new_tree)
        elif 'cross_stage' in old_name:
            restored = restored.replace(
                "OBSERVER=ROOT/'" + str((A13 / 'independent/'
                    'mr3_readonly_v13_drive_shim_process_monitor_v2.py').relative_to(ROOT)) + "'",
                "OBSERVER=Path(__file__).with_name('mr3_readonly_v13_drive_shim_process_monitor_v2.py')")
            restored = restored.replace(
                "SHIM_BINDING=ROOT/'" + str((A13 / 'independent/'
                    'mr3_v13_shim_binding_v1.json').relative_to(ROOT)) + "'",
                "SHIM_BINDING=Path(__file__).with_name('mr3_v13_shim_binding_v1.json')")
        elif 'closure' in old_name:
            tree = ast.parse(restored)
            tree.body = [n for n in tree.body if not isinstance(n, ast.FunctionDef) or
                         n.name not in ('load_checked_shim', 'call_shim_review')]
            old_tree = ast.parse(old_raw)
            old_main = next(n for n in old_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
            new_main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
            start = next(i for i, n in enumerate(old_main.body) if isinstance(n, ast.Assign)
                         and any(isinstance(t, ast.Name) and t.id == 'supplement_path' for t in n.targets))
            index = next(i for i, n in enumerate(new_main.body) if isinstance(n, ast.Assign)
                         and isinstance(n.value, ast.Call) and isinstance(n.value.func, ast.Name)
                         and n.value.func.id == 'load_checked_shim')
            new_main.body[index:index + 1] = copy.deepcopy(old_main.body[start:start + 5])
            for n in ast.walk(new_main):
                if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'call_shim_review':
                    n.func = ast.Attribute(value=ast.Name(id='supplement', ctx=ast.Load()),
                                           attr='review', ctx=ast.Load())
                    n.args = n.args[1:]
            restored = ast.unparse(tree)
        assert dump(restored) == dump(old_raw), old_name
        preserved[new_name] = {'old_source_sha256': sha(old_raw.encode()),
                               'draft_sha256': sha(current.encode()),
                               'old_AST_after_reversing_only_declared_changes': True,
                               'declared_change': scope}
    assert plan['drive_contract']['binary_build_receipt'] == old_plan['drive_contract']['binary_build_receipt']
    assert plan['drive_command_cap_audit'] == old_plan['drive_command_cap_audit']
    for key in ('binding', 'monitor', 'supplement_consumer'):
        assert plan['shim_runtime_custody'][key] == old_plan['shim_runtime_custody'][key]
    for prior, current in zip(old_plan['stages'], plan['stages']):
        assert current['command'] == [v.replace('mr3_p2a0_20261017_v13_', 'mr3_p2a0_20261017_v14_')
                                      for v in prior['command']]
        assert current['worker_bindings'] == prior['worker_bindings']
        assert current['wall_ceiling_seconds'] == prior['wall_ceiling_seconds']
    xml_path = ROOT / ('ros2_ws/ros2-multi-robot-automap/src/multi_robot/config/'
                       'mr3_fastdds_loopback_udp.xml')
    xml_relative = str(xml_path.relative_to(ROOT))
    old_xml = subprocess.check_output(['git', 'show', '60f932ed:' + xml_relative], cwd=ROOT)
    old_tree, new_tree = ET.fromstring(old_xml), ET.fromstring(xml_path.read_bytes())

    def form(node):
        return (node.tag, tuple(sorted(node.attrib.items())), (node.text or '').strip(),
                tuple(form(child) for child in node))

    names = {'rr/' + robot + '/' + kind + '/get_parametersReply'
             for robot in ('tb1', 'tb2', 'tb3')
             for kind in ('controller_server', 'behavior_server', 'velocity_smoother')}
    new_profiles = []
    for parent in new_tree.iter():
        for node in list(parent):
            if node.tag.rsplit('}', 1)[-1] == 'publisher' and node.attrib.get('profile_name') in names:
                new_profiles.append(node)
                parent.remove(node)
    assert len(new_profiles) == 9 and {n.attrib['profile_name'] for n in new_profiles} == names
    assert form(old_tree) == form(new_tree), 'old36 XML profiles/transport changed'
    for node in new_profiles:
        elements = {n.tag.rsplit('}', 1)[-1]: (n.text or '').strip() for n in node.iter()}
        assert elements['kind'] == 'RELIABLE' and elements['sec'] == '1' and elements['nanosec'] == '0'

    audit_path = W / 'mr3_learning/audit_ppo.py'
    audit_tree = ast.parse(audit_path.read_bytes())
    assignments = {node.targets[0].id: node.value for node in audit_tree.body
                   if isinstance(node, ast.Assign) and len(node.targets) == 1
                   and isinstance(node.targets[0], ast.Name)}
    ros_prefix = 'ros2_ws/ros2-multi-robot-automap/'

    def value(node):
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Name) and node.id == 'ROS':
            return ros_prefix
        if isinstance(node, ast.Name) and node.id == 'WIRELESS':
            return str(W.relative_to(ROOT)) + '/'
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
            return value(node.left) + value(node.right)
        raise ValueError('nonliteral execution pin')

    pins = {}
    for name in ('EVALUATOR_PHASE_PINS', 'PREPARATION_RUNTIME_PINS', 'EXECUTION_CONFIG_PINS'):
        entries = assignments[name]
        pins.update({value(k): value(v) for k, v in zip(entries.keys, entries.values)})
    assert len(pins) == 36
    for relative, expected in pins.items():
        assert sha((ROOT / relative).read_bytes()) == expected, 'current runtime pin differs: ' + relative
    preparation = assignments['PREPARATION_RUNTIME_PINS']
    assert xml_relative in {value(k) for k in preparation.keys}, 'XML missing preparation pin'
    assert pins[xml_relative] == sha(xml_path.read_bytes()), 'direct current XML pin absent/stale'
    assert value(assignments['ENV_DOCUMENT_SHA256']) == sha((W / 'MR3_ENV_CONTRACT.md').read_bytes())
    sources = {str(path): {'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())}
               for path in sorted(DRAFT.rglob('*')) if path.is_file()}
    report = {'schema': 'mr3-v14-canonical-coordinator-static-v1', 'passed': True,
              'all94_A13_other_bindings_preserved': True,
              'only_authorized_current_audit_ppo_and_loader_test_bindings_refreshed': changed,
              'new_bindings': 9,
              'total_bindings': 105, 'orchestration_AST_review': preserved,
              'budgets_and_physics_angular_settled_gates_unchanged': True,
              'all4_stage_commands_equal_except_run_id': True,
              'A13_build_Drivev6_Shim_sources_reused_in_place': True,
              'only9_exact_reply_profiles_added': True, 'old36_profiles_transport_unchanged': True,
              'nine_response_writer_matching_seconds': 1, 'outer_client_guard_unchanged': 30,
              'direct_XML_preparation_runtime_pin_current': True, 'runtime_pin_count': 36,
              'ENV_digest_current': True,
              'readiness': plan['readiness'], 'source_bindings': sources,
              'scope': 'Canonical source/path static only; source readiness is decided by root, '
                       'exact clean pushed freeze/preflight and all native gates remain required.'}
    Path('/tmp/mr3_p2a0_v14_canonical_coord_static_v1.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'passed': True, 'AST_sources': len(preserved), 'bindings': len(bindings), 'readiness': plan['readiness']['status']}))


if __name__ == '__main__':
    main()
