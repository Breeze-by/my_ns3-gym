"""Canonical-ready test sources only; never install them or run a World."""
import ast
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=Path('/home/zhuyulab/ns3-workspace')
ROS_TEST=Path('ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/test')
W_TEST=Path('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/mr3_learning/tests')
OUT=HERE/'canonical_tests_v1'
files={}

callback=(HERE/'test_motion_authority_ros_wrapper_v2.py').read_text()
start=callback.index("ROOT=Path('/home/zhuyulab/ns3-workspace')")
end=callback.index('from multi_robot_exploration import mr3_adapter as adapter')
callback=callback[:start]+'''# Official ROS setup supplies the installed canonical package. No shadow path.
HERE=Path(__file__).resolve().parent
COMP=HERE.parent
ROOT=COMP.parents[3]
'''+callback[end:]
callback=callback.replace("COMP/'test/test_mr3_reach_runtime_independent.py'","HERE/'test_mr3_reach_runtime_independent.py'")
callback=callback.replace('SHADOW=HERE/\'shadow\'/COMP.relative_to(ROOT)/\'multi_robot_exploration\'\n','')
files[ROS_TEST/'test_mr3_motion_authority_callbacks.py']=callback

metadata=(HERE/'test_authority_metadata_entry_v1.py').read_text()
start=metadata.index("ROOT=Path('/home/zhuyulab/ns3-workspace')")
end=metadata.index('from mr3_learning import motion_authority_profile as profiles')
metadata=metadata[:start]+metadata[end:]
start=metadata.index('sup.WORKSPACE=ROOT\n')
end=metadata.index('\n\nclass AdmissionReached')
metadata=metadata[:start]+'''# These are ordinary installed/source-package imports, never /tmp candidates.
ROOT=sup.WORKSPACE
W=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
PROFILE=profiles.MOTION_AUTHORITY_PROFILE
assert Path(sup.__file__).resolve()==(W/'mr3_learning/supervisor.py').resolve()
assert Path(bench.__file__).resolve()==(W/'mr3_learning/benchmark.py').resolve()
assert Path(ppo.__file__).resolve()==(W/'mr3_learning/ppo.py').resolve()
'''+metadata[end:]
tree=ast.parse(metadata)
removed=set()
cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='MetadataEntryContracts')
for node in cls.body:
    if isinstance(node,ast.FunctionDef) and node.name in (
        'test_fixed_accessor_and_worker_typed_contract','test_worker_launch_metadata_uses_same_fixed_contract'):
        removed.update(range(node.lineno-1,node.end_lineno))
metadata='\n'.join(line for i,line in enumerate(metadata.splitlines()) if i not in removed)+'\n'
marker='    def test_supervisor_actual_reset_rpc_metadata_and_legacy_shape(self):\n'
assert metadata.count(marker)==1
metadata=metadata.replace(marker,marker+'''        self.assertIsNone(profiles.motion_authority_profile_for_safety_contract('legacy'))
        self.assertEqual(profiles.motion_authority_profile_for_safety_contract('mr3-reach-v1'),PROFILE)
        for bad in (True,None,1,[],{},'reach'):
            with self.assertRaises(ValueError):profiles.motion_authority_profile_for_safety_contract(bad)
''')
files[W_TEST/'test_motion_authority_metadata.py']=metadata

worker='''"""Actual canonical worker profile entry and metadata; no ROS graph/World."""
import ast
import copy
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace as NS
import unittest
from multi_robot_exploration.mr3_motion_authority import PROFILE

SCRIPTS=Path(__file__).resolve().parents[3]/'scripts'
sys.path.insert(0,str(SCRIPTS))
spec=importlib.util.spec_from_file_location('_mr3_authority_worker_canonical',SCRIPTS/'mr3_env_worker.py')
worker=importlib.util.module_from_spec(spec);spec.loader.exec_module(worker)
assert Path(worker.__file__).resolve()==(SCRIPTS/'mr3_env_worker.py').resolve()
worker_tree=ast.parse(Path(worker.__file__).read_text())

class WorkerProfileContracts(unittest.TestCase):
    def test_actual_request_helper_and_constructor_reject_mixed_profile_before_ROS_start(self):
        self.assertIsNone(worker.motion_authority_profile_from_request({}))
        self.assertIsNone(worker.motion_authority_profile_from_request({'safety_contract':'legacy','motion_authority_profile':None}))
        self.assertEqual(worker.motion_authority_profile_from_request({'safety_contract':'mr3-reach-v1','motion_authority_profile':PROFILE}),PROFILE)
        for contract,profile in (('legacy',PROFILE),('mr3-reach-v1',None),('mr3-reach-v1',True),
                                 ('mr3-reach-v1',''),('mr3-reach-v1','initial-zero-encoder-hold-v1')):
            request={'epoch':'artificial','scene':'open','seed':101,'safety_contract':contract,'motion_authority_profile':profile}
            with self.assertRaises(ValueError):worker.motion_authority_profile_from_request(request)
            with tempfile.TemporaryDirectory() as directory:
                with self.assertRaisesRegex(ValueError,'receiving-authority profile'):
                    worker.Worker(Path(directory),request)
        for contract in (True,None,[],{},1):
            with self.assertRaises(ValueError):worker.motion_authority_profile_from_request({'safety_contract':contract})

    def test_actual_constructor_launch_metadata_region_has_fixed_profile_no_extra_CLI(self):
        cls=next(n for n in worker_tree.body if isinstance(n,ast.ClassDef) and n.name=='Worker')
        init=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='__init__')
        start=next(i for i,n in enumerate(init.body) if isinstance(n,ast.Assign)
            and any(isinstance(t,ast.Attribute) and t.attr=='command' for t in n.targets))
        end=next(i for i,n in enumerate(init.body) if i>start and isinstance(n,ast.Expr)
            and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute)
            and n.value.func.attr=='write_text')
        # Exact actual constructor source; only graph/process initialization is
        # excluded. This does not claim that the full worker actually launched.
        for contract in ('legacy','mr3-reach-v1'):
            with tempfile.TemporaryDirectory() as temporary:
                directory=Path(temporary)
                shell=NS(epoch='artificial_epoch',scene='open',seed=101,safety_contract=contract,
                    motion_authority_profile=PROFILE if contract=='mr3-reach-v1' else None,
                    reach_geometry_rule='binary-cone-v1',seed_rule='legacy',start_graph_rule='original-seed-cell',
                    preparation_probe_version=None,terminal_probe=False,plant_stimulus_arm=None,
                    plant_stimulus_work_deadline_ns=None,transport_environment={},
                    control_version=2 if contract=='mr3-reach-v1' else 1,
                    startup_readiness_protocol='received-input-pause-drain-v1',startup_deadline_ns=900,
                    startup_wait_deadline_ns=800)
                namespace=dict(vars(worker),self=shell,directory=directory,
                    subprocess=NS(check_output=lambda *args,**kwargs:'a'*40))
                exec(compile(ast.Module(body=init.body[start:end+1],type_ignores=[]),worker.__file__,'exec'),namespace)
                metadata=json.loads((directory/'metadata.json').read_text())
                self.assertEqual(metadata.get('motion_authority_profile'),shell.motion_authority_profile)
                self.assertIn('mr3_safety_contract:='+contract,shell.command)
                self.assertFalse(any('motion_authority_profile:=' in x for x in shell.command))
                self.assertEqual(metadata.get('actuation_profile'),
                    'initial-zero-encoder-hold-v1' if contract=='mr3-reach-v1' else None)

if __name__=='__main__':unittest.main(verbosity=2)
'''
files[ROS_TEST/'test_mr3_motion_authority_worker_profile.py']=worker

# Only the synthetic Lifecycle fixture is retained; its dispatcher/mask imports
# are the current actual modules, not an old production class or oracle copy.
old=Path('/tmp/mr3_p2a_outward_cancel_probe_review_v1/test_goal_lifecycle_revision2.py').read_text()
life=next(n for n in ast.parse(old).body if isinstance(n,ast.ClassDef) and n.name=='Lifecycle')
fixture='''"""Synthetic received observations; current real dispatcher/masks, no World."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[8]
COMP=ROOT/'ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration'
# Pure Python protocol/observation dependency only; no ROS nodes or binaries.
sys.path.insert(0,str(COMP))
from multi_robot_exploration.mr3_protocol import GoalDispatcher
from multi_robot_exploration.mr3_observation import _action_masks
NAMES=('tb1','tb2','tb3')
'''+ast.get_source_segment(old,life)+'\n'
files[W_TEST/'test_mr3_probe_lifecycle_fixture.py']=fixture

probe=(HERE/'test_provisional_system_v1.py').read_text()
cls=next(n for n in ast.parse(probe).body if isinstance(n,ast.ClassDef) and n.name=='ProducerTests')
probe='''"""Current canonical v2 producer and actual protocol/masks; no native inputs."""
import ast
import copy
import hashlib
import subprocess
from pathlib import Path
import unittest
from mr3_learning import benchmark
from mr3_learning.supervisor import WORKSPACE as ROOT
from .test_mr3_probe_lifecycle_fixture import Lifecycle
W=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
choose=benchmark.probe_action_reach_v2
record=benchmark.record_probe_reach_v2_submission
finish=benchmark.finish_probe_reach_v2
tree=ast.parse(Path(benchmark.__file__).read_text())
assert Path(benchmark.__file__).resolve()==(W/'mr3_learning/benchmark.py').resolve()
BASELINE_COMMIT='935b466bd076002afdfe161b55a508938de2a8b0'
BASELINE_SHA256='ec77b8284b74e5757e8ce1ec18e0fdbbd508fa42945d8217a6db9272ed16805a'
'''+ast.get_source_segment(probe,cls)+'\n'
old='        original=ast.parse((W/\'mr3_learning/benchmark.py\').read_text())\n'
new='''        # Exact historical source bytes are an immutable test oracle only.
        data=subprocess.check_output(['git','show',BASELINE_COMMIT+':'+
            'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/mr3_learning/benchmark.py'],cwd=ROOT)
        self.assertEqual(hashlib.sha256(data).hexdigest(),BASELINE_SHA256)
        original=ast.parse(data.decode())
'''
assert probe.count(old)==1;probe=probe.replace(old,new)
files[W_TEST/'test_reach_outward_cancel_v2_producer.py']=probe

manifest=[]
for relative,text in files.items():
    ast.parse(text,filename=str(relative))
    assert '/tmp/mr3_' not in text and '/tmp/p2a' not in text
    path=OUT/relative;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text)
    manifest.append({'target':str(relative),'bytes':len(text.encode()),'sha256':hashlib.sha256(text.encode()).hexdigest(),
        'artificial_only':True,'canonical_executed':False})
(OUT/'manifest_v1.json').write_text(json.dumps({'schema':'mr3-authority-canonical-ready-test-sources-v1',
    'status':'AST_ONLY_NOT_YET_INSTALLED_OR_CANONICAL_CPU','files':manifest,
    'callback_cases':8,'worker_cases':2,'metadata_cases':4,'probe_producer_cases':7,
    'reader_cases_owned_by_helper':6,'total_pending_actual_fresh_cases':27,
    'baseline_oracle_git': '935b466bd076002afdfe161b55a508938de2a8b0',
    'no_tmp_candidate_imports':True,'repository_edited':False},indent=2)+'\n')
print(json.dumps({'canonical_test_sources':len(files),'AST_PASS':True,'owned_case_count':21,'helper_reader_cases':6}))
