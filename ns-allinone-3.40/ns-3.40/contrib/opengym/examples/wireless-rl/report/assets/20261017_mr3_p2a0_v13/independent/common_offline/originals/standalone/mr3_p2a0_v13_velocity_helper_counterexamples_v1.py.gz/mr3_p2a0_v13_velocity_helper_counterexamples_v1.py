"""Read-only exact-function extraction of proposed helper; no ROS or native execution."""
import ast
import hashlib
import json
import math
from pathlib import Path
source = Path('/tmp/mr3_velocity_bound_proposal_v2/proposed_mr3_motion_safety.py')
raw = source.read_bytes()
tree = ast.parse(raw)
function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'measured_velocity_error')
constants = {}
for node in tree.body:
    if isinstance(node, ast.Assign):
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id in ('MEASURED_SPEED_BOUND', 'MEASURED_TURN_BOUND'):
                constants[target.id] = ast.literal_eval(node.value)
namespace = {'math': math, **constants}
exec(compile(ast.Module(body=[function], type_ignores=[]), str(source), 'exec'), namespace)
check = namespace['measured_velocity_error']
raw_turn = {'linear': {'x': .1, 'y': 0., 'z': 0.}, 'angular': {'x': 1.3, 'y': 0., 'z': 0.}}
local = {'planar_speed_mps': .1, 'v': .1, 'w': 0.}
peer_twist = {'linear': {'x': .26, 'y': 0., 'z': 0.}, 'angular': {'x': 0., 'y': 0., 'z': .8}}
peer = {'v': 0., 'w': 0., 'odometry': {'twist': {'twist': peer_twist}}}
local_result = check(local)
peer_result = check(peer, require_raw=True)
result = {'scope': 'Pure proposed-helper counterexamples, not complete runtime/native tests; original files unchanged.', 'source': str(source), 'source_sha256': hashlib.sha256(raw).hexdigest(), 'constants': constants,
 'local_fullangular_input_gap': {'local_state': local, 'source_raw_twist_not_in_helper_input': raw_turn, 'true_raw_angular_norm': math.hypot(*raw_turn['angular'].values()), 'helper_result': local_result, 'counterexample_confirmed': local_result is None},
 'peer_scalar_raw_binding_gap': {'state': peer, 'helper_result': peer_result, 'raw_scalar_v_differs': peer['v'] != peer_twist['linear']['x'], 'raw_scalar_w_differs': peer['w'] != peer_twist['angular']['z'], 'counterexample_confirmed': peer_result is None},
 'source_bytes_unchanged': source.read_bytes() == raw}
output = Path('/tmp/mr3_p2a0_v13_velocity_helper_counterexamples_v1.json')
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'output':str(output),'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'local_gap':result['local_fullangular_input_gap']['counterexample_confirmed'],'peer_gap':result['peer_scalar_raw_binding_gap']['counterexample_confirmed']}))
