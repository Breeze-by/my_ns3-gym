"""CPU-only real production-method ledger fixture and duplicate-TF cost probe."""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
from time import perf_counter

from multi_robot_exploration.mr3_information import IdealInformation

ROOT = Path('/home/zhuyulab/ns3-workspace')
BASE = ROOT / 'ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration'
spec = importlib.util.spec_from_file_location('real_information_fixtures', BASE / 'test/test_mr3_information.py')
fixtures = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixtures)
OUT = Path('/tmp/mr3_p2a0_v9_information_producer_fixture_v1')
OUT.mkdir(exist_ok=False)
node = fixtures.state_input_bridge()
for index, name in enumerate(node.names):
    odom = fixtures.input_odom(1_998_000_000, x=1.17 + index * .3)
    odom.pose.pose.position.y, odom.pose.pose.position.z = -.83, .011
    odom.pose.pose.orientation.z = math.sin(-.71 / 2)
    odom.pose.pose.orientation.w = math.cos(-.71 / 2)
    odom.pose.covariance = [float(i) / 10000 for i in range(36)]
    odom.twist.covariance = [float(35-i) / 1000 for i in range(36)]
    odom.twist.twist.linear.x, odom.twist.twist.angular.z = .13, -.27
    tf = fixtures.input_tf(1_979_000_000)
    tf.transforms[0].transform.translation.x = 2.37
    tf.transforms[0].transform.translation.y = -1.18
    tf.transforms[0].transform.translation.z = .025
    tf.transforms[0].transform.rotation.z = math.sin(.36 / 2)
    tf.transforms[0].transform.rotation.w = math.cos(.36 / 2)
    IdealInformation.receive_local_odom(node, name, odom)
    IdealInformation.receive_local_tf(node, name, tf)
    future = fixtures.input_odom(2_002_000_000, x=1.18 + index * .3)
    IdealInformation.receive_local_odom(node, name, future)
IdealInformation.publish_states(node)
node.clock_ns = 2_100_000_000
IdealInformation.publish_states(node)
ledger = OUT / 'information_states.jsonl'
ledger.write_text(node.state_audit_stream.getvalue())

performance = []
for audit in (False, True):
    sample = fixtures.state_input_bridge(audit=audit)
    path = OUT / ('tf_duplicate_audit.jsonl' if audit else 'unused.jsonl')
    if audit:
        config = sample.state_audit_stream.getvalue()
        sample.state_audit_stream = path.open('x', buffering=1)
        sample.state_audit_stream.write(config)
    tf = fixtures.input_tf(2_001_000_000)
    started = perf_counter()
    for unused in range(6000):
        IdealInformation.receive_local_tf(sample, 'tb1', tf)
    elapsed = perf_counter() - started
    if audit:
        sample.state_audit_stream.close()
        rows = [json.loads(line) for line in path.read_text().splitlines()]
        assert len(rows) == 6001
        assert sum(row['payload'].get('admission') == 'ignored_pending_order' for row in rows) == 5999
        assert all(row['payload'].get('matched_input_sequence') == 1 for row in rows[2:])
    performance.append({'audit_enabled': audit, 'callbacks': 6000,
                        'wall_seconds': elapsed, 'mean_callback_seconds': elapsed / 6000,
                        'pending_retained': len(sample.pending_transforms['tb1']),
                        'all_raw_rows_saved': 6000 if audit else None,
                        'bytes': path.stat().st_size if audit else 0})
result = {'schema': 'mr3-information-producer-ledger-fixture-v1',
          'production_source_sha256': hashlib.sha256((BASE / 'multi_robot_exploration/mr3_information.py').read_bytes()).hexdigest(),
          'test_source_sha256': hashlib.sha256((BASE / 'test/test_mr3_information.py').read_bytes()).hexdigest(),
          'ledger_path': str(ledger), 'ledger_sha256': hashlib.sha256(ledger.read_bytes()).hexdigest(),
          'ledger_rows': len(ledger.read_text().splitlines()), 'nonidentity_fixture': True,
          'performance': performance, 'native_starts': 0, 'ROS_init_or_spin': 0,
          'scope': 'CPU fake publishers around real production methods; performance is host-local diagnostic, not native timeliness credit'}
output = OUT / 'receipt.json'
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
