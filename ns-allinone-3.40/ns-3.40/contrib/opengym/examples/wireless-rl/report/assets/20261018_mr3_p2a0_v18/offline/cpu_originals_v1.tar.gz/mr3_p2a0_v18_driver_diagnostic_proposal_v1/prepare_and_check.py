"""Generate only /tmp candidate files and syntax-check, never build/load a plugin."""
from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import time

ROOT=Path('/home/zhuyulab/ns3-workspace')
PACKAGE=ROOT/'ros2_ws/ros2-multi-robot-automap/src/multi_robot'
OUT=Path(__file__).parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def command(argv,name,cwd=ROOT):
    start=time.monotonic()
    utc=datetime.now(timezone.utc).isoformat()
    env=dict(os.environ)
    env.pop('PYTHONPATH',None)
    env.update(PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1')
    log=OUT/(name+'.log')
    with log.open('xb') as output:
        result=subprocess.run(argv,cwd=cwd,env=env,stdout=output,stderr=subprocess.STDOUT)
    return {'argv':argv,'cwd':str(cwd),'environment_override':{
        'PYTHONPATH':None,'PYTHONNOUSERSITE':'1','PYTHONDONTWRITEBYTECODE':'1'},
        'start_utc':utc,'end_utc':datetime.now(timezone.utc).isoformat(),
        'wall_sec':time.monotonic()-start,'exit_code':result.returncode,
        'stdout':str(log),'stdout_sha256':sha(log.read_bytes())}


source_paths=['src/mr3_gazebo_diff_drive.cpp','include/multi_robot/mr3_gazebo_diff_drive.hpp',
              'include/multi_robot/paired_wheel_slew.hpp','include/multi_robot/mr3_drive_target.hpp',
              'CMakeLists.txt']
original={str(PACKAGE/p): (PACKAGE/p).read_bytes() for p in source_paths}
sources=OUT/'sourceproof'
sources.mkdir()
bindings=[]
for path,data in original.items():
    relative=str(Path(path).relative_to(PACKAGE))
    frozen=subprocess.check_output(['git','show','eee6b2f90f697b28a1c20a2af5d1a6d2f044465e:'+str(Path(path).relative_to(ROOT))],cwd=ROOT)
    assert data==frozen, f'canonical differs from frozen source: {path}'
    selected=sources/relative
    selected.parent.mkdir(parents=True,exist_ok=True)
    selected.write_bytes(data)
    bindings.append({'source':path,'sha256':sha(data),'frozen_git_blob_equal':True,'selected':str(selected)})

cmake=original[str(PACKAGE/'CMakeLists.txt')].decode()
addition='''
# Opt-in diagnostic observer only. No existing driver target/source/flags change.
set(mr3_observer_source ${CMAKE_CURRENT_SOURCE_DIR}/src/mr3_stop_response_observer.cpp)
set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS ${mr3_observer_source})
file(SHA256 ${mr3_observer_source} mr3_observer_source_sha)
add_library(mr3_stop_response_observer SHARED src/mr3_stop_response_observer.cpp)
target_compile_features(mr3_stop_response_observer PRIVATE cxx_std_17)
target_include_directories(mr3_stop_response_observer PRIVATE ${GAZEBO_INCLUDE_DIRS})
target_compile_definitions(mr3_stop_response_observer PRIVATE
  MR3_OBSERVER_SOURCE_SHA256="${mr3_observer_source_sha}")
target_link_libraries(mr3_stop_response_observer ${GAZEBO_LIBRARIES}
  nlohmann_json::nlohmann_json ${CMAKE_DL_LIBS})
install(TARGETS mr3_stop_response_observer DESTINATION lib)

'''
anchor='add_library(mr3_gazebo_step_plugin SHARED src/mr3_gazebo_step_plugin.cpp)'
assert cmake.count(anchor)==1
candidate=cmake.replace(anchor,addition+anchor)
assert candidate.replace(addition,'')==cmake
(OUT/'CMakeLists.proposed.txt').write_text(candidate)
source=OUT/'mr3_stop_response_observer.cpp'
patch=''.join(difflib.unified_diff(cmake.splitlines(keepends=True),candidate.splitlines(keepends=True),
    fromfile='a/ros2_ws/ros2-multi-robot-automap/src/multi_robot/CMakeLists.txt',
    tofile='b/ros2_ws/ros2-multi-robot-automap/src/multi_robot/CMakeLists.txt'))
patch+=''.join(difflib.unified_diff([],source.read_text().splitlines(keepends=True),
    fromfile='/dev/null',tofile='b/ros2_ws/ros2-multi-robot-automap/src/multi_robot/src/mr3_stop_response_observer.cpp'))
(OUT/'review_only.patch').write_text(patch)
(OUT/'diagnostic_plugin_example.xml').write_text('''<!-- Illustrative, NOT applied/authorized/executed. Only a diagnostic generated SDF adds this plugin. -->
<plugin name="mr3_stop_response_observer" filename="libmr3_stop_response_observer.so">
  <epoch>EXACT_EPISODE_EPOCH</epoch><robot>tb1</robot>
  <output_path>EXCLUSIVE_EPISODE_PATH/stop_response_tb1.jsonl</output_path>
  <start_ns>0</start_ns><end_ns>10000000000</end_ns>
  <base_link>base_footprint</base_link>
  <right_joint>wheel_right_joint</right_joint><left_joint>wheel_left_joint</left_joint>
</plugin>
''')

pkg=subprocess.run(['/usr/bin/pkg-config','--cflags','gazebo'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
(OUT/'pkg_config_cflags.txt').write_bytes(pkg.stdout)
(OUT/'pkg_config_stderr.txt').write_bytes(pkg.stderr)
argv=['/usr/bin/c++','-std=c++17','-fsyntax-only','-Wall','-Wextra',
      '-DMR3_OBSERVER_SOURCE_SHA256="'+sha(source.read_bytes())+'"']+shlex.split(pkg.stdout.decode())+[str(source)]
result=command(argv,'syntax01')
for path,data in original.items():
    assert Path(path).read_bytes()==data, 'canonical source changed during CPU check'
read_only_tokens=['SetParam(', 'SetVelocity(', 'SetForce(', 'SetWorldPose(', 'SetLinearVel(',
                  'SetAngularVel(', 'create_publisher', 'create_subscription', 'publish(',
                  'Advertise<', 'Subscribe(', 'rclcpp::init', 'ros_node_']
body=source.read_text()
assert all(t not in body for t in read_only_tokens)
check={'schema':'mr3-v18-isolated-observer-proposal-checks-v1',
       'passed':result['exit_code']==0,'scope':'CPU syntax and source/isolation checks only; no plugin ELF, Gazebo/native, formal audit, parameter change or PASS credit',
       'commands':[result],'package_config_command':['/usr/bin/pkg-config','--cflags','gazebo'],
       'canonical_unchanged_bindings':bindings,'cmake_removing_only_new_block_recovers_original_bytes':True,
       'read_only_mutation_and_transport_tokens_absent':read_only_tokens,
       'candidate_source_sha256':sha(source.read_bytes()),'candidate_patch_sha256':sha((OUT/'review_only.patch').read_bytes()),
       'checker_source_sha256':sha(Path(__file__).read_bytes())}
with (OUT/'checks_v1.json').open('x') as output:
    json.dump(check,output,indent=2)
    output.write('\n')
print(json.dumps({'passed':check['passed'],'checks':str(OUT/'checks_v1.json'),
                  'source_sha256':check['candidate_source_sha256'],
                  'patch_sha256':check['candidate_patch_sha256'],
                  'syntax_exit':result['exit_code'],'syntax_wall_sec':result['wall_sec']},indent=2))
raise SystemExit(0 if check['passed'] else 1)
