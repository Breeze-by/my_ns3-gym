import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT=Path('/home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap')
OUT=Path('/tmp/mr3_p2a0_v22_root_ros_relevant02_v1')
assert not OUT.exists()
OUT.mkdir()
names=['test_mr3_task_contract.py','test_mr3_adapter_launch.py','test_mr3_terminal_launch.py',
       'test_mr3_drive_launch.py','test_launch_and_smoke.py']
paths=[ROOT/'src/multi_robot_exploration/test'/name for name in names]
source_paths=paths+[ROOT/'src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py']
bindings={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths}
argv=['/usr/bin/python3','-B','-m','pytest','-q','--tb=short',*[str(p.relative_to(ROOT)) for p in paths]]
start=time.monotonic()
with (OUT/'stdout.txt').open('xb') as one,(OUT/'stderr.txt').open('xb') as two:
    child=subprocess.run(argv,cwd=ROOT,stdout=one,stderr=two)
assert bindings=={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths}
result={'schema':'mr3-v22-ros-relevant-cpu-checks-v1','scope':'Existing actual launch-action construction and pure task/geometry tests, with updated fake plugin existence markers. No launched ROS/Gazebo participant or native research run.',
 'argv':argv,'cwd':str(ROOT),'returncode':child.returncode,'passed':child.returncode==0,
 'wall_seconds':time.monotonic()-start,'source_before_after_sha':bindings,
 'environment_selected':{n:os.environ.get(n) for n in ('ROS_DISTRO','PYTHONNOUSERSITE','PYTHONDONTWRITEBYTECODE','PYTHONPATH','AMENT_PREFIX_PATH')},
 'stdout_sha256':hashlib.sha256((OUT/'stdout.txt').read_bytes()).hexdigest(),
 'stderr_sha256':hashlib.sha256((OUT/'stderr.txt').read_bytes()).hexdigest()}
(OUT/'execution.json').write_text(json.dumps(result,indent=2)+'\n')
print((OUT/'stdout.txt').read_text()[-2000:])
print(json.dumps({k:result[k] for k in ('passed','returncode','wall_seconds')}))
raise SystemExit(child.returncode)
