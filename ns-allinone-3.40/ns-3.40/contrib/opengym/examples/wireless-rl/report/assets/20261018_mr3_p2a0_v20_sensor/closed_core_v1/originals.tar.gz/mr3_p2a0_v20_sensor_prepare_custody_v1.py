"""Mechanical V19 codec reuse with the actual V20 ordinary4/recorder receipt."""
import ast
import difflib
import hashlib
import json
from pathlib import Path


OLD = Path('/tmp/mr3_p2a0_v19_pack_closed_iters150_v1.py')
NEW = Path('/tmp/mr3_p2a0_v20_sensor_pack_closed_v1.py')


def main():
    original = OLD.read_text()
    text = original
    replacements = [
        ("    parser.add_argument('--execution', type=Path, required=True)",
         "    parser.add_argument('--execution', type=Path, required=True)\n    parser.add_argument('--source-kind', choices=('native', 'sensor_capture'), required=True)"),
        ("    assert source.name == 'mr3_p2a0_20261018_v19_iters150'\n    assert args.prospective_prefix.endswith('/20261018_mr3_p2a0_v19/native/iters150')",
         "    expected_names = {'native': 'mr3_p2a0_20261018_v20_sensor_iters150',\n                      'sensor_capture': 'mr3_p2a0_v20_sensor_capture_v1'}\n    suffixes = {'native': '/native/iters150', 'sensor_capture': '/sensor_capture'}\n    assert source.name == expected_names[args.source_kind]\n    assert args.prospective_prefix.endswith('/20261018_mr3_p2a0_v20_sensor' + suffixes[args.source_kind])"),
        ("    consumers = execution.get('diagnostic_consumers', [])\n    assert type(consumers) is list",
         "    assert execution['schema'] == 'mr3-startup-sensor-execution-v1'\n    consumers = [execution['original_physical_4step']]\n    assert type(consumers[0]) is dict"),
        ("    summary_path = source / 'benchmark_summary.json'\n    summary_raw = summary_path.read_bytes()\n    summary = json.loads(summary_raw)\n    assert summary['freeze'] == execution['freeze'] and type(summary['passed']) is bool",
         "    summary_path = Path(execution['benchmark_summary']['path'])\n    summary_raw = summary_path.read_bytes()\n    assert sha(summary_raw) == execution['benchmark_summary']['sha256']\n    summary = json.loads(summary_raw)\n    assert summary['freeze'] == execution['freeze'] and type(summary['passed']) is bool\n    recorder_path = Path(execution['recorder_final']['path'])\n    recorder_raw = recorder_path.read_bytes()\n    assert sha(recorder_raw) == execution['recorder_final']['sha256']\n    recorder = json.loads(recorder_raw)\n    metadata_path = Path(execution['actual_workload']['protocol']['path']).parent / 'metadata.json'\n    metadata_raw = metadata_path.read_bytes()\n    metadata = json.loads(metadata_raw)\n    assert metadata['freeze'] == execution['freeze'] and recorder['epoch'] == metadata['epoch']"),
        ("'mr3-v19-native-custody-helper-configuration-v1'", "'mr3-v20-sensor-custody-helper-configuration-v1'"),
        ("    for artifact in artifacts:\n        if artifact['available']:",
         "    assert recorder_path.read_bytes() == recorder_raw, 'closed recorder final changed'\n    assert metadata_path.read_bytes() == metadata_raw, 'closed worker metadata changed'\n    for artifact in artifacts:\n        if artifact['available']:"),
        ("'mr3-v19-native-byte-custody-v1'", "'mr3-v20-sensor-byte-custody-v1'"),
        ("        'stage': 'iters150', 'source': str(source), 'freeze': execution['freeze'],",
         "        'stage': 'iters150', 'source_kind': args.source_kind, 'source': str(source), 'freeze': execution['freeze'],"),
        ("        'original_diagnostic_consumers': execution.get('diagnostic_consumers'),",
         "        'original_physical_4step': execution['original_physical_4step'],\n        'original_physical_passed': execution['original_physical_passed'],\n        'strict_native_closure_passed': execution['strict_native_closure_passed'],\n        'actual_workload_original': execution['actual_workload'],\n        'e61c_original': execution['e61c'],\n        'closed_recorder_final': {'source': str(recorder_path), 'sha256': sha(recorder_raw),\n                                  'bytes': len(recorder_raw), 'original_value': recorder},\n        'closed_worker_metadata': {'source': str(metadata_path), 'sha256': sha(metadata_raw),\n                                  'bytes': len(metadata_raw)},"),
    ]
    for before, after in replacements:
        assert text.count(before) == 1, before
        text = text.replace(before, after)
    with NEW.open('x') as stream:
        stream.write(text)
    old_ast, new_ast = ast.parse(original), ast.parse(text)
    core = ('sha', 'identity', 'file_digest', 'verify_file', 'pack_file', 'inventory')
    same = {}
    for name in core:
        first = next(node for node in old_ast.body if isinstance(node, ast.FunctionDef) and node.name == name)
        second = next(node for node in new_ast.body if isinstance(node, ast.FunctionDef) and node.name == name)
        a, b = ast.get_source_segment(original, first), ast.get_source_segment(text, second)
        assert a == b
        same[name] = hashlib.sha256(a.encode()).hexdigest()
    restored = text
    for before, after in reversed(replacements):
        assert restored.count(after) == 1
        restored = restored.replace(after, before)
    assert restored == original
    patch = Path('/tmp/mr3_p2a0_v20_sensor_custody_mechanical_v1.patch')
    with patch.open('x') as stream:
        stream.write(''.join(difflib.unified_diff(original.splitlines(True), text.splitlines(True),
                                               fromfile=str(OLD), tofile=str(NEW))))
    result = {'schema': 'mr3-v20-sensor-custody-mechanical-proof-v1',
              'old_helper': {'path': str(OLD), 'sha256': hashlib.sha256(original.encode()).hexdigest()},
              'new_helper': {'path': str(NEW), 'sha256': hashlib.sha256(text.encode()).hexdigest()},
              'six_core_functions_exact_bytes_same': same,
              'whole_helper_reverse_all_declared_adapter_changes_exact': True,
              'scope': 'Only V20 actual schema/identity plus recorder root adapter; no codec/stat or research gate change.',
              'passed': True}
    with Path('/tmp/mr3_p2a0_v20_sensor_custody_mechanical_proof_v1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
