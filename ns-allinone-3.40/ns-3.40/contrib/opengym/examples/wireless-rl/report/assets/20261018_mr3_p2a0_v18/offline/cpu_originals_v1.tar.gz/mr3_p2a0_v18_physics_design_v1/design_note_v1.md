# V18 physics diagnostic proposal — not admitted

Recommend one three-robot, one-worker open10132-step engineering baseline using the existing V6 fixture. Add a separate1ms post-physics measurement file; leave the original30Hz odometry/actuation,20ms control phases, model/contact settings and original `.01m/s ×3`/`.78s` stop gate intact. It is a diagnosis, with zero learning and no P2A.0 matrix credit.

The active `p1c_*` worlds specify ODE1ms/1000Hz and omit the ODE solver block. Installed SDF1.7 defaults predict quick/50iterations/SOR1.3. These are source-derived defaults, not old runtime readback. The two available ground-plane models both specify friction100/50, while wheel collisions specify100000/100000; confirm the resolved collision properties during the future run. Do not change friction on this evidence.

The old `multi_empty_world`/`turtlebot3_world`150/1.4 configuration also changes the step to20ms, MOI handling, CFM, contact correction and surface layer. Copying the whole block would confound a test. If separately authorized, a second fresh run should vary **only iterations50→150**, retaining SOR1.3 and every other setting. One comparison supports sensitivity analysis, not a convergence theorem. Closed-loop commands can differ, so preserve their exact streams.

Record all3 actual canonical origins at each1ms WorldUpdateEnd with full pose/linear/angular vectors, base_link/CoG transforms, actual last target/actuation identities, joint feedback and supported solver residual/contact counts. This file stays isolated from actor, masks, navigation and guard. Match existing30Hz WorldUpdateBegin odometry with explicit engine-phase labels; evaluate the predeclared0/1tick offsets without selecting a convenient shift.

The primary question is whether the approximately.011m/s lateral signal persists at1ms, oscillates between coarse samples, or disagrees with co-located pose increments. Check the point-shift equations from measured transforms. Retain the original30Hz rest verdict. High-rate finite sampling still cannot prove continuous truth or justify calling the failure noise.

Proposed ceiling:1800wall seconds and32API steps for baseline; only if prospectively authorized, another1800/32 for the single contrast. Maximum2runs/64steps,2resets and0updates; charge all startup/physical/alignment/cleanup costs separately and leave pilot training balances unchanged. Preserve non-reproduction, missing stop coverage and failures without retry. A production repair still needs a new complete same-freeze matrix.

Official references: [Gazebo physics parameters](https://classic.gazebosim.org/tutorials?cat=physics&tut=physics_params), [Gazebo friction](https://classic.gazebosim.org/tutorials?cat=physics&tut=friction). Exact local XML/default/source SHA facts and the full capture/analysis contract are in the adjacent JSON files.
