"""Run the same canonical two-package ROS CPU scope; no native launch."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
OLD = Path('/tmp/mr3_p2a0_v14_ros_semantic_full_v1.json')
PREFIX = Path('/tmp/mr3_p2a0_v15_ros_semantic_full_v1')
reference = json.loads(OLD.read_text())
paths = sorted(set(reference['source_before']) | {
    'ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/test/test_navigation_peer_geometry.py',
    'ros2_ws/ros2-multi-robot-automap/src/multi_robot/config/mr3_fastdds_loopback_udp.xml',
    'ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/test/test_fastdds_environment.py',
})
sha = lambda raw: hashlib.sha256(raw).hexdigest()
before = {path: sha((ROOT / path).read_bytes()) for path in paths}
environment = dict(os.environ)
removed = []
for key in list(environment):
    if key.startswith('CONDA') or key in (
            'PYTHONPATH', 'AMENT_PREFIX_PATH', 'COLCON_PREFIX_PATH',
            'CMAKE_PREFIX_PATH', 'LD_LIBRARY_PATH', 'VIRTUAL_ENV'):
        removed.append(key)
        del environment[key]
environment.update(PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1', ROS_DOMAIN_ID='211')
log = PREFIX.with_suffix('.log')
report = PREFIX.with_suffix('.json')
assert not log.exists() and not report.exists()
started = time.monotonic()
with log.open('x') as output:
    process = subprocess.run(reference['command'], cwd=reference['cwd'],
                             env=environment, stdout=output, stderr=subprocess.STDOUT)
duration = time.monotonic() - started
after = {path: sha((ROOT / path).read_bytes()) for path in paths}
raw = log.read_bytes()
encoded = gzip.compress(raw, mtime=0)
with Path(str(log) + '.gz').open('xb') as output:
    output.write(encoded)
assert gzip.decompress(encoded) == raw
result = {
    'schema': 'mr3-p2a0-ros-semantic-check-v15',
    'scope': 'Same two packages and six explicit lint ignores as V14; navigation '
             'peer bound decoupling and new real-cloud/grid regression included; no native.',
    'command': reference['command'], 'cwd': reference['cwd'],
    'environment_removed_keys': sorted(removed),
    'environment_overrides': {key: environment[key] for key in (
        'PYTHONNOUSERSITE', 'PYTHONDONTWRITEBYTECODE', 'ROS_DOMAIN_ID')},
    'source_before': before, 'source_after': after, 'sources_stable': before == after,
    'source_count': len(paths), 'exit_code': process.returncode, 'wall_seconds': duration,
    'stdout_stderr': str(log), 'stdout_sha256': sha(raw),
    'stdout_gzip': str(log) + '.gz', 'encoded_sha256': sha(encoded),
    'script_sha256': sha(Path(__file__).read_bytes()),
    'passed': process.returncode == 0 and before == after,
}
with report.open('x') as output:
    output.write(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in (
    'passed', 'exit_code', 'source_count', 'sources_stable', 'wall_seconds')}))
print(raw.decode()[-800:])
raise SystemExit(0 if result['passed'] else 1)
