"""Seal diagnostic custody without re-reading original traces."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

PREFIX='mr3_p2a0_v17_stop_response_'
ROOT=Path('/tmp')
BASE=ROOT/'mr3_p2a0_v17_stop_response_raw_diagnostic_v1'
OUTPUT=ROOT/'mr3_p2a0_v17_stop_response_diagnostic_custody_v1.json'


def sha(data):
    return hashlib.sha256(data).hexdigest()


note={
    'kind':'explicit_post_execution_note',
    'argv':['/usr/bin/python3','/tmp/mr3_p2a0_v17_stop_response_chain_review_v1.py'],
    'shell_tool_argv':['rtk','proxy','/usr/bin/python3','/tmp/mr3_p2a0_v17_stop_response_chain_review_v1.py'],
    'cwd':'/home/zhuyulab/ns3-workspace','reported_exit_code':0,
    'wall_sec':None,'stdout_file':None,
    'limitation':'The first chain postprocessor stdout was returned in the tool transcript but not redirected to a file, and exact process wall time was not separately captured. No stdout file or wall time is fabricated. The initial raw extraction and subsequent v2 tail execution both retain exact argv, exit, wall, stdout, script SHA and before/after input bindings.',
}
with (ROOT/'mr3_p2a0_v17_stop_response_chain_execution_note_v1.json').open('x') as out:
    json.dump(note,out,indent=2)
    out.write('\n')
source_checks=[]
for path in sorted(BASE.glob('episode*/report.json')):
    report=json.loads(path.read_bytes())
    for item in report['input_manifest']:
        s=Path(item['source']).stat()
        current={k:getattr(s,k) for k in ('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns')}
        stable=current==item['source_stat_after']
        assert stable, item['source']
        source_checks.append({'source':item['source'],'source_sha256':item['source_sha256'],
                              'source_bytes':item['source_bytes'],'final_stat_unchanged':stable,
                              'hash_scope':'one extraction pass; final check uses file identity/stat without a second original content scan'})
files=[]
for path in sorted(ROOT.glob(PREFIX+'*')):
    for p in sorted(path.rglob('*')) if path.is_dir() else [path]:
        if not p.is_file() or p==OUTPUT:
            continue
        data=p.read_bytes()
        files.append({'path':str(p),'bytes':len(data),'sha256':sha(data)})
result={'schema':'mr3-v17-stop-response-diagnostic-custody-v1',
        'freeze':'eee6b2f90f697b28a1c20a2af5d1a6d2f044465e',
        'diagnostic_completed':True,'formal_outcome_stays_failed':True,
        'utc':datetime.now(timezone.utc).isoformat(),
        'source_checks':source_checks,'files':files,'file_count':len(files),
        'total_selected_and_derived_bytes':sum(r['bytes'] for r in files),
        'no_canonical_source_git_binary_control_changes':True,
        'scope':'Source-stat seal and raw/derived diagnostic file inventory only, without formal audit/native invocation. Encoded/decoded selected row hashes verified by chain review. Diagnostic writers stop after this output.'}
with OUTPUT.open('x') as out:
    json.dump(result,out,indent=2)
    out.write('\n')
print(json.dumps({'output':str(OUTPUT),'sha256':sha(OUTPUT.read_bytes()),
                  'file_count':len(files),'bytes':result['total_selected_and_derived_bytes'],
                  'original_sources':len(source_checks),'original_stat_stable':True},indent=2))
