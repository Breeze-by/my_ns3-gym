"""Read-only bounded-tail phase diagnostics; no acceptance or prefix formal audit."""
from pathlib import Path
import hashlib
import json
import math
import sys
import time
run,out,freeze=Path(sys.argv[1]),Path(sys.argv[2]),sys.argv[3]
result={'schema':'mr3-v11-partial-phase-live-v1','run':str(run),'freeze':freeze,
        'wall_monotonic_ns':time.monotonic_ns(),'scope':'Bounded actual complete tail rows only; no formal or native acceptance credit','episodes':[]}
def tail(path,limit=3_000_000):
 if not path.is_file():return [],{'exists':False}
 with path.open('rb')as stream:
  stream.seek(0,2);size=stream.tell();start=max(0,size-limit);stream.seek(start);data=stream.read()
 if start:
  at=data.find(b'\n');data=data[at+1:]if at>=0 else b''
 if data and not data.endswith(b'\n'):data=data[:data.rfind(b'\n')+1]
 return [json.loads(line)for line in data.splitlines()if line.strip()],{'exists':True,'bytes':size,'tail_start':start,'complete_tail_sha256':hashlib.sha256(data).hexdigest(),'tail_only':bool(start)}
for ep in sorted(run.glob('worker*/episode*')):
 entry={'episode':str(ep),'inputs':{},'alerts':[],'phase':{}};result['episodes'].append(entry)
 try:
  meta=json.loads((ep/'metadata.json').read_text());entry['epoch']=meta['epoch'];assert meta['freeze']==freeze
  files={}
  for name in ('information_states.jsonl','peer_phase.jsonl','motion_safety.jsonl','control_phase_worker.jsonl','drive_phase_worker.jsonl','physics.jsonl','transitions.jsonl'):
   files[name],entry['inputs'][name]=tail(ep/name)
  transitions=files['transitions.jsonl'];entry['returned_records_in_tail']=len(transitions)
  entry['closed']=(ep/'supervisor_shutdown.json').is_file()
  physical=files['physics.jsonl'];entry['last_physics']=physical[-1]if physical else None
  entry['phase']['last_worker_rows']=files['control_phase_worker.jsonl'][-8:]
  advances=[r for r in files['drive_phase_worker.jsonl']if r['kind']=='advance_permitted']
  entry['phase']['latest_advances']=[{k:r.get(k)for k in ('request_id','start_time_ns','steps','control_kind','control_request_id')}for r in advances[-5:]]
  info=files['information_states.jsonl'];peer=files['peer_phase.jsonl'];motion=files['motion_safety.jsonl']
  for label,rows,kind,key in (('state',info,'state_phase_ack','ack'),('peer',peer,'ack_published','ack'),('guard',motion,'control_ack_published','ack')):
   values=[r for r in rows if r['kind']==kind]
   if values:
    ack=values[-1]['payload'][key];entry['phase'][label]={'request_id':ack['request_id'],'clock_ns':ack['clock_ns'],'target_time_ns':ack['target_time_ns'],'operation':ack['operation'],'ok':ack['ok'],'state_sequence':ack.get('state_sequence'),'commit_sequence':ack.get('commit_sequence'),'error':ack.get('error'),'status':ack.get('status')}
  latest={}
  for r in motion:
   if r['kind']=='decision':
    v=r['payload'];latest[v['robot']]={'clock_ns':v['clock_ns'],'sequence':v['decision_sequence'],'reason':v['decision']['reason'],'output':v['decision']['output'],'ready':v['ready'],'phase_kind':v.get('phase_kind')}
  entry['phase']['latest_guard_decisions']=latest
  for file,rows in files.items():
   for r in rows:
    kind=r.get('kind');p=r.get('payload',{})
    if kind in ('infrastructure_abort_started','state_input_failure','invalid_phase_request','invalid_state_bundle','control_failure','settled_turn_model_failure','invalid_received_states','clock_changed_during_decision'):
     entry['alerts'].append({'file':file,'kind':kind,'row':r})
    if file=='control_phase_worker.jsonl'and kind=='ack_received'and r.get('ack',{}).get('ok')is False:
     ack=r['ack'];legit=r['component']=='state'and ack.get('error')=='state_phase_task_terminal'and ack.get('scope')=='terminal_cancelled_uncommitted_state_phase'
     if not legit:entry['alerts'].append({'file':file,'kind':'actual_nonterminal_negative_ack','row':r})
  if transitions:
   release=transitions[0].get('info',{}).get('release_time_ns') if transitions[0].get('kind')=='reset' else None
   # Do not infer coverage from a tail without the reset anchor.
   entry['release_anchor_in_tail']=release
   if release is not None:
    maxima={r:{'planar':0.,'angular':0.}for r in ('tb1','tb2','tb3')}
    for r in motion:
     if r['kind']!='own_odom':continue
     p=r['payload'];m=p['message'];s=m['header']['stamp'];source=s['sec']*1_000_000_000+s['nanosec']
     if source<release:continue
     t=m['twist']['twist'];v=math.hypot(t['linear']['x'],t['linear']['y']);w=math.sqrt(sum(t['angular'][k]**2 for k in ('x','y','z')))
     maxima[p['robot']]['planar']=max(maxima[p['robot']]['planar'],v);maxima[p['robot']]['angular']=max(maxima[p['robot']]['angular'],w)
     if v>.3 or w>1.2:entry['alerts'].append({'file':'motion_safety.jsonl','kind':'raw_body_bound','robot':p['robot'],'source_ns':source,'planar':v,'angular':w,'original':r})
    entry['bounded_tail_raw_maxima']=maxima
 except Exception as error:entry['read_diagnostic_error']=repr(error)
with out.open('x')as stream:stream.write(json.dumps(result,sort_keys=True,indent=2,allow_nan=False)+'\n')
print(json.dumps({'output':str(out),'episodes':[{'episode':e['episode'],'closed':e.get('closed'),'returned_records':e.get('returned_records_in_tail'),'phase':e.get('phase'),'alerts':e['alerts'],'error':e.get('read_diagnostic_error')}for e in result['episodes']]},sort_keys=True))
