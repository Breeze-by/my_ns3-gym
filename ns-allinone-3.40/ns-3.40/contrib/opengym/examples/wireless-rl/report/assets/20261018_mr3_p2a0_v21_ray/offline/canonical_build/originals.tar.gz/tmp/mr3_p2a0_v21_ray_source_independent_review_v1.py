#!/usr/bin/python3
"""Read-only source/interface review; do not run author CPU checks or Gazebo."""
import ast
import hashlib
import json
from pathlib import Path
import re
import time


BASE = Path('/tmp/mr3_p2a0_v20_sensor_ray_geometry_source_review_v1')
HERE = Path('/tmp/mr3_p2a0_v21_ray_cache_lock_review_v1')
OBSERVER = Path('/tmp/mr3_p2a0_v21_ray_observer_proposal_v2/mr3_ray_provenance_observer.cpp')
LAUNCH = Path('/tmp/mr3_p2a0_v21_ray_proposal_v2/proposed_launch.py')
CHECKS = OBSERVER.parent / 'build_checks_v1.json'
INJECTION = LAUNCH.parent / 'injection_checks_v2.json'
OUT = Path('/tmp/mr3_p2a0_v21_ray_source_independent_review_v1.json')
EXPECTED_CPP = '65b1c1db64861366811266580daf8cf43bcf565fc856a405f473b02bdefd082c'
EXPECTED_LAUNCH = '6c76a4f0afbeb4c26f8c28b8e1139bbd12e5162a54ca3a193b99a156ef47a2d2'
bindings = {}


def read(path, expected=None):
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    keys = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    first = {k: getattr(before, k) for k in keys}
    assert first == {k: getattr(after, k) for k in keys}
    digest = hashlib.sha256(raw).hexdigest()
    if expected is not None:
        assert digest == expected, str(path)
    bindings[str(path)] = {'bytes': len(raw), 'sha256': digest, 'before_stat': first}
    return raw


start = time.monotonic()
cpp = read(OBSERVER, EXPECTED_CPP).decode()
launch = read(LAUNCH, EXPECTED_LAUNCH).decode()
checks = json.loads(read(CHECKS, '29dc3f408770c7fd94632a4a51cf2ae8e53af0e7938a6a889af6cc3ddb66703e'))
injection = json.loads(read(INJECTION))
assert checks['passed'] is True and checks['source_before'] == checks['source_after']
assert all(c['exit_code'] == 0 for c in checks['commands'])
assert checks['source_before'][str(OBSERVER)] == EXPECTED_CPP
assert injection['passed'] is True and injection['source_stable'] is True
assert injection['source_sha256'][str(LAUNCH)] == EXPECTED_LAUNCH
for command in checks['commands']:
    for stream in ('stdout', 'stderr'):
        ref = command[stream]
        read(Path(ref['path']), ref['sha256'])
for stream in ('stdout', 'stderr'):
    read(Path(injection[stream]))
factory = read(OBSERVER.parent / 'factory_cpu.cpp')
assert b'GetType() == gazebo::SENSOR_PLUGIN' in factory
assert 'public gazebo::SensorPlugin' in cpp and 'GZ_REGISTER_SENSOR_PLUGIN' in cpp
assert 'public gazebo::ModelPlugin' not in cpp
assert all(token not in cpp for token in ('Discover(', 'GetSensors(', 'WorldUpdateBegin', 'ResetLastUpdateTime'))
for name in ('GetIntersection', 'SetActive', 'SetUpdateRate', 'SetPoints', 'SetLength', 'UpdateRays'):
    assert re.search(r'->\s*' + name + r'\s*\(', cpp) is None, name
assert cpp.index('state->Emit({{"kind", "configuration"}') < cpp.index('state->scanConnection = ray->ConnectUpdated')
assert 'length < fullRange' in cpp
assert 'global_cast_end_before_collision' in cpp
assert 'relative_end_after_collision' in cpp
assert 'measurement_time_after_ns' in cpp
assert 'not native ODE geometry readback' in cpp

tree = ast.parse(launch)
functions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
append = ast.get_source_segment(launch, functions['append_ray_provenance'])
assert 'sensor[@name=' in append and 'hls_lfcd_lds' in append
assert 'type' in append and 'ray' in append
assert 'rendered.replace(block, "", 1) != model' in append
assert 'model[:sensor_end] + block + model[sensor_end:]' in append
assert 'if "ray_provenance" not in binding:\n        return model' in append

primary = {
    'sensor': BASE / 'official/Sensor_11.10.2.cc',
    'ray_sensor': BASE / 'inputs/RaySensor_11.10.2.cc',
    'multi_ray': BASE / 'inputs/MultiRayShape_11.10.2.cc',
    'ode_multi_ray': BASE / 'inputs/ODEMultiRayShape_11.10.2.cc',
    'ode_ray': BASE / 'official/ODERayShape_11.10.2.cc',
    'ray_shape': BASE / 'official/RayShape_11.10.2.cc',
    'sensor_manager': HERE / 'SensorManager_11.10.2.cc',
    'event_header': Path('/usr/include/gazebo-11/gazebo/common/Event.hh')
}
for path in primary.values():
    read(path)
report = {
    'schema': 'mr3-v21-ray-source-independent-review-v1',
    'passed_source_interface_review': True,
    'scope': 'Read-only source and existing author receipts. No repeated13 CPU groups, factory execution, six launch fixtures, ROS/DDS/Gazebo/native, or task acceptance.',
    'source_bindings': bindings,
    'observer_source_sha256': EXPECTED_CPP,
    'launch_source_sha256': EXPECTED_LAUNCH,
    'confirmed_lifecycle': [
        'RaySensor::Load70-115 creates and initializes LaserShape before RaySensor::Init calls Sensor::Init.',
        'Sensor::Init161-173 invokes LoadPlugin; LoadPlugin330-349 invokes the real SensorPlugin::Load then Init.',
        'Dynamic spawning SensorManager::Update291-297 calls sensor.Init before container.AddSensor; startup initializes sensor containers before RunThreads.',
        'The new source registers in SensorPlugin::Load, so its own sensor is not yet being updated by that container. No delayed manager discovery or private lock is used.',
        'Sensor::Fini clears plugins before RaySensor::Fini clears LaserShape; weak sensor/model references avoid an ownership cycle and the callback keeps State alive while emitting.'
    ],
    'confirmed_cache_and_time_semantics': [
        'MultiRayShape.Update168-189 resets full length/retro, builds global cast endpoints and does the actual collision update before Sensor Updated callback.',
        'SetLength changes contact length and relative endpoint but does not shorten GlobalPoints.end; the observer names these fields differently.',
        'CollisionName is not reset on no-hit scans. Only finite0<=length<fullRange with nonempty label is identified as a current collision; other cached labels may be stale.',
        'RaySensor.UpdateImpl353-360 assigns LastMeasurementTime after collision checks and uses it for the Gazebo LaserScan message time. Updated runs after UpdateImpl returns.',
        'That timestamp is not an atomic original-cast time, and endpoint generation, collision checks, current parent/collision poses and callback world time need not be one snapshot.',
        'Collision SDF/current getters are labelled as such and are not claimed to be native ODE geometry readback. No GetIntersection or other recast occurs.'
    ],
    'confirmed_lock_scope': [
        'SensorContainer.Update787-801 holds its container recursive mutex; nonstrict Sensor.Update279-283 holds mutexLastUpdateTime while invoking Updated.',
        'Callback does not ResetLastUpdateTime, wait for the world thread, call sensor manager, or acquire an additional physics mutex.',
        'The old delayed ModelPlugin registration was superseded because EventT::Signal does not hold the Connect insertion mutex during callback-map traversal. This was a source-level registration race risk, not an observed native failure.',
        'No new lock can retroactively turn cached cast and later current geometry into an atomic snapshot.'
    ],
    'confirmed_launch_scope': [
        'Ray config is an optional strict8-key extension with enabled identity True, fixed library/SHA format, fixed parent/sensor, and a separate0..300s window.',
        'The appended plugin is inside the unique base_scan/hls_lfcd_lds ray sensor; sensor geometry/noise/pose/driver tags are untouched.',
        'Removing the exact new block restores the original model string. With no ray extension, prior binding and spawn bytes remain unchanged.',
        'Existing physics observer0..1ms window does not shorten the independent ray window. Four-step capture does not receive32step/e61c or matrix credit.'
    ],
    'author_receipts_reviewed_not_reexecuted': {
        'actual_SDK_build_cpu_factory': str(CHECKS),
        'reported_groups': 13,
        'factory_scope': 'Actual .so dlopen/RegisterPlugin/GetType==SENSOR_PLUGIN, without Load or initialization.',
        'launch_actual_SDF_fixtures': str(INJECTION),
        'reported_tests': 6,
        'earlier_ModelPlugin_builds_retained_by_author': True
    },
    'remaining_limits': [
        'Actual sensor Load/callback delivery, per-scan cache/raw CDR matching, loaded-library/process admission, and normal native closure still require the prospective capture.',
        'Direct SensorPlugin registration avoids the observer delayed-registration window; it does not guarantee the external best-effort CDR recorder receives every first scan.',
        'Passive diagnostic still adds CPU/IO and callback time; no absolute noninterference theorem is claimed.',
        'Missing cache/raw packets, duplicate/missing measurement stamps, diagnostic errors or unavailable collision geometry must remain explicit, not filled by assumed current poses.'
    ],
    'posthoc_analysis_design_only': [
        'Join robot/scoped sensor identity and exact measurement stamp to received raw LaserScan header; inspect all360 beams and unique stamps.',
        'Compare recorded final_sensor_range binary64 converted to binary32 with actual CDR beam values; preserve nonfinite classes/representation limits and unmatched best-effort packets as unknown.',
        'Count all current-shortened hit collision names, retaining no-hit stale labels separately; do not recast rays.',
        'Near raw source to processed public pose/TF/occupied100 uses the existing V20 small method with aggregate-map and public-pose proxy limits.',
        'Do not project later current getters back onto original cached cast or claim task/matrix/solver-repair success from this descriptive diagnostic.'
    ],
    'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'wall_seconds': time.monotonic() - start
}
for path, value in bindings.items():
    source = Path(path)
    assert hashlib.sha256(source.read_bytes()).hexdigest() == value['sha256']
    after = source.stat()
    assert value['before_stat'] == {k: getattr(after, k) for k in value['before_stat']}
    value['stable_before_after'] = True
with OUT.open('x') as stream:
    json.dump(report, stream, indent=2, sort_keys=True, allow_nan=False)
    stream.write('\n')
print(json.dumps({'output': str(OUT), 'sha256': hashlib.sha256(OUT.read_bytes()).hexdigest(),
                  'source_interface_review_passed': True, 'bindings': len(bindings),
                  'no_native_or_author_tests_executed': True}, sort_keys=True))
