"""Prospective integration/static checks; mocked Git bytes are not source admission."""
import ast
import copy
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
A18 = ROOT / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
              'report/assets/20261018_mr3_p2a0_v18')
MODULE_SPEC = importlib.util.spec_from_file_location(
    'proposed_preflight', HERE / 'proposed_preflight_v1.py')
PREFLIGHT = importlib.util.module_from_spec(MODULE_SPEC)
MODULE_SPEC.loader.exec_module(PREFLIGHT)


class PreflightAndRunner(unittest.TestCase):
    def exercise(self, *, missing=False, bad_source=False, bad_executable=False):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            assets = root / 'assets'
            source = assets / 'independent/mr3_p2a0_v19_live_admission_v1.py'
            source.parent.mkdir(parents=True)
            raw = (HERE / 'proposed_live_admission_v1.py').read_bytes()
            source.write_bytes(raw)
            relative = str(source.relative_to(root))
            binding = {'path': relative, 'sha256': hashlib.sha256(raw).hexdigest()}
            if bad_source:
                binding['sha256'] = '0' * 64
            plan = json.loads((HERE / 'gazebo_executable_plan_fragment_v1.json').read_text())
            plan['independent_source_bindings'] = [] if missing else [binding]
            if bad_executable:
                plan['gazebo_executable']['sha256'] = '0' * 64
            # Isolate the unavailable future Git object only. The real frozen()
            # SHA comparison, real source import and actual ELF checks execute.
            with mock.patch.object(PREFLIGHT, 'ROOT', root), \
                    mock.patch.object(PREFLIGHT, 'A', assets), \
                    mock.patch.object(PREFLIGHT, 'git_raw', return_value=raw) as git:
                result = PREFLIGHT.check_gazebo_executable('1' * 40, plan)
                git.assert_called_once_with('1' * 40, relative)
                return result

    def test_bound_current_source_dispatch_executes_real_corrected_witness(self):
        result = self.exercise()
        self.assertEqual(result['resolved_path'], '/usr/bin/gzserver-11.10.2')
        self.assertEqual(result['bytes'], 159232)

    def test_missing_corrected_source_binding_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'one frozen source binding'):
            self.exercise(missing=True)

    def test_wrong_corrected_source_sha_is_rejected_before_dispatch(self):
        with self.assertRaisesRegex(ValueError, 'frozen binding differs'):
            self.exercise(bad_source=True)

    def test_bound_current_source_still_rejects_wrong_executable_sha(self):
        with self.assertRaisesRegex(ValueError, 'ELF/SHA/size differs'):
            self.exercise(bad_executable=True)

    def test_preflight_inverse_ast_preserves_every_old_gate(self):
        old = ast.parse((HERE / 'original_preflight_draft.py').read_text())
        tree = ast.parse((HERE / 'proposed_preflight_v1.py').read_text())
        tree.body = [node for node in tree.body if not (
            isinstance(node, ast.FunctionDef) and node.name == 'check_gazebo_executable')]
        removed_call = 0
        for node in tree.body:
            if not isinstance(node, ast.FunctionDef) or node.name != 'main':
                continue
            body = []
            for statement in node.body:
                if (isinstance(statement, ast.Assign) and any(
                        isinstance(target, ast.Name) and target.id == 'gazebo_executable'
                        for target in statement.targets)):
                    removed_call += 1
                    continue
                body.append(statement)
            node.body = body
            for child in ast.walk(node):
                if isinstance(child, ast.Dict):
                    pairs = [(key, value) for key, value in zip(child.keys, child.values)
                             if not (isinstance(key, ast.Constant)
                                     and key.value == 'gazebo_executable')]
                    child.keys, child.values = map(list, zip(*pairs)) if pairs else ([], [])
        self.assertEqual(removed_call, 1)
        self.assertEqual(ast.dump(old, include_attributes=False),
                         ast.dump(tree, include_attributes=False))

    def test_runner_is_only_v18_to_v19_mechanical_version_derivation(self):
        old = (A18 / 'independent/mr3_p2a0_v18_run_diagnostics_v1.py').read_text()
        actual = (HERE / 'runner_v19_draft_snapshot.py').read_text()
        self.assertEqual(ast.dump(ast.parse(old), include_attributes=False),
                         ast.dump(ast.parse(actual.replace('v19', 'v18')),
                                  include_attributes=False))

    def test_exact_budget_and_stage_paths_domains_ports(self):
        plan = json.loads((HERE / 'plan_v19_draft_snapshot.json').read_text())
        budget = plan['budget']
        self.assertEqual(Decimal(str(budget['max_native_launcher_wall_seconds'])),
                         Decimal('2749.0'))
        self.assertEqual(Decimal(str(budget['stage_wall_ceiling_seconds'])),
                         Decimal('1374.5'))
        self.assertEqual(sum(Decimal(str(row['native_wall_ceiling_seconds']))
                             for row in plan['stages']), Decimal('2749.0'))
        for stage, name, domain, port in zip(plan['stages'], ('baseline', 'iters150'),
                                             (154, 156), (13361, 13371)):
            self.assertEqual((stage['stage'], stage['domain'], stage['port'], stage['steps']),
                             (name, domain, port, 32))
            command = stage['command']
            for option, expected in [('--base-domain', str(domain)), ('--base-port', str(port)),
                                     ('--steps', '32'), ('--run-id', stage['run_id']),
                                     ('--schedule', 'open:101'),
                                     ('--preparation-probe-version', 'mr3-p2a0-outward-cancel-v6')]:
                self.assertEqual(command[command.index(option) + 1], expected)
            self.assertEqual(Path(stage['run_directory']).name,
                             'mr3_p2a0_20261018_v19_' + name)
            self.assertEqual(Path(stage['configuration']).name, name + '.json')
            self.assertIn('/20261018_mr3_p2a0_v19/', stage['configuration'])
            self.assertEqual(command[1],
                             'MR3_PHYSICS_DIAGNOSTIC_CONFIG_FILE=' + stage['configuration'])
        self.assertEqual((budget['max_native_runs'], budget['max_saved_api_records']), (2, 66))
        carried = plan['cumulative_diagnostic_budget']
        self.assertGreaterEqual(Decimal('3600') - Decimal(str(carried['charged_before_v19_seconds'])),
                                Decimal('2749.0'))

    def test_all_old152_bindings_and_original_gates_still_exact(self):
        old = json.loads((A18 / 'predeclared_plan_v18.json').read_text())
        plan = json.loads((HERE / 'plan_v19_draft_snapshot.json').read_text())
        self.assertEqual(len(old['independent_source_bindings']), 152)
        self.assertEqual(plan['independent_source_bindings'], old['independent_source_bindings'])
        self.assertEqual(plan['original_gates_preserved'], old['original_gates_preserved'])
        self.assertEqual(plan['diagnostic_libraries'], old['diagnostic_libraries'])
        for key in ('original_driver', 'new_diagnostic_build_receipt', 'drive_contract',
                    'shim_runtime_custody', 'scope_of_solver_type_proof'):
            self.assertEqual(plan[key], old[key])
        for previous, current in zip(old['stages'], plan['stages']):
            before = copy.deepcopy(previous['diagnostic_consumers'])
            after = json.loads(json.dumps(current['diagnostic_consumers']).replace('v19', 'v18'))
            self.assertEqual(before, after)


if __name__ == '__main__':
    unittest.main(verbosity=2)
