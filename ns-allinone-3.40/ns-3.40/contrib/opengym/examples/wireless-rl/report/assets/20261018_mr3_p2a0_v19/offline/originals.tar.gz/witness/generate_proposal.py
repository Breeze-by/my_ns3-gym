"""Generate a prospective witness patch; never edits canonical sources."""
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/zhuyulab/ns3-workspace')
OUT = Path(__file__).resolve().parent
A18 = ROOT / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
              'report/assets/20261018_mr3_p2a0_v18')
SOURCE = A18 / 'independent/mr3_p2a0_v18_live_admission_v1.py'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


NEW_FUNCTIONS = '''def declared_gazebo_executable(spec):
    """Bind the explicit executable entity and bytes before launch."""
    require(type(spec) is dict and set(spec) == {
        "path", "resolved_path", "sha256", "bytes"},
        "gazebo executable declaration fields differ")
    declared = Path(spec["path"])
    require(declared.is_absolute() and str(declared) == spec["path"],
            "gazebo executable path must be absolute canonical syntax")
    resolved = declared.resolve(strict=True)
    require(str(resolved) == spec["resolved_path"],
            "declared gazebo executable resolved path changed")
    raw, proof = read(declared)
    require(type(spec["bytes"]) is int and spec["bytes"] > 0
            and len(raw) == spec["bytes"]
            and raw.startswith(b"\\x7fELF") and proof["sha256"] == spec["sha256"],
            "declared gazebo executable ELF/SHA/size differs")
    return {**proof, "resolved_path": str(resolved),
            "package_provenance": {"available": False,
                "scope": "not needed for executable entity/SHA admission"}}


def executable_identity(actual_executable_path, spec):
    """Use the process executable entity, never a guessed executable basename."""
    declared = declared_gazebo_executable(spec)
    require(os.path.samefile(actual_executable_path, spec["path"]),
            "observer process executable differs from declared gazebo entity")
    require(str(Path(actual_executable_path).resolve(strict=True))
            == declared["resolved_path"],
            "observer process executable resolved path differs")
    raw, actual = read(actual_executable_path)
    require(actual["sha256"] == declared["sha256"],
            "observer process executable SHA differs")
    return {"declaration": declared, "actual": actual,
            "actual_resolved_path": str(Path(actual_executable_path).resolve(strict=True)),
            "samefile": True, "scope": "same live executable entity and SHA; PID/start/ancestry checked separately"}


'''


def main():
    before = SOURCE.read_bytes()
    original = before.decode()
    marker = '\n\ndef mapped(raw, path):\n'
    assert original.count(marker) == 1
    changed = original
    changed = changed.replace(marker, '\n\n' + NEW_FUNCTIONS + 'def mapped(raw, path):\n', 1)
    old_line = '    require(Path(f"/proc/{pid}/exe").resolve(strict=True).name == "gzserver", "observer PID is not gzserver")\n'
    assert changed.count(old_line) == 1
    changed = changed.replace(old_line, '    executable_proof = executable_identity(f"/proc/{pid}/exe", plan["gazebo_executable"])\n', 1)
    old_proof = '            "maps_path": str(maps_path), "maps_sha256": sha(maps_raw),\n'
    assert changed.count(old_proof) == 1
    changed = changed.replace(old_proof, '            "executable": executable_proof,\n' + old_proof, 1)
    executable = Path('/usr/bin/gzserver')
    executable_raw = executable.read_bytes()
    specification = {'path': str(executable), 'resolved_path': str(executable.resolve(strict=True)),
                     'sha256': sha(executable_raw), 'bytes': len(executable_raw)}
    files = {
        'original_v18_live_admission_v1.py': before,
        'proposed_live_admission_v1.py': changed.encode(),
        'gazebo_executable_plan_fragment_v1.json':
            (json.dumps({'gazebo_executable': specification}, indent=2) + '\n').encode(),
        'preflight_insertion_v1.py': (
            '# Insert after the frozen live-witness module is loaded as witness_module.\n'
            '# This is a prelaunch executable/entity/SHA check only; no Gazebo execution.\n'
            'gazebo_executable = witness_module.declared_gazebo_executable(plan["gazebo_executable"])\n'
            '# Preserve gazebo_executable in the output preflight receipt.\n').encode(),
    }
    for name, raw in files.items():
        with (OUT / name).open('xb') as stream:
            stream.write(raw)
    assert SOURCE.read_bytes() == before
    proof = {'schema': 'mr3-witness-executable-proposal-v1',
             'scope': 'prospective CPU proposal; V18 original failure remains unchanged',
             'canonical_source': str(SOURCE), 'canonical_source_sha256': sha(before),
             'canonical_source_unchanged': True,
             'files': [{'path': str(OUT / name), 'sha256': sha(raw), 'bytes': len(raw)}
                       for name, raw in files.items()]}
    with (OUT / 'generation_receipt_v1.json').open('x') as stream:
        json.dump(proof, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'passed': True, 'proposed_source_sha256': sha(changed.encode()),
                      'gazebo_executable': specification}))


if __name__ == '__main__':
    main()
