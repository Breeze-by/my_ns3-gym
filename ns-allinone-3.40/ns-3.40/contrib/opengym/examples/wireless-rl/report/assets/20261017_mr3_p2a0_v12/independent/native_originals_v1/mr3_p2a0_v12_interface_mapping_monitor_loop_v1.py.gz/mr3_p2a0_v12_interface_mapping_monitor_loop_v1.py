"""Read-only V12 monitoring:35s until two full proofs/epoch, then120s status only."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

ROOT=Path('/home/zhuyulab/ns3-workspace')
FREEZE='6b1b4a0108351f5bfb70ec0c96ba895248d4f7a8'
SCRIPT=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v10/independent/mr3_readonly_v10_drive_process_monitor.py'
SCRIPT_SHA='7126969f615d768c5b8fe18039ffd5e0f9d090941e7a857e75b2c44436fb3d13'
LAUNCH=Path('/tmp/mr3_p2a0_v12_interface_launch.json')
BINARY=Path('/tmp/mr3_p2a0_v12_binaryproof.json')
RUN=ROOT/'ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261017_v12_interface'
CALLS=Path('/tmp/mr3_p2a0_v12_interface_monitor_calls_v1.jsonl')
assert not CALLS.exists()
index=1
proof_counts={}
started=time.monotonic()
prior_state=None
with CALLS.open('x')as calls:
    while time.monotonic()-started<2400:
        try:
            launch=json.loads(LAUNCH.read_bytes())if LAUNCH.exists()else None
        except json.JSONDecodeError:
            launch=None
        state=launch.get('status')if launch else 'awaiting_launch'
        directories=sorted(str(p)for p in RUN.glob('worker*/episode*'))
        enough=bool(directories)and all(proof_counts.get(p,0)>=2 for p in directories)
        if launch and 'benchmark_parent'in launch and BINARY.exists()and(not enough or state in('completed','failed')):
            assert launch['freeze']==FREEZE
            assert hashlib.sha256(SCRIPT.read_bytes()).hexdigest()==SCRIPT_SHA
            output=Path(f'/tmp/mr3_p2a0_v12_interface_process_monitor_{index:03d}.json')
            console=output.with_suffix('.console.log')
            assert not output.exists()and not console.exists()
            command=['/usr/bin/python3',str(SCRIPT),str(RUN),'--launch',str(LAUNCH),'--binary-proof',str(BINARY),'--output',str(output)]
            with console.open('x')as stream:
                process=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1'),timeout=30)
            data=json.loads(output.read_bytes())if output.exists()else{}
            processes={row['identity']['pid']:row['identity']for row in data.get('owned_current_processes',[])}
            good=[]
            for gazebo in data.get('gazebo_mapped_libraries',[]):
                if(gazebo['new_drive_mapped']and not gazebo['old_system_drive_mapped']and gazebo['identity_still_same_after_maps']and gazebo['mappings']and all(p['matches_declared_binary']for p in gazebo['mappings'])):
                    good.append(gazebo)
            complete=[]
            for episode in data.get('episodes',[]):
                path=episode['directory'];metadata=Path(path)/'supervisor_metadata.json'
                if not metadata.exists():continue
                worker=json.loads(metadata.read_bytes())['worker_identity'];ancestry=False
                for gazebo in good:
                    pid=gazebo['identity']['pid'];seen=set()
                    while pid in processes and pid not in seen:
                        seen.add(pid);identity=processes[pid]
                        if(identity['pid'],identity['start_ticks'])==(worker['pid'],worker['start_ticks']):ancestry=True
                        pid=identity['parent']
                roles=all(all(episode['drivers'][name].get(k)is True for k in('available','compiled_match','library_match','tagged_match'))for name in('tb1','tb2','tb3'))
                evidence=all(episode['evidence'].get(name,{}).get('valid')is True for name in('drive_topology','model_tb1','model_tb2','model_tb3'))
                if ancestry and roles and evidence and not data.get('errors'):
                    proof_counts[path]=proof_counts.get(path,0)+1
                    complete.append({'directory':path,'worker_identity':worker,'proof_count':proof_counts[path]})
            row={'capture':index,'state':state,'argv':command,'returncode':process.returncode,'output':str(output),'output_sha256':hashlib.sha256(output.read_bytes()).hexdigest()if output.exists()else None,'mapped_gz':[g['identity']for g in good],'complete_episode_proofs':complete,'errors':data.get('errors',[]),'wall_monotonic_ns':time.monotonic_ns()}
            calls.write(json.dumps(row)+'\n');calls.flush();print(json.dumps(row),flush=True);index+=1
            if state in('completed','failed'):break
            enough=bool(directories)and all(proof_counts.get(p,0)>=2 for p in directories)
            if enough:print(json.dumps({'paused_same_epoch_repeat_capture':True,'proof_counts':proof_counts,'status_poll_seconds':120}),flush=True)
        elif state!=prior_state:
            print(json.dumps({'state':state,'read_only':True,'proof_counts':proof_counts}),flush=True)
        prior_state=state
        time.sleep(120 if enough else 35)
print(json.dumps({'read_only_loop_complete':True,'captures':index-1,'proof_counts':proof_counts,'wall_seconds':time.monotonic()-started,'native_process_control':False}),flush=True)
