import pathlib,subprocess,os,time,json,hashlib,datetime
R=pathlib.Path("/home/zhuyulab/ns3-workspace");T=pathlib.Path("/tmp");helper=T/"mr3_p2a0_v17_archive_offline_originals_v1.py";sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();plan=R/"ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v17/predeclared_plan_v17.json"
assert sha(helper)=="0b15f22b00b24010d2aadbfbeee873dc201e7dd74c6a5ad47de94e44ed2d90c6"
assert sha(plan)=="de619095444706e83d59704928ccdcd099dd18d9222b20ed5cff34a1d135430f"
argv=["/usr/bin/python3",str(helper),"--writers-stopped"];console=T/"mr3_p2a0_v17_offline_publish_v1.log";receipt=T/"mr3_p2a0_v17_offline_publish_receipt_v1.json";assert not console.exists() and not receipt.exists()
env=os.environ.copy();env.pop("PYTHONPATH",None);env.update(PYTHONNOUSERSITE="1",PYTHONDONTWRITEBYTECODE="1");started=datetime.datetime.now(datetime.timezone.utc).isoformat();begin=time.monotonic()
with console.open("xb") as f:r=subprocess.run(argv,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,check=False)
record=dict(argv=argv,cwd=str(R),env={"PYTHONPATH":"unset","PYTHONNOUSERSITE":"1","PYTHONDONTWRITEBYTECODE":"1"},started_utc=started,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),returncode=r.returncode,wall_seconds=time.monotonic()-begin,console=str(console),console_sha256=sha(console),source_sha256=sha(helper),plan_sha256=sha(plan),plan_unchanged=sha(plan)=="de619095444706e83d59704928ccdcd099dd18d9222b20ed5cff34a1d135430f")
with receipt.open("x") as f:json.dump(record,f,indent=2);f.write("\n")
print(json.dumps(record,indent=2));print(console.read_text());raise SystemExit(r.returncode)
