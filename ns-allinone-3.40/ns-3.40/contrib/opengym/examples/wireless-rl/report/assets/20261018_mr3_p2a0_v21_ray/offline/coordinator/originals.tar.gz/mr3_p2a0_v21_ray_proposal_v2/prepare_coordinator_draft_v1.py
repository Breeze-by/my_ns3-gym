"""Deterministic TMP-only derivation; never executes a coordinator or native child."""
import copy
import hashlib
import json
from pathlib import Path

ROOT=Path('/home/zhuyulab/ns3-workspace')
W=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
OLD=W/'report/assets/20261018_mr3_p2a0_v20_sensor'
NEW=W/'report/assets/20261018_mr3_p2a0_v21_ray'
D=Path(__file__).parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def transformed(text):
    return text.replace('20261018_mr3_p2a0_v20_sensor','20261018_mr3_p2a0_v21_ray').replace('mr3_p2a0_v20_sensor','mr3_p2a0_v21_ray').replace('predeclared_plan_v20_sensor','predeclared_plan_v21_ray')

parent=transformed(Path('/tmp/mr3_p2a0_v20_sensor_coordinator_proposal_v2/mr3_p2a0_v20_sensor_run_v1.py').read_text())
parent=parent.replace("ROS_DOMAIN_ID='170'","ROS_DOMAIN_ID='174'").replace('127.0.0.1:13451','127.0.0.1:13471')
parent=parent.replace("<=900.","<=350.").replace('exceeds900','exceeds350')
parent=parent.replace("live=load(OLD_A/'independent/mr3_p2a0_v19_live_admission_v1.py','sensor_live_witness')", "live=load(A/'independent/mr3_p2a0_v21_ray_live_admission_v1.py','ray_live_witness')")
parent=parent.replace('One opt-in startup sensor collection','One opt-in actual ray-cache collection')
parent=parent.replace('\ndef execute_capture(', '\n'+(D/'ray_availability_function.py').read_text()+'\n\ndef execute_capture(')
parent=parent.replace("    record.update(status='completed',capture_process_completed=not record['errors'],passed=not record['errors'],", "    try:\n        metadata,_=read(Path(stage['run_directory'])/'worker0/episode001_open_101/metadata.json')\n        proof,_=read(watch['proof']['path'])\n        expected={**plan['ray_library'],'process_id':proof['owned_gzserver']['pid']}\n        ray=ray_availability(Path(stage['run_directory'])/'worker0/episode001_open_101',metadata['epoch'],expected)\n    except Exception as error:\n        ray={'passed':False,'errors':[repr(error)]}\n    record['ray_measurement_availability']=ray\n    record.update(status='completed',capture_process_completed=not record['errors'],passed=not record['errors'] and ray['passed'],")
parent=parent.replace("pass_scope='Ready/recording/normal-stop/no-write-identity-error/strict-native-close only; measurement availability separately retained.'", "pass_scope='Process closure plus perrobot basic ray configuration/connected/complete360scan/noerror; original scientific physics verdict separately retained.'")
(D/'mr3_p2a0_v21_ray_run_v1.py').write_text(parent)

pre=transformed((OLD/'independent/mr3_p2a0_v20_sensor_preflight_v1.py').read_text())
pre=pre.replace("witness_path = OLD_A / 'independent/mr3_p2a0_v19_live_admission_v1.py'", "witness_path = A / 'independent/mr3_p2a0_v21_ray_live_admission_v1.py'")
pre=pre.replace('170','174').replace('13451','13471').replace('49900','50900').replace('50149','51149')
pre=pre.replace('900.','350.').replace("previous_v18_v19_charged_wall_seconds", "previous_v18_v19_v20_charged_wall_seconds").replace('2489.3860735194758','2718.6609461181798')
insert='''\n\ndef check_ray(freeze, plan, configuration):
    expected = plan['ray_library']
    fixed = ROOT/'ros2_ws/ros2-multi-robot-automap/install/multi_robot/lib/libmr3_ray_provenance_observer.so'
    require(expected['installed_path'] == str(fixed) and expected['plugin_type'] == 'SensorPlugin',
            'only fixed SensorPlugin target permitted')
    source = frozen(freeze, {'path': expected['source_path'], 'sha256': expected['source_sha256']})
    actual = fixed.read_bytes()
    require(actual.startswith(b'\\x7fELF') and sha(actual) == expected['library_sha256']
            and len(actual) == expected['library_bytes']
            and str(fixed.resolve(strict=True)) == expected['installed_resolved_path'],
            'actual ray SensorPlugin ELF/path differs')
    encoded = frozen(freeze, expected['archived_library_binding'])
    require(gzip.decompress(encoded) == actual and sha(source).encode() in actual,
            'ray archive/compiled source differs')
    receipt = json.loads(frozen(freeze, plan['ray_build_receipt']))
    require(receipt['passed'] is True\n            and receipt['source_after']['sha256'] == expected['source_sha256']\n            and receipt['installed_new_library'] == {\n                'path': str(fixed), 'resolved': expected['installed_resolved_path'],\n                'bytes': expected['library_bytes'], 'sha256': expected['library_sha256']},\n            'ray canonical build receipt source/actual ELF differs')\n    custody = json.loads(frozen(freeze, plan['ray_binary_receipt_binding']))\n    require(custody['decoded_sha256'] == sha(actual) and custody['decoded_bytes'] == len(actual)\n            and custody['encoded_sha256'] == sha(encoded)\n            and custody['source_cpp_sha256'] == expected['source_sha256'],\n            'ray binary custody receipt differs')
    require(configuration['capture_start_ns'] == 0 and configuration['capture_end_ns'] == 1000000,
            'old observer measurement window must be explicitly one millisecond')
    require(configuration['ray_provenance'] == {
        'enabled': True, 'library': str(fixed), 'source_sha256': expected['source_sha256'],
        'library_sha256': expected['library_sha256'], 'start_ns': 0, 'end_ns': 300000000000,
        'sensor_link': 'base_scan', 'sensor_name': 'hls_lfcd_lds'}, 'fixed ray config differs')
    return {'source_sha256': sha(source), 'actual_elf_sha256': sha(actual),
            'actual_elf_bytes': len(actual), 'plugin_type': 'SensorPlugin',
            'scope': 'Source/archive/actual ELF identity only; live mapped Load evidence still required.'}
'''
pre=pre.replace('\ndef main():', insert+'\n\ndef main():')
pre=pre.replace("    for stage in plan['stages']:\n", "    ray_libraries = {}\n    for stage in plan['stages']:\n")
pre=pre.replace("        for name in ('observer', 'profile'):\n            expected = libraries[name]", "        ray_libraries[stage['stage']] = check_ray(freeze, plan, config)\n        for name in ('observer', 'profile'):\n            expected = libraries[name]")
pre=pre.replace("'new_diagnostic_build_receipt': plan['new_diagnostic_build_receipt'],", "'new_diagnostic_build_receipt': plan['new_diagnostic_build_receipt'],\n        'ray_library': ray_libraries,")
(D/'mr3_p2a0_v21_ray_preflight_v1.py').write_text(pre)

plan=json.loads((OLD/'predeclared_plan_v20_sensor.json').read_bytes())
oldbindings=copy.deepcopy(plan['independent_source_bindings'])
plan=json.loads(transformed(json.dumps(plan)))
# Keep every existing frozen source/ELF/archive entity; only new coordinator/config paths change.
for key in ('diagnostic_libraries','new_diagnostic_build_receipt','drive_contract','shim_runtime_custody','original_driver','gazebo_executable'):
    plan[key]=json.loads((OLD/'predeclared_plan_v20_sensor.json').read_bytes())[key]
original_contract=json.loads((OLD/'predeclared_plan_v20_sensor.json').read_bytes())['recorder_contract']
for key in ('source_path','source_sha256','executable_path','executable_sha256','executable_bytes','archived_binary_binding','command'):
    plan['recorder_contract'][key]=original_contract[key]
plan['independent_source_bindings']=oldbindings
plan['schema']='mr3-p2a0-isolated-ray-provenance-diagnostic-v21'
plan['status']='draft_not_native_admission'
plan['source_base']='4f8bd0e509e6f958c5993a50008955afac72c345'
plan['purpose']='One finite actual cached-ray collision provenance plus existing raw CDR capture; no production150/SLAM/map repair selection, no32step/four-stage/PPO credit.'
plan['pending']=['root promotion and audited mutable runtime launch/CMake bindings','root final review and actual exact40 source/archive admission','clean pushed actual exact40 source admission']
plan['new_source_bindings_pending']=list(plan['pending'])
plan['final_cpu_checks']={'status':'pending_new_focused_checks','old14_scope':'Immutable V20 offline only; not rerun or relabeled V21.'}
plan.pop('launcher_binding_correction',None)
budget=plan['budget'];budget['max_native_launcher_wall_seconds']=350.
budget.pop('previous_v18_v19_charged_wall_seconds')
budget['previous_v18_v19_v20_charged_wall_seconds']=2718.6609461181798
budget['max_cumulative_after_this_ceiling_seconds']=3068.6609461181798
budget.pop('unused_if_entire900_charged_seconds')
budget['unused_if_entire350_charged_seconds']=531.3390538818202
budget['native_ceiling_scope']='No parent signals/retry; actual natural native duration charged and exceeding350 is FAIL, never hidden.'
stage=plan['stages'][0];stage.update(domain=174,port=13471,native_wall_ceiling_seconds=350.)
oldrun=stage['run_id'];stage['run_id']='mr3_p2a0_20261018_v21_ray';stage['run_directory']=str(Path(stage['run_directory']).with_name(stage['run_id']))
stage['command']=[v.replace(oldrun,stage['run_id']) for v in stage['command']]
i=stage['command'].index('--base-domain');stage['command'][i+1]='174'
i=stage['command'].index('--base-port');stage['command'][i+1]='13471'
for job in stage['diagnostic_consumers']:
    job['command']=[v.replace(oldrun,stage['run_id']) for v in job['command']]
config=json.loads((OLD/'configuration/iters150.json').read_bytes())
config['run_directory']=stage['run_directory'];config['capture_end_ns']=1000000
config['ray_provenance']={'enabled':True,'library':str(ROOT/'ros2_ws/ros2-multi-robot-automap/install/multi_robot/lib/libmr3_ray_provenance_observer.so'),
    'source_sha256':'65b1c1db64861366811266580daf8cf43bcf565fc856a405f473b02bdefd082c',
    'library_sha256':'b76138132ae7dbb35936c2e0971e909f688189d240de3910516157b3553d57b8','sensor_link':'base_scan','sensor_name':'hls_lfcd_lds','start_ns':0,'end_ns':300000000000}
recorder=json.loads((OLD/'configuration/recorder_template.json').read_bytes())
for key in ('run_directory','output_directory','ready_path','stop_marker'):
    recorder[key]=transformed(recorder[key]).replace(oldrun,stage['run_id'])
recorder['expected_domain_id']=174
(D/'configuration').mkdir(exist_ok=True)
for name,value in [('iters150.json',config),('recorder_template.json',recorder)]:
    raw=(json.dumps(value,indent=2)+'\n').encode();(D/'configuration'/name).write_bytes(raw)
    bind={'path':str((NEW/'configuration'/name).relative_to(ROOT)),'sha256':sha(raw)}
    if name=='iters150.json':stage['configuration_binding']=bind
    else:plan['recorder_contract']['config_template_binding']=bind
plan['ray_library']={'plugin_type':'SensorPlugin','source_path':'ros2_ws/ros2-multi-robot-automap/src/multi_robot/src/mr3_ray_provenance_observer.cpp',
 'source_sha256':config['ray_provenance']['source_sha256'],'installed_path':config['ray_provenance']['library'],
 'installed_resolved_path':str(ROOT/'ros2_ws/ros2-multi-robot-automap/build/multi_robot/libmr3_ray_provenance_observer.so'),'library_sha256':'b76138132ae7dbb35936c2e0971e909f688189d240de3910516157b3553d57b8','library_bytes':463272,
 'archived_library_binding':{'path':str((NEW/'binary/libmr3_ray_provenance_observer.so.gz').relative_to(ROOT)),'sha256':'39f729a04c2aac90bdb03e1c292a904a528ad924e5f1061682f6f8ab48ff4529'},'status':'actual_canonical_build_verified_no_native_credit'}
plan['ray_build_receipt']={'path':str((NEW/'binary/canonical_build_receipt_v1.json').relative_to(ROOT)),'sha256':'015487b70f8add3593228d170201a7ba4b122252601bbfdd7f415545c5ec4cc2'}
plan['ray_binary_receipt_binding']={'path':str((NEW/'binary/receipt_v1.json').relative_to(ROOT)),'sha256':'cf589cf183d759a77caae7518c44b810c6186137f1c4b66e6b63a0d774448714'}
plan['ray_basic_measurement_required']={'configuration_per_robot':1,'sensor_connected_per_robot':1,'minimum_complete360_scans_per_robot':1,'diagnostic_errors_allowed':0,'overall_passed':'capture_process_completed AND basic_ray_measurement_passed','scope':'End-of-run required basic availability, notcast/CDR/beam equality or physical scientific gates.'}
plan['measurement_availability_scope']+=' Ray cache current-hit names valid only shortened rays; missing scan/diagnostic_error explicit. Both sources link by actual measurement stamp, not by mapheader. No actor inputs.'
plan['old_observer_window_scope']='Explicit0..1ms only; late-spawn observer may have configuration/capture_complete and no sample. No1ms whole-robot coverage credit; first-boundary profile predicate unchanged.'
plan['historical_bindings_scope']={'baseline_rows':160,'preserved_rows':160,'independent_update_policy':'All160 V20 rows unchanged, including audit_ppo. Runtime baseline only production launch/CMake change; newCPP separatelyadded. No W7 world/task projection, no world/SLAM/map/driver changes.','runtime_updates_pending':['launch actual opt-in SensorPlugin injection','CMake added ray target'], 'new_sources':'Append fixed V21 sources/configs with exact prepared bytes after sealing; actual runtime binding count from final preflight, not guessed103.'}
for name in ('mr3_p2a0_v21_ray_run_v1.py','mr3_p2a0_v21_ray_preflight_v1.py','mr3_p2a0_v21_ray_live_admission_v1.py','test_launch_ray_binding.py','test_ray_witness.py','test_ray_coordinator.py'):
    plan['independent_source_bindings'].append({'path':str((NEW/'independent'/name).relative_to(ROOT)),'sha256':sha((D/name).read_bytes())})
for binding in (stage['configuration_binding'],plan['recorder_contract']['config_template_binding'],plan['ray_build_receipt'],plan['ray_binary_receipt_binding'],plan['ray_library']['archived_library_binding'],{'path':plan['ray_library']['source_path'],'sha256':plan['ray_library']['source_sha256']}):
    plan['independent_source_bindings'].append(binding)
(D/'predeclared_plan_v21_ray.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'created':'TMP-only draft','independent_rows':len(plan['independent_source_bindings']), 'pending':plan['pending']}))
