"""CPU harness injects draft audit only; canonical __file__ lets retained Git test locate root."""
import importlib.util
from pathlib import Path
import sys
import types
import unittest

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
DRAFT = Path('/tmp/mr3_p2a0_v17_stimulus_v6_proposal')
sys.path.insert(0, str(W))
import mr3_learning  # noqa: E402,F401

spec = importlib.util.spec_from_file_location(
    'mr3_learning.audit_preparation', DRAFT / 'audit_preparation.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
tests = types.ModuleType('draft_preparation_comparison_tests')
tests.__file__ = str(W / 'mr3_learning/tests/test_preparation_comparison.py')
exec(compile((DRAFT / 'test_preparation_comparison.py').read_bytes(),
             tests.__file__, 'exec'), tests.__dict__)
result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(tests))
raise SystemExit(0 if result.wasSuccessful() else 1)
