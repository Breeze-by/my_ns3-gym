#!/usr/bin/python3
"""Summarize finished reset receipts; never run auditors or read large raw traces."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re

FREEZE = 'eee6b2f90f697b28a1c20a2af5d1a6d2f044465e'
ROOT = Path('/home/zhuyulab/ns3-workspace')
RUN = ROOT / 'ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261017_v17_reset'
PREFIX = '/tmp/mr3_p2a0_v17_reset_'
ROBOTS = ('tb1', 'tb2', 'tb3')
SCHEDULE = (('open', 101), ('open', 101), ('rooms', 101), ('corridors', 101))
ANGULAR_SHA = '7a472ba7efdd55addc710b98c66c89feff7f5092f214f76fd76cd4ca526343d0'
PHYSICS_SHA = '2516e394f60eac5dd24fd66b51c4c48fc37245090eb1626ebe1c7a3a23f8bafb'
MATRIX_SHA = {'angular_matrix_v1': '8c9f04929cd9a52df0bea22106d64756c42c51350adae9ee20823e0054028901',
              'physics_matrix_v1': '50651f8b8ed5bee161f4c44a18e1ce68f7d8a27cda88fc466756b91f0f35cee8'}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def finite(value):
    return type(value) in (int, float) and math.isfinite(value)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--aggregate', type=Path, default=Path(PREFIX + 'audit_execution_v1.json'))
    parser.add_argument('--aggregate-sha256', required=True)
    parser.add_argument('--output', type=Path, default=Path(PREFIX + 'finished_leaf_summary_v1.json'))
    args = parser.parse_args()
    if args.output.exists():
        parser.error('refuse to replace existing diagnostic')
    if not re.fullmatch('[0-9a-f]{64}', args.aggregate_sha256):
        parser.error('exact completed aggregate SHA256 required')
    bindings = {}
    issues = []

    def read(path, expected=None, jsonl=False):
        path = Path(path)
        if path.stat().st_size > 16 * 1024 * 1024:
            raise ValueError('diagnostic input exceeds small-file limit: ' + str(path))
        raw = path.read_bytes()
        digest = sha(raw)
        if expected is not None and digest != expected:
            raise ValueError('original input SHA differs: ' + str(path))
        bindings[str(path)] = {'bytes': len(raw), 'sha256': digest}
        return [json.loads(line) for line in raw.splitlines() if line] if jsonl else json.loads(raw)

    # No leaf, launch or transitions is read until this original aggregate check passes.
    aggregate = read(args.aggregate, args.aggregate_sha256)
    if (aggregate.get('schema') != 'mr3-p2a0-audit-execution-v17'
            or aggregate.get('freeze') != FREEZE or aggregate.get('stage') != 'reset'
            or aggregate.get('all_submitted_jobs_finished') is not True
            or type(aggregate.get('passed')) is not bool):
        raise ValueError('refuse incomplete or mismatched original reset aggregate')
    receipts = {row['path']: row for row in aggregate['receipts']}
    if len(receipts) != len(aggregate['receipts']):
        raise ValueError('duplicate aggregate receipt paths')
    failed = {row['path'] for row in aggregate['receipts'] if row.get('passed') is not True}
    failed.update(row['output'] for row in aggregate['commands']
                  if row.get('required_success') is True and row.get('passed') is not True)
    leaves = {}
    leaf_status = {}
    for name in ('full_audit', 'input_review_v1', 'physics_matrix_v1',
                 'angular_matrix_v1', 'closure_binary_review_v1'):
        path = PREFIX + name + '.json'
        if path not in receipts or not Path(path).is_file():
            leaf_status[name] = {'path': path, 'available': False}
            issues.append('missing original completed leaf: ' + name)
            continue
        value = read(path, receipts[path]['sha256'])
        if type(value.get('passed')) is not bool:
            raise ValueError('original leaf passed is not typed bool: ' + name)
        if 'freeze' in value and value['freeze'] != FREEZE:
            raise ValueError('original leaf source freeze differs: ' + name)
        if name in MATRIX_SHA and value.get('script_sha256') != MATRIX_SHA[name]:
            raise ValueError('original matrix source differs: ' + name)
        leaves[name] = value
        leaf_status[name] = {'path': path, 'available': True,
                             'passed': value['passed'], **bindings[path]}
    full = leaves.get('full_audit', {})
    native = full.get('native', {})
    physics = leaves.get('physics_matrix_v1', {})
    angular = leaves.get('angular_matrix_v1', {})
    closure = leaves.get('closure_binary_review_v1', {})
    native_rows = {row['directory']: row for row in native.get('episodes', [])}
    closure_rows = {row['directory']: row for row in closure.get('episodes', [])}
    physical_rows = {row['episode']: row for row in physics.get('episodes', [])}
    angular_rows = {row['episode']: row for row in angular.get('episodes', [])}
    expected = {(f'worker{worker}', f'episode{number:03d}_{scene}_{seed}')
                for worker in (0, 1) for number, (scene, seed) in enumerate(SCHEDULE, 1)}
    if set(native_rows) != {str(RUN.joinpath(*identity)) for identity in expected}:
        issues.append('native full leaf does not contain exact eight reset episodes')
    episodes = []
    saved_native_identities = set()
    for worker, episode in sorted(expected):
        directory = RUN / worker / episode
        n = native_rows.get(str(directory))
        if n is None:
            continue
        identity = worker + '/' + episode
        c = closure_rows.get(str(directory), {})
        p = physical_rows.get(identity, {})
        a = angular_rows.get(identity, {})
        variants = [x for x in (directory / 'transitions.jsonl',) if x.is_file()]
        if len(variants) != 1:
            issues.append(identity + ': small plain transitions unavailable')
            continue
        records = read(variants[0], n.get('evidence_sha256', {}).get('transitions.jsonl'), jsonl=True)
        if not records or records[0].get('kind') != 'reset':
            raise ValueError(identity + ': no actual reset record')
        steps = records[1:]
        final = records[-1]
        if any(row.get('kind') != 'step' for row in steps):
            raise ValueError(identity + ': non-step record')
        if final['snapshot']['epoch'] != n['epoch']:
            raise ValueError(identity + ': final received snapshot epoch differs')
        if (len(records) != 33 or len(steps) != 32 or final.get('terminated') is not False
                or final.get('truncated') is not True
                or final.get('info', {}).get('reason') != 'external_sampler_limit'):
            issues.append(identity + ': original 32-step/external-truncation eligibility differs')
        activity = []
        for robot in final['snapshot']['robots']:
            item = {'robot': robot['name'],
                    'estimated_received_path_m': robot['activity'].get('estimated_path_m'),
                    'path_observation_complete': robot['activity'].get('path_observation_complete'),
                    'accepted_goal_count': robot['navigation'].get('accepted_goal_count')}
            activity.append(item)
        if {x['robot'] for x in activity} != set(ROBOTS):
            raise ValueError(identity + ': three actual received robot activity rows missing')
        paths = [x['estimated_received_path_m'] for x in activity]
        minimum_path = min(paths) if all(finite(x) for x in paths) else None
        submitted = 0
        for row in steps:
            info = row['info']
            if 'action_submitted' in info and type(info['action_submitted']) is not bool:
                raise ValueError(identity + ': nonboolean action_submitted')
            submitted += int(info.get('action_submitted', info.get('command') is not None))
        if submitted != n['transitions']['submitted_action_count']:
            issues.append(identity + ': returned command count differs from original native leaf')
        for pair in n.get('processes', {}).get('owned_pid_identities', []):
            if len(pair) != 2 or any(type(x) is not int for x in pair):
                raise ValueError('untyped original PID/start identity')
            saved_native_identities.add(tuple(pair))
        original_angular = a.get('original_angular_audit', {})
        if original_angular and original_angular.get('script_sha256') != ANGULAR_SHA:
            raise ValueError('per-episode original angular consumer differs')
        episodes.append({'worker': worker, 'episode': episode, 'directory': str(directory),
            'epoch': n['epoch'], 'scene': n['scene'], 'seed': n['seed'],
            'actual_reset_records': 1, 'actual_step_api_returns': len(steps),
            'actual_submitted_commands': submitted,
            'task_sampled_physical_time_sec': n['transitions']['sampled_physical_time_sec'],
            'final_terminated': final.get('terminated'), 'final_truncated': final.get('truncated'),
            'final_reason': final.get('info', {}).get('reason'),
            'received_activity': activity, 'minimum_robot_received_path_m': minimum_path,
            'native_original_passed': n.get('passed'),
            'physical_matrix_episode': p,
            'angular_original_scope': {k: original_angular.get(k) for k in
                ('passed', 'sampled_bounds_passed', 'stimulus_coverage_passed', 'missing',
                 'positive_span_robots', 'negative_span_robots',
                 'sequential_opposite_sign_span_robots', 'criteria')},
            'angular_matrix_sampled_bounds_passed': a.get('sampled_bounds_passed'),
            'closure': {k: c.get(k) for k in ('passed', 'native_started', 'native_clean_exits',
                'owned_identity_rows', 'worker_identity', 'supervisor', 'errors')}})
    pooled_coverage = physics.get('robot_stop_coverage', {})
    if physics and not pooled_coverage:
        issues.append('original physics matrix stop coverage absent')
    if physics:
        proof = physics.get('artifact_proof', {}).get('per_episode_report', {})
        # Existing matrix source binding is retained; this helper never runs that consumer.
        physical_source = {'immutable_original_consumer_sha256': PHYSICS_SHA,
                           'source_report': proof, 'source_report_passed': physics.get('source_report_passed')}
    else:
        physical_source = None
    by_robot_min = {}
    for name in ROBOTS:
        values = [robot['estimated_received_path_m'] for ep in episodes
                  for robot in ep['received_activity'] if robot['robot'] == name]
        by_robot_min[name] = min(values) if len(values) == 8 and all(finite(x) for x in values) else None
    identities = closure.get('identities', [])
    saved_union = set()
    for row in identities:
        saved = row['saved']
        pair = (saved['pid'], saved['start_ticks'])
        if any(type(x) is not int for x in pair):
            raise ValueError('untyped formal closure PID/start identity')
        saved_union.add(pair)
    if closure and (len(saved_union) != closure.get('saved_identity_count')
                    or not saved_native_identities.issubset(saved_union)):
        issues.append('formal saved PID/start union/count or native subset differs')
    launch_path = Path(PREFIX + 'launch.json')
    launch = read(launch_path) if launch_path.is_file() else {}
    if launch and (launch.get('freeze') != FREEZE or launch.get('stage') != 'reset'):
        raise ValueError('original launcher identity differs')
    accounting = {'reset_api_calls': sum(x['actual_reset_records'] for x in episodes),
        'returned_step_api_calls': sum(x['actual_step_api_returns'] for x in episodes),
        'actual_submitted_commands': sum(x['actual_submitted_commands'] for x in episodes),
        'task_sampled_physical_time_sec': sum(x['task_sampled_physical_time_sec'] for x in episodes),
        'benchmark_wall_seconds_including_all_attempts': native.get('wall_sec_including_all_attempts'),
        'launcher_wall_seconds': launch.get('wall_duration_sec'),
        'cumulative_matrix_wall_seconds': launch.get('cumulative_wall_seconds')}
    result = {'schema': 'mr3-v17-reset-finished-formal-leaf-summary-v1', 'freeze': FREEZE,
        'aggregate_original_passed': aggregate['passed'], 'all_submitted_jobs_finished': True,
        'runner_errors': aggregate.get('runner_errors'), 'required_failed_outputs': sorted(failed),
        'original_leaf_status': leaf_status, 'diagnostic_consistency_issues': issues,
        'episodes': episodes, 'minimum_received_path_per_robot_across_eight_episodes': by_robot_min,
        'physical_pooled_A_or_B_coverage': pooled_coverage,
        'physical_matrix_original_scope': physics.get('scope'),
        'physical_original_source_binding': physical_source,
        'angular_reset_original_criteria': angular.get('criteria'),
        'angular_reset_original_scope': angular.get('scope'),
        'closure_union': {'original_passed': closure.get('passed'),
            'computed_unique_saved_pid_start_count': len(saved_union),
            'original_saved_identity_count': closure.get('saved_identity_count'),
            'native_ledger_unique_pid_start_count': len(saved_native_identities),
            'original_all_saved_identities_gone': closure.get('all_saved_identities_gone'),
            'same_identity_present_count': sum(row.get('same_identity_present') is True for row in identities),
            'native_started_total': closure.get('native_started_total'),
            'native_clean_exits_total': closure.get('native_clean_exits_total'),
            'original_errors': closure.get('errors')},
        'accounting': accounting, 'original_inputs': bindings,
        'helper_sha256': sha(Path(__file__).read_bytes()),
        'limitations': ['Diagnostic summary of finished original receipts, not a new formal auditor.',
            'Physics stop credit is pooled across the exact eight reset episodes: at least one original A OR B per robot; per-episode missing credit remains missing.',
            'Reset angular gate retains sampled_bounds_passed for every episode; original stimulus_coverage false stays false and is not promoted by pooling.',
            'Received estimated activity is not evaluator truth, 95% success, or trained-policy reliability.',
            'No large raw trace, ModelStates, ROS, process control, native, formal rerun, or canonical mutation.']}
    for path, expected in bindings.items():
        if sha(Path(path).read_bytes()) != expected['sha256']:
            raise ValueError('finished input changed during summary: ' + path)
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'output': str(args.output), 'sha256': sha(args.output.read_bytes()),
        'aggregate_original_passed': aggregate['passed'], 'required_failed_outputs': sorted(failed),
        'diagnostic_consistency_issues': issues, 'episode_count': len(episodes),
        'accounting': accounting}, sort_keys=True))

if __name__ == '__main__':
    main()
