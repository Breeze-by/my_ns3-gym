"""DISABLED fixed external MR3 policy-stage parent; no arbitrary command CLI."""
import time
ENTERED_NS = time.monotonic_ns()
import argparse
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A = W/'report/assets/20261024_mr3_p2a_v71_masked_stimulus_qualification'
BASE = Path('/tmp/mr3_p2a_policy_stage_parent_candidate_v1')
SELF = BASE/'stage_parent_v1.py'
PLAN = A/'plan_v1.json'
QUALIFICATION = Path('/tmp/mr3_p2a_reach_v71_qualification.json')
MATRIX_SUMMARY = Path('/tmp/mr3_p2a_reach_v71_driver_v1/summary.json')
MATRIX_ACCOUNT = Path('/tmp/mr3_p2a_v71_closed_accounting_for_policy_v1.json')
FIXED_G = 'b3707dcf258c832f35ef60f47a5dc8dc52296629'
PYTHON = '/home/zhuyulab/miniconda3/envs/ns3gym/bin/python'
STAGES = ('minimum', 'pilot', 'validation')
CAPS = {'minimum': Decimal('1800'), 'pilot': Decimal('2905.9547395464029'), 'validation': Decimal('9000')}
NATIVE = {'minimum': Decimal('1150'), 'pilot': Decimal('2100'), 'validation': Decimal('8500')}
SCOPE_NAMES = {'minimum': 'engineering', 'pilot': 'pilot', 'validation': 'validation'}
CONTRACT = 'mr3-reach-v1'
ACTUATION = 'initial-zero-encoder-hold-v1'
AUTHORITY = 'mr3-owned-stream-authority-v1'
MASKED = 'mr3-reach-reset-masked-cancel-v1'
PROBE = 'mr3-p2a-reach-masked-cancel-v1'
STABLE = ('st_dev', 'st_ino', 'st_mode', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
SIGNALS = []


class PendingEvidence(ValueError):
    pass


def require(ok, message):
    if not ok:
        raise ValueError(message)


def dec(value):
    require(type(value) in (str, int, float) and type(value) is not bool, 'typed decimal required')
    result = Decimal(str(value))
    require(result.is_finite(), 'finite decimal required')
    return result


def parse(raw):
    def unique(pairs):
        value = {}
        for key, item in pairs:
            require(key not in value, 'duplicate JSON key')
            value[key] = item
        return value
    return json.loads(raw, object_pairs_hook=unique,
        parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite JSON')))


def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n');stream.flush();os.fsync(stream.fileno())


def identity(pid):
    require(type(pid) is int and pid > 0, 'typed observed PID required')
    try:
        tail = Path('/proc', str(pid), 'stat').read_text().rsplit(')', 1)[1].split()
        return dict(pid=pid, start_ticks=int(tail[19]), parent=int(tail[1]),
                    group=int(tail[2]), session=int(tail[3]), state=tail[0])
    except FileNotFoundError:
        return None


def typed_identity(value):
    return type(value) is dict and all(type(value.get(k)) is int and value[k] > 0
                                        for k in ('pid', 'start_ticks'))


def same(left, right):
    return typed_identity(left) and typed_identity(right) and all(left[k] == right[k] for k in ('pid', 'start_ticks'))


def absent(saved):
    require(typed_identity(saved), 'missing original typed PID/start')
    current = identity(saved['pid'])
    require(current is None or current['start_ticks'] != saved['start_ticks'],
            'saved identity still present, including zombie')
    return dict(saved=saved, original_identity_gone=True, observed_monotonic_ns=time.monotonic_ns())


def bound(path, maximum=64*1024*1024, allow_link=False):
    path = Path(path)
    require(path.is_absolute() and '..' not in path.parts, 'absolute fixed path required')
    literal = path.lstat();real = path.resolve(strict=True)
    require(allow_link or real == path, 'metadata/source symlink not admitted')
    before = path.stat()
    require(stat.S_ISREG(before.st_mode) and before.st_size <= maximum, 'not regular or over finite file cap')
    digest = hashlib.sha256();count = 0
    with real.open('rb') as stream:
        require(tuple(getattr(os.fstat(stream.fileno()), k) for k in STABLE) == tuple(getattr(before, k) for k in STABLE),
                'opened object differs')
        for block in iter(lambda: stream.read(1024*1024), b''):
            digest.update(block);count += len(block)
        require(tuple(getattr(os.fstat(stream.fileno()), k) for k in STABLE) == tuple(getattr(before, k) for k in STABLE),
                'object changed while read')
    require(tuple(getattr(path.stat(), k) for k in STABLE) == tuple(getattr(before, k) for k in STABLE)
            and tuple(getattr(path.lstat(), k) for k in STABLE) == tuple(getattr(literal, k) for k in STABLE), 'bound path changed')
    return dict(path=str(path), bytes=count, sha256=digest.hexdigest(), resolved_path=str(real),
        stat=list(getattr(before, k) for k in STABLE), literal_lstat=list(getattr(literal, k) for k in STABLE),
        literal_target=os.readlink(path) if stat.S_ISLNK(literal.st_mode) else None)


def checked_json(reference, fixed_path=None):
    if type(reference) is not dict:
        raise PendingEvidence('real sealed metadata reference is pending')
    path = Path(reference['path'])
    require(fixed_path is None or path == fixed_path, 'metadata belongs to another fixed activity')
    proof = bound(path, 16*1024*1024)
    require(type(reference.get('bytes')) is int and reference['bytes'] == proof['bytes']
            and reference.get('sha256') == proof['sha256'], 'metadata SHA/bytes differ')
    raw = path.read_bytes()
    require(len(raw) == proof['bytes'] and hashlib.sha256(raw).hexdigest() == proof['sha256']
            and bound(path, 16*1024*1024) == proof, 'metadata changed before decode')
    return parse(raw), proof


def git(*args, root=ROOT):
    return subprocess.check_output(['git', *args], cwd=root, stderr=subprocess.PIPE, timeout=15)


def canonical_freeze(freeze, root=ROOT):
    require(type(freeze) is str and re.fullmatch('[0-9a-f]{40}', freeze), 'exact freeze required')
    require(git('rev-parse', 'HEAD', root=root).decode().strip() == freeze ==
            git('rev-parse', 'origin/main', root=root).decode().strip(), 'HEAD/origin/freeze differ')
    require(not git('status', '--porcelain', '--untracked-files=all', root=root), 'canonical tree is not clean')


def state_dir(stage):
    require(stage in STAGES, 'unknown fixed stage')
    return Path('/tmp')/('mr3_p2a_v71_policy_stage_parent_'+stage+'_v1')


def scope_path(stage):
    return BASE/('admission_'+stage+'_v1.json')


def check_scope(scope, stage, freeze):
    require(scope.get('schema') == 'mr3-fixed-policy-stage-admission-v1'
            and scope.get('stage') == stage and scope.get('execution_freeze') == freeze == FIXED_G,
            'wrong fixed stage admission')
    if scope.get('admitted') is not True:
        raise PendingEvidence('DISABLED: Root real stage admission remains pending')
    require(scope.get('decision_maker') == 'Root' and scope.get('numeric_user_approval_claimed') is False
            and scope.get('automatic_next_stage_entry') is False, 'unknown or automatic admission')
    require(scope.get('original_stage_cap_seconds') == str(CAPS[stage])
            and scope.get('internal_tail_seconds') == '500'
            and scope.get('native_ceiling_seconds') == str(NATIVE[stage]), 'original caps changed')
    require(scope.get('fee_scope') == SCOPE_NAMES[stage], 'stage fees reassigned')
    if stage != 'minimum':
        require(scope.get('external_finalize_seconds') == '300', 'original external reserve changed')


def qualification_shape(value, plan, freeze):
    require(value.get('schema') == 'mr3-reach-scientific-qualification-v1'
            and value.get('passed') is True and value.get('freeze') == freeze
            and value.get('mandatory_roles') == 30 and len(value.get('episodes', [])) == 12
            and value.get('plan_sha256') == bound(PLAN)['sha256'], 'actual12EP/30 qualification is pending')
    require(value.get('actuation_profile') == ACTUATION and value.get('motion_authority_profile') == AUTHORITY,
            'qualification actuator/authority differs')
    probe = value.get('probe_masked_cancel_stimulus_replay', {})
    require(value.get('reset_workload_reader_profile') == MASKED and value.get('preparation_probe_version') == PROBE
            and probe.get('schema') == 'mr3-independent-masked-cancel-qualification-v1'
            and probe.get('profile') == MASKED and probe.get('probe_version') == PROBE
            and probe.get('freeze') == freeze and probe.get('passed') is True
            and probe.get('producer_imported_as_oracle') is False and len(probe.get('episodes', [])) == 9,
            'independent actual9 masked probe qualification is pending')
    authority = value.get('motion_authority_replay', {})
    require(authority.get('schema') == 'mr3-independent-motion-authority-qualification-v1'
            and authority.get('profile') == AUTHORITY and authority.get('freeze') == freeze
            and authority.get('passed') is True and authority.get('raw_generation_known') is False
            and len(authority.get('episodes', [])) == 12, 'independent authority12 proof is pending')
    # The pinned canonical main independently calls validate_qualification again
    # before model construction. This metadata guard is not a new science oracle.


def require_capacity(scope):
    # No concrete capacity parent/verifier exists in the frozen canonical source.
    # Do not invent its future fields or promote {passed: True} to admission.
    raise PendingEvidence('validation disabled: actual full-chain capacity receipt and fixed validator are not implemented in v1')


def settled_fee(stage, started_ns, main_end_ns, final_start_ns, final_end_ns, ended_ns, external):
    require(all(type(x) is int for x in (started_ns, main_end_ns, final_start_ns, final_end_ns, ended_ns))
            and 0 < started_ns <= main_end_ns <= final_start_ns <= final_end_ns <= ended_ns, 'invalid continuous parent interval')
    external = dec(external)
    require((0 < external <= 300) if stage == 'minimum' else external == 300, 'external fee reserve pending/changed')
    main_cap = CAPS[stage] if stage == 'minimum' else CAPS[stage]-external
    cap = CAPS[stage]+external if stage == 'minimum' else CAPS[stage]
    main = Decimal(main_end_ns-started_ns)/10**9
    final = Decimal(final_end_ns-final_start_ns)/10**9
    complete = Decimal(ended_ns-started_ns)/10**9
    return dict(main_seconds=str(main), finalizer_seconds=str(final), complete_parent_seconds=str(complete),
        main_cap_seconds=str(main_cap), external_cap_seconds=str(external), complete_cap_seconds=str(cap),
        main_within_cap=main <= main_cap, finalizer_within_cap=final <= external,
        complete_within_cap=complete <= cap, gaps_included=True, nested_wait_added=False,
        passed=main <= main_cap and final <= external and complete <= cap)


def matrix_accounting(scope, metadata):
    ledger, ref = checked_json(scope.get('matrix_accounting'), MATRIX_ACCOUNT);metadata.append(ref)
    summary, ref = checked_json(scope.get('matrix_summary'), MATRIX_SUMMARY);metadata.append(ref)
    require(ledger.get('schema') == 'mr3-engineering-closure-ledger-v1' and ledger.get('passed') is True
            and ledger.get('activity_passed') is True and ledger.get('execution_freeze') == FIXED_G
            and type(ledger.get('actual_root_tool_session_id')) is int and ledger['actual_root_tool_session_id'] == 65935
            and type(ledger.get('actual_root_tool_returncode')) is int and ledger['actual_root_tool_returncode'] == 0
            and ledger.get('actual_before_after_equal') is True
            and ledger.get('all_saved_main_identities_fresh_gone') is True, 'actual closed A71 matrix account is pending')
    require(summary.get('schema') == 'mr3-v71-matrix-parent-result-v1' and summary.get('passed') is True
            and summary.get('execution_freeze') == FIXED_G and summary.get('scientific_qualification') is True
            and summary.get('complete_parent_fee_known') is True and summary.get('source_before')
            and summary['source_before'] == summary.get('source_after'), 'actual matrix summary/source is pending')
    absent(summary['driver_identity'])
    used = dec(ledger['engineering_cumulative_seconds']);fee = dec(ledger['engineering_added_parent_union_seconds'])
    require(dec(ledger['engineering_entry_seconds']) == Decimal('111365.9618345326018')
            and used == dec(ledger['engineering_entry_seconds'])+fee
            and fee == dec(summary['actual_parent_seconds'])
            and dec(ledger['engineering_ceiling_seconds']) == 180000
            and dec(ledger['engineering_remaining_seconds']) == 180000-used,
            'closed matrix continuous fee arithmetic differs')
    external = max(Decimal(0), Decimal(300)-dec(summary['engineering_external_actual_seconds']))
    return used, external


def predecessor_parent(scope, stage, metadata):
    previous = 'minimum' if stage == 'pilot' else 'pilot'
    directory = state_dir(previous)
    summary, ref = checked_json(scope.get('predecessor_parent'), directory/'summary.json');metadata.append(ref)
    reap, ref = checked_json(scope.get('predecessor_root_reap'), directory/'root_actual_reap_v1.json');metadata.append(ref)
    require(summary.get('schema') == 'mr3-fixed-policy-stage-parent-summary-v1' and summary.get('stage') == previous
            and summary.get('freeze') == FIXED_G and summary.get('passed') is True
            and summary.get('all_submitted_waits_drained') is True and summary.get('source_before_after_equal') is True
            and summary.get('fee', {}).get('passed') is True, 'complete predecessor parent/account is pending')
    require(reap.get('schema') == 'mr3-fixed-policy-stage-parent-root-reap-v1'
            and reap.get('stage') == previous and reap.get('freeze') == FIXED_G
            and reap.get('actual_waited') is True and type(reap.get('actual_returncode_observed')) is int
            and reap['actual_returncode_observed'] == 0 and type(reap.get('actual_tool_session_id')) is int
            and reap['actual_tool_session_id'] > 0 and same(reap.get('saved_parent'), summary['driver_identity'])
            and reap.get('summary_sha256') == bound(directory/'summary.json')['sha256'],
            'real predecessor root tool reap is pending')
    absent(summary['driver_identity'])
    final = summary.get('final_result', {});science = final.get('scientific_result', {})
    require(final.get('passed') is True and final.get('all_saved_identities_gone') is True
            and final.get('strict_custody_passed') is True and type(science.get('optimizer_updates')) is int
            and science['optimizer_updates'] > 0
            and (science.get('eligible_decisions') == 16 if previous == 'minimum'
                 else type(science.get('eligible_decisions')) is int and 2 <= science['eligible_decisions'] <= 64),
            'real eligible predecessor updates/closure are pending')
    return summary


def context(stage, freeze, scope_sha):
    require(Path(__file__).resolve() == SELF and freeze == FIXED_G, 'fixed parent location/freeze differs')
    raw = scope_path(stage).read_bytes();require(hashlib.sha256(raw).hexdigest() == scope_sha, 'sealed admission SHA differs')
    scope = parse(raw);check_scope(scope, stage, freeze)
    require(bound(SELF)['sha256'] == scope.get('parent_source', {}).get('sha256')
            and bound(SELF)['bytes'] == scope['parent_source']['bytes'], 'parent source pin differs')
    canonical_freeze(freeze)
    metadata = [bound(scope_path(stage))]
    runtimes = scope.get('runtime_bindings')
    require(type(runtimes) is list and {row.get('path') for row in runtimes} == {'/usr/bin/python3',PYTHON}
            and len(runtimes) == 2, 'fixed two interpreter byte pins required')
    for reference in runtimes:
        actual = bound(reference['path'], allow_link=True)
        require(actual['sha256'] == reference.get('sha256') and type(reference.get('bytes')) is int
                and actual['bytes'] == reference['bytes'], 'fixed interpreter bytes changed')
        metadata.append(dict(actual, allow_link=True))
    plan, ref = checked_json(scope.get('plan'), PLAN);metadata.append(ref)
    qualification, ref = checked_json(scope.get('qualification'), QUALIFICATION);metadata.append(ref)
    require(plan.get('schema') == 'mr3-reach-preparation-plan-v1' and plan.get('learner_python') == PYTHON
            and plan.get('reset_workload_reader_profile') == MASKED and plan.get('preparation_probe_version') == PROBE
            and plan.get('actuation_profile') == ACTUATION and plan.get('motion_authority_profile') == AUTHORITY,
            'fixed plan/profile differs')
    qualification_shape(qualification, plan, freeze)
    used, external = matrix_accounting(scope, metadata)
    if stage == 'minimum':
        require(external > 0 and str(external) == scope.get('external_finalize_seconds')
                and 180000-used >= CAPS[stage]+external, 'actual engineering minimum/main+tail is not funded')
    else:
        prior = predecessor_parent(scope, stage, metadata)
        external = Decimal(300)
        used = dec(prior.get('engineering_cumulative_seconds'))
        require(scope.get('pilot_remaining_seconds') == '2905.9547395464029'
                and scope.get('pilot_remaining_decisions') == 1870
                and scope.get('validation_remaining_seconds') == '9000'
                and scope.get('validation_remaining_decisions') == 900, 'original policy balance differs')
    if stage == 'validation':
        require_capacity(scope)
    spec = plan['policy_stages'][stage]
    require(spec['wall_seconds'] == str(CAPS[stage]) and spec['tail_reserve_seconds'] == '500'
            and spec.get('external_finalize_reserve_seconds') == ('0' if stage == 'minimum' else '300'),
            'frozen plan stage cap differs')
    require(spec['argv'][:3] == [PYTHON, '-m', 'mr3_learning.ppo'], 'fixed PPO entry differs')
    return dict(stage=stage, freeze=freeze, scope=scope, scope_sha256=scope_sha, plan=plan,
        spec=spec, metadata=metadata, external=external, engineering_entry=used)


def sources(ctx):
    canonical_freeze(ctx['freeze'])
    plan = ctx['plan'];expected = {ROOT/name:sha for name, sha in plan['source_bindings'].items()}
    expected[PLAN] = bound(PLAN)['sha256']
    for p in A.glob('*.py'):
        expected.setdefault(p, None)
    rows = []
    for p, expected_sha in sorted(expected.items()):
        row = bound(p)
        require(expected_sha is None or row['sha256'] == expected_sha, 'canonical source SHA changed')
        require(hashlib.sha256(git('show', ctx['freeze']+':'+str(p.relative_to(ROOT)))).hexdigest() == row['sha256'],
                'canonical source absent/different in fixed Git')
        rows.append(dict(row, kind='canonical_Git_source'))
    for name, expected_sha in sorted(plan['library_bindings'].items()):
        p = Path(name) if Path(name).is_absolute() else ROOT/name
        row = bound(p, allow_link=True);require(row['sha256'] == expected_sha, 'selected library changed')
        rows.append(dict(row, kind='selected_library'))
    for old in ctx['metadata']:
        actual = bound(old['path'], allow_link=old.get('allow_link') is True)
        if 'allow_link' in old:actual['allow_link'] = old['allow_link']
        require(actual == old, 'closed metadata or interpreter changed after admission')
    for row in [bound(SELF), *ctx['metadata']]:
        rows.append(dict(row, kind='external_parent_or_closed_metadata'))
    require(bound(scope_path(ctx['stage']))['sha256'] == ctx['scope_sha256'], 'admission changed')
    canonical_freeze(ctx['freeze'])
    return rows


def commands(ctx):
    stage = ctx['stage'];prefix = '/tmp/mr3_p2a_reach_v71_'+stage
    main_outer = Path(prefix+'_wait');final_outer = Path(prefix+'_finalize_wait');final = Path(prefix+'_final.json')
    main = [PYTHON, '-m', 'mr3_learning.reach_policy_chain', '--plan', str(PLAN), '--freeze', ctx['freeze'],
            '--qualification', str(QUALIFICATION), '--stage', stage]
    close = [PYTHON, '-m', 'mr3_learning.reach_policy_chain', '--plan', str(PLAN), '--freeze', ctx['freeze'],
             '--stage', stage, '--finalize-outer-wait', str(main_outer/'actual_wait.json'), '--output', str(final)]
    return main, close, main_outer, final_outer, final


def outer_argv(inner, output, stage, source_rows):
    argv = [PYTHON, '-B', '-m', 'mr3_learning.reach_execution', '--output', str(output), '--scope', SCOPE_NAMES[stage]]
    for path in dict.fromkeys(row['path'] for row in source_rows):
        argv += ['--source', path]
    return [*argv, '--', *inner]


def waited(argv, console):
    result = dict(actual_argv=list(argv), process_submitted=False, actual_waited=False, actual_returncode=None, saved_identity=None,
                  started_monotonic_ns=time.monotonic_ns(), errors=[])
    process = None
    try:
        with Path(console).open('x') as stream:
            env = dict(os.environ, PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1')
            env.pop('PYTHONPATH', None);env.pop('PYTHONHOME', None)
            process = subprocess.Popen(argv, cwd=W, env=env, stdout=stream, stderr=subprocess.STDOUT)
            result['process_submitted'] = True
            result['saved_identity'] = identity(process.pid)
            if not typed_identity(result['saved_identity']):
                result['errors'].append('spawned original identity unavailable')
            while True:
                try:
                    result['actual_returncode'] = process.wait();result['actual_waited'] = True;break
                except BaseException as error:
                    result['errors'].append('wait interrupted; still draining: '+repr(error))
    except BaseException as error:
        result['errors'].append(repr(error))
    finally:
        if process is not None and not result['actual_waited']:
            while True:
                try:
                    result['actual_returncode'] = process.wait();result['actual_waited'] = True;break
                except BaseException as error:result['errors'].append(repr(error))
    result['ended_monotonic_ns'] = time.monotonic_ns()
    return result


def phase_pair(run_main, run_final):
    """No skipped finalizer after an actually submitted main, even on rc failure."""
    main = run_main()
    final = run_final()
    return main, final


def waits_drained(phases):
    return all(value is not None and (value.get('process_submitted') is False
               or (value.get('process_submitted') is True and value.get('actual_waited') is True
                   and type(value.get('actual_returncode')) is int)) for value in phases)


def phase_receipt(path, phase, inner):
    value = parse(Path(path).read_bytes())
    require(value.get('schema') == 'mr3-reach-outer-actual-wait-v1' and value.get('actual_argv') == inner
            and value.get('actual_waited') is True and type(value.get('actual_returncode')) is int
            and value['actual_returncode'] == 0 and phase.get('actual_waited') is True
            and phase.get('actual_returncode') == 0 and not phase['errors']
            and value.get('errors') == [] and value.get('source_unchanged') is True
            and value.get('source_before') == value.get('source_after') and value.get('source_before')
            and same(phase['saved_identity'], value.get('coordinator_identity')), 'actual phase wait/source failed')
    absent(value['coordinator_identity']);absent(value['child_identity'])
    return value


def final_result(path, stage):
    result = parse(Path(path).read_bytes());science = result.get('scientific_result', {})
    require(result.get('schema') == 'mr3-reach-policy-stage-final-absence-v1' and result.get('passed') is True
            and result.get('stage') == stage and result.get('freeze') == FIXED_G
            and result.get('strict_custody_passed') is True and result.get('all_saved_identities_gone') is True
            and result.get('within_stage_wall_allocation') is True, 'actual canonical finalizer failed')
    require(type(science.get('optimizer_updates')) is int, 'typed actual optimizer updates required')
    if stage == 'minimum':require(type(science.get('eligible_decisions')) is int and science['eligible_decisions'] == 16 and science['optimizer_updates'] > 0, 'minimum actual updates/sample gate failed')
    elif stage == 'pilot':require(type(science.get('eligible_decisions')) is int and 2 <= science['eligible_decisions'] <= 64
            and science['optimizer_updates'] > 0, 'pilot actual updates/sample gate failed')
    else:require(science['optimizer_updates'] == 0 and type(science.get('strict_task_successes')) is int
            and science['strict_task_successes'] == 3, 'strict final task/update gate failed')
    require(science.get('actuation_profile') == ACTUATION and science.get('motion_authority_profile') == AUTHORITY,
            'actual policy science profiles differ')
    if stage != 'validation':
        checkpoint = result.get('final_checkpoint')
        require(type(checkpoint) is dict and type(checkpoint.get('bytes')) is int and checkpoint['bytes'] > 0,
                'actual final.zip checkpoint missing')
        actual = bound(checkpoint['path'])
        require(actual['sha256'] == checkpoint.get('sha256') and actual['bytes'] == checkpoint['bytes']
                and Path(actual['path']).name == 'final.zip', 'actual final checkpoint changed')
    for row in result['identities']:absent(row['saved'])
    return result


def execute(stage, freeze, scope_sha):
    directory = state_dir(stage);errors = [];before = [];after = [];ctx = None;main = final = None
    final_value = None;fee = None;started = None;owner = None;main_end = final_start = final_end = None
    try:
        owner = identity(os.getpid())
        boot = parse((directory/'bootstrap.json').read_bytes())
        require(same(boot.get('saved_parent'), owner) and boot.get('freeze') == freeze
                and boot.get('scope_sha256') == scope_sha and type(boot.get('started_monotonic_ns')) is int
                and 0 < boot['started_monotonic_ns'] <= ENTERED_NS, 'same-PID bootstrap/source admission unavailable')
        started = boot['started_monotonic_ns']
        ctx = context(stage, freeze, scope_sha);before = sources(ctx)
        inner, close, main_outer, final_outer, output = commands(ctx)
        require(ctx['scope'].get('actual_main_argv') == inner and ctx['scope'].get('actual_finalizer_argv') == close,
                'fixed predeclared main/finalizer argv differs')
        require(not any(p.exists() for p in (main_outer, final_outer, output,
                Path(ctx['spec']['run_directory']), Path(ctx['spec']['output_directory']))), 'exclusive stage outputs already exist')
        write(directory/'entry.json', dict(stage=stage, freeze=freeze, saved_parent=owner,
            scope_sha256=scope_sha, main_argv=inner, finalizer_argv=close, source_before=before))
        def first():
            nonlocal main_end, main
            value = waited(outer_argv(inner, main_outer, stage, before), directory/'main.log')
            main = value;main_end = time.monotonic_ns()
            try:write(directory/'main_wait.json', value)
            except BaseException as error:errors.append('main receipt write: '+repr(error))
            return value
        def last():
            nonlocal final_start, final_end, final
            # Fixed sources must remain trusted before executing the next module.
            canonical_freeze(freeze)
            final_start = time.monotonic_ns()
            value = waited(outer_argv(close, final_outer, stage, before), directory/'finalizer.log')
            final = value;final_end = time.monotonic_ns()
            try:write(directory/'finalizer_wait.json', value)
            except BaseException as error:errors.append('finalizer receipt write: '+repr(error))
            return value
        main, final = phase_pair(first, last)
        phase_receipt(main_outer/'actual_wait.json', main, inner)
        phase_receipt(final_outer/'actual_wait.json', final, close)
        final_value = final_result(output, stage)
    except BaseException as error:
        errors.append(repr(error))
    finally:
        if ctx is not None:
            try:after = sources(ctx);require(before and before == after, 'complete source before/after differs')
            except BaseException as error:errors.append('post-source: '+repr(error))
    ended = time.monotonic_ns()
    if started is not None and all(type(x) is int for x in (main_end, final_start, final_end)) and ctx is not None:
        try:
            fee = settled_fee(stage, started, main_end, final_start, final_end, ended, ctx['external'])
            if not fee['passed']:errors.append('complete main/final/gap/source actual fee exceeded original limits')
        except BaseException as error:errors.append('fee: '+repr(error))
    complete = Decimal(ended-started)/10**9 if started is not None else None
    drained = waits_drained([p for p in (main, final) if p is not None])
    result = dict(schema='mr3-fixed-policy-stage-parent-summary-v1', stage=stage, freeze=freeze,
        passed=bool(not errors and fee and fee['passed'] and final_value and drained and not SIGNALS),
        driver_identity=owner, scope_sha256=scope_sha, errors=errors, signals=SIGNALS,
        complete_parent_started_monotonic_ns=started, ended_monotonic_ns=ended,
        complete_parent_fee_known=complete is not None, actual_parent_seconds=str(complete) if complete is not None else None,
        observed_driver_lower_bound_seconds=str(Decimal(ended-ENTERED_NS)/10**9),
        fee_scope=SCOPE_NAMES[stage], fee=fee, main=main, finalizer=final, final_result=final_value,
        engineering_entry_verified=ctx is not None,
        engineering_cumulative_seconds=(str(ctx['engineering_entry']+complete) if ctx is not None and complete is not None and stage=='minimum'
                                        else str(ctx['engineering_entry']) if ctx is not None else None),
        source_before=before, source_after=after, source_before_after_equal=bool(before and before==after),
        all_submitted_waits_drained=drained, parent_self_freshgone_requires_external_actual_reap=True,
        parent_source_Git_claimed=False, external_parent_source_SHA_bound=True,
        finalizer_passed_does_not_substitute_its_own_fee=True, automatic_next_stage_entry=False,
        hard_realtime_cap_claimed=False, native_or_policy_success_invented=False)
    write(directory/'summary.json', result)
    print(json.dumps({k:result[k] for k in ('passed','stage','actual_parent_seconds','errors')}), flush=True)
    return 0 if result['passed'] else 1


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', required=True, choices=STAGES)
    parser.add_argument('--freeze', required=True)
    parser.add_argument('--admission-sha256', required=True)
    parser.add_argument('--execute', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args(argv)
    require(Path(__file__).resolve() == SELF and args.freeze == FIXED_G, 'fixed disabled parent/freeze only')
    require(Path(sys.executable).resolve() == Path('/usr/bin/python3').resolve(), 'fixed system parent interpreter required')
    require(re.fullmatch('[0-9a-f]{64}', args.admission_sha256), 'exact predeclared admission SHA required')
    def received(signum, frame):SIGNALS.append(dict(signal=signum, observed_monotonic_ns=time.monotonic_ns()))
    signal.signal(signal.SIGINT, received);signal.signal(signal.SIGTERM, received)
    if args.execute:return execute(args.stage, args.freeze, args.admission_sha256)
    directory = state_dir(args.stage);directory.mkdir(exist_ok=False)
    owner = identity(os.getpid());require(typed_identity(owner), 'real bootstrap identity unavailable')
    command = ['/usr/bin/python3', '-B', str(SELF), '--stage', args.stage, '--freeze', args.freeze,
               '--admission-sha256', args.admission_sha256, '--execute']
    write(directory/'bootstrap.json', dict(schema='mr3-fixed-policy-stage-same-pid-bootstrap-v1',
        saved_parent=owner, freeze=args.freeze, scope_sha256=args.admission_sha256,
        started_monotonic_ns=ENTERED_NS, actual_argv=sys.argv, exec_argv=command,
        unobserved_earlier_time_invented=False, parent_ancestor_absence_claimed=False))
    try:os.execv(command[0], command)
    except BaseException as error:
        SIGNALS.append(dict(bootstrap_exec_error=repr(error)))
        return execute(args.stage, args.freeze, args.admission_sha256)


if __name__ == '__main__':
    raise SystemExit(main())
