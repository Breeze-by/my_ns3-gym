"""Four execution-entry source shadows only; no checkout mutations."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

ROOT=Path('/home/zhuyulab/ns3-workspace')
HERE=Path(__file__).resolve().parent
W=Path('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/mr3_learning')
WORKER=Path('ros2_ws/ros2-multi-robot-automap/scripts/mr3_env_worker.py')
paths=[W/'supervisor.py',W/'benchmark.py',W/'ppo.py',WORKER]
old={str(p):(ROOT/p).read_text() for p in paths};new=dict(old)


def change(path,a,b):
    key=str(path);assert new[key].count(a)==1,(key,a[:60],new[key].count(a))
    new[key]=new[key].replace(a,b)


S=W/'supervisor.py';B=W/'benchmark.py';P=W/'ppo.py'
change(S,'from .ipc import JsonLinePeer\n','from .ipc import JsonLinePeer\nfrom .motion_authority_profile import motion_authority_profile_for_safety_contract\n')
change(S,'        self.actuation_profile = actuation_profile_for_safety_contract(safety_contract)\n',
       '        self.actuation_profile = actuation_profile_for_safety_contract(safety_contract)\n'
       '        self.motion_authority_profile = motion_authority_profile_for_safety_contract(safety_contract)\n')
change(S,'            metadata["actuation_profile"] = self.actuation_profile\n',
       '            metadata["actuation_profile"] = self.actuation_profile\n'
       '        if self.motion_authority_profile is not None:\n'
       '            metadata["motion_authority_profile"] = self.motion_authority_profile\n')
change(S,'**startup,\n',
       '**startup,\n'
       '                                **({"motion_authority_profile": self.motion_authority_profile}\n'
       '                                   if self.motion_authority_profile is not None else {}),\n')
for path in (B,P):
    change(path,'from .env import MR3Env\n','from .env import MR3Env\nfrom .motion_authority_profile import (\n'
           '    motion_authority_profile_for_safety_contract, selected_motion_authority_profile,\n'
           ')\n')
    change(path,'        metadata["actuation_profile"] = profile\n',
           '        metadata["actuation_profile"] = profile\n'
           '    authority_profile = motion_authority_profile_for_safety_contract(args.safety_contract)\n'
           '    if authority_profile is not None:\n'
           '        metadata["motion_authority_profile"] = authority_profile\n')
change(B,'from .motion_authority_profile import (\n    motion_authority_profile_for_safety_contract, selected_motion_authority_profile,\n)\n',
       'from .motion_authority_profile import motion_authority_profile_for_safety_contract\n')
change(P,'        result["actuation_profile"] = profile\n',
       '        result["actuation_profile"] = profile\n'
       '    if authority_profile is not None:\n'
       '        result["motion_authority_profile"] = authority_profile\n')

# Qualification proof shape is supplied by the independently owned reader gate;
# do not run/seal this candidate until that owner fixes the below admission hook.
change(P,'        validate_qualification(args.reach_qualification, args.reach_plan, admission_freeze)\n',
       '        qualification = validate_qualification(args.reach_qualification, args.reach_plan, admission_freeze)\n'
       '        require_qualified_motion_authority(qualification)\n'
       '        authority_plan = load_plan(args.reach_plan)\n'
       '        if (selected_motion_authority_profile(authority_plan, required=True)\n'
       '                != motion_authority_profile_for_safety_contract(args.safety_contract)):\n'
       '            parser.error("PPO receiving-authority profile differs from its qualification plan")\n')
change(P,'    motion_authority_profile_for_safety_contract, selected_motion_authority_profile,\n',
       '    motion_authority_profile_for_safety_contract, selected_motion_authority_profile,\n'
       '    require_qualified_motion_authority,\n')

change(WORKER,'from multi_robot_exploration.mr3_safety_intent import actuation_profile_for_safety_contract\n',
       'from multi_robot_exploration.mr3_safety_intent import actuation_profile_for_safety_contract\n'
       'from multi_robot_exploration.mr3_motion_authority import PROFILE as MOTION_AUTHORITY_PROFILE\n')
change(WORKER,'class Worker:\n','''def motion_authority_profile_from_request(request):
    """Receiving permission is fixed by the new Reach contract, not a CLI knob."""
    if type(request) is not dict:
        raise ValueError("worker reset request is not an object")
    contract = request.get("safety_contract", "legacy")
    if type(contract) is not str or contract not in ("legacy", "mr3-reach-v1"):
        raise ValueError("unknown safety contract for receiving authority")
    expected = MOTION_AUTHORITY_PROFILE if contract == "mr3-reach-v1" else None
    selected = request.get("motion_authority_profile")
    if ((expected is None and selected is not None) or
            (expected is not None and (type(selected) is not str or selected != expected))):
        raise ValueError("worker receiving-authority profile differs from fixed reset contract")
    return expected


class Worker:
''')
change(WORKER,'        self.safety_contract = request.get("safety_contract", "legacy")\n',
       '        self.safety_contract = request.get("safety_contract", "legacy")\n'
       '        self.motion_authority_profile = motion_authority_profile_from_request(request)\n')
change(WORKER,'            metadata["actuation_profile"] = profile\n',
       '            metadata["actuation_profile"] = profile\n'
       '        if self.motion_authority_profile is not None:\n'
       '            metadata["motion_authority_profile"] = self.motion_authority_profile\n')

records=[];patch=[]
for key,text in new.items():
    ast.parse(text,filename=key)
    path=HERE/'shadow'/key;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text)
    records.append({'path':key,'base_bytes':len(old[key].encode()),'base_sha256':hashlib.sha256(old[key].encode()).hexdigest(),
                    'bytes':len(text.encode()),'sha256':hashlib.sha256(text.encode()).hexdigest()})
    patch.extend(difflib.unified_diff(old[key].splitlines(True),text.splitlines(True),fromfile='a/'+key,tofile='b/'+key))
(HERE/'metadata_candidate.patch').write_text(''.join(patch))
(HERE/'source_manifest_v1.json').write_text(json.dumps({'status':'UNSEALED_WAITING_INDEPENDENT_PROFILE_ACCESSOR',
    'files':records,'production_installed':False,'free_CLI_profile_parameter':False},indent=2)+'\n')
print(json.dumps({'AST_PASS':True,'files':len(records),'patch_bytes':len(''.join(patch).encode())}))
