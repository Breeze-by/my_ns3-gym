import hashlib
import json
from pathlib import Path


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def reference(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def identity(path):
    stat = path.stat()
    return [stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns,
            stat.st_ctime_ns]


def main():
    target = Path('/tmp/mr3_p2a0_v19_selected_native_v1/iters150')
    manifest_path = target / 'manifest.json'
    manifest = json.loads(manifest_path.read_bytes())
    execution_path = Path('/tmp/mr3_p2a0_v19_pack_closed_iters150_execution_v1.json')
    execution = json.loads(execution_path.read_bytes())
    original_execution_ref = manifest['original_execution']
    original_execution_raw = Path(original_execution_ref['source']).read_bytes()
    assert sha(original_execution_raw) == original_execution_ref['sha256']
    original = json.loads(original_execution_raw)
    summary_ref = manifest['original_benchmark_summary']
    summary_raw = Path(summary_ref['source']).read_bytes()
    assert sha(summary_raw) == summary_ref['sha256']
    benchmark = json.loads(summary_raw)
    assert execution['exit_code'] == 0 and execution['passed'] is True
    assert manifest['passed'] is True
    assert manifest['source_statfinal_inventory_exact'] is True
    assert manifest['stage'] == 'iters150' and original['status'] == 'completed'
    assert execution['source_sha256_before'] == execution['source_sha256_after']
    assert sha(Path('/tmp/mr3_p2a0_v19_pack_closed_iters150_v1.py').read_bytes()) == execution['source_sha256_after']
    assert manifest['helper_configuration']['workers'] == 2
    raw_bytes = selected_bytes = selected_parts = largest = 0
    selected_paths = set()
    for row in manifest['files']:
        assert row['source_stat_initial'] == row['source_stat_final']
        assert identity(Path(row['source'])) == row['source_stat_final']
        verification = row['verification']
        assert verification['all_part_encoded_and_decoded_sha_verified'] is True
        assert verification['reassembled_decoded_sha256'] == row['raw_sha256']
        assert verification['decoded_bytes'] == row['raw_bytes']
        offset = 0
        for index, part in enumerate(row['parts']):
            assert part['index'] == index and part['raw_offset'] == offset
            assert part['encoding'] == 'gzip'
            selected = target / part['selected']
            assert str(selected) not in selected_paths
            selected_paths.add(str(selected))
            assert selected.stat().st_size == part['selected_bytes']
            assert part['selected_bytes'] < 100000000
            offset += part['raw_bytes']
            selected_bytes += part['selected_bytes']
            selected_parts += 1
            largest = max(largest, part['selected_bytes'])
        assert offset == row['raw_bytes']
        raw_bytes += row['raw_bytes']
    assert len(manifest['files']) == manifest['source_files']
    assert raw_bytes == manifest['raw_bytes']
    assert selected_bytes == manifest['selected_bytes']
    assert selected_parts == manifest['selected_parts']
    assert largest == manifest['largest_encoded_part_bytes']
    artifacts = []
    artifact_verdicts = {}
    for item in manifest['closed_consumer_artifacts']:
        assert item['available'] is True
        raw = Path(item['source']).read_bytes()
        assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
        actual = json.loads(raw)
        assert type(actual['passed']) is bool
        assert actual['passed'] is item['original_passed']
        artifacts.append(item)
        artifact_verdicts[item['label']] = actual['passed']
    assert artifact_verdicts == {'observer_1ms': True, 'original_physical': False}
    all_files = [path for path in target.rglob('*') if path.is_file()]
    assert len(all_files) == selected_parts + 2
    baseline_manifest = Path('/tmp/mr3_p2a0_v19_selected_native_v1/baseline/manifest.json')
    assert sha(baseline_manifest.read_bytes()) == 'fdc8f5ae17007dc4b7331bbf9fad1ad02186f4cc1b43390531600ef15874cf2a'
    episodes = [episode for worker in benchmark['workers_results']
                for episode in worker['episodes']]
    transitions = sum(episode['transitions'] for episode in episodes)
    summary = {
        'schema': 'mr3-v19-iters150-native-custody-summary-v1',
        'custody_passed': True,
        'scope': 'Lossless byte custody only. Original capture/admission/closure PASS and original physical FAIL copied without new matrix/task/PPO or physical credit. Baseline archive unchanged.',
        'freeze': manifest['freeze'], 'plan_sha256': manifest['plan_sha256'],
        'source': manifest['source'], 'target': str(target),
        'prospective_prefix': manifest['prospective_prefix'],
        'source_files': manifest['source_files'], 'raw_bytes': raw_bytes,
        'selected_parts': selected_parts, 'selected_part_bytes': selected_bytes,
        'largest_encoded_part_bytes': largest, 'max_encoded_bytes_strict': 100000000,
        'target_all_files': len(all_files),
        'target_all_bytes': sum(path.stat().st_size for path in all_files),
        'workers': 2,
        'checks': {
            'all_originals_included': True,
            'all_encoded_part_sha_verified_by_pack': True,
            'all_decoded_part_and_reassembled_whole_sha_verified_by_pack': True,
            'all_source_fd_and_finalpath_stat_verified_by_pack': True,
            'final_source_path_stat_rechecked_by_summary': True,
            'final_source_inventory_and_receipts_unchanged': True,
            'all_six_codec_core_functions_byte_identical_to_sealed_baseline': True,
            'inherited_codec_groups_passed': 4,
            'iters150_synthetic_entry_tests_passed': 8,
            'baseline_manifest_sha256_unchanged': True},
        'original_outcomes': {
            'stage_passed': original['passed'],
            'stage_pass_scope': original['pass_scope'],
            'benchmark_passed': benchmark['passed'],
            'original_consumer_artifacts': artifacts,
            'saved_returned_resets': len(episodes),
            'saved_returned_steps': transitions,
            'saved_api_records': len(episodes) + transitions,
            'native_wall_seconds': original['native_wall_seconds'],
            'benchmark_wall_seconds': benchmark['wall_sec_including_all_attempts'],
            'consumer_wall_seconds': {row['label']: row['wall_seconds']
                                      for row in original['diagnostic_consumers']},
            'original_execution_sha256': original_execution_ref['sha256'],
            'original_benchmark_summary_sha256': summary_ref['sha256']},
        'custody_cost': {
            'wall_seconds': execution['wall_seconds'],
            'child_user_cpu_seconds': execution['child_user_cpu_seconds'],
            'child_system_cpu_seconds': execution['child_system_cpu_seconds'],
            'entry_fixtures_and_fatal_lint_wall_seconds': 1.2067500888369977,
            'not_added_to_native_budget': True},
        'execution': {key: execution[key]
                      for key in ['argv', 'cwd', 'environment_exact', 'exit_code']},
        'references': [reference(path) for path in [
            manifest_path, execution_path,
            '/tmp/mr3_p2a0_v19_pack_closed_iters150_derivation_v1.json',
            '/tmp/mr3_p2a0_v19_pack_closed_iters150_checks_v1.json',
            '/tmp/mr3_p2a0_v19_pack_closed_iters150_checks_v2.json',
            '/tmp/mr3_p2a0_v19_run_pack_closed_iters150_v1.py',
            '/tmp/mr3_p2a0_v19_pack_closed_iters150_execution_v1.stdout.log',
            __file__]],
        'writers_stop_after_summary': True,
        'canonical_writes': 0, 'new_native_calls': 0, 'new_formal_audits': 0}
    output = Path('/tmp/mr3_p2a0_v19_iters150_custody_summary_v1.json')
    with output.open('x') as stream:
        json.dump(summary, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'passed': True, 'summary': reference(output),
                      'manifest': reference(manifest_path),
                      'execution': reference(execution_path),
                      'source_files': manifest['source_files'],
                      'target_all_files': len(all_files),
                      'target_all_bytes': summary['target_all_bytes'],
                      'original_physical_passed': False}))


if __name__ == '__main__':
    main()
