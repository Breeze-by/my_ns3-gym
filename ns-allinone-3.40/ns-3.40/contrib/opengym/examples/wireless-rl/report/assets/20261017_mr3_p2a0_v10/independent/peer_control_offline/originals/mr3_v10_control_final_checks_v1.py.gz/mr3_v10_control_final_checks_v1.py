import hashlib
import json
from pathlib import Path
import subprocess
import time
ROOT = Path("/home/zhuyulab/ns3-workspace")
BASE = ROOT/"ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v10/independent"
files = [BASE/"mr3_independent_control_phase_v1.py", BASE/"mr3_independent_control_phase_v1_tests.py"]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
before = {str(p): sha(p) for p in files}
compat = Path('/tmp/mr3_v10_control_consumer_compat_v3.py')
compat.write_text(Path('/tmp/mr3_v10_control_consumer_compat_v2.py').read_text().replace('consumer_compat_v2.json','consumer_compat_v3.json'))
commands = [
 ("mutation_tests_final", ["env", "PYTHONDONTWRITEBYTECODE=1", "/usr/bin/python3", str(files[1]), "-v"]),
 ("style_final", ["/usr/bin/python3", "-m", "flake8", *map(str, files), "--max-line-length=99"]),
 ("syntax_final", ["/usr/bin/python3", "-c", "from pathlib import Path; import sys; [compile(Path(p).read_text(), p, 'exec') for p in sys.argv[1:]]", *map(str, files)]),
 ("real_method_compat_final", ["env", "PYTHONDONTWRITEBYTECODE=1", "/usr/bin/python3", str(compat)])]
results = []
for label, argv in commands:
 start=time.monotonic(); r=subprocess.run(argv,cwd=ROOT,capture_output=True,text=True)
 out=Path('/tmp/mr3_p2a0_v10_control_'+label+'_v1.log');out.write_text(r.stdout+r.stderr)
 results.append({'label':label,'cwd':str(ROOT),'argv':argv,'exit_code':r.returncode,
                 'wall_seconds':time.monotonic()-start,'stdout_stderr':str(out),'sha256':sha(out)})
result={'schema':'mr3-v10-control-consumer-offline-checks-v1',
        'passed':all(r['exit_code']==0 for r in results),'checks':results,
        'source_before':before,'source_after':{str(p):sha(p) for p in files},
        'history':[str(p) for pattern in ('mr3_p2a0_v10_control_consumer_tests_*.log','mr3_p2a0_v10_control_consumer_style_*.log','mr3_p2a0_v10_control_consumer_compat_*.log') for p in sorted(Path('/tmp').glob(pattern))],
        'history_notes':['Initial asset style failures retained; AST-preserving temporary formatting tool only, no runtime dependency added.',
                         'Tests06 import failed for /tmp shallow parent path; fixed candidate helper discovery; all output retained.',
                         'Earlier 32/49/50/51/55/57 counts belong their original intermediate source, not final source credit.',
                         'Runtime read-only review identified terminal cancellation oldhubclock<T exception; final tests preserve narrow actual-notice/typed-clock branch only.'],
        'limitations':['Synthetic callbacks/worker/native rows award no native or continuous physical credit.',
                       'Actual production-method peer fixtures use real ROS messages/fake publishers and synthetic spacing.',
                       'Two modes share one source and overlap; no extra independent replication credit.',
                       'Source-stop DDS-inflight overlaps are diagnostic, not an invented zero-latency gate.'],
        'cli':{'full':'DIRECTORY --freeze FREEZE --output OUTPUT',
               'peer':'DIRECTORY --freeze FREEZE --peer-only --output OUTPUT'}}
assert before==result['source_after']
Path('/tmp/mr3_p2a0_v10_control_consumer_checks_v1.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(result,sort_keys=True))
