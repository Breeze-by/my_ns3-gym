import hashlib,json,os
from pathlib import Path
import subprocess,sys

ROOT=Path('/home/zhuyulab/ns3-workspace')
W=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A=Path(__file__).resolve().parent

def main():
    out=A/'checks/helper_cpu_v1';out.mkdir(parents=True,exist_ok=False)
    sources=[*sorted((A/'candidate').glob('*.py')),A/'test_motion_authority_audit.py',Path(__file__),
        *[W/'mr3_learning'/name for name in ('__init__.py','audit_reach_runtime.py','initial_encoder_replay.py',
             'reach_execution.py','preparation.py','proxy2d_process.py')],Path('/usr/bin/python3').resolve()]
    snapshots=out/'source_snapshots';snapshots.mkdir();bindings=[]
    for ordinal,path in enumerate(sources):
        raw=path.read_bytes();sha=hashlib.sha256(raw).hexdigest();snapshot=snapshots/(f'{ordinal:03d}_{sha}_{path.name}')
        snapshot.open('xb').write(raw)
        bindings.append(dict(path=str(path),bytes=len(raw),sha256=sha,snapshot=str(snapshot)))
    test=['/usr/bin/python3','-B','-m','pytest','-q','-p','no:cacheprovider',str(A/'test_motion_authority_audit.py'),
          '--junitxml='+str(out/'pytest.xml')]
    (out/'source_recovery_v1.json').open('x').write(json.dumps(dict(
        schema='mr3-authority-helper-artificial-cpu-source-v1',base_HEAD=subprocess.check_output(
            ['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),sources=bindings,pytest_argv=test),indent=2)+'\n')
    argv=['/usr/bin/python3','-B','-m','mr3_learning.reach_execution','--scope','cpu','--output',str(out/'actual')]
    for path in sources:argv.extend(['--source',str(path)])
    env=dict(os.environ,PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONPATH',None)
    return subprocess.call([*argv,'--',*test],cwd=W,env=env)

if __name__=='__main__':raise SystemExit(main())
