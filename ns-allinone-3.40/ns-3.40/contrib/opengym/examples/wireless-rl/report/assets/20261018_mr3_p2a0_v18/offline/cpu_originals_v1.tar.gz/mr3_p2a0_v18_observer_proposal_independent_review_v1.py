#!/usr/bin/python3
"""Independent static review of immutable V18 observer proposal v3 only."""
import difflib
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path('/home/zhuyulab/ns3-workspace')
ROS = ROOT / 'ros2_ws/ros2-multi-robot-automap'
P = Path('/tmp/mr3_p2a0_v18_driver_diagnostic_proposal_v3')
PRIMARY = Path('/tmp/mr3_p2a0_v18_solver_primary_sources_v1')
OUT = Path('/tmp/mr3_p2a0_v18_observer_proposal_independent_review_v1.json')
MD = OUT.with_suffix('.md')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def main():
    assert not OUT.exists() and not MD.exists()
    paths = [P / name for name in ('review_only.patch', 'mr3_stop_response_observer.cpp',
        'CMakeLists.proposed.txt', 'design_v1.json', 'checks_v1.json',
        'diagnostic_plugin_example.xml', 'World_11.10.2.cc', 'ODEJoint_11.10.2.cc')]
    paths += [PRIMARY / 'ODEPhysics_11_10_2.cc', Path('/usr/include/gazebo-11/gazebo/physics/Link.hh'),
        Path('/usr/include/gazebo-11/gazebo/physics/ode/ODEPhysics.hh'),
        Path('/tmp/mr3_p2a0_v18_observer_json_nonfinite_review_v1/receipt.json'),
        Path('/tmp/mr3_p2a0_v18_observer_json_nonfinite_review_v1/run.stdout')]
    relative = ['src/mr3_gazebo_diff_drive.cpp', 'include/multi_robot/mr3_gazebo_diff_drive.hpp',
        'include/multi_robot/paired_wheel_slew.hpp', 'include/multi_robot/mr3_drive_target.hpp', 'CMakeLists.txt']
    for name in relative:
        paths.extend([P / 'sourceproof' / name, ROS / 'src/multi_robot' / name])
    model = ROS / 'src/multi_robot/models/turtlebot3_waffle/model.sdf'
    launch = ROS / 'src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py'
    paths.extend([model, launch])
    raw = {str(path): path.read_bytes() for path in paths}
    assert sha(raw[str(P / 'review_only.patch')]) == '8276a4ec2a20d65a0663a265154fba0866773f7b74bc8e6aec94c942a5e7cff2'
    assert sha(raw[str(P / 'mr3_stop_response_observer.cpp')]) == 'fbc9c228cc6ddb46f14318b5d6df27ef9bdc667ab169e4c3de598c9a1ddf0f2f'
    body = raw[str(P / 'mr3_stop_response_observer.cpp')].decode()
    old = raw[str(P / 'sourceproof/CMakeLists.txt')].decode()
    proposed = raw[str(P / 'CMakeLists.proposed.txt')].decode()
    patch = ''.join(difflib.unified_diff(old.splitlines(keepends=True), proposed.splitlines(keepends=True),
        fromfile='a/ros2_ws/ros2-multi-robot-automap/src/multi_robot/CMakeLists.txt',
        tofile='b/ros2_ws/ros2-multi-robot-automap/src/multi_robot/CMakeLists.txt'))
    patch += ''.join(difflib.unified_diff([], body.splitlines(keepends=True), fromfile='/dev/null',
        tofile='b/ros2_ws/ros2-multi-robot-automap/src/multi_robot/src/mr3_stop_response_observer.cpp'))
    assert patch.encode() == raw[str(P / 'review_only.patch')]
    opcodes = difflib.SequenceMatcher(a=old, b=proposed, autojunk=False).get_opcodes()
    assert all(tag in ('equal', 'insert') for tag, *_ in opcodes)
    for name in relative:
        assert raw[str(P / 'sourceproof' / name)] == raw[str(ROS / 'src/multi_robot' / name)]
    assert b'mr3_stop_response_observer' not in raw[str(model)]
    assert b'mr3_stop_response_observer' not in raw[str(launch)]
    for token in ('SetParam(', 'SetVelocity(', 'SetForce(', 'SetWorldPose(', 'SetLinearVel(',
                  'SetAngularVel(', 'create_publisher', 'create_subscription', 'Advertise<', 'Subscribe('):
        assert token not in body
    assert 'ConnectBeforePhysicsUpdate' in body and 'ConnectWorldUpdateEnd' in body
    assert 'weak = std::weak_ptr<State>(state)' in body
    assert 'clock_ns != pair_clock_ns' in body
    assert 'pair_iterations' not in body and 'before_iterations' not in body
    assert 'dWorldGetQuickStepNumIterations' not in body
    assert 'GetWorldId' not in body
    assert 'physics->GetParam(key, value)' in body
    assert 'state->output.reset(std::fopen(path.c_str(), "wx"))' in body
    assert 'std::fflush(output.get()) != 0' in body
    assert 'throw std::runtime_error' in body
    numeric = json.loads(raw['/tmp/mr3_p2a0_v18_observer_json_nonfinite_review_v1/run.stdout'])
    assert numeric == {'available': True, 'cpp_type': 'double', 'value': None}
    config = ET.fromstring(raw[str(P / 'diagnostic_plugin_example.xml')])
    assert config.tag == 'plugin' and config.get('filename') == 'libmr3_stop_response_observer.so'
    header = raw['/usr/include/gazebo-11/gazebo/physics/Link.hh'].decode()
    assert 'Get the linear velocity of the origin of the link frame' in header
    assert "Get the linear velocity at the body's center of gravity" in header

    def lines(path, needles):
        source = raw[str(path)].decode().splitlines()
        return {needle: [i for i, text in enumerate(source, 1) if needle in text] for needle in needles}

    bindings = {path: {'bytes': len(data), 'sha256': sha(data)} for path, data in raw.items()}
    design = json.loads(raw[str(P / 'design_v1.json')])
    authored_checks = json.loads(raw[str(P / 'checks_v1.json')])
    review = {
        'schema': 'mr3-v18-observer-proposal-independent-review-v1',
        'reviewed_proposal': {'directory': str(P), 'patch_sha256': sha(raw[str(P / 'review_only.patch')]),
            'source_sha256': sha(raw[str(P / 'mr3_stop_response_observer.cpp')])},
        'verdict': 'separate-default-off observer structure is sound for a bounded diagnostic, but v3 needs a narrow native-ODE parameter/source-scope revision before it can prove an applied solver profile; no experiment GO is implied',
        'critical_findings': [{
            'id': 'R1', 'priority': 'required_before_native_solver_profile_evidence',
            'finding': 'All configuration physics_parameters pass through GetParam. For solver_type, cfm, erp, precon_iters, iters and sor the installed-version implementation reads SDF elements; no ODEPhysics/GetWorldId/dWorldGet getters are present in v3.',
            'reason': 'A cached configuration value is not an independent native solver readback. V3 design calls these actual readbacks, which is too broad. This is a source-proven evidence insufficiency; it is not evidence that this baseline or prior V17 used the wrong live setting.',
            'narrow_fix_sent_to_author': 'New version: label cached values as SDF/cache and add direct ODEPhysics GetWorldId native values (at least dWorldGetQuickStepNumIterations/W/CFM/ERP with GetStepType), preserving unsupported/error semantics and engine/library identity. Keep actual native rms_error/constraint_residual scope separate.',
            'evidence': {'observer_lines': lines(P / 'mr3_stop_response_observer.cpp', ['Json Parameter(', 'physics->GetParam(key, value)', 'Json params;', '{params[key] = Parameter(physics, key);}']),
                'primary_lines': lines(PRIMARY / 'ODEPhysics_11_10_2.cc', ['int ODEPhysics::GetSORPGSIters()', 'bool ODEPhysics::GetParam', '_key == "iters"', '_key == "sor"', '_key == "rms_error"', '_key == "constraint_residual"'])}}],
        'narrow_recommendations': [{
            'id': 'R2', 'finding': 'Sample rows record actual world_iterations and same simtime; runtime pairing checks clock but does not retain/check pre-iteration at post. Add pair_iterations and equality check, or require the independent reader to enforce equal pre/post iterations and exact 1ms consecutive spacing. This is a robustness obligation, not an observed native mismatch.',
            'evidence': lines(P / 'mr3_stop_response_observer.cpp', ['world_iterations', 'pair_clock_ns = clock_ns', 'clock_ns != pair_clock_ns', 'before_record_sequence'])}, {
            'id': 'R3', 'finding': 'Parameter(double NaN) remains available:true and nlohmann dump silently writes value:null. A tiny actual-library CPU serialization example reproduced this. It is not proof of native nonfinite solver output.',
            'narrow_fix_sent_to_author': 'Mark nonfinite parameter values explicitly unavailable/nonfinite with no zero fallback. The future reader must reject nonfinite/null required pose/velocity/joint samples and must not treat optional unavailable world residuals as measured zeros.',
            'cpu_receipt': '/tmp/mr3_p2a0_v18_observer_json_nonfinite_review_v1/receipt.json',
            'cpu_test_result': numeric}],
        'positive_source_findings': [
            'Exact patch reconstruction succeeds. It only appends a separate CMake target and a new observer source; all original driver source/header/helper/target and original CMake snapshot bytes match current canonical source. No existing actuator function is edited.',
            'Normal canonical model and launch contain no observer plugin. Default-off means omitted plugin entry, not an enabled:false branch after Load; its file I/O and event callbacks run only if an explicit generated diagnostic SDF inserts the new library.',
            'BeforePhysicsUpdate and WorldUpdateEnd match official11.10.2 hook order. At the latter pose propagation has completed. Pair_sequence/before_record_sequence, explicit phases, same-clock check and actual iteration values allow an independent reader to reject broken pairing.',
            'Link world_origin_linear_velocity_xyz and world_cog_linear_velocity_xyz names agree with installed Link.hh semantics. Recording both canonical and explicit base plus worldCoG pose supports the omega-cross-offset check without flattening the body.',
            'Joint GetParam(vel/fmax) corresponds to actual ODE motor parameters. GetForce is correctly labelled as that API and explicitly not claimed to be motor/solver reaction wrench or target-consumption ACK.',
            'Callbacks hold only weak captures; an active callback obtains a local shared State. Destructor disconnects both event connections while State retains file/model handles until callback completion. No obvious weak-callback ownership cycle was found; no lifetime/TSAN/native test was performed.',
            'Exclusive fopen(wx), checked fwrite and checked flush after completed pairs avoid overwriting old evidence and preserve I/O failure. Exceptions are deliberately uncaught through the callback and may abort the diagnostic engine; the design correctly calls that an infrastructure failure, not harmless isolation.',
            'Design explicitly disclaims zero overhead or timing equivalence. Three1kHz observers nominally cause3000 flush calls/sec plus getters/JSON/writes; added wall load can alter asynchronous ROS arrival/order despite unchanged actuator code.'],
        'future_admission_and_consumer_requirements': [
            'Build/link a real ELF and exercise loader/factory/lifetime/invalid-path cases as appropriate before native; authored checks only establish syntax/source facts. Do not repeat authored syntax and count it as independent native credit.',
            'Reject fallback/unconfigured compiled_source_sha256, empty or unexpected dladdr path, wrong epoch/robot/base/right-left joints. Bind sample model.name and scoped links to the exact expected model, not only the supplied robot label.',
            'Archive generated effective SDF and prove that removing only the exact observer plugin restores the original effective model XML; original driver plugin/epoch/audit path and a014 loaded library remain exact. Record observer build source macro, actual library byte SHA and PID/start/maps inode/device provenance before claiming loaded source custody.',
            'Source macro plus dladdr pathname is not by itself an actual ELF hash/URI/custody proof. Current target source isolation does not prove future rebuilt driver binary bytes unchanged; independently verify a014 driver bytes after the real build.',
            'Observer does not expose private driver target/actuation sequence. Bind actual tagged target/storage/actuation JSON and motor targets offline by epoch/clock/order; do not invent per-packet identity or join only equal values.',
            'Independent reader must bind complete inclusive capture window with one ordered pre/post per iteration, exact namespace and1ms clock progression, finite fields, explicit EOF/pair closure and flush/IO validity. Missing file/row, incomplete pair, write/callback failure or window omission is diagnostic FAIL, never healthy data.',
            'The illustrative0..10s capture window is not a task-relative guarantee and can finish in warmup. Predeclare a window that actually contains release, eligible movement and the whole relevant zero tail, plus adequate raw source tail. Do not infer task scope merely from observer first/last timestamps.',
            'V3 has world-scoped residual/contact counts only and no per-pair contact geometry/wrench or actual surface readbacks. It can separate phase/measurement versus body motion and show correlations, but cannot attribute a particular robot support contact or solver impulse as the cause.',
            'Pair-flush IO and JSON overhead must fit prospective storage/wall limits. CPU syntax gives no throughput estimate. Callback errors may prevent clean exit; retain diagnostic infrastructure failure and all owned cleanup evidence rather than changing failure classification.'],
        'proposed_experiment_boundary': {
            'status': 'design_review_only_no_GO_or_native',
            'baseline': 'prospective32step baseline/1800wall, exactly3robots, original guard/owned/storage/task/physical gates unchanged; all attempts charged and retained',
            'optional_refinement': 'only if predeclared before any result, a separate32step iters150 comparison/1800wall with same observer and all other physical/control settings; actual native ODE getter must prove150, no post-hoc profile change or retries-until-PASS',
            'scope': 'Neither branch is a complete four-stage P2A.0 acceptance matrix or a causal proof from one observed pair; preserve original V17 nonrest FAIL and .01/3source/.78/.144/95% gates.'},
        'validation_scope': {'reviewer_reran_author_syntax': False,
            'reviewer_executed_gazebo_or_ros_or_native_or_formal': False,
            'canonical_or_author_directory_edited': False,
            'independent_cpu_check': 'nlohmann NaN serialization only; source/exact compile+run argv/stdout preserved separately',
            'author_result_only': {'syntax_passed': authored_checks['passed'],
                'source_sha256': authored_checks['candidate_source_sha256'],
                'scope': authored_checks['scope']}},
        'source_bindings': bindings, 'review_source_sha256': sha(Path(__file__).read_bytes()),
        'limits': ['This review applies exactly to fbc9/8276 v3 bytes. Any author v4 must receive its own source/hash review; findings are not automatically resolved by a future message.',
            'No actual solver value, participant, generated runtime SDF, observer ELF load or real IO/lifetime fault was exercised here.']}
    for path, proof in bindings.items():
        assert sha(Path(path).read_bytes()) == proof['sha256'], 'source changed during review: ' + path
    OUT.write_text(json.dumps(review, indent=2, sort_keys=True, allow_nan=False) + '\n')
    MD.write_text("""# V18 observer v3 独立只读复核

对象为patch8276a4ec/sourcefbc9c228，未改作者目录或canonical，未启动native/formal。分离插件、默认不插入SDF及有限noninterference措辞合理；尚不能据此宣称实际solver参数来源完整。

**必须窄修 R1**：configuration只经GetParam读取。官方11.10.2的iters/sor/CFM/ERP等来自SDF缓存，v3没有GetWorldId/dWorldGet原生getter；设计把它们统称actual过强。建议新版本分开cached与native参数，直接读ODE world并绑定实际engine/library。此为证据不足，不是已证当前native参数错误。

**建议窄补 R2/R3**：post除clock外再核同iteration；显式处理double非有限值。独立微型CPU已证nlohmann把available:true/NaN写成value:null，不能把它读成0或健康；未声称原生solver有NaN。

正向核验：patch独立重建完全同；原driver四源/原CMake快照和canonical相等；正常model/launch均无该plugin。origin/CoG API字段正确，vel/fmax是电机参数、GetForce不是反力/ACK的限定正确。weak callback在返回前持有State；但未作native生命周期证明。wx独占及fwrite/每pair fflush检查会把错误变成诊断infra failure；未捕获异常可能终止engine，不能称无害。设计已准确保留JSON/IO造成wall与回调负载的限制。

正式准入仍需actual observer ELF/compiled macro/库SHA/路径/PIDstart/maps绑定、generated SDF只增observer的逆差分、a014原driver重建后字节验证，以及真正任务窗口内完整finite的1ms pre/post reader。示例0..10秒可能仅覆盖warmup。源只提供world residual/contact count，不能定位单个地面接触；desired/target/actuation仍需从原driver账本真实因果绑定，不可伪造private seq。

32step/1800wall baseline及可选iters150/1800wall均只是事前设计，尚无GO实验。迭代对比必须保持同observer及其他物理/control值，实际原生getter证实150；原.01/三样本/.78/.144/95%等门和V17真FAIL保持。新baseline只诊断，不授完整四stage/P2A.0信用。

详见同名JSON的逐字段/行号证据、source before/after SHA和独立非有限值CPU回执。此结论只适用于v3，不自动替代作者后续新版本复核。
""")
    print(json.dumps({'output': str(OUT), 'output_sha256': sha(OUT.read_bytes()),
        'markdown': str(MD), 'markdown_sha256': sha(MD.read_bytes()),
        'source_sha256': sha(Path(__file__).read_bytes()), 'input_count': len(bindings),
        'inputs_before_after_stable': True, 'critical_findings': ['R1'],
        'native_started': False, 'canonical_mutation': False}, sort_keys=True))

if __name__ == '__main__':
    main()
