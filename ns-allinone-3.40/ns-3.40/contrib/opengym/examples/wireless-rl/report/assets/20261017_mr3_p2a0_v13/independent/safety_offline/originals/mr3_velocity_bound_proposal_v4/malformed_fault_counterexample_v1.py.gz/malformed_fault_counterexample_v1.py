import json,sys
sys.path.insert(0,sys.argv[1])
import test_node_proposal as test
value=test.node()
value.received["robots"][0]["odometry"]["twist"]=None
try:
 result=value.normal_velocity_fault(test.TARGET)
 print(json.dumps({"exception":None,"fault":result},sort_keys=True,allow_nan=False))
except Exception as error:
 print(json.dumps({"exception":type(error).__name__,"message":str(error)},sort_keys=True))
