"""Preserve late publication/observer originals; immutable main manifest stays intact."""
import gzip
import hashlib
import json
from pathlib import Path

R = Path('/home/zhuyulab/ns3-workspace')
A = R / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v16'
D = A / 'independent/offline_publication_v1'
assert not D.exists()
paths = sorted(Path('/tmp').glob('mr3_p2a0_v16_offline_publish*'))
paths += sorted(Path('/tmp').glob('mr3_p2a0_v16_prefreeze*'))
paths.append(Path('/tmp/mr3_p2a0_v16_git_add_dryrun_prefreeze_v1.log'))
paths.append(Path(__file__))
assert all(p.is_file() and not p.is_symlink() for p in paths)
D.mkdir()
rows = []
sha = lambda raw: hashlib.sha256(raw).hexdigest()
for path in paths:
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    signature = lambda st: (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns)
    assert signature(before) == signature(after)
    encoded = gzip.compress(raw, mtime=0)
    assert gzip.decompress(encoded) == raw
    target = D / (path.name + '.gz')
    with target.open('xb') as output:
        output.write(encoded)
    assert path.read_bytes() == raw and signature(path.stat()) == signature(after)
    rows.append(dict(source=str(path), selected=str(target.relative_to(R)),
                     raw_bytes=len(raw), raw_sha256=sha(raw),
                     encoded_bytes=len(encoded), encoded_sha256=sha(encoded), encoding='gzip'))
result = dict(schema='mr3-v16-offline-publication-originals-v1', entries=rows,
              self_excluded=True,
              scope='Late publication receipt/verification and final static prefreeze source/allowlist originals. '
                    'No native/formal/PPO credit; main offline manifest unchanged.')
manifest = D / 'manifest.json'
with manifest.open('x') as output:
    output.write(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(passed=True, count=len(rows), raw_bytes=sum(x['raw_bytes'] for x in rows),
                     encoded_bytes=sum(x['encoded_bytes'] for x in rows),
                     manifest_sha256=sha(manifest.read_bytes()))))
