"""Descriptive paired analysis after both fixed V19 observer reviews pass.

This never reruns or replaces the original stopping/physical consumers.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
FORMAL_CONSUMER = ROOT / (
    'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/'
    '20261018_mr3_p2a0_v18/independent/mr3_independent_stop_observer_v1.py')
FORMAL_SHA = 'e61ce4e00907ab35e196f7abe9fadfd9da099af3542f98dc773d593c33ca2b65'
COMPILED_SHA = '4e721e15ee7c67938c1f2c1dbd3005e0832adb0182c66d6dce6ddcafaf7c0396'
SCHEMA = 'mr3-stop-response-observer-v1'
ROBOTS = ('tb1', 'tb2', 'tb3')
PRE = 'before_physics_after_collision'
POST = 'world_update_end_after_physics_and_pose_propagation'
TICK_NS = 1_000_000
LATE_NS = 780_000_000


def need(value, reason):
    if not value:
        raise ValueError(reason)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def integer(value):
    need(type(value) is int and value >= 0, 'invalid_integer')
    return value


def number(value):
    need(type(value) in (float, int) and math.isfinite(value), 'invalid_number')
    return value


def vector(value):
    need(type(value) is list and len(value) == 3, 'invalid_vector')
    return [number(item) for item in value]


def decode(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, 'duplicate_json_key')
            result[key] = value
        return result

    def bad(value):
        raise ValueError('nonfinite_json_constant:' + value)

    return json.loads(raw, object_pairs_hook=pairs, parse_constant=bad)


def finite_tree(value):
    if type(value) is float:
        need(math.isfinite(value), 'nonfinite_tree')
    elif type(value) is dict:
        for child in value.values():
            finite_tree(child)
    elif type(value) is list:
        for child in value:
            finite_tree(child)


def identity(stat):
    return (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)


class Moments:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.square = 0.0
        self.minimum = None
        self.maximum = None

    def add(self, value):
        value = number(value)
        self.count += 1
        self.total = number(self.total + value)
        self.square = number(self.square + value * value)
        self.minimum = value if self.minimum is None else min(self.minimum, value)
        self.maximum = value if self.maximum is None else max(self.maximum, value)

    def result(self):
        return {'count': self.count, 'minimum': self.minimum, 'maximum': self.maximum,
                'mean': self.total / self.count if self.count else None,
                'rms': math.sqrt(self.square / self.count) if self.count else None}


class VectorMoments:
    def __init__(self):
        self.axes = [Moments() for _ in range(3)]
        self.planar = Moments()

    def add(self, value):
        value = vector(value)
        for item, accumulator in zip(value, self.axes):
            accumulator.add(item)
        self.planar.add(math.hypot(*value[:2]))

    def result(self):
        return {'xyz': [item.result() for item in self.axes],
                'planar_norm': self.planar.result()}


def extracted(row, robot):
    """Only stateless finite vector extraction, not the heavy formal replay."""
    need(row['model']['name'] == robot, 'sample_model_mismatch')
    model = row['model']
    values = {'model': (vector(model['world_pose']['position_xyz']),
                        vector(model['world_linear_velocity_xyz']))}
    for name, scoped in (('canonical', 'base_footprint'), ('base', 'base_link')):
        link = row[name]
        need(link['name'] == robot + '::' + scoped, 'sample_link_mismatch')
        for suffix, pose_key, velocity_key in (
                ('origin', 'world_pose', 'world_origin_linear_velocity_xyz'),
                ('cog', 'world_cog_pose', 'world_cog_linear_velocity_xyz')):
            values[name + '_' + suffix] = (
                vector(link[pose_key]['position_xyz']), vector(link[velocity_key]))
    wheels = row['joints_right_left']
    need(type(wheels) is list and len(wheels) == 2, 'invalid_wheels')
    for wheel, side in zip(wheels, ('right', 'left')):
        need(wheel['name'] == robot + '::wheel_' + side + '_joint', 'wheel_name_mismatch')
        number(wheel['motor_velocity_target_radps'])
        number(wheel['velocity_radps'])
    return values, wheels


class PairedSummary:
    def __init__(self, robot, epoch, start, end):
        self.robot, self.epoch, self.start, self.end = robot, epoch, start, end
        need(type(epoch) is str and bool(epoch), 'invalid_epoch')
        need(integer(start) < integer(end) and start % TICK_NS == end % TICK_NS == 0,
             'invalid_task_interval')
        self.header = None
        self.sequence = 0
        self.pending = None
        self.last_pair = 0
        self.last_clock = None
        self.last_iteration = None
        self.complete = False
        self.next_task = start
        self.task_pairs = 0
        self.zero_pairs = 0
        self.late_pairs = 0
        self.inconsistent_motor_zero_pairs = 0
        self.current_streak = None
        self.streaks = []
        self.stats = {}
        self.wheels = {}

    def accumulator(self, key):
        return self.stats.setdefault(key, VectorMoments())

    def end_streak(self):
        if self.current_streak is not None:
            self.streaks.append(self.current_streak)
            self.current_streak = None

    def observe(self, pre, post):
        clock = pre['sim_time_ns']
        a, pre_wheels = extracted(pre, self.robot)
        b, post_wheels = extracted(post, self.robot)
        pre_zero = all(wheel['motor_velocity_target_radps'] == 0 for wheel in pre_wheels)
        post_zero = all(wheel['motor_velocity_target_radps'] == 0 for wheel in post_wheels)
        self.inconsistent_motor_zero_pairs += int(pre_zero != post_zero)
        if not (pre_zero and post_zero):
            self.end_streak()
            return
        self.zero_pairs += 1
        if self.current_streak is None:
            self.current_streak = {
                'start_ns': clock, 'end_ns': clock, 'pair_count': 0, 'late_pair_count': 0,
                'first_late_ns': None, 'last_late_ns': None,
                'carryin_before_task_release_not_counted': clock == self.start}
        streak = self.current_streak
        streak['end_ns'] = clock
        streak['pair_count'] += 1
        if clock - streak['start_ns'] < LATE_NS:
            return
        self.late_pairs += 1
        streak['late_pair_count'] += 1
        if streak['first_late_ns'] is None:
            streak['first_late_ns'] = clock
        streak['last_late_ns'] = clock
        for name in a:
            pre_position, pre_velocity = a[name]
            post_position, post_velocity = b[name]
            displacement = [number(y - x) for x, y in zip(pre_position, post_position)]
            difference = [number(value / .001) for value in displacement]
            self.accumulator(name + '.pre_getter_velocity').add(pre_velocity)
            self.accumulator(name + '.post_getter_velocity').add(post_velocity)
            both = self.accumulator(name + '.both_phases_getter_velocity')
            both.add(pre_velocity)
            both.add(post_velocity)
            self.accumulator(name + '.pre_to_post_displacement_m').add(displacement)
            self.accumulator(name + '.pre_to_post_difference_velocity').add(difference)
            self.accumulator(name + '.difference_minus_pre_getter').add(
                [number(x - y) for x, y in zip(difference, pre_velocity)])
            self.accumulator(name + '.difference_minus_post_getter').add(
                [number(x - y) for x, y in zip(difference, post_velocity)])
        for phase, wheels in (('pre', pre_wheels), ('post', post_wheels)):
            for side, wheel in zip(('right', 'left'), wheels):
                self.wheels.setdefault(phase + '.' + side, Moments()).add(wheel['velocity_radps'])

    def record(self, row):
        need(type(row) is dict and row.get('schema') == SCHEMA, 'unknown_schema')
        need(row.get('epoch') == self.epoch and row.get('robot') == self.robot,
             'row_identity_mismatch')
        need(integer(row.get('record_sequence')) == self.sequence + 1, 'record_sequence_gap')
        self.sequence += 1
        integer(row.get('sim_time_ns'))
        integer(row.get('world_iterations'))
        need(row.get('measurements_finite') is True, 'producer_nonfinite')
        finite_tree(row)
        kind = row.get('kind')
        if kind == 'configuration':
            need(self.sequence == 1 and self.header is None, 'duplicate_configuration')
            need(row.get('compiled_source_sha256') == COMPILED_SHA, 'unknown_compiled_source')
            self.header = row
            return
        need(self.header is not None and not self.complete, 'invalid_capture_lifecycle')
        if kind == 'capture_complete':
            need(self.pending is None and row.get('last_pair_sequence') == self.last_pair,
                 'incomplete_capture')
            self.complete = True
            return
        need(kind == 'sample' and row.get('phase') in (PRE, POST), 'unknown_kind_or_phase')
        clock = row['sim_time_ns']
        iteration = row['world_iterations']
        pair = integer(row.get('pair_sequence'))
        need(type(row.get('pair_iterations')) is int and row['pair_iterations'] == iteration,
             'pair_iterations_mismatch')
        need(type(row.get('before_clock_ns')) is int and row['before_clock_ns'] == clock,
             'before_clock_mismatch')
        if self.start <= clock <= self.end:
            need(row.get('physics_enabled') is True, 'task_physics_disabled')
        if row['phase'] == PRE:
            need(self.pending is None and pair == self.last_pair + 1,
                 'missing_or_duplicate_pre_post_pair')
            need(type(row.get('before_record_sequence')) is int
                 and row['before_record_sequence'] == self.sequence, 'before_sequence_mismatch')
            if self.last_clock is not None:
                need(clock == self.last_clock + TICK_NS and iteration == self.last_iteration + 1,
                     'capture_clock_or_iteration_gap')
            self.pending = row
            return
        need(self.pending is not None, 'post_without_pre')
        pre = self.pending
        need(pair == pre['pair_sequence'] and clock == pre['sim_time_ns']
             and iteration == pre['world_iterations']
             and type(row.get('before_record_sequence')) is int
             and row['before_record_sequence'] == pre['record_sequence'], 'pre_post_mismatch')
        if self.start <= clock <= self.end:
            need(clock == self.next_task, 'task_pair_gap')
            self.next_task += TICK_NS
            self.task_pairs += 1
            self.observe(pre, row)
        self.last_pair, self.last_clock, self.last_iteration = pair, clock, iteration
        self.pending = None

    def finish(self):
        need(self.header is not None and self.pending is None, 'missing_header_or_final_post')
        need(self.next_task == self.end + TICK_NS, 'task_interval_incomplete')
        self.end_streak()
        return {'robot': self.robot, 'actual_interval': {'start_ns': self.start, 'end_ns': self.end},
                'task_pairs': self.task_pairs, 'both_motor_zero_pairs': self.zero_pairs,
                'late_zero_pairs': self.late_pairs,
                'pre_post_zero_status_differs_pairs': self.inconsistent_motor_zero_pairs,
                'all_zero_streaks': self.streaks,
                'all_late_zero_streaks': [row for row in self.streaks if row['late_pair_count']],
                'late_zero_vectors': {key: value.result() for key, value in self.stats.items()},
                'late_zero_actual_wheel_velocity_radps': {
                    key: value.result() for key, value in self.wheels.items()}}


def read_small(path, bindings, expected=None):
    path = Path(path)
    before = path.stat()
    raw = path.read_bytes()
    need(identity(before) == identity(path.stat()), 'small_input_changed_during_read')
    digest = sha(raw)
    need(expected is None or digest == expected, 'small_input_sha_mismatch')
    proof = {'sha256': digest, 'bytes': len(raw)}
    need(str(path) not in bindings or bindings[str(path)] == proof, 'small_input_replaced')
    bindings[str(path)] = proof
    return decode(raw)


def expected_binding(report, path):
    result = report['inputs'][str(Path(path))]
    need(type(result) is dict and type(result.get('bytes')) is int
         and type(result.get('sha256')) is str and len(result['sha256']) == 64,
         'invalid_formal_input_binding')
    return result


def prepare(reviews, plan_path, freeze, bindings):
    need(type(freeze) is str and len(freeze) == 40
         and all(value in '0123456789abcdef' for value in freeze), 'invalid_freeze')
    need(sha(FORMAL_CONSUMER.read_bytes()) == FORMAL_SHA, 'formal_consumer_bytes_changed')
    bindings[str(FORMAL_CONSUMER)] = {'sha256': FORMAL_SHA,
                                     'bytes': FORMAL_CONSUMER.stat().st_size}
    plan_raw = Path(plan_path).read_bytes()
    plan_sha = sha(plan_raw)
    plan = read_small(plan_path, bindings, plan_sha)
    need(type(plan) is dict, 'invalid_plan')
    contexts = []
    # Both reports must pass before ANY raw capture is opened.
    for stage, report_path in zip(('baseline', 'iters150'), reviews):
        report = read_small(report_path, bindings)
        need(report.get('schema') == 'mr3-independent-stop-observer-review-v1'
             and report.get('passed') is True and report.get('errors') == []
             and type(report.get('errors')) is list, 'formal_observer_not_passed')
        need(report.get('consumer_sha256') == FORMAL_SHA, 'wrong_formal_consumer')
        need(report.get('freeze') == freeze and report.get('stage') == stage,
             'formal_freeze_or_stage_mismatch')
        formal_plan_path = report.get('plan_path')
        need(type(formal_plan_path) is str
             and Path(formal_plan_path).resolve() == Path(plan_path).resolve(),
             'formal_plan_path_mismatch')
        need(expected_binding(report, formal_plan_path)['sha256'] == plan_sha,
             'formal_plan_sha_mismatch')
        proof_path = report['admission_proof_path']
        proof = read_small(proof_path, bindings, expected_binding(report, proof_path)['sha256'])
        need(proof.get('schema') == 'mr3-stop-observer-admission-proof-v1'
             and proof.get('passed') is True and proof.get('freeze') == freeze
             and proof.get('plan_sha256') == plan_sha and proof.get('stage') == stage,
             'admission_identity_mismatch')
        need(report.get('epoch') == proof.get('epoch')
             and report.get('episode_directory') == proof.get('episode_directory')
             and report.get('run_directory') == proof.get('run_directory'),
             'formal_admission_scope_mismatch')
        need(proof['observer']['source_sha256'] == COMPILED_SHA, 'compiled_observer_mismatch')
        interval = report['actual_interval']
        need(type(interval) is dict and type(interval.get('returned_step_calls')) is int
             and interval['returned_step_calls'] == 32, 'unexpected_workload')
        start, end = integer(interval['start_ns']), integer(interval['end_ns'])
        need(start < end and start % TICK_NS == end % TICK_NS == 0, 'invalid_task_interval')
        need(type(report.get('robots')) is list
             and [item['robot'] for item in report['robots']] == list(ROBOTS),
             'formal_robot_scope_mismatch')
        paths = {}
        for robot in ROBOTS:
            path = Path(proof['observer_files'][robot]['path'])
            need(path.suffix == '.jsonl', 'only_actual_plain_capture_supported')
            paths[robot] = {'path': str(path), 'expected': expected_binding(report, path)}
        contexts.append({'stage': stage, 'epoch': report['epoch'], 'interval': interval,
                         'raw_files': paths, 'formal_report': str(report_path),
                         'formal_sha256': bindings[str(Path(report_path))]['sha256']})
    need(contexts[0]['epoch'] != contexts[1]['epoch'], 'same_epoch_for_two_stages')
    return contexts


def analyze_file(path, expected, robot, epoch, start, end, progress=None):
    path = Path(path)
    replay = PairedSummary(robot, epoch, start, end)
    before = path.stat()
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as stream:
        need(identity(before) == identity(os.fstat(stream.fileno())), 'opened_different_inode')
        for line_number, raw in enumerate(stream, 1):
            digest.update(raw)
            size += len(raw)
            need(raw.endswith(b'\n') and bool(raw.strip()), 'incomplete_jsonl_line')
            replay.record(decode(raw))
            if progress is not None:
                progress(line_number, path)
        after_fd = os.fstat(stream.fileno())
    need(identity(before) == identity(after_fd) == identity(path.stat()),
         'raw_capture_stat_changed')
    actual_sha = digest.hexdigest()
    need(type(expected.get('bytes')) is int and size == expected['bytes']
         and actual_sha == expected['sha256'], 'raw_capture_sha_or_size_changed')
    result = replay.finish()
    result['input'] = {'path': str(path), 'sha256': actual_sha, 'bytes': size,
                       'stat_identity_before_after': list(identity(before)),
                       'whole_file_single_pass': True, 'records': replay.sequence}
    return result


def analyze(reviews, plan_path, freeze):
    started = time.monotonic()
    small = {}
    contexts = prepare(reviews, plan_path, freeze, small)
    results = []
    for context in contexts:
        robots = []
        interval = context['interval']
        for robot in ROBOTS:
            item = context['raw_files'][robot]
            robots.append(analyze_file(item['path'], item['expected'], robot, context['epoch'],
                                       interval['start_ns'], interval['end_ns']))
        results.append({**context, 'robots': robots})
    for path, proof in small.items():
        raw = Path(path).read_bytes()
        need(len(raw) == proof['bytes'] and sha(raw) == proof['sha256'],
             'small_input_changed_before_summary')
    return {
        'schema': 'mr3-v19-paired-zero-motor-description-v1',
        'analysis_completed': True, 'preparation_matrix_credit': False,
        'freeze': freeze, 'plan_sha256': small[str(Path(plan_path))]['sha256'],
        'stages': results, 'small_inputs': small,
        'selection': {'task_interval': 'actual formal reset release through last step inclusive',
                      'phase_selection': 'both wheel motor targets exactly zero in BOTH pre/post',
                      'continuous_sampled_zero_elapsed_ns': LATE_NS,
                      'boundary': 'elapsed >=780000000 inclusive; all matching pairs/all streaks',
                      'carryin': 'zero history resets at task release; no earlier duration assumed',
                      'weighting': 'pre/post separately and combined at equal sample weights'},
        'limits': [
            'Purely descriptive, conditioned on two unchanged formal observer PASS receipts.',
            'No reclassification of .01/three-source/.78/.144 or original30Hz physical verdict.',
            'Sampled exact-zero GetParam motor targets are not physical rest or zero wheel speed.',
            'All eligible streaks and samples are retained, not the longest/best stopping window.',
            'Pre/post displacement /1ms is sampled pose propagation, not a continuous theorem.',
            'No claim of V17 reproduction, unique cause, solver repair or policy95% success.'
        ],
        'execution': {'argv': sys.argv, 'cwd': str(Path.cwd()),
                      'environment': {key: os.environ.get(key) for key in
                                      ('PYTHONNOUSERSITE', 'PYTHONDONTWRITEBYTECODE')},
                      'wall_seconds': time.monotonic() - started,
                      'analysis_source_sha256': sha(Path(__file__).read_bytes()),
                      'formal_source_sha256': FORMAL_SHA,
                      'compiled_observer_source_sha256': COMPILED_SHA}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', required=True, type=Path)
    parser.add_argument('--freeze', required=True)
    parser.add_argument('--baseline-review', required=True, type=Path)
    parser.add_argument('--contrast-review', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    need(not args.output.exists(), 'output_already_exists')
    result = analyze([args.baseline_review, args.contrast_review], args.plan, args.freeze)
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'analysis_completed': True, 'output': str(args.output),
                      'sha256': sha(args.output.read_bytes()), 'preparation_matrix_credit': False}))


if __name__ == '__main__':
    main()
