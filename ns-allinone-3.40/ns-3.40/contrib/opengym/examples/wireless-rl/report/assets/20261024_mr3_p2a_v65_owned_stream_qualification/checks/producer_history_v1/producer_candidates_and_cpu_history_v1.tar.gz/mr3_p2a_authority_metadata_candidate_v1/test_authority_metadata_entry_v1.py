"""Artificial metadata/RPC/public admission only; no ROS graph or learning."""
import ast
import contextlib
import copy
import importlib
import io
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch

ROOT=Path('/home/zhuyulab/ns3-workspace')
W=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
HERE=Path(__file__).resolve().parent
SHADOW=HERE/'shadow'/W.relative_to(ROOT)/'mr3_learning'
sys.path.insert(0,str(W))
import mr3_learning
mr3_learning.__path__.insert(0,str(SHADOW))
from mr3_learning import motion_authority_profile as profiles
from mr3_learning import supervisor as sup
from mr3_learning import benchmark as bench
from mr3_learning import ppo
from mr3_learning import reach_preparation as preparation
sup.WORKSPACE=ROOT
sup.ROS_ROOT=ROOT/'ros2_ws/ros2-multi-robot-automap'
bench.WORKSPACE=ROOT
ppo.WORKSPACE=ROOT

PROFILE='mr3-owned-stream-authority-v1'
WORKER=HERE/'shadow/ros2_ws/ros2-multi-robot-automap/scripts/mr3_env_worker.py'
worker_tree=ast.parse(WORKER.read_text())
node=next(n for n in worker_tree.body if isinstance(n,ast.FunctionDef) and n.name=='motion_authority_profile_from_request')
worker_namespace={'MOTION_AUTHORITY_PROFILE':PROFILE}
exec(compile(ast.Module(body=[node],type_ignores=[]),str(WORKER),'exec'),worker_namespace)
worker_profile=worker_namespace['motion_authority_profile_from_request']


class AdmissionReached(Exception):pass


def artificial_qualification():
    episodes=[{'directory':f'/ARTIFICIAL/episode{i:03d}','epoch':f'artificial-{i}'} for i in range(12)]
    proof={'schema':'mr3-independent-motion-authority-qualification-v1','profile':PROFILE,
        'passed':True,'freeze':'a'*40,'raw_generation_known':False,
        'episodes':[dict(row,passed=True,profile=PROFILE,robots=['tb1','tb2','tb3'],
                         runtime_result_sha256='0'*64) for row in episodes]}
    return {'safety_contract':'mr3-reach-v1','motion_authority_profile':PROFILE,
            'freeze':'a'*40,'episodes':episodes,'motion_authority_replay':proof}


class MetadataEntryContracts(unittest.TestCase):
    def test_fixed_accessor_and_worker_typed_contract(self):
        self.assertIsNone(profiles.motion_authority_profile_for_safety_contract('legacy'))
        self.assertEqual(profiles.motion_authority_profile_for_safety_contract('mr3-reach-v1'),PROFILE)
        for bad in (True,None,1,[],{},'reach'):
            with self.assertRaises(ValueError):profiles.motion_authority_profile_for_safety_contract(bad)
        self.assertIsNone(worker_profile({}))
        self.assertIsNone(worker_profile({'safety_contract':'legacy','motion_authority_profile':None}))
        self.assertEqual(worker_profile({'safety_contract':'mr3-reach-v1','motion_authority_profile':PROFILE}),PROFILE)
        for contract,profile in (('legacy',PROFILE),('mr3-reach-v1',None),('mr3-reach-v1',True),
                                 ('mr3-reach-v1',''),('mr3-reach-v1','initial-zero-encoder-hold-v1')):
            with self.assertRaises(ValueError):worker_profile({'safety_contract':contract,'motion_authority_profile':profile})
        init=next(n for n in worker_tree.body if isinstance(n,ast.ClassDef) and n.name=='Worker')
        init=next(n for n in init.body if isinstance(n,ast.FunctionDef) and n.name=='__init__')
        names=[n.func.id for n in ast.walk(init) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)]
        self.assertIn('motion_authority_profile_from_request',names)
        self.assertNotIn('mr3_motion_authority_profile:=',WORKER.read_text())

    def test_supervisor_actual_reset_rpc_metadata_and_legacy_shape(self):
        for contract in ('legacy','mr3-reach-v1'):
            with tempfile.TemporaryDirectory() as temp:
                supervisor=sup.Supervisor(output_root=temp,safety_contract=contract)
                requests=[]
                class Peer:
                    def send(self,value):requests.append(copy.deepcopy(value))
                    def receive(self,timeout):
                        value=requests[-1]
                        return {'id':value['id'],'epoch':value['epoch'],'ok':True,
                                'result':{'snapshot':{'epoch':value['epoch']}}}
                fixture_identity={'pid':12345,'parent':1,'group':12345,'session':12345,'start_ticks':5,'state':'S'}
                dummy=NS(pid=12345,stdout=NS(fileno=lambda:0),stdin=NS(fileno=lambda:1))
                with patch.object(sup.subprocess,'Popen',return_value=dummy) as launch, \
                     patch.object(sup,'process_identity',return_value=fixture_identity), \
                     patch.object(sup,'JsonLinePeer',return_value=Peer()), \
                     patch.object(sup,'remember_processes'):
                    try:result=supervisor.reset(scene='open',seed=101)
                    finally:
                        if supervisor.episode is not None:
                            supervisor.episode.stop_monitor.set();supervisor.episode.monitor.join(timeout=1)
                            supervisor.episode.output.close()
                self.assertEqual(requests[0]['op'],'reset')
                metadata=json.loads((supervisor.episode.directory/'supervisor_metadata.json').read_text())
                expected=PROFILE if contract=='mr3-reach-v1' else None
                self.assertEqual(supervisor.motion_authority_profile,expected)
                self.assertEqual(requests[0].get('motion_authority_profile'),expected)
                self.assertEqual(metadata.get('motion_authority_profile'),expected)
                if expected is None:
                    self.assertNotIn('motion_authority_profile',requests[0])
                    self.assertNotIn('motion_authority_profile',metadata)
                else:
                    self.assertEqual(requests[0]['safety_contract'],'mr3-reach-v1')
                    self.assertEqual(metadata['actuation_profile'],'initial-zero-encoder-hold-v1')
                self.assertEqual(result['snapshot']['epoch'],requests[0]['epoch'])
                launch.assert_called_once()

    def test_worker_launch_metadata_uses_same_fixed_contract(self):
        # Execute the exact constructor's launch/metadata region with explicit
        # artificial values. Heavy ROS graph/thread/World initialization is not
        # run and this does not claim full Worker lifecycle qualification.
        cls=next(n for n in worker_tree.body if isinstance(n,ast.ClassDef) and n.name=='Worker')
        init=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='__init__')
        start=next(i for i,n in enumerate(init.body) if isinstance(n,ast.Assign)
            and any(isinstance(t,ast.Attribute) and t.attr=='command' for t in n.targets))
        end=next(i for i,n in enumerate(init.body) if i>start and isinstance(n,ast.Expr)
            and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute)
            and n.value.func.attr=='write_text')
        selected=init.body[start:end+1]
        def actuation(contract):return 'initial-zero-encoder-hold-v1' if contract=='mr3-reach-v1' else None
        from mr3_learning.supervisor import actuation_profile_for_safety_contract
        for contract in ('legacy','mr3-reach-v1'):
            with tempfile.TemporaryDirectory() as temp:
                directory=Path(temp)
                shell=NS(epoch='artificial_epoch',scene='open',seed=101,safety_contract=contract,
                    motion_authority_profile=PROFILE if contract=='mr3-reach-v1' else None,
                    reach_geometry_rule='binary-cone-v1',seed_rule='legacy',start_graph_rule='original-seed-cell',
                    terminal_probe=False,plant_stimulus_arm=None,plant_stimulus_work_deadline_ns=None,
                    transport_environment={},control_version=2 if contract=='mr3-reach-v1' else 1,
                    startup_readiness_protocol='received-input-pause-drain-v1',startup_deadline_ns=900,
                    startup_wait_deadline_ns=800)
                env={'self':shell,'directory':directory,'ROS_ROOT':ROOT/'ros2_ws/ros2-multi-robot-automap',
                    'WORKSPACE':ROOT,'subprocess':NS(check_output=lambda *a,**k:'a'*40),'json':json,
                    'os':importlib.import_module('os'),'sys':sys,'BINARY_CONE_V1':'binary-cone-v1',
                    'CONTROL_PROTOCOL':'mr3-controlled-execution-phase-v1','CONTROL_WALL_GUARD_SEC':10,
                    'PHASE_PROTOCOL':'mr3-evaluator-phase-v1','PHASE_WALL_GUARD_SEC':10,
                    'SHUTDOWN_PROTOCOL':'artificial-existing-protocol','NAV2_SHUTDOWN_WALL_GUARD_SEC':30,
                    'STARTUP_CLEANUP_RESERVE_SEC':60.,'STARTUP_RESPONSE_RESERVE_SEC':5.,
                    'actuation_profile_for_safety_contract':actuation_profile_for_safety_contract}
                exec(compile(ast.Module(body=selected,type_ignores=[]),str(WORKER),'exec'),env)
                metadata=json.loads((directory/'metadata.json').read_text())
                self.assertEqual(metadata.get('motion_authority_profile'),shell.motion_authority_profile)
                self.assertIn('mr3_safety_contract:='+contract,shell.command)
                self.assertFalse(any('motion_authority_profile:=' in x for x in shell.command))
                self.assertEqual(metadata.get('actuation_profile'),actuation(contract))

    def test_public_benchmark_records_fixed_profile_without_native_worker(self):
        for contract in ('legacy','mr3-reach-v1'):
            with tempfile.TemporaryDirectory() as temp, patch.object(bench,'run_worker',return_value={
                    'worker_id':0,'episodes':[{'transitions':1,'truncated':True,'terminated':False}],
                    'shutdown_receipts':[],'error':None}), patch.object(bench,'resource_sample',return_value={}):
                with contextlib.redirect_stdout(io.StringIO()):
                    bench.main(['--workers','1','--steps','1','--schedule','open:101','--run-id','fixture',
                                '--output-root',temp,'--safety-contract',contract])
                metadata=json.loads((Path(temp)/'fixture/benchmark_metadata.json').read_text())
                self.assertEqual(metadata.get('motion_authority_profile'),PROFILE if contract=='mr3-reach-v1' else None)
                self.assertEqual(metadata.get('actuation_profile'),
                    'initial-zero-encoder-hold-v1' if contract=='mr3-reach-v1' else None)
                if contract=='mr3-reach-v1':self.assertFalse(metadata['training_eligible'])

    def test_public_PPO_missing_or_mixed_authority_refuses_before_targets_or_model(self):
        base={'safety_contract':'mr3-reach-v1','actuation_profile':'initial-zero-encoder-hold-v1',
              'motion_authority_profile':PROFILE}
        # Reader qualification is mocked only at the preexisting admission API;
        # this checks public PPO's extra refusal, not native qualification.
        for plan,qualification in ((dict(base),{}),
                ({k:v for k,v in base.items() if k!='motion_authority_profile'},artificial_qualification()),
                (dict(base,motion_authority_profile='wrong'),artificial_qualification()),
                (dict(base),{'motion_authority_profile':PROFILE,'motion_authority_proof':{'passed':False}})):
            with tempfile.TemporaryDirectory() as temp, \
                 patch.object(preparation,'load_plan',return_value=plan), \
                 patch.object(preparation,'validate_qualification',return_value=qualification), \
                 patch.object(ppo.subprocess,'check_output',return_value='a'*40), \
                 patch.object(ppo,'MaskablePPO') as model, \
                 patch.object(ppo,'build_rollout_buffer') as targets, \
                 patch.object(ppo,'collect_episodes') as collect, \
                 contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises((ValueError,SystemExit)):
                    ppo.main(['--run-id','refused','--output-root',temp,'--decisions','2','--wall-seconds','1',
                        '--device','cpu','--safety-contract','mr3-reach-v1','--reach-plan',temp+'/plan.json',
                        '--reach-qualification',temp+'/qualification.json'])
                model.assert_not_called();targets.assert_not_called();collect.assert_not_called()
                self.assertFalse((Path(temp)/'refused').exists())

    def test_public_PPO_positive_complete_twelve_role_gate_reaches_only_pre_model_boundary(self):
        plan={'safety_contract':'mr3-reach-v1','actuation_profile':'initial-zero-encoder-hold-v1',
              'motion_authority_profile':PROFILE}
        qualification=artificial_qualification();proof=qualification['motion_authority_replay']
        self.assertEqual(profiles.require_qualified_motion_authority(qualification),proof)
        for mutate in (lambda q:q['motion_authority_replay']['episodes'].pop(),
                       lambda q:q['motion_authority_replay'].update(raw_generation_known=True),
                       lambda q:q['motion_authority_replay']['episodes'][0].update(robots=['tb1','tb2'])):
            invalid=copy.deepcopy(qualification);mutate(invalid)
            with self.assertRaises(ValueError):profiles.require_qualified_motion_authority(invalid)
        with tempfile.TemporaryDirectory() as temp, \
             patch.object(preparation,'load_plan',return_value=plan), \
             patch.object(preparation,'validate_qualification',return_value=qualification), \
             patch.object(ppo.subprocess,'check_output',return_value='a'*40), \
             patch.object(ppo.time,'monotonic',side_effect=AdmissionReached('after admission before model')), \
             patch.object(ppo,'MaskablePPO') as model, \
             patch.object(ppo,'build_rollout_buffer') as targets:
            with self.assertRaises(AdmissionReached):
                ppo.main(['--run-id','stopped_before_model','--output-root',temp,'--decisions','2',
                    '--wall-seconds','1','--device','cpu','--safety-contract','mr3-reach-v1',
                    '--reach-plan',temp+'/plan.json','--reach-qualification',temp+'/qualification.json'])
            model.assert_not_called();targets.assert_not_called()
            self.assertFalse((Path(temp)/'stopped_before_model').exists())


if __name__=='__main__':unittest.main(verbosity=2)
