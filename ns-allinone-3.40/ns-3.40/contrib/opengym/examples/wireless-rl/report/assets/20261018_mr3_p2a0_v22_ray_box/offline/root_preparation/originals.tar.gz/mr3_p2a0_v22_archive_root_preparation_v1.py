import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT=Path('/home/zhuyulab/ns3-workspace')
A=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v22_ray_box/offline/root_preparation'
assert not A.exists()
A.mkdir(parents=True)
paths=[Path('/tmp')/p for p in [
 'mr3_p2a0_v22_initial_root_checks_v1.json',
 'mr3_p2a0_v22_root_promote_and_checks_v1.py',
 'mr3_p2a0_v22_run_ros_relevant02_v1.py',
 'mr3_p2a0_v22_prepare_launch_cmake_v1.py',
 'mr3_p2a0_v22_promote_physics_sources_v1.py',
 'mr3_p2a0_v22_physics_source_promotion_v1.json',
 'mr3_p2a0_v22_auditor_source_promotion_v1.json',
 'mr3_p2a0_v22_select_world_configuration_v1.py',
 'mr3_p2a0_v22_selected_world_configuration_v1.json',
 'mr3_p2a0_v22_native_readback_independent_review_v1.json',
 'mr3_p2a0_v22_update_preparation_docs_v1.py',
 'mr3_p2a0_v22_archive_root_preparation_v1.py',
]]
for name in ['mr3_p2a0_v22_root_conda16_v1','mr3_p2a0_v22_root_ros_relevant02_v1',
             'mr3_p2a0_v22_ray_box_corrector_native_readback_proposal_v2',
             'mr3_p2a0_v22_launch_cmake_proposal_v1']:
    paths.extend(p for p in (Path('/tmp')/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
assert len(paths)==len(set(paths))
rows=[]; originals={}
for p in sorted(paths):
    raw=p.read_bytes(); s=p.stat()
    assert not raw.startswith(b'\x7fELF'),p
    member=str(p.relative_to('/tmp')); originals[member]=raw
    rows.append({'path':str(p),'member':member,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(), 'stat':[s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns]})
manifest={'schema':'mr3-v22-root-preparation-custody-v1','scope':'Original source preparation, exact selection/promotion, getter delta, failed invocations and final real CPU checks. No native admission or run. Original returned ROS failure was explicitly truncated.', 'files':rows}
raw=(json.dumps(manifest,indent=2)+'\n').encode()
originals['manifest_v1.json']=raw
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as tar:
    for name,data in sorted(originals.items()):
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
        tar.addfile(info,io.BytesIO(data))
encoded=gzip.compress(buffer.getvalue(),compresslevel=6,mtime=0)
(A/'originals.tar.gz').write_bytes(encoded);(A/'manifest_v1.json').write_bytes(raw)
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(encoded))) as tar:
    assert set(tar.getnames())==set(originals)
    for name,data in originals.items(): assert tar.extractfile(name).read()==data
for row in rows:
    p=Path(row['path']);s=p.stat()
    assert [s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns]==row['stat']
    assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
receipt={'schema':'mr3-v22-root-preparation-custody-receipt-v1','originals':len(rows),'original_bytes':sum(r['bytes'] for r in rows),'archive_bytes':len(encoded),'archive_sha256':hashlib.sha256(encoded).hexdigest(),'members_roundtrip':len(originals),'source_final_sha_stat_stable':True}
(A/'receipt_v1.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
