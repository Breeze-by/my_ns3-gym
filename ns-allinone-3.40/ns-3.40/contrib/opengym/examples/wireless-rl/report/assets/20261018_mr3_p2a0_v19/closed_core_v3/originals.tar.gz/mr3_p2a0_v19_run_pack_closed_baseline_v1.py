#!/usr/bin/env python3
"""Invoke the custody helper once with an exact minimal safe environment."""
import hashlib
import json
from pathlib import Path
import resource
import subprocess
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
TMP = Path('/tmp')
helper = TMP / 'mr3_p2a0_v19_pack_closed_baseline_v1.py'
argv = ['/usr/bin/python3', '-B', str(helper), '--source',
    str(ROOT / 'ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261018_v19_baseline'),
    '--target', '/tmp/mr3_p2a0_v19_selected_native_v1/baseline',
    '--prospective-prefix',
    'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v19/native/baseline',
    '--execution', '/tmp/mr3_p2a0_v19_baseline_execution.json']
env = {'PATH': '/usr/bin:/bin', 'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1',
       'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'TZ': 'UTC'}
output = TMP / 'mr3_p2a0_v19_pack_closed_baseline_execution_v1.stdout.log'
receipt = TMP / 'mr3_p2a0_v19_pack_closed_baseline_execution_v1.json'
assert not output.exists() and not receipt.exists(), 'no custody attempt overwrite/retry'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
before = helper.read_bytes()
started = time.monotonic()
cpu_before = resource.getrusage(resource.RUSAGE_CHILDREN)
with output.open('x') as stream:
    result = subprocess.run(argv, env=env, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
cpu_after = resource.getrusage(resource.RUSAGE_CHILDREN)
value = {'schema': 'mr3-v19-custody-helper-execution-v1', 'argv': argv,
         'cwd': str(ROOT), 'environment_exact': env, 'exit_code': result.returncode,
         'passed': result.returncode == 0, 'wall_seconds': time.monotonic() - started,
         'child_user_cpu_seconds': cpu_after.ru_utime - cpu_before.ru_utime,
         'child_system_cpu_seconds': cpu_after.ru_stime - cpu_before.ru_stime,
         'source_sha256_before': sha(before), 'source_sha256_after': sha(helper.read_bytes()),
         'stdout': str(output), 'stdout_sha256': sha(output.read_bytes()),
         'scope': 'Custody process only, no simulation or formal audit. Original baseline result retained; active counterpart untouched.'}
with receipt.open('x') as stream:
    json.dump(value, stream, indent=2)
    stream.write('\n')
print(json.dumps(value), flush=True)
raise SystemExit(result.returncode)
