"""Static path-only/adapter provenance checks for V14 drafts, no source imports."""
import ast
import copy
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A13 = W / 'report/assets/20261017_mr3_p2a0_v13'
A14 = W / 'report/assets/20261017_mr3_p2a0_v14'
DRAFT = Path('/tmp/mr3_p2a0_v14_coord_draft_v1')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def dump(source):
    return ast.dump(ast.parse(source), include_attributes=False)


def main():
    old_plan = json.loads((A13 / 'predeclared_plan_v13.json').read_bytes())
    plan = json.loads((DRAFT / 'predeclared_plan_v14.json').read_bytes())
    bindings = plan['independent_source_bindings']
    assert bindings[:96] == old_plan['independent_source_bindings']
    assert len(bindings) == len({b['path'] for b in bindings}) == 105
    for row in bindings:
        path = ROOT / row['path']
        if path.is_relative_to(A14):
            path = DRAFT / path.relative_to(A14)
        assert sha(path.read_bytes()) == row['sha256']
    for key in ('unchanged_gates', 'pilot_budget_unchanged', 'max_api_records',
                'max_submitted_script_decisions', 'max_total_wall_seconds',
                'physical_response_criteria', 'angular_interface_criteria',
                'angular_reset_criteria', 'settled_turn_criteria'):
        assert plan[key] == old_plan[key], key
    assert plan['readiness']['status'] == 'draft_pending_root_final_review'
    assert plan['readiness']['no_native_or_formal_authorized_by_this_template'] is True
    preserved = {}
    pairs = [
        ('mr3_p2a0_v13_launch_stage.py', 'literal version/path only'),
        ('mr3_p2a0_v13_audit_stage.py', 'reuse original A13 drivev6'),
        ('mr3_p2a0_v13_buildproof_preflight.py', 'reuse original A13 Shim monitor'),
        ('mr3_p2a0_v13_cross_stage_mapping_monitor_v1.py', 'reuse original A13 observer/binding'),
        ('mr3_v13_multiepoch_closure_binary_review_v1.py', 'checked immutable reader/path adapter'),
    ]
    for old_name, scope in pairs:
        new_name = old_name.replace('v13', 'v14')
        old_raw = (A13 / 'independent' / old_name).read_text()
        current = (DRAFT / 'independent' / new_name).read_text()
        restored = current.replace('v14', 'v13').replace('V14', 'V13')
        if 'audit_stage' in old_name:
            # All references become old version on reverse rename already.
            pass
        elif 'buildproof_preflight' in old_name:
            old_tree, new_tree = ast.parse(old_raw), ast.parse(restored)
            old_function = next(n for n in old_tree.body if isinstance(n, ast.FunctionDef)
                                and n.name == 'check_shim')
            new_tree.body = [copy.deepcopy(old_function) if isinstance(n, ast.FunctionDef)
                             and n.name == 'check_shim' else n for n in new_tree.body]
            restored = ast.unparse(new_tree)
        elif 'cross_stage' in old_name:
            restored = restored.replace(
                "OBSERVER=ROOT/'" + str((A13 / 'independent/'
                    'mr3_readonly_v13_drive_shim_process_monitor_v2.py').relative_to(ROOT)) + "'",
                "OBSERVER=Path(__file__).with_name('mr3_readonly_v13_drive_shim_process_monitor_v2.py')")
            restored = restored.replace(
                "SHIM_BINDING=ROOT/'" + str((A13 / 'independent/'
                    'mr3_v13_shim_binding_v1.json').relative_to(ROOT)) + "'",
                "SHIM_BINDING=Path(__file__).with_name('mr3_v13_shim_binding_v1.json')")
        elif 'closure' in old_name:
            tree = ast.parse(restored)
            tree.body = [n for n in tree.body if not isinstance(n, ast.FunctionDef) or
                         n.name not in ('load_checked_shim', 'call_shim_review')]
            old_tree = ast.parse(old_raw)
            old_main = next(n for n in old_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
            new_main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
            start = next(i for i, n in enumerate(old_main.body) if isinstance(n, ast.Assign)
                         and any(isinstance(t, ast.Name) and t.id == 'supplement_path' for t in n.targets))
            index = next(i for i, n in enumerate(new_main.body) if isinstance(n, ast.Assign)
                         and isinstance(n.value, ast.Call) and isinstance(n.value.func, ast.Name)
                         and n.value.func.id == 'load_checked_shim')
            new_main.body[index:index + 1] = copy.deepcopy(old_main.body[start:start + 5])
            for n in ast.walk(new_main):
                if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'call_shim_review':
                    n.func = ast.Attribute(value=ast.Name(id='supplement', ctx=ast.Load()),
                                           attr='review', ctx=ast.Load())
                    n.args = n.args[1:]
            restored = ast.unparse(tree)
        assert dump(restored) == dump(old_raw), old_name
        preserved[new_name] = {'old_source_sha256': sha(old_raw.encode()),
                               'draft_sha256': sha(current.encode()),
                               'old_AST_after_reversing_only_declared_changes': True,
                               'declared_change': scope}
    assert plan['drive_contract']['binary_build_receipt'] == old_plan['drive_contract']['binary_build_receipt']
    assert plan['drive_command_cap_audit'] == old_plan['drive_command_cap_audit']
    for key in ('binding', 'monitor', 'supplement_consumer'):
        assert plan['shim_runtime_custody'][key] == old_plan['shim_runtime_custody'][key]
    for prior, current in zip(old_plan['stages'], plan['stages']):
        assert current['command'] == [v.replace('mr3_p2a0_20261017_v13_', 'mr3_p2a0_20261017_v14_')
                                      for v in prior['command']]
        assert current['worker_bindings'] == prior['worker_bindings']
        assert current['wall_ceiling_seconds'] == prior['wall_ceiling_seconds']
    sources = {str(path): {'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())}
               for path in sorted(DRAFT.rglob('*')) if path.is_file()}
    report = {'schema': 'mr3-v14-coordinator-draft-static-v1', 'passed': True,
              'all96_A13_bindings_preserved': True, 'new_bindings': 9,
              'total_bindings': 105, 'orchestration_AST_review': preserved,
              'budgets_and_physics_angular_settled_gates_unchanged': True,
              'all4_stage_commands_equal_except_run_id': True,
              'A13_build_Drivev6_Shim_sources_reused_in_place': True,
              'readiness': plan['readiness'], 'source_bindings': sources,
              'scope': '/tmp template only; future authorized audit_ppo/XML sourcepin may '
                       'be refreshed by root, exact new freeze required before native.'}
    Path('/tmp/mr3_p2a0_v14_coord_draft_static_v2.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'passed': True, 'AST_sources': len(preserved), 'bindings': len(bindings), 'ready': False}))


if __name__ == '__main__':
    main()
