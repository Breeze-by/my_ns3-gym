#!/usr/bin/python3
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

D = Path('/tmp/mr3_p2a0_v24_closed_pack_support_v1')
TARGET = Path('/tmp/mr3_p2a0_v24_selected_closed_v1')


def digest(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    assert not D.exists()
    D.mkdir()
    result = json.loads((TARGET / 'manifest.json').read_text())
    groups = {k: Path(v['manifest']) for k,v in result['native'].items() if v['source_exists']}
    groups['metadata'] = Path(result['metadata']['manifest'])
    totals = {'source_files': 0, 'raw_bytes': 0, 'selected_parts': 0, 'selected_bytes': 0}
    group_data = {}
    for name, path in groups.items():
        value = json.loads(path.read_text())
        assert value['source_end_sha_and_stat_verified'] is True
        for key in totals:
            totals[key] += value[key]
        group_data[name] = {key: value[key] for key in totals}
        group_data[name].update(manifest=digest(path), prospective_prefix=value['prospective_prefix'])
    prefix = 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v24_install/native'
    assert all(value['prospective_prefix'].startswith(prefix + '/') for value in group_data.values())
    summary = {'schema': 'mr3-v24-closed-custody-handoff-v1',
               'scope': 'Byte custody only, original interface FAIL and terminal/reset/deadline SKIP preserved.',
               'selected_root': str(TARGET), 'top_manifest': digest(TARGET / 'manifest.json'),
               'groups': group_data, 'totals': totals,
               'copy_hint': 'Copy this selected tree to ' + prefix + ' as interface/ and metadata/ plus root configuration/manifest. Keep original manifests unchanged.',
               'execution': digest(Path('/tmp/mr3_p2a0_v24_closed_pack_execution_v1/execution.json')),
               'all_original_end_sha_and_stat_verified': result['all_original_stat_and_whole_sha_rechecked'],
               'excluded': ['Build/cache/CPU ELF not selected.', 'Small derivative forensic support sealed separately.', 'No mutable continuation state included.']}
    (D / 'handoff_v1.json').write_text(json.dumps(summary, indent=2) + '\n')
    files = [Path(__file__), Path('/tmp/mr3_p2a0_v24_run_closed_pack_v1.py'), D / 'handoff_v1.json']
    files.extend(sorted(Path('/tmp/mr3_p2a0_v24_matrix_pack_proposal_v1').iterdir()))
    files.extend(sorted(Path('/tmp/mr3_p2a0_v24_closed_pack_execution_v1').iterdir()))
    assert all(p.is_file() and not p.is_symlink() for p in files)
    bound = [digest(p) for p in files]
    archive = D / 'originals.tar.gz'
    with archive.open('xb') as out, gzip.GzipFile(filename='', mode='wb', fileobj=out, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as tar:
            for path in files:
                raw = path.read_bytes()
                item = tarfile.TarInfo(path.relative_to('/tmp').as_posix())
                item.size = len(raw)
                item.mtime = 0
                item.mode = 0o644
                tar.addfile(item, io.BytesIO(raw))
    with tarfile.open(archive, mode='r:gz') as tar:
        members = tar.getmembers()
        assert len(members) == len(files)
        for row in bound:
            member = tar.extractfile(Path(row['path']).relative_to('/tmp').as_posix())
            raw = member.read()
            assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
    assert bound == [digest(p) for p in files]
    manifest = {'schema': 'mr3-v24-closed-custody-support-manifest-v1', 'passed': True,
                'scope': summary['scope'], 'source_files': len(files), 'raw_bytes': sum(x['bytes'] for x in bound),
                'files': bound, 'archive': digest(archive), 'roundtrip_all_members_verified': True,
                'source_final_bytes_verified': True, 'writers_stopped': True}
    (D / 'manifest_v1.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'handoff': digest(D / 'handoff_v1.json'), 'manifest': digest(D / 'manifest_v1.json'),
                      'archive': digest(archive), 'source_files': len(files)}))

if __name__ == '__main__':
    main()
