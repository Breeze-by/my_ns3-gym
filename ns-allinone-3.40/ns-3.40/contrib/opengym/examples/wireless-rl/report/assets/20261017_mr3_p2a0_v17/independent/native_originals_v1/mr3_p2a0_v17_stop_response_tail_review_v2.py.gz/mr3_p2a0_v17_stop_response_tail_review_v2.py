"""Secondary diagnostic using captured subsets only, with no new raw scans."""
import ctypes
import hashlib
import json
import math
from pathlib import Path
import statistics
import struct

BASE = Path('/tmp/mr3_p2a0_v17_stop_response_raw_diagnostic_v1')
OUTPUT = Path('/tmp/mr3_p2a0_v17_stop_response_tail_review_v2.json')
INPUTS = {}
libm = ctypes.CDLL('libm.so.6')
for func in (libm.cosf, libm.sinf):
    func.argtypes = [ctypes.c_float]
    func.restype = ctypes.c_float


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    data = path.read_bytes()
    INPUTS[str(path)] = sha(data)
    return json.loads(data)


def summary(values):
    return {'n': len(values), 'min': min(values), 'max': max(values),
            'mean': statistics.mean(values), 'median': statistics.median(values),
            'negative': sum(v < 0 for v in values), 'zero': sum(v == 0 for v in values),
            'positive': sum(v > 0 for v in values)} if values else None


def coefficients(sample):
    q = sample['orientation']
    yaw = math.atan2(2*(q['w']*q['z']+q['x']*q['y']),
                     1-2*(q['y']*q['y']+q['z']*q['z']))
    return libm.cosf(yaw), libm.sinf(yaw)


def characterize(samples, begin, end):
    rows = [r for r in samples if begin <= r['source_ns'] <= end]
    phase = {}
    derived = []
    ratios = []
    for r in rows:
        phase.setdefault(r['source_ns'] % 20_000_000, []).append(r['linear_xyz'][1])
        c,s = coefficients(r)
        bx,by = r['linear_xyz'][:2]
        den = c*c+s*s
        wx,wy = (c*bx-s*by)/den, (s*bx+c*by)/den
        if r['planar_speed']:
            ratios.append(math.hypot(wx,wy)/r['planar_speed'])
    for a,b in zip(rows,rows[1:]):
        dt = (b['source_ns']-a['source_ns'])/1e9
        dx,dy = (b['xy'][0]-a['xy'][0])/dt, (b['xy'][1]-a['xy'][1])/dt
        c,s = coefficients(b)
        bx,by = b['linear_xyz'][:2]
        den = c*c+s*s
        derived.append({'start_source_ns': a['source_ns'], 'end_source_ns': b['source_ns'],
                        'source_line': b['source_line'], 'previous_source_line': a['source_line'],
                        'fd_world_vx':dx,'fd_world_vy':dy,'chord_speed':math.hypot(dx,dy),
                        'fd_body_vx_approx':c*dx+s*dy,'fd_body_vy_approx':c*dy-s*dx,
                        'raw_body_vx':bx,'raw_body_vy':by,
                        'raw_world_vx_approx':(c*bx-s*by)/den,
                        'raw_world_vy_approx':(s*bx+c*by)/den})
    result = {'sample_count':len(rows),'interval_ns':[begin,end],
              'raw_vx':summary([r['linear_xyz'][0] for r in rows]),
              'raw_vy':summary([r['linear_xyz'][1] for r in rows]),
              'raw_norm':summary([r['planar_speed'] for r in rows]),
              'position_z':summary([r['position_xyz'][2] for r in rows]),
              'source_spacing_ns':sorted({b['source_ns']-a['source_ns'] for a,b in zip(rows,rows[1:])}),
              'source_mod_20ms_to_vy':{str(k):summary(v) for k,v in sorted(phase.items())},
              'float_yaw_inverse_raw_norm_ratio':summary(ratios),
              'sampled_chord_polyline_m':sum(math.dist(a['xy'],b['xy']) for a,b in zip(rows,rows[1:])),
              'endpoint_chord_m':math.dist(rows[0]['xy'],rows[-1]['xy']) if rows else None,
              'finite_difference_rows':derived}
    for key in ('fd_world_vx','fd_world_vy','chord_speed','fd_body_vx_approx',
                'fd_body_vy_approx','raw_world_vx_approx','raw_world_vy_approx'):
        result[key]=summary([r[key] for r in derived])
    return result


chain = read(Path('/tmp/mr3_p2a0_v17_stop_response_chain_review_v1.json'))
result={'schema':'mr3-v17-stop-response-tail-v2','freeze':chain['freeze'],
        'diagnostic_completed':True,'formal_gate_credit':False,'episodes':[]}
for item in chain['episodes']:
    name=item['episode']
    samples=read(BASE/name/'unique_own_odom.json')
    a=item['actual_linear_and_angular_stay_zero_from_ns']
    stop=item['first_three_rest'][0]['source_ns'] if item['first_three_rest'] else item['physics_end_ns']
    result['episodes'].append({'episode':name,
        'pre_cancel_selected_prefix':characterize(samples,samples[0]['source_ns'],item['stop_responses'][0]['event_ns']),
        'after_final_zero_plus_horizon_through_first_rest_or_end':characterize(samples,a+780_000_000,stop),
        'last_second':characterize(samples,item['physics_end_ns']-1_000_000_000,item['physics_end_ns'])})
result['scope']=[
    'Original own_odom subset contains every tb1 callback in the selected window, with full pose/quaternion/twist/covariance, frames, original row number and row SHA; not merely bound-event excerpts.',
    'All selected unique source samples are 34ms apart. Ten distinct source-time offsets modulo the 20ms command cadence are present. This is not exclusive lock to one command-cadence offset; it remains one observation per 34ms drive/odom callback and cannot resolve sub-callback physics oscillation or aliasing.',
    'Raw twist is instantaneous source-time world-velocity-derived data, whereas finite differences are average center displacement over 34ms. Their discrepancy is observed, not evidence of rest or a producer bug by itself.',
    'Approximate world reconstruction uses the archived quaternion and the installed libm cosf/sinf after float yaw conversion. This is a norm/coordinate diagnostic, not additional truth or independent sensor evidence.',
    'These archived channels can establish command and wheel-target closure, raw-source uniqueness, source cadence, orientation and displacement. They do not archive an independent 1ms WorldLinearVel/WorldPose/contact-constraint/solver impulse or motor-torque stream sufficient to uniquely attribute contact/solver oscillation versus measurement-point semantics. No further scan of these same raw files can create those absent measurements.',
    'Original .01m/s three-sample rest, .78s and .144m gates and original formal failures remain unchanged. No native execution, formal auditor, parameter modification, or synthetic PASS credit.'
]
result['script_sha256']=sha(Path(__file__).read_bytes())
result['input_bindings']=INPUTS
for path, expected in INPUTS.items():
    assert sha(Path(path).read_bytes())==expected
with OUTPUT.open('x') as out:
    json.dump(result,out,indent=2)
    out.write('\n')
print(json.dumps({'output':str(OUTPUT),'sha256':sha(OUTPUT.read_bytes()),'episodes':[
    {'episode':r['episode'],'tail':{k:v for k,v in r['after_final_zero_plus_horizon_through_first_rest_or_end'].items()
     if k not in ('finite_difference_rows','source_mod_20ms_to_vy')}} for r in result['episodes']]},indent=2))
