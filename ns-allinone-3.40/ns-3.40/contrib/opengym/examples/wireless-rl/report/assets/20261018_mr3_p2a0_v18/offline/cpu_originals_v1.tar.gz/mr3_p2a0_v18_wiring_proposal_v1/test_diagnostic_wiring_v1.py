"""CPU-only source/launch graph checks. No processes, ROS context or Gazebo load."""
import ast
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET

from launch import LaunchContext
from launch.actions import DeclareLaunchArgument
from launch.utilities import normalize_to_list_of_substitutions, perform_substitutions

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap')
NAME = 'gazebo_multirobot_mapping_with_nav2.launch.py'
KEY = 'MR3_PHYSICS_DIAGNOSTIC_CONFIG_FILE'
GRAPH_EXAMPLES = []


def load(path):
    spec = importlib.util.spec_from_file_location('candidate_launch_' + str(id(path)), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


class DiagnosticWiring(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='mr3_p2a0_v18_wiring_cpu_')
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.run = self.root / 'declared_diag_run'
        self.episode = self.run / 'worker0/episode001_open_101'
        self.episode.mkdir(parents=True)
        self.prefix = self.root / 'synthetic_package_prefix'
        (self.prefix / 'lib').mkdir(parents=True)
        self.libs = {}
        for key, name in [('observer_library', 'libmr3_stop_response_observer.so'),
                          ('profile_library', 'libmr3_physics_diagnostic_profile.so')]:
            p = self.prefix / 'lib' / name
            raw = ('plain non-ELF CPU fixture ' + name).encode()
            p.write_bytes(raw)
            self.libs[key] = {'path': str(p), 'sha256': digest(raw), 'source_sha256': 'a' * 64}
        (self.prefix / 'lib/libmr3_gazebo_step.so').write_bytes(b'not executed, only existing path check')
        self.config = {'schema': 'mr3-physics-diagnostic-config-v1',
            'run_directory': str(self.run), 'episode_relative_directory': 'worker0/episode001_open_101',
            'scene': 'open', 'seed': 101, 'mode': 'baseline',
            'capture_start_ns': 0, 'capture_end_ns': 180000000000, **self.libs}
        self.path = self.root / 'input_config.json'
        self.path.write_text(json.dumps(self.config))
        self.module = load(HERE / 'proposed' / NAME)

    def prepare(self, *, config=None, **kwargs):
        if config is not None:
            self.path.write_text(json.dumps(config))
        values = dict(adapter_mode=True, stepped_mode=True, robot_count=3, epoch='actual_fixture_epoch',
            audit_path=str(self.episode / 'adapter.jsonl'),
            world=str(ROOT / 'src/multi_robot/worlds/p1c_open.world'), seed='101',
            package_prefix=str(self.prefix))
        values.update(kwargs)
        return self.module.prepare_physics_diagnostic(str(self.path), **values)

    def graph(self, module, *, config_path=''):
        original_share = module.get_package_share_directory
        original_prefix = module.get_package_prefix
        original_execute = module.ExecuteProcess
        commands = []
        def share(name):
            candidate = ROOT / 'src' / name
            return str(candidate) if candidate.is_dir() else original_share(name)
        def prefix(name):
            return str(self.prefix) if name == 'multi_robot' else original_prefix(name)
        def execute(**kwargs):
            commands.append(copy.deepcopy(kwargs))
            return original_execute(**kwargs)
        with patch.dict(os.environ, {KEY: config_path}), \
                patch.object(module, 'get_package_share_directory', share), \
                patch.object(module, 'get_package_prefix', prefix), \
                patch.object(module, 'ExecuteProcess', execute):
            context = LaunchContext()
            for action in module.generate_launch_description().entities:
                if isinstance(action, DeclareLaunchArgument):
                    context.launch_configurations[action.name] = perform_substitutions(
                        context, action.default_value)
            context.launch_configurations.update({'world': 'p1c_open.world',
                'execution_mode': 'adapter', 'mr3_stepped': 'true',
                'mr3_audit_path': str(self.episode / 'adapter.jsonl'),
                'mr3_episode_epoch': 'actual_fixture_epoch', 'gazebo_seed': '101'})
            actions = module.launch_setup(context)
        def token(value):
            if isinstance(value, list):
                return perform_substitutions(context, normalize_to_list_of_substitutions(value))
            if hasattr(value, 'perform'):
                return value.perform(context)
            return value
        for row in commands:
            row['cmd'] = [token(value) for value in row['cmd']]
        GRAPH_EXAMPLES.append({'source': module.__file__, 'config_enabled': bool(config_path),
            'commands': commands, 'scope': 'Constructed launch graph only; no process executed.'})
        return actions, commands

    def test_unset_default_real_launch_graph_argv_and_three_model_bytes_match_base(self):
        old = load(HERE / 'base' / NAME)
        _, old_commands = self.graph(old)
        raw = {p.name: p.read_bytes() for p in self.episode.glob('drive_model_*.sdf')}
        self.assertEqual(len(raw), 3)
        for p in self.episode.glob('drive_model_*.sdf'):
            p.unlink()
        _, new_commands = self.graph(self.module)
        self.assertEqual(old_commands, new_commands)
        self.assertEqual(raw, {p.name: p.read_bytes() for p in self.episode.glob('drive_model_*.sdf')})
        self.assertFalse((self.episode / 'physics_diagnostic_binding.json').exists())

    def test_enabled_actual_launch_graph_has_system_plugin_before_ros_separator_and_binding(self):
        _, commands = self.graph(self.module, config_path=str(self.path))
        server = next(row for row in commands if row['cmd'][0] == 'gzserver')
        cmd = server['cmd']
        lib = self.libs['profile_library']['path']
        at = cmd.index(lib)
        self.assertEqual(cmd[at - 1], '-s')
        self.assertLess(at, cmd.index('--ros-args'))
        binding_path = self.episode / 'physics_diagnostic_binding.json'
        self.assertEqual(server['additional_env'][KEY], str(binding_path))
        binding = json.loads(binding_path.read_bytes())
        self.assertEqual(binding['epoch'], 'actual_fixture_epoch')
        self.assertEqual(binding['config_sha256'], digest(self.path.read_bytes()))
        self.assertEqual(set(binding['observer_outputs']), {'tb1', 'tb2', 'tb3'})
        for robot in ('tb1', 'tb2', 'tb3'):
            model = ET.parse(self.episode / f'drive_model_{robot}.sdf')
            observer = model.find(f"model/plugin[@name='mr3_stop_response_observer_{robot}']")
            self.assertEqual(observer.get('filename'), self.libs['observer_library']['path'])
            self.assertEqual(observer.findtext('robot'), robot)
            self.assertEqual(observer.findtext('base_link'), 'base_link')
            self.assertEqual(observer.findtext('output_path'), binding['observer_outputs'][robot])
            self.assertEqual(observer.findtext('epoch'), binding['epoch'])
        self.assertFalse(any('tb4' in p.name for p in self.episode.iterdir()))

    def test_append_only_preserves_every_effective_original_byte_and_prevents_duplicate(self):
        selected = self.prepare()
        original = (ROOT / 'src/multi_robot/models/turtlebot3_waffle/model.sdf').read_text()
        rendered = self.module.append_physics_observer(original, 'tb1', selected)
        start = rendered.index('  <plugin name="mr3_stop_response_observer_tb1"')
        end = rendered.index('  </plugin>\n', start) + len('  </plugin>\n')
        self.assertEqual(rendered[:start] + rendered[end:], original)
        with self.assertRaises(ValueError):
            self.module.append_physics_observer(rendered, 'tb1', selected)
        with self.assertRaises(ValueError):
            self.module.append_physics_observer(original, 'tb4', selected)

    def test_mode_and_exact_config_schema_typed_window_and_mismatches_are_rejected(self):
        cases = []
        for key, value in [('schema', 'unknown'), ('mode', 'auto'), ('seed', True),
                           ('capture_start_ns', 0.0), ('capture_end_ns', False),
                           ('capture_end_ns', 0), ('capture_end_ns', 2**63),
                           ('scene', 'rooms'), ('episode_relative_directory', '../other')]:
            row = copy.deepcopy(self.config); row[key] = value; cases.append(row)
        unknown = copy.deepcopy(self.config); unknown['command'] = 'not allowed'; cases.append(unknown)
        for row in cases:
            with self.subTest(row=row), self.assertRaises((ValueError, FileNotFoundError)):
                self.prepare(config=row)
        self.assertFalse((self.episode / 'physics_diagnostic_binding.json').exists())

    def test_scoped_run_seed_and_adapter_stepped_epoch_audit_are_required(self):
        for change in [dict(adapter_mode=False), dict(stepped_mode=False), dict(robot_count=2),
                       dict(epoch=''), dict(audit_path=''), dict(seed='102'),
                       dict(audit_path='relative/adapter.jsonl')]:
            with self.subTest(change=change), self.assertRaises(ValueError):
                self.prepare(**change)
        wrong = copy.deepcopy(self.config)
        wrong['run_directory'] = str(self.root)
        with self.assertRaises((ValueError, FileNotFoundError)):
            self.prepare(config=wrong)

    def test_library_allowlist_hash_and_source_digest_are_required(self):
        for field, value in [('path', '/tmp/arbitrary_library.so'), ('sha256', 'b' * 64),
                             ('source_sha256', True), ('source_sha256', 'A' * 64)]:
            row = copy.deepcopy(self.config); row['profile_library'][field] = value
            with self.subTest(field=field), self.assertRaises((ValueError, FileNotFoundError)):
                self.prepare(config=row)

    def test_binding_is_exclusive_and_duplicate_input_keys_or_nonfinite_json_rejected(self):
        first = self.prepare()
        path = Path(first['binding_path'])
        original = path.read_bytes()
        with self.assertRaises(FileExistsError):
            self.prepare()
        self.assertEqual(path.read_bytes(), original)
        for raw in (b'{"x":1,"x":2}', b'{"x":NaN}'):
            with self.assertRaises(ValueError):
                self.module.diagnostic_json(raw)

    def test_profile_source_system_kind_first_boundary_single_conditional_set_and_native_reads(self):
        source = (HERE / 'proposed/mr3_physics_diagnostic_profile.cpp').read_text()
        self.assertIn('GZ_REGISTER_SYSTEM_PLUGIN(PhysicsDiagnosticProfile)', source)
        self.assertNotIn('GZ_REGISTER_WORLD_PLUGIN', source)
        self.assertEqual(source.count('->SetParam('), 1)
        self.assertIn('if (contrast && !world->Physics()->SetParam("iters", boost::any(int(150))))', source)
        for denied in ('->SetPaused(', '->Step(', '->SetWorldPose(', '->SetLinearVel(', 'Publish('):
            self.assertNotIn(denied, source)
        self.assertIn('if (applied) {return;}', source)
        self.assertIn('world->Iterations() != 1', source)
        self.assertIn('Ns(info.simTime) != 1000000LL', source)
        self.assertIn('ConnectWorldUpdateBegin(', source)
        self.assertIn('dWorldGetQuickStepNumIterations(id)', source)
        self.assertIn('Invariants(before).dump() != Invariants(after).dump()', source)
        self.assertIn('applied = true;', source)

    def test_cmake_is_append_only_and_original_physics_world_model_sources_are_not_patched(self):
        base = (HERE / 'base/CMakeLists.txt').read_text()
        proposed = (HERE / 'proposed/CMakeLists.txt').read_text()
        begin = proposed.index('# Diagnostic-only opt-in SystemPlugin.')
        end = proposed.index('\nament_package()', begin)
        self.assertEqual(proposed[:begin] + proposed[end + 1:], base)
        patch_raw = (HERE / 'review_only.patch').read_text()
        self.assertNotIn('diff --git a/ros2_ws/', patch_raw)  # plain unapplied unified diff
        self.assertNotIn('--- a/ros2_ws/ros2-multi-robot-automap/src/multi_robot/worlds/', patch_raw)
        self.assertNotIn('--- a/ros2_ws/ros2-multi-robot-automap/src/multi_robot/models/', patch_raw)


if __name__ == '__main__':
    result = unittest.main(verbosity=2, exit=False)
    (HERE / 'actual_graph_examples_v3.json').write_text(json.dumps(GRAPH_EXAMPLES, indent=2) + '\n')
    raise SystemExit(not result.result.wasSuccessful())
