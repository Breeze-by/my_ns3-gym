#!/usr/bin/env python3
"""Read a draft plan and local source/ELF bytes only; never invoke its commands."""
import ast
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A = W / 'report/assets/20261018_mr3_p2a0_v18'
OUT = Path('/tmp/mr3_p2a0_v18_plan_readonly_review_v1.json')
PROOF = Path('/tmp/mr3_p2a0_v18_plan_readonly_review_v1_sources')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    PROOF.mkdir()
    sources = []
    def read(path, snapshot=False):
        path = Path(path)
        before = path.stat()
        raw = path.read_bytes()
        after = path.stat()
        identity = lambda value: (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns)
        assert identity(before) == identity(after), 'input changed while read'
        row = {'path': str(path), 'sha256': sha(raw), 'bytes': len(raw)}
        if snapshot:
            target = PROOF / (path.name + '.gz')
            assert not target.exists(), 'sourceproof basename collision'
            encoded = gzip.compress(raw, mtime=0)
            target.write_bytes(encoded)
            assert gzip.decompress(encoded) == raw
            row.update(selected=str(target), encoded_sha256=sha(encoded), decoded_sha256=sha(raw))
        sources.append(row)
        return raw

    plan_path = A / 'predeclared_plan_v18.json'
    plan_raw = read(plan_path, True)
    plan = json.loads(plan_raw)
    assert plan['schema'] == 'mr3-p2a0-isolated-physical-diagnostic-v18'
    assert plan['status'] == 'draft_not_native_admission' and plan['pending']
    assert [row['stage'] for row in plan['stages']] == ['baseline', 'iters150']
    assert 'both fixed cases' in plan['fixed_pair_rule']
    assert 'No sample-dependent selection/retry' in plan['fixed_pair_rule']
    counts = {'resets': 0, 'steps': 0, 'records': 0, 'wall': 0}
    stage_checks = []
    pending_paths = []
    for stage in plan['stages']:
        label = stage['stage']
        argv = stage['command']
        def arg(flag):
            return argv[argv.index(flag) + 1]
        assert argv[:1] == ['env']
        assert argv[1] == 'MR3_PHYSICS_DIAGNOSTIC_CONFIG_FILE=' + stage['configuration']
        assert argv[2].endswith('/envs/ns3gym/bin/python')
        assert argv[3:5] == ['-m', 'mr3_learning.benchmark']
        assert arg('--workers') == '1' and arg('--schedule') == 'open:101'
        assert arg('--steps') == '32' and '--preparation-motion-probe' in argv
        assert arg('--preparation-probe-version') == 'mr3-p2a0-outward-cancel-v6'
        assert '--preparation-parameter-review' in argv
        assert int(arg('--base-domain')) == stage['domain']
        assert int(arg('--base-port')) == stage['port']
        assert arg('--run-id') == stage['run_id'] == 'mr3_p2a0_20261018_v18_' + label
        assert str(Path(arg('--output-root')) / stage['run_id']) == stage['run_directory']
        assert stage['steps'] == stage['returned_steps_max'] == 32
        assert stage['returned_resets_max'] == 1 and stage['saved_api_records_max'] == 33
        config_raw = read(stage['configuration'], True)
        assert sha(config_raw) == stage['configuration_binding']['sha256']
        assert ROOT / stage['configuration_binding']['path'] == Path(stage['configuration'])
        config = json.loads(config_raw)
        assert set(config) == {'schema', 'run_directory', 'episode_relative_directory', 'scene',
            'seed', 'mode', 'capture_start_ns', 'capture_end_ns', 'observer_library', 'profile_library'}
        assert config['schema'] == 'mr3-physics-diagnostic-config-v1'
        assert config['mode'] == label and config['run_directory'] == stage['run_directory']
        assert config['scene'] == stage['scene'] == 'open' and config['seed'] == stage['seed'] == 101
        assert config['episode_relative_directory'] == 'worker0/episode001_open_101'
        assert config['capture_start_ns'] == 0 and config['capture_end_ns'] == 300000000000
        for name in ('observer', 'profile'):
            declared = plan['diagnostic_libraries'][name]
            lib = config[name + '_library']
            assert lib == {'path': declared['installed_path'], 'sha256': declared['library_sha256'],
                           'source_sha256': declared['source_sha256']}
        assert stage['expected_configuration']['iters_before'] == 50
        assert stage['expected_configuration']['iters_during_task'] == (150 if label == 'iters150' else 50)
        jobs = stage['diagnostic_consumers']
        assert [job['label'] for job in jobs] == ['observer_1ms', 'original_physical']
        for job in jobs:
            command = job['command']
            assert command[:2] == ['/usr/bin/python3', '-B']
            assert command[3] == stage['run_directory']
            assert command[command.index('--output') + 1] == job['output']
            if not Path(command[2]).exists():
                pending_paths.append(command[2])
        observer, original = jobs
        assert observer['requires_live_proof'] is True and observer['required_capture_success'] is True
        assert observer['command'][4:6] == ['--freeze', '{freeze}']
        assert observer['command'][observer['command'].index('--plan') + 1] == str(plan_path)
        assert observer['command'][observer['command'].index('--admission-proof') + 1] == '{admission_proof}'
        assert original['requires_live_proof'] is False and original['required_capture_success'] is False
        assert original['required_original_closure'] is True
        assert original['command'][4:] == ['--output', original['output']]
        old_raw = read(original['command'][2])
        tree = ast.parse(old_raw)
        old_main = next(f for f in tree.body if isinstance(f, ast.FunctionDef) and f.name == 'main')
        cli = ast.get_source_segment(old_raw.decode(), old_main)
        assert 'add_argument("directory"' in cli and 'add_argument("--output"' in cli
        counts['resets'] += stage['returned_resets_max']
        counts['steps'] += stage['returned_steps_max']
        counts['records'] += stage['saved_api_records_max']
        counts['wall'] += stage['native_wall_ceiling_seconds']
        stage_checks.append({'stage': label, 'command_config_run_date_budget_match': True,
            'records': 33, 'domain': stage['domain'], 'port': stage['port'],
            'consumer_cli_template_match': True, 'capture_window_seconds': 300,
            'capture_window_is_coverage_to_be_verified_natively': True})
    assert counts == {'resets': 2, 'steps': 64, 'records': 66, 'wall': 3600}
    budget = plan['budget']
    assert budget['max_saved_api_records'] == 66 and budget['max_returned_steps'] == 64
    assert budget['max_returned_resets'] == 2 and budget['max_native_runs'] == 2
    assert budget['max_native_launcher_wall_seconds'] == 3600 and budget['optimizer_updates'] == 0

    library_checks = {}
    for name in ('observer', 'profile'):
        lib = plan['diagnostic_libraries'][name]
        source = read(ROOT / lib['source_path'])
        actual = read(lib['library_path'])
        installed = read(lib['installed_path'])
        assert sha(source) == lib['source_sha256']
        assert actual == installed and sha(actual) == lib['library_sha256']
        assert len(actual) == lib['library_bytes'] and lib['source_sha256'].encode() in actual
        archived = ROOT / lib['archived_library_gzip']
        if not archived.exists():
            pending_paths.append(str(archived))
        library_checks[name] = {'source_current_and_macro_bytes_match': True,
            'actual_build_install_sha_match': True, 'library_sha256': lib['library_sha256'],
            'scope': 'Read bytes only. No dlopen, linker check, plugin execution or native mapping proof.'}
    new_build = ROOT / plan['new_diagnostic_build_receipt']['path']
    if not new_build.exists():
        pending_paths.append(str(new_build))
    preflight = read(A / 'independent/mr3_p2a0_v18_preflight_v1.py', True).decode()
    runner = read(A / 'independent/mr3_p2a0_v18_run_diagnostics_v1.py', True).decode()
    read(A / 'independent/mr3_p2a0_v18_live_admission_v1.py', True)
    for field in ('passed', 'freeze', 'plan_sha256'):
        assert "'" + field + "'" in preflight and "'" + field + "'" in runner
    assert "plan['status'] == 'ready' and plan['pending'] == []" in preflight
    assert "plan.get('status') == 'ready' and not plan.get('pending')" in runner
    assert 'original = helper.check_binary(plan, freeze)' in preflight
    assert 'shim = helper.check_shim(plan, freeze)' in preflight
    assert 'binary_build_receipt' in plan['drive_contract'] and 'binding' in plan['shim_runtime_custody']
    bad_bindings = []
    for row in plan['independent_source_bindings']:
        path = ROOT / row['path']
        actual = sha(path.read_bytes()) if path.exists() else None
        if actual != row['sha256']:
            bad_bindings.append({'path': row['path'], 'expected': row['sha256'], 'actual': actual})
    a18bindings = [row['path'] for row in plan['independent_source_bindings']
                   if '20261018_mr3_p2a0_v18' in row['path']]
    value = {'schema': 'mr3-v18-draft-plan-readonly-review-v1',
        'review_checks_passed': True, 'native_admission_granted': False, 'ready': False,
        'plan_status_at_read': plan['status'], 'pending_at_read': plan['pending'],
        'scope': 'Static plan/config/source and actual ELF byte reading only. No preflight/runner/consumer command execution, build, participant, experiment, formal audit, or Git mutation.',
        'stages': stage_checks, 'budget_counts': counts, 'fixed_pair_not_conditional_sampling': True,
        'library_checks': library_checks, 'preflight_runner_fields_compatible': True,
        'old_check_binary_check_shim_plan_fields_present': True,
        'new_reader_cli': 'Safety confirmed exact CLI; source still pending at this read, so no final implementation/PASS claim.',
        'pending_missing_paths': sorted(set(pending_paths)),
        'independent_bindings': {'current_count': len(plan['independent_source_bindings']),
            'A18_bound_paths': a18bindings, 'stale_or_missing_rows': bad_bindings,
            'scope': 'Draft lists old147 only. Final bindings must include the new tools/consumer/config/build artifacts and current authorized hashes before ready.'},
        'research_scope': 'Original .01/3samples/.78/.144 and all declared gates remain. Fixed two diagnostics give no task/matrix/PPO or continuous-physics credit.',
        'sources': sources, 'all_review_writers_stopped': True}
    with OUT.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'output': str(OUT), 'sha256': sha(OUT.read_bytes()),
                      'review_checks_passed': True, 'ready': False,
                      'missing_pending_paths': len(set(pending_paths)),
                      'stale_bindings': len(bad_bindings)}))


if __name__ == '__main__':
    main()
