0000000000018190 <nav2_rotation_shim_controller::RotationShimController::isCollisionFree(geometry_msgs::msg::TwistStamped_<std::allocator<void> > const&, double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&)@@Base>:
   18190:	f3 0f 1e fa          	endbr64 
   18194:	41 57                	push   %r15
   18196:	41 56                	push   %r14
   18198:	41 55                	push   %r13
   1819a:	49 89 d5             	mov    %rdx,%r13
   1819d:	41 54                	push   %r12
   1819f:	49 89 f4             	mov    %rsi,%r12
   181a2:	55                   	push   %rbp
   181a3:	48 89 cd             	mov    %rcx,%rbp
   181a6:	53                   	push   %rbx
   181a7:	48 89 fb             	mov    %rdi,%rbx
   181aa:	48 8d 79 40          	lea    0x40(%rcx),%rdi
   181ae:	48 83 ec 48          	sub    $0x48,%rsp
   181b2:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
   181b9:	00 00 
   181bb:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   181c0:	31 c0                	xor    %eax,%eax
   181c2:	e8 e9 dd ff ff       	call   15fb0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x240>
   181c7:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   181ce:	00 
   181cf:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
   181d5:	f2 41 0f 10 45 00    	movsd  0x0(%r13),%xmm0
   181db:	66 0f 54 05 1d 2a 02 	andpd  0x22a1d(%rip),%xmm0        # 3ac00 <typeinfo name for nav2_core::Controller*@@Base+0xa0>
   181e2:	00 
   181e3:	f2 0f 5c 83 a0 01 00 	subsd  0x1a0(%rbx),%xmm0
   181ea:	00 
   181eb:	f2 0f 11 44 24 18    	movsd  %xmm0,0x18(%rsp)
   181f1:	f2 0f 10 83 c8 01 00 	movsd  0x1c8(%rbx),%xmm0
   181f8:	00 
   181f9:	66 0f 2f 04 24       	comisd (%rsp),%xmm0
   181fe:	0f 86 e9 01 00 00    	jbe    183ed <nav2_rotation_shim_controller::RotationShimController::isCollisionFree(geometry_msgs::msg::TwistStamped_<std::allocator<void> > const&, double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&)@@Base+0x25d>
   18204:	0f 1f 40 00          	nopl   0x0(%rax)
   18208:	f2 0f 10 24 24       	movsd  (%rsp),%xmm4
   1820d:	f2 0f 58 a3 c0 01 00 	addsd  0x1c0(%rbx),%xmm4
   18214:	00 
   18215:	f2 41 0f 10 54 24 50 	movsd  0x50(%r12),%xmm2
   1821c:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
   18222:	48 8b 05 87 29 02 00 	mov    0x22987(%rip),%rax        # 3abb0 <typeinfo name for nav2_core::Controller*@@Base+0x50>
   18229:	f2 0f 59 d4          	mulsd  %xmm4,%xmm2
   1822d:	f2 0f 11 24 24       	movsd  %xmm4,(%rsp)
   18232:	66 48 0f 6e c8       	movq   %rax,%xmm1
   18237:	f2 0f 58 d0          	addsd  %xmm0,%xmm2
   1823b:	f2 0f 5c c2          	subsd  %xmm2,%xmm0
   1823f:	f2 0f 58 05 71 29 02 	addsd  0x22971(%rip),%xmm0        # 3abb8 <typeinfo name for nav2_core::Controller*@@Base+0x58>
   18246:	00 
   18247:	f2 0f 11 54 24 08    	movsd  %xmm2,0x8(%rsp)
   1824d:	e8 4e 7f ff ff       	call   101a0 <fmod@plt>
   18252:	66 0f ef f6          	pxor   %xmm6,%xmm6
   18256:	f2 0f 10 54 24 08    	movsd  0x8(%rsp),%xmm2
   1825c:	66 0f 2f f0          	comisd %xmm0,%xmm6
   18260:	0f 83 ba 01 00 00    	jae    18420 <nav2_rotation_shim_controller::RotationShimController::isCollisionFree(geometry_msgs::msg::TwistStamped_<std::allocator<void> > const&, double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&)@@Base+0x290>
   18266:	f2 0f 5c 05 4a 29 02 	subsd  0x2294a(%rip),%xmm0        # 3abb8 <typeinfo name for nav2_core::Controller*@@Base+0x58>
   1826d:	00 
   1826e:	66 0f 2f 44 24 18    	comisd 0x18(%rsp),%xmm0
   18274:	0f 83 73 01 00 00    	jae    183ed <nav2_rotation_shim_controller::RotationShimController::isCollisionFree(geometry_msgs::msg::TwistStamped_<std::allocator<void> > const&, double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&)@@Base+0x25d>
   1827a:	4c 8b 6b 68          	mov    0x68(%rbx),%r13
   1827e:	4c 8b 7b 78          	mov    0x78(%rbx),%r15
   18282:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   18289:	00 00 
   1828b:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
   18292:	00 00 
   18294:	49 8b 8d b8 06 00 00 	mov    0x6b8(%r13),%rcx
   1829b:	4d 8b 85 b0 06 00 00 	mov    0x6b0(%r13),%r8
   182a2:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   182a9:	00 00 
   182ab:	49 89 ce             	mov    %rcx,%r14
   182ae:	4d 29 c6             	sub    %r8,%r14
   182b1:	0f 84 59 01 00 00    	je     18410 <nav2_rotation_shim_controller::RotationShimController::isCollisionFree(geometry_msgs::msg::TwistStamped_<std::allocator<void> > const&, double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&)@@Base+0x280>
   182b7:	48 b8 f8 ff ff ff ff 	movabs $0x7ffffffffffffff8,%rax
   182be:	ff ff 7f 
   182c1:	49 39 c6             	cmp    %rax,%r14
   182c4:	0f 87 63 01 00 00    	ja     1842d <nav2_rotation_shim_controller::RotationShimController::isCollisionFree(geometry_msgs::msg::TwistStamped_<std::allocator<void> > const&, double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&)@@Base+0x29d>
   182ca:	4c 89 f7             	mov    %r14,%rdi
   182cd:	f2 0f 11 54 24 08    	movsd  %xmm2,0x8(%rsp)
   182d3:	e8 b8 7c ff ff       	call   ff90 <operator new(unsigned long)@plt>
   182d8:	49 8b 8d b8 06 00 00 	mov    0x6b8(%r13),%rcx
   182df:	4d 8b 85 b0 06 00 00 	mov    0x6b0(%r13),%r8
   182e6:	f2 0f 10 54 24 08    	movsd  0x8(%rsp),%xmm2
   182ec:	48 89 c7             	mov    %rax,%rdi
   182ef:	4a 8d 14 37          	lea    (%rdi,%r14,1),%rdx
   182f3:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
   182f8:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
   182fd:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
   18302:	49 39 c8             	cmp    %rcx,%r8
   18305:	74 48                	je     1834f <nav2_rotation_shim_controller::RotationShimController::isCollisionFree(geometry_msgs::msg::TwistStamped_<std::allocator<void> > const&, double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&)@@Base+0x1bf>
   18307:	4c 89 c0             	mov    %r8,%rax
   1830a:	48 89 fa             	mov    %rdi,%rdx
   1830d:	0f 1f 00             	nopl   (%rax)
   18310:	f3 0f 6f 18          	movdqu (%rax),%xmm3
   18314:	48 83 c0 18          	add    $0x18,%rax
   18318:	48 83 c2 18          	add    $0x18,%rdx
   1831c:	0f 11 5a e8          	movups %xmm3,-0x18(%rdx)
   18320:	48 8b 70 f8          	mov    -0x8(%rax),%rsi
   18324:	48 89 72 f8          	mov    %rsi,-0x8(%rdx)
   18328:	48 39 c1             	cmp    %rax,%rcx
   1832b:	75 e3                	jne    18310 <nav2_rotation_shim_controller::RotationShimController::isCollisionFree(geometry_msgs::msg::TwistStamped_<std::allocator<void> > const&, double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&)@@Base+0x180>
   1832d:	48 b8 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaab,%rax
   18334:	aa aa 0a 
   18337:	48 83 e9 18          	sub    $0x18,%rcx
   1833b:	4c 29 c1             	sub    %r8,%rcx
   1833e:	48 c1 e9 03          	shr    $0x3,%rcx
   18342:	48 0f af c8          	imul   %rax,%rcx
   18346:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
   1834a:	48 8d 7c c7 18       	lea    0x18(%rdi,%rax,8),%rdi
   1834f:	f2 0f 10 45 28       	movsd  0x28(%rbp),%xmm0
   18354:	f2 0f 10 4d 30       	movsd  0x30(%rbp),%xmm1
   18359:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
   1835e:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
   18363:	4c 89 ff             	mov    %r15,%rdi
   18366:	e8 35 78 ff ff       	call   fba0 <nav2_costmap_2d::FootprintCollisionChecker<nav2_costmap_2d::Costmap2D*>::footprintCostAtPose(double, double, double, std::vector<geometry_msgs::msg::Point_<std::allocator<void> >, std::allocator<geometry_msgs::msg::Point_<std::allocator<void> > > >)@plt>
   1836b:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
   18370:	48 85 ff             	test   %rdi,%rdi
   18373:	74 19                	je     1838e <nav2_rotation_shim_controller::RotationShimController::isCollisionFree(geometry_msgs::msg::TwistStamped_<std::allocator<void> > const&, double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&)@@Base+0x1fe>
   18375:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   1837a:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
   18380:	48 29 fe             	sub    %rdi,%rsi
   18383:	e8 38 7c ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   18388:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
   1838e:	66 0f 2e 05 2a 28 02 	ucomisd 0x2282a(%rip),%xmm0        # 3abc0 <typeinfo name for nav2_core::Controller*@@Base+0x60>
   18395:	00 
   18396:	7a 38                	jp     183d0 <nav2_rotation_shim_controller::RotationShimController::isCollisionFree(geometry_msgs::msg::TwistStamped_<std::allocator<void> > const&, double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&)@@Base+0x240>
   18398:	75 36                	jne    183d0 <nav2_rotation_shim_controller::RotationShimController::isCollisionFree(geometry_msgs::msg::TwistStamped_<std::allocator<void> > const&, double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&)@@Base+0x240>
   1839a:	48 8b 43 68          	mov    0x68(%rbx),%rax
   1839e:	48 8b 80 d8 03 00 00 	mov    0x3d8(%rax),%rax
   183a5:	80 78 78 ff          	cmpb   $0xff,0x78(%rax)
   183a9:	0f 84 e7 87 ff ff    	je     10b96 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x6c6>
   183af:	bf 10 00 00 00       	mov    $0x10,%edi
   183b4:	e8 47 79 ff ff       	call   fd00 <__cxa_allocate_exception@plt>
   183b9:	48 8d 35 c0 11 02 00 	lea    0x211c0(%rip),%rsi        # 39580 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x33e0>
   183c0:	48 89 c7             	mov    %rax,%rdi
   183c3:	48 89 c5             	mov    %rax,%rbp
   183c6:	e8 a5 78 ff ff       	call   fc70 <std::runtime_error::runtime_error(char const*)@plt>
   183cb:	e9 e2 87 ff ff       	jmp    10bb2 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x6e2>
   183d0:	66 0f 2f 05 f0 27 02 	comisd 0x227f0(%rip),%xmm0        # 3abc8 <typeinfo name for nav2_core::Controller*@@Base+0x68>
   183d7:	00 
   183d8:	73 d5                	jae    183af <nav2_rotation_shim_controller::RotationShimController::isCollisionFree(geometry_msgs::msg::TwistStamped_<std::allocator<void> > const&, double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&)@@Base+0x21f>
   183da:	f2 0f 10 83 c8 01 00 	movsd  0x1c8(%rbx),%xmm0
   183e1:	00 
   183e2:	66 0f 2f 04 24       	comisd (%rsp),%xmm0
   183e7:	0f 87 1b fe ff ff    	ja     18208 <nav2_rotation_shim_controller::RotationShimController::isCollisionFree(geometry_msgs::msg::TwistStamped_<std::allocator<void> > const&, double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&)@@Base+0x78>
   183ed:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   183f2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
   183f9:	00 00 
   183fb:	75 3f                	jne    1843c <nav2_rotation_shim_controller::RotationShimController::isCollisionFree(geometry_msgs::msg::TwistStamped_<std::allocator<void> > const&, double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&)@@Base+0x2ac>
   183fd:	48 83 c4 48          	add    $0x48,%rsp
   18401:	5b                   	pop    %rbx
   18402:	5d                   	pop    %rbp
   18403:	41 5c                	pop    %r12
   18405:	41 5d                	pop    %r13
   18407:	41 5e                	pop    %r14
   18409:	41 5f                	pop    %r15
   1840b:	c3                   	ret    
   1840c:	0f 1f 40 00          	nopl   0x0(%rax)
   18410:	31 ff                	xor    %edi,%edi
   18412:	e9 d8 fe ff ff       	jmp    182ef <nav2_rotation_shim_controller::RotationShimController::isCollisionFree(geometry_msgs::msg::TwistStamped_<std::allocator<void> > const&, double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&)@@Base+0x15f>
   18417:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   1841e:	00 00 
   18420:	f2 0f 58 05 90 27 02 	addsd  0x22790(%rip),%xmm0        # 3abb8 <typeinfo name for nav2_core::Controller*@@Base+0x58>
   18427:	00 
   18428:	e9 41 fe ff ff       	jmp    1826e <nav2_rotation_shim_controller::RotationShimController::isCollisionFree(geometry_msgs::msg::TwistStamped_<std::allocator<void> > const&, double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&)@@Base+0xde>
   1842d:	4d 85 f6             	test   %r14,%r14
   18430:	79 05                	jns    18437 <nav2_rotation_shim_controller::RotationShimController::isCollisionFree(geometry_msgs::msg::TwistStamped_<std::allocator<void> > const&, double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&)@@Base+0x2a7>
   18432:	e8 89 7a ff ff       	call   fec0 <std::__throw_bad_array_new_length()@plt>
   18437:	e8 04 78 ff ff       	call   fc40 <std::__throw_bad_alloc()@plt>
   1843c:	e8 1f 7c ff ff       	call   10060 <__stack_chk_fail@plt>
   18441:	f3 0f 1e fa          	endbr64 
   18445:	49 89 c4             	mov    %rax,%r12
   18448:	e9 7b 87 ff ff       	jmp    10bc8 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x6f8>
   1844d:	f3 0f 1e fa          	endbr64 
   18451:	48 89 c5             	mov    %rax,%rbp
   18454:	e9 96 87 ff ff       	jmp    10bef <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x71f>
   18459:	90                   	nop
   1845a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
