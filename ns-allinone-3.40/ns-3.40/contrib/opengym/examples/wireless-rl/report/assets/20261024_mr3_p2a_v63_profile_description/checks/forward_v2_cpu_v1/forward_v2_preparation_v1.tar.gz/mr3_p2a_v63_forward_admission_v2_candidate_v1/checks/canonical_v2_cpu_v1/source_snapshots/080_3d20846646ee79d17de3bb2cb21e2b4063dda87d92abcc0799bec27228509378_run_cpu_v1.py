"""Four CPU-only checks against canonical v2 parent and unchanged consumer."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path('/home/zhuyulab/ns3-workspace')
W=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
C=W/'report/assets/20261024_mr3_p2a_v63_profile_description'
A=Path(__file__).resolve().parent
B=A/'checks/canonical_v2_cpu_v1'


def identity():
    tail=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()
    return dict(pid=os.getpid(),parent=int(tail[1]),group=int(tail[2]),session=int(tail[3]),start_ticks=int(tail[19]))


def main():
    B.mkdir(parents=True,exist_ok=False)
    for name in ['run_description_v2.py','bootstrap_v2.py','scope_v2.json']:
        if (C/name).read_bytes() != (A/name).read_bytes():
            raise ValueError('canonical v2 is not the exact prepared source: '+name)
    config=json.loads((C/'scope_v2.json').read_text())
    if config['admitted'] is not True or config['previous_accounting']['sha256'] is None:
        raise ValueError('actual previous ledger/admission still pending')
    spec=json.loads((C/'spec_v1.json').read_text())
    sources=sorted(set([*A.glob('*.py'),A/'cpu_spec_v1.json',A/'whole_byte_inverse_v2.json',
        *[C/name for name in ['run_description_v2.py','bootstrap_v2.py','scope_v2.json',
            'describe_partial_profiles_v1.py','spec_v1.json','test_profile_description_v1.py','test_parent_failure_v1.py']],
        *(W/'mr3_learning').glob('*.py'),
        *[Path(value['path']) for value in config['metadata_bindings']],Path(config['previous_accounting']['path']),
        *[Path(value['path']) for value in config['source_bindings']],
        Path(spec['description_source']['path']),Path('/usr/bin/python3').resolve()]))
    if any(path.suffix=='.pstats' for path in sources):raise ValueError('original pstats excluded')
    snapshots=B/'source_snapshots';snapshots.mkdir()
    rows=[]
    for ordinal,path in enumerate(sources):
        raw=path.read_bytes();digest=hashlib.sha256(raw).hexdigest()
        snapshot=snapshots/(str(ordinal).zfill(3)+'_'+digest+'_'+path.name)
        snapshot.open('xb').write(raw)
        rows.append(dict(path=str(path),bytes=len(raw),sha256=digest,snapshot=str(snapshot)))
    (B/'source_recovery_v1.json').open('x').write(json.dumps(dict(
        base_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        source_credit='actual canonical v2 bytes plus unchanged canonical consumer; v2 may still be uncommitted',
        sources=rows),indent=2)+'\n')
    (B/'runner_identity_v1.json').open('x').write(json.dumps(identity(),indent=2)+'\n')
    command=json.loads((A/'cpu_spec_v1.json').read_text())['actual_argv']
    argv=['/usr/bin/python3','-B','-m','mr3_learning.reach_execution','--scope','cpu','--output',str(B/'actual')]
    for path in sources:argv.extend(['--source',str(path)])
    argv.extend(['--',*command])
    env=dict(os.environ,PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1')
    env.pop('PYTHONPATH',None);env.pop('PYTHONHOME',None)
    return subprocess.call(argv,cwd=W,env=env)


if __name__=='__main__':raise SystemExit(main())
