"""Correction regression/final exact source custody; CPU only."""
import ast
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time


HERE = Path(__file__).parent
OLD = Path('/tmp/mr3_p2a0_v20_sensor_coordinator_proposal_v1')
CWD = Path('/home/zhuyulab/ns3-workspace')
ENV = {'PATH': '/usr/bin:/bin', 'PYTHONNOUSERSITE': '1',
       'PYTHONDONTWRITEBYTECODE': '1', 'LANG': 'C.UTF-8',
       'LC_ALL': 'C.UTF-8', 'TZ': 'UTC'}


def proof(path):
    raw = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def main():
    start = time.monotonic()
    before = {str(path): proof(path) for path in sorted(HERE.glob('*.py'))}
    parent = HERE / 'mr3_p2a0_v20_sensor_run_v1.py'
    old = OLD / parent.name
    inserted = "    bindings=plan['independent_source_bindings']+[\n        {'path':path,'sha256':value['sha256']}\n        for path,value in preflight['source_bindings'].items()]"
    original = "    bindings=plan['independent_source_bindings']+preflight['source_bindings']"
    source = parent.read_text()
    assert source.count(inserted) == 1
    restored = source.replace(inserted, original)
    assert restored.encode() == old.read_bytes()
    assert ast.dump(ast.parse(restored)) == ast.dump(ast.parse(old.read_bytes()))
    for name in ('mr3_p2a0_v20_sensor_preflight_v1.py', 'mr3_p2a0_v20_sensor_coordinator_tests_v1.py'):
        assert (HERE / name).read_bytes() == (OLD / name).read_bytes()
    initial = json.loads((HERE / 'checks_v2.json').read_bytes())
    old14 = next(row for row in initial['commands'] if row['label'] == 'existing14_tests01')
    assert old14['exit_code'] == 0
    for name in ('mr3_p2a0_v20_sensor_run_v1.py', 'mr3_p2a0_v20_sensor_preflight_v1.py', 'mr3_p2a0_v20_sensor_coordinator_tests_v1.py'):
        assert proof(HERE / name)['sha256'] == initial['source_before'][str(HERE / name)]
    result = {'schema': 'mr3-v20-sensor-binding-correction-final-checks-v1',
              'scope': 'CPU-only actual main wiring with original real preflight; Git/unused-resource calls mocked, Popen forbidden. No native/DDS/SDK admission.',
              'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'cwd': str(CWD), 'environment': ENV, 'source_before': before,
              'whole_parent_reverse_bytes_and_ast_equal': True,
              'unchanged_preflight_and_existing14_test_bytes': True,
              'old14_actual_result': old14, 'old14_receipt': proof(HERE / 'checks_v2.json'),
              'original_main_red': 'Exact sealed parent list+103-mapping raises TypeError before child or capture.',
              'initial_fixture_failure': 'A new fixture incorrectly required all runtime metadata records to have exactly three keys; real 103 mapping also contains normative/status provenance. Initial three FAIL outputs/source retained; parent fix unchanged.',
              'commands': []}
    commands = [
        ('real_fixture_tests02', ['/usr/bin/python3', '-B', str(HERE / 'mr3_p2a0_v20_sensor_runtime_binding_tests_v2.py'), '-v']),
        ('fatal_style02', ['/usr/bin/python3', '-m', 'flake8', *before.keys(), '--select=E9,F63,F7,F82']),
    ]
    for label, argv in commands:
        began = time.monotonic()
        run = subprocess.run(argv, env=ENV, cwd=CWD, capture_output=True, check=False)
        outputs = {}
        for name, raw in [('stdout', run.stdout), ('stderr', run.stderr)]:
            path = HERE / (label + '.' + name + '.log')
            with path.open('xb') as stream:
                stream.write(raw)
            outputs[name] = proof(path)
        result['commands'].append({'argv': argv, 'exit_code': run.returncode,
                                   'wall_seconds': time.monotonic() - began, **outputs})
    result['source_after'] = {str(path): proof(path) for path in sorted(HERE.glob('*.py'))}
    result['source_stable'] = result['source_before'] == result['source_after']
    result['passed'] = result['source_stable'] and all(row['exit_code'] == 0 for row in result['commands'])
    result['wall_seconds'] = time.monotonic() - start
    path = HERE / 'checks_final_v2.json'
    with path.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'passed': result['passed'], 'receipt': proof(path), 'wall_seconds': result['wall_seconds']}))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
