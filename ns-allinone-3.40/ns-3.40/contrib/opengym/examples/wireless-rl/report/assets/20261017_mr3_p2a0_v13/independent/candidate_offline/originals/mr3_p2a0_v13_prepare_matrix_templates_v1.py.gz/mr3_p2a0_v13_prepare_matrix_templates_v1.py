"""Produce non-admissible V13 coordinator/plan templates in /tmp only."""
from pathlib import Path
import copy
import hashlib
import json

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = Path('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl')
OLD = ROOT / W / 'report/assets/20261017_mr3_p2a0_v12'
NEW = W / 'report/assets/20261017_mr3_p2a0_v13'
OUT = Path('/tmp/mr3_p2a0_v13_matrix_templates_v1')
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def write(path, data):
    with path.open('xb') as stream:
        stream.write(data)


def write_json(path, value):
    write(path, (json.dumps(value, indent=2, allow_nan=False) + '\n').encode())


def version(value):
    if type(value) is str:
        return value.replace('20261017_mr3_p2a0_v12', '20261017_mr3_p2a0_v13').replace(
            'mr3_p2a0_v12', 'mr3_p2a0_v13').replace('mr3_v12_', 'mr3_v13_').replace(
            'predeclared_plan_v12', 'predeclared_plan_v13')
    if type(value) is list:
        return [version(v) for v in value]
    if type(value) is dict:
        return {k: version(v) for k, v in value.items()}
    return value


def main():
    OUT.mkdir()
    old_raw = (OLD / 'predeclared_plan_v12.json').read_bytes()
    original = json.loads(old_raw)
    plan = version(copy.deepcopy(original))
    # Historical immutable assets are references, never relabelled or overwritten.
    plan['independent_source_bindings'] = copy.deepcopy(original['independent_source_bindings'])
    plan['schema'] = 'mr3-p2a0-predeclaration-v13'
    plan['authorization'] = 'Continue P2A.0 only; no PPO/pilot/GPU, no P2B/gateway; new matrix requires reviewed clean pushed freeze'
    plan['source_binding'] = 'PENDING one new clean pushed V13 exact40 source freeze; no inherited native credit'
    plan['readiness'] = {'status': 'draft_pending_source', 'freeze': None,
        'pending_bindings': ['new guard full-vector model-invalid failfast-c producer/tests/auditor',
            'directed paired-wheel helper actual rebuild and four-macro binary proof',
            'new actual9 readback script and benchmark hook/pins',
            'source/install/plugin identity and canonical dependency',
            'all new coordinator/test/source hashes and final source-contract review'],
        'no_native_or_formal_authorized_by_this_template': True}
    plan['unchanged_gates'] = copy.deepcopy(original['unchanged_gates'])
    contracts = plan['new_execution_contracts']
    contracts.update(command_linear_limit_mps=.20, command_angular_limit_radps=.8,
        nav2_primary_controller='dwb_core::DWBLocalPlanner',
        nav2_wrapper='nav2_rotation_shim_controller::RotationShimController',
        nav2_wrapper_profile='mr3-nav2-shim-dwb-020-v1',
        explicit_linear_command_accel_mps2=.5, explicit_angular_command_accel_radps2=3.2,
        full_model_failfast='option-c: typed guard model-invalid negative -> infrastructure attempt FAIL -> original permanent-zero cleanup/real storage, no synthetic task terminal or reward rescue')
    plan['navigation_profile'] = {
        'status': 'pending_producer_install_and_native_verification',
        'plugin': contracts['nav2_wrapper'], 'primary_controller': contracts['nav2_primary_controller'],
        'angular_dist_threshold_rad': .5, 'angular_disengage_threshold_rad': .5,
        'forward_sampling_distance_m': .3, 'rotate_to_heading_angular_vel_radps': .8,
        'max_angular_accel_radps2': 3.2, 'closed_loop': True,
        'simulate_ahead_time_sec': 1., 'rotate_to_goal_heading': False,
        'dwb_and_smoother_linear_command_limit_mps': .2,
        'dwb_and_smoother_linear_accel_mps2': .5,
        'smoother_feedback': 'OPEN_LOOP', 'smoother_frequency_hz': 20.,
        'critics_and_global_planner': 'All original critics/scales/goalchecker/progresschecker/GridBased/BT retained',
        'limitations': ['legal goals remain only>.10m; no .30m candidate minimum; short paths may delegate DWB',
            'sampling uses path.front and actual TF; nominal1Hz/.20 is a design scale, not a freshness proof',
            'closed-loop Shim feasibility clamp is not a standalone absolute angular cap; final caps/body gates stay mandatory',
            'readback alone does not prove plugin implementation use or physical progress']}
    plan['full_execution_model_failfast'] = {
        'status': 'pending_final_source', 'strategy': 'c',
        'normal_order': 'unchanged state -> peer -> guard/self receipt -> three native storage -> evaluator -> advance',
        'invalid_path': 'fresh latest-causal complete raw linear/angular vectors with finite typed scalar/raw consistency -> typed negative guard ACK -> sticky worker infrastructure failure -> existing abort_cleanup permanent stop/local receipt/three zero storage/strict close',
        'before_release': 'failed reset/no fake task transition or reward',
        'after_release_or_already_real_terminal': 'enclosing attempt invalid; original evaluator outcome/times retained; no task sample rescue',
        'forbidden': ['generic readiness retry', 'advance to wait for freshness', 'exploration_failure used to fabricate navigation terminal', 'source-age/model threshold widening'],
        'unchanged_bounds': {'measured_planar_norm_mps': .3, 'full_angular_norm_radps': 1.2,
            'sampled_angular_accel_radps2': 7., 'stop_horizon_sec': .78, 'stop_path_m': .144}}
    plan['drive_contract']['algorithm'] = 'Directed interval bounds on maxa*dt and largest pair error; common alpha always rounded inward; measured-current joint feedback and exact Fraction wheel budgets retained. Final source/build pending.'
    plan['drive_contract']['binary_build_receipt'] = {
        'path': str(NEW / 'binary/mr3_p2a0_v13_drive_build_receipt_v1.json'), 'sha256': None,
        'status': 'pending_actual_rebuild_not_old_d0d_receipt'}
    plan['drive_command_cap_audit'] = {
        'status': 'draft_ready_cpu_not_native',
        'consumer': str(NEW / 'independent/mr3_independent_drive_trace_v6.py'),
        'draft_source': '/tmp/mr3_independent_drive_trace_v6.py',
        'draft_sha256': sha(Path('/tmp/mr3_independent_drive_trace_v6.py').read_bytes()),
        'composition': 'Actually call immutable v5 original full review; preserve original result and every failure; then exact final guard/target publication/native received and actuation desired commands <=.20/.8 without epsilon or raw rewrite',
        'old_v5': str(W / 'report/assets/20261017_mr3_p2a0_v10/independent/mr3_independent_drive_trace_v5.py'),
        'old_v5_sha256': '1010c0192233c2c649924bda2709479c991b18b34a753bda265779cf5bbf57a5'}
    addresses = {'interface': (140, 13301), 'terminal': (142, 13311),
                 'reset': (144, 13321), 'deadline': (148, 13331)}
    for stage in plan['stages']:
        name = stage['stage']; domain, port = addresses[name]
        command = stage['command']
        command[command.index('--base-domain') + 1] = str(domain)
        command[command.index('--base-port') + 1] = str(port)
        for index, binding in enumerate(stage['worker_bindings']):
            binding['domain'], binding['port'] = domain + index, port + index
        stage['required_audits'].extend([
            'V13 final guard/target publication/native received and desired actuation commands exact<=.20/.8; full immutable v5 drive gate retained',
            'fresh latest-causal full-vector execution-model invalidity failfast-c must preserve infrastructure FAIL/real zero-storage closure, no fabricated task failure',
            'actual installed RotationShim plugin/library/config source identity; actual9 readback alone not execution proof'])
    plan['revision_reasons'].append('V12 new same-freeze interface and terminal passed, but reset had genuine per-episode received activity failures; full raw DWB late passive corridor diagnostics support a general path-heading alignment limitation, not unique old open-case attribution. V12 originals/FAIL/deadlineSKIP remain intact; no same-freeze retry credit.')
    plan['revision_reasons'].append('V13 proposes existing installed RotationShim + same DWB critics, command.20, explicit.5/3.2 slew, directed numerical helper and explicit full-model failfast-c. No safety/task/participation gate reduced; native execution remains unverified until complete new matrix.')
    plan['scope_limits'].append('Frozen external v3/32 stimulus and all immutable angular/physical/raw gates are unchanged; no new goal planner/fallback, no claim every candidate executable or PPO effective.')
    plan['historical_bindings_scope'] = 'All76 V12 immutable independent bindings remain exact historical references; append only new V13 frozen sources after review. New freeze/source/build are pending; this template cannot launch.'
    plan['new_source_bindings_pending'] = []
    source_manifest = []
    for old_name, new_name in [
        ('mr3_p2a0_v12_audit_stage.py', 'mr3_p2a0_v13_audit_stage.py'),
        ('mr3_p2a0_v12_launch_stage.py', 'mr3_p2a0_v13_launch_stage.py'),
        ('mr3_p2a0_v12_buildproof_preflight.py', 'mr3_p2a0_v13_buildproof_preflight.py'),
        ('mr3_v12_multiepoch_closure_binary_review_v1.py', 'mr3_v13_multiepoch_closure_binary_review_v1.py')]:
        source = (OLD / 'independent' / old_name).read_bytes()
        draft = version(source.decode()).replace('mr3-p2a0-audit-execution-v12', 'mr3-p2a0-audit-execution-v13').replace(
            'mr3-p2a0-predeclaration-v12', 'mr3-p2a0-predeclaration-v13')
        if 'audit_stage' in new_name:
            draft = draft.replace("LOCAL / 'mr3_independent_drive_trace_v5.py'", "ASSETS / '20261017_mr3_p2a0_v13/independent/mr3_independent_drive_trace_v6.py'")
        if 'closure' not in new_name:
            marker = "    plan = json.loads(plan_path.read_text())\n" if 'audit_stage' in new_name else '    plan = json.loads(plan_raw)\n'
            assert marker in draft
            draft = draft.replace(marker, marker + "    assert plan['readiness']['status'] == 'ready' and not plan['readiness']['pending_bindings'], 'V13 template not finalized'\n")
        write(OUT / new_name, draft.encode())
        binding = {'path': str(NEW / 'independent' / new_name), 'sha256': None,
            'draft_path': str(OUT / new_name), 'draft_sha256': sha(draft.encode()),
            'status': 'template_only_not_frozen'}
        plan['new_source_bindings_pending'].append(binding)
        source_manifest.append({'original_path': str((OLD / 'independent' / old_name).relative_to(ROOT)),
            'original_sha256': sha(source), **binding})
    for p, name in [(Path('/tmp/mr3_independent_drive_trace_v6.py'), 'mr3_independent_drive_trace_v6.py'),
                    (Path('/tmp/mr3_independent_drive_trace_v6_tests.py'), 'mr3_independent_drive_trace_v6_tests.py'),
                    (Path('/tmp/mr3_p2a0_v13_navigation_profile_draft_v1/mr3_actual_nav2_parameters_v13_draft.py'), 'mr3_actual_nav2_parameters_v13.py')]:
        plan['new_source_bindings_pending'].append({'path': str(NEW / 'independent' / name),
            'sha256': None, 'draft_path': str(p), 'draft_sha256': sha(p.read_bytes()),
            'status': 'pending_canonical_freeze'})
    write_json(OUT / 'predeclared_plan_v13.json', plan)
    previous_sources = json.loads(Path('/tmp/source_bindings_6b1b4a010835.json').read_bytes())
    proposed_changes = {
        'ros2_ws/ros2-multi-robot-automap/src/multi_robot/params/nav2_params_tb1_0.yaml',
        'ros2_ws/ros2-multi-robot-automap/src/multi_robot/params/nav2_params_tb2_0.yaml',
        'ros2_ws/ros2-multi-robot-automap/src/multi_robot/params/nav2_params_tb3_0.yaml',
        'ros2_ws/ros2-multi-robot-automap/src/multi_robot/package.xml',
        'ros2_ws/ros2-multi-robot-automap/src/multi_robot/include/multi_robot/paired_wheel_slew.hpp',
        'ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/multi_robot_exploration/mr3_motion_safety.py',
        'ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/multi_robot_exploration/motion_safety.py',
        str(W / 'mr3_learning/benchmark.py'), str(W / 'mr3_learning/audit_motion.py'),
        str(W / 'mr3_learning/audit_ppo.py'), str(W / 'mr3_learning/audit_protocol.py')}
    bindings = {'schema': 'mr3-v13-source-bindings-template-v1', 'freeze': None,
        'status': 'not_final_not_native_admissible',
        'old_runtime_sourcepack_reference': {'path': '/tmp/source_bindings_6b1b4a010835.json',
            'freeze': previous_sources['freeze'], 'sha256': sha(Path('/tmp/source_bindings_6b1b4a010835.json').read_bytes()),
            'count': len(previous_sources['files'])},
        'runtime_paths': [{'path': row['path'], 'reference_v12_sha256': row['sha256'],
            'new_freeze_sha256': None, 'status': 'refresh_all_exact_git_at_finalizer',
            'known_proposed_change': row['path'] in proposed_changes} for row in previous_sources['files']],
        'immutable_independent_bindings': original['independent_source_bindings'],
        'new_bindings_pending': plan['new_source_bindings_pending'],
        'no_fixed_new_count': 'actual source inventory/finalization may add producers/tests/consumer/build artifacts; do not assert100/76 are the V13 totals',
        'coordinator_sources': source_manifest}
    write_json(OUT / 'source_bindings_template_v1.json', bindings)
    write_json(OUT / 'construction_manifest_v1.json', {'schema': 'mr3-v13-template-construction-v1',
        'scope': 'No Git writes/native/formal calls; no executable admission while draft.',
        'base_plan': str(OLD / 'predeclared_plan_v12.json'), 'base_plan_sha256': sha(old_raw),
        'generator_sha256': sha(Path(__file__).read_bytes()),
        'files': [{'path': str(p), 'sha256': sha(p.read_bytes())}for p in sorted(OUT.iterdir())if p.is_file()]})
    print(json.dumps({'out': str(OUT), 'immutable_bindings': len(original['independent_source_bindings']),
        'pending_new_bindings': len(plan['new_source_bindings_pending']), 'native_authorized': False}))


if __name__ == '__main__':
    main()
