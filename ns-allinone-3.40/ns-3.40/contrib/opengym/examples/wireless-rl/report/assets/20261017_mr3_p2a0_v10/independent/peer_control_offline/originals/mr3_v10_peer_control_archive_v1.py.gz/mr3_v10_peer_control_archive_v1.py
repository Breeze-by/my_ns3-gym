from pathlib import Path
import gzip
import hashlib
import json
ROOT=Path('/home/zhuyulab/ns3-workspace')
BASE=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v10/independent'
DEST=BASE/'peer_control_offline'
patterns=('mr3_p2a0_v10_peer*','mr3_p2a0_v10_control*','mr3_v10_peer*','mr3_v10_control*','mr3_v10_cloud*','mr3_v10_information_peer*','mr3_p2a0_v10_cloud_arange*','mr3_p2a0_v10_information_peer_safe*')
files=set()
for pattern in patterns:
 for path in Path('/tmp').glob(pattern):
  files.update([p for p in path.rglob('*') if p.is_file()] if path.is_dir() else [path])
files.update(Path('/tmp')/name for name in ('mr3_independent_control_phase_v1.py','mr3_independent_control_phase_v1_tests.py','mr3_v10_peer_control_archive_v1.py'))
info_manifest=json.loads((BASE/'information_offline/manifest.json').read_text())
references=[item for item in info_manifest['entries'] if '/mr3_p2a0_v10_information_producer_fixture_v2/' in item['source']]
entries=[]
def sha(data):return hashlib.sha256(data).hexdigest()
for src in sorted(files):
 if src.suffix in ('.pyc','.pyo') or '__pycache__' in src.parts:continue
 raw=src.read_bytes();dst=DEST/'originals'/src.relative_to('/tmp')
 dst=Path(str(dst)+'.gz'); encoded=gzip.compress(raw,compresslevel=9,mtime=0)
 dst.parent.mkdir(parents=True,exist_ok=True)
 if dst.exists():assert dst.read_bytes()==encoded,str(dst)
 else:dst.write_bytes(encoded)
 assert gzip.decompress(dst.read_bytes())==raw
 entries.append({'source':str(src),'selected_path':str(dst.relative_to(ROOT)),
                 'raw_sha256':sha(raw),'encoded_sha256':sha(encoded),
                 'decoded_sha256':sha(gzip.decompress(encoded)),
                 'raw_bytes':len(raw),'selected_bytes':len(encoded),'decoded_equals_raw':True})
for item in references:
 src=Path(item['source']);dst=ROOT/item['selected_path']
 assert sha(src.read_bytes())==item['raw_sha256']
 assert sha(gzip.decompress(dst.read_bytes()))==item['raw_sha256']
manifest={'schema':'mr3-v10-peer-control-offline-originals-v1','passed':True,'entries':entries,
          'external_canonical_fixture_references':references,'count':len(entries),
          'raw_bytes':sum(e['raw_bytes'] for e in entries),
          'selected_bytes':sum(e['selected_bytes'] for e in entries),
          'production_source_sha256':'ac0834ab362a771efddbbb656d27edee176b9089be81a83f55ad3a2440065898',
          'consumer_sha256':'04cd7d079c16004b20320868943bcdac899da7646304d30cbad0804d1a6ee8d3',
          'consumer_tests_sha256':'9d89029457a7975d22dd78e8963a3b92ce1a16352d9db9355c995740a5e6eed3',
          'scope':'Offline unit/mutation/actual-production-method fixtures with fake publishers only; zero native launches',
          'important_limits':['Final production38 tests and reader58 tests are separate scopes, not full-stage success.',
                              'Earlier mutable reader source versions were not all snapshotted. Intermediate stdout/compat receipts remain original but do not gain final-source replay credit.',
                              'Peer Tests01/03 are command working-directory errors. Tests02 corrected a nondeterministic CDR-padding equality assertion; actual message fields and cloud.data bytes are the preserved contract.',
                              'Source-stop DDS-inflight overlap is diagnostic; processed worker stop prefix is mandatory. Original20ms terminal/160ms driver/body gates remain mandatory.',
                              'The initial malformed final-check shell invocation was a tool call only and produced no saved check receipt; it did not execute tests or modify production. The corrected exact runner is archived.'],
          'temporary_formatter':'autopep8 installed only under /tmp; no project/runtime dependency. Initial formatting AST was checked unchanged. Configuration-test local extraction was a test-only edit.'}
for item in entries:
 assert sha(Path(item['source']).read_bytes())==item['raw_sha256']
 assert sha((ROOT/item['selected_path']).read_bytes())==item['encoded_sha256']
 assert sha(gzip.decompress((ROOT/item['selected_path']).read_bytes()))==item['decoded_sha256']
DEST.mkdir(exist_ok=True)
p=DEST/'manifest.json';p.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(json.dumps({'manifest':str(p),'sha256':sha(p.read_bytes()),'count':len(entries),'raw_bytes':manifest['raw_bytes'],'selected_bytes':manifest['selected_bytes'],'passed':True}))
