#include <fastrtps/xmlparser/XMLProfileManager.h>
#include <fastrtps/attributes/PublisherAttributes.h>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

int main(int argc, char ** argv)
{
  using eprosima::fastrtps::xmlparser::XMLProfileManager;
  using eprosima::fastrtps::xmlparser::XMLP_ret;
  if (argc != 2 || XMLProfileManager::loadXMLFile(argv[1]) != XMLP_ret::XML_OK) {
    return 2;
  }
  std::vector<std::pair<std::string, int>> expected;
  const char * robots[] = {"tb1", "tb2", "tb3"};
  const char * lifecycle[] = {"controller_server", "planner_server", "behavior_server",
    "bt_navigator", "waypoint_follower", "velocity_smoother"};
  const char * parameters[] = {"controller_server", "behavior_server", "velocity_smoother"};
  for (const auto * robot : robots) {
    for (const auto * node : lifecycle) {
      const std::string prefix = std::string("rr/") + robot + "/" + node;
      expected.emplace_back(prefix + "/change_stateReply", 5);
      expected.emplace_back(prefix + "/get_stateReply", 1);
    }
    for (const auto * node : parameters) {
      expected.emplace_back(std::string("rr/") + robot + "/" + node + "/get_parametersReply", 1);
    }
  }
  bool valid = expected.size() == 45;
  bool first = true;
  std::cout << "{\"no_participant_or_endpoint_created\":true,\"profiles\":[";
  for (const auto & item : expected) {
    eprosima::fastrtps::PublisherAttributes attrs;
    XMLProfileManager::getDefaultPublisherAttributes(attrs);
    const auto found = XMLProfileManager::fillPublisherAttributes(item.first, attrs, false);
    const auto & duration = attrs.qos.m_reliability.max_blocking_time;
    const bool matched = found == XMLP_ret::XML_OK && duration.seconds == item.second &&
      duration.nanosec == 0;
    valid = valid && matched;
    if (!first) { std::cout << ','; }
    first = false;
    std::cout << "{\"name\":\"" << item.first << "\",\"exact_expected_match\":"
              << (matched ? "true" : "false") << ",\"seconds\":" << duration.seconds
              << ",\"nanoseconds\":" << duration.nanosec << "}";
  }
  eprosima::fastrtps::PublisherAttributes defaults;
  XMLProfileManager::getDefaultPublisherAttributes(defaults);
  const auto missing = XMLProfileManager::fillPublisherAttributes("service", defaults, false);
  const auto & duration = defaults.qos.m_reliability.max_blocking_time;
  valid = valid && missing != XMLP_ret::XML_OK && duration.seconds == 0 &&
    duration.nanosec == 100000000;
  std::cout << "],\"default_or_service_fallback_present\":"
            << (missing == XMLP_ret::XML_OK ? "true" : "false")
            << ",\"default_max_blocking_seconds\":" << duration.seconds
            << ",\"default_max_blocking_nanoseconds\":" << duration.nanosec
            << ",\"passed\":" << (valid ? "true" : "false") << "}\n";
  return valid ? 0 : 1;
}
