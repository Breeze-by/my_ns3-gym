#!/bin/bash
set -eo pipefail
source /opt/ros/humble/setup.bash
exec /usr/bin/python3 -B /tmp/mr3_p2a_v64_canonical_cpu_v2/run_cpu.py
