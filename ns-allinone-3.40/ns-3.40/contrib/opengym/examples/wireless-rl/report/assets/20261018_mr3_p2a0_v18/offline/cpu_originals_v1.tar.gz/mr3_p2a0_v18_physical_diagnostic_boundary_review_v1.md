# V18 受控物理诊断：独立边界复核（仅静态）

建议先做有界、隔离的1ms物理更新前/后诊断，再决定solver修复。本次未启动ROS/Gazebo、未新建participant、未重跑formal，未改Git。V17零target/轮参考仍vy约.011来自parent既有原件分析；本复核不把它升级为solver根因。

## 已证源码事实

- 原three worlds只声明ODE、dt=.001、RTF1/update1000；solver子树未显式声明。安装SDFormat1.7 schema默认quick/50/1.3只是静态默认，不能称live配置。
- actual driver接WorldUpdateBegin，先WORLD odom发布，再读取轮反馈并写actuation。官方11.10.2先增加simTime/iteration，随后Begin→碰撞检测→BeforePhysics→求解/dirtyPose→End；相同T的pre/post应按iteration+phase配对，不能把前态当后态或重写旧FAIL。
- WORLD odom由model WorldLinearVel做yaw旋转；该函数只填angular.z。需要同点、同相位full world XYZ/姿态/COM偏置来分辨测量与真实机体运动。零轮参考不等于零机体速度，单独float yaw不能从精确world零制造.011。
- 18路任务contact有意排除wheel/caster–ground支撑。ContactManager无listener可不留反馈；GetContacts只取GetContactCount有效前缀。空数组不能自动排除地面冲量。
- ODE GetParam(iters/sor)与GetSORPGSIters返回SDF缓存；public GetWorldId允许配合dWorldGetQuickStepNumIterations/W/CFM/ERP作实际双读。官方源与实际包/库SHA已在同目录primary receipt保留。

## 最小新增证据

每个实际1ms tick恰一对before_physics/after_physics，绑定epoch/robot/scoped link、iteration、原clock、dt；保存同点world pose/linearXYZ/angularXYZ及COM、当前轮速/电机参考/fmax、实际tagged target/storage/actuation引用、原odom及其发布相位。contact保存真实pair、有效个数、位置/normal/depth与实际可用post-solve wrench；反馈未启用/遗漏须显式，不补0。

保存active engine/profile/effectiveSDF、实际ODE读回、step/gravity/solver/friction/CFM/ERP/damping等，以及加载库/模型SHA。额外日志为evaluator-isolated原件，不进入actor、候选、mask、reward或目标排名；不得SetLinearVel归零、忽略vy、低通/clip出静止、关碰撞或删支撑。buffer溢出/缺pre-post/wall成本都留证，最后仍须原严格关闭。

先用原profile观察eligible movement及整段zero尾部：若wheel仍动查joint/motor；若joint近0但world pose/vel同向漂移查contact/约束；若同点同相位raw/世界不符再查测量。只有一变量solver细化使残差与横漂同降，才支持收敛假说。iters增大并不保证单调；closed-loop动作也可能分叉，必须标明实际matched prefix。world直接求解可作独立参考，不能伪称仅iterations变更。friction、CFM/ERP、damping、mass/inertia、torque/几何变化是plant变更，须另作有据论证。

## 原门与source接线

不改rest全平面≤.01/三raw源、.78s/.144m、有意义初速≥.05且先前输出≥.1s、源gap≤.1s、.30/1.2/7、160ms实际存储、.50机体、.0078 settled整段预算、95%/300s、三机真值≥1m/目标、18源/reward/所有权/关闭。pooled A或B不能抵消真实eligible nonrest；诊断PASS不替完整同冻结四stage。

重要：mr3_task_contract.py:74–78/379–395核整个world SHA；audit_ppo.py:367–384还要求三world和machine task契约逐字等于W7。直接添加solver XML也会触发原source门。最小选项是保留原world/model字节，另冻结一个load-time有限physics profile来源，所有写入和实际读回显式归档；若改world，须事前版本化仅physics子树适配并证明collision/ROI/栅格/任务值完全同，不能删除旧门或悄悄改digest。

必要有界诊断与有据修复仍在已授权P2A.0内，无须再次索取完成权限。新profile进入正式验收前须clean push/新run-id/预声明scope与预算/独立读回和来源绑定；保留所有baseline/refinement失败，后续完整矩阵仅使用一个冻结profile。无新PPO/pilot或余额重置。

完整可检索字段、逐源SHA、精确line anchors及primary URLs见同名JSON。该复核只证明契约/源码事实和最小证据义务，未证明实时solver值、实际接触因果、连续机体安全或修复有效。
