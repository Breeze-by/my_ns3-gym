# V60 CANCEL 因果链：静态诊断与后继取证草稿

本次只读了 E 源码、3 份本机 Nav2 安装头文件和已经闭合的 134762-byte `physical_per_episode_result.json`。没有读取 V60 raw stream/launch 日志，没有重跑任何科学 reader、查询 tool 30588、修改仓库或启动 World。**原 required physics FAIL 保持；当前没有根因结论。**

## 已知事实与不能偷换的起点

固定 actor 为 `mr3_p2a_reach_v60_reset_w1_e2_d678c4be / tb2`，episode 为 `worker1/episode002_open_101`。

| 事件 | 已闭合结果中的值 |
|---|---|
| 第一 native cancel | 42.86 s，goal `:tb2:1` |
| cancel 接受 / result CANCELED | 接受 source/received 42.86；result source 42.86、received 43.06 |
| 第一停止响应 | 初速 .14960545723941543 m/s；reported rest 45.891 s；3.031 s / .25933076894522444 m；nonrest beyond horizon=True；原 FAIL |
| 报告列出的首个 A_final_linear_zero | 45.82 s，w=-.05157894736842117，初速 .030734845328757365 m/s，未达到 A 类原 eligibility |
| 后继 native goal | 49.86 s，晚于 reported rest |
| 第二 cancel 对照 | 54.86 s，goal `:tb2:14`；初速 .18941609608698412；rest 55.231；.371 s / .04085287574552093 m；原 valid |

45.82−42.86=2.96 s、45.891−45.82=.071 s 只用于划分待调查段。**不能把 B 类停止起点从真实 cancel 42.86 移到线速度零事件 45.82，以把 3.031 s 改成 .071 s 或改判 PASS。** 报告列举的零事件也不代替窗口内完整命令序列。`linear_x=0` 且 `angular_z!=0` 不等于两个轮电机命令为零。

原 .78 s / .144 m、初速≥.05、prior-nonzero span≥.1 s、rest≤.01 连续3点、原 source-gap 门、R=.0078 和 STOP 债务都不改变。tb2 报告中的三类 sampled speed bound violations 都为0，与 cancel end-to-end stop FAIL 并不矛盾。

## 静态因果链和已知排序缺口

1. `mr3_protocol.GoalDispatcher.submit(WAIT)` 仅请求 `_cancel`。`cancel_goal` 被 adapter transport 交付后，`native_cancel` 的 scope 明确是 `native_cancel_call_attempt`；它不是零速度、wheel write 或静止 ACK。
2. `MR3Adapter.canceled/completed` 把取消接受布尔值或 action result status 放入 receipt。5 Hz receipt FIFO 可让同 source 42.86 的 result 在43.06交付；这与源码协议一致，但该 .2 s 本身不能解释3.031 s。`on_result` 释放导航 ownership，并不证明 controller/smoother/guard/motor 已静止。
3. 普通 per-goal WAIT/CANCEL 没有直接向 MotionSafety 发“这个 robot 本代 goal 已取消，后续必须零”的消息。MotionSafety仍按实际收到的 smoother Twist 和原几何/时效门工作；全局永久 STOP 属于另一路，不能随意拿它替代正常 WAIT。
4. smoother normal input callback 会把 `last_command_time_=now()`；guard `raw_request.received_stamp` 也在消费回调现取 now。Twist 没有 producer stamp、goal UUID 或 cancellation generation。因此 `.2 s` guard timeout 约束的是接收后的 freshness，不能单凭它证明输入是在取消之后新生成的。旧队列/持续旧 producer 输出是候选，不是已证事实。
5. 仓库 smoother 20 Hz / OPEN_LOOP 源码会按 timeout 和 max_decel 处理既有命令；YAML/默认值只给静态候选，必须核本 episode 的实际参数/readback/loaded source。不能把 smoother 默认1 s timeout 当成扩大原 .78 s 门的理由。
6. 安装头 `bt_action_node.hpp::halt` 等待 child cancel 和 result；超时仅记 `Failed to cancel action server...` / `Failed to get result ... node halt!`，随后仍 `on_cancelled` 并置 IDLE。这是值得查的 parent/child ordering 分支。尚未证明本轮走过该分支，也尚未证明这些安装头就是本轮加载 ELF 的对应编译版本。
7. Native target storage 与34 ms实际写入分开：`OnTarget` 在锁内验证→store→receive latch→status ACK；Update才快照最新 target 并 slew/write/readback/APPLIED。现有20 ms barrier/ACK和runtime独立约束必须保留。不能把 storage ACK、actual_cmd_vel Twist 或 body desired0 叫作实际 motor0。
8. startup encoder hold 首次任何非零接收后永久退出。后继 CANCEL 如存在 wheel/plant 问题，不能未经新版本审查就重臂 helper、刷新 q_ref/机身 anchor 或扩大反馈范围。

本次小结果已把 later native goal 放在49.86，晚于45.891 rest。因此“后继 goal 太早”不能解释当前第一异常窗口。native agent 的 missing meaningful cancel stimulus / safehandoff 提案是另一个问题，不能声称已修复本次真实 B 类 stop violation。

## 先区分哪一段晚，不先改控制器

- 若取消后仍有非零 `raw_request` 且 guard 保留同实际请求：优先定位 Nav2 child cancel、smoother输入/缓存或 unstamped callback来源；现有日志可能只能定位到 consumer，不能恢复丢失的 producer stamp。
- 若 actual raw_request 已零而 guard 输出持续非零：用同一 motion record prefix 和 decision.request 选择顺序核查，尤其同 sim clock 的 callback/commit先后；不按相同时钟强排跨进程总序。
- 若 guard 零已发布但 native store/consume/write仍选旧非零：检查 target原JSON、decision sequence、cmd_seq、actuation_seq 和真实 ACK/physics permission。不能只看 cmd_vel echo。
- 若 native nominal/actual motor 已按原 slew及时变零但 body仍不rest：再定位 wheel/plant/转向耦合；原 sampled bound FAIL 不撤销。

任何一段都需要闭合原件证据。本报告不认定上述任一候选已经发生。

如果取证后选择让 WAIT 直接约束 MotionSafety 请求，必须作为独立版本处理：以 epoch 和机器人命令 ownership 明确取消代，默认 fail-closed，并保留真实收到该约束的 ACK。不能把取消接受伪装成 rest/HOLD，也不能重臂 initial servo。原 Twist 没有 goal generation；即使已等到 rest，下一个 GOAL 前后仍可能出现无法关联新旧代的 unstamped Twist。新方案必须明确处置这个边界，不能仅据 callback 接收时刻把旧输入认作新 goal 的命令。

## 当前后继选择规则

root 指定主窗口为 **[42.6, 46.1] s**。如启用同 actor 第二取消作描述对照，次级窗口单独固定为 **[54.6, 55.6] s**；它不是同激励 A/B。`future_window_fields_spec_v2.json` 是当前规则，v1 的更宽草案已被该 v2 取代。

除窗口外只保留严格声明的上下文：每流/actor/kind/feed 的边界前最后一条和边界后第一条、原配置、两个固定 goal 的 send/receipt/terminal依赖及 cancel之后首次 native_send（49.86事实的来源指针）。上下文必须单列 selection reason，不能偷偷扩成任意时间扫描输出。当前代码只消费 adapter/motion/drive/odom/launch 五个固定流；field spec 中其他 recorder/phase 字段是未来设计，未获准增加本次输入。

adapter 没有原生 record_sequence / wall_monotonic_ns，只能给原文件行号/字节偏移；native drive有 sim_time_ns / record_sequence，但没有 wall timestamp。motion有 wall_monotonic_ns。取证器只保留来源自带字段，不能捏造 adapter/native wall clock 或 Twist producer source stamp，不能按 consumer wall/相同 sim clock制造跨进程总排序。

## 有界流式草稿

最终候选 `cancel_window_extract_draft_v2.py` 借鉴 V54 firstfault 的完整输入 SHA/stat、严格 JSON、逐行解析和 UNKNOWN-on-partial 方式，改为此固定取消窗口的描述性提取。当前 `pending_extraction_spec_v4.json` 为 `admitted=False`，encoded SHA、字节数、closed inventory及资源均待真实闭合库存填入；它在读取任何 raw 前拒绝。实际执行还要求 consumer 与 spec 本体均在新的 clean/pushed Git freeze 中逐字一致，末尾重核 spec 字节及指纹。原件路径必须为绝对 canonical path，无符号链接组件。

v2 显式列出 `unrestored_dependencies`：选中的 actuation 若缺 command_received、guard decision、同 target/sequence/source clock/pair 的真实 APPLIED 或原始 first-nonzero receive，就不能报告描述完整。它不增加第二遍原件扫描。critical payload/机器人归属异常计入 parse 不完整，不能静默丢弃。即使所需描述完整，`root_cause_proved=False`、`causal_status=UNKNOWN_DESCRIPTIVE_ONLY` 和原 FAIL 仍保持。main 开始直接观察自身 pid/parent/group/session/start_ticks，并保存实际 argv。

输入成本按所有声明文件的**完整 encoded + decoded 扫描**计，不按窗口命中行。单遍 encoded 读取同时核 SHA、解压和解析，没有独立预哈希原件扫描。gzip 必须核完整 encoded pin、成功完整解码并报告实际 decoded SHA/bytes；库存已有 decoded pin 时比对，没有时明确 expected-decoded unavailable，不能为了填写它先增加一次原件读取。plain decoded=encoded。byte/line/work/output 上限在新 scope 里前瞻声明，source/provenance 前后核验和完整 parent wall 另完整计入。任何超限、尾部未读、parse错误、必需字段缺失或 selection drop 都报告 INCOMPLETE；来源本来没有 UUID/producer stamp/wall 的因果 UNKNOWN 单独保留，完整描述也不证明根因。

root 必须先真实整体 reap并闭合V60，再为新有限forensics封 source/spec/resource/freeze，最后才实际读取这些原件。现在不运行取证器、不读取launch/raw、不重跑原physics reader、不改判V60。

## 版本保留与唯一人工 CPU

`cancel_window_extract_draft_v1.py` 已精确恢复并保留为 31254B、SHA `2c48abb38daf572b8e8166e9108013ba27e5ff21d6e1e93e925447d6aa956ed0`，与原 `pending_extraction_spec_v2.json` 的 consumer pin 一致。更早曾报告 `345f...` 的私有未执行 draft 原字节没有另存，无法复核；不为它声明 CPU/正式取证信用。中间 pending v1/v2/v3 均保留，不作为最终准入。

最终 v2 为 38080B、SHA `cc293099c8919d6e6e309818977728267604fc944621b28761a21abb40919fec`。唯一人工 CPU 用新建的微小 synthetic bytes 覆盖 typed unadmitted 拒绝、actor/kind 边界、原零/False/None、新行 SHA/decoded offset、gzip 可选 decoded pin、完整后缀 parse、上限/selection drop、未知 launch clock、SHA/epoch/native kind、父路径 symlink 和未恢复关联依赖。没有运行 extractor.main，也没有打开任何 V60 原件、inventory、receipt 或 launch。

实际 tool `91782` 已 reap rc0；7/7 PASS，0 fail/error/skip，实际 child wait `.769616157` s。67 绑定源 before/after/current/recovery 全一致，JUnit 与 actual argv/spec 均核验，2 份保存 CPU start 身份 fresh-gone。原回执/JUnit/source recovery 和验证结果见 `artificial_cpu_v1/`、`artificial_cpu_actual_tool_wait_v1.json`、`artificial_cpu_source_recovery_v1.json`、`artificial_cpu_verified_v1.json`；CPU 不给物理、资格或 P2A 信用。
