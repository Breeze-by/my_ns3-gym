"""Artificial only. Do not run while the V71 qualification parent is active."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

SPEC = importlib.util.spec_from_file_location('stage_parent', Path(__file__).with_name('stage_parent_v1.py'))
parent = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(parent)


class FixedStageParentTests(unittest.TestCase):
    def admission(self, stage='pilot'):
        return dict(schema='mr3-fixed-policy-stage-admission-v1', stage=stage,
            execution_freeze=parent.FIXED_G, admitted=True, decision_maker='Root',
            numeric_user_approval_claimed=False, automatic_next_stage_entry=False,
            original_stage_cap_seconds=str(parent.CAPS[stage]), internal_tail_seconds='500',
            native_ceiling_seconds=str(parent.NATIVE[stage]), fee_scope=parent.SCOPE_NAMES[stage],
            external_finalize_seconds='300')

    def test_pending_never_opens_stage(self):
        value = self.admission();value['admitted'] = False
        with self.assertRaises(parent.PendingEvidence):parent.check_scope(value, 'pilot', parent.FIXED_G)
        value['admitted'] = 1
        with self.assertRaises(parent.PendingEvidence):parent.check_scope(value, 'pilot', parent.FIXED_G)

    def test_enum_and_original_caps_are_not_overridable(self):
        with self.assertRaises(ValueError):parent.state_dir('arbitrary')
        for key, value in [('native_ceiling_seconds','2101'),('internal_tail_seconds','499'),
                           ('external_finalize_seconds','301'),('automatic_next_stage_entry',True),
                           ('original_stage_cap_seconds','3000')]:
            scope = self.admission();scope[key] = value
            with self.subTest(key=key),self.assertRaises(ValueError):
                parent.check_scope(scope, 'pilot', parent.FIXED_G)

    def test_capacity_passed_label_is_not_capacity_evidence(self):
        with self.assertRaises(parent.PendingEvidence):
            parent.require_capacity({'capacity_proof':{'passed':True,'seconds':1}})

    def test_complete_fee_includes_interstage_and_postsource_gaps(self):
        ns = 10**9
        value = parent.settled_fee('pilot', ns, 2501*ns, 2551*ns, 2751*ns, 2801*ns, '300')
        self.assertEqual(value['main_seconds'],'2500')
        self.assertEqual(value['finalizer_seconds'],'200')
        self.assertEqual(value['complete_parent_seconds'],'2800')
        self.assertTrue(value['passed'])
        # Identical main and successful finalizer, but the complete parent exceeds its own original cap.
        late = parent.settled_fee('pilot', ns, 2501*ns, 2551*ns, 2751*ns, 3001*ns, '300')
        self.assertTrue(late['finalizer_within_cap'])
        self.assertFalse(late['passed'])

    def test_finalizer_own_fee_and_main_reservation_are_independent(self):
        ns = 10**9
        long_final = parent.settled_fee('validation', ns, 8001*ns, 8001*ns, 8302*ns, 8302*ns, '300')
        self.assertFalse(long_final['finalizer_within_cap']);self.assertFalse(long_final['passed'])
        long_main = parent.settled_fee('pilot', ns, 2701*ns, 2701*ns, 2702*ns, 2702*ns, '300')
        self.assertTrue(long_main['complete_within_cap']);self.assertFalse(long_main['main_within_cap'])
        minimum = parent.settled_fee('minimum', ns, 1701*ns, 1701*ns, 1751*ns, 1801*ns, '50')
        self.assertTrue(minimum['passed']);self.assertEqual(minimum['complete_cap_seconds'],'1850')
        with self.assertRaises(ValueError):parent.settled_fee('minimum',ns,2*ns,2*ns,3*ns,3*ns,'0')
        with self.assertRaises(ValueError):parent.settled_fee('pilot',True,2*ns,2*ns,3*ns,3*ns,'300')

    def test_failed_actual_main_is_reaped_then_actual_finalizer_runs(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp);marker = root/'finalized'
            main, final = parent.phase_pair(
                lambda:parent.waited(['/usr/bin/python3','-B','-c','raise SystemExit(7)'],root/'main.log'),
                lambda:parent.waited(['/usr/bin/python3','-B','-c',
                    'from pathlib import Path;Path('+repr(str(marker))+').write_text("final")'],root/'final.log'))
            self.assertEqual(main['actual_returncode'],7);self.assertTrue(main['actual_waited'])
            self.assertTrue(marker.exists());self.assertEqual(final['actual_returncode'],0)
            self.assertLessEqual(main['ended_monotonic_ns'],final['started_monotonic_ns'])
            self.assertTrue(parent.waits_drained([main,final]))
            self.assertTrue(parent.absent(main['saved_identity'])['original_identity_gone'])
            self.assertTrue(parent.absent(final['saved_identity'])['original_identity_gone'])

    def test_interrupted_wait_does_not_skip_reap(self):
        class Process:
            pid = os.getpid()
            calls = 0
            def wait(self):
                self.calls += 1
                if self.calls == 1:raise KeyboardInterrupt('artificial wait interruption')
                return 9
        process = Process()
        with tempfile.TemporaryDirectory() as tmp,patch.object(parent.subprocess,'Popen',return_value=process):
            result = parent.waited(['/usr/bin/python3','-B','-c','raise SystemExit(9)'],Path(tmp)/'log')
        self.assertEqual(process.calls,2);self.assertTrue(result['actual_waited'])
        self.assertEqual(result['actual_returncode'],9);self.assertTrue(result['errors'])

    def test_missing_identity_or_wait_is_not_successful_drain(self):
        self.assertFalse(parent.waits_drained([{'process_submitted':True,'actual_waited':False,'saved_identity':None}]))
        self.assertFalse(parent.waits_drained([{'process_submitted':True,'actual_waited':True,'actual_returncode':False}]))
        saved = parent.identity(os.getpid())
        with self.assertRaises(ValueError):parent.absent(saved)
        with self.assertRaises(ValueError):parent.absent({'pid':True,'start_ticks':1})
        with patch.object(parent,'identity',side_effect=PermissionError('artificial unreadable proc')):
            with self.assertRaises(PermissionError):parent.absent(saved)

    def test_exact_pushed_freeze_and_clean_tree(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            def git(*argv):return subprocess.check_output(['git',*argv],cwd=root,stderr=subprocess.PIPE)
            git('init','-b','main');git('config','user.email','cpu@example.invalid');git('config','user.name','CPU fixture')
            source = root/'code.py';source.write_text('x=1\n');git('add','code.py');git('commit','-m','artificial fixture')
            freeze = git('rev-parse','HEAD').decode().strip();git('update-ref','refs/remotes/origin/main',freeze)
            parent.canonical_freeze(freeze,root=root)
            source.write_text('x=2\n')
            with self.assertRaises(ValueError):parent.canonical_freeze(freeze,root=root)
            git('checkout','--','code.py')
            with self.assertRaises(ValueError):parent.canonical_freeze('0'*40,root=root)

    def test_metadata_source_mutation_symlink_and_duplicate_reject(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'metadata.json';path.write_text('{"passed":true}\n')
            proof = parent.bound(path)
            self.assertEqual(parent.checked_json(proof)[0],{'passed':True})
            path.write_text('{"passed":false}\n')
            with self.assertRaises(ValueError):parent.checked_json(proof)
            link = Path(tmp)/'alias';link.symlink_to(path)
            with self.assertRaises(ValueError):parent.bound(link)
        with self.assertRaises(ValueError):parent.parse('{"passed":true,"passed":false}')

    def test_parent_failure_keeps_unknown_account_and_no_submission(self):
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp)
            parent.write(directory/'bootstrap.json',{'saved_parent':{'pid':True,'start_ticks':1},
                'freeze':parent.FIXED_G,'scope_sha256':'0'*64,'started_monotonic_ns':1})
            with patch.object(parent,'state_dir',return_value=directory),patch.object(parent,'waited') as launch:
                self.assertEqual(parent.execute('minimum',parent.FIXED_G,'0'*64),1)
            result = parent.parse((directory/'summary.json').read_bytes())
            self.assertIsNone(result['engineering_cumulative_seconds'])
            self.assertFalse(result['complete_parent_fee_known']);self.assertEqual(result['source_before'],[])
            self.assertFalse(result['passed']);launch.assert_not_called()


if __name__ == '__main__':
    unittest.main()
