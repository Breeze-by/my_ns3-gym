#!/usr/bin/env python3
"""Bind the synthetic CPU result to actual installed ODE and headers."""
import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import time

P = pathlib.Path(__file__).parent


def binding(path):
    path = pathlib.Path(path)
    before = path.stat()
    data = path.read_bytes()
    after = path.stat()
    fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns')
    first = {key: getattr(before, key) for key in fields}
    last = {key: getattr(after, key) for key in fields}
    assert first == last
    return {'path': str(path), 'resolved_path': str(path.resolve()),
            'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'elf': data[:4] == b'\x7fELF', 'stat_before': first, 'stat_after': last}


started = time.monotonic()
result = json.loads((P / 'reproduction_stdout_v1.json').read_text())
assert result['defect_reproduced'] is True
assert result['false_positive_cases'] == 6
assert len(result['cases']) == 15
ode = binding(result['actual_dCollide_library'])
assert ode['elf']
command = ['/usr/bin/nm', '-D', ode['resolved_path']]
run = subprocess.run(command, capture_output=True)
(P / 'actual_ode_nm_stdout_v1.log').write_bytes(run.stdout)
(P / 'actual_ode_nm_stderr_v1.log').write_bytes(run.stderr)
assert run.returncode == 0
names = run.stdout.decode().splitlines()
assert any(line.endswith(' dSetColliderOverride') for line in names)
assert any(line.endswith(' dCollide') for line in names)
assert not any('dCollideRayBox' in line for line in names)
headers = [binding('/usr/include/gazebo-11/gazebo/ode/' + name)
           for name in ('ode.h', 'collision.h', 'odemath.h', 'odeinit.h',
                        'common.h', 'objects.h')]
source = pathlib.Path('/tmp/mr3_p2a0_v21_native_box_transform_source_review_v1')
references = [binding(source / name) for name in
              ('ode_ray_11.10.2.cpp', 'ode_box_11.10.2.cpp',
               'ode_collision_kernel_11.10.2.cpp', 'ode_collision_kernel_11.10.2.h')]
originals = [binding(path) for path in sorted(P.iterdir()) if path.is_file()
             and path.name != 'checks_v1.json']
report = {
    'schema': 'mr3-ray-box-original-defect-cpu-checks-v1',
    'passed': True, 'defect_reproduced': True,
    'scope': 'Synthetic CPU-only direct dCollide on installed Gazebo-bundled ODE. No Gazebo server/world/physics stepping, ROS/DDS, original cast replay, source/Git mutation or native-research credit.',
    'cases': 15, 'false_positive_cases': 6,
    'actual_ode': ode, 'headers': headers, 'primary_source': references,
    'export_probe': {'argv': command, 'exit_code': run.returncode,
                     'dSetColliderOverride_available': True,
                     'dCollideRayBox_exported': False},
    'originals': originals,
    'initial_failure': 'Initial -I SDK build under -Werror rejected pre-existing ode/misc.h string-literal-to-char* declarations. Original argv/source/stdout/stderr remain. -isystem marks existing SDK headers; own-source warnings remain errors.',
    'numeric_counterexample': {'origin': [0, -.12, .073],
        'direction': [0, -1, -1e-9], 'box_halfheight': .0445,
        'original_contact_depth': .012500000000000011,
        'original_contact_position': [0, -.1325, .0729999999875],
        'independent_analytic_reference': 'MISS'},
    'limitations': ['Direct narrowphase reproduction alone does not establish original cast-time native primitives.',
                    'Broadphase/lifecycle are investigated in the separate correction proposal probes.',
                    'No old failed native receipt is changed.'],
    'execution': {'argv': sys.argv, 'executable': sys.executable,
                  'cwd': os.getcwd(), 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  'wall_seconds': time.monotonic() - started}
}
out = P / 'checks_v1.json'
with out.open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({'path': str(out), 'sha256': hashlib.sha256(out.read_bytes()).hexdigest(),
                  'actual_ode_sha256': ode['sha256'], 'actual_ode_bytes': ode['bytes']}))
