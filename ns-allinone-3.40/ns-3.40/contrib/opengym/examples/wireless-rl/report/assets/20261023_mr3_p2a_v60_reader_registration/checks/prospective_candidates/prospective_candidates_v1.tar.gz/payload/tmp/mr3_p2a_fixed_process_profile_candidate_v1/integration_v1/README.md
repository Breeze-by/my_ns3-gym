# 固定实际接线 shadow，尚未 native

此目录补齐后继单次open101/1worker/8step普通probe_action诊断所需接线；不修改生产E、不重跑core14toy、没有ROS/World/raw/model执行。core仍为父目录原11286B/SHA `bef68fb65d28edc24689e22b576c5b727fc179c67dde3e7c0b53d7eeac0073e7`。真实parent/scope/费用/新freeze尚由root另封；`fixed_profile_launcher_v1.py`在/tmp下直接拒绝native启动，只有canonical新clean/pushed freeze且源码逐字匹配后才有入口。

| 文件 | 固定作用 |
|---|---|
| fixed_profile_launcher_v1.py | 固定原benchmark argv：open101、worker1、8step、普通probe_action、零学习、原20/34ms和RPC时限；原cooperative allocation1500/close120是待新scope批准的草案。预载仅作worker命令替换的Supervisor投影后调用原benchmark.main。 |
| fixed_roles_entry_v1.py | 只按core固定program绝对路径推断3role；恢复原script父目录sys.path[0]，补齐worker ros_smoke_test兄弟import；再用同一core运行。 |
| fixed_integration_v1.py | 只提供两份固定source投影与adapter encode_snapshot函数透明hook；不改共享stdlib runpy对象，仅替换该core模块的alias。 |
| base_source_pins_v1.json | 三份current==E原源SHA/bytes；不为当前/tmp投影声明正式冻结或Native信用。 |

两份投影按literal count==1生成并whole-byte逆还原：Supervisor.reset只把原worker解释器命令前置固定entry；worker.__init__只将原mr3_worker_ros线程target包为profiled_call('ros_spin', spin)，并在原ros2 launch argv加入固定prefix与`^(motion_safety|mr3_adapter)$` filter。不改参数生成、动作/数学、线程数量、线程名/daemon、RPC或启动守卫。普通8step不启用32step preparation_motion_probe/readback，也没有放宽相应入口；**本诊断没有现成Nav2 readback**，如实保留这一范围限制。

原E字节、投影字节、old/new literal、SHA和逆还原证据在supervisor_static_projection、worker_static_projection及static_projection_review_v1.json。未来canonical目录会改变entry绝对路径，须重新生成该路径对应的projection SHA并纳入新source freeze，不能把/tmp的projection SHA冒当canonical运行字节。

worker按原filename、__file__、__name__='__main__'执行保存的投影，原末尾sys.exit(main())保留；其traceback/pstats filename仍为原worker路径，**执行体确有显式profile投影，不能宣称执行体逐字是E原源码**。每次真实worker还会保存自身source_projection证明。Supervisor保持原模块名/文件与WORKSPACE/ROS_ROOT推导，只有shell命令literal变化。实际进程wrapper argv会与原argv不同，core同时保存actual cmdline与原program argv，不伪装成原进程命令。

adapter在core main capture内导入固定真实module，先核实际module.__file__与固定source一致，仅把module.encode_snapshot包为同一原function的profiled_call；args/kwargs原样转交、返回对象身份和异常继续传播，finally恢复原function。这个函数仍由原单worker ThreadPoolExecutor执行；main不冒称覆盖encoder。motion_safety不需要source投影，原SingleThreadedExecutor由main capture覆盖。

参数dict原本生成随机launch_params路径，继续保留；core只读regular/no-symlink原实际参数文件，记录完整SHA/bytes并复制快照，没有动态argv授权sidecar或fixed-YAML改写。诊断配置由固定source/launcher及实际参数快照给出；未做的GetParameters/readback明确UNKNOWN，不能将它用作配置或科学资格。

接线CPU仅做AST和人工函数测试，未导入执行Supervisor/Worker/adapter生产模块：tool57708真实reap rc0，3/3 PASS、0fail/error/skip、1.139958058秒；72源before/after/current/recovery一致，JUnit/actualargv核验，2保存CPU身份fresh-gone。static_cpu_v1保留实际wait/JUnit/console，static_cpu_source_recovery_v1.json与static_cpu_verified_v1.json保留严格证据。core14toy没有重跑或改判。

实际ROS launch命令构造/临时参数与三进程五lane的真实进入、关闭及pstats尚未观察；当前只是一份可审候选，不是native/capacity PASS。root须先真正关闭V60，明确新资源与闭合来源、source/Git freeze、实际launcher outer wait、保存身份、完整artifact/source inventory，然后才运行这唯一诊断。它只定位成本，不给95%、P2A、pilot/final或补判旧FAIL信用。
