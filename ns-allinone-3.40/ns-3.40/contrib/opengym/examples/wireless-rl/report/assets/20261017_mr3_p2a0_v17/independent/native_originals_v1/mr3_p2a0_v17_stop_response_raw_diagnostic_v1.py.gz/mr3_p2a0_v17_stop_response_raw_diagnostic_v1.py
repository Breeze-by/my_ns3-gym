"""Read-only, one sequential pass per original; diagnostic, never gate credit."""
import argparse
from bisect import bisect_right
from collections import Counter
from datetime import datetime, timezone
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
RUN = ROOT / 'ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261017_v17_reset/worker1'
FREEZE = 'eee6b2f90f697b28a1c20a2af5d1a6d2f044465e'
CASES = [('episode002_open_101', 95.5, 96.18, 96.22),
         ('episode003_rooms_101', 89.6, 90.26, 90.36)]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def ns(sec):
    return round(sec * 1_000_000_000)


def identity(path):
    s = path.stat()
    return {k: getattr(s, k) for k in ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')}


def stamp(message):
    v = message['header']['stamp']
    return v['sec'] * 1_000_000_000 + v['nanosec']


def vec(value):
    return [value[k] for k in ('x', 'y', 'z')]


def ref(line, row, raw):
    return {'source_line': line, 'record_sequence': row.get('record_sequence'),
            'raw_line_sha256': digest(raw)}


def scan(path, out, include, consume, json_lines=True):
    before = identity(path)
    h = hashlib.sha256()
    selected_hash = hashlib.sha256()
    selected_bytes = 0
    count = 0
    total = 0
    index = []
    with path.open('rb') as original, out.open('xb') as encoded, gzip.GzipFile(filename='', mode='wb',
            fileobj=encoded, mtime=0) as selected:
        for line, raw in enumerate(original, 1):
            h.update(raw)
            total += len(raw)
            if not raw.strip():
                continue
            row = json.loads(raw) if json_lines else None
            if not json_lines or include(row):
                selected.write(raw)
                selected_hash.update(raw)
                selected_bytes += len(raw)
                count += 1
                if row is not None:
                    r = ref(line, row, raw)
                    index.append(r)
                    consume(row, r)
    after = identity(path)
    if before != after or total != before['st_size']:
        raise ValueError(f'original changed during sequential read: {path}')
    return {'source': str(path), 'source_sha256': h.hexdigest(), 'source_bytes': total,
            'source_stat_before': before, 'source_stat_after': after,
            'original_sequential_reads': 1, 'selected_path': str(out),
            'selected_encoding': 'gzip', 'selected_rows': count,
            'selected_decoded_bytes': selected_bytes,
            'selected_decoded_sha256': selected_hash.hexdigest(),
            'selected_encoded_bytes': out.stat().st_size,
            'selected_encoded_sha256': digest(out.read_bytes()), 'row_index': index}


def extrema(rows, fields):
    return {f: {'minimum': min((r[f] for r in rows), default=None),
                'maximum': max((r[f] for r in rows), default=None)} for f in fields}


def diagnose(episode, window, b_sec, a_sec, output):
    directory = RUN / episode
    output.mkdir()
    window_ns = ns(window)
    odom, commands, decisions, drive, adapter, transitions, physics = [], [], [], [], [], [], []
    kinds = Counter()
    duplicate_sources = 0
    conflicts = []

    def motion_include(row):
        p = row['payload']
        return (p.get('robot') == 'tb1' and ns(row['sim_time_sec']) >= window_ns
                and row['kind'] in ('own_odom', 'actual_cmd_vel', 'decision'))

    def motion_consume(row, r):
        nonlocal duplicate_sources
        kinds[row['kind']] += 1
        p = row['payload']
        record_clock = ns(row['sim_time_sec'])
        if row['kind'] == 'own_odom':
            m = p['message']
            linear = vec(m['twist']['twist']['linear'])
            angular = vec(m['twist']['twist']['angular'])
            sample = dict(r, source_ns=stamp(m), receipt_clock_ns=record_clock,
                          linear_xyz=linear, angular_xyz=angular,
                          planar_speed=math.hypot(*linear[:2]),
                          xy=vec(m['pose']['pose']['position'])[:2],
                          position_xyz=vec(m['pose']['pose']['position']),
                          orientation=m['pose']['pose']['orientation'],
                          frames=[m['header']['frame_id'], m['child_frame_id']])
            if odom and sample['source_ns'] == odom[-1]['source_ns']:
                duplicate_sources += 1
                same = all(sample[k] == odom[-1][k] for k in (
                    'linear_xyz', 'angular_xyz', 'position_xyz', 'orientation', 'frames'))
                if not same:
                    conflicts.append([odom[-1]['source_line'], sample['source_line']])
            else:
                if odom and sample['source_ns'] < odom[-1]['source_ns']:
                    raise ValueError('own source rewind')
                odom.append(sample)
        elif row['kind'] == 'actual_cmd_vel':
            commands.append(dict(r, clock_ns=record_clock,
                                 v=p['twist']['linear']['x'], w=p['twist']['angular']['z'],
                                 payload=p))
        else:
            decisions.append(dict(r, clock_ns=record_clock, payload=p))

    def drive_consume(row, r):
        drive.append(dict(r, **{k: v for k, v in row.items() if k not in r}))

    manifest = []
    manifest.append(scan(directory / 'motion_safety.jsonl', output / 'motion_tb1_selected.jsonl.gz',
                         motion_include, motion_consume))
    manifest.append(scan(directory / 'drive_tb1.jsonl', output / 'drive_tb1_selected.jsonl.gz',
                         lambda row: row['sim_time_ns'] >= window_ns, drive_consume))
    manifest.append(scan(directory / 'adapter.jsonl', output / 'adapter_selected.jsonl.gz',
                         lambda row: ns(row['stamp']) >= window_ns,
                         lambda row, r: adapter.append(dict(r, **row))))
    for name, rows in [('transitions.jsonl', transitions), ('physics.jsonl', physics)]:
        manifest.append(scan(directory / name, output / (name + '.gz'), lambda row: True,
                             lambda row, r: rows.append(dict(r, **row))))
    # Metadata is captured once and parsed from the captured small bytes.
    mp = directory / 'metadata.json'
    mbefore = identity(mp)
    metadata_bytes = mp.read_bytes()
    mafter = identity(mp)
    if mbefore != mafter:
        raise ValueError('metadata changed')
    (output / 'metadata.json').write_bytes(metadata_bytes)
    metadata = json.loads(metadata_bytes)
    manifest.append({'source': str(mp), 'source_sha256': digest(metadata_bytes),
                     'source_bytes': len(metadata_bytes), 'source_stat_before': mbefore,
                     'source_stat_after': mafter, 'original_sequential_reads': 1,
                     'selected_path': str(output / 'metadata.json'), 'selected_encoding': 'identity'})
    if metadata['freeze'] != FREEZE:
        raise ValueError('freeze mismatch')
    release = transitions[0]['info']['release_time_ns']
    end = physics[-1]['end_time_ns']
    acts = [r for r in drive if r['kind'] == 'actuation']
    receives = [r for r in drive if r['kind'] == 'command_received']
    clocks = [r['source_ns'] for r in odom]
    event_reports = []
    for category, event_sec in [('B_native_cancel_end_to_end', b_sec), ('A_final_linear_zero', a_sec)]:
        event = ns(event_sec)
        anchor_index = bisect_right(clocks, event) - 1
        anchor = odom[anchor_index]
        following = odom[anchor_index + 1]
        frac = (event - anchor['source_ns']) / (following['source_ns'] - anchor['source_ns'])
        start_xy = [anchor['xy'][i] + frac * (following['xy'][i] - anchor['xy'][i]) for i in (0, 1)]
        candidates = [r for r in odom if event <= r['source_ns'] <= end]
        first_rest = next((i for i in range(len(candidates) - 2)
                           if all(r['planar_speed'] <= .01 for r in candidates[i:i+3])), None)
        rest = candidates[first_rest] if first_rest is not None else None
        stop = rest['source_ns'] if rest else end
        path = 0.0
        point = start_xy
        final_xy = point
        max_chord = {'speed_mps': 0.0}
        for prev, cur in zip(odom, odom[1:]):
            if cur['source_ns'] < event or cur['source_ns'] > stop:
                continue
            distance = math.dist(point, cur['xy'])
            path += distance
            point = cur['xy']
            final_xy = point
            dt = cur['source_ns'] - max(event, prev['source_ns'])
            if dt > 0 and distance / (dt / 1e9) > max_chord['speed_mps']:
                max_chord = {'speed_mps': distance / (dt / 1e9),
                             'previous_source_line': prev['source_line'],
                             'source_line': cur['source_line'], 'source_ns': cur['source_ns'],
                             'distance_m': distance, 'dt_ns': dt}
        after = [r for r in candidates if r['source_ns'] >= event + 780_000_000]
        # Distinct commands are listed; all original rows are preserved separately.
        command_changes = []
        for r in commands:
            if r['clock_ns'] < event:
                continue
            if not command_changes or (r['v'], r['w']) != (command_changes[-1]['v'], command_changes[-1]['w']):
                command_changes.append({k: r[k] for k in ('clock_ns', 'v', 'w', 'source_line')})
        event_reports.append({'category': category, 'event_ns': event, 'anchor': anchor,
            'horizon_ns': event + 780_000_000,
            'first_source_after_horizon': next((r for r in candidates if r['source_ns'] > event + 780_000_000), None),
            'first_three_rest_samples': candidates[first_rest:first_rest+3] if rest else [],
            'latency_sec': (rest['source_ns'] - event) / 1e9 if rest else None,
            'observed_path_to_first_rest_or_end_m': path,
            'observed_center_chord_to_first_rest_or_end_m': math.dist(start_xy, final_xy),
            'maximum_sampled_center_chord_speed': max_chord,
            'post_horizon_samples': len(after),
            'post_horizon_nonrest_samples': sum(r['planar_speed'] > .01 for r in after),
            'post_horizon_planar_range': extrema(after, ['planar_speed']),
            'actual_command_changes_after_event': command_changes,
            'post_event_nonzero_angular_commands': sum(r['clock_ns'] >= event and r['w'] != 0 for r in commands),
            'post_event_nonzero_linear_commands': sum(r['clock_ns'] >= event and r['v'] != 0 for r in commands)})
    summaries = []
    for sec in range(math.floor(window), math.ceil(end / 1e9) + 1):
        lo, hi = ns(sec), ns(sec + 1)
        samples = [r for r in odom if lo <= r['source_ns'] < hi]
        active = [r for r in acts if lo <= r['sim_time_ns'] < hi]
        if not samples and not active:
            continue
        summaries.append({'second': sec, 'odom_count': len(samples),
            'first_odom': samples[0] if samples else None,
            'last_odom': samples[-1] if samples else None,
            'odom_planar': extrema(samples, ['planar_speed']),
            'actuation_count': len(active),
            'desired_nonzero_count': sum(r['desired_v'] != 0 or r['desired_w'] != 0 for r in active),
            'current_rim_abs_max': max((max(map(abs, r['current_rim_mps'])) for r in active), default=None),
            'applied_rim_abs_max': max((max(map(abs, r['applied_rim_mps'])) for r in active), default=None),
            'last_actuation': active[-1] if active else None})
    report = {'episode': episode, 'epoch': metadata['epoch'], 'freeze': FREEZE,
              'window_start_ns': window_ns, 'release_ns': release, 'physics_end_ns': end,
              'unique_own_odom_samples_in_selected_window': len(odom),
              'repeated_source_callbacks': duplicate_sources, 'conflicting_duplicate_sources': conflicts,
              'motion_kind_counts': dict(kinds), 'events': event_reports,
              'seconds': summaries, 'drive_kind_counts': dict(Counter(r['kind'] for r in drive)),
              'last_command_received': receives[-1] if receives else None,
              'last_actuation': acts[-1] if acts else None,
              'adapter_native_and_cancel_receipts': [r for r in adapter if
                (r['kind'] in ('native_send', 'native_cancel') and r['payload'].get('robot') == 'tb1') or
                (r['kind'] == 'delivery' and r['payload'].get('stream') == 'receipt'
                 and r['payload'].get('source') == 'tb1')],
              'input_manifest': manifest}
    for name, value in [('unique_own_odom.json', odom), ('actual_commands.json', commands),
                        ('drive_derived.json', drive), ('report.json', report)]:
        (output / name).write_text(json.dumps(value, indent=2) + '\n')
    return {'episode': episode, 'report': str(output / 'report.json'),
            'report_sha256': digest((output / 'report.json').read_bytes()),
            'events': [{k: v for k, v in r.items() if k in (
                'category', 'event_ns', 'latency_sec', 'observed_path_to_first_rest_or_end_m',
                'post_horizon_nonrest_samples', 'post_event_nonzero_angular_commands',
                'post_event_nonzero_linear_commands')} for r in event_reports]}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-directory', type=Path, required=True)
    args = parser.parse_args()
    args.output_directory.mkdir()
    start = time.monotonic()
    results = [diagnose(*case, args.output_directory / case[0]) for case in CASES]
    report = {'schema': 'mr3-v17-stop-response-raw-diagnostic-v1',
              'diagnostic_completed': True, 'freeze': FREEZE, 'episodes': results,
              'script': str(Path(__file__).resolve()), 'script_sha256': digest(Path(__file__).read_bytes()),
              'utc': datetime.now(timezone.utc).isoformat(), 'wall_sec': time.monotonic() - start,
              'scope': 'Read-only single-pass extraction. No formal auditor invocation, gate changes, native/control calls, or new PASS credit. Raw messages and source row references retained.'}
    (args.output_directory / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
