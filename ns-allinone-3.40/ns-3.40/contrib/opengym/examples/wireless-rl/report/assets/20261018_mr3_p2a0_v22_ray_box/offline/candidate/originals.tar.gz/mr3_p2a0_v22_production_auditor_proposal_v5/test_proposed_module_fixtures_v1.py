"""Run the unchanged four status-document assertions with their revised narrow fixture.
Production load_native_gates, ENV/machine helpers execute from the exact proposed AST.
Original dependency-loaded component boundary remains mocked as in the original tests.
"""
import ast
import copy
import hashlib
import gzip
from functools import partial
import json
from pathlib import Path
import subprocess
import types
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
source = (HERE / 'proposed_audit_ppo.py').read_text()
tree = ast.parse(source)
functions = {'require', 'sha', 'verify_machine_task_file', 'verify_environment_appendix', 'load_native_gates',
             'verify_frozen_pins', 'verify_execution_configs', 'verify_ray_box_library',
             'project_sensor_diagnostic_runtime', 'project_ray_box_runtime'}
body = [node for node in tree.body if isinstance(node, ast.Assign) or (
    isinstance(node, ast.FunctionDef) and node.name in functions)]
audit_ppo = types.ModuleType('fixture_actual_proposed_auditor')
audit_ppo.__dict__.update(Path=Path, hashlib=hashlib, gzip=gzip, json=json, subprocess=subprocess,
                          load_pinned=lambda *a: None, load_compatible_components=lambda *a: None)
exec(compile(ast.Module(body=copy.deepcopy(body), type_ignores=[]),
             str(HERE / 'proposed_audit_ppo.py'), 'exec'), audit_ppo.__dict__)
audit_ppo.__dict__.update(SimpleNamespace=SimpleNamespace, partial=partial, audit_scalar=SimpleNamespace(
    ORIGINAL_SCALAR_SHA256=audit_ppo.SCALAR_SHA256, audit_episode=lambda *a, **k: None))
audit_ppo.__file__ = '/home/zhuyulab/ns3-workspace/ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/mr3_learning/audit_ppo.py'
tests = ast.parse((HERE / 'proposed_test_audit_ppo.py').read_text())
classes = [node for node in tests.body if isinstance(node, ast.ClassDef)
           and node.name in ('NativeBindingTests', 'ProductionExecutionProjectionTests')]
exec(compile(ast.Module(body=classes, type_ignores=[]),
             str(HERE / 'proposed_test_audit_ppo.py'), 'exec'), globals())

if __name__ == '__main__':
    original_read = Path.read_bytes
    env_path = Path('/home/zhuyulab/ns3-workspace') / audit_ppo.WIRELESS / 'MR3_ENV_CONTRACT.md'
    proposed_env = (HERE / 'MR3_ENV_CONTRACT.proposed.md').read_bytes()
    def read(path):
        return proposed_env if path == env_path else original_read(path)
    with patch.object(Path, 'read_bytes', read):
        unittest.main(verbosity=2)
