"""Only CPU old_originals fixtures, including actual archived native identity bytes."""
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile


ROOT = Path('/home/zhuyulab/ns3-workspace')
A13 = ROOT / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
              'report/assets/20261017_mr3_p2a0_v13')
OLD = Path('/tmp/mr3_p2a0_v14_offline_archiver_before_identity_v1.py')
NEW = Path('/tmp/mr3_p2a0_v14_archive_offline_originals_v1.py')


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def main():
    old, new = load(OLD, 'before_identity'), load(NEW, 'after_identity')
    original_manifest = A13 / 'native/interface/manifest.json'
    manifest_raw = original_manifest.read_bytes()
    original = json.loads(manifest_raw)
    actual = next(row for row in original['files']
                  if '02103626e39e3318' in row.get('selected', ''))
    assert actual['encoding'] == 'identity'
    actual_path = original_manifest.parent / actual['selected']
    actual_raw = actual_path.read_bytes()
    assert hashlib.sha256(actual_raw).hexdigest() == actual['raw_sha256']
    cases = []
    with tempfile.TemporaryDirectory(prefix='mr3_v14_identity_cpu_') as directory:
        base = Path(directory)
        old.OLD = new.OLD = base
        selected = base / 'actual.json.gz'
        selected.write_bytes(actual_raw)
        manifest = base / 'manifest.json'

        def set_row(row):
            manifest.write_text(json.dumps({'entries': [dict(row, selected=str(selected))]}))

        set_row(actual)
        try:
            old.old_originals()
        except ValueError as failure:
            assert 'old selected raw SHA mismatch' in str(failure)
            cases.append({'case': 'old_actual_identity_gzip', 'accepted': False,
                          'scope': 'reproduced suffix-only false rejection'})
        else:
            raise AssertionError('old reader did not reproduce identity gzip failure')
        accepted, _ = new.old_originals()
        assert actual['raw_sha256'] in accepted and selected.read_bytes() == actual_raw
        cases.append({'case': 'new_actual_identity_gzip', 'accepted': True,
                      'raw_bytes_equal_actual_native_original': True})

        payload = b'encoded gzip must decode once\n'
        encoded = gzip.compress(payload, mtime=0)
        selected.write_bytes(encoded)
        good = {'source': '/tmp/cpu_original', 'raw_sha256': hashlib.sha256(payload).hexdigest(),
                'selected_sha256': hashlib.sha256(encoded).hexdigest(), 'encoding': 'gzip'}
        set_row(good)
        assert good['raw_sha256'] in new.old_originals()[0]
        cases.append({'case': 'explicit_gzip', 'accepted': True})
        set_row(dict(good, selected_sha256='0' * 64))
        try:
            new.old_originals()
        except ValueError as failure:
            assert 'encoded SHA mismatch' in str(failure)
            cases.append({'case': 'explicit_gzip_wrong_encoded_SHA', 'accepted': False})
        else:
            raise AssertionError('incorrect encoded SHA accepted')
        for codec in ('brotli', None):
            set_row(dict(good, encoding=codec))
            try:
                new.old_originals()
            except ValueError as failure:
                assert 'unknown old selected codec' in str(failure)
                cases.append({'case': 'unknown_codec_' + str(codec), 'accepted': False})
            else:
                raise AssertionError('unknown explicit codec accepted')
        compression = dict(good)
        compression['compression'] = compression.pop('encoding')
        set_row(compression)
        assert good['raw_sha256'] in new.old_originals()[0]
        cases.append({'case': 'explicit_compression_gzip', 'accepted': True})
        legacy = dict(good)
        legacy.pop('encoding')
        set_row(legacy)
        assert good['raw_sha256'] in new.old_originals()[0]
        cases.append({'case': 'legacy_no_codec_suffix_fallback', 'accepted': True})
        set_row(dict(good, compression='identity'))
        try:
            new.old_originals()
        except ValueError as failure:
            assert 'conflicting selected codecs' in str(failure)
            cases.append({'case': 'conflicting_explicit_codecs', 'accepted': False})
        else:
            raise AssertionError('conflicting explicit codecs accepted')
    assert original_manifest.read_bytes() == manifest_raw and actual_path.read_bytes() == actual_raw
    print(json.dumps({'schema': 'mr3-v14-native-identity-codec-fixtures-v1', 'passed': True,
                      'scope': 'Only old_originals CPU calls; archive main never invoked.',
                      'actual_manifest': str(original_manifest),
                      'actual_manifest_sha256': hashlib.sha256(manifest_raw).hexdigest(),
                      'actual_selected': str(actual_path),
                      'actual_raw_sha256': hashlib.sha256(actual_raw).hexdigest(),
                      'old_source_sha256': hashlib.sha256(OLD.read_bytes()).hexdigest(),
                      'new_source_sha256': hashlib.sha256(NEW.read_bytes()).hexdigest(),
                      'cases': cases}, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
