"""Small synthetic ROS-message fixtures; no node, episode or native process."""

import copy
import json

import numpy as np
import pytest
import rclpy
from geometry_msgs.msg import TransformStamped
from nav_msgs.msg import OccupancyGrid, Odometry
from rclpy.node import Node

from merge_map.merge_map import merge_maps, merge_navigation_map
from multi_robot_exploration.mr3_information import map_digest, map_payload
from multi_robot_exploration.mr3_observation import build_snapshot
from multi_robot_exploration.mr3_proxy2d_information import ProxyInformation, ROBOTS
from multi_robot_exploration.mr3_transport import Envelope


def grid(data, *, stamp=1, origin=0., width=None):
    message = OccupancyGrid()
    message.header.stamp.sec = stamp
    message.header.frame_id = "map"
    message.info.resolution = .2
    message.info.width = len(data) if width is None else width
    message.info.height = len(data) // message.info.width
    message.info.origin.position.x = origin
    message.info.origin.orientation.w = 1.
    message.data = data
    return message


def complete(maps=None, **kwargs):
    information = ProxyInformation("proxy-fixture", **kwargs)
    information.set_time(2.)
    maps = maps or {name: grid([0, -1, 0]) for name in ROBOTS}
    for name, message in maps.items():
        information.receive_local_map(name, message)
    information.publish_maps()
    return information


def test_original_bridge_can_run_without_node_or_rclpy_initialization(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("CPU message fixture must not initialize ROS")
    monkeypatch.setattr(rclpy, "init", forbidden)
    monkeypatch.setattr(Node, "__init__", forbidden)
    information = complete()
    inputs = information.snapshot_inputs()
    assert set(inputs["navigation_maps"]) == set(ROBOTS)
    assert all(value["received_stamp"] == 2. for value in inputs["map_sources"].values())
    assert information.map_diagnostics["completed"] == 1


def test_raw_callbacks_cannot_supply_received_or_navigation_snapshots():
    information = ProxyInformation("proxy-fixture")
    information.set_time(2.)
    for name in ROBOTS:
        information.receive_local_map(name, grid([0, -1, 0]))
    assert information.received.snapshot() == {}
    with pytest.raises(ValueError, match="completed map bundle"):
        information.snapshot_inputs()
    information.publish_maps()
    assert information.snapshot_inputs()["map_version"] == 1


def test_wrapper_reuses_exact_original_conservative_and_own_known_composition():
    maps = {"tb1": grid([0, -1, 0]), "tb2": grid([100, 100, -1]),
            "tb3": grid([-1, -1, -1])}
    information = complete(maps)
    expected = merge_maps(list(maps.values()))
    assert map_digest(information.hub_map) == map_digest(expected)
    assert list(information.hub_map.data) == [100, 100, 0]
    for name in ROBOTS:
        assert map_digest(information.navigation_maps[name]) == map_digest(
            merge_navigation_map(maps[name], expected))
    assert list(information.navigation_maps["tb1"].data) == [0, 100, 0]
    inputs = information.snapshot_inputs()
    assert all(entry["composition_version"] == "mr3-own-known-shared-unknown-v1"
               for entry in inputs["navigation_maps"].values())


def test_undelivered_peer_source_never_updates_hub_or_other_robot_navigation(monkeypatch):
    information = complete()
    before = map_digest(information.navigation_maps["tb1"])
    old = information.received.get("map", "tb2")
    information.set_time(3.)
    information.receive_local_map("tb2", grid([100, 100, 100], stamp=2))
    monkeypatch.setattr(information.transport, "deliver", lambda *args, **kwargs: ())
    information.publish_maps()
    assert information.received.get("map", "tb2") == old
    assert map_digest(information.navigation_maps["tb1"]) == before
    assert list(information.hub_map.data) == [0, -1, 0]
    inputs = information.snapshot_inputs()
    assert inputs["map_sources"]["tb2"]["received_stamp"] == 2.
    assert inputs["map_received_stamp"] == 2.


def test_undelivered_new_shared_map_cannot_replace_robot_navigation(monkeypatch):
    information = complete()
    before = map_digest(information.navigation_maps["tb1"])
    shared = information.edges["tb1"].get("shared_map", "hub")
    information.set_time(3.)
    information.receive_local_map("tb2", grid([100, 100, 100], stamp=2))
    monkeypatch.setattr(information.downlinks["tb1"], "deliver", lambda *args, **kwargs: ())
    information.publish_maps()
    assert list(information.hub_map.data) == [100, 100, 100]
    assert map_digest(information.navigation_maps["tb1"]) == before
    assert information.edges["tb1"].get("shared_map", "hub") == shared
    source = information.snapshot_inputs()["navigation_maps"]["tb1"]
    assert source["received_stamp"] == 2.
    assert source["shared_map_version"] == shared.version
    assert source["input_shared_map_payload_sha256"] == map_digest(
        information.received_map_publishers["tb1"].latest)


def test_repeat_delivery_preserves_source_and_map_version_and_detaches_outputs():
    information = complete()
    information.set_time(3.)
    information.publish_maps()
    inputs = information.snapshot_inputs()
    assert inputs["map_version"] == 1
    assert inputs["map_source_stamp"] == 1.
    assert inputs["map_received_stamp"] == 3.
    assert information.edges["tb1"].get("shared_map", "hub").source_stamp == 1.
    inputs["raw_grid"][0, 0] = 100
    inputs["navigation_maps"]["tb1"]["grid"][0, 0] = 100
    inputs["map_sources"]["tb1"]["source_stamp"] = 99.
    assert information.snapshot_inputs()["raw_grid"][0, 0] == 0
    assert information.snapshot_inputs()["navigation_maps"]["tb1"]["grid"][0, 0] == 0
    assert information.snapshot_inputs()["map_sources"]["tb1"]["source_stamp"] == 1.
    payloads = information.snapshot_payloads()
    assert payloads["fused"] == map_payload(information.hub_map)
    assert set(payloads) == {"fused", *ROBOTS, *("navigation:" + name for name in ROBOTS)}


def test_missing_robot_map_cannot_select_legacy_fused_observation_path():
    information = complete({"tb1": grid([0, -1, 0])})
    with pytest.raises(ValueError, match="all three delivered"):
        information.snapshot_inputs()


def test_snapshot_is_the_original_staging_v5_builder_with_delivered_inputs():
    information = complete()
    robots = [{"name": name, "x": float(index), "y": 0., "yaw": 0., "v": 0., "w": 0.,
               "valid": True, "epoch": information.epoch, "source_stamp": 2.,
               "received_stamp": 2., "navigation": {"phase": "idle"}}
              for index, name in enumerate(ROBOTS)]
    actual = information.build_snapshot(robots, 2., 1, task_start=2.)
    inputs = information.snapshot_inputs()
    expected = build_snapshot(inputs.pop("raw_grid"), inputs.pop("resolution"), inputs.pop("origin"),
        robots, 2., information.epoch, inputs.pop("map_version"), 1, task_start=2., **inputs)
    assert actual == expected
    assert actual["schema"] == "mr3-observation-v3"
    assert actual["candidate_rule"]["version"] == "mr3-navigation-geometric-staging-v5"
    assert all(value["source"] == "delivered_navigation_map" for value in actual["path_maps"].values())


def test_exact_rule_is_bound_to_original_delivered_bundle_and_new_snapshot_version():
    information = complete(seed_rule="exact-point-bridge-v1")
    inputs = information.snapshot_inputs()
    assert inputs.pop("seed_rule") == "exact-point-bridge-v1"
    legacy = complete().snapshot_inputs()
    for role in ("raw_grid",):
        np.testing.assert_array_equal(inputs.pop(role), legacy.pop(role))
    for role in ("robot_maps", "navigation_maps"):
        for name in ROBOTS:
            np.testing.assert_array_equal(inputs[role][name].pop("grid"), legacy[role][name].pop("grid"))
    assert inputs == legacy
    result = information.build_snapshot([{"name": name, "valid": False} for name in ROBOTS],
                                        2., 1, task_start=2.)
    assert result["candidate_rule"]["version"] == "mr3-navigation-geometric-staging-v6-exact-seed-v1"
    assert result["candidate_rule"]["seed_rule"] == "exact-point-bridge-v1"
    assert all(item["seed_point_bridge_certificate"] is None for item in result["path_maps"].values())


def test_estimated_state_requires_explicit_delivery_and_preserves_raw_inputs():
    information = ProxyInformation("proxy-fixture")
    information.set_time(2.)
    odometry, transform = Odometry(), TransformStamped()
    odometry.header.stamp.sec = transform.header.stamp.sec = 2
    odometry.pose.pose.position.x = 1.25
    odometry.pose.pose.orientation.w = transform.transform.rotation.w = 1.
    odometry.twist.twist.linear.x = .1
    sent = information.send_estimated_state("tb1", odometry, transform)
    assert sent.received_stamp is None
    assert information.received.get("state", "tb1") is None
    information.deliver()
    received = information.received.get("state", "tb1")
    assert received.received_stamp == 2.
    assert received.source_stamp == 2.
    assert received.payload["x"] == 1.25
    assert received.payload["odometry"]["pose"]["pose"]["position"]["x"] == 1.25
    assert received.payload["v"] == .1
    odometry.pose.pose.position.x = 999.
    assert received.payload["x"] == 1.25
    future = copy.deepcopy(transform)
    future.header.stamp.sec = 3
    with pytest.raises(ValueError, match="causal"):
        information.send_estimated_state("tb1", odometry, future)


def test_original_store_rejects_duplicate_and_cross_epoch_without_receipt_refresh():
    information = complete()
    old = information.received.get("map", "tb1")
    assert not information.received.receive(old, 3.)
    assert information.received.get("map", "tb1").received_stamp == 2.
    foreign = Envelope.create(epoch="another-epoch", stream="map", source="tb1",
        source_stamp=2., generated_stamp=2., sequence=99, version=99, payload=old.payload)
    assert not information.received.receive(foreign, 3.)
    assert information.received.get("map", "tb1") == old
    reset = ProxyInformation("new-epoch")
    assert reset.map_version == 0 and reset.transport.pending_count == 0
    assert reset.received.snapshot() == {}
    assert all(edge.snapshot() == {} for edge in reset.edges.values())


def test_invalid_grid_and_clock_rewind_fail_closed_without_invented_delivery():
    information = complete()
    bad = grid([101, 0, -1], stamp=2)
    before = information.local_maps["tb1"]
    information.receive_local_map("tb1", bad)
    assert information.errors and information.local_maps["tb1"] == before
    information.set_time(1.)
    information.publish_maps()
    assert information.clock_failed
    with pytest.raises(ValueError, match="healthy completed"):
        information.snapshot_inputs()
