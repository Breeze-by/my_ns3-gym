"""Final source/diff/style and command-consumer audit, no simulation or services."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
ROS = ROOT / 'ros2_ws/ros2-multi-robot-automap'
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
OUT = Path(__file__).parent
PACKAGE = ROS / 'src/multi_robot_exploration'
CONTROL = PACKAGE / 'multi_robot_exploration/control.py'
TEST = PACKAGE / 'test/test_navigation_peer_geometry.py'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    old = (OUT / 'control_before.py').read_bytes()
    new = CONTROL.read_bytes()
    current_test = TEST.read_bytes()
    before = ast.parse(old)
    after = ast.parse(new)
    original_import = next(node for node in before.body if isinstance(node, ast.ImportFrom)
                           and node.module == 'multi_robot_exploration.mr3_motion_safety')
    after.body = [copy.deepcopy(original_import) if isinstance(node, ast.ImportFrom) and
                  node.module == 'multi_robot_exploration.mr3_motion_safety' else node
                  for node in after.body]
    added = [node for node in after.body if isinstance(node, ast.Assign) and
             any(isinstance(target, ast.Name) and target.id == 'PEER_SPEED_BOUND_MPS'
                 for target in node.targets)]
    assert len(added) == 1 and ast.literal_eval(added[0].value) == .26
    after.body.remove(added[0])
    assert ast.dump(before) == ast.dump(after)
    assert ast.dump(ast.parse(current_test)) == ast.dump(ast.parse((OUT / 'test_before_style.py').read_bytes()))
    (OUT / 'control_final.py').write_bytes(new)
    (OUT / 'test_navigation_peer_geometry_final.py').write_bytes(current_test)
    commands = [
        ('style_final', ['/usr/bin/python3', '-m', 'flake8', '--max-line-length=99',
                         str(CONTROL), str(TEST)]),
        ('diff_check', ['git', 'diff', '--check', '--', str(CONTROL.relative_to(ROOT)),
                        str(TEST.relative_to(ROOT))]),
        ('control_diff', ['git', 'diff', '--', str(CONTROL.relative_to(ROOT))]),
        ('command_consumers', ['rg', '-n', r'\bCOMMAND_SPEED_LIMIT\b', '--glob', '*.py',
                               str(ROS / 'src'), str(ROS / 'scripts'), str(W / 'mr3_learning')]),
    ]
    checks = []
    for label, argv in commands:
        started = time.monotonic()
        result = subprocess.run(argv, cwd=ROOT, capture_output=True)
        wall = time.monotonic() - started
        log = OUT / (label + '.log')
        with log.open('xb') as stream:
            stream.write(result.stdout + result.stderr)
        assert result.returncode == 0, label
        checks.append({'label': label, 'argv': argv, 'cwd': str(ROOT), 'exit': result.returncode,
                       'wall_sec': wall, 'stdout_stderr': str(log),
                       'stdout_stderr_sha256': sha(log.read_bytes())})
    assert new == CONTROL.read_bytes() and current_test == TEST.read_bytes()
    red = json.loads((OUT / 'regression_red2.json').read_bytes())
    green = json.loads((OUT / 'related_green.json').read_bytes())
    replay = json.loads((OUT / 'actual_publication_replay_v1.json').read_bytes())
    assert red['exit'] == 1 and green['exit'] == 0 and replay['passed'] is True
    report = {
        'schema': 'mr3-v15-navigation-peer-geometry-repair-checks-v1', 'passed': True,
        'files': {str(CONTROL): {'sha256': sha(new), 'bytes': len(new)},
                  str(TEST): {'sha256': sha(current_test), 'bytes': len(current_test)}},
        'production_change': 'Only replace COMMAND_SPEED_LIMIT->PEER_SPEED_BOUND_MPS import '
                             'alias with independent navigation constant .26. Body radius import '
                             'and every existing function/method AST remain unchanged.',
        'only_import_and_independent_navigation_constant_AST_change': True,
        'style_only_final_test_change_AST_identical_to_56_PASS': True,
        'regression': {'red': {'path': str(OUT / 'regression_red2.json'), 'tests_failed': 7,
                               'exit': red['exit'], 'wall_sec': red['wall_sec']},
                       'green': {'path': str(OUT / 'related_green.json'), 'tests_passed': 56,
                                 'exit': green['exit'], 'wall_sec': green['wall_sec']},
                       'first_red_rendering_interruption': {
                           'receipt': str(OUT / 'regression_red.json'),
                           'owned_PID_start_signal_record': str(OUT / 'red_report_interrupt_identity.json'),
                           'scope': 'Own CPU pytest rendered a huge repetitive bytes failure diff; '
                                    'SIGINT interrupted its report and pytest produced IndexError. '
                                    'Original source/stdout/exit retained. Shape+SHA assertion changes '
                                    'remove report cost, not geometry requirements.'}},
        'full_actual_producer_offline_replay': {
            'path': str(OUT / 'actual_publication_replay_v1.json'),
            'all_six_payloads_exact_immutable_geometry': True,
            'command_limit': .20, 'navigation_peer_prediction': .26,
            'native_credit': False},
        'checks': checks,
        'command_consumer_audit': {
            'raw_search': str(OUT / 'command_consumers.log'),
            'scope': 'Exact identifier across canonical ROS/src+scripts and wireless mr3_learning Python; '
                     'tests shown separately in raw output; build/install/history assets excluded.',
            'production': [
                'mr3_motion_safety.py defines and applies final-command limit .20; intentional.',
                'audit_motion.py reads helper.COMMAND_SPEED_LIMIT/TURN_LIMIT for the same command '
                'validation; intentional and unchanged.',
                'control.py was the only cross-module navigation alias and is now independent.'],
            'navigation_dataflow': 'peer_safety_radius feeds real peer_obstacles.body_points and '
                                   'control.grid_with_peers (baseline planning call sites). No other '
                                   'direct COMMAND_SPEED_LIMIT alias found.',
            'other_implicit_command_cap_coupling_found': False},
        'required_parent_pin_updates': [
            {'owner': 'root', 'dictionary': 'audit_ppo.PREPARATION_RUNTIME_PINS',
             'path': str(CONTROL.relative_to(ROOT)), 'new_sha256': sha(new)},
            {'owner': 'root', 'scope': 'New test source/archive/static evidence and any new-version '
                                      'plan current audit_ppo SHA after pin update; no old immutable '
                                      'reader or old FAIL evidence is rewritten.'}],
        'unchanged_scope': 'Guard .20/.8 commands, measured .30/1.2, all geometry/body .50, '
                           'age/latency, settled path/speed, stop .78/.144, task/reward/contacts '
                           'and strict closure gates are untouched. Navigation .26 restores '
                           'immutable A10 prediction; it is not a new physical velocity theorem.',
        'sources_stable_at_verdict': True, 'native_or_service_or_colcon_runs': 0,
    }
    with (OUT / 'final_checks_v1.json').open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'passed': True, 'control_sha256': sha(new), 'test_sha256': sha(current_test),
                      'red': 7, 'related_green': 56, 'replayed_actual_payloads': 6}))


if __name__ == '__main__':
    main()
