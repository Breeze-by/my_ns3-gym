P2A.0剩余出口静态复核：原门应保留，没有新增门。

- 隔离50/150诊断不提供四阶段或策略信用；有依据修复后仍须新clean/pushed同冻结的interface、terminal、8轮reset、deadline完整链，失败即停、不拼旧PASS。
- 物理响应是A OR B：interface原2516每机至少一类；reset跨自己的八轮每机至少一类。原有eligible已观测超时/路径超界不能被pool信用抵消。每轮缺信用保留missing，不另加每轮A AND B。
- interface角运动覆盖为每机一个3fresh的|wz|>=.1同号段、总体双号、至少一台双号；reset仅逐轮sampled_bounds，coverage false如实保留。1.2/7/.1s源连续性保持。
- 每轮三台received path>.05m/native accept只是工程可用性；不替代任务真值1m/goal、95%/300s、地图质量、18源接触及.50m安全门。
- terminal两分支须保留真实短步和同边界零动作结算，API≠实际策略动作；deadline原300KEEP和严格关闭保留，均无95%或运动刺激信用。
- 完整state→peer→guard→self receipt→三台实际target storage→20ms物理链、sticky负ACK、永久零停、全body/source与settled整区间门均不能由1ms诊断代替。
- 原四阶段预算608 API/596保守step调用/18000墙秒，无GPU/更新；pilot余额不重置。

P2A.0通过后是工程交付待用户验收。P2A仍需网络实际选目标且无手工探索/真值输入的同版本训练—验证链，达到原95%任务。P2B/P2C/gateway不因此自动开始。

本次只读源码、冻结V17计划和契约，未读取活动V19 raw/回执，未运行native/ROS/DDS/正式审计或完整tests。详见同名JSON的逐项原件行号和SHA。
