from pathlib import Path
import json

root = Path('/home/zhuyulab/ns3-workspace')
w = root / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
ros = root / 'ros2_ws/ros2-multi-robot-automap'

closed = '''

## 原生闭合：FAIL 保留

冻结`26534fae40409e266376baf0995fb15dc0223e4b`干净推送后，source preflight核验97个runtime源、33个独立源及实际驱动库通过。实际仅启动interface，2026-10-17 07:28:33.084717–07:30:53.148215 UTC，140.06299758609384墙秒，exit1；0 reset返回、0 step、0任务秒。terminal/reset/deadline未尝试。准确argv见[launch原件](assets/20261017_mr3_p2a0_v9/accounting/mr3_p2a0_v9_interface_launch.json)，原生完整失败在[native目录](assets/20261017_mr3_p2a0_v9/native/interface/benchmark_summary.json)。

启动真实错误为`initial paused motion inputs are not ready for task release`。暂停初始74.323秒、17个1ms对齐后74.340；guard本机源均新鲜，但tb2 received TF source73.795、odom74.313、received74.320、sequence697，真实源龄545ms超过原500ms。新增producer原件明确证明：74.320秒周期716先选旧TF ref5173/source73.795并实际发布；新TF ref5176/source74.195在同clock的9.363墙毫秒后才进入producer。物理暂停74.340后，下一次10Hz定时发布无法发生。此为定时器与callback顺序/暂停饥饿，future odom保留修复正常、未发生state队列溢出/冲突。不能把v9缓存修复记为解决本次故障。

完整/输入/driver/information正式审计全部FAIL（缺reset/summary），不授启动、参数、机体响应或严格关闭信用。隔离诊断重放4780个odom（3588未来到达）、16101个TF、716次真实publication/716次motion接收及11061次decision的来源一致通过，但整体仍FAIL。45份保存的PID/start-tick身份全部消失；仅4份正常spawn/ready退出，worker forced cleanup=true，没有完整native_stop/Nav2 finalized，故不能把“进程已消失”写成“关闭门通过”。[关闭诊断原件](assets/20261017_mr3_p2a0_v9/independent/mr3_p2a0_v9_interface_closure_binary_review_v1.json)。

165份原生文件131198920原字节无损选存7508070字节；归档清单逐字核验97份Git源、137份原冻结前资产和54份独立原件，库存[SHA/文件清单](assets/20261017_mr3_p2a0_v9/inventory_native_v1.json)。原V9 sourcepack、原FAIL和所有诊断保留；无盲重试。后续[v10](20261017_mr3_p2a0_v10.md)显式状态→障碍→guard→驱动存储→物理提交，并修启动失败有序关闭。P2A.0尚未完成；原生GPU/optimizer=0，pilot余额1870决策/2905.954739546403墙秒不动。
'''
p = w / 'report/20261017_mr3_p2a0_v9.md'
s = p.read_text().replace('本版原生尚未启动。', '本版原生启动失败，完整结果见文末闭合。')
assert '## 原生闭合：FAIL 保留' not in s
p.write_text(s + closed)

new = '''# MR3-P2A.0 v10：暂停期间的显式因果执行阶段

继续用户“完成P2A.0”的授权。v9冻结`26534fae40409e266376baf0995fb15dc0223e4b`在启动、0个返回reset/step时FAIL：定时器先选旧TF、新TF同clock晚到，暂停后下一次10Hz发布不能触发。[原FAIL与完整证据](20261017_mr3_p2a0_v9.md)保持，不能用旧interface PASS拼装新矩阵。

本版在每20ms物理边界暂停时显式完成：信息节点选取实际已收到且source≤clock的本机odom/TF，真实发布main bundle和六个side消息并ACK；peer节点核对真实main bundle及六次side callback的SHA/身份/接收墙时，实际发布scan/cloud并ACK；guard核对自身真正收到的两份ACK/main bundle及causal own源，生成唯一正常输出、等待三条真实cmd_vel回收；worker再等三台原生驱动的实际storage ACK，评价器相位闭合后才推进下一20ticks。请求共用epoch/request_id/target clock，各成功normal ACK不可在同clock改写。10墙秒有界等待不推进仿真、不刷新source时间。

启动先接管旧clock下已实际回收和存储的三条零指令，再真实推进20ticks进入未正常提交的新clock，完成上述依赖链后release。接管前1ms相位对齐仍须原pre-release零输出及完整驱动审计。受控stepped状态发布改为每20ms显式提交（有效50Hz）；非受控warmup/非stepped原10Hz周期保持。这是执行接口版本变化，不能声称仍是stepped10Hz。`.5s`源龄原门不变，状态不读未交付的队友raw。

停车使用独立永久zero-stop类别：terminal/stop/failure可在同clock以更高guard序号立即三零，ready=false；单独stop_status/控制回执，不覆盖normal ACK，不授缺输入时的安全信用。后续每个关闭physics quantum仍须三台实际零storage。真实terminal可取消尚未完成的normal state commit；只有实际收到同epoch终态后，排空才可复用最后真实commit的原引用/源时间，不能生成新state或恢复LIVE推进。

启动发生基础设施失败时，以隔离begin/finalize协议先标记invalid并真实通知取消goal，等待实际零storage、Nav2/helper关闭、真实navigation_closed，最后由evaluator原有序关闭native。无reset就不造reward/transition，所有失败仍返回FAIL。通常已sealed episode保留原finalize规则。

任务95%/300秒、质量、每台1米+goal、18条fresh零接触、peer .50m、机体planar .30/angular1.2/accel7、停止.78秒/.144米、完整160ms驱动与settled全段漂移门均保持。候选v5/K8、actor/奖励、C++轮反馈及物理参数不改。外部32步工程fixture用于刺激实际导航/取消/双向转向，不能作为生产探索fallback。

以一个新clean且已push冻结依次跑interface32、terminal两轮、双worker八轮32步reset、300KEEP deadline，并逐阶段核对全部原门、新information v2及peer/control独立审计。发生失败停止该版后续，保留原件、修复后新冻结完整重验；没有同版本盲重试、跨冻结PASS或伪造回执。预算608 API/596脚本动作/18000原生墙秒（1800/1800/6400/8000）保持；这些是准备工程的事前admission与实测门，不是运行时强杀预算。

当前正在实现/离线验证，尚无v10原生结果。完成同冻结矩阵和证据、commit/push后待用户验收P2A.0。PPO训练未重新开始，原生GPU/optimizer=0，无95%学习策略信用；pilot余额1870决策/2905.954739546403墙秒不变，P2B/gateway未开始。
'''
p = w / 'report/20261017_mr3_p2a0_v10.md'
assert not p.exists()
p.write_text(new)

status = ('2026-10-17 continuation: P2A.0 remains authorized. V9 source26534fae4040 failed before task release (0 returned resets/steps): actual producer ledger proves old TF selected before same-clock late fresh TF, then the paused10Hz timer cannot republish. All originals/45 gone identities retained; forced cleanup is not strict closure PASS. V10 implements explicit paused state publication -> actual peer callback/obstacle publication -> actual guard/self-receipt -> three native target-storage receipts -> physics, with separate permanent zero-stop and invalid-startup orderly close. Controlled state cadence is20ms; noncontrolled10Hz and original.5s age/safety/task gates unchanged. New clean pushed complete matrix required. No pilot/P2B/gateway; balance1870 decisions/2905.954739546403 wallsec unchanged. See wireless-rl/report/20261017_mr3_p2a0_v10.md. User acceptance follows completion.')
for p in (root/'AGENTS.md', ros/'AGENTS.md', w/'AGENTS.md'):
    lines=p.read_text().splitlines()
    indices=[i for i,line in enumerate(lines) if line.startswith('2026-10-17 continuation:')]
    assert len(indices)==1
    lines[indices[0]]=status
    p.write_text('\n'.join(lines)+'\n')

for p in (w/'RESEARCH_PLAN.md', w/'IMPLEMENTATION_PLAN.md'):
    s=p.read_text()
    s=s.replace('v9修producer future-latest缓存缺陷并补真实选取账本，再以新冻结完整重验；该缺陷为本次原生具体根因尚未证实。', 'v9缓存修复后启动仍FAIL，真实ledger证实定时旧TF先选、新TF同clock晚到而暂停饥饿；v10显式因果阶段、独立zero-stop及启动invalid有序关闭后以新冻结完整重验。')
    s=s.replace('v8接口PASS、terminal FAIL，v9须同冻结重验', 'v9启动FAIL保留，v10显式阶段实现后须同冻结完整重验')
    s=s.replace('[v9计划/报告](report/20261017_mr3_p2a0_v9.md)', '[v10计划/报告](report/20261017_mr3_p2a0_v10.md)')
    s=s.replace('原.5源龄/.1发布周期与全部任务/安全门保持，再以新冻结整套重验。', 'v9真实原件现证定时callback顺序及暂停饥饿；v10以暂停期间显式20ms状态→障碍→guard→storage阶段接管stepped，非受控原10Hz及原.5源龄与全部任务/安全门保持，以新冻结整套重验。')
    p.write_text(s)

p=ros/'user_guide.md';s=p.read_text()
s=s.replace('v9修producer future-latest odom覆盖缓存导致跳过发送的缺陷，补真实入站/选取独立诊断；不改源龄门、发布周期或策略输入，再以新冻结完整重验，见[v9报告](../../ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/20261017_mr3_p2a0_v9.md)。', 'v9启动仍FAIL，真实producer账本证实旧TF先选、新TF同clock晚到而暂停后无法再次定时发布。v10改为暂停期间显式20ms状态→实际peer障碍→guard回收→三台storage→物理阶段，独立zero-stop不覆正常回执，并补启动失败有序关闭；非受控10Hz、源龄门及策略输入保持。新冻结完整重验中，见[v10报告](../../ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/20261017_mr3_p2a0_v10.md)。')
p.write_text(s)

p=w/'MR3_ENV_CONTRACT.md';s=p.read_text();s=s.replace('状态发布仍`.1s`、源龄门仍`.5s`', '非受控状态发布仍`.1s`、源龄门仍`.5s`')
s+='''

## P2A.0 v10 显式受控执行阶段（待同冻结原生验证）

在`mr3_stepped=true`时，启动实际旧零输出/三存储ACK后接管timer，再真实推进20ticks到新clock；每一物理边界暂停，完成state_phase→peer_phase→motion control→三台driver存储→evaluator相位后再推进。三阶段共用epoch/request_id/target_time_ns且成功normal必须clock完全相等。状态节点取消周期state发布，选择自身实际causal入站、真实发布bundle及side消息；受控有效状态节拍改为50Hz，warmup/非stepped原10Hz保持。peer必须实际收到匹配SHA、sequence和publication开始后callback的六side及main bundle，才能真实发布障碍并ACK；guard必须实际收到两份ACK及main bundle、own causal输入，唯一正常输出并回收后ACK。墙超时10秒使本轮invalid，不推进仿真/修改源时间。诊断引用、raw ingress与协议ACK不进入actor/奖励。

normal回执同clock不可覆；独立`phase_kind=stop`只能永久三零、ready=false，可在相同clock用更高seq，单独`/motion_safety/stop_status`及控制ACK，不授几何/缺输入安全信用。终止或取消需真实通知，随后每次20ticks关闭推进仍等真实零存储。真实terminal可取消pending state commit；仅排空可复用最后真实水位原引用且保留源时间，不能再发布新state或LIVE推进。未返回reset的基础设施失败以隔离abort begin→真实cancel/zero/Nav2/helper/navigation_closed→finalize→原有序native关闭，不产生reward/伪造transition；正常sealed评价器规则不变。新的peer/control/information独立原件审计与所有旧任务/物理门均必需，详见[本版报告](report/20261017_mr3_p2a0_v10.md)。
'''
p.write_text(s)

p=ros/'launch_commands.md';s=p.read_text()
# Only the active v9 block is superseded. Historical commands/results stay in dated reports.
start=s.index('## MR3-P2A.0 v9 当前训练前工程准备')
end=s.find('\n## ',start+4)
if end<0:end=len(s)
block=s[start:end].replace('v9','v10').replace('V9','V10')
block=block.replace('共八份精确独立回执，terminal五份、reset八份、deadline五份', '并新增peer/control精确独立回执；准确清单以本版预声明为准')
block+='\n受控stepped在暂停中以state_phase→peer_phase→motion control→三台storage显式提交，状态有效50Hz；非受控10Hz保持。独立zero-stop同clock更高序号仅三零、不覆normal ACK；启动invalid也走实际cancel/Nav2/native有序关闭。所有原源龄/任务/机体安全门不变。\n'
s=s[:start]+block+s[end:];p.write_text(s)

p=w/'report/README.md';s=p.read_text();line='| [20261017_mr3_p2a0_v9.md](20261017_mr3_p2a0_v9.md) | 因果odom缓存与真实信息选取诊断 | 修复中，须新冻结完整矩阵，无训练信用 |'
assert line in s
s=s.replace(line, '| [20261017_mr3_p2a0_v10.md](20261017_mr3_p2a0_v10.md) | 显式因果执行阶段及启动关闭 | 实现/验证中，须同冻结完整矩阵，无训练信用 |\n| [20261017_mr3_p2a0_v9.md](20261017_mr3_p2a0_v9.md) | 因果odom缓存与真实信息选取诊断 | 启动0步FAIL，后续SKIP，forced清理无严格关闭信用 |')
p.write_text(s)

p=w/'report/ARCHIVE_INDEX.json';d=json.loads(p.read_text())
d['clarifications'].append({'recorded_date':'2026-10-17','review_base_commit':'26534fae40409e266376baf0995fb15dc0223e4b','report':str((w/'report/20261017_mr3_p2a0_v10.md').relative_to(root)), 'affected_reports':[str((w/'report/20261017_mr3_p2a0_v9.md').relative_to(root))], 'scope':'V9 failed before reset release; actual producer ledger proves timer/callback paused starvation, not loss of retained future odometry. All originals and forced-cleanup limitations retained. V10 explicit paused causal phases and startup infrastructure abort are a new execution version requiring a full new clean pushed freeze matrix; no legacy PASS or pilot budget reset.'})
p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')

p=w/'log.md'
with p.open('a') as f:
    f.write('''

### 2026-10-17 MR3-P2A.0 v9 原生启动失败闭合

- 源冻结26534fae40409e266376baf0995fb15dc0223e4b；clean+pushed preflight命令`python report/assets/20261017_mr3_p2a0_v9/independent/mr3_p2a0_v9_buildproof_preflight.py`，cwd本wireless-rl，conda ns3gym/unset PYTHONPATH/PYTHONNOUSERSITE=1，97 runtime/33 independent源及实际d0d驱动库匹配PASS。原`/tmp/mr3_p2a0_v9_source_preflight.json` SHA545844e18f8ceb61c741e84c6af9f17f49fb2ad29f01acd43687609579d04ee1已归档。
- 原生`python report/assets/20261017_mr3_p2a0_v9/independent/mr3_p2a0_v9_launch_stage.py interface 26534fae40409e266376baf0995fb15dc0223e4b`；精确benchmark argv/domain100/port12901/环境与PID原件见A9/accounting/mr3_p2a0_v9_interface_launch.json。07:28:33.084717–07:30:53.148215 UTC，140.06299758609384墙秒/exit1，0返回reset、0step、0任务秒。真实initial paused motion not ready错误；本版terminal/reset/deadline均SKIP，不盲重试。
- 初始74.323暂停加17×1ms到74.340，tb2 received source73.795/age545ms>500，own均fresh。producer716实际pub先选TFref5173，freshTFref5176同74.320晚9.363墙毫秒入站；暂停导致下一10Hzpub不触发。新ledger直接证明timer/order starvation。futureodom保留正常；没有队列overflow/conflict。全部原.5源龄/物理门保持。
- 正式full/input/driver/information审计均FAIL缺reset/summary；isolated来源诊断4780odom（3588future）/16101TF/716pub/716motionreceived/11061decision replay provenance通过但overallFalse。执行`python /tmp/mr3_p2a0_v9_root_audit_runner_diagnostic_v2.py interface`，fullaudit exit1/5.867655317764729墙秒、旧不可变driveV4 exit1/.22970817796885967墙秒；准确CLI/console/SHA在A9独立原件。45实际saved身份均消失；forcedcleanup=true，仅4正常spawn/ready退出，无完整native_stop/Nav2final，严格关闭不可PASS。
- 原生pack `/usr/bin/python3 /tmp/mr3_p2a0_v9_pack_native_v1.py interface`及归档`/usr/bin/python3 /tmp/archive_mr3_p2a0_v9_closed_v1.py` exit0：165文件131198920原字节→7508070无损选择，97Git源、137prefreeze assets、54独立原件核验；manifest SHA4401e4570e7a130b9fc1b5df6e1bfb2a8fba302dfc50b111b9a269ab2c67f3d1；inventory_native_v1 SHAf357ba0945a2411225ef9c8e0588aeed2ac3d8b8668b3db875fb8624a279dfb4。所有失败原件保留，后续v10显式阶段与startup invalid有序关闭。原生GPU/optimizer=0，pilot余额1870/2905.954739546403保持。
''')

print('v9 closure and v10 active documents written; source pins still pending final code')
