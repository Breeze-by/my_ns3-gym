"""Preserve closed native execution/provenance originals, keeping its FAIL."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path('/home/zhuyulab/ns3-workspace')
DEST = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v18/closed_fixed_v1'
TMP = Path('/tmp')
files = set()
for pattern in ('mr3_p2a0_v18_source_preflight.json', 'source_bindings_85abe3916ab1.*',
                'mr3_p2a0_v18_pair_*', 'mr3_p2a0_v18_baseline_*',
                'mr3_p2a0_v18_closed_summary_v*', 'mr3_p2a0_v18_native_custody_summary_v1.json',
                'mr3_p2a0_v18_pack_closed_baseline*', 'mr3_p2a0_v18_run_pack_closed_baseline_v1.py',
                'mr3_p2a0_v18_pack_closed_support_v1.py'):
    files.update(path for path in TMP.glob(pattern) if path.is_file())
assert files
sha = lambda raw: hashlib.sha256(raw).hexdigest()
buffer = io.BytesIO()
entries = []
with tarfile.open(fileobj=buffer, mode='w', format=tarfile.PAX_FORMAT) as archive:
    for path in sorted(files):
        before = path.stat()
        raw = path.read_bytes()
        after = path.stat()
        assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (
            after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), str(path)
        info = tarfile.TarInfo(path.name)
        info.size = len(raw)
        info.mode = 0o644
        archive.addfile(info, io.BytesIO(raw))
        entries.append({'source': str(path), 'member': path.name, 'bytes': len(raw), 'sha256': sha(raw)})
tar_raw = buffer.getvalue()
encoded = gzip.compress(tar_raw, mtime=0)
assert gzip.decompress(encoded) == tar_raw
with tarfile.open(fileobj=io.BytesIO(tar_raw)) as archive:
    for entry in entries:
        assert sha(archive.extractfile(entry['member']).read()) == entry['sha256']
        assert sha(Path(entry['source']).read_bytes()) == entry['sha256']
native = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v18/native/baseline/manifest.json'
manifest = json.loads(native.read_bytes())
DEST.mkdir(exist_ok=False)
(DEST / 'originals.tar.gz').write_bytes(encoded)
value = {'schema': 'mr3-closed-fixed-facts-custody-v1', 'passed': True,
    'freeze': '85abe3916ab1582b68d7b3c3c0b96ea7fd68f6f1', 'entries': entries,
    'archive': str((DEST / 'originals.tar.gz').relative_to(ROOT)), 'encoded_sha256': sha(encoded),
    'encoded_bytes': len(encoded), 'tar_sha256': sha(tar_raw),
    'native_manifest': str(native.relative_to(ROOT)), 'native_manifest_sha256': sha(native.read_bytes()),
    'scope': 'Lossless custody only; original V18 FAIL and both SKIPs unchanged. '
             'No source changes during native/formal execution; extra closed-data analysis is pending separately.'}
(DEST / 'manifest.json').write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps({'passed': True, 'originals': len(entries), 'encoded_bytes': len(encoded),
                  'native_manifest_sha256': value['native_manifest_sha256']}))
