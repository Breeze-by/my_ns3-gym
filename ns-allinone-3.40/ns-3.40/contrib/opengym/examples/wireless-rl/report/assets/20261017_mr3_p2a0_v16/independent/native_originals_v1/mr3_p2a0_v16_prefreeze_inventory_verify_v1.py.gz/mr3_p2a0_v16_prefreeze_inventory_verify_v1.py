"""Verify the final V16 source, original custody, links and staging allowlist."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote

R = Path('/home/zhuyulab/ns3-workspace')
WP = 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
RP = 'ros2_ws/ros2-multi-robot-automap'
W = R / WP
A = W / 'report/assets/20261017_mr3_p2a0_v16'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
review_path = Path('/tmp/mr3_p2a0_v16_final_plan_source_independent_v2.json')
review = json.loads(review_path.read_bytes())
assert review['passed'] is True and review['bindings']['old'] == 121 and review['bindings']['unchanged'] == 117 and review['bindings']['new'] == 13
for path, digest in review['all_observed_source_hashes_before_after'].items():
    assert sha(Path(path).read_bytes()) == digest, path
plan = json.loads((A / 'predeclared_plan_v16.json').read_bytes())
assert plan['readiness']['status'] == 'ready' and not plan['readiness']['pending_bindings']
assert not plan['new_source_bindings_pending']
assert review['plan']['sha256'] == sha((A / 'predeclared_plan_v16.json').read_bytes())
receipt = plan['drive_contract']['binary_build_receipt']
raw = (R / receipt['path']).read_bytes()
assert sha(raw) == receipt['sha256']
build = json.loads(raw)
library = Path(build['library_path']).read_bytes()
assert sha(library) == 'a014f2c618e38fc8a306d76c100083d952606333045a2e35bffce6f8b25b10c8' == build['library_sha256']
assert Path(build['installed_path']).read_bytes() == library
assert gzip.decompress((R / build['archived_library_gzip']).read_bytes()) == library
for key in ('compiled_source_sha256', 'compiled_header_sha256', 'compiled_helper_sha256', 'compiled_target_contract_sha256'):
    assert build[key].encode() in library
main = json.loads((A / 'independent/offline_originals_v1/manifest.json').read_bytes())
for row in main['entries']:
    encoded = (R / row['selected']).read_bytes()
    assert sha(encoded) == row['encoded_sha256'] and len(encoded) == row['encoded_bytes']
    raw = gzip.decompress(encoded)
    assert len(raw) == row['raw_bytes'] and sha(raw) == row['raw_sha256']
    assert row['encoding'] == 'gzip'
for row in main['deduplicated_prior']:
    ref = row['already_canonical']
    assert sha(Path(ref['manifest']).read_bytes()) == ref['manifest_sha256']
    encoded = Path(ref['selected']).read_bytes()
    assert sha(encoded) == ref['selected_encoded_sha256']
    assert ref['encoding'] in ('gzip', 'identity')
    raw = gzip.decompress(encoded) if ref['encoding'] == 'gzip' else encoded
    assert sha(raw) == row['raw_sha256'] == ref['raw_sha256']
allowed = {'AGENTS.md', *[WP + '/' + x for x in (
    'AGENTS.md', 'IMPLEMENTATION_PLAN.md', 'RESEARCH_PLAN.md', 'MR3_ENV_CONTRACT.md', 'log.md',
    'mr3_learning/audit_ppo.py', 'mr3_learning/audit_preparation.py', 'mr3_learning/benchmark.py',
    'mr3_learning/tests/test_preparation_comparison.py',
    'mr3_learning/tests/test_benchmark_stimulus_v5.py',
    'report/README.md', 'report/ARCHIVE_INDEX.json', 'report/20261017_mr3_p2a0_v16.md')],
    *[RP + '/' + x for x in ('AGENTS.md', 'user_guide.md', 'launch_commands.md')]}
links = []
for path in sorted(allowed):
    if not path.endswith('.md'):
        continue
    for target in re.findall(r'\]\(([^)]+)\)', (R / path).read_text()):
        if target.startswith(('http:', 'https:', '#', 'app:', 'plugin:', 'mailto:')):
            continue
        local = unquote(target.split('#', 1)[0])
        assert ((R / path).parent / local).exists(), (path, target)
        links.append([path, target])
files = []
for path in sorted(A.rglob('*')):
    assert not path.is_symlink(), path
    if not path.is_file() or '__pycache__' in path.parts or path.suffix == '.pyc':
        continue
    raw = path.read_bytes()
    assert not raw.startswith(b'\x7fELF'), path
    row = dict(path=str(path.relative_to(A)), bytes=len(raw), sha256=sha(raw))
    if raw.startswith(b'\x1f\x8b'):
        decoded = gzip.decompress(raw)
        assert not decoded.startswith(b'\x7fELF'), path
        row.update(decoded_bytes=len(decoded), decoded_sha256=sha(decoded))
    files.append(row)
inventory = A / 'inventory_prefreeze_v1.json'
assert not inventory.exists()
inventory.write_text(json.dumps(dict(self_excluded=True, exclude_python_cache=True, files=files), indent=2) + '\n')
dry = subprocess.check_output(['git', 'add', '-n', '.'], cwd=R)
Path('/tmp/mr3_p2a0_v16_git_add_dryrun_prefreeze_v1.log').write_bytes(dry)
paths = [re.fullmatch("add '(.*)'", line).group(1) for line in dry.decode().splitlines()]
asset_paths = {str((A / row['path']).relative_to(R)) for row in files} | {str(inventory.relative_to(R))}
assert not set(paths) - (allowed | asset_paths), sorted(set(paths) - (allowed | asset_paths))
subprocess.run(['git', 'diff', '--check'], cwd=R, check=True)
result = dict(passed=True, source_review_sha256=sha(review_path.read_bytes()),
              source_before_after_still_current=True, runtime_source_paths=101,
              independent_bindings=134, pins=36, library_sha256=sha(library),
              main_originals_checked=len(main['entries']), late_originals_checked=0,
              old_custody_raw_refs_checked=len(main['deduplicated_prior']),
              prefreeze_assets=len(files), inventory_sha256=sha(inventory.read_bytes()),
              links=len(links), dryrun_paths=len(paths), allowed_non_asset_paths=sorted(allowed),
              dryrun_sha256=sha(dry), script_sha256=sha(Path(__file__).read_bytes()),
              scope='Static source/binary/custody/staging only; no native experiment.')
output = Path('/tmp/mr3_p2a0_v16_prefreeze_inventory_review_v1.json')
with output.open('x') as stream:
    stream.write(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ('passed', 'prefreeze_assets', 'inventory_sha256', 'links', 'dryrun_paths')}))
