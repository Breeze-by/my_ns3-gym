"""Finite recorded-pair geometry and fixed-version Shim branch semantics only."""
import hashlib
import json
import math
from pathlib import Path

BASE = Path('/tmp/mr3_p2a0_v15_interface_first_phase_v1')
OUT = Path('/tmp/mr3_p2a0_v15_first_phase_geometry_math_v1.json')


def maximum_projection(dx, dy, heading, half_angle):
    bearing = math.atan2(dy, dx)
    difference = math.atan2(math.sin(bearing - heading), math.cos(bearing - heading))
    distance = math.hypot(dx, dy)
    if half_angle >= math.pi or abs(difference) <= half_angle:
        return distance
    return max(dx * math.cos(heading - half_angle) + dy * math.sin(heading - half_angle),
               dx * math.cos(heading + half_angle) + dy * math.sin(heading + half_angle))


def main():
    source = BASE / 'selected_original_motion_rows.jsonl'
    raw = source.read_bytes()
    review = json.loads((BASE / 'review.json').read_bytes())
    release = review['release_ns']
    goal = review['initial_goal']
    examined = []
    replayed = 0
    for line in raw.splitlines():
        record = json.loads(line)
        row = record['row']
        if row['kind'] != 'decision':
            continue
        value = row['payload']
        own, peers = value['own_state'], value['received_peers']
        decision = value['decision']
        if decision.get('component_filter') is not None:
            decision = decision['component_filter']['rejected_mixed_decision']
        checks = decision.get('near_peer_checks', [])
        for check in checks:
            peer = peers[check['peer']]
            dx, dy = peer['x'] - own['x'], peer['y'] - own['y']
            for direction in check['direction_checks']:
                heading = own['yaw'] + (math.pi if direction['sign'] < 0 else 0.)
                projection = maximum_projection(dx, dy, heading, direction['heading_half_angle_rad'])
                assert projection == direction['maximum_projection_m']
                assert -projection - check['source_uncertainty_m'] == direction['nonclosing_margin_m']
                replayed += 1
        elapsed = (value['clock_ns'] - release) / 1e9
        if elapsed not in (0., 2.42, 4., 6., 9., 10.):
            continue
        peer = peers['tb3']
        dx, dy = peer['x'] - own['x'], peer['y'] - own['y']
        heading = math.atan2(goal['y'] - own['y'], goal['x'] - own['x'])
        signed_projection = dx * math.cos(heading) + dy * math.sin(heading)
        pair = next((item for item in checks if item['peer'] == 'tb3'), None)
        bound = pair['direction_checks'][0] if pair and pair['direction_checks'] else None
        examined.append({'task_elapsed_sec': elapsed, 'tb1_xy': [own['x'], own['y']],
                         'tb3_received_xy': [peer['x'], peer['y']],
                         'tb3_source_stamp': peer['source_stamp'], 'yaw_rad': own['yaw'],
                         'direct_goal_bearing_rad': heading,
                         'direct_goal_error_rad': math.atan2(math.sin(heading - own['yaw']),
                                                             math.cos(heading - own['yaw'])),
                         'direct_goal_projection_toward_peer_m': signed_projection,
                         'direct_goal_normalized_straightaway_margin':
                         -signed_projection / math.hypot(dx, dy),
                         'actual_pair_gate': pair,
                         'direct_goal_heading_same_recorded_cone_margin_m':
                         (-maximum_projection(dx, dy, heading, bound['heading_half_angle_rad'])
                          - pair['source_uncertainty_m']) if bound else None,
                         'counterfactual_scope': 'Finite same-pair angle calculation only; '
                         'not a valid changed-trajectory or future-plant simulation.'})
    # Exact branch predicate from official 1.1.20: abs(angle)>selected threshold.
    examples = []
    for angle in (.5, math.nextafter(.5, math.inf), .45, .1,
                  math.nextafter(.1, math.inf), .03):
        examples.append({'sampled_path_angle_abs': angle,
                         'rotation_with_.5': angle > .5,
                         'rotation_with_.1': angle > .1})
    assert examples[0]['rotation_with_.5'] is False
    assert examples[1]['rotation_with_.5'] is True
    assert examples[3]['rotation_with_.1'] is False
    assert examples[4]['rotation_with_.1'] is True
    result = {'schema': 'mr3-v15-first-phase-geometry-math-v1',
              'source': {'path': str(source), 'bytes': len(raw),
                         'sha256': hashlib.sha256(raw).hexdigest()},
              'recorded_direction_checks_recomputed_exactly': replayed,
              'finite_recorded_examples': examined, 'shim_predicate_CPU_examples': examples,
              'proven': [
                  'All original first-phase forward commands were blocked by peer geometry; '
                  'nonzero angular components often remained in real output.',
                  'By t4, direct-goal error<.1; by t6 it is about-.0039. The persistent '
                  'first-phase stall is not explained by remaining .45rad misalignment.',
                  'The initial normalized straightaway margin is positive, but at t9 the '
                  'same goal vector has positive projection toward the now-moved received tb3.',
                  'Official Shim uses a sampled point along current_path at distance>=.3m '
                  'from path start, not necessarily the final goal direction. .5 startup '
                  'values were actually read back in all three native controller nodes.'],
              'not_proven': [
                  'Native Shim sampled path heading and exact branch were not recorded in '
                  'the inspected INFO/WARN launch log; first-forward .518rad direct-goal '
                  'error therefore does not contradict the .5 sampled-path threshold.',
                  '.1/.1 would change the earlier native trajectory or release translation. '
                  'The old original-pair math is not changed-trajectory native evidence.',
                  'Any source-age uncertainty, turn model or body gate is erroneous.'],
              'parameter_hypothesis': {
                  'change_only': ['FollowPath.angular_dist_threshold:.5->.1',
                                  'FollowPath.angular_disengage_threshold:.5->.1'],
                  'reason': 'Tighter pure-turn handoff alignment can be tested prospectively; '
                            'it does not by itself address dynamic peer geometry that still '
                            'blocks forward motion after real direct-goal alignment.',
                  'status': 'Not recommended as a claimed sufficient stall repair; no source applied.',
                  'startup_semantics': 'Set both in actual three YAML profiles and rebuild/install '
                                      'before native. The official dynamic callback does not '
                                      'handle angular_disengage_threshold, so do not rely on '
                                      'successful runtime SetParameters to prove the cached value.',
                  'would_require_versioned_updates': [
                      'Three actual params/nav2_params_tbN_0.yaml only; generic DWB-only '
                      'config need not acquire Shim keys.',
                      'A new versioned actual-nav2 parameter reader/profile + its typed '
                      'fixtures, preserving all other39 controller parameters and other9-node '
                      'limits; old A13 reader/receipts immutable.',
                      'Benchmark selected new readback reader source + environment/profile '
                      'expectation, exact source pins and predeclared new same-freeze matrix.',
                      'Source/installed YAML binding and native GetParameters for all three '
                      'controller threshold pairs; same actual Shim mapped ELF/header/XML proof.',
                      'CPU strict threshold boundary and nonidentity sampled-path-vs-goal '
                      'semantics examples; all unchanged body/angular/settled/latency/geometry '
                      'gates and meaningful stopping/activity requirements remain mandatory.']},
              'scope': 'No production imports, native/formal execution, ModelStates or Git writes. '
                       'CPU finite geometry is a diagnostic, not proof of continuous safety or '
                       'a prospective parameter change succeeding.'}
    assert hashlib.sha256(source.read_bytes()).hexdigest() == result['source']['sha256']
    with OUT.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'output': str(OUT), 'sha256': hashlib.sha256(OUT.read_bytes()).hexdigest(),
                      'exact_direction_replays': replayed,
                      'examples': [{'t': row['task_elapsed_sec'],
                                    'straightaway': row['direct_goal_normalized_straightaway_margin'],
                                    'direct_error': row['direct_goal_error_rad'],
                                    'same_cone_margin': row['direct_goal_heading_same_recorded_cone_margin_m']}
                                   for row in examined]}))


if __name__ == '__main__':
    main()
