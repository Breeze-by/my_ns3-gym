#!/usr/bin/python3
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

D = Path(__file__).parent


def bound(path):
    def ident(s):
        return [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns]
    s = path.stat()
    raw = path.read_bytes()
    assert ident(s) == ident(path.stat())
    return raw, {'source': str(path), 'name': path.name, 'bytes': len(raw),
                 'sha256': hashlib.sha256(raw).hexdigest(), 'stat': ident(s)}


def main():
    files = sorted(D.iterdir())
    assert all(p.is_file() and not p.is_symlink() for p in files)
    assert not any(p.name in ('originals.tar.gz', 'sealed_manifest_v1.json', 'handoff_v1.json') for p in files)
    captured = [bound(p) for p in files]
    archive = D / 'originals.tar.gz'
    with archive.open('xb') as out, gzip.GzipFile(filename='', mode='wb', fileobj=out, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w|') as tar:
            for raw, row in captured:
                item = tarfile.TarInfo(row['name'])
                item.size = len(raw)
                item.mtime = 0
                item.mode = 0o644
                tar.addfile(item, io.BytesIO(raw))
    with tarfile.open(archive, mode='r:gz') as tar:
        assert len(tar.getmembers()) == len(captured)
        for raw, row in captured:
            decoded = tar.extractfile(row['name']).read()
            assert decoded == raw and hashlib.sha256(decoded).hexdigest() == row['sha256']
    assert [r for raw,r in captured] == [bound(p)[1] for p in files]
    manifest = {'schema': 'mr3-v24-body-forensics-support-custody-v1', 'passed': True,
                'scope': 'Lossless custody of descriptive small leaves/bounded bytes/primary SDK and raw-vs-guard analysis; original whole V24 FAIL retained.',
                'files': [r for raw,r in captured], 'source_files': len(captured),
                'raw_bytes': sum(len(raw) for raw,row in captured), 'archive': bound(archive)[1],
                'full_member_roundtrip_verified': True, 'source_end_bytes_and_stat_stable': True,
                'exclusions': ['Original large motion/drive/physics/CDR not reread or duplicated; full originals are in root-authorized selected_closed_v1 pack.',
                               'CI15files and RTclosure archived separately, linked by exact source hashes.',
                               'No ELF/buildcache/CPU binary/symlink/Git artifact.'],
                'all_writers_stopped': True}
    (D / 'sealed_manifest_v1.json').write_text(json.dumps(manifest, indent=2) + '\n')
    handoff = {'schema': 'mr3-v24-body-forensic-independent-handoff-v1', 'writers_stopped': True,
               'directory': str(D), 'manifest': bound(D / 'sealed_manifest_v1.json')[1],
               'archive': bound(archive)[1], 'source_files': len(captured),
               'core_reports': {n: bound(D/n)[1] for n in ('body_formal_review_v1.json', 'body_drive_context_review_v1.json', 'raw_guard_smoother_review_v2.json', 'review_summary_zh.md')},
               'pack_support': '/tmp/mr3_p2a0_v24_closed_pack_support_v1/handoff_v1.json',
               'actual_V24_verdict': 'FAIL preserved; no new formal/native or corrected-physics PASS supplied',
               'source_write': False, 'native_or_tests': False}
    (D / 'handoff_v1.json').write_text(json.dumps(handoff, indent=2) + '\n')
    print(json.dumps({'handoff': bound(D / 'handoff_v1.json')[1],
                      'manifest': bound(D / 'sealed_manifest_v1.json')[1],
                      'archive': bound(archive)[1], 'source_files': len(captured)}))

if __name__ == '__main__':
    main()
