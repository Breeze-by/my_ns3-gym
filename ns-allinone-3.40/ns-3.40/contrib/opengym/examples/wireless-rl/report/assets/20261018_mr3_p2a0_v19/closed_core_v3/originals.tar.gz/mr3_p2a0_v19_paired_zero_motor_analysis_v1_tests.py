"""Synthetic-only tests; no V19 data, ROS, native or formal audit invocation."""
import ast
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest

SOURCE = Path('/tmp/mr3_p2a0_v19_paired_zero_motor_analysis_v1.py')
SPEC = importlib.util.spec_from_file_location('paired_description', SOURCE)
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)


def capture(robot='tb1', epoch='synthetic', last=800):
    result = [{'schema': M.SCHEMA, 'epoch': epoch, 'robot': robot, 'kind': 'configuration',
               'compiled_source_sha256': M.COMPILED_SHA, 'record_sequence': 1,
               'world_iterations': 0, 'sim_time_ns': 0, 'measurements_finite': True}]
    for tick in range(last + 1):
        for phase in (M.PRE, M.POST):
            position = [tick * .001 + (.001 if phase == M.POST else 0), 0.0, 0.0]
            pose = {'position_xyz': position}
            values = {'schema': M.SCHEMA, 'epoch': epoch, 'robot': robot,
                      'kind': 'sample', 'phase': phase, 'record_sequence': len(result) + 1,
                      'sim_time_ns': tick * M.TICK_NS, 'world_iterations': tick,
                      'pair_iterations': tick, 'pair_sequence': tick + 1,
                      'before_clock_ns': tick * M.TICK_NS,
                      'before_record_sequence': 2 + 2 * tick,
                      'measurements_finite': True, 'physics_enabled': True,
                      'model': {'name': robot, 'world_pose': pose,
                                'world_linear_velocity_xyz': [1.0, 0.0, 0.0]},
                      'joints_right_left': [
                          {'name': robot + '::wheel_' + side + '_joint',
                           'motor_velocity_target_radps': 0.0,
                           'velocity_radps': value}
                          for side, value in (('right', 2.0), ('left', -3.0))]}
            for key, scoped in (('canonical', 'base_footprint'), ('base', 'base_link')):
                values[key] = {'name': robot + '::' + scoped,
                               'world_pose': pose, 'world_cog_pose': pose,
                               'world_origin_linear_velocity_xyz': [1.0, 0.0, 0.0],
                               'world_cog_linear_velocity_xyz': [1.0, 0.0, 0.0]}
            result.append(values)
    return result


class PairedDescriptionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='mr3_v19_pair_cpu_')
        self.path = Path(self.temp.name) / 'physics_tb1.jsonl'

    def tearDown(self):
        self.temp.cleanup()

    def write(self, rows):
        raw = b''.join((json.dumps(row, allow_nan=True) + '\n').encode() for row in rows)
        self.path.write_bytes(raw)
        return {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}

    def analyze(self, rows, start=0, end=800_000_000, **kwargs):
        expected = self.write(rows)
        return M.analyze_file(self.path, expected, 'tb1', 'synthetic', start, end, **kwargs)

    def test_immutable_interface_and_historical_shape(self):
        raw = M.FORMAL_CONSUMER.read_bytes()
        self.assertEqual(hashlib.sha256(raw).hexdigest(), M.FORMAL_SHA)
        constants = {}
        for node in ast.parse(raw).body:
            if isinstance(node, ast.Assign) and len(node.targets) == 1:
                target = node.targets[0]
                if isinstance(target, ast.Name) and target.id in ('PRE', 'POST', 'SCHEMA'):
                    constants[target.id] = ast.literal_eval(node.value)
        self.assertEqual(constants, {'PRE': M.PRE, 'POST': M.POST, 'SCHEMA': M.SCHEMA})
        historical = Path('/tmp/mr3_p2a0_v18_closed_observer_diagnostic_v1')
        for name in ('tb1_pre_fixed_link_velocity_residual.jsonl',
                     'tb1_zero_motor_model_planar_speed.jsonl'):
            rows = historical.joinpath(name).read_text().splitlines()
            self.assertEqual(len(rows), 1)
            values, wheels = M.extracted(json.loads(rows[0]), 'tb1')
            self.assertEqual(set(values), {'model', 'canonical_origin', 'canonical_cog',
                                           'base_origin', 'base_cog'})
            self.assertEqual(len(wheels), 2)

    def test_exact_780ms_boundary_and_symmetric_statistics(self):
        result = self.analyze(capture())
        self.assertEqual(result['task_pairs'], 801)
        self.assertEqual(result['late_zero_pairs'], 21)
        self.assertEqual(result['all_late_zero_streaks'][0]['first_late_ns'], 780_000_000)
        stats = result['late_zero_vectors']['model.both_phases_getter_velocity']
        self.assertEqual(stats['planar_norm']['count'], 42)
        self.assertEqual(stats['planar_norm']['mean'], 1.0)
        self.assertEqual(stats['planar_norm']['rms'], 1.0)
        wheels = result['late_zero_actual_wheel_velocity_radps']
        self.assertEqual(wheels['pre.right']['mean'], 2.0)
        self.assertEqual(wheels['post.left']['mean'], -3.0)

    def test_779ms_does_not_qualify(self):
        result = self.analyze(capture(last=779), end=779_000_000)
        self.assertEqual(result['late_zero_pairs'], 0)
        self.assertEqual(result['all_late_zero_streaks'], [])

    def test_carryin_zero_resets_at_task_release(self):
        result = self.analyze(capture(last=900), start=100_000_000, end=900_000_000)
        self.assertEqual(result['late_zero_pairs'], 21)
        streak = result['all_late_zero_streaks'][0]
        self.assertEqual(streak['start_ns'], 100_000_000)
        self.assertEqual(streak['first_late_ns'], 880_000_000)
        self.assertTrue(streak['carryin_before_task_release_not_counted'])

    def test_broken_zero_and_pre_post_disagreement_reset_history(self):
        rows = capture()
        # At790ms only post changes, so the pair is excluded rather than averaged.
        rows[2 + 2 * 790]['joints_right_left'][0]['motor_velocity_target_radps'] = 1.0
        result = self.analyze(rows)
        self.assertEqual(result['late_zero_pairs'], 10)
        self.assertEqual(result['pre_post_zero_status_differs_pairs'], 1)
        self.assertEqual(len(result['all_zero_streaks']), 2)
        self.assertEqual(result['all_zero_streaks'][1]['late_pair_count'], 0)

    def test_task_end_clips_capture_without_selecting_later_samples(self):
        result = self.analyze(capture(), end=780_000_000)
        self.assertEqual(result['late_zero_pairs'], 1)
        self.assertEqual(result['all_zero_streaks'][0]['end_ns'], 780_000_000)

    def test_missing_pair_and_wrong_pair_reference_rejected(self):
        for mutate in ('missing_post', 'wrong_clock', 'wrong_reference'):
            rows = capture(last=2)
            if mutate == 'missing_post':
                rows.pop()
            elif mutate == 'wrong_clock':
                rows[2]['sim_time_ns'] = 1
            else:
                rows[2]['before_record_sequence'] += 1
            with self.subTest(mutate=mutate), self.assertRaises(ValueError):
                self.analyze(rows, end=2_000_000)

    def test_missing_task_tail_rejected(self):
        with self.assertRaisesRegex(ValueError, 'task_interval_incomplete'):
            self.analyze(capture(last=779), end=780_000_000)

    def test_nan_unknown_and_typed_motor_values_rejected(self):
        for mutate in ('nan', 'unknown_phase', 'unknown_compiled', 'null_vector', 'bool_motor'):
            rows = capture(last=2)
            if mutate == 'nan':
                rows[1]['model']['world_linear_velocity_xyz'][1] = float('nan')
            elif mutate == 'unknown_phase':
                rows[1]['phase'] = 'not-a-known-phase'
            elif mutate == 'unknown_compiled':
                rows[0]['compiled_source_sha256'] = '0' * 64
            elif mutate == 'null_vector':
                rows[1]['model']['world_linear_velocity_xyz'][1] = None
            else:
                rows[1]['joints_right_left'][0]['motor_velocity_target_radps'] = False
            with self.subTest(mutate=mutate), self.assertRaises((ValueError, TypeError)):
                self.analyze(rows, end=2_000_000)

    def test_wrong_sha_and_same_bytes_stat_change_rejected(self):
        rows = capture(last=2)
        expected = self.write(rows)
        with self.assertRaisesRegex(ValueError, 'raw_capture_sha_or_size_changed'):
            M.analyze_file(self.path, {**expected, 'sha256': '0' * 64},
                           'tb1', 'synthetic', 0, 2_000_000)

        def change(line, path):
            if line == 1:
                stat = path.stat()
                os.utime(path, ns=(stat.st_atime_ns, stat.st_mtime_ns + 1000000))
        with self.assertRaisesRegex(ValueError, 'raw_capture_stat_changed'):
            self.analyze(rows, end=2_000_000, progress=change)

    def admission_fixture(self):
        root = Path(self.temp.name)
        plan = root / 'plan.json'
        plan.write_text('{"synthetic_only":true}\n')
        plan_sha = M.sha(plan.read_bytes())
        reports = []
        for stage in ('baseline', 'iters150'):
            episode = root / stage
            episode.mkdir()
            proof_path = episode / 'proof.json'
            proof = {'schema': 'mr3-stop-observer-admission-proof-v1', 'passed': True,
                     'freeze': 'a' * 40, 'plan_sha256': plan_sha, 'stage': stage,
                     'epoch': stage, 'episode_directory': str(episode),
                     'run_directory': str(root / ('run_' + stage)),
                     'observer': {'source_sha256': M.COMPILED_SHA},
                     'observer_files': {
                         robot: {'path': str(episode / ('physics_' + robot + '.jsonl'))}
                         for robot in M.ROBOTS}}
            proof_path.write_text(json.dumps(proof))
            inputs = {str(plan): {'bytes': len(plan.read_bytes()), 'sha256': plan_sha},
                      str(proof_path): {'bytes': len(proof_path.read_bytes()),
                                        'sha256': M.sha(proof_path.read_bytes())}}
            for robot in M.ROBOTS:
                inputs[proof['observer_files'][robot]['path']] = {'bytes': 1, 'sha256': 'f' * 64}
            report = {'schema': 'mr3-independent-stop-observer-review-v1', 'passed': True,
                      'errors': [], 'freeze': 'a' * 40, 'stage': stage,
                      'consumer_sha256': M.FORMAL_SHA, 'plan_path': str(plan),
                      'admission_proof_path': str(proof_path), 'inputs': inputs,
                      'actual_interval': {'start_ns': 0, 'end_ns': 800_000_000,
                                          'returned_step_calls': 32},
                      'robots': [{'robot': robot} for robot in M.ROBOTS]}
            for key in ('epoch', 'run_directory', 'episode_directory'):
                report[key] = proof[key]
            path = episode / 'formal.json'
            path.write_text(json.dumps(report))
            reports.append(path)
        return plan, reports

    def test_both_formal_pass_before_any_raw_is_opened(self):
        plan, reports = self.admission_fixture()
        original = json.loads(reports[1].read_text())
        for mutation, value in (('passed', False), ('passed', 1),
                                ('errors', [{'code': 'failure'}]),
                                ('freeze', 'b' * 40), ('consumer_sha256', '0' * 64)):
            edited = copy.deepcopy(original)
            edited[mutation] = value
            reports[1].write_text(json.dumps(edited))
            with self.subTest(mutation=mutation, value=value), self.assertRaises(ValueError):
                M.analyze(reports, plan, 'a' * 40)
        reports[1].write_text(json.dumps(original))
        contexts = M.prepare(reports, plan, 'a' * 40, {})
        self.assertEqual([row['stage'] for row in contexts], ['baseline', 'iters150'])
        # Positive prepare has no raw files available and must not try opening any.
        self.assertFalse(Path(contexts[0]['raw_files']['tb1']['path']).exists())

    def test_plan_and_admission_binding_mutations_rejected(self):
        plan, reports = self.admission_fixture()
        original = json.loads(reports[0].read_text())
        for mutation in ('plan_sha', 'stage', 'interval_type', 'raw_hash_type'):
            edited = copy.deepcopy(original)
            if mutation == 'plan_sha':
                edited['inputs'][str(plan)]['sha256'] = '0' * 64
            elif mutation == 'stage':
                edited['stage'] = 'unrecognized'
            elif mutation == 'interval_type':
                edited['actual_interval']['returned_step_calls'] = 32.0
            else:
                raw = next(key for key in edited['inputs'] if key.endswith('.jsonl'))
                edited['inputs'][raw]['bytes'] = True
            reports[0].write_text(json.dumps(edited))
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                M.prepare(reports, plan, 'a' * 40, {})


if __name__ == '__main__':
    unittest.main(verbosity=2)
