"""Read-only final source/plan binding checks; no imports of production gates."""
from pathlib import Path
import ast
import hashlib
import json

ROOT = Path('/home/zhuyulab/ns3-workspace')
B = Path(__file__).resolve().parent
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A22 = W / 'report/assets/20261018_mr3_p2a0_v22_ray_box'
A23 = W / 'report/assets/20261018_mr3_p2a0_v23_entry'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
j = json.loads((B / 'predeclared_plan_v23.json').read_bytes())
o = json.loads((A22 / 'predeclared_plan_v22.json').read_bytes())
old = {r['path']: r['sha256'] for r in o['independent_source_bindings']}
new = {r['path']: r['sha256'] for r in j['independent_source_bindings']}
assert len(new) == len(j['independent_source_bindings']) == 198
assert len(old) == 191 and all(new[k] == v for k, v in old.items())
for name, digest in new.items():
    path = ROOT / name
    if A23 in path.parents:
        path = B / 'independent' / path.name
    assert sha(path.read_bytes()) == digest, str(path)
for key in ('max_api_records', 'max_submitted_script_decisions', 'max_total_wall_seconds',
            'unchanged_gates', 'pilot_budget_unchanged', 'physical_response_criteria',
            'angular_interface_criteria', 'angular_reset_criteria', 'drive_contract',
            'external_probe_v6', 'world_solver_candidate', 'production_environment'):
    assert j[key] == o[key], key
assert [len(s['required_audit_receipts']) for s in j['stages']] == [10, 7, 10, 7]
for before, after in zip(o['stages'], j['stages']):
    assert before['wall_ceiling_seconds'] == after['wall_ceiling_seconds']
    assert after['command'][0] == '/home/zhuyulab/miniconda3/envs/ns3gym/bin/python'
assert j['native_admission_granted'] is False
assert j['readiness']['status'] == 'ready' and not j['readiness']['pending_bindings']
assert j['conditional_engineering_matrix_authorized'] is True
assert j['prior_entry_cost']['wall_seconds'] == .24578428314998746
for path in sorted((B / 'independent').glob('*.py')):
    ast.parse(path.read_bytes())
    if path.name.startswith('mr3'):
        assert 'mr3_p2a0_20261018_v22_' not in path.read_text(), str(path)
final = (B / 'independent/mr3_p2a0_v23_buildproof_preflight.py').read_text()
back = final.replace("PROBE_PREFIX = Path('/tmp/mr3_p2a0_v23_preflight_learner_entry')\n", '')
back = back.replace("Path(str(PROBE_PREFIX) + '_probe_v1.json')", "Path('/tmp/mr3_p2a0_v23_learner_entry_probe_v1.json')")
back = back.replace("Path(str(PROBE_PREFIX) + '_' + label + '.stdout.log')", "Path('/tmp/mr3_p2a0_v23_learner_entry_' + label + '.stdout.log')")
back = back.replace("Path(str(PROBE_PREFIX) + '_' + label + '.stderr.log')", "Path('/tmp/mr3_p2a0_v23_learner_entry_' + label + '.stderr.log')")
assert back == (B / 'initial_preflight_actual_probe_source_v1.py').read_text()
result = {'schema': 'mr3-v23-final-static-bindings-v2', 'passed': True,
          'old191_exact_current': True, 'new_files': 7, 'binding_count': 198,
          'plan_sha256': sha((B / 'predeclared_plan_v23.json').read_bytes()),
          'source_sha256': sha(Path(__file__).read_bytes()),
          'stage_mandatory_counts': [10, 7, 10, 7],
          'budgets': {k: j[k] for k in ('max_api_records', 'max_submitted_script_decisions', 'max_total_wall_seconds')},
          'opening_remaining_wall_seconds': 18000 - .24578428314998746,
          'actual_three_probe_source_inverse_only_output_names': True,
          'scope': 'Static bytes/AST/JSON only; no gate imports, ROS/DDS/native or full suite.'}
with (B / 'static_bindings_v2.json').open('x') as stream:
    stream.write(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
