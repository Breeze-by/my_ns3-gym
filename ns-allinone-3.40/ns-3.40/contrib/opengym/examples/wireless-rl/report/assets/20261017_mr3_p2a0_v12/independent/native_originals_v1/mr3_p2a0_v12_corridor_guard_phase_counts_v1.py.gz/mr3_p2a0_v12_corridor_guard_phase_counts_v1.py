"""Closed w1/e4 actual guard diagnostic only, no production imports/truth/control."""
from pathlib import Path
import json,hashlib,collections
E=Path('/home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261017_v12_reset/worker1/episode004_corridors_101')
raw=(E/'transitions.jsonl').read_bytes();trans=[json.loads(s)for s in raw.splitlines()];release=trans[0]['snapshot']['robots'][0]['activity']['started_at'];end=release+32
counts=collections.defaultdict(lambda:dict(count=0,reasons=collections.Counter(),request_v_nonzero=0,output_v_nonzero=0,output_w_nonzero=0,max_abs_request_v=0,max_abs_output_v=0))
p=E/'motion_safety.jsonl';size=p.stat().st_size;h=hashlib.sha256();examples={}
with p.open('rb')as f:
 for line,raw in enumerate(f,1):
  h.update(raw);r=json.loads(raw)
  if r['kind']!='decision'or not release<=r['sim_time_sec']<=end:continue
  v=r['payload'];robot=v['robot'];t=r['sim_time_sec']-release;phase='goal1'if t<10 else'wait1'if t<13 else'goal2'if t<28 else'wait2';k=robot+':'+phase;c=counts[k];d=v['decision'];q=v['request']or{'v':0,'w':0};c['count']+=1;c['reasons'][d['reason']]+=1;c['request_v_nonzero']+=q['v']!=0;c['output_v_nonzero']+=d['output'][0]!=0;c['output_w_nonzero']+=d['output'][1]!=0;c['max_abs_request_v']=max(c['max_abs_request_v'],abs(q['v']));c['max_abs_output_v']=max(c['max_abs_output_v'],abs(d['output'][0]))
  if k+':'+d['reason']not in examples:examples[k+':'+d['reason']]={'line':line,'row':r}
assert p.stat().st_size==size
for c in counts.values():c['reasons']=dict(c['reasons'])
result={'schema':'mr3-actual-corridor-post-failure-guard-counts-v1','scope':'Closed native decision counts only, no formal verdict or new same-freeze success. Passive observer joined after known failure and added load; its sample can explain this episode only, not missing old open controller scores.','episode':str(E),'epoch':trans[0]['snapshot']['epoch'],'release':release,'final':end,'motion_safety_sha256':h.hexdigest(),'counts':dict(counts),'first_reason_raw_examples':examples,'final_received_paths':{b['name']:b['activity']for b in trans[-1]['snapshot']['robots']}}
out=Path('/tmp/mr3_p2a0_v12_corridor_guard_phase_counts_v1.json')
with out.open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
print(out)
for k,c in counts.items():print(k,c)
