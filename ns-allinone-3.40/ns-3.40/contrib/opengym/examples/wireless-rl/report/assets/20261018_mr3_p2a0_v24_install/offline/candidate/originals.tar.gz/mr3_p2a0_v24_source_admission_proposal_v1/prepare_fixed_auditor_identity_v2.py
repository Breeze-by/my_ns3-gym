"""Generate TMP fixed literal revision from declared A24 custody; never apply Git/source."""
from pathlib import Path
import ast
import copy
import gzip
import hashlib
import json
import pprint

B = Path(__file__).resolve().parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A = W / 'report/assets/20261018_mr3_p2a0_v24_install'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
old_text = (B / 'baseline_auditor.py').read_text()
assert sha(old_text.encode()) == 'de297d83fd5436651e526fe9782ac0ebed02573ed9aa735a58d9fdcf613c0adf'
assignments = {n.targets[0].id: n for n in ast.parse(old_text).body if isinstance(n, ast.Assign)
               and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name)}
values = {key: ast.literal_eval(assignments[key].value) for key in
          ('RAY_BOX_SOURCE_PINS', 'RAY_BOX_LIBRARY_SPEC', 'ENV_EXECUTION_APPENDIX_BYTES')}
spec = copy.deepcopy(values['RAY_BOX_LIBRARY_SPEC'])
for key, name in [('receipt','receipt_v1.json'), ('build','canonical_build_receipt_v1.json'),
                  ('archive','libmr3_ray_box_corrector.so.gz')]:
    path = A / 'binary' / name
    raw = path.read_bytes()
    spec[key] = {'path':str(path.relative_to(ROOT)), 'sha256':sha(raw), 'bytes':len(raw)}
receipt = json.loads((A / 'binary/receipt_v1.json').read_bytes())
assert receipt['schema'] == 'mr3-v22-ray-box-actual-binary-custody-v1'
assert receipt['passed'] is True and receipt['old_four_libraries_byte_unchanged'] is True
build = json.loads((A / 'binary/canonical_build_receipt_v1.json').read_bytes())
assert build['schema'] == 'mr3-v22-canonical-ray-box-build-v1'
path = ROOT / spec['library']['path']
raw = path.read_bytes()
assert path.resolve(strict=True) == ROOT / spec['library']['resolved']
assert raw.startswith(b'\x7fELF') and gzip.decompress((A / 'binary/libmr3_ray_box_corrector.so.gz').read_bytes()) == raw
spec['library']['bytes'], spec['library']['sha256'] = len(raw), sha(raw)
expected_library = copy.deepcopy(receipt['installed_library'])
assert expected_library == dict(spec['library'], path=str(ROOT / spec['library']['path']), resolved=str(ROOT / spec['library']['resolved']))
sources = copy.deepcopy(values['RAY_BOX_SOURCE_PINS'])
wrapper = 'ros2_ws/ros2-multi-robot-automap/src/multi_robot/src/mr3_ray_box_corrector.cpp'
sources[wrapper] = 'f82646c8434b77c42f585ac1828eda84640bac873f70cc7de6848cfbd6493473'
for relative, digest in sources.items():
    assert sha((ROOT / relative).read_bytes()) == digest and digest.encode() in raw
    short = str(Path(relative).relative_to('ros2_ws/ros2-multi-robot-automap/src/multi_robot'))
    assert receipt['sources'][short]['sha256'] == digest
for item in [spec['ode_library'], *spec['unchanged_libraries'].values()]:
    path = ROOT / item['path']
    assert path.resolve(strict=True) == Path(ROOT / item['resolved'])
    data = path.read_bytes()
    assert len(data) == item['bytes'] and sha(data) == item['sha256']
environment = (B / 'MR3_ENV_CONTRACT.proposed_pending_v4.md').read_bytes()
old_environment = (B / 'baseline_environment.md').read_bytes()
assert environment.startswith(old_environment)
normative_size = len(old_environment) - values['ENV_EXECUTION_APPENDIX_BYTES']
assert sha(old_environment[:normative_size]) == '96d9bd3e3d597899b3d44a69ef9138e77b62b3641bd7261eb38846d5b003f155'
updates = {'ENV_DOCUMENT_SHA256':sha(environment),
           'ENV_EXECUTION_APPENDIX_SHA256':sha(environment[normative_size:]),
           'ENV_EXECUTION_APPENDIX_BYTES':len(environment)-normative_size,
           'RAY_BOX_SOURCE_PINS':sources, 'RAY_BOX_LIBRARY_SPEC':spec}
result = old_text
changes = []
for key, value in updates.items():
    previous = ast.get_source_segment(old_text, assignments[key])
    after = key + ' = ' + pprint.pformat(value, sort_dicts=False, width=100)
    assert result.count(previous) == 1
    result = result.replace(previous, after, 1)
    changes.append({'constant':key, 'before':previous, 'after':after})
recovered = result
for change in reversed(changes):
    assert recovered.count(change['after']) == 1
    recovered = recovered.replace(change['after'], change['before'], 1)
assert recovered == old_text
assert ast.dump(ast.parse(recovered)) == ast.dump(ast.parse(old_text))
output = B / 'audit_ppo.proposed_v24_v2.py'
assert not output.exists()
output.write_text(result)
proof = {'schema':'mr3-v24-fixed-auditor-identity-proposal-v1', 'source_STOP':True,
         'actual_native_admission':False, 'source':str(output), 'sha256':sha(result.encode()),
         'source_baseline_sha256':sha(old_text.encode()), 'changed_constants':changes,
         'whole_bytes_and_AST_inverse_to_baseline':True,
         'only_wrapper_source_changed':wrapper,
         'old4libs_ODE_core_header_execution_and_math_unchanged':True,
         'actual_fixed_library_spec':spec,
         'environment':{'source':str(B/'MR3_ENV_CONTRACT.proposed_pending_v4.md'),
             'sha256':sha(environment),'old_cace_fullprefix_exact':True,
             'appendix_bytes':len(environment)-normative_size,
             'appendix_sha256':sha(environment[normative_size:])},
         'scope':'Offline generation of fixed source literals from fixedA24 actual custody, not a runtime override/map. No source application, native or loader execution.'}
with (B/'auditor_identity_handoff_v2.json').open('x') as stream:
    stream.write(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'source':str(output),'sha256':proof['sha256'],'SO':spec['library']['sha256']}))
