"""Read-only V14 source/binary/research comparison, never native admission."""
import ast
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path('/home/zhuyulab/ns3-workspace')
BASE = '60f932edfadd5024b04a5289b2714d813e177d4f'
W = 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
ROS = 'ros2_ws/ros2-multi-robot-automap/'
A13 = W + 'report/assets/20261017_mr3_p2a0_v13/'
A14 = W + 'report/assets/20261017_mr3_p2a0_v14/'
XML = ROS + 'src/multi_robot/config/mr3_fastdds_loopback_udp.xml'
AUDIT = W + 'mr3_learning/audit_ppo.py'
TEST = W + 'mr3_learning/tests/test_audit_ppo.py'
ENV = W + 'MR3_ENV_CONTRACT.md'
OUT = Path('/tmp/mr3_p2a0_v14_research_static_v1')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def stable(path):
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    assert (before.st_ino, before.st_mtime_ns, before.st_size) == (
        after.st_ino, after.st_mtime_ns, after.st_size)
    return raw


def git(relative):
    return subprocess.check_output(['git', 'show', BASE + ':' + relative], cwd=ROOT)


def assignments(tree):
    return {node.targets[0].id: node for node in tree.body if isinstance(node, ast.Assign)
            and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)}


def text(node):
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if isinstance(node, ast.Name):
        return {'ROS': ROS, 'WIRELESS': W, 'SLAM': ROS + 'src/slam_toolbox/'}[node.id]
    assert isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add)
    return text(node.left) + text(node.right)


def main():
    OUT.mkdir()
    observed = {}

    def capture(relative):
        raw = stable(ROOT / relative)
        digest = sha(raw)
        assert relative not in observed or observed[relative] == digest
        observed[relative] = digest
        return raw

    old_plan = json.loads(git(A13 + 'predeclared_plan_v13.json'))
    plan_raw = capture(A14 + 'predeclared_plan_v14.json')
    plan = json.loads(plan_raw)
    assert plan['schema'] == 'mr3-p2a0-predeclaration-v14'
    old_bindings = {r['path']: r['sha256'] for r in old_plan['independent_source_bindings']}
    bindings = {r['path']: r['sha256'] for r in plan['independent_source_bindings']}
    assert len(bindings) == len(plan['independent_source_bindings']) == 105
    changed = {path for path, digest in old_bindings.items() if bindings.get(path) != digest}
    assert changed == {AUDIT, TEST}
    assert len(bindings.keys() - old_bindings.keys()) == 9
    for relative, expected in bindings.items():
        assert sha(capture(relative)) == expected, relative
    gate_keys = ('unchanged_gates', 'physical_response_criteria', 'settled_turn_criteria',
                 'angular_interface_criteria', 'angular_reset_criteria',
                 'full_execution_model_failfast', 'pilot_budget_unchanged',
                 'max_api_records', 'max_submitted_script_decisions', 'max_total_wall_seconds')
    for name in gate_keys:
        assert plan[name] == old_plan[name], name
    runtime_template = json.loads(git(A13 + 'independent/source_bindings_template_v1.json'))
    old_runtime = {r['path'] for r in runtime_template['runtime_paths']}
    assert len(old_runtime) == 100 and XML not in old_runtime
    expected_runtime = old_runtime | {XML}
    changed_runtime = []
    for relative in sorted(expected_runtime):
        raw = capture(relative)
        if raw != git(relative):
            changed_runtime.append(relative)
    assert set(changed_runtime) == {XML, ENV, AUDIT}
    # Compare whole executable subtrees, beyond the source proof's path subset.
    def changed_paths(*paths):
        return set(subprocess.check_output(
            ['git', 'diff', '--name-only', BASE, '--', *paths], cwd=ROOT,
            text=True).splitlines())
    assert changed_paths(ROS + 'src', ROS + 'scripts') == {
        XML, ROS + 'src/multi_robot_exploration/test/test_fastdds_environment.py'}
    assert changed_paths(W + 'mr3_learning') == {AUDIT, TEST}
    # Current auditor differs only by the new explicit XML source and ENV digest.
    tree = ast.parse(capture(AUDIT))
    before = ast.parse(git(AUDIT))
    current, original = assignments(tree), assignments(before)
    new_pins = current['PREPARATION_RUNTIME_PINS'].value
    new = dict(zip(map(text, new_pins.keys), map(text, new_pins.values)))
    old_pins = original['PREPARATION_RUNTIME_PINS'].value
    old = dict(zip(map(text, old_pins.keys), map(text, old_pins.values)))
    assert new == {**old, XML: sha(capture(XML))}
    assert text(current['ENV_DOCUMENT_SHA256'].value) == sha(capture(ENV))
    current['PREPARATION_RUNTIME_PINS'].value = original['PREPARATION_RUNTIME_PINS'].value
    current['ENV_DOCUMENT_SHA256'].value = original['ENV_DOCUMENT_SHA256'].value
    assert ast.dump(tree, include_attributes=False) == ast.dump(before, include_attributes=False)
    pin_proof = {}
    # Reparse because the exact-delta comparison above deliberately restored two nodes.
    current = assignments(ast.parse(capture(AUDIT)))
    for group in ('EVALUATOR_PHASE_PINS', 'PREPARATION_RUNTIME_PINS', 'EXECUTION_CONFIG_PINS'):
        node = current[group].value
        for key, digest in zip(node.keys, node.values):
            relative, expected = text(key), text(digest)
            assert relative not in pin_proof
            assert sha(capture(relative)) == expected
            pin_proof[relative] = expected
    assert len(pin_proof) == 36
    preflight = capture(A14 + 'independent/mr3_p2a0_v14_buildproof_preflight.py')
    preflight_tree = ast.parse(preflight)
    assert any(isinstance(n, ast.keyword) and n.arg == 'source_bindings'
               and isinstance(n.value, ast.Name) and n.value.id == 'source_proof'
               for n in ast.walk(preflight_tree))
    assert b'source_bindings=len(source_proof)' in preflight
    assert not any(isinstance(n, ast.Constant) and type(n.value) is int
                   and n.value in (100, 101) for n in ast.walk(preflight_tree))
    # The unchanged drive's physical/math implementation and exact installed bytes.
    binary = plan['drive_contract']['binary_build_receipt']
    build_raw = capture(binary['path'])
    assert sha(build_raw) == binary['sha256'] and build_raw == git(binary['path'])
    build = json.loads(build_raw)
    library = stable(Path(build['library_path']))
    assert sha(library) == build['library_sha256']
    assert stable(Path(build['installed_path'])) == library
    assert Path(build['installed_path']).resolve() == Path(build['library_path']).resolve()
    encoded = capture(build['archived_library_gzip'])
    assert encoded == git(build['archived_library_gzip'])
    assert sha(encoded) == build['archived_library_encoded_sha256']
    assert gzip.decompress(encoded) == library
    for field, relative in (
            ('compiled_source_sha256', 'src/mr3_gazebo_diff_drive.cpp'),
            ('compiled_header_sha256', 'include/multi_robot/mr3_gazebo_diff_drive.hpp'),
            ('compiled_helper_sha256', 'include/multi_robot/paired_wheel_slew.hpp'),
            ('compiled_target_contract_sha256', 'include/multi_robot/mr3_drive_target.hpp')):
        relative = ROS + 'src/multi_robot/' + relative
        raw = capture(relative)
        assert raw == git(relative) and sha(raw) == build[field]
        assert build[field].encode() in library
    # Every original A13 Git asset remains byte-identical, including old FAILs/inventories.
    archived = subprocess.check_output(['git', 'archive', BASE, '--', A13], cwd=ROOT)
    frozen_assets = []
    with tarfile.open(fileobj=io.BytesIO(archived), mode='r:') as stream:
        for member in stream:
            if member.isfile():
                raw = stream.extractfile(member).read()
                assert capture(member.name) == raw, member.name
                frozen_assets.append(member.name)
    assert all(sha(stable(ROOT / path)) == digest for path, digest in observed.items())
    result = dict(
        passed=True, base_commit=BASE, native_admission_granted=False,
        current_plan_sha256=sha(plan_raw), plan_readiness=plan['readiness'],
        binding_count=len(bindings), prior_bindings_unchanged=len(old_bindings) - len(changed),
        authorized_changed_binding_paths=sorted(changed), appended_bindings=9,
        expected_next_runtime_sourcepack_paths=sorted(expected_runtime),
        old_sourcepack_runtime_count=100, expected_next_runtime_sourcepack_count=101,
        sourcepack_count_scope='Prospective exact path set from immutable old100 plus new XML; '
                               'future actual pushed preflight/export must verify actual101.',
        changed_runtime_paths=sorted(changed_runtime), reviewed_pin_count=36,
        sourcepack_preflight_count_dynamic=True, exact_body_producer_policy_source_bytes_unchanged=True,
        hard_gate_keys_unchanged=gate_keys, original_a13_asset_files_unchanged=len(frozen_assets),
        actual_library_sha256=sha(library), actual_four_compiled_macros_match=True,
        source_before=observed, source_after=observed,
        scope='Read-only current worktree/old Git/compiled binary/static plan review. '
              'No native run, new source freeze, sourcepack export, optimization or acceptance credit.')
    output = OUT / 'review_v1.json'
    with output.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({k: v for k, v in result.items() if k not in (
        'source_before', 'source_after', 'expected_next_runtime_sourcepack_paths')}, indent=2))


if __name__ == '__main__':
    main()
