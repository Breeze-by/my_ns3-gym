#!/usr/bin/python3
"""Read closed V25 small original JSON only; no producer/consumer invocation."""
import hashlib
import json
import os
from pathlib import Path
import sys
import time


ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A25 = W / 'report/assets/20261018_mr3_p2a0_v25_smoother'
EP = ROOT / ('ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/'
             'mr3_p2a0_20261018_v25_interface/worker0/episode001_open_101')
OUT = Path('/tmp/mr3_p2a0_v25_capture_035_independent_review_v1')
PREFIX = '/tmp/mr3_p2a0_v25_interface_'
FREEZE = '579f7ad21d33c6de9351eb5308f155f0fc903fd7'
inputs = {}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def signature(path):
    stat = path.stat()
    return [stat.st_dev, stat.st_ino, stat.st_size,
            stat.st_mtime_ns, stat.st_ctime_ns]


def raw(path):
    path = Path(path)
    before = signature(path)
    data = path.read_bytes()
    assert signature(path) == before, str(path)
    proof = {'bytes': len(data), 'sha256': digest(data), 'stat': before}
    if str(path) in inputs:
        assert inputs[str(path)] == proof, str(path)
    else:
        inputs[str(path)] = proof
    return data


def read(path):
    return json.loads(raw(path))


def receipt(suffix):
    return read(PREFIX + suffix + '.json')


def main():
    started = time.monotonic()
    aggregate = receipt('audit_execution_v1')
    assert aggregate['all_submitted_jobs_finished'] is True
    assert aggregate['runner_errors'] == []
    assert aggregate['freeze'] == FREEZE
    assert aggregate['passed'] is False
    mandatory = []
    for declared in aggregate['receipts']:
        value = read(declared['path'])
        assert inputs[declared['path']]['sha256'] == declared['sha256']
        assert value['passed'] is declared['passed']
        mandatory.append({'path': declared['path'], 'passed': value['passed'],
                          'sha256': declared['sha256']})
    close = receipt('closure_binary_review_v1')
    phys = receipt('fixed_physics_v1')
    angular = receipt('fixed_angular_v1')
    full = receipt('full_audit')
    info = receipt('input_review_v1')
    native_close = read('/tmp/mr3_p2a0_v25_root_final_close_observation_v1.json')
    assert native_close['all_formal_jobs_finished'] is True
    assert native_close['all_saved_identities_gone'] is True
    assert all(row['same_identity_present'] is False
               for row in native_close['identities'])
    assert native_close['freeze'] == FREEZE
    module_path = A25 / 'independent/mr3_v25_smoother_custody_v1.py'
    source = raw(module_path).decode()
    source_sha = inputs[str(module_path)]['sha256']
    binding_path = A25 / 'independent/mr3_v25_smoother_binding_v1.json'
    raw(binding_path)
    binding_sha = inputs[str(binding_path)]['sha256']
    snapshots = []
    mapping_paths = sorted(Path('/tmp').glob(
        'mr3_p2a0_v25_interface_smoother_mapping_*.json'))
    for path in mapping_paths:
        value = read(path)
        assert value['freeze'] == FREEZE
        assert value['producer_source_sha256'] == source_sha
        assert value['binding'] == {'path': str(binding_path), 'sha256': binding_sha}
        snapshots.append({'path': str(path), 'passed': value['passed'],
                          'errors': value['errors'],
                          'complete': [r['complete'] for r in value['episodes']],
                          'wall_monotonic_ns': value['wall_monotonic_ns']})
    p35 = receipt('smoother_mapping_035')
    m35 = receipt('process_monitor_035')
    assert digest(raw(p35['monitor']['path'])) == p35['monitor']['sha256']
    m34 = receipt('process_monitor_034')
    m36 = receipt('process_monitor_036')
    nav = read(EP / 'nav2_shutdown.json')
    shutdown = read(EP / 'supervisor_shutdown.json')
    stop = read(EP / 'native_stop.json')
    metadata = read(EP / 'metadata.json')
    supervisor = read(EP / 'supervisor_metadata.json')
    assert p35['episodes'][0]['epoch'] == metadata['epoch'] == supervisor['epoch']
    assert p35['episodes'][0]['metadata_sha256'] == inputs[str(EP / 'metadata.json')]['sha256']
    assert p35['episodes'][0]['supervisor_metadata_sha256'] == inputs[str(EP / 'supervisor_metadata.json')]['sha256']
    assert p35['episodes'][0]['processes'] == {}
    assert p35['errors'] == ['process/ancestry/maps changed during capture']
    source_lines = source.splitlines()
    excerpt = '\n'.join(f'{i + 1}: {source_lines[i]}' for i in range(358, 421))
    phy_summary = {}
    for robot, r in phys['episodes'][0]['robots'].items():
        statuses = {}
        for response in r['stop_responses'] + r['cancel_stop_responses']:
            key = response['event_category'] + ':' + response['status']
            statuses[key] = statuses.get(key, 0) + 1
        phy_summary[robot] = {
            key: r[key] for key in (
                'errors', 'task_odom_samples', 'maximum_planar_speed_task',
                'maximum_angular_norm_task', 'maximum_raw_odom_chord_speed_task',
                'maximum_task_source_gap_ns', 'bound_violation_counts',
                'eligible_stop_events', 'credited_sampled_stop_events',
                'eligible_cancel_stop_events', 'credited_cancel_stop_events',
                'hard_zero_evidence_complete', 'cancel_end_to_end_evidence_complete',
                'physical_evidence_complete')}
        phy_summary[robot]['response_status_counts'] = statuses
        phy_summary[robot]['observed_nonrest_beyond_horizon'] = any(
            e.get('observed_nonrest_beyond_horizon') is True
            for e in r['stop_responses'] + r['cancel_stop_responses'])
    timing = {
        'monitor034_wall_ns': m34['wall_monotonic_ns'],
        'monitor035_wall_ns': m35['wall_monotonic_ns'],
        'proof035_wall_ns': p35['wall_monotonic_ns'],
        'monitor036_wall_ns': m36['wall_monotonic_ns'],
        'nav_shutdown_start_ns': nav['started_wall_monotonic_ns'],
        'nav_shutdown_complete_ns': nav['completed_wall_monotonic_ns'],
        'smoother_finalized_response_end_ns': {
            r['robot']: next(s['completed_wall_monotonic_ns'] for s in r['states']
                             if s['node'] == 'velocity_smoother')
            for r in nav['robots']}}
    assert timing['nav_shutdown_start_ns'] < timing['monitor035_wall_ns'] \
        < timing['nav_shutdown_complete_ns'] < timing['proof035_wall_ns']
    report = {
        'schema': 'mr3-v25-capture035-independent-small-original-review-v1',
        'freeze': FREEZE,
        'review_status': 'descriptive_closed_original_interpretation_completed',
        'original_overall_passed': False,
        'formal': {
            'all_finished': True, 'runner_errors': [],
            'jobs': len(aggregate['commands']),
            'job_passes': sum(c['passed'] is True for c in aggregate['commands']),
            'job_failures': sum(c['passed'] is False for c in aggregate['commands']),
            'mandatory_receipts': mandatory},
        'original_closure': {
            key: close[key] for key in (
                'passed', 'errors', 'native_closure_and_binary_children_passed',
                'native_started_total', 'native_clean_exits_total',
                'saved_identity_count', 'all_saved_identities_gone',
                'shim_mapping_passed', 'corrector_custody_passed',
                'smoother_custody_passed', 'input_bindings_rechecked')},
        'root_closed_observation': {
            'scope': 'Verified fields of root saved fresh observation; no new live process probe.'},
        'physical': {'passed': phys['passed'], 'per_robot': phy_summary,
                     'original_scope': phys['scope'],
                     'interpretation': 'Original per-robot A OR B is met. TB2/TB3 lack A credit; their actual B credit is retained. No new requirement for A AND B.'},
        'angular': {key: angular[key] for key in (
            'passed', 'sampled_bounds_passed', 'stimulus_coverage_passed', 'missing',
            'release_time_ns', 'final_physics_time_ns', 'positive_span_robots',
            'negative_span_robots', 'sequential_opposite_sign_span_robots', 'scope')},
        'angular_per_robot': {
            k: {key: r[key] for key in (
                'bounds_passed', 'errors', 'missing', 'max_angular_norm_rad_s',
                'max_sampled_angular_accel_rad_s2', 'max_source_gap_ns')}
            for k, r in angular['robots'].items()},
        'full_and_input': {
            'full_passed': full['passed'], 'full_errors': full['errors'],
            'input_passed': info['passed'],
            'whole_observation_and_seven_map_replay_passed': info['whole_observation_and_seven_map_replay_passed'],
            'transition_rows': info['episodes'][0]['transition_rows'],
            'received_activity': info['episodes'][0]['activity_independent_replay']['latest_actor_activity']},
        'smoother_mapping': {
            'snapshots': snapshots,
            'snapshot_count': len(snapshots),
            'complete_count': sum(any(v['complete']) for v in snapshots),
            'error_snapshot_paths': [v['path'] for v in snapshots if v['errors']],
            'source_and_binding_fields_match_actual_fixed_bytes': True,
            'proof035_processes_saved': p35['episodes'][0]['processes'],
            'proof035_error': p35['errors'],
            'missing_detail': ['failing robot', 'fresh identity after value',
                               'before/after maps', 'before/after ancestry',
                               'fresh cmdline/exe postvalues', 'failing conjunct'],
            'timing': timing,
            'monitor035_active_owned_count': len(m35['owned_current_processes']),
            'monitor036_active_owned_count': len(m36['owned_current_processes']),
            'source_excerpt': excerpt,
            'interpretation': '035 spans Nav2 shutdown completion. This supports a lifecycle-race hypothesis only; no unique false rejection or real ELF/identity change is established. Compound short-circuit condition does not identify the failed conjunct. Earlier valid proofs cannot erase the original error.'},
        'native_stop_saved': stop,
        'supervisor_shutdown_saved_flags': {
            k: shutdown[k] for k in ('forced_shutdown', 'failed_sample', 'worker_returncode')
            if k in shutdown},
        'scope': 'Only closed small original JSON/source. No raw scan, motion trace, consumer/test, SDK, ROS/DDS or native invocation. No retrospective PASS or replacement proof. Interface sampled passes are not whole-matrix, policy efficacy or 95% task credit.',
        'script_sha256': digest(Path(__file__).read_bytes()),
        'argv': sys.argv, 'cwd': str(Path.cwd()),
        'environment': {k: os.environ.get(k) for k in (
            'PYTHONNOUSERSITE', 'PYTHONDONTWRITEBYTECODE', 'ROS_DOMAIN_ID',
            'RMW_IMPLEMENTATION', 'FASTRTPS_DEFAULT_PROFILES_FILE',
            'RMW_FASTRTPS_USE_QOS_FROM_XML')},
        'input_bindings': inputs}
    report['root_closed_observation'].update({key: native_close[key] for key in (
        'saved_identity_count', 'all_saved_identities_gone', 'all_formal_jobs_finished',
        'native_started', 'native_clean_exits', 'native_wall',
        'carried_cumulative', 'remaining', 'capture_returncodes', 'source_clean')})
    for path, proof in list(inputs.items()):
        assert signature(Path(path)) == proof['stat'], path
        assert digest(Path(path).read_bytes()) == proof['sha256'], path
    report['input_end_sha_and_stat_stable'] = True
    report['wall_seconds'] = time.monotonic() - started
    report['writer_status'] = 'STOP after exclusive output'
    (OUT / 'review_v1.json').write_text(
        json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + '\n',
        encoding='utf-8')
    print(json.dumps({'status': report['review_status'],
                      'original_overall_passed': False,
                      'only_failed_mandatory': [r['path'] for r in mandatory if not r['passed']],
                      'snapshot_count': len(snapshots),
                      'complete_count': report['smoother_mapping']['complete_count'],
                      'input_count': len(inputs),
                      'output_sha256': digest((OUT / 'review_v1.json').read_bytes())},
                     ensure_ascii=False))


if __name__ == '__main__':
    main()
