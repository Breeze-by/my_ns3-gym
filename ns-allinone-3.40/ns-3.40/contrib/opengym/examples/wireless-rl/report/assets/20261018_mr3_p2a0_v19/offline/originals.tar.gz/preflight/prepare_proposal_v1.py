"""Prepare isolated V19 preflight integration; no canonical or root-draft edits."""
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT_DRAFT = Path('/tmp/mr3_p2a0_v19_root_draft_v1')
SEALED = Path('/tmp/mr3_p2a0_v19_witness_proposal_v1')

ADMISSION_FUNCTION = '''def check_gazebo_executable(freeze, plan):
    witness_path = A / 'independent/mr3_p2a0_v19_live_admission_v1.py'
    relative = str(witness_path.relative_to(ROOT))
    bindings = [row for row in plan['independent_source_bindings']
                if row['path'] == relative]
    require(len(bindings) == 1, 'corrected live witness must have one frozen source binding')
    frozen(freeze, bindings[0])
    spec = importlib.util.spec_from_file_location('declared_live_witness', witness_path)
    witness = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(witness)
    return witness.declared_gazebo_executable(plan['gazebo_executable'])


'''


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    originals = {p.name: p.read_bytes() for p in ROOT_DRAFT.iterdir() if p.is_file()}
    preflight = originals['mr3_p2a0_v19_preflight_v1.py'].decode()
    before_main = '\n\ndef main():\n'
    assert preflight.count(before_main) == 1
    proposed = preflight.replace(before_main, '\n\n' + ADMISSION_FUNCTION + 'def main():\n', 1)
    old_call = "    for binding in plan['independent_source_bindings']:\n        frozen(freeze, binding)\n"
    assert proposed.count(old_call) == 1
    proposed = proposed.replace(old_call, old_call +
                                "    gazebo_executable = check_gazebo_executable(freeze, plan)\n", 1)
    old_output = "        'source_bindings': runtime, 'independent_source_bindings': plan['independent_source_bindings'],\n"
    assert proposed.count(old_output) == 1
    proposed = proposed.replace(old_output, old_output +
                                "        'gazebo_executable': gazebo_executable,\n", 1)
    files = {'proposed_preflight_v1.py': proposed.encode(),
             'runner_v19_draft_snapshot.py': originals['mr3_p2a0_v19_run_diagnostics_v1.py'],
             'plan_v19_draft_snapshot.json': originals['predeclared_plan_v19_draft.json'],
             'original_preflight_draft.py': preflight.encode()}
    for name in ('original_v18_live_admission_v1.py', 'proposed_live_admission_v1.py',
                 'gazebo_executable_plan_fragment_v1.json', 'witness_executable_tests_v1.py'):
        files[name] = (SEALED / name).read_bytes()
    assert files['proposed_live_admission_v1.py'] == originals['mr3_p2a0_v19_live_admission_v1.py']
    runner_tests_path = Path('/tmp/mr3_p2a0_v18_runner_checks_v1.py')
    old_runner_tests = runner_tests_path.read_bytes()
    tests = old_runner_tests.decode().replace(
        "Path('/tmp/mr3_p2a0_v18_run_diagnostics_v1.py')",
        "Path(__file__).resolve().parent / 'runner_v19_draft_snapshot.py'")
    tests = tests.replace("Path('/tmp/mr3_p2a0_v18_runner_checks_v1.json')",
                          "Path(__file__).resolve().parent / 'runner_checks_v1.json'")
    files['original_v18_runner_checks_v1.py'] = old_runner_tests
    files['runner_checks_v1.py'] = tests.encode()
    patch = ''.join(difflib.unified_diff(
        preflight.splitlines(True), proposed.splitlines(True),
        fromfile='root_v19_preflight_draft.py', tofile='prospective_v19_preflight.py'))
    files['review_only.patch'] = patch.encode()
    for name, raw in files.items():
        with (HERE / name).open('xb') as stream:
            stream.write(raw)
    assert originals == {p.name: p.read_bytes() for p in ROOT_DRAFT.iterdir() if p.is_file()}
    receipt = {'passed': True, 'root_draft_unmodified': True,
               'root_draft_sources': [{'path': str(ROOT_DRAFT / name), 'sha256': sha(raw)}
                                      for name, raw in originals.items()],
               'files': [{'path': str(HERE / name), 'sha256': sha(raw), 'bytes': len(raw)}
                         for name, raw in files.items()],
               'scope': 'prospective preflight/source integration only; no native or preflight admission'}
    with (HERE / 'generation_receipt_v1.json').open('x') as stream:
        json.dump(receipt, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'passed': True, 'preflight_sha256': sha(proposed.encode()),
                      'root_draft_unmodified': True}))


if __name__ == '__main__':
    main()
