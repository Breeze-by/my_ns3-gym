"""Record short systemROS helper checks; never initializes or starts native nodes."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
ROS = ROOT / 'ros2_ws/ros2-multi-robot-automap'
OUT = Path(__file__).parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('label')
    parser.add_argument('files', nargs='+')
    args = parser.parse_args()
    assert args.label.isidentifier()
    paths = [ROS / 'src/multi_robot_exploration/multi_robot_exploration' / name
             for name in ('control.py', 'peer_obstacles.py', 'mr3_motion_safety.py')]
    paths += [ROS / name for name in args.files]
    before = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    env = {k: v for k, v in os.environ.items() if not k.startswith(('CONDA', 'VIRTUAL_ENV'))
           and k not in ('PYTHONPATH', 'AMENT_PREFIX_PATH', 'CMAKE_PREFIX_PATH',
                         'COLCON_PREFIX_PATH', 'LD_LIBRARY_PATH', 'ROS_PACKAGE_PATH')}
    overrides = {'PATH': '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
                 'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1', 'ROS_DOMAIN_ID': '211'}
    env.update(overrides)
    command = 'source /opt/ros/humble/setup.bash && source install/setup.bash && ' + shlex.join(
        ['/usr/bin/python3', '-m', 'pytest', '-q', '--tb=short', *args.files])
    argv = ['/bin/bash', '-c', command]
    started = time.monotonic()
    completed = subprocess.run(argv, cwd=ROS, env=env, capture_output=True)
    wall = time.monotonic() - started
    log = OUT / (args.label + '.log')
    with log.open('xb') as stream:
        stream.write(completed.stdout + completed.stderr)
    after = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    report = {'argv': argv, 'cwd': str(ROS), 'environment_overrides': overrides,
              'removed_environment': ['CONDA*', 'VIRTUAL_ENV*', 'PYTHONPATH', 'AMENT_PREFIX_PATH',
                                      'CMAKE_PREFIX_PATH', 'COLCON_PREFIX_PATH', 'LD_LIBRARY_PATH',
                                      'ROS_PACKAGE_PATH'], 'exit': completed.returncode,
              'wall_sec': wall, 'source_before': before, 'source_after': after,
              'sources_stable': before == after, 'stdout_stderr': str(log),
              'stdout_stderr_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
              'scope': 'SystemROS actual source helper/fake-publisher regression; no ROS init, '
                       'service call, native simulation or physical/task credit.'}
    with (OUT / (args.label + '.json')).open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps(report))
    print(log.read_text()[-1800:])


if __name__ == '__main__':
    main()
