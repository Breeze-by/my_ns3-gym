"""Version-pinned source/disk/log review only; no participant, service or native run."""
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import urllib.request
import xml.etree.ElementTree as ET

ROOT = Path('/home/zhuyulab/ns3-workspace')
ROS = ROOT / 'ros2_ws/ros2-multi-robot-automap'
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
OUT = Path('/tmp/mr3_p2a0_v13_parameter_reply_independent_review_v1')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def main():
    OUT.mkdir(exist_ok=False)
    bindings = {}

    def save(name, raw, source):
        path = OUT / name
        path.write_bytes(raw)
        bindings[name] = {'source': source, 'bytes': len(raw), 'sha256': sha(raw)}
        return raw.decode()

    urls = {
        'rmw_response_6_2_10.cpp': 'https://raw.githubusercontent.com/ros2/rmw_fastrtps/6.2.10/'
                                'rmw_fastrtps_shared_cpp/src/rmw_response.cpp',
        'custom_service_info_6_2_10.hpp': 'https://raw.githubusercontent.com/ros2/rmw_fastrtps/6.2.10/'
                                        'rmw_fastrtps_shared_cpp/include/'
                                        'rmw_fastrtps_shared_cpp/custom_service_info.hpp',
        'rmw_service_6_2_10.cpp': 'https://raw.githubusercontent.com/ros2/rmw_fastrtps/6.2.10/'
                                'rmw_fastrtps_cpp/src/rmw_service.cpp',
        'rmw_qos_6_2_10.cpp': 'https://raw.githubusercontent.com/ros2/rmw_fastrtps/6.2.10/'
                            'rmw_fastrtps_shared_cpp/src/qos.cpp',
        'rmw_available_6_2_10.cpp': 'https://raw.githubusercontent.com/ros2/rmw_fastrtps/6.2.10/'
                                  'rmw_fastrtps_shared_cpp/src/rmw_service_server_is_available.cpp',
        'release_rmw_response_6_2_10_1.cpp': 'https://raw.githubusercontent.com/ros2-gbp/'
                                          'rmw_fastrtps-release/release/humble/'
                                          'rmw_fastrtps_shared_cpp/6.2.10-1/src/rmw_response.cpp',
        'fastdds_qos_2_6_11.hpp': 'https://raw.githubusercontent.com/eProsima/Fast-DDS/v2.6.11/'
                                'include/fastdds/dds/core/policy/QosPolicies.hpp',
    }
    sources = {}
    for name, url in urls.items():
        with urllib.request.urlopen(url, timeout=30) as response:
            sources[name] = save(name, response.read(), url)
    require(sources['rmw_response_6_2_10.cpp'] == sources['release_rmw_response_6_2_10_1.cpp'],
            'upstream and Humble release package response sources differ')
    response = sources['rmw_response_6_2_10.cpp']
    require(response.index('client_present_t::MAYBE') < response.index('SerializedData data;',
            response.index('__rmw_send_response')) < response.index('response_writer_->write'),
            'error/write branch order differs')
    require(response.count('client will not receive response') == 1 and
            'get_qos().reliability().max_blocking_time' in response,
            'unique response-match timeout branch differs')

    argv = ['dpkg-query', '-W', 'ros-humble-rmw-fastrtps-cpp',
            'ros-humble-rmw-fastrtps-shared-cpp', 'ros-humble-fastrtps']
    cp = subprocess.run(argv, capture_output=True, cwd=ROOT)
    require(cp.returncode == 0, 'installed package query failed')
    versions = save('installed_versions.txt', cp.stdout + cp.stderr, {'argv': argv, 'cwd': str(ROOT)})
    require('6.2.10-' in versions and '2.6.11-' in versions, 'unexpected installed versions')
    header = Path('/opt/ros/humble/include/rmw_fastrtps_shared_cpp/'
                  'rmw_fastrtps_shared_cpp/custom_service_info.hpp')
    installed = save('installed_custom_service_info.hpp', header.read_bytes(), str(header))
    normalize = lambda text: [line.strip() for line in text.splitlines() if line.strip()]
    compatible = normalize(installed) == normalize(sources['custom_service_info_6_2_10.hpp'])
    save('installed_header_vs_official.diff', ''.join(difflib.unified_diff(
        sources['custom_service_info_6_2_10.hpp'].splitlines(keepends=True),
        installed.splitlines(keepends=True), fromfile='official6.2.10',
        tofile='installed')).encode(), 'read-only exact diff; formatting retained')
    require(compatible, 'installed listener nonblank source differs from official version')

    profile = ROS / 'src/multi_robot/config/mr3_fastdds_loopback_udp.xml'
    raw_xml = profile.read_bytes()
    save('frozen_native_profile.xml', raw_xml, str(profile))
    tree = ET.fromstring(raw_xml)
    publishers = {}
    for node in tree.iter():
        if node.tag.rsplit('}', 1)[-1] == 'publisher':
            publishers[node.attrib['profile_name']] = ET.tostring(node).decode()
    expected_names = ['rr/' + robot + '/' + kind + '/get_parametersReply'
                      for robot in ('tb1', 'tb2', 'tb3')
                      for kind in ('controller_server', 'behavior_server', 'velocity_smoother')]
    require(len(publishers) == 36 and all(name not in publishers for name in expected_names),
            'frozen profile is not original 18+18 without nine parameter writers')
    hook = W / ('report/assets/20261017_mr3_p2a0_v13/independent/'
                'mr3_actual_nav2_parameters_v13.py')
    hook_source = save('frozen_actual_parameter_hook.py', hook.read_bytes(), str(hook))
    require('wait_until(client.service_is_ready, service)' in hook_source and
            'default=30.' in hook_source, 'frozen readiness/client guard differs')

    ep = ROS / 'log/mr3_p2a0/mr3_p2a0_20261017_v13_interface/worker0/episode001_open_101'
    launch = (ep / 'launch.log').read_bytes()
    logs = [(i, line) for i, line in enumerate(launch.decode().splitlines(), 1)
            if 'get_parameters' in line and 'client will not receive response' in line]
    require(len(logs) == 1 and '/tb1/controller_server/get_parameters' in logs[0][1],
            'native exact error branch evidence differs')
    save('native_exact_branch_lines.json', (json.dumps(logs, indent=2) + '\n').encode(),
         {'path': str(ep / 'launch.log'), 'whole_raw_sha256': sha(launch)})
    native_result = json.loads((ep / 'actual_nav2_parameters.json').read_bytes())
    require(native_result['passed'] is False and native_result['nodes'] == [] and
            any('/tb1/controller_server/get_parameters response' in error
                for error in native_result['errors']), 'actual first parameter failure differs')
    save('native_failed_parameter_readback.json', (ep / 'actual_nav2_parameters.json').read_bytes(),
         str(ep / 'actual_nav2_parameters.json'))

    library_hashes = {}
    for filename in ('librmw_fastrtps_shared_cpp.so', 'librmw_fastrtps_cpp.so', 'libfastrtps.so'):
        path = Path('/opt/ros/humble/lib') / filename
        raw = path.read_bytes()
        library_hashes[str(path)] = {'resolved': str(path.resolve()), 'bytes': len(raw), 'sha256': sha(raw)}

    result = {
        'schema': 'mr3-v13-parameter-reply-independent-review-v1', 'passed': True,
        'source_freeze': native_result['freeze'], 'installed_packages': versions.splitlines(),
        'official_sources': bindings, 'installed_shared_libraries': library_hashes,
        'installed_listener_nonblank_source_matches_official_6_2_10': compatible,
        'native_failure': {'service': '/tb1/controller_server/get_parameters',
                           'actual_log_line_number': logs[0][0], 'error': logs[0][1],
                           'whole_launch_log_sha256': sha(launch), 'parameter_nodes_returned': 0},
        'established_mechanism': [
            'The exact native text selects the rmw6.2.10 response-matching timeout branch. '
            'It tests the request-associated response-reader GUID, using the response writer '
            'reliability max_blocking_time; the endpoint map still contains that GUID but '
            'the listener did not observe a match before the finite wait ended.',
            'That branch returns TIMEOUT before response write/serialization. This failure '
            'is not evidence of a serialized-payload or write-buffer size failure.',
            'Official service creation loads the generic service writer QoS, then the exact '
            'rr/...Reply profile, then applies RMW fields. RMW reliability changes its kind '
            'and leaves max_blocking_time intact. Nine exact named publisher overrides '
            'therefore target the timeout used here.'],
        'minimal_candidate': {
            'nine_exact_publisher_names': expected_names,
            'reliability_kind': 'RELIABLE', 'max_blocking_time_seconds': 1,
            'client_wall_guard_seconds_unchanged': 30,
            'application_readback_parameters_and_safety_gates_unchanged': True,
            'prefer_over_broad_default': 'Only nine parameter reply writers receive extra matching '
                                         'wait; no global service/client/default transport change.'},
        'comparison_with_client_wait_all_endpoints': [
            'Existing service_is_ready already checks graph request-reader and response-writer '
            'presence plus nonzero matching request-publisher/response-subscriber local counts.',
            'Local ready/graph endpoint visibility is not proof the server listener has '
            'processed this client response-reader GUID match. Creating all nine clients '
            'and waiting locally cannot by itself prove the missing server-side predicate.',
            'A genuinely remote per-GUID match acknowledgment would need added middleware '
            'instrumentation; no such acknowledgment is exposed by this read-only hook.'],
        'limits': [
            'The internal native wait duration and true discovery/match delay were not traced. '
            'Do not infer an observed100ms-to1s interval or claim1s is sufficient.',
            'The code names a service-discovery race workaround, but the exact transport, '
            'scheduling or discovery event that delayed this native GUID remains unobserved.',
            'Installed package/version/header and binary hashes bind the local environment; '
            'this review does not claim a reproducible source-to-ELF rebuild.',
            'Changing max_blocking_time also changes that writer synchronous write blocking '
            'budget, so it is a scoped execution-config change and needs a new freeze/matrix.',
            'No participant/service test, native retry, command/physics change, gate relaxation '
            'or Git write occurred. V13 actual failure remains unchanged.'],
        'recommended_verification': [
            'Factory-only exact9 XML QoS readback (candidate agent evidence, not a native proof).',
            'New-source freeze actual9 parameter hook completes with30s outer guard and typed '
            'values; all original state/peer/control/driver/physical/task/closure gates remain.',
            'If still failing, preserve exact failure and add source-specific match diagnostics '
            'under separate authorization rather than blind retry or broader timeout claims.'],
        'source_profile_and_native_readback_stable_before_after':
            raw_xml == profile.read_bytes() and native_result == json.loads(
                (ep / 'actual_nav2_parameters.json').read_bytes())
            and sha(launch) == sha((ep / 'launch.log').read_bytes()),
    }
    require(result['source_profile_and_native_readback_stable_before_after'], 'original changed')
    (OUT / 'review.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'passed': True, 'output': str(OUT / 'review.json'),
                      'review_sha256': sha((OUT / 'review.json').read_bytes()),
                      'official_source_files': len(urls)}))


if __name__ == '__main__':
    main()
