# Copyright 2019 Open Source Robotics Foundation, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Module for remap rule types."""

from typing import Iterable
from typing import Tuple

from launch.some_substitutions_type import SomeSubstitutionsType
from launch.substitution import Substitution


SomeRemapRule = Tuple[SomeSubstitutionsType, SomeSubstitutionsType]
SomeRemapRules = Iterable[SomeRemapRule]
RemapRule = Tuple[Tuple[Substitution, ...], Tuple[Substitution, ...]]
RemapRules = Iterable[RemapRule]
