"""Compile one SDK executable and run one <=20s lifecycle probe, no physics steps."""
import hashlib
import json
import os
from pathlib import Path
import shlex
import socket
import subprocess
import time

P = Path(__file__).parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
WORLD = ROOT / 'ros2_ws/ros2-multi-robot-automap/src/multi_robot/worlds/p1c_open.world'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
env = dict(os.environ)
for key in list(env):
    if key.startswith('CONDA') or key in ('PYTHONPATH', 'PYTHONHOME', 'LD_LIBRARY_PATH'):
        env.pop(key, None)
env.update(PATH='/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
           PYTHONNOUSERSITE='1', GAZEBO_MASTER_URI='http://127.0.0.1:13751',
           GAZEBO_MODEL_DATABASE_URI='',
           GAZEBO_MODEL_PATH=str(ROOT / 'ros2_ws/ros2-multi-robot-automap/src/multi_robot/models') +
           ':' + str(Path.home() / '.gazebo/models') + ':/usr/share/gazebo-11/models')
source = P / 'lifecycle_probe.cpp'
source_before = source.read_bytes()
world_before = WORLD.read_bytes()
flags = subprocess.check_output(['/usr/bin/pkg-config', '--cflags', '--libs', 'gazebo'], env=env)
(P / 'gazebo_pkgconfig_v1.txt').write_bytes(flags)
argv = ['/usr/bin/g++', '-O0', '-Wall', '-Wextra', '-pedantic', str(source),
        *shlex.split(flags.decode()), '-std=c++17', '-lgazebo_ode', '-o', str(P / 'lifecycle_probe')]


def execute(label, command, timeout):
    began = time.monotonic()
    result = dict(argv=command, cwd=str(P), environment=env, returncode=None)
    try:
        process = subprocess.run(command, cwd=P, env=env, capture_output=True, timeout=timeout)
        out, err = process.stdout, process.stderr
        result['returncode'] = process.returncode
    except subprocess.TimeoutExpired as error:
        out, err = error.stdout or b'', error.stderr or b''
        result['timeout'] = True
        result['error'] = repr(error)
    (P / (label + '.stdout.log')).write_bytes(out)
    (P / (label + '.stderr.log')).write_bytes(err)
    result.update(wall_seconds=time.monotonic()-began, stdout_sha256=sha(out), stderr_sha256=sha(err),
                  source_sha256=sha(source_before), world_sha256=sha(world_before))
    (P / (label + '.json')).write_text(json.dumps(result, indent=2) + '\n')
    return result


compile_result = execute('compile_v1', argv, 120)
assert compile_result['returncode'] == 0
# Read-only admission: do not start even the SDK master if this port is occupied.
with socket.socket() as reservation:
    reservation.bind(('127.0.0.1', 13751))
run_result = execute('probe_v1', [str(P / 'lifecycle_probe'), str(WORLD)], 20)
assert source.read_bytes() == source_before and WORLD.read_bytes() == world_before
print(json.dumps(dict(compile=compile_result['returncode'], compile_wall=compile_result['wall_seconds'],
                      sdk_probe=run_result['returncode'], sdk_probe_wall=run_result['wall_seconds'],
                      scope='Only Gazebo SDK create/load/init/fini; no Run/Step/ROS/plugins/robotspawn/matrix')))
