"""Offline parser synthetic byte fixtures only; never opens capture files."""
import importlib.util
from pathlib import Path
import struct
import unittest

P=Path(__file__).with_name('analyze_v1.py')
spec=importlib.util.spec_from_file_location('posthoc',P);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def fixture(endian):
    body=bytearray(struct.pack(endian+'iI',2,560000000));frame=b'base_scan\x00'
    body.extend(struct.pack(endian+'I',len(frame)));body.extend(frame)
    while len(body)%4:body.append(0)
    body.extend(struct.pack(endian+'7f',0.,6.28,.01745,0.,.2,.12,3.5))
    bits=[0xff800000,0x7fa12345,0x7f800000,0x3e080000]
    body.extend(struct.pack(endian+'I4II',4,*bits,0))
    return (b'\x00\x01\x00\x00' if endian=='<' else b'\x00\x00\x00\x00')+body,bits

class Layout(unittest.TestCase):
    def test_both_endian_original_bits_and_header(self):
        for endian in ('<','>'):
            raw,bits=fixture(endian);scan=m.scan_cdr(raw)
            self.assertEqual(scan['bits'],bits);self.assertEqual(scan['frame'],'base_scan')
            self.assertEqual(scan['source_ns'],2560000000)
            self.assertEqual([m.scalar_class(v) for v in scan['ranges']],['negative_infinity','nan','positive_infinity','finite'])
    def test_bad_layout_rejected(self):
        raw,_=fixture('<')
        for changed in (raw[:-1],b'\x00\x03'+raw[2:],raw+b'extra'):
            with self.assertRaises(ValueError):m.scan_cdr(changed)
    def test_double_bit_payload_class_binding(self):
        for bits,kind,value in [('3fc0f0148b6e2d1a','finite',struct.unpack('>d',bytes.fromhex('3fc0f0148b6e2d1a'))[0]),
                                ('fff0000000000000','negative_infinity',None),('7ff8000000000001','nan',None)]:
            self.assertEqual(m.scalar_class(m.floating({'value':value,'fpclass':kind,'binary64_hex':bits})),kind)
        with self.assertRaises(ValueError):m.floating({'value':None,'fpclass':'finite','binary64_hex':'7ff8000000000001'})

if __name__=='__main__':unittest.main()
