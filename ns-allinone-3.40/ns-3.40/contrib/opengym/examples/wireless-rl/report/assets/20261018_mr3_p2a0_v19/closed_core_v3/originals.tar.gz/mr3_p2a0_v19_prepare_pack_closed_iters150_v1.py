"""Prepare, but never execute, the closed-iters150 byte custody entry point."""
import ast
import hashlib
import json
from pathlib import Path

OLD = Path('/tmp/mr3_p2a0_v19_pack_closed_baseline_v1.py')
NEW = Path('/tmp/mr3_p2a0_v19_pack_closed_iters150_v1.py')
WRAPPER_OLD = Path('/tmp/mr3_p2a0_v19_run_pack_closed_baseline_v1.py')
WRAPPER_NEW = Path('/tmp/mr3_p2a0_v19_run_pack_closed_iters150_v1.py')
OUT = Path('/tmp/mr3_p2a0_v19_pack_closed_iters150_derivation_v1.json')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    original, wrapper = OLD.read_bytes(), WRAPPER_OLD.read_bytes()
    text = original.decode()
    changes = []

    def replace(before, after, count=1):
        nonlocal text
        assert text.count(before) == count, before
        text = text.replace(before, after)
        changes.append({'before': before, 'after': after, 'occurrences': count})

    replace('baseline', 'iters150', text.count('baseline'))
    replace("    assert execution['passed'] is True, 'closed V19 iters150 must retain its actual PASS'",
            "    assert type(execution['passed']) is bool, 'closed execution verdict must be an actual boolean'")
    replace("    assert execution['errors'] == [] and execution['returncode'] == 0\n", '')
    old = '''    consumers = execution['diagnostic_consumers']
    assert [row['label'] for row in consumers] == ['observer_1ms', 'original_physical']
    for row in consumers:
        assert row['passed'] is True and row['returncode'] == 0 and row['errors'] == []
        artifact_path = Path(row['output']['path'])
        artifact_raw = artifact_path.read_bytes()
        assert sha(artifact_raw) == row['output']['sha256']
        assert json.loads(artifact_raw)['passed'] is True
        artifacts.append({'source': str(artifact_path), 'sha256': sha(artifact_raw),
                          'bytes': len(artifact_raw), 'original_passed': True})
'''
    new = '''    consumers = execution.get('diagnostic_consumers', [])
    assert type(consumers) is list
    for row in consumers:
        output = row.get('output')
        if not isinstance(output, dict) or not output.get('path'):
            artifacts.append({'label': row.get('label'), 'available': False,
                              'original_passed': row.get('passed'),
                              'scope': 'original closed execution declares no output artifact'})
            continue
        artifact_path = Path(output['path'])
        artifact_raw = artifact_path.read_bytes()
        assert sha(artifact_raw) == output['sha256']
        artifacts.append({'label': row.get('label'), 'available': True,
                          'source': str(artifact_path), 'sha256': sha(artifact_raw),
                          'bytes': len(artifact_raw), 'original_passed': row.get('passed'),
                          'scope': 'verdict copied from closed execution, not re-audited by custody'})
'''
    replace(old, new)
    replace("    assert summary['freeze'] == execution['freeze'] and summary['passed'] is True",
            "    assert summary['freeze'] == execution['freeze'] and type(summary['passed']) is bool")
    replace("    for artifact in artifacts:\n        assert sha(Path(artifact['source']).read_bytes()) == artifact['sha256'], 'closed consumer artifact changed'\n",
            "    for artifact in artifacts:\n        if artifact['available']:\n            assert sha(Path(artifact['source']).read_bytes()) == artifact['sha256'], 'closed consumer artifact changed'\n")
    inverse = text
    for change in reversed(changes):
        assert inverse.count(change['after']) == change['occurrences'] if change['after'] else True
        if change['after']:
            inverse = inverse.replace(change['after'], change['before'])
        else:
            # Restore the one removed PASS-only line at its original anchor.
            anchor = "    assert type(execution['freeze']) is str and len(execution['freeze']) == 40\n"
            assert inverse.count(anchor) == 1
            inverse = inverse.replace(anchor, anchor + change['before'], 1)
    assert inverse.encode() == original
    old_tree, new_tree = ast.parse(original), ast.parse(text)
    functions = []
    for node in old_tree.body:
        if not isinstance(node, ast.FunctionDef) or node.name == 'main':
            continue
        other = next(row for row in new_tree.body
                     if isinstance(row, ast.FunctionDef) and row.name == node.name)
        assert ast.get_source_segment(original.decode(), node) == ast.get_source_segment(text, other)
        functions.append(node.name)
    new_wrapper = wrapper.decode().replace('baseline', 'iters150').encode()
    for path, raw in ((NEW, text.encode()), (WRAPPER_NEW, new_wrapper)):
        with path.open('xb') as stream:
            stream.write(raw)
    assert OLD.read_bytes() == original and WRAPPER_OLD.read_bytes() == wrapper
    receipt = {'passed': True, 'prepared_only': True, 'real_pack_executed': False,
               'source_old': {'path': str(OLD), 'sha256': sha(original)},
               'source_new': {'path': str(NEW), 'sha256': sha(text.encode())},
               'wrapper_old': {'path': str(WRAPPER_OLD), 'sha256': sha(wrapper)},
               'wrapper_new': {'path': str(WRAPPER_NEW), 'sha256': sha(new_wrapper)},
               'all_six_core_functions_byte_identical': functions,
               'whole_source_inverse_exact': True, 'old_sources_unchanged': True,
               'workers': 2, 'changes': changes,
               'scope': 'Only stage identity and factual-verdict custody changes. Before raw inventory/summary/consumer files are opened, source execution must be completed with iters150 identity and a typed actual verdict. No active data/receipt read.'}
    with OUT.open('x') as stream:
        json.dump(receipt, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'passed': True, 'source_new_sha256': sha(text.encode()),
                      'core_functions': functions, 'real_pack_executed': False}))


if __name__ == '__main__':
    main()
