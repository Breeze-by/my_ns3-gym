"""Closed V19 small-file ownership facts; no raw motion/adapter/physics scan."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
RUN_ROOT = ROOT / 'ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0'
OUTPUT = Path('/tmp/mr3_p2a0_v19_goal_ownership_small_review_v1.json')
FREEZE = '72d0465ddd1bbee09af117cfd9d89b7e729f8578'


def main():
    start = time.monotonic()
    inputs = {}

    def load(path, lines=False):
        raw = path.read_bytes()
        inputs[str(path)] = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
        return [json.loads(row) for row in raw.splitlines()] if lines else json.loads(raw)

    stages = []
    for stage in ('baseline', 'iters150'):
        run = RUN_ROOT / ('mr3_p2a0_20261018_v19_' + stage)
        benchmark = load(run / 'benchmark_summary.json')
        episode = benchmark['workers_results'][0]['episodes'][0]
        directory = Path(episode['output_directory'])
        summary = load(directory / 'summary.json')
        event = load(directory / (episode['epoch'] + '.json'))
        transitions = load(directory / 'transitions.jsonl', lines=True)
        assert benchmark['freeze'] == FREEZE and len(transitions) == 33
        assert summary['epoch'] == episode['epoch']
        assert event['episode_id'] == episode['epoch']
        commands = []
        for row in transitions[1:]:
            command = row['info']['command']
            assert type(command) is dict and type(command['action']) is int
            assert command['epoch'] == episode['epoch']
            action = command['action']
            assert 0 <= action < 1000
            digits = [action // 100, action // 10 % 10, action % 10]
            commands.append({'id': command['command_id'], 'action': action,
                             'created_at': command['created_at'], 'components': digits})
        robots = []
        for state in transitions[-1]['snapshot']['robots']:
            name = state['name']
            navigation = state['navigation']
            activity = state['activity']
            source = event['robots'][name]
            robots.append({'robot': name,
                           'received_accepted_goal_count': navigation['accepted_goal_count'],
                           'received_last_goal_id': navigation['last_goal_id'],
                           'received_last_terminal': navigation['last_terminal'],
                           'received_phase': navigation['phase'],
                           'received_activity_estimated_path_m': activity['estimated_path_m'],
                           'received_activity_complete': activity['path_observation_complete'],
                           'received_activity_samples': activity['sample_count'],
                           'evaluator_observed_nav_goal_uuids': source['nav_goal_count'],
                           'evaluator_nav_succeeded': source['nav_succeeded'],
                           'evaluator_nav_canceled': source['nav_canceled'],
                           'evaluator_nav_aborted': source['nav_aborted'],
                           'evaluator_path_m': source['path_length_m']})
        stages.append({'stage': stage, 'epoch': episode['epoch'], 'benchmark_returned_steps': 32,
                       'benchmark_passed_scope_sampling_only': benchmark['passed'],
                       'action_counts': dict(Counter(str(item['action']) for item in commands)),
                       'new_goal_component_requests': sum(
                           digit < 8 for item in commands for digit in item['components']),
                       'keep_component_requests': sum(
                           digit == 8 for item in commands for digit in item['components']),
                       'wait_component_requests': sum(
                           digit == 9 for item in commands for digit in item['components']),
                       'commands': commands, 'robots': robots,
                       'ownership_closed': summary['closed'],
                       'native_close': {key: summary[key] for key in
                                        ('reason', 'failures', 'native_failures',
                                         'launch_returncode', 'transition_count')},
                       'event': {key: event[key] for key in
                                 ('nav_goal_count', 'nav_succeeded', 'nav_canceled', 'nav_aborted',
                                  'navigation_protocol_closed', 'control_failure',
                                  'termination_reason', 'success', 'robot_participation_pass')}})
    for path, bound in inputs.items():
        raw = Path(path).read_bytes()
        assert len(raw) == bound['bytes']
        assert hashlib.sha256(raw).hexdigest() == bound['sha256']
    result = {'schema': 'mr3-v19-closed-small-ownership-facts-v1', 'descriptive_only': True,
              'stages': stages, 'inputs': inputs, 'inputs_before_after_stable': True,
              'findings': [
                  'Contrast returned32 KEEP/WAIT commands, no GOAL component request; '
                  'all three received accepted counts and observed Nav2 goal UUID counts are0.',
                  'Baseline has6 observed Nav2 goal UUIDs and2 received accepted goals per robot; '
                  'therefore the two stages did not receive matched motion excitation.',
                  'Goal ownership closed/pending0 proves terminal ownership closure, not alone '
                  'absence of earlier goals; counts and actual commands are separate evidence.',
                  'No evidence here of a submitted GOAL lost/rejected by Nav2 in contrast. '
                  'Candidate availability/filter cause is delegated to separate snapshot review.',
                  'Stationary contrast cannot establish braking repair or original A/B coverage; '
                  'no gate, threshold, matrix, task95% or policy credit is changed.'
              ],
              'limits': ['Evaluator nav_goal_count is distinct UUIDs seen on Nav2 status callbacks, '
                         'not a standalone action-server accept RPC trace.',
                         'No big adapter/motion/physics scan and no formal consumer was run.',
                         'Paired descriptive analysis is running separately under root control; '
                         'its unfinished output was not read.'],
              'execution': {'argv': sys.argv, 'cwd': str(Path.cwd()),
                            'wall_seconds': time.monotonic() - start,
                            'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}}
    with OUTPUT.open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'output': str(OUTPUT), 'sha256': hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),
                      'contrast_new_goal_components': stages[1]['new_goal_component_requests'],
                      'baseline_new_goal_components': stages[0]['new_goal_component_requests']}))


if __name__ == '__main__':
    main()
