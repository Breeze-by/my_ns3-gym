"""Seal author CPU/source originals only. Never read native data or change Git."""
import gzip
import hashlib
import json
from pathlib import Path
import tarfile
import time

MANIFESTS = [
    Path('/tmp/mr3_p2a0_v22_production_auditor_proposal_v5/manifest_v1.json'),
    Path('/tmp/mr3_p2a0_v22_production_auditor_proposal_v6/manifest_v6.json'),
    Path('/tmp/mr3_p2a0_v22_matrix_proposal_v3/manifest_v3.json'),
]
OUTPUT = Path('/tmp/mr3_p2a0_v22_candidate_offline_sealed_v1.tar.gz')
RECEIPT = Path('/tmp/mr3_p2a0_v22_candidate_offline_custody_v1.json')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    value = path.stat()
    return [value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns]


def main():
    start = time.monotonic()
    if OUTPUT.exists() or RECEIPT.exists():
        raise ValueError('never overwrite custody outputs')
    sources = {}
    for manifest_path in MANIFESTS:
        original = manifest_path.read_bytes()
        document = json.loads(original)
        for entry in document['files']:
            path = Path(entry['source'])
            if str(path) in sources:
                raise ValueError('duplicate absolute source in disjoint original manifests')
            raw = path.read_bytes()
            if len(raw) != entry['bytes'] or sha(raw) != entry['sha256']:
                raise ValueError('sealed original source differs: ' + str(path))
            sources[str(path)] = dict(entry)
        sources[str(manifest_path)] = {'source': str(manifest_path), 'sha256': sha(original),
                                       'bytes': len(original)}
    script = Path(__file__).resolve()
    raw = script.read_bytes()
    sources[str(script)] = {'source': str(script), 'sha256': sha(raw), 'bytes': len(raw)}
    before = {}
    for key, entry in sources.items():
        path = Path(key)
        if path.is_symlink() or not path.is_relative_to(Path('/tmp')):
            raise ValueError('only closed actual TMP regular files are selected')
        if '__pycache__' in path.parts or path.suffix == '.pyc':
            raise ValueError('cache is not evidence')
        before[key] = identity(path)
        with path.open('rb') as stream:
            if stream.read(4) == b'\x7fELF':
                raise ValueError('ELF/build artifact is not author CPU evidence')
        entry['archive_path'] = str(path.relative_to(Path('/tmp')))
        entry['source_stat'] = before[key]
    with OUTPUT.open('xb') as compressed:
        with gzip.GzipFile(filename='', mode='wb', fileobj=compressed, mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w|') as archive:
                for key, entry in sorted(sources.items()):
                    path = Path(key)
                    info = archive.gettarinfo(str(path), arcname=entry['archive_path'])
                    if not info.isfile():
                        raise ValueError('regular originals only')
                    with path.open('rb') as source:
                        archive.addfile(info, source)
    selected = {entry['archive_path']: entry for entry in sources.values()}
    verified = []
    with tarfile.open(OUTPUT, mode='r:gz') as archive:
        for member in archive:
            if not member.isfile() or member.name not in selected:
                raise ValueError('unexpected/non-file archive member')
            expected = selected[member.name]
            hasher = hashlib.sha256()
            count = 0
            stream = archive.extractfile(member)
            while True:
                chunk = stream.read(1024 * 1024)
                if not chunk:
                    break
                count += len(chunk)
                hasher.update(chunk)
            if count != expected['bytes'] or hasher.hexdigest() != expected['sha256']:
                raise ValueError('lossless roundtrip differs: ' + member.name)
            verified.append(member.name)
    if len(verified) != len(sources) or len(set(verified)) != len(sources):
        raise ValueError('missing or duplicate archive member')
    for key, entry in sources.items():
        path = Path(key)
        raw = path.read_bytes()
        if identity(path) != before[key] or sha(raw) != entry['sha256'] or len(raw) != entry['bytes']:
            raise ValueError('source changed before final custody verdict: ' + key)
    encoded = OUTPUT.read_bytes()
    if len(encoded) >= 100000000:
        raise ValueError('encoded artifact exceeds declared single-file ceiling')
    result = {'schema': 'mr3-v22-candidate-offline-custody-v1', 'passed': True,
              'argv': ['/usr/bin/python3', str(script)], 'wall_seconds': time.monotonic() - start,
              'archive': {'path': str(OUTPUT), 'sha256': sha(encoded), 'bytes': len(encoded),
                          'encoding': 'tar+gzip'},
              'count': len(sources), 'raw_bytes': sum(e['bytes'] for e in sources.values()),
              'original_manifest_counts': [196, 11, 62],
              'manifest_paths': [str(p) for p in MANIFESTS],
              'entries': list(sources.values()), 'all_members_roundtrip_verified': True,
              'all_sources_final_stat_and_sha_unchanged': True,
              'cache_elf_mock_worktree_excluded': True,
              'source_and_metadata_writers_stopped': True,
              'scope': 'Closed author CPU source, fixtures, raw stdout and original failures only. '
                       'No native/ROS/DDS/build/proc activity and no scientific/matrix acceptance credit. '
                       'Existing SDK and independent source reviews are separate originals and not duplicated.'}
    with RECEIPT.open('x') as stream:
        stream.write(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('passed', 'archive', 'count', 'raw_bytes', 'wall_seconds')}))


if __name__ == '__main__':
    main()
