"""Lossless /tmp evidence bundle. Never opens the large native raw inputs."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile


PREFIX = "/tmp/mr3_p2a0_v18_closed_observer"
DEST = Path(PREFIX + "_bundle_v1.tar.gz")
MANIFEST = Path(PREFIX + "_bundle_manifest_v1.json")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def stat(path):
    value = path.stat()
    return {key: getattr(value, key) for key in
            ("st_dev", "st_ino", "st_size", "st_mtime_ns")}


def main():
    assert not DEST.exists() and not MANIFEST.exists()
    history = {
        "schema": "mr3-v18-postmortem-development-history-v1",
        "cpu_arithmetic_check": {
            "argv": ["/usr/bin/python3", "/tmp/mr3_p2a0_v18_closed_observer_diagnostic_cpu_v1.py"],
            "environment": {"PYTHONDONTWRITEBYTECODE": "1", "PYTHONNOUSERSITE": "1"},
            "tool_command": "rtk proxy env PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 /usr/bin/python3 /tmp/mr3_p2a0_v18_closed_observer_diagnostic_cpu_v1.py",
            "tool_reported_exit_code": 0,
            "tool_reported_wall_seconds": 0.613494996,
            "tool_reported_stdout": "PASS: exact PRE odom join; zero reference with .011 drift retained; post integration residual.\n",
            "scope": "Original tool response transcription; not an execve trace. Original synthetic input/results and source are included.",
        },
        "syntax_probe": {
            "tool_reported_exit_code": 0, "tool_reported_stdout": "syntax PASS\n",
            "scope": "In-memory compile(Path(source).read_bytes(),...,exec), no pyc artifact."
        },
        "source_authoring_failure_before_file_creation": {
            "tool": "functions.exec JavaScript parser", "message": "SyntaxError: Unexpected token '*'",
            "scope": "The first attempted patch invocation failed before tool execution or source creation. No raw failing source file/SHA was retained; this is not a native, consumer-data or semantic-test failure."
        },
        "native_and_formal_calls": 0,
        "data_processing": "One actual large-data sequential pass per file, recorded by the original execution wrapper. Summary only reads reduced JSON."
    }
    history_path = Path(PREFIX + "_development_history_v1.json")
    history_path.write_text(json.dumps(history, indent=2) + "\n")
    files = [
        Path(PREFIX + "_diagnostic_v1.py"),
        Path(PREFIX + "_diagnostic_cpu_v1.py"),
        Path(PREFIX + "_diagnostic_run_v1.py"),
        Path(PREFIX + "_diagnostic_execution_v1.json"),
        Path(PREFIX + "_diagnostic_v1.stdout"),
        Path(PREFIX + "_diagnostic_v1.stderr"),
        Path(PREFIX + "_summary_v1.py"),
        Path(PREFIX + "_summary_v1.json"),
        Path(PREFIX + "_summary_v1.md"),
        history_path,
        Path(__file__),
        Path("/tmp/mr3_p2a0_v19_witness_independent_review_v1.py"),
        Path("/tmp/mr3_p2a0_v19_witness_independent_review_v1.json"),
    ]
    for directory in (Path(PREFIX + "_diagnostic_v1"),
                      Path("/tmp/mr3_p2a0_v18_closed_diagnostic_cpu_v1")):
        files.extend(path for path in directory.rglob("*") if path.is_file())
    files = sorted(set(files))
    entries, content = [], {}
    for path in files:
        assert path.is_file() and not path.is_symlink()
        assert "__pycache__" not in path.parts and path.suffix not in (".pyc", ".so")
        before = stat(path)
        raw = path.read_bytes()
        after = stat(path)
        assert before == after and len(raw) == before["st_size"]
        member = "originals/" + str(path.relative_to("/tmp"))
        content[member] = raw
        entries.append({"source_absolute_path": str(path), "archive_member": member,
                        "raw_bytes": len(raw), "raw_sha256": sha(raw),
                        "stat_before": before, "stat_after": after})
    inner = {"schema": "mr3-v18-closed-observer-evidence-manifest-v1",
             "files": entries,
             "scope": "Postmortem and related static witness review only; V18 FAIL unchanged.",
             "exclusions": ["Large native physics/motion raw files are referenced by their complete one-pass SHA in diagnostic.json, not copied into this supplemental bundle.",
                            "Immutable A18 low-level reader and runtime V19 proposal are referenced by original path/SHA, not duplicated.",
                            "No ELF/build/cache/symlink views, no new native/formal results."]}
    inner_raw = (json.dumps(inner, indent=2, sort_keys=True) + "\n").encode()
    content["manifest_v1.json"] = inner_raw
    decoded = io.BytesIO()
    with tarfile.open(fileobj=decoded, mode="w", format=tarfile.PAX_FORMAT) as archive:
        for name, raw in sorted(content.items()):
            item = tarfile.TarInfo(name)
            item.size, item.mode, item.mtime = len(raw), 0o644, 0
            item.uid = item.gid = 0
            item.uname = item.gname = ""
            archive.addfile(item, io.BytesIO(raw))
    tar_bytes = decoded.getvalue()
    with DEST.open("xb") as out:
        with gzip.GzipFile(filename="", mode="wb", fileobj=out, mtime=0) as zipped:
            zipped.write(tar_bytes)
    encoded = DEST.read_bytes()
    roundtrip = gzip.decompress(encoded)
    assert roundtrip == tar_bytes
    with tarfile.open(fileobj=io.BytesIO(roundtrip), mode="r:") as archive:
        assert sorted(archive.getnames()) == sorted(content)
        for item in archive.getmembers():
            assert item.isfile() and not item.issym()
            assert archive.extractfile(item).read() == content[item.name]
    for entry in entries:
        path = Path(entry["source_absolute_path"])
        assert stat(path) == entry["stat_before"]
        assert sha(path.read_bytes()) == entry["raw_sha256"]
    outer = {"schema": "mr3-v18-closed-observer-evidence-bundle-v1", "file_count": len(entries),
             "archive": {"path": str(DEST), "encoded_bytes": len(encoded),
                         "encoded_sha256": sha(encoded), "decoded_tar_bytes": len(tar_bytes),
                         "decoded_tar_sha256": sha(tar_bytes)},
             "inner_manifest_sha256": sha(inner_raw),
             "all_files_roundtrip_exact": True, "all_sources_stable_before_after": True,
             "files": entries, "exclusions": inner["exclusions"],
             "exact_archive_command": [
                 "env", "PYTHONDONTWRITEBYTECODE=1", "PYTHONNOUSERSITE=1",
                 "/usr/bin/python3", str(Path(__file__))]}
    MANIFEST.write_text(json.dumps(outer, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"files": len(entries), "archive": str(DEST), "archive_sha256": sha(encoded),
                      "manifest": str(MANIFEST), "manifest_sha256": sha(MANIFEST.read_bytes())}))


if __name__ == "__main__":
    main()
