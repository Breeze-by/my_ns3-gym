"""Bounded independent CPU commands; exact stdout and read-before/after source bindings."""
import ast
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

P = Path(__file__).resolve().parent
A = P / 'assets/20261017_mr3_p2a0_v17/independent'
CONDA = '/home/zhuyulab/miniconda3/envs/ns3gym/bin/python'
core = [P / name for name in ('benchmark.py', 'audit_preparation.py', 'test_preparation_comparison.py',
                             'test_benchmark_stimulus_v6.py', 'test_actual_replay_v1.py',
                             'run_comparison_tests.py', 'run_portable_stimulus_tests.py')]
assets = list(A.glob('*.py'))
inputs = core + assets + [P / 'old_benchmark.py', P / 'initial_float_boundary_benchmark.py']
for version in ('v15', 'v16'):
    inputs.append(Path('/home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0')
                  / ('mr3_p2a0_20261017_' + version + '_interface/worker0/episode001_open_101/transitions.jsonl'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


commands = [['/usr/bin/python3', '-B', str(P / 'test_actual_replay_v1.py')],
            [CONDA, '-B', str(P / 'run_comparison_tests.py')],
            [CONDA, '-B', str(P / 'run_portable_stimulus_tests.py')],
            ['/usr/bin/python3', '-B', str(A / 'mr3_independent_reset_wrappers_v17_tests.py')],
            ['/usr/bin/python3', '-m', 'flake8', *map(str, core), '--ignore=E501,W503'],
            ['/usr/bin/python3', '-m', 'flake8', *map(str, assets), '--ignore=E501,W503,E128']]
before = {str(path): sha(path) for path in inputs}
started = time.monotonic()


def run(item):
    index, argv = item
    begin = time.monotonic()
    process = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             env=dict(os.environ, PYTHONNOUSERSITE='1'))
    log = P / ('checks_v1_command_' + str(index) + '.log')
    with log.open('xb') as handle:
        handle.write(process.stdout)
    return {'argv': argv, 'returncode': process.returncode,
            'wall_seconds': time.monotonic() - begin,
            'stdout': str(log), 'stdout_sha256': sha(log)}


with ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(run, enumerate(commands, 1)))
after = {str(path): sha(path) for path in inputs}
for path in core + assets:
    ast.parse(path.read_bytes())
result = {'schema': 'mr3-v17-stimulus-v6-prototype-cpu-v1',
          'passed': all(item['returncode'] == 0 for item in results) and before == after,
          'scope': 'Pure CPU selector lifecycle/actual-snapshot replay and metadata eligibility only. '
                   'No canonical/Git/source/binary changes, ROS/native/formal run or new task/physical credit.',
          'methods': {'actual_and_default_replay': 4, 'portable_stimulus': 11,
                      'capacity': 10, 'reset_wrappers': 19},
          'commands': results, 'sources': before, 'source_before_after_stable': before == after,
          'ast_compile_passed': True,
          'assets_style_scope': 'E128 only for inherited unchanged physical-body formatting. '
                                'Wrapper inverse text/AST proof retains old math/source.',
          'wall_seconds': time.monotonic() - started, 'tool_sha256': sha(Path(__file__))}
with (P / 'checks_v1.json').open('x') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
print(json.dumps({'passed': result['passed'], 'receipt_sha256': sha(P / 'checks_v1.json'),
                  'commands': [{'returncode': item['returncode'], 'wall_seconds': item['wall_seconds'],
                                'stdout': item['stdout']} for item in results],
                  'wall_seconds': result['wall_seconds']}, indent=2))
raise SystemExit(0 if result['passed'] else 1)
