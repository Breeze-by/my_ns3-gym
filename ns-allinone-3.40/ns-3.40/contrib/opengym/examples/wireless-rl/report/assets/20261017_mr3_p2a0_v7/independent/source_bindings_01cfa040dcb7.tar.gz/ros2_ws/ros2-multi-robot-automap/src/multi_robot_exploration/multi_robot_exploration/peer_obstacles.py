"""Represent observed peer bodies in a dedicated Nav2 obstacle layer."""

import json
import math

from action_msgs.msg import GoalStatus, GoalStatusArray
from nav_msgs.msg import Odometry
import numpy as np
import rclpy
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile
from sensor_msgs.msg import LaserScan, PointCloud2, PointField
from std_msgs.msg import Header, String
from tf2_msgs.msg import TFMessage

from multi_robot_exploration.control import (
    PEER_BODY_RADIUS_M, peer_safety_radius, quaternion_yaw, transform_point_2d,
)


BEAM_COUNT = 2048
MAX_RANGE_M = 20.0


def body_points(peers):
    """Fill observed (x, y, source_age) peer disks with dense marking points."""
    groups = []
    for x, y, age in peers:
        radius = peer_safety_radius(age)
        offsets = np.arange(-radius, radius + 0.025, 0.025)
        dx, dy = np.meshgrid(offsets, offsets)
        inside = dx * dx + dy * dy <= radius * radius
        groups.append(np.column_stack((x + dx[inside], y + dy[inside], np.zeros(inside.sum()))))
    return np.concatenate(groups).astype("<f4") if groups else np.empty((0, 3), dtype="<f4")


def overlap_diagnostic(poses, odometry, transforms, now, tf_source_lead):
    """Retain the exact received inputs of the existing centre-distance gate.

    This is evidence, not a predictive collision check. Received ROS messages
    do not carry the transport epoch/sequence, and their stamps need not match.
    """
    def vector(message, axes):
        return {axis: (getattr(message, axis) if math.isfinite(getattr(message, axis)) else None)
                for axis in axes}

    pairs = []
    names = list(poses)
    for index, name in enumerate(names):
        for other in names[index + 1:]:
            distance = math.hypot(poses[other][0] - poses[name][0],
                                  poses[other][1] - poses[name][1])
            if distance < 2 * PEER_BODY_RADIUS_M:
                pairs.append({"robots": [name, other], "centre_distance_m": distance,
                              "threshold_m": 2 * PEER_BODY_RADIUS_M})
    if not pairs:
        return None
    inputs = {}
    for name, (x, y, yaw, _) in poses.items():
        odom = odometry[name]
        transform = transforms[name]
        odom_stamp = odom.header.stamp.sec + odom.header.stamp.nanosec / 1e9
        tf_stamp = transform.header.stamp.sec + transform.header.stamp.nanosec / 1e9
        position, orientation = odom.pose.pose.position, odom.pose.pose.orientation
        translation, rotation = transform.transform.translation, transform.transform.rotation
        inputs[name] = {
            "estimated_map_pose": {"x": x, "y": y, "yaw": yaw},
            "odom_stamp_sec": odom_stamp, "odom_source_age_sec": now - odom_stamp,
            "tf_validity_stamp_sec": tf_stamp, "tf_source_stamp_sec": tf_stamp - tf_source_lead,
            "tf_source_age_sec": now - (tf_stamp - tf_source_lead),
            "odom_frame": odom.header.frame_id, "odom_child_frame": odom.child_frame_id,
            "tf_frame": transform.header.frame_id, "tf_child_frame": transform.child_frame_id,
            "odom_position": vector(position, ("x", "y", "z")),
            "odom_orientation": vector(orientation, ("x", "y", "z", "w")),
            "tf_translation": vector(translation, ("x", "y", "z")),
            "tf_rotation": vector(rotation, ("x", "y", "z", "w")),
            "odom_twist": {
                kind: vector(getattr(odom.twist.twist, kind), ("x", "y", "z"))
                for kind in ("linear", "angular")},
        }
    return {
        "schema": "mr3-peer-overlap-inputs-v1", "observation_sim_time_sec": now,
        "body_radius_m": PEER_BODY_RADIUS_M, "tf_source_lead_sec": tf_source_lead,
        "pairs": pairs, "received_inputs": inputs,
        "transport_epoch_missing": True, "transport_sequence_missing": True,
        "nonfinite_auxiliary_components_encoded_as_null": True,
        "scope": "received odom/TF gate inputs; no truth or actual-contact assertion",
    }


class PeerObstacles(Node):
    def __init__(self):
        super().__init__("peer_obstacles")
        count = self.declare_parameter("robot_count", 3).value
        if not 1 <= count <= 4:
            raise ValueError("robot_count must be between 1 and 4")
        self.names = [f"tb{i}" for i in range(1, count + 1)]
        self.transforms = {}
        self.odometry = {}
        self.mission_started = False
        self.failed = False
        self.tf_source_lead_sec = self.declare_parameter("tf_source_lead_sec", 0.).value
        self.publishers_by_robot = {
            name: self.create_publisher(LaserScan, f"/{name}/peer_obstacles", 1)
            for name in self.names
        }
        self.body_publishers = {
            name: self.create_publisher(PointCloud2, f"/{name}/peer_footprints", 1)
            for name in self.names
        }
        self.failure_publisher = self.create_publisher(
            String, "/exploration_failure",
            QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL),
        )
        self.inputs = []
        task_release_start = self.declare_parameter("task_release_start", False).value
        if task_release_start:
            self.inputs.append(self.create_subscription(
                Header, "/exploration_start", self.receive_release,
                QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL),
            ))
        for name in self.names:
            self.inputs.extend([
                self.create_subscription(
                    Odometry, f"/{name}/odom",
                    lambda msg, name=name: self.odometry.update({name: msg}), 1,
                ),
                self.create_subscription(
                    TFMessage, f"/{name}/tf",
                    lambda msg, name=name: self.receive_tf(msg, name), 20,
                ),
            ])
            if not task_release_start:
                self.inputs.append(self.create_subscription(
                    GoalStatusArray, f"/{name}/navigate_to_pose/_action/status",
                    self.receive_status, 10,
                ))
        self.timer = self.create_timer(0.1, self.publish_obstacles)

    def receive_release(self, message):
        if message.frame_id == "map":
            self.mission_started = True

    def receive_tf(self, message, name):
        for transform in message.transforms:
            if (
                transform.header.frame_id.lstrip("/") == "map"
                and transform.child_frame_id.lstrip("/") == "odom"
            ):
                self.transforms[name] = transform

    def receive_status(self, message):
        if any(status.status in (
            GoalStatus.STATUS_ACCEPTED, GoalStatus.STATUS_EXECUTING, GoalStatus.STATUS_CANCELING,
        ) for status in message.status_list):
            self.mission_started = True

    def publish_obstacles(self):
        now = self.get_clock().now().nanoseconds / 1e9
        poses = {}
        for name in self.names:
            odometry = self.odometry.get(name)
            transform = self.transforms.get(name)
            if odometry is None or transform is None:
                break
            stamp = odometry.header.stamp.sec + odometry.header.stamp.nanosec / 1e9
            tf_stamp = transform.header.stamp.sec + transform.header.stamp.nanosec / 1e9
            lead = getattr(self, "tf_source_lead_sec", 0.)
            tf_source = tf_stamp - lead
            if (stamp <= 0 or now - stamp > 0.5 or now - tf_source > 0.5
                    or (lead > 0 and (tf_source > now or stamp > now))):
                break
            position = odometry.pose.pose.position
            x, y = transform_point_2d(position.x, position.y, transform.transform)
            yaw = quaternion_yaw(odometry.pose.pose.orientation) + quaternion_yaw(
                transform.transform.rotation
            )
            if not all(math.isfinite(v) for v in (x, y, yaw)):
                break
            poses[name] = (x, y, yaw, min(stamp, tf_source) if lead > 0 else stamp)
        if len(poses) != len(self.names):
            if self.mission_started and not self.failed:
                message = String()
                message.data = json.dumps({
                    "component": "peer_obstacles", "reason": "peer_state_unavailable",
                })
                self.failure_publisher.publish(message)
                self.get_logger().error("Peer odom/TF unavailable; obstacle publication stopped")
                self.failed = True
            return
        if self.failed:
            return
        diagnostic = overlap_diagnostic(poses, self.odometry, self.transforms, now, lead)
        if diagnostic is not None:
            message = String()
            message.data = json.dumps({
                "component": "peer_obstacles", "reason": "peer_body_envelopes_overlap",
                "diagnostic": diagnostic,
            }, allow_nan=False)
            self.failure_publisher.publish(message)
            self.failed = True
            return
        for name, (x, y, yaw, _) in poses.items():
            peers = []
            for other, (px, py, _, stamp) in poses.items():
                if other == name:
                    continue
                dx, dy = px - x, py - y
                peers.append((
                    math.cos(yaw) * dx + math.sin(yaw) * dy,
                    -math.sin(yaw) * dx + math.cos(yaw) * dy,
                    now - stamp,
                ))
            message = LaserScan()
            message.header.frame_id = "base_link"
            message.header.stamp = self.odometry[name].header.stamp
            message.angle_min = -math.pi
            message.angle_increment = 2 * math.pi / BEAM_COUNT
            message.angle_max = message.angle_min + (BEAM_COUNT - 1) * message.angle_increment
            message.range_min = 0.01
            message.range_max = MAX_RANGE_M
            # Clearing is confined to the separate peer layer. Static and real
            # lidar evidence remain in their own max-combined layers.
            message.ranges = [math.inf] * BEAM_COUNT
            self.publishers_by_robot[name].publish(message)
            points = body_points(peers)
            cloud = PointCloud2()
            cloud.header = message.header
            cloud.height = 1
            cloud.width = len(points)
            cloud.fields = [
                PointField(name=field, offset=offset, datatype=PointField.FLOAT32, count=1)
                for field, offset in (("x", 0), ("y", 4), ("z", 8))
            ]
            cloud.point_step = 12
            cloud.row_step = 12 * len(points)
            cloud.is_dense = True
            cloud.data = points.tobytes()
            self.body_publishers[name].publish(cloud)


def main(args=None):
    rclpy.init(args=args)
    node = PeerObstacles()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
