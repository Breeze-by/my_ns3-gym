#!/usr/bin/python3
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

D = Path(__file__).parent


def bound(path):
    def ident(s):
        return [s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
    s = path.stat()
    raw = path.read_bytes()
    assert ident(s) == ident(path.stat())
    return raw, {'source': str(path), 'name': path.name, 'bytes': len(raw),
                 'sha256': hashlib.sha256(raw).hexdigest(), 'stat': ident(s)}


def main():
    files = sorted(D.iterdir())
    assert all(p.is_file() and not p.is_symlink() for p in files)
    assert not any(p.name in ('originals.tar.gz','sealed_manifest_v1.json','handoff_v1.json') for p in files)
    captured = [bound(p) for p in files]
    archive = D / 'originals.tar.gz'
    with archive.open('xb') as output, gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w|') as tar:
            for raw, row in captured:
                info = tarfile.TarInfo(row['name'])
                info.size = len(raw)
                info.mode = 0o644
                info.mtime = 0
                tar.addfile(info,io.BytesIO(raw))
    with tarfile.open(archive,mode='r:gz') as tar:
        assert len(tar.getmembers()) == len(captured)
        for raw,row in captured:
            assert tar.extractfile(row['name']).read() == raw
    assert [row for raw,row in captured] == [bound(p)[1] for p in files]
    manifest = {'schema':'mr3-v25-actual-probe-independent-custody-v1',
                'source_files':len(captured),'raw_bytes':sum(len(raw) for raw,row in captured),
                'files':[row for raw,row in captured], 'archive':bound(archive)[1],
                'all_members_roundtrip_verified':True,'all_source_end_bytes_and_stat_stable':True,
                'scope':'Descriptive independent actual component probe output review; no build/test/ROS/probe/native rerun, no canonical mutation.',
                'original_actual_inputs':'Referenced by exact paths/SHA/stat inreview; not duplicated ELF or original producer receipts.',
                'all_writers_stopped':True}
    (D/'sealed_manifest_v1.json').write_text(json.dumps(manifest,indent=2)+'\n')
    handoff = {'schema':'mr3-v25-actual-probe-independent-review-handoff-v1',
               'review':bound(D/'review_v1.json')[1],'manifest':bound(D/'sealed_manifest_v1.json')[1],
               'archive':bound(archive)[1],'source_files':len(captured),'writers_stopped':True,
               'canonical_source_binary_reads_STOP':True,
               'scope':'Actual stock/fixed timer/pause/resume/callback-increment/library/closure review only; no continuous body/task/matrix proof.',
               'tolerance':'Fixed observed callback subtraction checks only4ULP of nominal bound; actual commandcaps strict; original hardgates unchanged.'}
    (D/'handoff_v1.json').write_text(json.dumps(handoff,indent=2)+'\n')
    print(json.dumps({'handoff':bound(D/'handoff_v1.json')[1],
                      'manifest':bound(D/'sealed_manifest_v1.json')[1],
                      'archive':bound(archive)[1]}))

if __name__ == '__main__':
    main()
