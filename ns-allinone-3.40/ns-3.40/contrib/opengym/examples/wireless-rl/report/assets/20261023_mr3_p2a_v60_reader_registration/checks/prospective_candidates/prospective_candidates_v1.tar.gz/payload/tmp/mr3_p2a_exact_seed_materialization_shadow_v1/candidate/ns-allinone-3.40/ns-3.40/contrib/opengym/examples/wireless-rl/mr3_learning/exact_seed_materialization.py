"""Fixed same-activity exact-input auxiliary fact; never a generic reader cache."""

import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time

PROFILE = "mr3-same-activity-exact-input-reuse-v1"
SCHEMA = "mr3-exact-seed-native-input-replay-v1"
WORKSPACE = Path(__file__).resolve().parents[7]
RELATIVE = Path("ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl")
WIRELESS = WORKSPACE / RELATIVE
EXTRA_SOURCES = tuple(str(RELATIVE / "mr3_learning" / name) for name in (
    "exact_seed_materialization.py", "audit_seed_inputs.py",
    "audit_reach_preparation.py", "reach_preparation.py", "preparation.py"))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def parse(raw):
    def pairs(rows):
        result = {}
        for key, value in rows:
            require(key not in result, "duplicate materialization JSON key: " + key)
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite JSON: " + value)))


def regular(path):
    path = Path(path)
    require(path.is_absolute() and path == path.resolve(strict=True)
            and stat.S_ISREG(path.lstat().st_mode), "noncanonical/nonregular materialization file: " + str(path))
    return path


def file_spec(path):
    path = regular(path)
    before = path.stat()
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    after = path.stat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
            == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
            "materialization file changed while hashing: " + str(path))
    return {"bytes": after.st_size, "sha256": digest.hexdigest()}


def profile(plan):
    selected = plan.get("audit_resource_profile")
    require(selected is None or type(selected) is str and selected == PROFILE,
            "unknown exact-input audit resource profile")
    return selected


def flag(argv, name):
    require(argv.count(name) == 1 and argv.index(name) + 1 < len(argv), "missing/repeated " + name)
    return argv[argv.index(name) + 1]


def input_argv(episode, output, plan_path):
    return ["/usr/bin/python3", "-B", "-m", "mr3_learning.audit_seed_inputs",
            "--episode", str(episode), "--output", str(output), "--plan", str(plan_path)]


def validate_plan(plan, plan_path=None):
    if profile(plan) is None:
        return
    require(plan.get("seed_rule", "legacy") != "legacy", "materialization requires an exact seed profile")
    for stage in plan["stages"]:
        leaves = sorted((job for job in stage["audits"] if re.fullmatch(r"input_[0-9]{3}", job["id"])),
                        key=lambda row: row["id"])
        eligible = stage["stage"] in ("interface", "reset")
        require(len(leaves) == (stage["expected_episodes"] if eligible else 0),
                "declared materialization input leaf coverage differs")
        full = next(job for job in stage["audits"] if job.get("role") == "full")
        require(full["depends_on"] == [job["id"] for job in leaves], "full lacks exact-input leaf dependencies")
        declared_plan = flag(full["argv"], "--plan")
        if plan_path is not None:
            require(declared_plan == str(Path(plan_path)), "full reads another materialization plan")
        for job in leaves:
            require(job.get("kind") != "aggregate" and job.get("required") is True
                    and job["argv"] == input_argv(flag(job["argv"], "--episode"), job["output"], declared_plan),
                    "noncanonical materialization input argv")
    require(set(plan.get("policy_stages", {})) <= {"minimum", "pilot", "validation"},
            "unknown policy materialization applicability")


def context(plan_path, directory):
    plan_path = regular(plan_path)
    plan_raw = plan_path.read_bytes()
    plan = parse(plan_raw)
    require(profile(plan) == PROFILE, "exact-input materialization profile was not selected")
    validate_plan(plan, plan_path)
    directory = Path(directory)
    require(directory.is_absolute() and directory == directory.resolve(strict=True) and directory.is_dir(),
            "noncanonical episode directory")
    matches = []
    for stage in plan["stages"]:
        run = Path(stage["run_directory"])
        if directory.parent.parent == run:
            matches.append((stage["stage"], run, stage))
    for name, stage in plan.get("policy_stages", {}).items():
        run = Path(stage["run_directory"])
        if directory.is_relative_to(run):
            parts = directory.relative_to(run).parts
            if (len(parts) == 4 and parts[0] == "native"
                    and re.fullmatch(r"round[0-9]{4,}", parts[1])
                    and re.fullmatch(r"worker[0-9]+", parts[2])
                    and re.fullmatch(r"episode[0-9]{3}_[a-z]+_[0-9]+", parts[3])):
                matches.append((name, run, stage))
    require(len(matches) == 1, "episode is not uniquely owned by this activity plan")
    name, run, stage = matches[0]
    require(re.fullmatch(r"worker[0-9]+", directory.parent.name)
            and re.fullmatch(r"episode[0-9]{3}_[a-z]+_[0-9]+", directory.name),
            "episode path is not a declared native layout")
    if name in {row["stage"] for row in plan["stages"]}:
        argv = stage["native"]["argv"]
        expected = {run / f"worker{worker}" / (f"episode{number:03d}_" + item.replace(":", "_"))
            for worker in range(int(flag(argv, "--workers")))
            for number, item in enumerate(flag(argv, "--schedule").split(","), 1)}
        require(directory in expected, "episode differs from fixed stage workload")
    eligible = name in ("interface", "reset")
    leaves = [job for job in stage.get("audits", []) if re.fullmatch(r"input_[0-9]{3}", job["id"])
              and flag(job["argv"], "--episode") == str(directory)]
    require(len(leaves) == (1 if eligible else 0), "eligible exact-input origin is missing/ambiguous")
    return plan, {"plan_path": str(plan_path), "plan_sha256": hashlib.sha256(plan_raw).hexdigest(),
                  "stage": name, "run_directory": str(run), "episode": str(directory)}, (leaves[0] if leaves else None)


def environment_sha256():
    env = dict(os.environ)
    for name in ("PYTHONPATH", "PYTHONHOME"):
        env.pop(name, None)
    env.update(PYTHONNOUSERSITE="1", PYTHONDONTWRITEBYTECODE="1")
    return hashlib.sha256(canonical(env)).hexdigest()


def runtime_mappings():
    # Same split/device/inode checks as native_custody.mapped_lines, for all
    # observed regular file-backed images of this system input process.
    selected = {}
    for line in Path("/proc/self/maps").read_text().splitlines():
        fields = line.split(maxsplit=5)
        if len(fields) < 5 or int(fields[4]) == 0:
            continue  # anonymous/non-file-backed mappings are outside this scope
        require(len(fields) == 6 and fields[5].startswith("/") and not fields[5].endswith(" (deleted)"),
                "unverifiable/deleted named runtime mapping")
        literal = fields[5]
        resolved = Path(literal).resolve(strict=True)
        info = regular(resolved).stat()
        major, minor = [int(value, 16) for value in fields[3].split(":")]
        require(info.st_ino == int(fields[4])
                and (os.major(info.st_dev), os.minor(info.st_dev)) == (major, minor),
                "runtime mapped object differs from its actual device/inode")
        record = selected.setdefault(literal, {"resolved_path": str(resolved), "device": fields[3],
            "inode": int(fields[4]), "mapping_lines": []})
        record["mapping_lines"].append(line)
    require(selected, "no verifiable regular file-backed runtime mappings")
    return selected


def runtime_files():
    paths = {str(Path(module.__file__).resolve()) for module in tuple(sys.modules.values())
             if getattr(module, "__file__", None) and Path(module.__file__).is_file()}
    paths.add(str(Path("/usr/bin/python3").resolve(strict=True)))
    mappings = runtime_mappings()
    modules = {path: file_spec(path) for path in sorted(paths)}
    files = {literal: {**record, **file_spec(record["resolved_path"])} for literal, record in mappings.items()}
    require(runtime_mappings() == mappings, "regular runtime mappings changed during capture")
    return {"python_module_files": modules, "file_backed_mappings": files,
        "scope": "origin system input process: loaded Python files and observed regular file-backed mappings at verdict; not full Conda mapped-set identity"}


def sources(plan, result):
    frozen = result["freeze"]
    require(type(frozen) is str and re.fullmatch(r"[0-9a-f]{40}", frozen), "exact materialization freeze required")
    require(subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=WORKSPACE, text=True).strip() == frozen,
            "materialization current HEAD differs from native freeze")
    proof = result["source_proof"]
    pure = Path("ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/multi_robot_exploration")
    names = ("__init__.py", "mr3_observation.py", "mr3_episode.py", "mr3_seed_certificate.py", "mr3_reach_geometry.py")
    if result.get("start_graph_rule", "original-seed-cell") != "original-seed-cell":
        names += ("mr3_point_graph.py",)
    expected_proof = {str(RELATIVE / "mr3_learning" / name) for name in (
        "audit_seed_inputs.py", "navigation_archive.py", "supervisor.py")}
    expected_proof.add("ros2_ws/ros2-multi-robot-automap/scripts/mr3_env_worker.py")
    expected_proof.update(str(pure / name) for name in names)
    require(type(proof) is dict and set(proof) == expected_proof, "incomplete exact-input source proof")
    result_sources = {}
    for relative in sorted(set(proof) | set(EXTRA_SOURCES)):
        path = Path(relative)
        require(not path.is_absolute() and ".." not in path.parts, "invalid materialization source path")
        raw = subprocess.check_output(["git", "show", frozen + ":" + relative], cwd=WORKSPACE)
        expected = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
        require(file_spec(WORKSPACE / path) == expected
                and plan["source_bindings"].get(relative) == expected["sha256"],
                "materialization current/frozen/plan source differs: " + relative)
        if relative in proof:
            require(proof[relative] == {"sha256": expected["sha256"], "git_source": frozen + ":" + relative},
                    "origin exact-input source proof differs")
        result_sources[relative] = expected
    return result_sources


def closure(result, directory):
    directory = Path(directory)
    bindings, resolution = result["input_bindings"], result["encoded_input_resolution"]
    require(type(bindings) is dict and bindings and type(resolution) is dict and resolution,
            "origin lacks complete encoded input/resolution bindings")
    require(set(resolution.values()) == set(bindings), "encoded input resolution coverage differs")
    for requested, encoded in resolution.items():
        requested = Path(requested)
        require(requested.is_relative_to(directory), "origin input escapes its episode")
        selected = requested if requested.exists() else Path(str(requested) + ".gz")
        require(str(regular(selected)) == encoded, "plain/gzip resolution changed")
    for path, expected in bindings.items():
        require(file_spec(path) == expected, "original encoded input changed: " + path)
    inventory = {}
    for folder, pattern in (("snapshots", "*.json"), ("maps", "*.json.gz")):
        base = directory / "observation_inputs" / folder
        require(base.is_dir() and base == base.resolve(strict=True), "archive directory is not canonical")
        inventory[folder] = sorted(str(regular(path)) for path in base.glob(pattern))
    require(inventory == result["encoded_archive_members"], "archive membership differs from actual replay verdict")
    require(len(inventory["snapshots"]) == result["exact_full_snapshot_replays"], "snapshot membership count differs")
    return {"encoded_inputs": bindings, "input_resolution": resolution, "directory_members": inventory,
            "closed_summary": file_spec(directory / "summary.json")}


def result_identity(result, plan, directory):
    metadata = parse(regular(Path(directory) / "metadata.json").read_bytes())
    require(result.get("schema") == SCHEMA and result.get("passed") is True and result.get("errors") == []
            and result.get("episode") == str(directory) and result.get("freeze") == metadata.get("freeze")
            and result.get("seed_rule") == metadata.get("seed_rule") == plan.get("seed_rule")
            and result.get("start_graph_rule", "original-seed-cell")
                == metadata.get("start_graph_rule", "original-seed-cell") == plan.get("start_graph_rule", "original-seed-cell")
            and metadata.get("reach_geometry_rule", "binary-cone-v1") == plan.get("reach_geometry_rule", "binary-cone-v1")
            and metadata.get("safety_contract") == "mr3-reach-v1"
            and result.get("whole_observation_and_seven_map_replay_passed") is True
            and type(result.get("exact_full_snapshot_replays")) is int and result["exact_full_snapshot_replays"] > 0,
            "origin exact-input scientific identity/PASS differs")
    require(type(metadata.get("epoch")) is str and bool(metadata["epoch"]), "invalid origin epoch")
    return {"freeze": metadata["freeze"], "epoch": metadata["epoch"], "seed_rule": metadata["seed_rule"],
            "start_graph_rule": metadata.get("start_graph_rule", "original-seed-cell"),
            "reach_geometry_rule": metadata.get("reach_geometry_rule", "binary-cone-v1")}


def seal_origin(result, plan_path, output):
    plan, key, job = context(plan_path, result["episode"])
    if job is None:
        result["exact_seed_execution"] = {"execution_kind": "not_applicable_actual_helper",
            "profile": PROFILE, "reason": "plan stage has no upstream input leaves"}
        return result
    require(job["output"] == str(output), "origin is not its declared input leaf output")
    require(sys.executable == "/usr/bin/python3" and sys.dont_write_bytecode
            and "PYTHONHOME" not in os.environ and "PYTHONPATH" not in os.environ
            and os.environ.get("PYTHONNOUSERSITE") == os.environ.get("PYTHONDONTWRITEBYTECODE") == "1",
            "origin input interpreter/environment is not canonical")
    result["origin_materialization"] = {"schema": PROFILE, "key": {**key, **result_identity(result, plan, result["episode"]),
        "input_job_id": job["id"]}, "environment_sha256": environment_sha256(),
        "runtime_files": runtime_files(), "sources": sources(plan, result),
        "closure": closure(result, result["episode"])}
    return result


def proc_identity(pid):
    try:
        fields = (Path("/proc") / str(pid) / "stat").read_text().rsplit(")", 1)[1].split()
        return {"pid": pid, "start_ticks": int(fields[19])}
    except FileNotFoundError:
        return None


def reuse(plan_path, directory):
    """Return None only for a plan-declared stage without upstream input leaves."""
    started = time.monotonic_ns()
    plan, key, job = context(plan_path, directory)
    if job is None:
        return None
    output, receipt_path = regular(job["output"]), regular(job["receipt"])
    output_raw, receipt_raw = output.read_bytes(), receipt_path.read_bytes()
    result, receipt = parse(output_raw), parse(receipt_raw)
    require(type(result) is dict and type(receipt) is dict, "invalid origin result/receipt")
    origin = result["origin_materialization"]
    require(origin["schema"] == PROFILE and origin["key"]
            == {**key, **result_identity(result, plan, directory), "input_job_id": job["id"]},
            "origin activity/freeze/epoch/plan key differs")
    require(receipt.get("schema") == "mr3-reach-native-wait-v1"
            and receipt.get("safety_contract") == "mr3-reach-v1"
            and receipt.get("id") == job["id"] and receipt.get("role") == job.get("role")
            and receipt.get("freeze") == result["freeze"] and receipt.get("plan_sha256") == key["plan_sha256"]
            and receipt.get("argv") == receipt.get("command_argv") == job["argv"]
            and receipt.get("cwd") == str(WIRELESS) and receipt.get("output") == str(output)
            and receipt.get("receipt") == str(receipt_path) and receipt.get("console") == job["console"]
            and receipt.get("required") is True and receipt.get("result_pass_key") == "passed"
            and receipt.get("execution_kind") == "subprocess_waited" and receipt.get("passed") is True
            and type(receipt.get("returncode")) is int and receipt["returncode"] == 0 and receipt.get("errors") == []
            and receipt.get("output_sha256") == hashlib.sha256(output_raw).hexdigest(),
            "origin lacks its exact genuine successful subprocess receipt")
    before, after = receipt.get("started_wall_monotonic_ns"), receipt.get("ended_wall_monotonic_ns")
    child, launcher = receipt.get("process_identity"), receipt.get("launcher_identity")
    require(type(before) is int and type(after) is int and 0 < before <= after <= started
            and type(child) is dict and type(launcher) is dict
            and type(launcher.get("pid")) is int and launcher["pid"] > 0
            and type(launcher.get("start_ticks")) is int and launcher["start_ticks"] > 0
            and type(child.get("pid")) is int and child["pid"] > 0
            and type(child.get("start_ticks")) is int and child["start_ticks"] > 0
            and child.get("parent") == launcher.get("pid") and receipt.get("pid") == child["pid"]
            and receipt.get("benchmark_parent") == child and receipt.get("coordinator_identity") == launcher,
            "origin real wait/child start identity missing")
    now = proc_identity(child["pid"])
    require(now is None or now["start_ticks"] != child["start_ticks"], "origin input reader identity is still present")
    require(origin["environment_sha256"] == environment_sha256(), "origin canonical environment differs")
    runtime = origin["runtime_files"]
    require(type(runtime) is dict and runtime.get("python_module_files") and runtime.get("file_backed_mappings"),
            "origin observed runtime closure empty")
    for path, expected in runtime["python_module_files"].items():
        require(file_spec(path) == expected, "origin interpreter/loaded Python dependency changed")
    for literal, expected in runtime["file_backed_mappings"].items():
        path = regular(expected["resolved_path"])
        info = path.stat()
        major, minor = [int(value, 16) for value in expected["device"].split(":")]
        require(str(Path(literal).resolve(strict=True)) == str(path) and info.st_ino == expected["inode"]
                and (os.major(info.st_dev), os.minor(info.st_dev)) == (major, minor)
                and file_spec(path) == {key: expected[key] for key in ("bytes", "sha256")},
                "origin regular mapped runtime file changed/replaced")
    require(origin["sources"] == sources(plan, result), "origin frozen source closure changed")
    require(origin["closure"] == closure(result, directory), "origin complete encoded file/membership closure changed")
    require(output.read_bytes() == output_raw and receipt_path.read_bytes() == receipt_raw,
            "origin result/receipt changed during validation")
    require(origin["closure"] == closure(result, directory), "inputs changed before reuse verdict")
    require(origin["sources"] == sources(plan, result), "sources changed before reuse verdict")
    require(file_spec(plan_path)["sha256"] == key["plan_sha256"], "plan changed before reuse verdict")
    result["exact_seed_execution"] = {"execution_kind": "verified_same_activity_fact", "profile": PROFILE,
        "origin_result": {"path": str(output), "bytes": len(output_raw), "sha256": hashlib.sha256(output_raw).hexdigest()},
        "origin_receipt": {"path": str(receipt_path), "bytes": len(receipt_raw), "sha256": hashlib.sha256(receipt_raw).hexdigest()},
        "origin_child_identity": child, "origin_returncode": receipt["returncode"],
        "origin_execution_kind": receipt["execution_kind"], "origin_freshgone_observation": now,
        "validation_started_monotonic_ns": started, "validation_ended_monotonic_ns": time.monotonic_ns()}
    return result
