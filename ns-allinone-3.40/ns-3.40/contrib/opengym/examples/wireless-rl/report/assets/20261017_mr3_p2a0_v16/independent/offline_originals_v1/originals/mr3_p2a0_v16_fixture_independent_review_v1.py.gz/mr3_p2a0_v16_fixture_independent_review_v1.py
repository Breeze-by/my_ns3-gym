"""Targeted received-only V5 fixture review with versioned red/green evidence."""
import ast
import copy
import hashlib
import itertools
import json
import math
from pathlib import Path
import subprocess

ROOT = Path('/home/zhuyulab/ns3-workspace')
WIRELESS = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
SOURCES = Path('/tmp/mr3_p2a0_v16_fixture_independent_sources_v2')
SELECTORS = {'_probe_goal_order', 'probe_action', 'probe_action_v3', 'probe_action_v4',
             'probe_action_v5', '_probe_nonapproaching_goal_action', 'record_probe_v4_submission'}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load(raw, label):
    tree = ast.parse(raw)
    namespace = {'math': math}
    exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n, ast.FunctionDef)
                                 and n.name in SELECTORS], type_ignores=[]), label, 'exec'), namespace)
    return tree, namespace


def response(snapshot, action):
    return {'command': {'epoch': snapshot['epoch'], 'observation_digest': snapshot['digest'],
                        'observation_sequence': snapshot['sequence'], 'action': action,
                        'command_id': snapshot['sequence']}}


def main():
    files = {str(path): path.read_bytes() for path in SOURCES.glob('*.py')}
    source = SOURCES / 'benchmark.py'
    tree, new = load(files[str(source)], str(source))
    old_raw = files[str(SOURCES / 'old_frozen_v4_benchmark.py')]
    old_tree, old = load(old_raw, str(SOURCES / 'old_frozen_v4_benchmark.py'))
    frozen = subprocess.check_output(['git', 'show',
        '17ef3cb212aacd6e9e4fcde65783bdf2528da955:'
        + (WIRELESS / 'mr3_learning/benchmark.py').relative_to(ROOT).as_posix()], cwd=ROOT)
    assert old_raw == frozen
    assert sha(files[str(source)]) == 'a72e64f00257505f29bdb974aba8d00c2d3ecd15915c33b2e2004b529a11b4b2'
    filter_goal = new['_probe_nonapproaching_goal_action']
    findings = []

    # Preserve meaningful old-finite-input RED and prove final GREEN on same input.
    counter = json.loads(Path('/tmp/mr3_p2a0_v16_filter_overflow_counterexample_v1.json').read_bytes())
    old_filter_raw = Path(counter['source']).read_bytes()
    assert sha(old_filter_raw) == counter['source_sha256']
    _, old_filter = load(old_filter_raw, counter['source'])
    assert old_filter['_probe_nonapproaching_goal_action'](counter['snapshot'], 88) is True
    assert filter_goal(counter['snapshot'], 88) is False
    findings.append({'check': 'preserved swallowed-NaN original RED now rejects exact same input',
                     'passed': True, 'old_returned': True, 'final_returned': False})

    base = {'robots': [{'name': 'tb1', 'x': 0., 'y': 0., 'fresh': True, 'valid': True},
                       {'name': 'tb2', 'x': 0., 'y': 1., 'fresh': True, 'valid': True},
                       {'name': 'tb3', 'x': 0., 'y': 2., 'fresh': True, 'valid': True}],
            'candidates': [{'x': 2., 'y': 0., 'path_distances_m': [1., 1., 1.]}]}
    assert filter_goal(base, 88) is True  # Exact perpendicular/zero is eligible.
    close = copy.deepcopy(base)
    close['candidates'][0]['y'] = 1e-15
    assert filter_goal(close, 88) is False
    cases = []
    for key, value in (('fresh', False), ('fresh', 1), ('valid', False), ('x', None),
                       ('x', float('nan')), ('x', float('inf')), ('y', True), ('x', 10 ** 500)):
        item = copy.deepcopy(base)
        item['robots'][2][key] = value
        cases.append((str(key) + ':' + repr(value), item))
    for key, value in (('x', None), ('y', False), ('x', float('inf'))):
        item = copy.deepcopy(base)
        item['candidates'][0][key] = value
        cases.append(('goal:' + key + ':' + repr(value), item))
    goal_zero = copy.deepcopy(base)
    goal_zero['candidates'][0].update(x=0., y=0.)
    cases.append(('zero goal distance', goal_zero))
    peer_zero = copy.deepcopy(base)
    peer_zero['robots'][2].update(x=0., y=0.)
    cases.append(('coincident peer', peer_zero))
    tiny = copy.deepcopy(base)
    tiny['candidates'][0].update(x=1e-200, y=0.)
    tiny['robots'][1].update(x=0., y=1e-200)
    cases.append(('underflowed denominator', tiny))
    for label, item in cases:
        assert filter_goal(item, 88) is False, label
        assert filter_goal(item, 888) is True and filter_goal(item, 999) is True
    findings.append({'check': 'fresh typed/finite/unknown/zero and underflow boundaries fail closed for GOAL',
                     'passed': True, 'mutation_cases': len(cases),
                     'exact_zero_margin_allowed': True, 'negative_1e_15_rejected': True,
                     'all_KEEP_or_WAIT_not_newly_geometry_blocked': True})

    # Actual frozen received snapshots only: replay selector state synthetically.
    episode = ROOT / ('ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/'
                      'mr3_p2a0_20261017_v15_interface/worker0/episode001_open_101')
    transition_path = episode / 'transitions.jsonl'
    transition_raw = transition_path.read_bytes()
    records = [json.loads(line) for line in transition_raw.splitlines()]
    old_state, new_default_state, v5_state = {}, {}, {}
    v5_prefix, first_change = [], None
    for row in records[:-1]:
        snapshot = row['snapshot']
        snapshot_before = json.dumps(snapshot, sort_keys=True, separators=(',', ':'))
        a = old['probe_action_v4'](snapshot, old_state)
        b = new['probe_action_v4'](snapshot, new_default_state)
        assert a == b and old_state == new_default_state
        old['record_probe_v4_submission'](old_state, response(snapshot, a))
        new['record_probe_v4_submission'](new_default_state, response(snapshot, b))
        assert old_state == new_default_state
        if snapshot['task_elapsed_sec'] <= 13:
            v5 = new['probe_action_v5'](snapshot, v5_state)
            assert snapshot['joint_action_mask'][v5] is True
            assert filter_goal(snapshot, v5) is True
            if v5 != a and first_change is None:
                first_change = snapshot['task_elapsed_sec']
            margins = []
            for index, choice in enumerate((v5 // 100, v5 // 10 % 10, v5 % 10)):
                if choice >= 8:
                    continue
                own, goal = snapshot['robots'][index], snapshot['candidates'][choice]
                gx, gy = goal['x'] - own['x'], goal['y'] - own['y']
                for peer_index, peer in enumerate(snapshot['robots']):
                    if index == peer_index:
                        continue
                    px, py = peer['x'] - own['x'], peer['y'] - own['y']
                    margin = -(gx * px + gy * py) / (math.hypot(gx, gy) * math.hypot(px, py))
                    assert math.isfinite(margin) and margin >= 0
                    margins.append(margin)
            v5_prefix.append({'t': snapshot['task_elapsed_sec'], 'v4_action': a, 'v5_action': v5,
                              'minimum_new_goal_margin': min(margins) if margins else None})
            new['record_probe_v4_submission'](v5_state, response(snapshot, v5))
        assert json.dumps(snapshot, sort_keys=True, separators=(',', ':')) == snapshot_before
    assert v5_prefix[0]['v5_action'] == 412
    assert v5_prefix[-1]['t'] == 13 and v5_prefix[-1]['v5_action'] == 321
    assert first_change == 13
    findings.append({'check': 'V4 defaults exact actions+diagnostics and V5 received-prefix branch',
                     'passed': True, 'V4_equivalent_steps': len(records) - 1,
                     'first_V5_change_sec': first_change, 'prefix': v5_prefix,
                     'scope': 'Lifecycle receipts above are synthetic exact matching commands, '
                              'not new native acceptance/cancellation/physical credit.'})

    old_functions = {n.name: n for n in old_tree.body if isinstance(n, ast.FunctionDef)}
    functions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
    unchanged = ('_probe_goal_order', 'probe_action', 'probe_action_v3',
                 'record_probe_v4_submission', '_new_preparation_abort',
                 '_preparation_failure', '_abort_requested')
    for name in unchanged:
        assert ast.dump(old_functions[name]) == ast.dump(functions[name])
    normalized_v4 = copy.deepcopy(functions['probe_action_v4'])
    assert len(normalized_v4.args.kwonlyargs) == 1
    assert normalized_v4.args.kwonlyargs[0].arg == 'nonapproaching_goals'
    assert isinstance(normalized_v4.args.kw_defaults[0], ast.Constant)
    assert normalized_v4.args.kw_defaults[0].value is False
    normalized_v4.args.kwonlyargs.clear()
    normalized_v4.args.kw_defaults.clear()
    removed = 0
    for node in normalized_v4.body:
        if (isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)
                and node.targets[0].id == 'legal'):
            assert len(node.value.elt.values) == 3
            condition = node.value.elt.values.pop()
            assert ast.unparse(condition) == ('not nonapproaching_goals or '
                                              '_probe_nonapproaching_goal_action(snapshot, action)')
            removed += 1
    normalized_v4.body = [node for node in normalized_v4.body if not
        (isinstance(node, ast.If) and isinstance(node.test, ast.Name)
         and node.test.id == 'nonapproaching_goals')]
    assert removed == 1 and ast.dump(normalized_v4) == ast.dump(old_functions['probe_action_v4'])
    for name in ('probe_action_v5', '_probe_nonapproaching_goal_action'):
        text = ast.unparse(functions[name])
        assert not any(word in text for word in ('ModelStates', 'truth', 'raw_guard',
                                                 'own_odom', 'open(', 'read_text'))
    findings.append({'check': 'old ranking/submission/abort AST exact and V4 default branch restoration',
                     'passed': True, 'unchanged_functions': list(unchanged),
                     'default_V4_AST_equal_after_only_explicit_disabled_V5_branch_removal': True,
                     'no_global_monkeypatch_raw_guard_or_truth_reads': True})
    for path, content in files.items():
        assert Path(path).read_bytes() == content
    assert transition_path.read_bytes() == transition_raw
    actual_source = Path('/tmp/mr3_p2a0_v16_stimulus_v5_proposal/benchmark.py')
    assert actual_source.read_bytes() == files[str(source)]
    report = {'schema': 'mr3-v16-fixture-independent-review-v1', 'passed': True,
              'sources': {path: {'bytes': len(content), 'sha256': sha(content)}
                          for path, content in files.items()},
              'source_stable_before_after': True,
              'actual_received_fixture': {'path': str(transition_path), 'sha256': sha(transition_raw)},
              'checks': findings,
              'scope_findings': {
                  'actor_observation_or_real_joint_mask_changed': False,
                  'original_snapshot_mutated': False,
                  'navigation_or_guard_or_physics_changed': False,
                  'new_A_and_B_stopping_requirement': False,
                  'ranking': 'After eligible received straight-direction GOAL screening only: '
                             'existing GOAL count, reverse opportunity, outward min/sum, path, ID.',
                  'freshness': 'Explicit valid/fresh booleans reuse the frozen received '
                               'snapshot contract; this selector is not an independent '
                               'source-age/epoch/receipt validator.',
                  'diagnostics': 'max_legal_goal_components from reused v3 is now within '
                                 'the external eligible subset. Do not call this actor-mask '
                                 'candidate availability; original snapshot remains authoritative.',
                  'first_phase_limit': 't0 remains412; original first-goal geometry can still '
                                       'evolve as peers move. V5 does not repair or prove '
                                       'first-phase motion/95-percent task capability.',
                  'second_phase_hypothesis': 't13 becomes321 using still-original received '
                                             'state. This changes an external stimulus conflict; '
                                             'it does not prove the closed-loop new trajectory, '
                                             'forward availability, turn/stop coverage, sampled '
                                             'model, activity, contacts or strict shutdown.',
                  'future_safety': 'No simulated trajectory or future-peer guarantee; '
                                   'all original native/formal hard gates remain required.'},
              'execution_scope': 'Targeted pure CPU synthetic/recorded received-prefix '
                                 'selector checks only, no author suite repeated; no native, '
                                 'formal rerun, ModelStates/control or Git edits.'}
    output = Path('/tmp/mr3_p2a0_v16_fixture_independent_review_v1.json')
    with output.open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'passed': True, 'check_groups': len(findings), 'output': str(output),
                      'sha256': sha(output.read_bytes()), 't0': v5_prefix[0], 't13': v5_prefix[-1]}))


if __name__ == '__main__':
    main()
