"""Read-only final plan/runner/launcher/monitor wiring checks; no native execution."""
import ast
import hashlib
import json
from pathlib import Path

ROOT=Path('/home/zhuyulab/ns3-workspace')
A=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v10'
FILES=[A/'predeclared_plan_v10.json',*[A/'independent'/n for n in ('mr3_p2a0_v10_audit_stage.py','mr3_p2a0_v10_launch_stage.py','mr3_v10_multiepoch_closure_binary_review_v1.py','mr3_readonly_v10_drive_process_monitor.py','mr3_v10_fifo_phase_review.py')]]
raw={str(p):p.read_bytes()for p in FILES};sha=lambda b:hashlib.sha256(b).hexdigest()
plan=json.loads(raw[str(FILES[0])]);runner=raw[str(FILES[1])].decode();launcher=raw[str(FILES[2])].decode();closure=raw[str(FILES[3])].decode();monitor=raw[str(FILES[4])].decode()
checks=[]
def check(value,message,**extra):
 checks.append(dict(passed=bool(value),check=message,**extra))
check(sha(raw[str(FILES[0])])=='0456d6100e44bf93afe66edf2d057d5c71161dbbdcdd2f12cbf37f0fe63a1e52','root final plan exact SHA')
bindings=[]
for b in plan['independent_source_bindings']:
 p=ROOT/b['path']; actual=sha(p.read_bytes())if p.is_file()else None
 bindings.append(dict(**b,actual_sha256=actual,passed=actual==b['sha256']))
check(len(bindings)==59 and all(b['passed']for b in bindings),'all final59 independent bindings exact')
check('PENDING' not in raw[str(FILES[0])].decode(),'no pending source pin placeholders')
check("extra=('--binary-proof', '/tmp/mr3_p2a0_v10_binaryproof.json')"in runner,'drive CLI receives required binary proof')
check("Path('/tmp/mr3_p2a0_v10_binaryproof.json')"in closure,'closure uses identical binary proof path')
common={'full_audit','drive_review_v1','settled_review_v1','closure_binary_review_v1','information_review_v1','peer_review_v1','control_review_v1'}
stage_rows=[]
for s in plan['stages']:
 name=s['stage']; prefix='/tmp/mr3_p2a0_v10_'+name+'_';labels=set(common)
 if name=='interface':labels|={'input_review_v1','fixed_angular_v1','fixed_physics_v1'}
 if name=='reset':labels|={'input_review_v1','angular_matrix_v1','physics_matrix_v1'}
 actual={prefix+x+'.json'for x in labels};required=set(s['required_audit_receipts'])
 check(actual==required,'exact mandatory stage output set '+name,missing=sorted(required-actual),extra=sorted(actual-required))
 cmd=s['command']; cli=lambda key:cmd[cmd.index(key)+1]
 run=Path(cli('--output-root'))/cli('--run-id')
 check(str(run)==s['run_directory'],'benchmark output-root/run-id matches audit directory '+name)
 for key in ('information','peer','control','settled_turn'):
  values=s[key+'_audit_command_template'];output=values[values.index('--output')+1]
  check(values[2]==s['run_directory'] and output in required and values[values.index('--freeze')+1]=='{freeze}','template directory/output/freeze '+name+'/'+key)
  check(('--peer-only'in values)==(key=='peer'),'peer-only scope '+name+'/'+key)
  check(('--require-use'in values)==(name=='interface'and key=='settled_turn'),'interface-only require-use '+name+'/'+key)
 stage_rows.append(dict(stage=name,run_directory=s['run_directory'],required_receipts=sorted(required),worker_bindings=s['worker_bindings']))
check("for formal in specification[\"required_audit_receipts\"]"in launcher and 'receipt.get("passed") is True'in launcher and 'receipt["freeze"] == freeze'in launcher,'launcher requires all preceding formal passedTrue and matching declared freeze')
check('preflight["plan_sha256"] == hashlib.sha256(plan_raw).hexdigest()'in launcher,'launcher binds final preflight to actual plan bytes')
check('"@{u}"'in launcher and '"status", "--porcelain"'in launcher,'launcher requires clean pushed HEAD')
check('remaining >= specification["wall_ceiling_seconds"]'in launcher and 'duration <= specification["wall_ceiling_seconds"]'in launcher,'finite stage budget and predecessor duration gates')
check("freeze=False, output=per_episode,\n                     required=False"in runner and "extra=('--per-episode-report', str(per_episode))"in runner,'raw reset physical FAIL preserved; pooled wrapper mandatory')
check("len(leaves) == 8 and all(v['passed'] for v in leaves)"in runner,'reset input requires all8 independent leaves without interface pooling')
check("glob(a.prefix+'_process_monitor_*.json')"in closure,'closure live monitor discovery wildcard')
monitor_names={s['stage']:str(Path('/tmp')/('mr3_p2a0_v10_'+s['stage']+'_process_monitor_001.json'))for s in plan['stages']}
for name,path in monitor_names.items():
 check(Path(path).match('mr3_p2a0_v10_'+name+'_process_monitor_*.json'),'proposed monitor filename discoverable '+name)
check("'_episode'+str(episode_index).zfill(3)+'_fifo_phase_final.json'"in closure and "'_fifo_phase_final'"in runner,'per-episode FIFO output/discovery exact')
check("(worker['pid'],worker['start_ticks']) in mapped_workers"in closure and "pid=saved['parent']"in closure,'closure requires live gz mapped-binary proof tied to every actual worker PID/start ancestry')
check("identity_still_same_after_maps"in closure and "all(x['matches_declared_binary'] for x in g['mappings'])"in closure,'closure requires current file SHA plus mapping inode/device and PID identity evidence')
check("control-chain reader remain complete acceptance gates including bootstrap and stop authorization"in raw[str(FILES[5])].decode(),'FIFO observer explicitly does not replace strict three-storage/bootstrap/stop readers')
for p in FILES:check(p.read_bytes()==raw[str(p)],'reviewed input unchanged during read '+p.name)
previous=json.loads(Path('/tmp/mr3_p2a0_v10_audit_runner_fixtures_checks_v1.json').read_text())
check(previous['passed']is True and previous['source_sha256']==sha(raw[str(FILES[1])]),'prior13 unchanged actual runner main CLI fixtures remain source-exact; old plan snapshot retained')
result={'schema':'mr3-v10-final-plan-command-independent-review-v2','passed':all(x['passed']for x in checks),'source_freeze':'pending','native_starts':0,'source_bindings':{p:sha(b)for p,b in raw.items()},'checks':checks,'stage_command_outputs':stage_rows,'independent_bindings':bindings,'monitor_output_examples':monitor_names,'monitor_admission_note':'Launch stage does not run the observer itself. During every live worker epoch, run the read-only monitor using a discoverable STAGE_process_monitor_NNN.json output. Strict closure fails if any worker lacks live actual gz mapping ancestry; an early empty startup monitor alone grants no proof.','required_gate_scope':'Every mandatory receipt matches actual CLI/output. Original immutable physical/angular/input source semantics remain, reset per-episode missing stop FAIL retained while pooled matrix mandatory, full/drive/info/peer/control/settled/closure independently required. Terminal/deadline gain no activity or meaningful-stop credit.','limits':'Static/read-only source review plus previously archived deliberate subprocess/Git mock fixtures, not native simulation/acceptance. Final freeze is not created by this review.'}
out=Path('/tmp/mr3_p2a0_v10_final_plan_command_review_v2.json')
with out.open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':result['passed'],'checks':len(checks),'failed':[x for x in checks if not x['passed']],'output':str(out),'sha256':sha(out.read_bytes())}))
