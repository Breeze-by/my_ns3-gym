"""CPU counterexamples for owned process and actual ELF mapping admission."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time
import unittest

spec = importlib.util.spec_from_file_location("witness", "/tmp/mr3_p2a0_v18_live_admission_v1.py")
w = importlib.util.module_from_spec(spec)
spec.loader.exec_module(w)


class Admission(unittest.TestCase):
    def test_actual_own_identity_and_ancestry(self):
        current = w.identity(os.getpid())
        self.assertEqual(w.ancestry(os.getpid(), current)[0]["start_ticks"], current["start_ticks"])
        with self.assertRaisesRegex(ValueError, "reused"):
            w.ancestry(os.getpid(), {**current, "start_ticks": current["start_ticks"] + 1})

    def test_actual_child_is_owned_and_reaped(self):
        child = subprocess.Popen(["/usr/bin/sleep", "0.1"])
        try:
            rows = w.ancestry(child.pid, w.identity(os.getpid()))
            self.assertEqual(rows[0]["pid"], child.pid)
            self.assertEqual(rows[-1]["pid"], os.getpid())
        finally:
            self.assertEqual(child.wait(), 0)
        self.assertIsNone(w.identity(child.pid))

    def test_actual_proc_maps_inode_device(self):
        maps = Path(f"/proc/{os.getpid()}/maps").read_bytes()
        library = next(line.split(None, 5)[5] for line in maps.decode().splitlines()
                       if len(line.split(None, 5)) == 6 and "/libc.so.6" in line)
        self.assertTrue(w.mapped(maps, library))
        with self.assertRaisesRegex(ValueError, "device/inode"):
            altered = b"\n".join(
                (line.replace(line.split()[4], b"1", 1) if library.encode() in line else line)
                for line in maps.splitlines())
            w.mapped(altered, library)
        with self.assertRaisesRegex(ValueError, "absent"):
            w.mapped(b"", library)

    def test_partial_configuration_never_admitted(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "row.jsonl"
            path.write_bytes(b'{"kind":"configuration"}')
            with self.assertRaises(FileNotFoundError):
                w.header(path)
            path.write_bytes(b'{"kind":"configuration"}\n')
            row, proof = w.header(path)
            self.assertEqual(row["kind"], "configuration")
            self.assertEqual(proof["first_line_sha256"], w.sha(path.read_bytes()))

    def test_immutable_read_hash(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "binary"
            path.write_bytes(bytes(range(256)))
            raw, proof = w.read(path)
            self.assertEqual(proof["sha256"], w.sha(raw))
            self.assertEqual(proof["bytes"], 256)


if __name__ == "__main__":
    started = time.monotonic()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(Admission)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    Path("/tmp/mr3_p2a0_v18_live_admission_checks_v3.json").write_text(json.dumps({
        "schema": "mr3-cpu-check-execution-v1", "passed": result.wasSuccessful(),
        "tests": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
        "wall_seconds": time.monotonic() - started, "source_sha256": w.sha(Path(w.__file__).read_bytes()),
        "test_source_sha256": w.sha(Path(__file__).read_bytes()),
        "scope": "CPU process/maps/file counterexamples; no Gazebo/ROS/native run"}, indent=2) + "\n")
    raise SystemExit(0 if result.wasSuccessful() else 1)
