#!/usr/bin/python3
"""Selection-only fake files; no codec, native, formal or active input read."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

SOURCE=Path(__file__).with_name('mr3_p2a0_v22_matrix_pack_closed_v1.py')
spec=importlib.util.spec_from_file_location('v22_pack_preparation', SOURCE)
h=importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
F='b'*40

def dump(path, value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value)+'\n')

class SelectionTests(unittest.TestCase):
    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory(prefix='mr3_v22_pack_selection_CPU_')
        self.addCleanup(self.temporary.cleanup)
        self.root=Path(self.temporary.name)
        self.temp=self.root/'tmp'
        self.temp.mkdir()
        self.base=self.root/'native'
        self.plan={'schema':'mr3-p2a0-predeclaration-v22','stages':[]}
        for stage in h.STAGES:
            run=self.base/('mr3_p2a0_20261018_v22_'+stage)
            self.plan['stages'].append({'stage':stage,'run_directory':str(run),
                'command':['python','-m','mr3_learning.benchmark','--run-id',run.name,'--output-root',str(self.base)],
                'required_audit_receipts':[str(self.temp/('mr3_p2a0_v22_'+stage+'_formal.json'))]})
        self.context=patch.multiple(h,TEMP=self.temp,BASE=self.base)
        self.context.start()
        self.addCleanup(self.context.stop)

    def test_exact_four_run_names_and_formal_prefixes(self):
        self.assertEqual(h.validate_plan(self.plan),self.plan['stages'])
        bad=copy.deepcopy(self.plan)
        bad['stages'][0]['run_directory']=str(self.base/'unrelated_native')
        with self.assertRaisesRegex(ValueError,'native root differs'):
            h.validate_plan(bad)
        bad=copy.deepcopy(self.plan)
        bad['stages'][0]['required_audit_receipts']=[str(self.temp/'wrong_epoch_formal.json')]
        with self.assertRaisesRegex(ValueError,'outside exact stage prefix'):
            h.validate_plan(bad)

    def test_every_stage_metadata_including_failed_partial_empty_nested_original(self):
        files=[]
        for stage in h.STAGES:
            for suffix in ['_failed_console.log','_audit_execution_v1.json','_corrector_mapping_001.json']:
                file=self.temp/('mr3_p2a0_v22_'+stage+suffix)
                file.write_bytes(b'' if suffix.endswith('.log') else b'{"passed":false}\n')
                files.append(file)
        nested=self.temp/'mr3_p2a0_v22_reset_failed_details/raw/stderr.log'
        nested.parent.mkdir(parents=True)
        nested.write_bytes(b'original failed stderr')
        files.append(nested)
        global_file=self.temp/h.GLOBAL_NAMES[0]
        global_file.write_bytes(b'{"event":"version_failed_later_stages_skip"}\n')
        files.append(global_file)
        extra=self.temp/'mr3_p2a0_v22_parent_actual_stdout.log'
        extra.write_bytes(b'actual root command stdout')
        files.append(extra)
        unrelated=self.temp/'mr3_p2a0_v21_interface_formal.json'
        unrelated.write_bytes(b'old source')
        selected,directories=h.metadata_selection([extra])
        self.assertEqual({x for x,stat in selected},set(files))
        self.assertTrue(directories)
        self.assertNotIn(unrelated,{x for x,stat in selected})

    def test_symlink_and_non_tmp_extra_are_rejected(self):
        outside=self.root/'outside.log'
        outside.write_bytes(b'not a selected original')
        with self.assertRaisesRegex(ValueError,'one exact original /tmp file'):
            h.metadata_selection([outside])
        (self.temp/'mr3_p2a0_v22_interface_bad.log').symlink_to(outside)
        with self.assertRaisesRegex(ValueError,'symlink not followed'):
            h.metadata_selection([])

    def closed_files(self, unfinished=False):
        plan_sha='d'*64
        common={'schema':'mr3-declared-matrix-orchestration-v2','freeze':F,'plan_sha256':plan_sha}
        rows=[dict(common,event='started'),dict(common,event='version_failed_later_stages_skip',
              stage='interface',later_stages=['terminal','reset','deadline'],error='original physics FAIL')]
        (self.temp/h.GLOBAL_NAMES[0]).write_text(''.join(json.dumps(x)+'\n' for x in rows))
        dump(self.temp/h.GLOBAL_NAMES[5],{'schema':'mr3-v22-cross-stage-mapping-complete-v1','freeze':F})
        dump(self.temp/h.GLOBAL_NAMES[1],{'freeze':F,'plan_sha256':plan_sha,'passed':True})
        dump(self.temp/'mr3_p2a0_v22_interface_launch.json',{'stage':'interface','freeze':F,
             'plan_sha256':plan_sha,'status':'completed','passed':True})
        dump(self.temp/'mr3_p2a0_v22_interface_audit_execution_v1.json',{'stage':'interface','freeze':F,
             'plan_sha256':plan_sha,'all_submitted_jobs_finished':not unfinished,'passed':False,
             'runner_errors':[],'commands':[{'passed':False,'label':'physical'}]})
        return plan_sha

    def test_closed_real_failure_and_three_later_skips_are_not_relabelled(self):
        plan_sha=self.closed_files()
        result=h.closed_metadata(self.plan,F,plan_sha,{})
        self.assertFalse(result['stages']['interface']['original_audit_execution']['passed'])
        self.assertEqual(result['orchestration_final_original']['error'],'original physics FAIL')
        for stage in ['terminal','reset','deadline']:
            self.assertTrue(result['stages'][stage]['declared_later_stage_skip'])
            self.assertIsNone(result['stages'][stage]['original_launch'])
            self.assertIsNone(result['stages'][stage]['original_audit_execution'])

    def test_unfinished_audit_refuses_selection_before_any_codec_call(self):
        plan_sha=self.closed_files(unfinished=True)
        with self.assertRaisesRegex(ValueError,'audit jobs not all drained'):
            h.closed_metadata(self.plan,F,plan_sha,{})

if __name__=='__main__':
    unittest.main()
