from pathlib import Path
import hashlib
import json

root=Path('/home/zhuyulab/ns3-workspace')
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
a=w/'report/assets/20261017_mr3_p2a0_v10';ind=a/'independent'
p=a/'predeclared_plan_v10.json';d=json.loads(p.read_text())

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def current_strings(value):
    if isinstance(value,str):
        return value.replace('mr3_p2a0_20261017_v9','mr3_p2a0_20261017_v10').replace('/tmp/mr3_p2a0_v9','/tmp/mr3_p2a0_v10')
    if isinstance(value,list):return [current_strings(v) for v in value]
    if isinstance(value,dict):return {k:current_strings(v) for k,v in value.items()}
    return value
d['stages']=current_strings(d['stages'])
for stage in d['stages']:
    if 'physics_matrix_audit_command_template' in stage:
        stage['physics_matrix_audit_command_template']=[v.replace('_reset_fixed_physics_v1.json','_reset_physical_per_episode_v1.json') for v in stage['physics_matrix_audit_command_template']]
d['scope_limits']=[s.replace('no completed v9 native result','no completed v10 native result') for s in d['scope_limits']]
d['offline_prerequisites']=[s.replace('current v9 ROS/conda','current v10 ROS/conda').replace('final v4 independent tagged-reader','final v5 independent tagged-reader with immutable v4 math') for s in d['offline_prerequisites']]
prerequisite='typed controlled state/peer/guard clients and actual publication/self-receipt/storage pipeline mutations; sticky negative ACK despite stop race; one normal target per clock even before takeover; latest tuple required at takeover'
if prerequisite not in d['offline_prerequisites']:d['offline_prerequisites'].append(prerequisite)
d['revision_reasons'][-1]='v9 actual producer ingress/selection ledger proves timer selected old TF before same-clock late fresh TF and paused10Hz starvation. V10 adds explicit20ms state/peer/guard/storage phase, permanent independent zero-stop and invalid-startup orderly closure; original freshness/body/task gates retained.'
d['new_execution_contracts'].update(controlled_execution='mr3-controlled-execution-phase-v1', controlled_state_period_sec=.02,noncontrolled_state_period_sec=.1,zero_stop='permanent phase_kind=stop; ready=false; only zero; dedicated status; never overwrite normal')
d['drive_contract']['independent_consumer']={'path':str((ind/'mr3_independent_drive_trace_v5.py').relative_to(root)),'sha256':sha(ind/'mr3_independent_drive_trace_v5.py')}
d['drive_contract']['stop_interface']='v5 extends immutable v4 only for explicitly evidenced permanent zero-stop same-clock higher sequence; no normal resume, fake self receipt, storage or physical credit; all original v4 math/160ms/source/library/body gates retained'
d['wall_budget_basis']['v8_scope']=d['wall_budget_basis']['v8_scope'].replace('predicted v9','predicted v10')
d['information_selection_audit']['consumer_sha256']=sha(ind/'mr3_independent_information_v2.py')
d['information_selection_audit']['tests_sha256']=sha(ind/'mr3_independent_information_v2_tests.py')
scope='; explicit takeover/normal commits/actual terminal cancellation and unchanged-watermark terminal drain; no new state publication in drain'
if scope not in d['information_selection_audit']['scope']:d['information_selection_audit']['scope']+=scope
core=ind/'mr3_independent_control_phase_v1.py'
tests=ind/'mr3_independent_control_phase_v1_tests.py'
assert core.is_file() and tests.is_file(),'control consumer not finalized'
d['controlled_execution_audit'].update(status='ready',consumer_sha256=sha(core),tests_sha256=sha(tests),scope='Actual callback and publication call windows with exact typed raw refs, independent original peer cloud/scan byte reconstruction, native command_received/status_publish and worker storage-before-physics; packet publication identity for identical untagged side ROS payloads is not asserted')
d['controlled_execution_audit']['asynchronous_stop_scope']='No normal advance/resume after worker actually processed stop or actively requested stop; all new guard outputs after its stop latch are zero. A guard-source stop still in DDS transit is not an atomic global cutoff: record overlaps diagnostically and retain original<=20ms terminal drain/full160ms driver/body gates, no zero-latency assertion.'
d['controlled_execution_audit']['shared_physics_dispatch']={'path':str((w/'mr3_learning/audit_controlled_physics.py').relative_to(root)),'sha256':sha(w/'mr3_learning/audit_controlled_physics.py'),'scope':'Same stdlib metadata-restricted real-zero bootstrap dispatch in engineering and policy evidence consumers; complete original raw rows passed to unchanged W7 integer/continuity/quantum math with setup-to-controlled threshold only. True task release, legacy path and policy capacity/objective unchanged; original function restored even on exception; no policy sampling or optimizer evidence.'}
d['audit_orchestration']={'script':str((ind/'mr3_p2a0_v10_audit_stage.py').relative_to(root)),'cli':'conda ns3gym python SCRIPT STAGE EXACT40; after actual native stage close only; every mandatory formal receipt required; all original exits retained; no native restart', 'reset_raw_physics_report':'The original per-episode completeness FAIL remains visible. The unchanged predeclared reset-only pooled wrapper decides matrix coverage while enforcing every raw/closure/observed eligible-response hard bound.'}
base=json.loads((w/'report/assets/20261017_mr3_p2a0_v9/predeclared_plan_v9.json').read_text())['independent_source_bindings']
assert d['independent_source_bindings'][:33]==base
newfiles=sorted(ind.glob('*.py'))
newfiles += [w/'mr3_learning'/n for n in ('audit_motion.py','audit_preparation.py','audit_ppo.py','audit_controlled_physics.py')]
newfiles += [w/'mr3_learning/tests'/n for n in ('test_audit_motion.py','test_audit_preparation.py','test_preparation_execution.py','test_audit_ppo.py','test_audit_controlled_physics.py')]
bindings={v['path']:v for v in base}
for file in newfiles:
    assert file.is_file(),file
    relative=str(file.relative_to(root));assert relative not in bindings
    bindings[relative]={'path':relative,'sha256':sha(file)}
d['independent_source_bindings']=list(bindings.values())
p.write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({'passed':True,'bindings':len(bindings),'plan_sha256':sha(p)}))
