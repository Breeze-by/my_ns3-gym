"""CPU-only old_originals fixture; never execute archive main or write Git."""
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile


OLD_SCRIPT = Path('/tmp/mr3_p2a0_v14_offline_archiver_before_selectedsha_v1.py')
NEW_SCRIPT = Path('/tmp/mr3_p2a0_v14_archive_offline_originals_v1.py')


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def main():
    old, new = load(OLD_SCRIPT, 'old_archiver'), load(NEW_SCRIPT, 'new_archiver')
    old_bytes = OLD_SCRIPT.read_bytes()
    new_bytes = NEW_SCRIPT.read_bytes()
    findings = []
    with tempfile.TemporaryDirectory(prefix='mr3_v14_native_sha_cpu_') as temporary:
        base = Path(temporary)
        selected = base / 'native_original.gz'
        raw = b'Preserved native raw bytes.\n'
        encoded = gzip.compress(raw, mtime=0)
        selected.write_bytes(encoded)
        raw_sha = hashlib.sha256(raw).hexdigest()
        encoded_sha = hashlib.sha256(encoded).hexdigest()
        manifest = base / 'manifest.json'
        old.OLD = new.OLD = base

        def row_with_sha(digest):
            manifest.write_text(json.dumps({'entries': [{
                'source': '/tmp/old_native_original', 'selected_path': str(selected),
                'raw_sha256': raw_sha, 'selected_sha256': digest}]}))

        row_with_sha('0' * 64)
        accepted_old, _ = old.old_originals()
        assert raw_sha in accepted_old
        findings.append({'case': 'old_wrong_encoded_SHA', 'raw_bytes_unchanged': True,
                         'accepted': True, 'scope': 'reproduced missing native-key check'})
        try:
            new.old_originals()
        except ValueError as failure:
            assert 'old selected encoded SHA mismatch' in str(failure)
            findings.append({'case': 'new_wrong_encoded_SHA', 'accepted': False,
                             'error': str(failure)})
        else:
            raise AssertionError('new reader accepted incorrect selected_sha256')

        row_with_sha(encoded_sha)
        accepted_new, _ = new.old_originals()
        assert raw_sha in accepted_new
        assert accepted_new[raw_sha]['selected_encoded_sha256'] == encoded_sha
        findings.append({'case': 'new_correct_encoded_SHA', 'accepted': True})
        assert selected.read_bytes() == encoded
        assert gzip.decompress(encoded) == raw
    assert OLD_SCRIPT.read_bytes() == old_bytes and NEW_SCRIPT.read_bytes() == new_bytes
    result = {'schema': 'mr3-v14-old-native-encoded-sha-regression-v1', 'passed': True,
              'scope': 'Three CPU fixture assertions only. Archive main never invoked; '
                       'no canonical archive/Git/native writes.',
              'old_source_sha256': hashlib.sha256(old_bytes).hexdigest(),
              'new_source_sha256': hashlib.sha256(new_bytes).hexdigest(),
              'findings': findings}
    print(json.dumps(result, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
