"""Real producer methods/ROS messages, fake publishers; no ROS init or native launch."""
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
from types import MethodType, SimpleNamespace
from std_msgs.msg import String

from multi_robot_exploration.mr3_information import IdealInformation

ROOT = Path('/home/zhuyulab/ns3-workspace')
BASE = ROOT / 'ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration'
SPEC = importlib.util.spec_from_file_location('production_fixtures', BASE / 'test/test_mr3_information.py')
F = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(F)
OUT = Path('/tmp/mr3_p2a0_v10_information_producer_fixture_v2')
OUT.mkdir(exist_ok=False)
node = F.state_input_bridge()
for index, name in enumerate(node.names):
    odom = F.input_odom(1_998_000_000, x=1.17 + index * .3)
    odom.pose.pose.position.y, odom.pose.pose.position.z = -.83, .011
    odom.pose.pose.orientation.z, odom.pose.pose.orientation.w = math.sin(-.71/2), math.cos(-.71/2)
    odom.pose.covariance = [float(i) / 10000 for i in range(36)]
    odom.twist.covariance = [float(35-i) / 1000 for i in range(36)]
    odom.twist.twist.linear.x, odom.twist.twist.angular.z = .13, -.27
    IdealInformation.receive_local_odom(node, name, odom)
    future = copy.deepcopy(odom)
    future.header.stamp.sec, future.header.stamp.nanosec = 2, 2_000_000
    IdealInformation.receive_local_odom(node, name, future)
    IdealInformation.receive_local_tf(node, name, F.input_tf(1_300_000_000))
node.publish_states()


def request(operation, identifier):
    value = {'schema': 'mr3-state-phase-request-v1', 'epoch': node.epoch,
             'request_id': identifier, 'operation': operation, 'target_time_ns': node.clock_ns}
    node.receive_state_phase_request(String(data=json.dumps(value)))
    return value


request('takeover', 'takeover2000000000')
node.clock_ns += 20_000_000
first = request('commit', 'boundary2020000000')
assert node.pending_state_phase is not None and node.state_sequence == 1
for name in node.names:
    tf = F.input_tf(1_979_000_000)
    tf.transforms[0].transform.translation.x = 2.37
    tf.transforms[0].transform.translation.y = -1.18
    tf.transforms[0].transform.translation.z = .025
    tf.transforms[0].transform.rotation.z = math.sin(.36/2)
    tf.transforms[0].transform.rotation.w = math.cos(.36/2)
    IdealInformation.receive_local_tf(node, name, tf)
node.poll_state_phase()
assert node.pending_state_phase is None and node.state_sequence == 2
node.receive_state_phase_request(String(data=json.dumps(first)))
node.publish_states()
assert node.state_sequence == 2
node.clock_ns += 20_000_000
request('commit', 'boundary2040000000')
node.clock_ns += 600_000_000
request('commit', 'pending_terminal')
assert node.pending_state_phase is not None
node.receive_state_terminal(String(data=json.dumps({'epoch': node.epoch,
    'end_sim_time_sec': 2.64, 'termination_reason': 'coverage_reached'})))
node.pending_drain, node.drain_responses, node.drain_timeout_sec = None, {}, 10.
node.drain_publisher = F.Publisher()
node.map_payload_sha256 = 'fixture_map_sha'
node.map_timer = SimpleNamespace(is_ready=lambda: False)
node.state_timer = SimpleNamespace(is_ready=lambda: True)
node.poll_drain = MethodType(IdealInformation.poll_drain, node)
IdealInformation.receive_drain_request(node, String(data=json.dumps({
    'epoch': node.epoch, 'request_id': 'terminal_snapshot', 'target_time_ns': node.clock_ns,
    'allow_terminal': True})))
node.poll_drain()
assert json.loads(node.drain_publisher.messages[-1].data)['state_sequence'] == 3
assert node.state_sequence == 3
ledger = OUT / 'information_states.jsonl'
ledger.write_text(node.state_audit_stream.getvalue())
receipt = {'schema': 'mr3-p2a0-v10-information-production-fixture-v1',
           'producer_sha256': hashlib.sha256((BASE/'multi_robot_exploration/mr3_information.py').read_bytes()).hexdigest(),
           'ledger': str(ledger), 'ledger_sha256': hashlib.sha256(ledger.read_bytes()).hexdigest(),
           'ledger_rows': len(ledger.read_text().splitlines()), 'epoch': node.epoch,
           'nonidentity_measured_inputs': True, 'late_causal_tf_wait_without_clock_advance': True,
           'scope': 'real production methods with ROS messages/fake publishers; no native or task credit',
           'native_starts': 0, 'ROS_init_or_spin': 0}
(OUT/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt, indent=2))
