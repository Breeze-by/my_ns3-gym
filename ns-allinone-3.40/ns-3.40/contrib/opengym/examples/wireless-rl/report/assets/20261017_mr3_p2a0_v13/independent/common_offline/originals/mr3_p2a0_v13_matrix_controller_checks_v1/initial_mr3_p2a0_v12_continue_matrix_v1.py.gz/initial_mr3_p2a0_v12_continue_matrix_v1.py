"""Run only the three declared remaining stages; official admission/gates stay authoritative."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A = W / 'report/assets/20261017_mr3_p2a0_v12'
FREEZE = '6b1b4a0108351f5bfb70ec0c96ba895248d4f7a8'
PLAN_SHA = '264a9c5aa996938691a335f9f00c7102cfce8863b21bd5fe3b1191472d8aecbf'
LEDGER = Path('/tmp/mr3_p2a0_v12_remaining_matrix_v1.jsonl')
ENV = dict(os.environ, PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1')
ENV.pop('PYTHONPATH', None)


def main():
    assert hashlib.sha256((A / 'predeclared_plan_v12.json').read_bytes()).hexdigest() == PLAN_SHA
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == FREEZE
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True)
    interface = json.loads(Path('/tmp/mr3_p2a0_v12_interface_audit_execution_v1.json').read_text())
    assert interface['passed'] is True and interface['freeze'] == FREEZE
    with LEDGER.open('x') as ledger:
        def record(**value):
            row = dict(schema='mr3-declared-matrix-orchestration-v1', freeze=FREEZE,
                       wall_monotonic_ns=time.monotonic_ns(),
                       utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), **value)
            ledger.write(json.dumps(row) + '\n')
            ledger.flush()
            print(json.dumps(row), flush=True)

        record(event='started', pid=os.getpid(), parent=os.getppid(), plan_sha256=PLAN_SHA,
               source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               scope='Only bound launch/audit CLI; no signals, retries, parameter changes or gate overrides')

        def invoke(stage, operation):
            command = [sys.executable, str(A / 'independent' /
                       ('mr3_p2a0_v12_' + operation + '_stage.py')), stage, FREEZE]
            console = Path('/tmp/mr3_p2a0_v12_' + stage + '_controller_' + operation + '.log')
            record(event='command_started', stage=stage, operation=operation,
                   argv=command, cwd=str(W), console=str(console))
            started = time.monotonic()
            child = None
            error = None
            with console.open('x') as output:
                try:
                    child = subprocess.Popen(command, cwd=W, env=ENV,
                                             stdout=output, stderr=subprocess.STDOUT)
                    code = child.wait()
                except BaseException as failure:
                    error = repr(failure)
                    code = child.wait() if child is not None else 1
            record(event='command_completed', stage=stage, operation=operation,
                   returncode=code, error=error, wall_seconds=time.monotonic() - started,
                   child_pid=child.pid if child is not None else None,
                   console_sha256=hashlib.sha256(console.read_bytes()).hexdigest())
            return code == 0 and error is None

        for stage in ('terminal', 'reset', 'deadline'):
            native_ok = invoke(stage, 'launch')
            audit_ok = invoke(stage, 'audit')
            if not (native_ok and audit_ok):
                record(event='version_failed_later_stages_skip', stage=stage,
                       native_ok=native_ok, audit_ok=audit_ok)
                return 1
            record(event='stage_passed', stage=stage)
        record(event='matrix_complete', passed=True)
        return 0


if __name__ == '__main__':
    sys.exit(main())
