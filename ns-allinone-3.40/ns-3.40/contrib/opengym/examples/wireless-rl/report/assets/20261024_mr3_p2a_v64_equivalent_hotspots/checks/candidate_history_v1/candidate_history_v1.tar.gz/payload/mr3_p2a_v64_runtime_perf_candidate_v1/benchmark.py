"""Fixed artificial runtime kernels; no native/throughput/capacity claims."""
import importlib.util
import json
from pathlib import Path
import time
from multi_robot_exploration import mr3_reach_runtime as candidate
from test_mr3_reach_runtime_independent import EPOCH, ROBOT, START, STEP, target, storage, applied

A=Path(__file__).parent
spec=importlib.util.spec_from_file_location('original_runtime_benchmark',A/'original_runtime.py')
original=importlib.util.module_from_spec(spec);spec.loader.exec_module(original)
results=[]
for count in (256, 4096):
    trackers=[original.ReachTracker(EPOCH,ROBOT),candidate.ReachTracker(EPOCH,ROBOT)]
    for i in range(1,count+1):
        pub=target(START+i*STEP,i)
        for tracker in trackers:
            tracker.publish_target(pub)
            tracker.receive_storage(storage(pub,i))
    event=applied(pub,pub['clock_ns'],1,count)
    assert trackers[0].ingress==trackers[1].ingress
    assert trackers[0].published==trackers[1].published
    assert trackers[0].storage.pending==trackers[1].storage.pending
    samples=[]
    for round_number in range(3):
        times={}
        for name,tracker in zip(('original','candidate'),trackers):
            started=time.perf_counter_ns()
            for _ in range(1000):
                assert tracker._applied(event) is True
            times[name+'_ns']=time.perf_counter_ns()-started
        assert trackers[0].status()==trackers[1].status()
        samples.append(times)
    results.append(dict(pending_count=count,calls_per_sample=1000,samples=samples,complete_evidence_equal=True))
output=dict(schema='mr3-v64-fixed-artificial-runtime-kernel-cost-v1',passed=True,results=results,scope='repeated zero latest-target _applied only; artificial data; elapsed time; not native capacity or startup cause',native_runs=0,scientific_qualification=False,capacity_qualified=False)
(A/'benchmark_result_v1.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output))
