"""One actual new corridor sample; no ROS init/native and no claim about old open case."""
import json,gzip,hashlib,math
from pathlib import Path
from rclpy.serialization import deserialize_message
from dwb_msgs.msg import LocalPlanEvaluation
from nav_msgs.msg import Path as ROSPath
B=Path('/tmp/mr3_p2a0_v12_passive_nav2_domain135_v6');p=B/'receipts.jsonl';raw=p.read_bytes();rows=[json.loads(s)for s in raw.splitlines()]
e=next((i,r)for i,r in enumerate(rows,1)if r.get('kind')=='raw_cdr_received'and r['topic']=='/tb1/evaluation')
paths=[(i,r)for i,r in enumerate(rows,1)if i<e[0]and r.get('kind')=='raw_cdr_received'and r['topic']=='/tb1/transformed_global_plan'];t=paths[-1]
def load(r,kind):
 path=B/r['payload'];enc=path.read_bytes();cdr=gzip.decompress(enc)
 assert hashlib.sha256(enc).hexdigest()==r['payload_proof']['encoded_sha256']
 assert hashlib.sha256(cdr).hexdigest()==r['raw_cdr_sha256']
 return deserialize_message(cdr,kind)
m=load(e[1],LocalPlanEvaluation);plan=load(t[1],ROSPath);winner=m.twists[m.best_index];start=winner.traj.poses[0];first=plan.poses[0].pose.position
sample=next(q.pose.position for q in plan.poses if math.hypot(q.pose.position.x-first.x,q.pose.position.y-first.y)>=.5)
heading=math.atan2(sample.y-start.y,sample.x-start.x);error=math.atan2(math.sin(heading-start.theta),math.cos(heading-start.theta))
def score(i,traj):return{'index':i,'v':traj.traj.velocity.x,'theta':traj.traj.velocity.theta,'stored_total':float(traj.total),'scores':[{'name':s.name,'raw_score':float(s.raw_score),'scale':float(s.scale),'weighted':float(s.raw_score)*float(s.scale)}for s in traj.scores]}
result={'schema':'mr3-actual-post-failure-path-heading-score-example-v1','scope':'Actual late corridor domain135/w1e4 sample only, not old open w0e2. No code/config/seed/control change, no formal gate or new native evidence. Path-heading computation is offline diagnostic from observed transformed plan and evaluation pose, not an executed RotationShim output or exact TF/controller cycle ACK.','raw_receipt_file':str(p),'closed_ledger_sha256':hashlib.sha256(raw).hexdigest(),'evaluation_line':e[0],'evaluation_receipt':e[1],'transformed_plan_line':t[0],'transformed_plan_receipt':t[1],'first_eval_pose':{'x':start.x,'y':start.y,'theta':start.theta},'received_path_50cm_sample_xy':[sample.x,sample.y],'path_bearing_rad':heading,'shortest_path_heading_error_rad':error,'winner':score(m.best_index,winner),'all_zero_v_trajectories':[score(i,t)for i,t in enumerate(m.twists)if t.traj.velocity.x==0],'best_full_positive':score(*min(((i,t)for i,t in enumerate(m.twists)if t.traj.velocity.x>0 and len(t.scores)==7 and t.total>=0),key=lambda pair:pair[1].total)),'interpretation':'Observed globalpath direction from this pose calls for positive CCW alignment (+2.59rad), but local DWB critic grid selects negative CW -.210526. Its total68 undercuts positive rotation+.463..+.632 total68.2 and forward trajectory69.4. Difference is actual spatial PathAlign/GoalAlign quantization tradeoff, not absence of legal forward/positive-turn samples or forced RotateToGoal. Chosen zero-v rotation is feasible; this shows short-horizon objective can choose a longer alignment direction, not an API/safety violation. Later actual captures show eventual positive v.','tie_source':'Official1.1.20 dwb_local_planner.cpp coreScoringAlgorithm only replaces best on strict score.total<best.total; actual candidate order in CDR preserves earlier-twist tie outcome. No secondary path-heading tie criterion.'}
out=Path('/tmp/mr3_p2a0_v12_passive_nav2_heading_example_v1.json')
with out.open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
print(out,'headingerror',error,'winner',winner.traj.velocity.theta,'sha',hashlib.sha256(out.read_bytes()).hexdigest())
