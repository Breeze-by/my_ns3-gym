"""Read static local sources and write /tmp-only prospective diagnostic design."""
import gzip
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path('/home/zhuyulab/ns3-workspace')
ROS = ROOT / 'ros2_ws/ros2-multi-robot-automap'
HERE = Path(__file__).resolve().parent
INPUTS = {}


def read(path):
    value = path.read_bytes()
    INPUTS[str(path)] = hashlib.sha256(value).hexdigest()
    return value


def xml(path):
    return ET.fromstring(read(path))


def flatten(node, prefix=''):
    result = {}
    for child in node:
        key = prefix + child.tag
        if len(child):
            result.update(flatten(child, key + '/'))
        else:
            result[key] = child.text.strip() if child.text else None
    return result


worlds = {}
for name in ('p1c_open.world', 'p1c_rooms.world', 'p1c_corridors.world',
             'multi_empty_world.world', 'turtlebot3_world.world'):
    path = ROS / 'src/multi_robot/worlds' / name
    root = xml(path)
    physics = root.find('world/physics')
    worlds[name] = {'path': str(path), 'sha256': INPUTS[str(path)],
                    'physics_type': physics.get('type'), 'explicit_physics': flatten(physics),
                    'ground_includes': [node.text for node in root.findall('world/include/uri')
                                        if 'ground' in node.text]}
schema_path = Path('/usr/share/sdformat9/1.7/physics.sdf')
schema = xml(schema_path)
solver = schema.find("element[@name='ode']/element[@name='solver']")
constraints = schema.find("element[@name='ode']/element[@name='constraints']")
defaults = {section + '/' + node.get('name'): node.get('default')
            for section, element in (('solver', solver), ('constraints', constraints))
            for node in element.findall('element') if node.get('default') is not None}
planes = []
for path in (Path('/usr/share/gazebo-11/models/ground_plane/model.sdf'),
             Path.home() / '.gazebo/models/ground_plane/model.sdf'):
    root = xml(path)
    surface = root.find('model/link/collision/surface')
    planes.append({'path': str(path), 'sha256': INPUTS[str(path)], 'surface': flatten(surface)})
model_path = ROS / 'src/multi_robot/models/turtlebot3_waffle/model.sdf'
model = xml(model_path).find('model')
collisions = []
for link in model.findall('link'):
    for collision in link.findall('collision'):
        surface = collision.find('surface')
        collisions.append({'link': link.get('name'), 'collision': collision.get('name'),
                           'surface': flatten(surface) if surface is not None else 'omitted; SDF defaults'})
physics_source = HERE / 'ODEPhysics_gazebo11_11.10.2.cc'
code = read(physics_source).decode()
for key in ('solver_type', 'iters', 'sor', 'cfm', 'erp', 'friction_model',
            'rms_error', 'constraint_residual', 'num_contacts'):
    assert '_key == "' + key + '"' in code
world_info = {'schema': 'mr3-v18-static-physics-source-review-v1',
              'scope': 'Static source/schema facts only; no world/participant/physics instantiation. '
                       'Defaults are source-derived predictions, not archived V17 runtime readback.',
              'worlds': worlds, 'installed_SDF17_ODE_defaults': defaults,
              'ground_plane_resolution_candidates': planes, 'robot_collision_surfaces': collisions,
              'engine_readback_support': ['solver_type', 'iters', 'sor', 'cfm', 'erp',
                                          'contact_max_correcting_vel', 'contact_surface_layer',
                                          'friction_model', 'rms_error', 'constraint_residual', 'num_contacts'],
              'references': [
                  {'url': 'https://classic.gazebosim.org/tutorials?cat=physics&tut=physics_params',
                   'paraphrase': 'ODE quick is iterative; iteration count affects accuracy and cost '
                                 'without a universal monotonic guarantee. SOR also affects quick. '
                                 'Pyramid friction decouples two tangential constraints.'},
                  {'url': 'https://classic.gazebosim.org/tutorials?cat=physics&tut=friction',
                   'paraphrase': 'Gazebo uses the lesser mu and mu2 from the contacting surfaces. '
                                 'Ground100/50 versus wheel100000/100000 therefore predicts '
                                 'wheel-ground100/50, subject to actual loaded surfaces.'}],
              'important_limits': [
                  'System and user ground models differ in other bytes but both explicitly100/50. '
                  'Resolve actual URI and capture effective collision parameters in a future run.',
                  'Legacy150iter/SOR1.4 physics blocks also set20ms stepping, CFM1e-5, maxcorr2000, '
                  'surface layer.01 and dynamic MOI true. Copying the whole block is not a '
                  'single-variable solver test and changes the current MR3 physical contract.',
                  'Do not infer that high friction, contact max_vel.01 or any one parameter '
                  'causes the observed .011 lateral residual without controlled evidence.'],
              'input_sha256': INPUTS}
with (HERE / 'static_physics_review_v1.json').open('x') as handle:
    json.dump(world_info, handle, indent=2, allow_nan=False)

plan = {
    'schema': 'mr3-v18-prospective-physics-diagnostic-design-v1',
    'readiness': 'design_only_root_review_and_future_source_freeze_required',
    'native_admission_granted': False, 'source_freeze': None,
    'scope': 'Three-robot non-learning engineering diagnosis only. No P2A.0 matrix, learned '
             'policy,95% mapping, task-reliability or continuous-physics credit.',
    'minimum_recommended_first_run': {
        'name': 'diag_baseline', 'workers': 1, 'scene': 'open', 'seed': 101,
        'robots': ['tb1', 'tb2', 'tb3'], 'fixture': 'existing mr3-p2a0-outward-cancel-v6',
        'policy_API_steps': 32, 'learner_updates': 0,
        'reason': 'Reuse frozen received-only goals/guard/storage/stepping; add passive evidence '
                  'only. Avoid a new stimulus or bypass of the safety/control path.',
        'physics_parameters': 'Original MR31ms/ODE and all model/contact/actuator parameters; '
                              'record effective resolved defaults before release.',
        'wall_ceiling_proposed_seconds': 1800,
        'outcomes': ['Observed issue with complete1ms data', 'not reproduced',
                     'missing meaningful stop coverage', 'infrastructure/capture failure'],
        'retry': False},
    'optional_separately_authorized_contrast': {
        'name': 'diag_iters150', 'admission': 'Requires explicit prospective root authorization '
                'and valid baseline capture; never an automatic retry to replace baseline.',
        'workers': 1, 'scene': 'open', 'seed': 101, 'API_steps': 32,
        'only_parameter_change': {'ODEsolver/iters': {'baseline_expected': 50, 'contrast': 150}},
        'keep': '1ms timestep, quick solver, SOR1.3, CFM/ERP/contact properties/friction, '
                'robot poses/model, command caps, wheel driver, sensors and original fixture.',
        'wall_ceiling_proposed_seconds': 1800, 'retry': False,
        'claim_limit': 'One paired setting comparison is iteration sensitivity evidence, not '
                       'numerical convergence or proof of root cause. Closed-loop Nav2/guard '
                       'streams can diverge with physics; record and report actual target '
                       'differences rather than pretend identical forcing.'},
    'maximum_if_both_authorized': {'native_runs': 2, 'policy_API_steps': 64,
                                  'resets': 2, 'returned_records_with_reset': 66,
                                  'wall_seconds': 3600, 'learning_updates': 0,
                                  'task_sim_seconds_nominal': 64,
                                  'startup_bootstrap_alignment_cleanup': 'Charge exact physics '
                                      'and launcher ledgers separately; not hidden in nominal64.',
                                  'pilot_training_budget_change': 0},
    'unchanged_gates_and_channels': {
        'original_rest': {'planar_speed_mps': .01, 'consecutive_fresh_source_samples': 3,
                          'stop_horizon_seconds': .78, 'max_source_gap_seconds': .1,
                          'meaningful_prior_output_span_seconds': .1,
                          'meaningful_initial_planar_speed_mps': .05},
        'public_odometry_and_actuation_rate_hz': 30,
        'physical_tick_ns': 1_000_000, 'control_phase_quantum_ns': 20_000_000,
        'do_not_change': ['mu/mu2', 'contact parameters', 'solver parameters in baseline',
                          'rest/motion/contact gates', 'candidate/actor/guard inputs',
                          'command/smoother/driver budgets', 'sensor/topic rates'],
        'new1ms_rows_are': 'Isolated diagnostic measurement only; never published into actor, '
                          'mask, guard, map, state-transport or learned policy inputs.'},
    'capture_contract_for_runtime_owner': {
        'minimum_timing': 'One passive post-physics WorldUpdateEnd row per actual1ms tick per '
                          'robot; label callback phase, epoch, instance, iteration and exact sim_ns. '
                          'Do not advance, set state or generate a substitute sensor message.',
        'raw_point_state': ['model WorldPose', 'canonical link name/initialRelativePose',
                            'canonical link WorldPose/WorldLinearVel/WorldAngularVel allxyz',
                            'base_link WorldPose/WorldLinearVel/WorldCoGLinearVel allxyz',
                            'inertial CoG/local frames and actual relative transforms'],
        'execution_binding': ['last actual stored cmd_seq/target sequence+clock',
                              'last actual actuation_seq and its timestamp',
                              'raw measured joint position/angular velocity',
                              'wheel command current/desired/applied from existing30Hz ledger'],
        'solver_diagnostics_if_available': ['rms_error', 'constraint_residual', 'num_contacts'],
        'effective_configuration_once': ['max_step_size', 'quick/world solver', 'iters', 'sor',
                                         'CFM', 'ERP', 'max correcting velocity', 'surface layer',
                                         'MOI scaling', 'friction model',
                                         'actual resolved ground/wheel/caster mu/mu2/contact '
                                         'properties and collision identity'],
        'archive': 'Per-robot append-only files with sequence/source clock, schema, source '
                   'SHA/macros/actual mapped library evidence, lossless raw bytes and completed '
                   'strict closure. Explicitly mark unsupported readbacks; never substitute0.',
        'phase_limit': 'Existing WORLD odometry is read in the30Hz WorldUpdateBegin path. '
                       'Do not assume equal header time means equal engine phase. Compare '
                       'predeclared0/1tick offsets and report both, never choose a shift to fit.'},
    'offline_questions_predeclared': [
        'At1ms, is canonical lateral velocity persistent, sign-alternating/high-frequency, '
        'or inconsistent with same-point finite differences? Report full distributions/tails.',
        'Compare co-located canonical pose differences at1/2/5/10ms and original30Hz source '
        'timestamps against raw instantaneous velocity; do not equate chord with an upper '
        'continuous-path bound or replace old rest measurements.',
        'Check point-shift relation between canonical/base_link/CoG using actual full angular '
        'velocity and transforms. A single old CoG offset is not an authorized correction.',
        'Align target-storage and30Hz actuation identities, joint feedback, contact/solver '
        'residual and fullxyz body signals through actual stop tails. Zero rims do not imply '
        'zero lateral body motion.',
        'Report old30Hz original rest result unchanged and describe whether1ms data supports '
        'aliasing/solver/phase/point hypotheses. No blanket continuous safety or simulator '
        'accuracy theorem from finite samples.'],
    'stop_and_validity_rules': [
        'Startup/capture identity/phase error or real safety failure stops the owned diagnostic '
        'through its existing controlled close; preserve all prefixes/failures, no native retry.',
        'No meaningful stop or no reproduced residual is an honest result. Do not silently '
        'change seeds, extend horizon, change friction or add attempts until a favorable case.',
        'Both authorized conditions are separately logged/charged. No cross-condition pooling '
        'into a P2A.0 same-freeze matrix. A later production repair requires its own full matrix.'],
    'source_note': 'Current V17 source is only a reference. New passive logger and any world '
                   'contrast must be reviewed/frozen separately; this design cannot start native.'}
with (HERE / 'prospective_diagnostic_design_v1.json').open('x') as handle:
    json.dump(plan, handle, indent=2, allow_nan=False)

text = '''# V18 physics diagnostic proposal — not admitted

Recommend one three-robot, one-worker open10132-step engineering baseline using the existing V6 fixture. Add a separate1ms post-physics measurement file; leave the original30Hz odometry/actuation,20ms control phases, model/contact settings and original `.01m/s ×3`/`.78s` stop gate intact. It is a diagnosis, with zero learning and no P2A.0 matrix credit.

The active `p1c_*` worlds specify ODE1ms/1000Hz and omit the ODE solver block. Installed SDF1.7 defaults predict quick/50iterations/SOR1.3. These are source-derived defaults, not old runtime readback. The two available ground-plane models both specify friction100/50, while wheel collisions specify100000/100000; confirm the resolved collision properties during the future run. Do not change friction on this evidence.

The old `multi_empty_world`/`turtlebot3_world`150/1.4 configuration also changes the step to20ms, MOI handling, CFM, contact correction and surface layer. Copying the whole block would confound a test. If separately authorized, a second fresh run should vary **only iterations50→150**, retaining SOR1.3 and every other setting. One comparison supports sensitivity analysis, not a convergence theorem. Closed-loop commands can differ, so preserve their exact streams.

Record all3 actual canonical origins at each1ms WorldUpdateEnd with full pose/linear/angular vectors, base_link/CoG transforms, actual last target/actuation identities, joint feedback and supported solver residual/contact counts. This file stays isolated from actor, masks, navigation and guard. Match existing30Hz WorldUpdateBegin odometry with explicit engine-phase labels; evaluate the predeclared0/1tick offsets without selecting a convenient shift.

The primary question is whether the approximately.011m/s lateral signal persists at1ms, oscillates between coarse samples, or disagrees with co-located pose increments. Check the point-shift equations from measured transforms. Retain the original30Hz rest verdict. High-rate finite sampling still cannot prove continuous truth or justify calling the failure noise.

Proposed ceiling:1800wall seconds and32API steps for baseline; only if prospectively authorized, another1800/32 for the single contrast. Maximum2runs/64steps,2resets and0updates; charge all startup/physical/alignment/cleanup costs separately and leave pilot training balances unchanged. Preserve non-reproduction, missing stop coverage and failures without retry. A production repair still needs a new complete same-freeze matrix.

Official references: [Gazebo physics parameters](https://classic.gazebosim.org/tutorials?cat=physics&tut=physics_params), [Gazebo friction](https://classic.gazebosim.org/tutorials?cat=physics&tut=friction). Exact local XML/default/source SHA facts and the full capture/analysis contract are in the adjacent JSON files.
'''
with (HERE / 'design_note_v1.md').open('x') as handle:
    handle.write(text)
assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest() == value for path, value in INPUTS.items())
receipt = {'schema': 'mr3-v18-design-static-check-v1', 'passed': True,
           'scope': 'XML/default/source consistency and prospective design only; no simulator, '
                    'participant, parser-world instantiation or native/formal/CPU runtime tests.',
           'source_before_after_stable': True, 'input_sha256': INPUTS,
           'outputs': {name: hashlib.sha256((HERE/name).read_bytes()).hexdigest()
                       for name in ('static_physics_review_v1.json', 'prospective_diagnostic_design_v1.json',
                                    'design_note_v1.md')},
           'tool_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
with (HERE / 'design_static_check_v1.json').open('x') as handle:
    json.dump(receipt, handle, indent=2, allow_nan=False)
print(json.dumps(receipt['outputs'], indent=2))
