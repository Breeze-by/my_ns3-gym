from pathlib import Path
import hashlib,json
root=Path('/home/zhuyulab/ns3-workspace');w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';a=w/'report/assets/20261017_mr3_p2a0_v12';ind=a/'independent';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=a/'predeclared_plan_v12.json';d=json.loads(p.read_text());base=json.loads((w/'report/assets/20261017_mr3_p2a0_v11/predeclared_plan_v11.json').read_text())
allowed={str((w/x).relative_to(root)) for x in ('mr3_learning/audit_ppo.py','mr3_learning/audit_preparation.py','mr3_learning/audit_controlled_physics.py','mr3_learning/tests/test_audit_controlled_physics.py')}
bindings={};changed=[]
for b in base['independent_source_bindings']:
    relative=b['path'];digest=sha(root/relative)
    if digest!=b['sha256']:changed.append(relative);assert relative in allowed,relative
    bindings[relative]={'path':relative,'sha256':digest}
for f in [*sorted(ind.glob('*.py')),w/'mr3_learning/tests/test_audit_controlled_readiness.py']:
    assert f.is_file();relative=str(f.relative_to(root));assert relative not in bindings
    bindings[relative]={'path':relative,'sha256':sha(f)}
d['independent_source_bindings']=list(bindings.values())
d['controlled_execution_audit']['shared_readiness_consumer']={'path':str((w/'mr3_learning/audit_controlled_physics.py').relative_to(root)),'sha256':sha(w/'mr3_learning/audit_controlled_physics.py'),'scope':'Strict protocol-restricted actual T0/bootstrap/T1 composite proof and scoped legacy prewarm ACK predicate; unchanged complete contact audit; both hooks restored even on failure.'}
d['historical_bindings_scope']='Prior V11 plan68 remains unchanged historically; all original33 exact. This plan repins only reviewed shared-readiness consumer/callers/tests, adding versioned coordinators and tests; all ROS/native source unchanged fromV11.'
p.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'passed':True,'bindings':len(bindings),'changed':changed,'plan_sha256':sha(p)}))
