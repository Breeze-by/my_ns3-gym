#!/usr/bin/python3
import hashlib
import json
from pathlib import Path
import resource
import subprocess
import time

ROOT=Path('/home/zhuyulab/ns3-workspace')
P=Path(__file__).parent
HELPER=Path('/tmp/mr3_p2a0_v23_matrix_pack_proposal_v1/mr3_p2a0_v23_matrix_pack_closed_v1.py')
TARGET=Path('/tmp/mr3_p2a0_v23_selected_closed_v1')
EXTRAS=[Path('/tmp')/x for x in [
 'mr3_p2a0_v23_matrix_parent_console_v1.log','mr3_p2a0_v23_cross_stage_mapping_parent_console_v1.log',
 'mr3_p2a0_v23_run_actual_preflight_v1.py','mr3_p2a0_v23_final_static_v1.py',
 'mr3_p2a0_v23_final_static_v1.json','mr3_p2a0_v23_final_add_dry_v1.txt',
 'mr3_p2a0_v23_final_stage_paths_v1.bin']]
EXTRAS += [Path('/tmp/mr3_p2a0_v23_actual_preflight_execution_v1')/x for x in ['execution.json','stdout.txt','stderr.txt']]
EXTRAS += sorted(Path('/tmp').glob('mr3_p2a0_v23_preflight_learner_entry_*'))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def ident(path):
 st=path.stat();return {'sha256':sha(path.read_bytes()),'bytes':st.st_size,'mtime_ns':st.st_mtime_ns,'inode':st.st_ino,'device':st.st_dev}
before={str(x):ident(x) for x in [HELPER,*EXTRAS,Path(__file__)]}
argv=['/usr/bin/python3','-B',str(HELPER),'--freeze','9160543e32ca49a56dfd05eaa0df3ccb6d25f89e',
      '--target',str(TARGET),'--all-writers-closed']
for extra in EXTRAS:argv+=['--extra',str(extra)]
env={'PATH':'/usr/bin:/bin','PYTHONNOUSERSITE':'1','PYTHONDONTWRITEBYTECODE':'1','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC'}
started=time.monotonic();usage=resource.getrusage(resource.RUSAGE_CHILDREN)
r=subprocess.run(argv,cwd=ROOT,env=env,capture_output=True)
wall=time.monotonic()-started;end=resource.getrusage(resource.RUSAGE_CHILDREN)
(P/'stdout.txt').write_bytes(r.stdout);(P/'stderr.txt').write_bytes(r.stderr)
after={str(x):ident(x) for x in [HELPER,*EXTRAS,Path(__file__)]}
receipt={'schema':'mr3-v23-actual-closed-pack-execution-v1','completed':True,'passed':r.returncode==0 and before==after,
 'scope':'Actual lossless failed-attempt byte custody only; original source/native/consumer failures retained; no native/formal run.',
 'argv':argv,'cwd':str(ROOT),'environment_exact':env,'returncode':r.returncode,'wall_seconds':wall,
 'child_cpu_seconds':end.ru_utime+end.ru_stime-usage.ru_utime-usage.ru_stime,
 'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr),'source_extra_before':before,'source_extra_after':after,
 'source_extra_sha_stat_stable':before==after,'target':str(TARGET)}
if r.returncode==0:
 manifest=TARGET/'manifest.json';raw=manifest.read_bytes();receipt['manifest']={'path':str(manifest),'sha256':sha(raw),'bytes':len(raw)}
(P/'execution.json').write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
print(json.dumps({'passed':receipt['passed'],'returncode':r.returncode,'wall_seconds':wall,
 'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace'),'manifest':receipt.get('manifest')},indent=2))
raise SystemExit(0 if receipt['passed'] else 1)
