# Conditional V25 ROS-clock smoother correction

This directory prepares source and an unexecuted finite probe. Nothing here is a
new native result, a body-bound repair PASS, a source-freeze admission or user
acceptance. No command cap changes are selected: .20 m/s and .8 rad/s remain.

The installed package is `ros-humble-nav2-velocity-smoother`
`1.1.20-1jammy.20260326.004635`. Its installed header and package.xml exactly
match upstream tag 1.1.20, commit
`a097086719c88f781aa59788eca29ac6ca5e56db`. Upstream and the official Humble
bloom release 1.1.20-1 have identical velocity_smoother.cpp and header bytes.
The original CPP SHA is
`788822f4ac41a03a46e73b6a7a73f876a75792e093d6c3f7b3dceecb69bcc50d`.
The installed stock ELF is 513088 bytes, SHA
`3581b317ef094f77b6bdab8df122c438ff7a8f8d09154eed7cc5f736e10576cf`.
Its exported type information includes the WallTimer binding specifically for
the VelocitySmoother zero-argument method functor. These facts support the
source/package relationship; they are not a reproducible-build attestation.

In this release `on_activate` (125) and frequency reconfiguration (314) create
wall timers. OPEN_LOOP uses the last output as feedback (249); acceleration and
deceleration increments divide their configured limits by nominal frequency
(190–194, 219–224). Consequently this implementation can advance a command
while a stepped ROS clock remains paused. This is an integration-contract
mismatch for the present externally stepped simulation, not a claim that the
upstream real-robot implementation is universally incorrect.

Safety's selected actual raw callbacks changed over 20 ms simulated time and
about .2998 s wall time. Guard decisions were clear with no component filter;
the available ledger records selected callbacks, not every intermediate raw
publication. This supports checking the timer mechanism. It does not uniquely
identify the physical mechanism behind the 1.20619 rad/s body sample or prove
that changing the timer will keep all future body samples below 1.2.

## Minimal package change

`official_package` contains all eight upstream package files, unmodified,
plus a copy of the upstream root Apache-2.0 LICENSE. `proposed_package` has the
same files and original dependency declarations. Only src/velocity_smoother.cpp
differs: add rclcpp/create_timer.hpp and replace the two timer factories with
Humble's existing node-interface/get_clock `rclcpp::create_timer` API. Exact
inverse replacement restores all original bytes. No new dependencies, header
layout, topics, lifecycle callbacks, constraints, arithmetic, nominal frequency,
timeout, command limits, physical properties or feedback settings change.

The target remains `velocity_smoother_core`, installed as
`libvelocity_smoother_core.so`, and the executable remains
`lib/nav2_velocity_smoother/velocity_smoother`. The planned canonical package is
`ros2_ws/ros2-multi-robot-automap/src/nav2_velocity_smoother`; the current launch
already selects the package by that name. Actual overlay selection must later
be proved from the built artifacts and live process mappings, not assumed from
these prepared paths. Root owns promotion and the single actual colcon build.

## Unexecuted real-component probe

The C++ probe links the real component library. One compile is planned after the
canonical overlay build. Two separate processes select stock and actual fixed
libraries using LD_LIBRARY_PATH; dladdr, complete process maps, source/ELF SHA
and saved process identities must demonstrate actual selection. The subclass
only reads protected timer and command state; it overrides no production method.

Each process uses public configure/activate/deactivate/cleanup, one executor,
a synthetic clock publisher, command publisher and output subscription. The
executor is created after rclcpp::init. Actual configured parameters are recorded.
At paused ROS time, the stock timer is expected to be steady and to publish
multiple command increments; the fixed timer must be non-steady and publish no
increments. Controlled 50 ms clock advances then collect actual outputs. A public
frequency change to 10 Hz repeats pause/100 ms advance behavior, exercising the
second timer construction site. The component and messages remain real ROS/DDS;
there is no Gazebo, robot, goal, map, policy or GPU operation.

Each process has a cooperative 10-second work guard, normal lifecycle cleanup,
and a recorded 15-second total ceiling; two children must total at most 30 seconds.
The wrapper sends no signals, imposes no kill timeout, starts no retry, and waits
for natural exit. Unexpected blocked SDK calls cannot be forcibly bounded by
this cooperative mechanism; any excess is retained as failure. A failed stock
probe skips the fixed probe. Root authorized only preparation so far: no package
build, probe compile, component process or DDS participant has been run here.

The prospective compile uses system Humble plus the canonical install:

```bash
source /opt/ros/humble/setup.bash
source /home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/install/setup.bash
export PYTHONNOUSERSITE=1
/usr/bin/cmake -S PROBE_SOURCE -B EXCLUSIVE_PROBE_BUILD -DCMAKE_BUILD_TYPE=Release
/usr/bin/cmake --build EXCLUSIVE_PROBE_BUILD --parallel 2
```

Root then supplies the actual probe SHA, fixed library SHA and build receipt to
run_probe_pair_v1.py. Its output directory must be absent. Domain 175 is proposed
for these synthetic processes and must be confirmed unused at execution.
Compile cost is recorded separately; both actual probe child wall times are
prospectively charged to the existing engineering balance, without resetting it.

## Scope after the probe

ROS-clock scheduling fixes the clock-selection precondition. The unchanged
algorithm still uses nominal per-callback increments. A quantized or coalesced
clock/executor schedule is not a theorem that every arbitrarily short observed
output interval has delta/interval below the configured acceleration. The probe
records actual clocks and outputs rather than inventing such a new hard gate.

No old result is relabeled. .30 planar, 1.2 angular norm, angular acceleration 7,
.78-second/.144-metre stopping, .01-m/s three unique fresh rest samples, A-or-B,
source-age, contact, geometry, candidate, actor/reward, 95% task and all original
34 matrix gates stay intact. The new clean pushed source and actual overlay
identity must pass preflight, then one complete same-freeze four-stage matrix.
