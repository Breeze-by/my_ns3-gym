from pathlib import Path
import shutil

OLD=Path('/tmp/mr3_p2a0_v18_driver_diagnostic_proposal_v3')
OUT=Path('/tmp/mr3_p2a0_v18_driver_diagnostic_proposal_v4')
OUT.mkdir()
s=(OLD/'mr3_stop_response_observer.cpp').read_text()
s=s.replace('// Candidate only: no production source or binary has been changed.\n','')
s=s.replace('#include <gazebo/physics/Joint.hh>', '#include <gazebo/physics/Joint.hh>\n#include <gazebo/physics/Collision.hh>\n#include <gazebo/physics/Contact.hh>\n#include <gazebo/physics/ContactManager.hh>\n#include <gazebo/physics/ode/ODEPhysics.hh>\n#include <gazebo/ode/ode.h>')
s=s.replace('#include <cctype>', '#include <cctype>\n#include <cmath>\n#include <unistd.h>')
s=s.replace('  Json result{{"available", true}, {"cpp_type", value.type().name()}};\n  if (const auto p = boost::any_cast<double>(&value)) {result["value"] = *p;}', '''  Json result{{"available", true}, {"cpp_type", value.type().name()},
    {"readback_scope", "public_GetParam_not_independent_native_readback"}};
  if (key == "solver_type" || key == "iters" || key == "sor" || key == "cfm" || key == "erp") {
    result["readback_scope"] = "sdf_cached_public_GetParam";
  }
  if (const auto p = boost::any_cast<double>(&value)) {
    if (!std::isfinite(*p)) {
      return {{"available", false}, {"nonfinite", true},
        {"readback_scope", result["readback_scope"]},
        {"nonfinite_class", std::isnan(*p) ? "NaN" : (*p < 0 ? "-Inf" : "+Inf")}};
    }
    result["value"] = *p;
  }''')
helpers=r'''
bool Finite(const Json & value)
{
  if (value.is_number_float() && !std::isfinite(value.get<double>())) {return false;}
  if (value.is_structured()) {
    for (const auto & item : value) {if (!Finite(item)) {return false;}}
  }
  return true;
}

Json NativeOde(const gazebo::physics::PhysicsEnginePtr & physics)
{
  const auto ode = boost::dynamic_pointer_cast<gazebo::physics::ODEPhysics>(physics);
  if (!ode || !ode->GetWorldId()) {
    return {{"available", false}, {"reason", "public_ODE_world_id_unavailable"}};
  }
  const auto id = ode->GetWorldId();
  dVector3 gravity;
  dWorldGetGravity(id, gravity);
  Json values{{"iters", dWorldGetQuickStepNumIterations(id)},
    {"precon_iters", dWorldGetQuickStepPreconIterations(id)},
    {"sor", dWorldGetQuickStepW(id)}, {"cfm", dWorldGetCFM(id)}, {"erp", dWorldGetERP(id)},
    {"contact_max_correcting_vel", dWorldGetContactMaxCorrectingVel(id)},
    {"contact_surface_layer", dWorldGetContactSurfaceLayer(id)},
    {"sor_lcp_tolerance", dWorldGetQuickStepTolerance(id)},
    {"use_dynamic_moi_rescaling", dWorldGetQuickStepInertiaRatioReduction(id)},
    {"gravity_xyz", {gravity[0], gravity[1], gravity[2]}}};
  const bool finite = Finite(values);
  return {{"available", finite}, {"nonfinite", !finite}, {"values", values},
    {"readback_scope", "native_dWorld_getters_on_public_ODEPhysics_GetWorldId"},
    {"solver_dispatch", {{"available", false},
        {"reason", "active_private_step_function_has_no_public_getter; GetStepType_reads_SDF"}}}};
}

Json Contacts(const gazebo::physics::PhysicsEnginePtr & physics,
  const gazebo::physics::ModelPtr & model, int64_t clock_ns, bool solved)
{
  const auto manager = physics->GetContactManager();
  if (!manager) {return {{"available", false}, {"reason", "contact_manager_unavailable"}};}
  const auto count = manager->GetContactCount();
  const auto & all = manager->GetContacts();
  Json result{{"manager_available", true}, {"valid_prefix_count", count},
    {"never_drop_contacts", manager->NeverDropContacts()}, {"records", Json::array()},
    {"scope", "retained_current_own_model_vs_static_environment_support_candidates_only; empty_is_not_no_contact"}};
  if (count > all.size()) {
    result["available"] = false;
    result["reason"] = "valid_prefix_count_exceeds_storage";
    return result;
  }
  // The vector may hold stale capacity beyond GetContactCount(). Never read it.
  for (unsigned int index = 0; index < count; ++index) {
    const auto contact = all[index];
    if (!contact || !contact->collision1 || !contact->collision2) {continue;}
    const auto one = contact->collision1->GetLink();
    const auto two = contact->collision2->GetLink();
    if (!one || !two) {continue;}
    const auto model_one = one->GetModel();
    const auto model_two = two->GetModel();
    const bool own_one = model_one == model;
    const bool own_two = model_two == model;
    if (own_one == own_two) {continue;}
    const auto other = own_one ? model_two : model_one;
    if (!other || !other->IsStatic()) {continue;}
    Json record{{"valid_prefix_index", index},
      {"collision1", contact->collision1->GetScopedName()},
      {"collision2", contact->collision2->GetScopedName()},
      {"link1", one->GetScopedName()}, {"link2", two->GetScopedName()},
      {"own_collision_index", own_one ? 1 : 2}, {"other_model_static", true},
      {"contact_time_ns", Ns(contact->time)}, {"point_count", contact->count},
      {"points", Json::array()}};
    if (Ns(contact->time) != clock_ns || contact->count < 0 || contact->count > MAX_CONTACT_JOINTS) {
      record["available"] = false;
      record["reason"] = "stale_contact_or_invalid_point_count";
      result["records"].push_back(record);
      continue;
    }
    record["available"] = contact->count > 0;
    for (int point = 0; point < contact->count; ++point) {
      Json value{{"position_world_xyz", Vector(contact->positions[point])},
        {"normal_world_xyz", Vector(contact->normals[point])},
        {"depth_m", contact->depths[point]}};
      if (solved && physics->GetType() == "ode") {
        const auto & wrench = contact->wrench[point];
        value["forces"] = {{"available", true},
          {"body1_force_link_xyz", Vector(wrench.body1Force)},
          {"body2_force_link_xyz", Vector(wrench.body2Force)},
          {"body1_torque_link_xyz", Vector(wrench.body1Torque)},
          {"body2_torque_link_xyz", Vector(wrench.body2Torque)},
          {"scope", "ODEPhysics_UpdatePhysics_rotates_feedback_into_each_link_frame; torque_about_CoG"}};
      } else {
        value["forces"] = {{"available", false}, {"reason", "before_current_ODE_physics_solve"}};
      }
      record["points"].push_back(value);
    }
    result["records"].push_back(record);
  }
  result["available"] = false;
  for (const auto & record : result["records"]) {
    if (record.value("available", false)) {result["available"] = true;}
  }
  if (!result["available"].get<bool>()) {
    result["reason"] = "no_retained_fresh_own_static_contact_evidence_not_proof_of_no_physical_contact";
  }
  return result;
}
'''
anchor='}  // namespace\n\nclass State'
assert s.count(anchor)==1
s=s.replace(anchor,helpers+'}  // namespace\n\nclass State')
s=s.replace('  uint64_t pair_sequence{0};','  uint64_t pair_sequence{0};\n  uint64_t pair_iterations{0};')
s=s.replace('    const auto bytes = row.dump() + "\\n";', '    row["measurements_finite"] = Finite(row);\n    const auto bytes = row.dump() + "\\n";')
s=s.replace('{"before_record_sequence", before_record_sequence},','{"before_record_sequence", before_record_sequence}, {"pair_iterations", pair_iterations},')
s=s.replace('{"solver_diagnostics_world_scope", solver},','{"solver_diagnostics_world_scope", solver},\n      {"native_ode", NativeOde(physics)},\n      {"contacts", Contacts(physics, model, clock_ns,\n          std::string(phase) == "world_update_end_after_physics_and_pose_propagation")},')
s=s.replace('    pair_clock_ns = clock_ns;','    pair_clock_ns = clock_ns;\n    pair_iterations = model->GetWorld()->Iterations();')
s=s.replace('    if (clock_ns != pair_clock_ns) {','    if (clock_ns != pair_clock_ns || model->GetWorld()->Iterations() != pair_iterations) {')
s=s.replace('diagnostic pre/post physics world-clock mismatch','diagnostic pre/post physics world-clock or iteration mismatch')
s=s.replace('{"loaded_library_path", library}, {"compiled_source_sha256", MR3_OBSERVER_SOURCE_SHA256},','{"loaded_library_path", library}, {"compiled_source_sha256", MR3_OBSERVER_SOURCE_SHA256},\n      {"process_id", static_cast<int64_t>(::getpid())},\n      {"world_name", model->GetWorld()->Name()},\n      {"native_ode", NativeOde(physics)},')
s=s.replace('{"physics_parameters", params}, {"gravity_xyz", Vector(model->GetWorld()->Gravity())},','{"physics_parameters", params},\n      {"physics_parameters_scope", "public_GetParam; solver_type/iters/sor/cfm/erp_are_SDF_cached"},\n      {"gravity_xyz", Vector(model->GetWorld()->Gravity())},')
(OUT/'mr3_stop_response_observer.cpp').write_text(s)
shutil.copy2(OLD/'prepare_and_check.py',OUT/'prepare_and_check.py')
shutil.copy2(OLD/'World_11.10.2.cc',OUT/'World_11.10.2.cc')
shutil.copy2(OLD/'primary_source.json',OUT/'primary_source.json')
print(OUT)
