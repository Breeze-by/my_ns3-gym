"""One canonical package build and binding readback, without ROS/Gazebo init."""
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
ROS = ROOT / 'ros2_ws/ros2-multi-robot-automap'
OUT = Path('/tmp/mr3_p2a0_v21_canonical_build_v1')
assert not OUT.exists()
OUT.mkdir()
SOURCE = ROS / 'src/multi_robot/src/mr3_ray_provenance_observer.cpp'
CMAKE = ROS / 'src/multi_robot/CMakeLists.txt'
def binding(path):
    raw = path.read_bytes()
    return {'path': str(path), 'resolved': str(path.resolve()),
            'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
assert binding(SOURCE)['sha256'] == '65b1c1db64861366811266580daf8cf43bcf565fc856a405f473b02bdefd082c'
assert binding(CMAKE)['sha256'] == '170eb49947c4daa61d30f45ab8fde637aa12766182dddfda15c9ca6453d0cc0d'
old = {name: binding(ROS / 'install/multi_robot/lib' / name) for name in
       ('libmr3_gazebo_diff_drive.so', 'libmr3_stop_response_observer.so',
        'libmr3_physics_diagnostic_profile.so')}
expected = {'libmr3_gazebo_diff_drive.so': 'a014f2c618e38fc8a306d76c100083d952606333045a2e35bffce6f8b25b10c8',
            'libmr3_stop_response_observer.so': '9a1d76b0d9a6585bb2d40fb348bc5636bdd256838291e8ea605d1d05b18806bf',
            'libmr3_physics_diagnostic_profile.so': '09321ea65a2c893d2e65316f43d5ee54d5dda7014a5d40e2186b6b720055fcc1'}
assert {name: row['sha256'] for name, row in old.items()} == expected
start = time.monotonic()
result = {'schema': 'mr3-v21-canonical-ray-build-v1',
          'scope': 'Canonical colcon package build and actual installed SO binding. No ROS init, participant, Gazebo, task, native or training.',
          'source_before': binding(SOURCE), 'cmake_before': binding(CMAKE), 'old_libraries_before': old,
          'environment_selected': {name: os.environ.get(name) for name in
                                   ('PATH', 'PYTHONPATH', 'LD_LIBRARY_PATH', 'AMENT_PREFIX_PATH',
                                    'ROS_DISTRO', 'PYTHONNOUSERSITE', 'PYTHONDONTWRITEBYTECODE')},
          'commands': []}
def run(label, argv):
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    began = time.monotonic()
    stdout, stderr = OUT / (label + '.stdout.log'), OUT / (label + '.stderr.log')
    with stdout.open('xb') as one, stderr.open('xb') as two:
        child = subprocess.run(argv, cwd=ROS, stdout=one, stderr=two, check=False)
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    result['commands'].append({'label': label, 'argv': argv, 'cwd': str(ROS),
                               'exit_code': child.returncode, 'wall_seconds': time.monotonic() - began,
                               'child_user_seconds': after.ru_utime - before.ru_utime,
                               'child_system_seconds': after.ru_stime - before.ru_stime,
                               'stdout': binding(stdout), 'stderr': binding(stderr)})
    (OUT / 'execution.json').write_text(json.dumps(result, indent=2) + '\n')
    assert child.returncode == 0, (label, child.returncode)

run('colcon', ['/usr/bin/python3', '/usr/bin/colcon', 'build', '--symlink-install',
               '--packages-select', 'multi_robot', '--allow-overriding', 'nav2_bringup',
               '--parallel-workers', '2', '--event-handlers', 'console_direct+'])
library = ROS / 'install/multi_robot/lib/libmr3_ray_provenance_observer.so'
assert SOURCE.read_bytes() == Path('/tmp/mr3_p2a0_v21_ray_observer_proposal_v2/mr3_ray_provenance_observer.cpp').read_bytes()
result['installed_new_library'] = binding(library)
result['old_libraries_after'] = {name: binding(Path(row['path'])) for name, row in old.items()}
assert result['old_libraries_after'] == old
run('factory', ['/tmp/mr3_p2a0_v21_ray_observer_proposal_v2/build/mr3_ray_provenance_factory_cpu', str(library)])
run('ldd', ['/usr/bin/ldd', '-r', str(library)])
ldd = (OUT / 'ldd.stdout.log').read_text() + (OUT / 'ldd.stderr.log').read_text()
assert 'not found' not in ldd and 'undefined symbol' not in ldd
assert b'65b1c1db64861366811266580daf8cf43bcf565fc856a405f473b02bdefd082c' in library.read_bytes()
result['new_target_flags'] = binding(ROS / 'build/multi_robot/CMakeFiles/mr3_ray_provenance_observer.dir/flags.make')
result['new_target_link'] = binding(ROS / 'build/multi_robot/CMakeFiles/mr3_ray_provenance_observer.dir/link.txt')
result['source_after'], result['cmake_after'] = binding(SOURCE), binding(CMAKE)
assert result['source_after'] == result['source_before'] and result['cmake_after'] == result['cmake_before']
result['passed'], result['wall_seconds'] = True, time.monotonic() - start
(OUT / 'execution.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'passed': True, 'wall_seconds': result['wall_seconds'], 'installed_new_library': result['installed_new_library']}))
