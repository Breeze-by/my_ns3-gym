"""One authorized closed byte-custody invocation; no native/audit/canonical writes."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import resource
import subprocess
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
D = Path(__file__).resolve().parent
HELPER = D / 'mr3_p2a0_v25_matrix_pack_closed_v2.py'
EXPECTED = 'd05b4d052fb72ad6b4fcc82b8fe99c40a52f9e5506aac431d0380bb443fed845'
PLAN = ROOT / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
               'report/assets/20261018_mr3_p2a0_v25_smoother/predeclared_plan_v25.json')
FREEZE = '579f7ad21d33c6de9351eb5308f155f0fc903fd7'
PLAN_SHA = '27a5027c930e2d805187ea9e7d53fd16e797ab395c0931c4b76f707a1f6ae051'
TARGET = Path('/tmp/mr3_p2a0_v25_selected_closed_v1')
ENV = {'PATH': '/usr/bin:/bin', 'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1',
       'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'TZ': 'UTC'}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(value):
    return [value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns]


def bind(path):
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    assert identity(before) == identity(after)
    return {'path': str(path), 'sha256': sha(raw), 'bytes': len(raw), 'stat': identity(after)}


def proc_identity(pid):
    try:
        raw = Path('/proc') / str(pid) / 'stat'
        text = raw.read_text()
        fields = text[text.rfind(')') + 2:].split()
        return {'pid': pid, 'start_ticks': int(fields[19]), 'state': fields[0]}
    except (FileNotFoundError, ProcessLookupError):
        return None


def main():
    assert not TARGET.exists() and not (D / 'invocation.json').exists()
    assert sha(HELPER.read_bytes()) == EXPECTED
    assert sha(PLAN.read_bytes()) == PLAN_SHA
    extras = [Path('/tmp') / name for name in (
        'mr3_p2a0_v25_matrix_parent_console_v1.log',
        'mr3_p2a0_v25_watcher_parent_console_v1.log',
        'mr3_p2a0_v25_capture_matrix_job_v1.py',
        'mr3_p2a0_v25_matrix_capture_v1.json',
        'mr3_p2a0_v25_matrix_capture_v1_started.json',
        'mr3_p2a0_v25_watcher_capture_v1.json',
        'mr3_p2a0_v25_watcher_capture_v1_started.json',
        'mr3_p2a0_v25_actual_preflight_once_v1.py',
        'mr3_p2a0_v25_actual_preflight_delta_v1.json',
        'mr3_p2a0_v25_root_final_close_observation_v1.json',
        'mr3_p2a0_v25_launch.lock')]
    for folder in ('mr3_p2a0_v25_actual_preflight_execution_v1',
                   'mr3_p2a0_v25_capture_035_review_v1'):
        extras.extend(sorted(path for path in (Path('/tmp') / folder).rglob('*') if path.is_file()))
    extras.extend(sorted(Path('/tmp').glob('mr3_p2a0_v25_preflight_learner_entry_*')))
    assert all(path.is_file() and not path.is_symlink() for path in extras)
    assert not any(path.name == 'mr3_p2a0_v25_root_state_v1.json' for path in extras)
    assert len(extras) == len(set(extras))
    before = [bind(path) for path in [Path(__file__), HELPER, PLAN, *extras]]
    close = json.loads((Path('/tmp') / 'mr3_p2a0_v25_root_final_close_observation_v1.json').read_bytes())
    assert close['freeze'] == FREEZE and close['all_formal_jobs_finished'] is True
    fresh = []
    for row in close['identities']:
        saved = row['saved']
        current = proc_identity(saved['pid'])
        fresh.append({'saved': saved, 'current': current,
                      'same_identity_present': current is not None
                      and current['start_ticks'] == saved['start_ticks']})
    assert all(not row['same_identity_present'] for row in fresh)

    # Inventory and closed small metadata are checked before encoding, once.
    spec = importlib.util.spec_from_file_location('v25_closed_pack', HELPER)
    helper = importlib.util.module_from_spec(spec)
    exec(compile(HELPER.read_bytes(), str(HELPER), 'exec'), helper.__dict__)
    bindings = {}
    plan = json.loads(helper.read_bound(PLAN, bindings))
    states = helper.closed_metadata(plan, FREEZE, PLAN_SHA, bindings)
    selected_meta, directories = helper.metadata_selection(extras)
    source_rows = []
    for stage in helper.validate_plan(plan):
        source = Path(stage['run_directory'])
        files = helper.inventory(source)[0] if source.exists() else []
        source_rows.append({'stage': stage['stage'], 'source': str(source),
                            'source_exists': source.exists(), 'files': [
                                {'path': str(path), 'stat': initial} for path, initial in files],
                            'files_count': len(files), 'raw_bytes': sum(row[1][2] for row in files)})
    selected = [str(path) for path, _ in selected_meta]
    assert '/tmp/mr3_p2a0_v25_root_state_v1.json' not in selected
    assert not any('mr3_p2a0_v26' in path for path in selected)
    required = ('mr3_p2a0_v25_interface_process_monitor_035.json',
                'mr3_p2a0_v25_interface_smoother_mapping_035.json',
                'mr3_p2a0_v25_interface_closure_binary_review_v1.json',
                'mr3_p2a0_v25_interface_audit_execution_v1.json')
    assert all('/tmp/' + name in selected for name in required)
    prepack = {'schema': 'mr3-v25-closed-prepack-selection-v1', 'freeze': FREEZE,
               'plan_sha256': PLAN_SHA, 'native': source_rows,
               'metadata': [{'path': str(path), 'stat': value} for path, value in selected_meta],
               'metadata_files_count': len(selected_meta),
               'metadata_raw_bytes': sum(value[2] for _, value in selected_meta),
               'metadata_directories': directories, 'fresh_saved_identity_absence': fresh,
               'all_fresh_saved_identities_gone': True, 'original_closed_state': states,
               'explicit_exclusions': [{'path': '/tmp/mr3_p2a0_v25_root_state_v1.json',
                                        'reason': 'mutable navigation state; never canonical evidence; bytes not selected'},
                                       {'scope': 'all future V26 or unrelated draft roots',
                                        'reason': 'only exact V25 stage/global and named closed extras admitted'}],
               'encoding_not_yet_started': True, 'scientific_verdict_recomputed': False}
    (D / 'prepack_selection_v1.json').write_text(json.dumps(prepack, indent=2) + '\n')
    print(json.dumps({'event': 'prepack_selection_checked', 'native': [
        {'stage': row['stage'], 'files': row['files_count'], 'raw_bytes': row['raw_bytes']}
        for row in source_rows], 'metadata_files': len(selected_meta),
        'metadata_raw_bytes': prepack['metadata_raw_bytes'],
        'fresh_saved_identities_gone': len(fresh), 'mutable_state_selected': False}), flush=True)
    argv = ['/usr/bin/python3', '-B', str(HELPER), '--freeze', FREEZE,
            '--target', str(TARGET), '--all-writers-closed']
    for path in extras:
        argv.extend(['--extra', str(path)])
    invocation = {'schema': 'mr3-v25-closed-pack-invocation-v1', 'argv': argv,
                  'cwd': str(ROOT), 'environment_exact': ENV, 'bound_inputs_before': before,
                  'prepack_selection': bind(D / 'prepack_selection_v1.json'),
                  'operator_GO': 'Root confirmed all native, mandatory/formal, parent, watcher '
                                 'and selected diagnostic writers closed; only one pack authorized.',
                  'scope': 'Lossless byte custody; all original FAIL/SKIP/035 preserved; '
                           'no native/formal/canonical/Git mutation.'}
    (D / 'invocation.json').write_text(json.dumps(invocation, indent=2) + '\n')
    usage_before = resource.getrusage(resource.RUSAGE_CHILDREN)
    started = time.monotonic()
    with (D / 'stdout.txt').open('xb') as out, (D / 'stderr.txt').open('xb') as err:
        result = subprocess.run(argv, cwd=ROOT, env=ENV, stdout=out, stderr=err)
    wall = time.monotonic() - started
    usage_after = resource.getrusage(resource.RUSAGE_CHILDREN)
    after = [bind(Path(row['path'])) for row in before]
    receipt = {**invocation, 'bound_inputs_after': after, 'input_bindings_stable': before == after,
               'exit_code': result.returncode, 'wall_seconds': wall,
               'child_user_cpu_seconds': usage_after.ru_utime - usage_before.ru_utime,
               'child_system_cpu_seconds': usage_after.ru_stime - usage_before.ru_stime,
               'stdout': bind(D / 'stdout.txt'), 'stderr': bind(D / 'stderr.txt'),
               'helper_invoked_once': True, 'retry_or_signals': False,
               'custody_completed': result.returncode == 0 and before == after}
    if (TARGET / 'manifest.json').exists():
        receipt['output_manifest'] = bind(TARGET / 'manifest.json')
        top = json.loads((TARGET / 'manifest.json').read_bytes())
        groups = [Path(value['manifest']) for value in top['native'].values() if value['source_exists']]
        groups.append(Path(top['metadata']['manifest']))
        receipts, parts = [], []
        for group in groups:
            group_raw = group.read_bytes()
            manifest = json.loads(group_raw)
            assert manifest['passed'] is True and manifest['source_end_sha_and_stat_verified'] is True
            for original in manifest['files']:
                for part in original['parts']:
                    assert ROOT / part['prospective_canonical'] == (
                        ROOT / manifest['prospective_prefix'] / part['selected'])
                    parts.append(part)
            receipts.append(bind(group))
        receipt['selected_group_manifests'] = receipts
        receipt['native_and_metadata_original_files'] = sum(
            json.loads(path.read_bytes())['source_files'] for path in groups)
        receipt['selected_encoded_parts'] = len(parts)
        receipt['selected_encoded_bytes'] = sum(part['selected_bytes'] for part in parts)
        receipt['selected_decoded_original_bytes'] = sum(
            json.loads(path.read_bytes())['raw_bytes'] for path in groups)
        receipt['largest_encoded_part'] = max(parts, key=lambda part: part['selected_bytes'])
        receipt['all_prospective_canonical_paths_exact'] = True
    (D / 'execution.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'execution': str(D / 'execution.json'), 'exit_code': result.returncode,
                      'wall_seconds': wall, 'custody_completed': receipt['custody_completed'],
                      'output_manifest': receipt.get('output_manifest')}), flush=True)
    raise SystemExit(result.returncode if before == after else 1)


if __name__ == '__main__':
    main()
