import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

REPO=Path('/home/zhuyulab/ns3-workspace')
W=REPO/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A=W/'report/assets/20261018_mr3_p2a0_v19'
OUT=Path(__file__).parent


def sha(raw):return hashlib.sha256(raw).hexdigest()


def ref(path):
    raw=path.read_bytes()
    return {'path':str(path),'bytes':len(raw),'sha256':sha(raw)}


def statid(stat):
    return [stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns,stat.st_ctime_ns]


def stable_hash(path):
    before=statid(path.stat());h=hashlib.sha256();count=0
    with path.open('rb') as stream:
        assert statid(os.fstat(stream.fileno()))==before
        while True:
            block=stream.read(1048576)
            if not block:break
            count+=len(block);h.update(block)
        assert statid(os.fstat(stream.fileno()))==before
    assert statid(path.stat())==before and count==before[2]
    return {'sha256':h.hexdigest(),'bytes':count,'stat_before_after':before}


def main():
    start=time.monotonic()
    docs=[W/'report/20261018_mr3_p2a0_v19.md',W/'log.md']
    docs_before={str(path):ref(path) for path in docs}
    doc_text={str(path):path.read_text() for path in docs}
    diff_argv=['/usr/bin/git','diff','--']+[str(path.relative_to(REPO)) for path in docs]
    diff=subprocess.run(diff_argv,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
    assert diff.returncode==0
    (OUT/'docs.diff').write_bytes(diff.stdout)
    native=[]
    for stage,expected_sha in [('baseline','fdc8f5ae17007dc4b7331bbf9fad1ad02186f4cc1b43390531600ef15874cf2a'),('iters150','33789be67b574323108375d939d464116371abaea645cbf04fbe0bfde8dbb7eb')]:
        path=A/'native'/stage/'manifest.json'
        raw=path.read_bytes();tmp=Path('/tmp/mr3_p2a0_v19_selected_native_v1')/stage/'manifest.json'
        assert sha(raw)==expected_sha and raw==tmp.read_bytes()
        manifest=json.loads(raw)
        assert manifest['passed'] is True and manifest['source_statfinal_inventory_exact'] is True
        assert manifest['freeze']=='72d0465ddd1bbee09af117cfd9d89b7e729f8578'
        expected_paths={str(path),str(path.parent/'helper_configuration.json')}
        encoded_bytes=parts=raw_bytes=largest=0
        for original in manifest['files']:
            assert original['source_stat_initial']==original['source_stat_final']
            assert original['verification']['all_part_encoded_and_decoded_sha_verified'] is True
            assert original['verification']['reassembled_decoded_sha256']==original['raw_sha256']
            raw_bytes+=original['raw_bytes']
            for part in original['parts']:
                selected=path.parent/part['selected'];proof=stable_hash(selected)
                assert proof['sha256']==part['selected_sha256'] and proof['bytes']==part['selected_bytes']
                assert proof['bytes']<100000000
                expected_paths.add(str(selected));parts+=1;encoded_bytes+=proof['bytes'];largest=max(largest,proof['bytes'])
        actual=[p for p in path.parent.rglob('*') if p.is_file()]
        assert set(str(p) for p in actual)==expected_paths
        assert raw_bytes==manifest['raw_bytes'] and encoded_bytes==manifest['selected_bytes'] and parts==manifest['selected_parts']
        native.append({'stage':stage,'manifest':ref(path),'manifest_exact_tmp_copy':True,
                       'original_files':len(manifest['files']),'original_raw_bytes':raw_bytes,
                       'encoded_parts_verified':parts,'encoded_bytes_verified':encoded_bytes,'largest_encoded_part_bytes':largest,
                       'canonical_files_including_metadata':len(actual),'canonical_bytes_including_metadata':sum(p.stat().st_size for p in actual),
                       'all_encoded_sha_size_and_stat_verified':True,
                       'raw_codec_reassembly_scope':'Existing whole/part decoder proofs retained; no gzip/raw decoded or large original scanned by this review.'})
    archives=[]
    for name,expected_count,expected_size,expected_sha in [
        ('closed_core_v3',128,963557,'f75c75127bccbc26e895a31b43293c93fc18b61b6bac3a24cd475293118b2e8b'),
        ('closed_pose_v1',67,328121,'0b8d12e26af29b5e6a6032b2a8dc51a70aa3ca2bcc55a91c728fb157b5b23fca')]:
        path=A/name/'manifest_v1.json';manifest=json.loads(path.read_bytes())
        archive=A/name/manifest.get('archive','originals.tar.gz')
        proof=stable_hash(archive)
        assert proof['bytes']==manifest['archive_bytes']==expected_size
        assert proof['sha256']==manifest['archive_sha256']==expected_sha
        assert len(manifest['files'])==expected_count
        archives.append({'name':name,'manifest':ref(path),'archive':str(archive),
                         'encoded_sha_size_and_stat':proof,'original_count':len(manifest['files']),
                         'original_bytes':sum(row['bytes'] for row in manifest['files']),
                         'scope':'Encoded archive verification only; prior recorded roundtrip is retained, not repeated.'})
    closed_path=Path('/tmp/mr3_p2a0_v19_closed_summary_v2.json');closed=json.loads(closed_path.read_bytes())
    assert closed['capture_admission_native_closure_passed'] is True
    assert closed['physical_response_pair_passed'] is False and closed['iters150_selected'] is False
    assert closed['fresh_saved_identity_count']==91 and closed['fresh_live_saved_identities']==[]
    assert closed['native_wall_seconds']==1638.4207719592378
    assert closed['v18_plus_v19_diagnostic_native_wall_seconds']==2489.3860735194758
    assert closed['unused_of_3600_diagnostic_ceiling']==1110.6139264805242
    stage_facts=[]
    for item in closed['stages']:
        stage=item['stage'];execution_path=Path('/tmp/mr3_p2a0_v19_'+stage+'_execution.json')
        execution=json.loads(execution_path.read_bytes())
        formal_path=Path('/tmp/mr3_p2a0_v19_'+stage+'_observer_review.json');formal=json.loads(formal_path.read_bytes())
        physical_path=Path('/tmp/mr3_p2a0_v19_'+stage+'_physical_review.json');physical=json.loads(physical_path.read_bytes())
        assert execution['passed'] is True and execution['status']=='completed'
        assert formal['passed'] is True and physical['passed'] is (stage=='baseline')
        assert item['strict_closure']['passed'] is True
        assert item['strict_closure']['started_processes']==item['strict_closure']['exited_processes']==39
        assert item['saved_reset_records']==1 and item['returned_step_calls']==32 and item['saved_api_records']==33
        assert formal['actual_interval']['end_ns']-formal['actual_interval']['start_ns']==32000000000
        stage_facts.append({'stage':stage,'native_wall_seconds':execution['native_wall_seconds'],
                            'interval':formal['actual_interval'],'original_physical_passed':physical['passed'],
                            'consumers':[{key:row[key] for key in ['label','returncode','passed','wall_seconds']} for row in execution['diagnostic_consumers']],
                            'strict_closure_passed':True,'native_exits_zero':39,
                            'references':[ref(execution_path),ref(formal_path),ref(physical_path)]})
    required_literals=['72d0465ddd1bbee09af117cfd9d89b7e729f8578','916.0106622199528','722.410109739285','731.308353652712','16.604266077280045','679.791821338702','14.919598877895623','1638.4207719592378','2489.3860735194758','1110.6139264805242','1870','2905.954739546403','12714005','.642580','.794788','11.529448','9.335524']
    for path,text in doc_text.items():
        for literal in required_literals:assert literal in text,(path,literal)
        assert '150尚未选用' in text and 'V17' in text and 'FAIL' in text
    link_checks=[]
    report_path=docs[0]
    for destination in re.findall(r'\]\(([^)]+)\)',doc_text[str(report_path)]):
        if '://' in destination or destination.startswith('#'):continue
        destination=destination.split('#',1)[0]
        target=(report_path.parent/destination).resolve()
        assert target.exists(),(destination,str(target))
        link_checks.append({'destination':destination,'exists':True})
    for path in docs:assert ref(path)==docs_before[str(path)],'doc bytes changed during independent review'
    preflight=json.loads(Path('/tmp/mr3_p2a0_v19_source_preflight.json').read_bytes())
    assert preflight['passed'] is True and len(preflight['source_bindings'])==103 and len(preflight['independent_source_bindings'])==155
    report={'schema':'mr3-v19-closure-encoded-doc-independent-review-v1','passed':True,
            'scope':'Read-only canonical encoded bytes/copies, small closed receipts, documentary numbers/links. No new native/formal or physical acceptance credit; no original raw/gzip reassembly repeated.',
            'native_encoded':native,'canonical_native_total_files':sum(row['canonical_files_including_metadata'] for row in native),
            'canonical_native_total_bytes':sum(row['canonical_bytes_including_metadata'] for row in native),
            'small_archives':archives,'stage_facts':stage_facts,
            'closed_summary':ref(closed_path),'runtime_source_count':103,'independent_source_count':155,
            'documentation_before_after':list(docs_before.values()),'required_numeric_literals_checked_per_document':len(required_literals),
            'report_links':link_checks,'git_diff_argv':diff_argv,'git_diff_returncode':diff.returncode,'git_diff':ref(OUT/'docs.diff'),
            'semantic_review':['Capture/admission/strict closure PASS is separated from iters150 physical=False and no-valid-stimulus scope.',
                               'Neither endpoint nor sparse startup ray prediction is claimed to prove all poses or actual scan provenance.',
                               'Fixed diagnostic budget/pilot balance and archive sizes agree with original closed receipts.',
                               'Original failures/V17 rest issue/150-not-selected/whole-matrix-not-complete remain explicit.'],
            'native_calls':0,'formal_audit_calls':0,'canonical_writes':0,'wall_seconds':time.monotonic()-start}
    output=OUT/'review_v1.json';output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'review':ref(output),'canonical_native_files':report['canonical_native_total_files'],'canonical_native_bytes':report['canonical_native_total_bytes'],'archive_counts':[row['original_count'] for row in archives],'wall_seconds':report['wall_seconds']}))


if __name__=='__main__':main()
