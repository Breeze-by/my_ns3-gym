#!/usr/bin/env python3
"""Lossless custody of the stopped production auditor independent review directory."""
import datetime
import gzip
import hashlib
import io
import json
import os
import pathlib
import stat
import sys
import tarfile
import time

ROOTS = [pathlib.Path("/tmp/mr3_p2a0_v22_production_auditor_independent_review_v1")]
OUT = pathlib.Path(__file__).parent
ARCHIVE = OUT.parent / 'mr3_p2a0_v22_production_auditor_review_sealed_v1.tar.gz'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def metadata(value):
    return {key: getattr(value, key) for key in
            ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_mode')}


def read_stable(path):
    fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
    try:
        before = metadata(os.fstat(fd))
        assert stat.S_ISREG(before['st_mode']), str(path)
        parts = []
        while True:
            part = os.read(fd, 1024 * 1024)
            if not part:
                break
            parts.append(part)
        data = b''.join(parts)
        after = metadata(os.fstat(fd))
    finally:
        os.close(fd)
    assert before == after == metadata(path.stat()), str(path)
    assert len(data) == before['st_size'], str(path)
    return data, before, after


def add(tar, member, data, mode=0o644):
    info = tarfile.TarInfo(member)
    info.size = len(data)
    info.mode = stat.S_IMODE(mode)
    info.mtime = 0
    info.uid = info.gid = 0
    info.uname = info.gname = ''
    tar.addfile(info, io.BytesIO(data))


start = time.monotonic()
began = datetime.datetime.now(datetime.timezone.utc).isoformat()
selected, excluded, content = [], [], {}
directory_counts = {}
for root in ROOTS:
    assert root.is_dir(), str(root)
    count = {'files': 0, 'selected_non_elf': 0, 'excluded_elf': 0}
    for path in sorted(root.rglob('*')):
        if path.is_dir():
            continue
        data, before, after = read_stable(path)
        member = str(path.relative_to('/tmp'))
        row = {'path': str(path), 'member': member, 'bytes': len(data),
               'sha256': digest(data), 'stat_before': before, 'stat_after': after,
               'role': 'stopped_source_cpu_or_independent_review_original'}
        count['files'] += 1
        if data.startswith(b'\x7fELF'):
            row['exclusion_reason'] = 'ELF executable or Python cache bytes intentionally excluded; identity retained in this manifest.'
            excluded.append(row)
            count['excluded_elf'] += 1
        else:
            selected.append(row)
            content[member] = data
            count['selected_non_elf'] += 1
    directory_counts[str(root)] = count
helper = pathlib.Path(__file__).resolve()
data, before, after = read_stable(helper)
member = str(helper.relative_to('/tmp'))
selected.append({'path': str(helper), 'member': member, 'bytes': len(data),
                 'sha256': digest(data), 'stat_before': before, 'stat_after': after,
                 'role': 'custody_helper_source'})
content[member] = data
manifest = {
    'schema': 'mr3-v22-production-auditor-independent-review-custody-manifest-v1',
    'scope': 'All stopped production auditor independent review originals, plus this custody helper. ELF, pycache and pyc bytes excluded with identity recorded. No review/test/build/native rerun.',
    'directory_counts': directory_counts, 'files': selected,
    'excluded_elf': excluded,
    'selected_directory_originals': sum(value['selected_non_elf'] for value in directory_counts.values()),
    'helper_sources': 1, 'selected_files': len(selected),
    'selected_raw_bytes': sum(row['bytes'] for row in selected),
    'preserved_history': 'Original v5 test incompatibility and its exact v6 correction remain described in the unchanged review; no original review file overwritten.'}
manifest_data = (json.dumps(manifest, indent=2) + '\n').encode()
manifest_path = OUT / 'manifest_v1.json'
with manifest_path.open('xb') as stream:
    stream.write(manifest_data)
manifest_member = str(manifest_path.relative_to('/tmp'))
with ARCHIVE.open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=6) as encoded:
        with tarfile.open(fileobj=encoded, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for row in selected:
                add(tar, row['member'], content[row['member']], row['stat_before']['st_mode'])
            add(tar, manifest_member, manifest_data)
members_verified = 0
with tarfile.open(ARCHIVE, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(selected) + 1
    for row in selected:
        data = tar.extractfile(row['member']).read()
        assert len(data) == row['bytes'] and digest(data) == row['sha256']
        members_verified += 1
    assert tar.extractfile(manifest_member).read() == manifest_data
    members_verified += 1
for row in selected + excluded:
    data, before, after = read_stable(pathlib.Path(row['path']))
    assert before == after == row['stat_after']
    assert digest(data) == row['sha256']
archive_data = ARCHIVE.read_bytes()
handoff = {
    'schema': 'mr3-v22-production-auditor-independent-review-custody-handoff-v1',
    'passed': True, 'manifest_path': str(manifest_path),
    'manifest_sha256': digest(manifest_data),
    'archive_path': str(ARCHIVE), 'archive_bytes': len(archive_data),
    'archive_sha256': digest(archive_data),
    'selected_directory_originals': manifest['selected_directory_originals'],
    'selected_files_including_helper': len(selected),
    'selected_raw_bytes': manifest['selected_raw_bytes'],
    'excluded_cpu_elf_count': len(excluded),
    'archive_members_verified': members_verified,
    'all_selected_and_excluded_source_final_sha_stat_stable': True,
    'execution': {'argv': sys.argv, 'executable': sys.executable,
                  'cwd': os.getcwd(), 'began_utc': began,
                  'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  'wall_seconds': time.monotonic() - start},
    'scope': 'Lossless TMP custody only, no compiler/factory/math reruns, canonical writes or native runs.'}
handoff_path = OUT / 'handoff_v1.json'
with handoff_path.open('x') as stream:
    json.dump(handoff, stream, indent=2)
    stream.write('\n')
print(json.dumps(handoff))
