"""Pack exact preflight runtime Git objects only; no build/native side effects."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path('/home/zhuyulab/ns3-workspace')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--preflight', type=Path,
                    default=Path('/tmp/mr3_p2a0_v10_source_preflight.json'))
args = parser.parse_args()
proof_raw = args.preflight.read_bytes()
proof = json.loads(proof_raw)
freeze = proof['freeze']
assert proof['passed'] is True and re.fullmatch('[0-9a-f]{40}', freeze)
for reference in ('HEAD', '@{u}'):
    assert subprocess.check_output(['git', 'rev-parse', reference], cwd=ROOT,
                                   text=True).strip() == freeze
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
paths = sorted(proof['source_bindings'])
assert paths and all(not Path(path).is_absolute() and '..' not in Path(path).parts
                     for path in paths)
manifest = Path('/tmp') / ('source_bindings_' + freeze[:12] + '.json')
archive = manifest.with_suffix('.tar.gz')
assert not manifest.exists() and not archive.exists(), 'do not replace any source pack'
tar = subprocess.check_output(['git', 'archive', '--format=tar', freeze, '--', *paths], cwd=ROOT)
entries = []
with tarfile.open(fileobj=io.BytesIO(tar), mode='r:') as stream:
    members = {item.name: item for item in stream.getmembers() if item.isfile()}
    assert set(members) == set(paths)
    for relative in paths:
        raw = stream.extractfile(members[relative]).read()
        assert raw == (ROOT / relative).read_bytes(), relative + ' worktree differs'
        assert raw == subprocess.check_output(['git', 'show', freeze + ':' + relative], cwd=ROOT)
        binding = proof['source_bindings'][relative]
        assert sha(raw) == binding['sha256'], relative + ' preflight source SHA differs'
        entries.append({'path': relative, 'bytes': len(raw), 'sha256': sha(raw),
                        'git_source': freeze + ':' + relative})
encoded = gzip.compress(tar, mtime=0)
with archive.open('xb') as output:
    output.write(encoded)
assert gzip.decompress(archive.read_bytes()) == tar
result = {'schema': 'mr3-exact-git-source-pack-v1', 'freeze': freeze, 'files': entries,
          'archive': str(archive), 'encoded_sha256': sha(encoded), 'tar_sha256': sha(tar),
          'preflight': str(args.preflight), 'preflight_sha256': sha(proof_raw),
          'scope': 'Exact runtime source_bindings objects; independent sources remain '
                   'separately SHA/Git-bound by the frozen plan and preflight.'}
with manifest.open('x') as output:
    output.write(json.dumps(result, indent=2) + '\n')
assert args.preflight.read_bytes() == proof_raw
print(json.dumps({'passed': True, 'freeze': freeze, 'sources': len(entries),
                  'manifest': str(manifest), 'manifest_sha256': sha(manifest.read_bytes()),
                  'archive': str(archive), 'archive_bytes': len(encoded),
                  'encoded_sha256': sha(encoded), 'tar_sha256': sha(tar)}))
