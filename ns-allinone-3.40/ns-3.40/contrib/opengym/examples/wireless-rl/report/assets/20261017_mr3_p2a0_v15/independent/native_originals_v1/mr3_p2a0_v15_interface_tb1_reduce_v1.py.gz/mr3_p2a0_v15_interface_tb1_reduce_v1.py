"""One closed-log streaming tb1 request/decision diagnostic, not a formal audit."""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
EPISODE = ROOT / ('ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/'
                  'mr3_p2a0_20261017_v15_interface/worker0/episode001_open_101')
OUT = Path('/tmp/mr3_p2a0_v15_interface_tb1_closed_diagnostic_v1')


def main():
    assert (EPISODE / 'supervisor_shutdown.json').is_file()
    OUT.mkdir(exist_ok=False)
    metadata = json.loads((EPISODE / 'metadata.json').read_bytes())
    assert metadata['freeze'] == '17ef3cb212aacd6e9e4fcde65783bdf2528da955'
    with (EPISODE / 'transitions.jsonl').open() as stream:
        reset = json.loads(next(stream))
    release = reset['info']['release_time_ns']
    path = EPISODE / 'motion_safety.jsonl'
    before = path.stat()
    digest = hashlib.sha256()
    raw_requests, actuals = {}, {}
    kinds, failures = Counter(), []
    intervals = ((0, 1.5), (1.5, 10), (10, 13), (13, 15), (15, 19), (19, 22),
                 (22, 28), (28, 32.0000001))
    stats = {}
    for a, b in intervals:
        stats[(a, b)] = {'decisions': 0, 'request_nonzero_v': 0, 'request_nonzero_w': 0,
                         'output_nonzero_v': 0, 'output_nonzero_w': 0, 'reasons': Counter()}
    selected, unique = {}, {}
    nearest_t19, maximum_request_v, minimum_margin = None, None, None
    task_decisions = 0
    with path.open('rb') as stream:
        for line_number, line in enumerate(stream, 1):
            digest.update(line)
            row = json.loads(line)
            kinds[row['kind']] += 1
            payload = row['payload']
            if row['kind'] in ('settled_turn_model_failure', 'normal_control_model_invalid',
                                'invalid_received_states', 'clock_changed_during_decision',
                                'control_failure', 'failure'):
                failures.append({'line': line_number, 'row': row})
            if payload.get('robot') != 'tb1':
                continue
            if row['kind'] == 'raw_request':
                raw_requests[payload['request']['sequence']] = (line_number, row)
            elif row['kind'] == 'actual_cmd_vel':
                actuals[payload.get('observed_decision_sequence')] = (line_number, row)
            elif row['kind'] == 'decision':
                clock = payload['clock_ns']
                elapsed = (clock - release) / 1e9
                if not 0 <= elapsed <= 32 or payload.get('phase_kind') == 'stop':
                    continue
                task_decisions += 1
                request, decision = payload['request'], payload['decision']
                for a, b in intervals:
                    if a <= elapsed < b:
                        item = stats[(a, b)]
                        item['decisions'] += 1
                        item['reasons'][decision['reason']] += 1
                        item['request_nonzero_v'] += bool(request and request.get('v'))
                        item['request_nonzero_w'] += bool(request and request.get('w'))
                        item['output_nonzero_v'] += decision['output'][0] != 0
                        item['output_nonzero_w'] += decision['output'][1] != 0
                        break
                if not 18 <= elapsed <= 22:
                    continue
                entry = (line_number, row)
                signature = (decision['reason'], bool(request and request.get('v')),
                             bool(request and request.get('w')),
                             tuple(value != 0 for value in decision['output']))
                unique.setdefault(signature, entry)
                unique[signature + ('last',)] = entry
                if nearest_t19 is None or abs(elapsed - 19) < nearest_t19[0]:
                    nearest_t19 = (abs(elapsed - 19), entry)
                if maximum_request_v is None or abs(request.get('v') or 0) > maximum_request_v[0]:
                    maximum_request_v = (abs(request.get('v') or 0), entry)
                margin = decision.get('minimum_margin_m')
                if margin is not None and (minimum_margin is None or margin < minimum_margin[0]):
                    minimum_margin = (margin, entry)
    after = path.stat()
    assert (before.st_ino, before.st_size, before.st_mtime_ns) == (
        after.st_ino, after.st_size, after.st_mtime_ns), 'closed source changed during diagnostic'
    for entry in list(unique.values()) + [item[1] for item in
                                          (nearest_t19, maximum_request_v, minimum_margin)
                                          if item is not None]:
        selected[entry[0]] = entry[1]
    compact = []
    originals = []
    for line_number, row in sorted(selected.items()):
        payload = row['payload']
        request, own = payload['request'], payload['own_state']
        decision = payload['decision']
        raw = raw_requests.get(request['sequence'])
        actual = actuals.get(payload['decision_sequence'])
        assert raw is not None and raw[1]['payload']['request'] == request
        assert actual is not None and [actual[1]['payload']['twist']['linear']['x'],
                                       actual[1]['payload']['twist']['angular']['z']] == decision['output']
        originals.extend([{'source_line': raw[0], 'row': raw[1]},
                          {'source_line': line_number, 'row': row},
                          {'source_line': actual[0], 'row': actual[1]}])
        compact.append({'line': line_number, 'record_sequence': row['record_sequence'],
                        'task_elapsed_sec': (payload['clock_ns'] - release) / 1e9,
                        'clock_ns': payload['clock_ns'], 'decision_sequence': payload['decision_sequence'],
                        'request_sequence': request['sequence'], 'raw_request_line': raw[0],
                        'actual_receipt_line': actual[0],
                        'request': {key: request.get(key) for key in
                                    ('v', 'w', 'received_stamp', 'supported')},
                        'own': {key: own.get(key) for key in
                                ('x', 'y', 'yaw', 'v', 'w', 'planar_speed_mps',
                                 'source_stamp', 'odom_source_stamp', 'tf_source_stamp', 'settled_turn')},
                        'decision': decision})
    report = {'schema': 'mr3-v15-tb1-closed-single-stream-diagnostic-v1',
              'scope': 'Single streaming reduction after supervisor_shutdown artifact exists; '
                       'not a formal gate, not a ModelStates read or a new native experiment.',
              'epoch': metadata['epoch'], 'freeze': metadata['freeze'],
              'source': {'path': str(path), 'bytes': before.st_size,
                         'sha256': digest.hexdigest(), 'inode': before.st_ino,
                         'mtime_ns': before.st_mtime_ns, 'stable_after_read': True},
              'release_ns': release, 'rows': sum(kinds.values()), 'kinds': dict(kinds),
              'tb1_task_decisions': task_decisions,
              'tb1_intervals': [{'range_sec': list(key), **value,
                                  'reasons': dict(value['reasons'])}
                                 for key, value in stats.items()],
              't18_to_t22_distinct_first_and_last': compact,
              'selected_raw_and_actual_receipt_exactly_bound': True,
              'model_or_input_failure_rows': failures,
              'selected_originals': 'selected_motion_rows.jsonl',
              'created_wall_monotonic_ns': time.monotonic_ns()}
    (OUT / 'selected_motion_rows.jsonl').write_text(''.join(
        json.dumps(row, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n'
        for row in originals))
    (OUT / 'review.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'out': str(OUT), 'source_sha256': digest.hexdigest(),
                      'tb1_intervals': report['tb1_intervals'], 'selected': compact,
                      'failure_count': len(failures)}, separators=(',', ':')))


if __name__ == '__main__':
    main()
