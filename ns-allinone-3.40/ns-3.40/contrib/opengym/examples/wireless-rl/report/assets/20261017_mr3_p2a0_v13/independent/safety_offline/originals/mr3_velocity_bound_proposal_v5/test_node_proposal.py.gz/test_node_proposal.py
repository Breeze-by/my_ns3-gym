"""Real extracted node methods with native-free source-time model fixtures."""

import ast
from collections import deque
import copy
import hashlib
import json
import math
from pathlib import Path
from types import SimpleNamespace
import unittest

import test_proposal as base


HERE = Path(__file__).resolve().parent
NEW = base.NEW
ROBOTS = NEW.ROBOTS
EPOCH = base.EPOCH
TARGET = 10_020_000_000


def message(value):
    if isinstance(value, dict):
        return SimpleNamespace(**{key: message(item) for key, item in value.items()})
    if isinstance(value, list):
        return [message(item) for item in value]
    return value


def raw(source_ns=TARGET, vx=.1, vy=0., wx=0., wy=0., wz=0.):
    result = copy.deepcopy(base.FIXTURE['raw_own_odom']['payload']['message'])
    result['header']['stamp'] = {'sec': source_ns // 10**9, 'nanosec': source_ns % 10**9}
    result['twist']['twist'] = {
        'linear': {'x': vx, 'y': vy, 'z': 0.},
        'angular': {'x': wx, 'y': wy, 'z': wz}}
    return result


def state(name, payload, sequence):
    result = base.state(payload['twist']['twist']['linear']['x'],
                        payload['twist']['twist']['linear']['y'],
                        w=payload['twist']['twist']['angular']['z'])
    source = payload['header']['stamp']
    seconds = source['sec'] + source['nanosec'] / 1e9
    result.update(name=name, source_stamp=seconds, odom_source_stamp=seconds,
                  tf_source_stamp=seconds, input_sequences={'odom': sequence, 'tf': 1})
    return result


def methods(filename):
    tree = ast.parse((HERE / filename).read_text())
    cls = next(item for item in tree.body if isinstance(item, ast.ClassDef)
               and item.name == 'MotionSafety')
    selected = [item for item in cls.body if isinstance(item, ast.FunctionDef)
                and item.name in {'normal_velocity_fault', 'receive_odom', 'emit_motion'}]
    ns = dict(math=math, json=json, hashlib=hashlib, ROBOTS=ROBOTS,
              measured_velocity_error=NEW.measured_velocity_error,
              timestamp_ns=NEW.timestamp_ns, elapsed_ns=NEW.elapsed_ns,
              valid_state=NEW.valid_state, guard_motion=NEW.guard_motion,
              COMMAND_TIMEOUT_SEC=NEW.COMMAND_TIMEOUT_SEC,
              Bool=lambda **kwargs: SimpleNamespace(**kwargs),
              String=lambda **kwargs: SimpleNamespace(**kwargs),
              Twist=lambda: SimpleNamespace(linear=SimpleNamespace(x=0., y=0., z=0.),
                                            angular=SimpleNamespace(x=0., y=0., z=0.)))
    source = ast.parse((HERE / 'original_mr3_information.py').read_text())
    helpers = {'stamp_payload', 'vector_payload', 'quaternion_payload',
               'pose_payload', 'header_payload', 'odom_payload'}
    pure = [item for item in source.body if isinstance(item, ast.FunctionDef)
            and item.name in helpers]
    exec(compile(ast.fix_missing_locations(ast.Module(body=pure, type_ignores=[])),
                 'actual_information_payload_helpers', 'exec'), ns)
    extracted = ast.ClassDef(name='ActualNode', bases=[], keywords=[], body=selected,
                             decorator_list=[])
    exec(compile(ast.fix_missing_locations(ast.Module(body=[extracted], type_ignores=[])),
                 filename, 'exec'), ns)
    return ns['ActualNode']


NODE = methods('proposed_motion_safety.py')
OLD_NODE = methods('original_motion_safety.py')


def node(*, started=True, release_ns=10_000_000_000):
    result = NODE()
    result.epoch = EPOCH
    result.started = started
    result.stop_time = None
    result.halted = None
    result.normal_control_model_fault = None
    result.records = []
    result.record = lambda kind, payload: result.records.append((kind, payload))
    result.own_input_history = {name: {'odom': deque(), 'tf': deque()} for name in ROBOTS}
    result.input_sequences = {name: {'odom': 1, 'tf': 1} for name in ROBOTS}
    result.odometry = {}
    result.settled_turn = {
        name: SimpleNamespace(release_ns=release_ns if started else None,
                              observe=lambda *_: None, output=lambda *_: None)
        for name in ROBOTS}
    result.local = {}
    peers = []
    for name in ROBOTS:
        payload = raw()
        result.own_input_history[name]['odom'].append((1, message(payload)))
        result.local[name] = state(name, payload, 1)
        peer = dict(result.local[name], odometry=copy.deepcopy(payload), sequence=10)
        peers.append(peer)
    result.local_state = lambda name: result.local.get(name)
    result.received = {'epoch': EPOCH, 'sequence': 10, 'robots': peers}
    result.get_clock = lambda: SimpleNamespace(now=lambda: SimpleNamespace(nanoseconds=TARGET))
    result.now = lambda: TARGET / 1e9
    return result


class NodeModelProposalTests(unittest.TestCase):
    def test_rawless_scalar_must_dominate_abs_v_and_v_w_are_typed_finite(self):
        value = base.state()
        value['v'] = .2
        self.assertEqual(NEW.measured_velocity_error(value), 'inconsistent_planar_speed')
        self.assertFalse(NEW.valid_state(value, 10., EPOCH))
        for key in ('v', 'w'):
            for invalid in (True, None, float('nan'), float('inf'), '.1'):
                value = base.state()
                value[key] = invalid
                self.assertEqual(NEW.measured_velocity_error(value),
                                 'invalid_measured_velocity')
        for v in (.1, -.1):
            value = base.state()
            value['v'] = v
            self.assertIsNone(NEW.measured_velocity_error(value))

    def test_exact_raw_peak_cannot_be_hidden_by_later_healthy_own_sample(self):
        value = node(release_ns=75_100_000_000)
        peak = base.FIXTURE['raw_own_odom']['payload']
        healthy = raw(92_620_000_000)
        value.own_input_history['tb2']['odom'] = deque([
            (2650, message(peak['message'])), (2651, message(healthy))])
        value.local['tb2'] = state('tb2', healthy, 2651)
        fault = value.normal_velocity_fault(92_620_000_000)
        self.assertEqual(fault['reason'], 'measured_planar_speed_exceeded')
        self.assertEqual(fault['role'], 'own_history')
        self.assertEqual(fault['input_sequence'], 2650)
        self.assertEqual(fault['odom_source_ns'], 92_617_000_000)
        self.assertEqual(fault['classification'],
                         'normal_control_model_invalid_not_task_attributed')
        self.assertEqual(fault['twist'], peak['message']['twist']['twist'])

    def test_full_own_angular_xyz_is_checked_from_original_history(self):
        value = node()
        payload = raw(wx=1.3)
        value.own_input_history['tb1']['odom'] = deque([(1, message(payload))])
        self.assertIsNone(NEW.measured_velocity_error(value.local['tb1']))
        self.assertEqual(value.normal_velocity_fault(TARGET)['reason'],
                         'measured_angular_speed_exceeded')

    def test_future_callback_is_retained_and_rejected_only_when_source_causal(self):
        value = node()
        payload = raw(TARGET + 19_000_000, vx=.31)
        value.receive_odom(message(payload), 'tb1')
        self.assertIsNone(value.halted)
        self.assertIsNone(value.normal_velocity_fault(TARGET))
        self.assertEqual(value.normal_velocity_fault(TARGET + 20_000_000)['odom_source_ns'],
                         TARGET + 19_000_000)

    def test_unselected_prewarm_peak_does_not_latch_after_release(self):
        value = node()
        value.own_input_history['tb1']['odom'].appendleft(
            (0, message(raw(9_900_000_000, vx=.9))))
        self.assertIsNone(value.normal_velocity_fault(TARGET))
        self.assertIsNone(value.halted)

    def test_warmup_callback_itself_never_creates_new_hard_model_latch(self):
        value = node(started=False)
        value.receive_odom(message(raw(TARGET + 19_000_000, vx=.9)), 'tb1')
        self.assertIsNone(value.halted)
        self.assertIsNone(value.normal_control_model_fault)
        self.assertTrue(any(kind == 'own_odom' for kind, _ in value.records))

    def test_initial_normal_selected_own_raw_angular_is_not_exempt(self):
        value = node(started=False)
        value.own_input_history['tb1']['odom'] = deque([(1, message(raw(wx=1.3)))])
        fault = value.normal_velocity_fault(TARGET)
        self.assertEqual(fault['role'], 'selected_own')
        self.assertIsNone(fault['known_release_ns'])

    def test_received_peer_must_have_raw_and_exact_scalar_v_w_binding(self):
        for key, replacement in [('odometry', None), ('v', 0.), ('w', .5), ('w', False)]:
            value = node()
            peer = value.received['robots'][0]
            peer[key] = replacement
            with self.subTest(key=key):
                fault = value.normal_velocity_fault(TARGET)
                self.assertEqual(fault['role'], 'received_peer')
                self.assertIsNotNone(fault['reason'])

    def test_true_history_fault_flows_to_actual_negative_ack_and_sticky_client(self):
        value = node(release_ns=75_100_000_000)
        peak = base.FIXTURE['raw_own_odom']['payload']
        healthy = raw(92_620_000_000)
        value.own_input_history['tb2']['odom'] = deque([
            (2650, message(peak['message'])), (2651, message(healthy))])
        value.local['tb2'] = state('tb2', healthy, 2651)
        _, actual, sent, records, target = base.phase(
            'proposed_mr3_motion_control.py', halted=None,
            model_check=value.normal_velocity_fault, target_ns=92_620_000_000)
        self.assertIs(sent[0]['ok'], False)
        self.assertEqual(sent[0]['error'], 'normal_control_model_invalid')
        fault = actual.normal_control_model_fault
        self.assertEqual(fault['input_sequence'], 2650)
        self.assertEqual(fault['odom_source_ns'], 92_617_000_000)
        self.assertEqual(fault['commit_clock_ns'], target)
        self.assertTrue(any(kind == 'normal_control_model_invalid' for kind, _ in records))
        client = base.CLIENT.ControlPhaseClient(EPOCH)
        client.begin('motion', 'commit', target, request_id=sent[0]['request_id'])
        client.receive('motion', sent[0], target, target)
        self.assertIs(client.consume(allow_error=True)['ok'], False)
        with self.assertRaises(ValueError):
            client.begin('motion', 'commit', target + 20_000_000)
        # Same current clock explicit stop remains allowed. This models real
        # callback receipts in the client, not native DDS/actuator execution.
        _, _, stop, _, _ = base.phase('proposed_mr3_motion_control.py',
                                      operation='stop', target_ns=target)
        stop[0]['request_id'] = 'cleanup-stop'
        client.begin('motion', 'stop', target, request_id='cleanup-stop')
        client.receive('motion', stop[0], target, target)
        self.assertIs(client.consume()['ok'], True)
        self.assertEqual(stop[0]['status']['phase_kind'], 'stop')

    def test_stale_or_future_peer_remains_original_readiness_scope(self):
        for stamp in (9., 11.):
            value = node()
            peer = value.received['robots'][0]
            peer['source_stamp'] = stamp
            peer['odometry']['twist']['twist']['linear']['y'] = .31
            self.assertIsNone(value.normal_velocity_fault(TARGET))

    def test_future_or_nonfinite_peer_source_fields_do_not_latch_body_model(self):
        for key in ('source_stamp', 'odom_source_stamp', 'tf_source_stamp'):
            for stamp in (11., float('nan')):
                value = node()
                peer = value.received['robots'][0]
                peer[key] = stamp
                peer['odometry']['twist']['twist']['linear']['y'] = .31
                self.assertIsNone(value.normal_velocity_fault(TARGET))

    def test_malformed_peer_twist_produces_structured_model_fault(self):
        for replacement in (None, [], 'bad', {'twist': None}, {'twist': []}):
            value = node()
            value.received['robots'][0]['odometry']['twist'] = replacement
            fault = value.normal_velocity_fault(TARGET)
            self.assertEqual(fault['classification'],
                             'normal_control_model_invalid_not_task_attributed')
            self.assertEqual(fault['reason'], 'invalid_measured_velocity')
            self.assertEqual(fault['role'], 'received_peer')

    def test_nonfinite_raw_own_is_structured_and_cannot_be_json_hashed(self):
        value = node()
        value.own_input_history['tb1']['odom'] = deque([(1, message(raw(vy=float('nan'))))])
        fault = value.normal_velocity_fault(TARGET)
        self.assertEqual(fault['reason'], 'invalid_measured_velocity')
        self.assertIsNone(fault['odom_payload_sha256'])

    def test_detected_normal_fault_is_never_claimed_to_be_within_task(self):
        value = node()
        value.stop_time = 10.01
        value.own_input_history['tb1']['odom'] = deque([(1, message(raw(vx=.31)))])
        fault = value.normal_velocity_fault(TARGET)
        self.assertGreater(fault['odom_source_ns'], fault['known_stop_time_ns'])
        self.assertEqual(fault['classification'],
                         'normal_control_model_invalid_not_task_attributed')

    def test_new_model_fault_suppresses_generic_exploration_failure_only(self):
        for cls, halted, expected in [(OLD_NODE, 'normal_control_model_invalid', 1),
                                      (NODE, 'normal_control_model_invalid', 0),
                                      (NODE, 'external_safety_failure', 1)]:
            value = node()
            value.halted = halted
            value.failure_sent = False
            value.failure_calls = []
            value.failure_pub = SimpleNamespace(publish=lambda m: value.failure_calls.append(m))
            value.local_observers_ready = lambda: True
            value.topology_ready = lambda: True
            value.observers_started = True
            value.issued_motion = set()
            value.ready_pub = SimpleNamespace(publish=lambda _: None)
            value.requests = {}
            value.decision_sequences = dict.fromkeys(ROBOTS, 0)
            value.pending_outputs = {name: deque() for name in ROBOTS}
            value.outputs = {name: SimpleNamespace(publish=lambda _: None) for name in ROBOTS}
            value.drive_targets = value.outputs
            value.drive_audit = None
            value.pending_status = {}
            value.publish_completed_status = lambda _: None
            cls.emit_motion(value, stop=True)
            with self.subTest(cls=cls, halted=halted):
                self.assertEqual(len(value.failure_calls), expected)
                for output in value.pending_status[(TARGET, 'stop')]['outputs'].values():
                    self.assertEqual(output, {'linear_x': 0., 'angular_z': 0.})


if __name__ == '__main__':
    unittest.main(verbosity=2)
