"""Standalone real target parser/gtest old-red/new-green; no ROS or colcon."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT=Path('/home/zhuyulab/ns3-workspace');BASE=ROOT/'ros2_ws/ros2-multi-robot-automap/src/multi_robot';HEADER=BASE/'include/multi_robot/mr3_drive_target.hpp';TEST=BASE/'test/test_drive_target.cpp';PREFIX='/tmp/mr3_p2a0_v13_drive_target_cap'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before={str(p):sha(p) for p in (HEADER,TEST)};results=[];began=time.monotonic()
for version,inc in [('old','/tmp/mr3_p2a0_v13_drive_target_cap_original_include'),('new',str(BASE/'include'))]:
 argv=['g++','-std=c++17','-O2','-Wall','-Wextra','-Werror','-pedantic','-I'+inc,str(TEST),'-lgtest','-lgtest_main','-pthread','-o',PREFIX+'_'+version+'_gtest_v1'];start=time.monotonic();proc=subprocess.run(argv,cwd=ROOT,text=True,capture_output=True);build=Path(PREFIX+'_'+version+'_build_v1.log');build.write_text(proc.stdout+proc.stderr);row={'version':version,'compile_argv':argv,'cwd':str(ROOT),'compile_returncode':proc.returncode,'compile_wall_sec':time.monotonic()-start,'compile_output':str(build),'compile_output_sha256':sha(build)}
 if proc.returncode==0:
  run=[PREFIX+'_'+version+'_gtest_v1'];start=time.monotonic();proc=subprocess.run(run,cwd=ROOT,text=True,capture_output=True);output=Path(PREFIX+'_'+version+'_run_v1.log');output.write_text(proc.stdout+proc.stderr);row.update(run_argv=run,run_returncode=proc.returncode,run_wall_sec=time.monotonic()-start,run_output=str(output),run_output_sha256=sha(output))
 results.append(row)
files=[HEADER,TEST,BASE/'include/multi_robot/paired_wheel_slew.hpp',BASE/'test/test_paired_wheel_slew.cpp'];argv=['git','diff','--check','--']+[str(p.relative_to(ROOT)) for p in files];start=time.monotonic();proc=subprocess.run(argv,cwd=ROOT,text=True,capture_output=True);out=Path(PREFIX+'_diff_check_v1.log');out.write_text(proc.stdout+proc.stderr)
result={'schema':'mr3-drive-target-cap-applied-checks-v1','scope':'Tag ParseDriveTarget hard cap changed .26 to .20. Old schema/seq/sourceclock and angular .8 tests retained. Real old/current inline parser gtests, no colcon/native/GPU/commit.','passed':results[0].get('run_returncode')==1 and results[1].get('run_returncode')==0 and proc.returncode==0,'results':results,'diff_check':{'argv':argv,'returncode':proc.returncode,'wall_sec':time.monotonic()-start,'output':str(out),'output_sha256':sha(out)},'source_before_checks':before,'source_after_checks':{str(p):sha(p) for p in files},'source_checks_unchanged':all(sha(Path(path))==digest for path,digest in before.items()),'total_wall_sec':time.monotonic()-began,'old_header_sha256':sha(Path('/tmp/mr3_p2a0_v13_drive_target_cap_original_include/multi_robot/mr3_drive_target.hpp'))}
p=Path(PREFIX+'_checks_v1.json');p.write_text(json.dumps(result,indent=2)+chr(10));print(json.dumps({'output':str(p),'sha256':sha(p),'passed':result['passed'],'results':results,'files':result['source_after_checks'],'total_wall_sec':result['total_wall_sec']},indent=2));raise SystemExit(0 if result['passed'] and result['source_checks_unchanged'] else 1)
