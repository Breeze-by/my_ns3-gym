"""Launch only explicitly authorized passive ROS observers using exact live worker environments."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
ROS = ROOT / 'ros2_ws/ros2-multi-robot-automap'
RUN = ROS / 'log/mr3_p2a0/mr3_p2a0_20261017_v12_reset'
SCRIPT = Path('/tmp/mr3_p2a0_v12_passive_nav2_observer_v2.py')
FREEZE = '6b1b4a0108351f5bfb70ec0c96ba895248d4f7a8'
children = []
receipt = {'scope': 'Non-predeclared passive diagnosis authorized only after known V12 '
                   'w0e2 activity FAIL. No new formal PASS credit; added publication/IO '
                   'load begins here and cannot explain the earlier closed w0e2 failure.',
           'freeze': FREEZE, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'wall_monotonic_ns': time.monotonic_ns(), 'script': str(SCRIPT),
           'script_sha256': hashlib.sha256(SCRIPT.read_bytes()).hexdigest(), 'observers': []}
for index, domain in ((0, 134), (1, 135)):
    meta_path = sorted((RUN / ('worker' + str(index))).glob('episode*/supervisor_metadata.json'))[-1]
    meta = json.loads(meta_path.read_text())
    assert meta['domain_id'] == domain
    ident = meta['worker_identity']
    stat = Path('/proc/' + str(ident['pid']) + '/stat').read_text()
    values = stat[stat.rfind(')') + 2:].split()
    assert int(values[19]) == ident['start_ticks']
    environment = dict(item.decode().split('=', 1) for item in Path(
        '/proc/' + str(ident['pid']) + '/environ').read_bytes().split(b'\0') if item)
    assert environment['ROS_DOMAIN_ID'] == str(domain)
    assert environment['PYTHONNOUSERSITE'] == '1'
    environment['PYTHONDONTWRITEBYTECODE'] = '1'
    allowed = ['ROS_DOMAIN_ID', 'ROS_LOCALHOST_ONLY', 'RMW_IMPLEMENTATION',
               'FASTRTPS_DEFAULT_PROFILES_FILE', 'FASTDDS_DEFAULT_PROFILES_FILE',
               'SKIP_DEFAULT_XML', 'RMW_FASTRTPS_USE_QOS_FROM_XML',
               'RMW_FASTRTPS_PUBLICATION_MODE', 'PYTHONNOUSERSITE', 'PYTHONDONTWRITEBYTECODE']
    declared = {key: environment.get(key) for key in allowed}
    for key in ('FASTRTPS_DEFAULT_PROFILES_FILE', 'FASTDDS_DEFAULT_PROFILES_FILE'):
        if declared.get(key):
            declared[key + '_sha256'] = hashlib.sha256(Path(declared[key]).read_bytes()).hexdigest()
    env_path = Path('/tmp/mr3_p2a0_v12_passive_nav2_domain' + str(domain) + '_environment_v4.json')
    env_proof = {'source': 'exact verified owned live worker /proc/PID/environ; '
                           'only allowed transport keys shown, complete inherited environment '
                           'passed directly to system Python (no ad-hoc PYTHONPATH construction)',
                 'worker_identity': ident, 'metadata_path': str(meta_path),
                 'metadata_sha256': hashlib.sha256(meta_path.read_bytes()).hexdigest(),
                 'transport_environment': declared, 'capture_wall_monotonic_ns': time.monotonic_ns()}
    with env_path.open('x') as stream:
        json.dump(env_proof, stream, indent=2)
        stream.write('\n')
    output = Path('/tmp/mr3_p2a0_v12_passive_nav2_domain' + str(domain) + '_v4')
    command = ['/usr/bin/python3', str(SCRIPT), '--run', str(RUN), '--domain', str(domain),
               '--freeze', FREEZE, '--output-dir', str(output),
               '--environment-receipt', str(env_path), '--wall-limit-sec', '7200']
    console = Path(str(output) + '_console.log')
    with console.open('x') as stream:
        child = subprocess.Popen(command, cwd=ROS, env=environment,
                                 stdout=stream, stderr=subprocess.STDOUT)
    children.append(child)
    child_stat = Path('/proc/' + str(child.pid) + '/stat').read_text()
    fields = child_stat[child_stat.rfind(')') + 2:].split()
    receipt['observers'].append({'argv': command, 'cwd': str(ROS), 'output': str(output),
                                 'console': str(console), 'environment_receipt': str(env_path),
                                 'identity': {'pid': child.pid, 'start_ticks': int(fields[19])}})
path = Path('/tmp/mr3_p2a0_v12_passive_nav2_launch_receipt_v4.json')
with path.open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps(receipt))

results=[]
for child in children:
    results.append({"pid":child.pid,"returncode":child.wait()})
Path("/tmp/mr3_p2a0_v12_passive_nav2_children_exit_v4.json").write_text(json.dumps({"children":results,"wall_monotonic_ns":time.monotonic_ns()},indent=2)+"\n")
