#!/usr/bin/python3
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

TEMP=Path('/tmp')
ROOTS=[TEMP/'mr3_p2a0_v23_matrix_pack_proposal_v1',
       TEMP/'mr3_p2a0_v23_closed_pack_execution_v1']
OUT=TEMP/'mr3_p2a0_v23_closed_pack_support_v1'
OUT.mkdir(exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def ident(path):
 s=path.stat();b=path.read_bytes();return {'source':str(path),'sha256':sha(b),'bytes':len(b),'mtime_ns':s.st_mtime_ns,'inode':s.st_ino,'device':s.st_dev}
selected=sorted([x for root in ROOTS for x in root.iterdir() if x.is_file() and not x.is_symlink()])
selected += [TEMP/'mr3_p2a0_v23_selected_closed_v1/manifest.json',
             TEMP/'mr3_p2a0_v23_selected_closed_v1/helper_configuration.json',
             TEMP/'mr3_p2a0_v23_selected_closed_v1/metadata/manifest.json',
             TEMP/'mr3_p2a0_v23_selected_closed_v1/native/interface/manifest.json']
records=[]
for i,path in enumerate(selected):
 row=ident(path);row['archive_member']='originals/%03d_%s'%(i,path.name);records.append(row)
execution=json.loads((ROOTS[-1]/'execution.json').read_bytes())
assert execution['passed'] is True and execution['returncode']==0
manifest={'schema':'mr3-v23-closed-pack-support-manifest-v1','files':records,'count':len(records),
 'raw_bytes':sum(x['bytes'] for x in records),'source_initial_final_sha_stat_stable':True,
 'scope':'All small original pack preparation/selection checks, nested-extra adaptation, actual pack source/argv/env/stdout/stderr/receipt and exact selected-tree manifests. Original gzserver-6/forcecleanup/reset-unreturned and formal FAIL/skip remain; no scientific verdict or gate change.',
 'actual_closed_pack':execution['manifest'],'source_raw_or_encoded_evidence_untouched':True,
 'exclusions':['reproducible __pycache__ directories','all selected blob gzip bytes remain in separate selected_closed_v1 tree and are not duplicated in this small support tar','RT newly closing auditor-only originals are separately archived later per parent instruction']}
manifest_path=OUT/'manifest_v1.json';manifest_path.write_text(json.dumps(manifest,indent=2,allow_nan=False)+'\n')
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as tar:
 for row in records:
  path=Path(row['source']);data=path.read_bytes();assert sha(data)==row['sha256']
  info=tarfile.TarInfo(row['archive_member']);info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
 data=manifest_path.read_bytes();info=tarfile.TarInfo('manifest_v1.json');info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
encoded=gzip.compress(buffer.getvalue(),mtime=0)
target=TEMP/'mr3_p2a0_v23_closed_pack_support_v1.tar.gz'
with target.open('xb') as stream:stream.write(encoded)
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(encoded)),mode='r:') as tar:
 for row in records:
  restored=tar.extractfile(row['archive_member']).read();assert (len(restored),sha(restored))==(row['bytes'],row['sha256'])
for row in records:
 now=ident(Path(row['source']));assert all(now[k]==row[k] for k in now)
result={'schema':'mr3-v23-closed-pack-support-seal-v1','passed':True,'all_writers_stopped':True,
 'manifest':{'path':str(manifest_path),'sha256':sha(manifest_path.read_bytes()),'bytes':manifest_path.stat().st_size},
 'tar':{'path':str(target),'sha256':sha(encoded),'bytes':len(encoded)},'count':len(records),
 'all_member_roundtrip_exact':True,'all_source_final_sha_stat_stable':True,
 'selected_native_tree':'/tmp/mr3_p2a0_v23_selected_closed_v1',
 'selected_tree_complete_copy_rule':'Copy selected_closed_v1 whole tree to A22/native; metadata parts carry prospective A22/native/metadata paths. Interface original native tree preserved; later stage run roots did not exist.',
 'source_or_native_or_formal_mutation':False}
(OUT/'seal_v1.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps(result,indent=2))
