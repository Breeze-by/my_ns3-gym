import gzip,hashlib,json
from pathlib import Path
R=Path('/home/zhuyulab/ns3-workspace');A=R/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v17';T=Path('/tmp');sha=lambda b:hashlib.sha256(b).hexdigest()
files=[T/x for x in ('root_mr3_v17_closure_static_review_v1.py','root_mr3_v17_closure_static_review_v1.json','mr3_p2a0_v17_closure_git_add_dryrun_v1.log','mr3_p2a0_v17_closed_publish_execution_v1.json','mr3_p2a0_v17_closed_publish_v1.log','mr3_p2a0_v17_closed_archive_receipt_v1.json','root_mr3_v17_capture_closure_static_v1.py')]
target=A/'independent/closure_static_v1';assert not target.exists();target.mkdir();rows=[]
for source in files:
 before=source.stat();raw=source.read_bytes();encoded=gzip.compress(raw,mtime=0);selected=target/(source.name+'.gz');selected.write_bytes(encoded);after=source.stat();assert (before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns);assert gzip.decompress(selected.read_bytes())==raw
 rows.append(dict(source=str(source),selected_path=str(selected.relative_to(R)),raw_bytes=len(raw),raw_sha256=sha(raw),selected_bytes=len(encoded),selected_encoded_sha256=sha(encoded),selected_decoded_sha256=sha(raw)))
manifest=target/'manifest.json';manifest.write_text(json.dumps(dict(schema='mr3-v17-post-publication-original-custody-v1',freeze='eee6b2f90f697b28a1c20a2af5d1a6d2f044465e',entries=rows,scope='Late closure receipts/static originals only; original FAIL and prior inventory preserved.'),indent=2)+'\n')
old=A/'inventory_native_v1.json';assert sha(old.read_bytes())=='a711b076280676eff18c53708e108f7afd0c24edd27b46f704490693f7b916df';known={x['path']:x for x in json.loads(old.read_bytes())['files']};inventory=[]
for path in sorted(A.rglob('*')):
 if not path.is_file() or '__pycache__' in path.parts or path.suffix=='.pyc':continue
 assert not path.is_symlink();rel=str(path.relative_to(A));raw=path.read_bytes()
 if rel in known:
  row=known[rel];assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
 else:
  row=dict(path=rel,bytes=len(raw),sha256=sha(raw))
  if raw.startswith(b'\x1f\x8b'):
   decoded=gzip.decompress(raw);row.update(decoded_bytes=len(decoded),decoded_sha256=sha(decoded))
 inventory.append(row)
new=A/'inventory_native_v2.json';assert not new.exists();new.write_text(json.dumps(dict(schema='mr3-v17-closed-native-inventory-v2',freeze='eee6b2f90f697b28a1c20a2af5d1a6d2f044465e',self_excluded=True,exclude_python_cache=True,prior_inventory_preserved=old.name,files=inventory),indent=2)+'\n')
print(json.dumps(dict(passed=True,originals=len(rows),raw_bytes=sum(x['raw_bytes'] for x in rows),selected_bytes=sum(x['selected_bytes'] for x in rows),manifest_sha256=sha(manifest.read_bytes()),final_inventory_entries=len(inventory),final_inventory_sha256=sha(new.read_bytes()))))
