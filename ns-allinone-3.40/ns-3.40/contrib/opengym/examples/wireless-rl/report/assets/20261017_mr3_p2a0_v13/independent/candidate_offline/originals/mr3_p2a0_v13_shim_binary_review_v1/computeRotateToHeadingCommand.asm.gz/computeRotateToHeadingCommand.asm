<nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@plt>:
    fab0:	f3 0f 1e fa          	endbr64 
    fab4:	f2 ff 25 6d 75 03 00 	bnd jmp *0x3756d(%rip)        # 47028 <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base+0x2ebc8>
    fabb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
