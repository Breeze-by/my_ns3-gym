"""Record exact diagnostic plugin build/link execution; no native simulation."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
ROS = ROOT / 'ros2_ws/ros2-multi-robot-automap'
OUT = Path('/tmp/mr3_p2a0_v18_build_execution_v1.json')
LOG = Path('/tmp/mr3_p2a0_v18_build_v1.log')
source_paths = [ROS / 'src/multi_robot' / path for path in (
    'CMakeLists.txt', 'src/mr3_stop_response_observer.cpp', 'src/mr3_physics_diagnostic_profile.cpp',
    'src/mr3_gazebo_diff_drive.cpp', 'include/multi_robot/mr3_gazebo_diff_drive.hpp',
    'include/multi_robot/paired_wheel_slew.hpp', 'include/multi_robot/mr3_drive_target.hpp')]
sha = lambda raw: hashlib.sha256(raw).hexdigest()
before = {str(path): sha(path.read_bytes()) for path in source_paths}
driver = ROS / 'install/multi_robot/lib/libmr3_gazebo_diff_drive.so'
original_driver = sha(driver.read_bytes())
assert original_driver == 'a014f2c618e38fc8a306d76c100083d952606333045a2e35bffce6f8b25b10c8'
assert not OUT.exists() and not LOG.exists()
command = ['/bin/bash', '--noprofile', '--norc', '-c',
           'source /opt/ros/humble/setup.bash && /usr/bin/python3 /usr/bin/colcon build '
           '--symlink-install --packages-select multi_robot --allow-overriding nav2_bringup']
env = {key: value for key, value in os.environ.items() if key not in ('PYTHONPATH', 'LD_LIBRARY_PATH',
       'AMENT_PREFIX_PATH', 'CMAKE_PREFIX_PATH', 'COLCON_PREFIX_PATH', 'ROS_PACKAGE_PATH', 'PYTHONHOME')
       and not key.startswith('CONDA')}
env.update(PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1', CMAKE_BUILD_PARALLEL_LEVEL='2')
start = time.monotonic()
with LOG.open('x') as output:
    result = subprocess.run(command, cwd=ROS, env=env, stdout=output, stderr=subprocess.STDOUT)
after = {str(path): sha(path.read_bytes()) for path in source_paths}
record = {'schema': 'mr3-diagnostic-build-execution-v1', 'argv': command, 'cwd': str(ROS),
    'returncode': result.returncode, 'wall_seconds': time.monotonic() - start,
    'source_before': before, 'source_after': after, 'sources_stable': before == after,
    'original_driver_before': original_driver, 'original_driver_after': sha(driver.read_bytes()),
    'console': str(LOG), 'console_sha256': sha(LOG.read_bytes()),
    'environment': {'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1', 'CMAKE_BUILD_PARALLEL_LEVEL': '2',
                    'conda_and_inherited_ROS_paths_removed': True},
    'scope': 'CPU C++ build/link/install only; no simulator or training',
    'end_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
record['passed'] = result.returncode == 0 and before == after and record['original_driver_after'] == original_driver
OUT.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
raise SystemExit(0 if record['passed'] else 1)
