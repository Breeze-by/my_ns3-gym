#include <cfenv>
#include <limits>
#define multi_robot original_multi_robot
#include "original.hpp"
#undef multi_robot
#undef MULTI_ROBOT__PAIRED_WHEEL_SLEW_HPP_
#include "proposed.hpp"
extern "C" void replay(int old, const double * p, double * out) {
 const std::array<double,2> c{p[0],p[1]},d{p[2],p[3]};
 if(old){const auto r=original_multi_robot::limit_paired_wheel_speeds(c,d,p[4],p[5]);out[0]=r.applied[0];out[1]=r.applied[1];out[2]=r.alpha;}
 else{const auto r=multi_robot::limit_paired_wheel_speeds(c,d,p[4],p[5]);out[0]=r.applied[0];out[1]=r.applied[1];out[2]=r.alpha;}
}
extern "C" int long_double_digits(){return std::numeric_limits<long double>::digits;}
extern "C" int rounding_mode(){return std::fegetround();}
