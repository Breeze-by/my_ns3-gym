// Pure SDFormat parsing only: no Gazebo/ROS/DDS initialization or world loading.
#include <sdf/sdf.hh>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>

int main(int argc, char **argv)
{
  if (argc != 2) throw std::invalid_argument("one minimal SDF path required");
  std::ifstream stream(argv[1]);
  if (!stream) throw std::runtime_error("input unavailable");
  std::ostringstream raw;
  raw << stream.rdbuf();
  sdf::SDFPtr parsed(new sdf::SDF());
  if (!sdf::init(parsed) || !sdf::readString(raw.str(), parsed))
    throw std::runtime_error("SDFormat parse failed");
  auto physics = parsed->Root()->GetElement("world")->GetElement("physics");
  std::cout << physics->ToString("", true, true);
}
