import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
from datetime import datetime, timezone

script = Path('/tmp/mr3_p2a0_v17_stop_response_raw_diagnostic_v1.py')
cwd = '/home/zhuyulab/ns3-workspace'
argv = ['/usr/bin/python3', str(script), '--output-directory',
        '/tmp/mr3_p2a0_v17_stop_response_raw_diagnostic_v1']
env = dict(os.environ)
env.pop('PYTHONPATH', None)
env['PYTHONNOUSERSITE'] = '1'
env['PYTHONDONTWRITEBYTECODE'] = '1'
log = Path('/tmp/mr3_p2a0_v17_stop_response_raw_diagnostic_v1.log')
start = time.monotonic()
utc = datetime.now(timezone.utc).isoformat()
with log.open('xb') as output:
    result = subprocess.run(argv, cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT)
receipt = {'argv': argv, 'cwd': cwd, 'environment_override': {
    'PYTHONPATH': None, 'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1'},
    'script_sha256': hashlib.sha256(script.read_bytes()).hexdigest(),
    'start_utc': utc, 'end_utc': datetime.now(timezone.utc).isoformat(),
    'wall_sec': time.monotonic()-start, 'exit_code': result.returncode,
    'stdout': str(log), 'stdout_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
target = Path('/tmp/mr3_p2a0_v17_stop_response_raw_diagnostic_execution_v1.json')
with target.open('x') as out:
    json.dump(receipt, out, indent=2)
    out.write('\n')
print(json.dumps(receipt, indent=2))
raise SystemExit(result.returncode)
