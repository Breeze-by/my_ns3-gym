import hashlib
import importlib.util
import json
from pathlib import Path
import sys

spec = importlib.util.spec_from_file_location("control", "/tmp/mr3_independent_control_phase_v1.py")
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
paths = [Path("/tmp/mr3_p2a0_v10_information_peer_safe_fixture_v1/information_states.jsonl"),
         Path("/tmp/mr3_p2a0_v10_peer_producer_fixture_v1/peer_phase.jsonl"),
         Path("/tmp/mr3_p2a0_v10_information_producer_fixture_v2/information_states.jsonl"),
         Path("/tmp/mr3_p2a0_v10_peer_producer_overlap_fixture_v1/peer_phase.jsonl")]
bindings = [{"path": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]
read = lambda p: [m.HELPERS.parse(s) for s in p.read_bytes().splitlines()]
result = {"schema": "mr3-v10-real-method-peer-consumer-compat-v1", "passed": False,
          "consumer_sha256": hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest(),
          "inputs": bindings,
          "scope": "Actual production methods with real ROS messages/fake publishers; synthetic positions, not native or whole worker phase credit"}
state = m.information_acks(read(paths[0]), "episode-a")
peer = m.PeerReplay("episode-a", state)
for row in read(paths[1]):
    peer.record(row)
result["positive"] = peer.finish()
state = m.information_acks(read(paths[2]), "episode-a")
peer = m.PeerReplay("episode-a", state)
overlap_denied = 0
for row in read(paths[3]):
    try:
        peer.record(row)
    except ValueError as error:
        assert row['kind'] == 'inputs_matched' and str(error) == 'original peer body envelope overlap'
        overlap_denied += 1
assert overlap_denied == 2 and peer.commit_sequence == 0
try:
    peer.finish()
except ValueError as error:
    result["negative_overlap"] = {"expected_error": str(error), "original_geometry_denials": overlap_denied,
                                  "actual_success_commits": peer.commit_sequence}
else:
    raise AssertionError("overlap fixture unexpectedly gained peer credit")
for item in bindings:
    assert hashlib.sha256(Path(item["path"]).read_bytes()).hexdigest() == item["sha256"]
result["passed"] = True
out = Path("/tmp/mr3_p2a0_v10_control_consumer_compat_v2.json")
out.write_text(json.dumps(result, sort_keys=True, indent=2)+"\n")
print(json.dumps(result, sort_keys=True))
sys.exit(0)
