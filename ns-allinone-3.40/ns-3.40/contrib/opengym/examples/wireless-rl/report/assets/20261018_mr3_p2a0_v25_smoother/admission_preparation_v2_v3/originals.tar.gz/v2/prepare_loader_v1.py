"""Make a TMP fixed-source loader proposal; no native or canonical writes."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

D = Path(__file__).parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
WREL = 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
AREL = WREL + 'report/assets/20261018_mr3_p2a0_v25_smoother/'
path = ROOT / WREL / 'mr3_learning/audit_ppo.py'
old = path.read_bytes()
assert hashlib.sha256(old).hexdigest() == 'cc467064ab66e04507ed4d4e805a4e23cdf09b3716fd85517ebb34fe7b2de521'
new = old
for before, after in [
    (b"ENV_DOCUMENT_SHA256 = 'f1e0be60d35db3677fb9194341c1ae4133a5c74ed7199056fe18f7e797f40416'",
     b"ENV_DOCUMENT_SHA256 = '41feac9a6d76adb839a615d7703e78e1b1c9f2ce22d55aba805387643536380e'"),
    (b"ENV_EXECUTION_APPENDIX_SHA256 = 'b9bae951da6102af67bb3e106b0136dd0067eca9677cfaf3394f5095f87124a3'",
     b"ENV_EXECUTION_APPENDIX_SHA256 = 'c281693ef4755ae4c6760a87ec675c34e2d56da67ccceb79cc34a4d2f2f941c0'"),
    (b'ENV_EXECUTION_APPENDIX_BYTES = 9875', b'ENV_EXECUTION_APPENDIX_BYTES = 11913'),
]:
    assert new.count(before) == 1
    new = new.replace(before, after, 1)
source = AREL + 'independent/mr3_v25_smoother_custody_v1.py'
binding = AREL + 'independent/mr3_v25_smoother_binding_v1.json'
source_sha = hashlib.sha256((D / 'mr3_v25_smoother_custody_v1.py').read_bytes()).hexdigest()
binding_sha = hashlib.sha256((D / 'mr3_v25_smoother_binding_v1.json').read_bytes()).hexdigest()
block = f'''
SMOOTHER_OVERLAY_PINS = {{
    {source!r}: {source_sha!r},
    {binding!r}: {binding_sha!r},
}}


def verify_velocity_smoother_overlay(root, freeze):
    """Fixed official 1.1.20 two-timer overlay; old math and validators unchanged."""
    proof = verify_frozen_pins(root, freeze, SMOOTHER_OVERLAY_PINS, 'node-clock smoother overlay')
    source = {source!r}
    binding = root / {binding!r}
    module = load_pinned('mr3_v25_smoother_overlay_custody', root / source,
                         SMOOTHER_OVERLAY_PINS[source])
    reader = module.Reader()
    proof.update(module.verify_frozen_build(root, freeze, binding, reader))
    reader.finish()
    return proof


'''.encode()
anchor = b'def extend_snapshot_validator(auditor, candidate_module):\n'
assert new.count(anchor) == 1
new = new.replace(anchor, block + anchor, 1)
call_before = b'    proof.update(verify_ray_box_library(root, freeze))\n'
call_after = call_before + b'    proof.update(verify_velocity_smoother_overlay(root, freeze))\n'
assert new.count(call_before) == 1
new = new.replace(call_before, call_after, 1)
ast.parse(new)
(D / 'audit_ppo.proposed_v25.py').write_bytes(new)
(D / 'audit_ppo.base_v24.py').write_bytes(old)
(D / 'audit_ppo.proposed_v25.patch').write_text(''.join(difflib.unified_diff(
    old.decode().splitlines(True), new.decode().splitlines(True),
    fromfile='a/' + str(path.relative_to(ROOT)), tofile='b/' + str(path.relative_to(ROOT)))))
# Verify inverse exact bytes, not just an AST similarity.
inverse = new.replace(call_after, call_before, 1).replace(block + anchor, anchor, 1)
for after, before in [
    (b"ENV_DOCUMENT_SHA256 = '41feac9a6d76adb839a615d7703e78e1b1c9f2ce22d55aba805387643536380e'",
     b"ENV_DOCUMENT_SHA256 = 'f1e0be60d35db3677fb9194341c1ae4133a5c74ed7199056fe18f7e797f40416'"),
    (b"ENV_EXECUTION_APPENDIX_SHA256 = 'c281693ef4755ae4c6760a87ec675c34e2d56da67ccceb79cc34a4d2f2f941c0'",
     b"ENV_EXECUTION_APPENDIX_SHA256 = 'b9bae951da6102af67bb3e106b0136dd0067eca9677cfaf3394f5095f87124a3'"),
    (b'ENV_EXECUTION_APPENDIX_BYTES = 11913', b'ENV_EXECUTION_APPENDIX_BYTES = 9875')]:
    inverse = inverse.replace(after, before, 1)
assert inverse == old
(D / 'loader_inverse_v1.json').write_text(json.dumps({
    'passed': True, 'base_sha256': hashlib.sha256(old).hexdigest(),
    'proposal_sha256': hashlib.sha256(new).hexdigest(), 'source_sha256': source_sha,
    'binding_sha256': binding_sha, 'whole_byte_inverse': True,
    'scope': 'Three fixed ENV literals, new fixed verifier/pins and one call only; no old function/validator/math changes after exact inverse. Not full CLI or native execution.'}, indent=2) + '\n')
print(hashlib.sha256(new).hexdigest())
