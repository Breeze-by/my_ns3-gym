"""Named module ownership keeps explicit thread hooks on the same capture."""
from fixed_process_profile_v1 import main

if __name__ == '__main__':
    raise SystemExit(main())
