"""Small uninstalled shadow checks; real protocol/masks, no native inputs."""
import ast
import copy
import importlib.util
import json
import math
from pathlib import Path
import sys
import types
import unittest

ROOT=Path('/home/zhuyulab/ns3-workspace')
W=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
OUT=Path(__file__).resolve().parent
SHADOW=OUT/'shadow'/W.relative_to(ROOT)/'mr3_learning'
sys.path.insert(0,str(W))
old_fixture=Path('/tmp/mr3_p2a_outward_cancel_probe_review_v1/test_goal_lifecycle_revision2.py')
spec=importlib.util.spec_from_file_location('_preserved_lifecycle_fixture',old_fixture)
life_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(life_module)
Lifecycle=life_module.Lifecycle
raw=(SHADOW/'benchmark.py').read_text();tree=ast.parse(raw)
names={'_probe_goal_order','_probe_nonapproaching_goal_action','_probe_v2_number',
       'probe_action_reach_v2','record_probe_reach_v2_submission','finish_probe_reach_v2'}
selected=[node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in names]
assert len(selected)==len(names)
ns={'math':math};exec(compile(ast.Module(body=selected,type_ignores=[]),str(SHADOW/'benchmark.py'),'exec'),ns)
choose,record,finish=(ns[name] for name in ('probe_action_reach_v2','record_probe_reach_v2_submission','finish_probe_reach_v2'))


def shadow_reader():
    path=SHADOW/'audit_reach_reset_workload.py'
    module=types.ModuleType('mr3_learning._outward_v2_shadow_reader')
    module.__package__='mr3_learning'
    # Canonical base path is only for immutable definition dependencies. This
    # never calls source_proof or claims a canonical implementation receipt.
    module.__file__=str(W/'mr3_learning'/path.name)
    exec(compile(path.read_text(),str(path),'exec'),module.__dict__)
    return module


class ProducerTests(unittest.TestCase):
    def snap(self,life,t,*,moving=True):
        if t<=6:x=.2*t;speed=.2 if t else 0.
        elif t<13:x=1.21;speed=0.
        elif t<=19:x=1.21+.2*(t-13);speed=.2 if t>13 else 0.
        else:x=2.42;speed=0.
        snap=life.snapshot(float(t),x=x,speed=speed if moving else 0.,path=x)
        snap['source_stamp']=float(t)
        if t>=13:
            for goal in snap['candidates']:goal['x']+=1.21
        return snap

    def cancel(self,life,t):
        life.advance(t+.05)
        for name,state in life.dispatcher.states.items():
            life.dispatcher.on_cancel_response(name,state.goal_id,True,t+.05)
        self.assertFalse(life.dispatcher.closed)
        life.complete_all(5,t+.1)

    def test_two_rounds_all_three_real_owners_complete_exactly32_submissions(self):
        life,diag=Lifecycle(),{}
        for t in range(32):
            snap=self.snap(life,t);action=choose(snap,diag)
            self.assertTrue(snap['joint_action_mask'][action])
            record(diag,life.apply(snap,action))
            if t in (0,13):
                self.assertEqual(action,345);life.accept_all(t+.1)
            if t in (6,19):
                self.assertEqual(action,999);self.cancel(life,t)
            if t==7:
                self.assertFalse(any('handoff_observed_ns' in s for s in diag['reach_v2_stimulus']['rounds']['initial'].values()))
        finish(self.snap(life,32),diag)
        state=diag['reach_v2_stimulus']
        self.assertTrue(state['coverage_passed'])
        self.assertEqual(len(state['decisions']),32)
        self.assertEqual(len([e for e in life.events if e['type']=='send_goal']),6)
        self.assertEqual(len([e for e in life.events if e['type']=='cancel_goal']),6)

    def test_short_candidates_keep_masks_and_fail_coverage_without_retry(self):
        life,diag=Lifecycle(),{}
        for t in range(32):
            snap=self.snap(life,t,moving=False)
            for goal in snap['candidates']:goal['valid']=False
            # Recompute original masks after removing received candidates.
            from multi_robot_exploration.mr3_observation import _action_masks
            snap['per_robot_action_mask'],snap['joint_action_mask'],_= _action_masks(snap['robots'],snap['candidates'],float(t))
            action=choose(snap,diag);record(diag,life.apply(snap,action))
        with self.assertRaisesRegex(ValueError,'coverage unavailable'):finish(self.snap(life,32,moving=False),diag)
        self.assertFalse(diag['reach_v2_stimulus']['coverage_passed'])
        self.assertEqual([e for e in life.events if e['type']=='send_goal'],[])

    def test_real_success_before_commitment_never_counts_idle_wait_as_cancel(self):
        life,diag=Lifecycle(),{}
        snap=self.snap(life,0);record(diag,life.apply(snap,choose(snap,diag)));life.accept_all()
        snap=self.snap(life,1);self.assertFalse(snap['per_robot_action_mask'][0][9]);self.assertEqual(choose(snap,diag),888)
        record(diag,life.apply(snap,888));life.complete_all(4,3.9)
        snap=self.snap(life,10,moving=False);record(diag,life.apply(snap,choose(snap,diag)))
        snap=self.snap(life,13,moving=False);self.assertEqual(choose(snap,diag),888)
        self.assertTrue(diag['reach_v2_stimulus']['coverage_failures'])
        self.assertEqual([e for e in life.events if e['type']=='cancel_goal'],[])

    def test_cancel_acceptance_without_terminal_does_not_enable_second_goal(self):
        life,diag=Lifecycle(),{}
        for t in range(7):
            snap=self.snap(life,t);record(diag,life.apply(snap,choose(snap,diag)))
            if t==0:life.accept_all()
        life.advance(6.05)
        for name,state in life.dispatcher.states.items():life.dispatcher.on_cancel_response(name,state.goal_id,True,6.05)
        snap=self.snap(life,13,moving=False);self.assertEqual(choose(snap,diag),888)
        self.assertFalse(life.dispatcher.closed)
        self.assertFalse(any('cancel_terminal_observed_ns' in row for row in diag['reach_v2_stimulus']['rounds']['initial'].values()))

    def test_unsubmitted_or_wrong_command_never_latches_scientific_wait(self):
        life,diag=Lifecycle(),{}
        for t in range(6):
            snap=self.snap(life,t);record(diag,life.apply(snap,choose(snap,diag)))
            if t==0:life.accept_all()
        snap=self.snap(life,6);self.assertEqual(choose(snap,diag),999)
        bad={'command':dict(epoch=snap['epoch'],command_id=True,action=999,
            observation_sequence=snap['sequence'],observation_digest=snap['digest'])}
        with self.assertRaises(ValueError):record(diag,bad)
        record(diag,{'action_submitted':False})
        self.assertFalse(any('wait_command_id' in row for row in diag['reach_v2_stimulus']['rounds']['initial'].values()))
        self.assertEqual([e for e in life.events if e['type']=='cancel_goal'],[])

    def test_external_stop_cannot_confirm_a_merely_submitted_wait(self):
        life,diag=Lifecycle(),{}
        for t in range(6):
            snap=self.snap(life,t);record(diag,life.apply(snap,choose(snap,diag)))
            if t==0:life.accept_all()
        snap=self.snap(life,6);self.assertEqual(choose(snap,diag),999)
        # A worker can return the genuinely published command even when its
        # adapter action was rejected. Another stop cause must not earn credit.
        record(diag,{'command':dict(epoch=snap['epoch'],command_id=snap['sequence'],
            action=999,observation_sequence=snap['sequence'],observation_digest=snap['digest'])})
        life.dispatcher.safety_stop(6.,'task_failure')
        self.cancel(life,6)
        choose(self.snap(life,7,moving=False),diag)
        members=diag['reach_v2_stimulus']['rounds']['initial']
        self.assertFalse(any('cancel_terminal_observed_ns' in row for row in members.values()))
        self.assertTrue(diag['reach_v2_stimulus']['coverage_failures'])

    def test_legacy_selector_function_ASTs_unchanged(self):
        original=ast.parse((W/'mr3_learning/benchmark.py').read_text())
        for name in ('_probe_goal_order','probe_action','probe_action_v3','probe_action_v4',
                     'probe_action_v5','probe_action_v6','record_probe_v4_submission'):
            a=next(node for node in original.body if isinstance(node,ast.FunctionDef) and node.name==name)
            b=next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name==name)
            self.assertEqual(ast.dump(a),ast.dump(b))


class FixedReaderTests(unittest.TestCase):
    def test_both_selected_reader_kinds_have_one_exact_version_inverse(self):
        module=shadow_reader()
        for profile,version in ((module.PROFILE,module.PROBE_VERSION),(module.PROFILE_V2,module.PROBE_VERSION_V2)):
            for kind in ('angular','physics'):
                private,proof=module.load_reader(kind,workload_profile=profile)
                self.assertEqual(private.PROBE_VERSION,version)
                self.assertTrue(proof['whole_source_inverse_equal'])
                self.assertEqual(proof['source_sha256'],proof['inverse_sha256'])
                self.assertEqual(len(proof['literal_changes']),1)

    def test_missing_wrong_unknown_pairs_rejected_and_old_default_preserved(self):
        module=shadow_reader()
        self.assertEqual(module.profile_from_plan({'reset_workload_reader_profile':module.PROFILE})[1],module.PROBE_VERSION)
        for profile in (None,True,'unknown'):
            with self.assertRaises(ValueError):module.profile_spec(profile)
        for version in (None,module.PROBE_VERSION,'unknown'):
            with self.assertRaises(ValueError):module.profile_from_plan({
                'reset_workload_reader_profile':module.PROFILE_V2,'preparation_probe_version':version})
        selected=module.profile_from_plan({'reset_workload_reader_profile':module.PROFILE_V2,
            'preparation_probe_version':module.PROBE_VERSION_V2})
        argv=module.command_argv('physics','/synthetic','a'*40,'/tmp/not_written','/tmp/report_not_read',workload_profile=selected[0])
        self.assertEqual(argv[argv.index('--workload-profile')+1],module.PROFILE_V2)


if __name__=='__main__':unittest.main(verbosity=2)
