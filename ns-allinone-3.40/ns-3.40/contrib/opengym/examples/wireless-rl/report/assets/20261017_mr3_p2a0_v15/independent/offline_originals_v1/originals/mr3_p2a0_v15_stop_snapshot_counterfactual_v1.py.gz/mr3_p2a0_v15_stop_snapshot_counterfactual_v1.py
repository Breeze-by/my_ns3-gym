"""Read-only V14 prefix diagnostic; not a new execution or physical credit."""
from pathlib import Path
import hashlib
import json

BASE = Path('/home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/log/'
            'mr3_p2a0/mr3_p2a0_20261017_v14_interface/worker0/episode001_open_101')


def main():
    snapshots = []
    for line in (BASE / 'adapter.jsonl').open():
        row = json.loads(line)
        if row['kind'] == 'observation':
            snapshots.append(row['payload'])
    rows = {name: [] for name in ('tb1', 'tb2', 'tb3')}
    digest = hashlib.sha256()
    motion = BASE / 'motion_safety.jsonl'
    with motion.open('rb') as source:
        for line_number, line in enumerate(source, 1):
            digest.update(line)
            if b'"kind":"actual_cmd_vel"' not in line:
                continue
            row = json.loads(line)
            p = row['payload']
            rows[p['robot']].append({
                'line': line_number, 'clock_ns': round(row['sim_time_sec'] * 1e9),
                'v': p['twist']['linear']['x'], 'w': p['twist']['angular']['z']})
    selected = []
    for snapshot in snapshots:
        now = round(snapshot['source_stamp'] * 1e9)
        item = {'task_elapsed_sec': snapshot['task_elapsed_sec'], 'snapshot_sequence': snapshot['sequence'],
                'robots': {}}
        for index, robot in enumerate(snapshot['robots']):
            active, latest = None, None
            for command in rows[robot['name']]:
                if command['clock_ns'] > now:
                    break
                latest = command
                if command['v'] == 0:
                    active = None
                elif active is None:
                    active = command['clock_ns']
            wait_action = 888 + (100, 10, 1)[index]
            item['robots'][robot['name']] = {
                'received_v': robot['v'], 'received_phase': robot['navigation']['phase'],
                'received_goal_id': robot['navigation']['goal_id'],
                'received_path_m': robot['activity']['estimated_path_m'],
                'commitment_remaining_sec': robot['navigation']['commitment_remaining_sec'],
                'single_wait_action': wait_action,
                'single_wait_legal': snapshot['joint_action_mask'][wait_action],
                'latest_actual_output': latest,
                'actual_nonzero_span_ns': None if active is None else now - active,
                'scope': 'Actual V14 source-prefix condition only, never fed to proposed fixture.'}
        selected.append(item)
    result = {'schema': 'mr3-v15-stop-prefix-counterfactual-v1',
              'scope': 'V14 recorded-prefix diagnostic only. New cancellations change later trajectories; '
                       'no counterfactual safety/stop coverage or native credit.',
              'motion': {'path': str(motion), 'sha256': digest.hexdigest()}, 'snapshots': selected}
    output = Path('/tmp/mr3_p2a0_v15_stop_snapshot_counterfactual_v1.json')
    with output.open('x') as target:
        json.dump(result, target, indent=2)
        target.write('\n')
    for item in selected:
        if item['task_elapsed_sec'] in (1., 4., 6., 15., 19., 20.):
            print(json.dumps(item))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
