"""Read-only V13 prefreeze inventory, whitelist, pins, archive and local-link check.

Adapted from the V12 inventory layout and contract_checks link/pin procedure.
Outputs are explicit paths opened exclusively. This script does not stage,
build, test, publish, launch native processes or modify any existing manifest.
"""
import argparse
import ast
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote

ROOT = Path('/home/zhuyulab/ns3-workspace')
WP = 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
RP = 'ros2_ws/ros2-multi-robot-automap'
W = ROOT / WP
ASSET = W / 'report/assets/20261017_mr3_p2a0_v13'
OLD = W / 'report/assets/20261017_mr3_p2a0_v12'
BASE = 'd48b939f3c18f6a57520b240dc57435f5228bb35'
ALLOWED = {
    'AGENTS.md',
    *[WP + '/' + name for name in (
        'AGENTS.md', 'IMPLEMENTATION_PLAN.md', 'MR3_ENV_CONTRACT.md',
        'RESEARCH_PLAN.md', 'log.md', 'mr3_learning/audit_motion.py',
        'mr3_learning/audit_ppo.py', 'mr3_learning/benchmark.py',
        'mr3_learning/tests/test_audit_motion.py', 'report/ARCHIVE_INDEX.json',
        'report/README.md', 'report/20261017_mr3_p2a0_v13.md')],
    *[RP + '/' + name for name in (
        'AGENTS.md', 'user_guide.md', 'launch_commands.md',
        'src/multi_robot/config/nav2_params.yaml',
        'src/multi_robot/include/multi_robot/mr3_drive_target.hpp',
        'src/multi_robot/include/multi_robot/paired_wheel_slew.hpp',
        'src/multi_robot/package.xml',
        'src/multi_robot/params/nav2_params_tb1_0.yaml',
        'src/multi_robot/params/nav2_params_tb2_0.yaml',
        'src/multi_robot/params/nav2_params_tb3_0.yaml',
        'src/multi_robot/test/test_drive_target.cpp',
        'src/multi_robot/test/test_paired_wheel_slew.cpp',
        'src/multi_robot/vendor/gazebo_ros_diff_drive.PROVENANCE.md',
        'src/multi_robot_exploration/multi_robot_exploration/motion_safety.py',
        'src/multi_robot_exploration/multi_robot_exploration/mr3_motion_control.py',
        'src/multi_robot_exploration/multi_robot_exploration/mr3_motion_safety.py',
        'src/multi_robot_exploration/test/test_motion_safety.py',
        'src/multi_robot_exploration/test/test_mr3_motion_control.py',
        'src/multi_robot_exploration/test/test_settled_turn.py',
        'src/multi_robot_exploration/test/test_motion_velocity_model.py')],
}
EXPECTED_BINARY_FILES = {
    'binary/mr3_p2a0_v13_drive_build_receipt_v1.json',
    'binary/libmr3_gazebo_diff_drive.so.gz',
    'binary/canonical_build_checks_v1.json.gz',
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def static_assignments(path):
    """Evaluate only literal/+ arithmetic and mappings, without importing code."""
    values = {}

    def expression(node):
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Name):
            return values[node.id]
        if isinstance(node, ast.BinOp):
            left, right = expression(node.left), expression(node.right)
            if isinstance(node.op, ast.Add):
                return left + right
            if isinstance(node.op, ast.Mult):
                return left * right
            if isinstance(node.op, ast.Div):
                return left / right
        if isinstance(node, ast.Tuple):
            return tuple(expression(item) for item in node.elts)
        if isinstance(node, ast.Dict):
            return {expression(k): expression(v) for k, v in zip(node.keys, node.values)}
        raise ValueError('not a static literal expression')

    for node in ast.parse(path.read_bytes()).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(
                node.targets[0], ast.Name):
            try:
                values[node.targets[0].id] = expression(node.value)
            except (ValueError, KeyError, TypeError):
                pass
    return values


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inventory', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--allow-canonical-inventory', action='store_true')
    parser.add_argument('--expected-independent-bindings', type=int, default=96)
    args = parser.parse_args()
    require(not args.inventory.exists() and not args.report.exists(), 'never overwrite outputs')
    require(args.report.is_absolute() and str(args.report).startswith('/tmp/'),
            'review report must be a new /tmp path')
    inventory_inside = args.inventory.resolve().is_relative_to(ASSET.resolve())
    require(not inventory_inside or (args.allow_canonical_inventory and
            args.inventory == ASSET / 'inventory_prefreeze_v1.json'),
            'canonical inventory writes require explicit root invocation and exact path')
    require(args.inventory.is_absolute(), 'inventory must be absolute')
    bindings = {}

    def read(path):
        path = Path(path)
        raw = path.read_bytes()
        record = {'bytes': len(raw), 'sha256': sha(raw)}
        require(str(path) not in bindings or bindings[str(path)] == record,
                'input changed between reads: ' + str(path))
        bindings[str(path)] = record
        return raw

    plan_path = ASSET / 'predeclared_plan_v13.json'
    plan = json.loads(read(plan_path))
    old_plan = json.loads(read(OLD / 'predeclared_plan_v12.json'))
    require(plan['schema'] == 'mr3-p2a0-predeclaration-v13', 'wrong active plan')
    require(plan['readiness']['status'] == 'ready' and
            plan['readiness']['pending_bindings'] == [], 'active plan is not ready')
    declared = plan['independent_source_bindings']
    current = {row['path']: row['sha256'] for row in declared}
    previous = {row['path']: row['sha256'] for row in old_plan['independent_source_bindings']}
    require(len(current) == len(declared) == args.expected_independent_bindings,
            'declared independent binding count is not the reviewed final unique count')
    for relative, expected in current.items():
        require(sha(read(ROOT / relative)) == expected, 'plan binding differs: ' + relative)
    updated_old = sorted(k for k in previous if k in current and previous[k] != current[k])
    expected_updated = sorted(WP + '/mr3_learning/' + n for n in (
        'audit_motion.py', 'audit_ppo.py', 'tests/test_audit_motion.py'))
    require(not previous.keys() - current.keys() and updated_old == expected_updated,
            'unexpected old independent binding removed or changed')
    require(sum(current.get(k) == v for k, v in previous.items()) == 73,
            '73 retained immutable bindings no longer match')
    for name in ('unchanged_gates', 'pilot_budget_unchanged', 'max_total_wall_seconds',
                 'max_api_records', 'max_submitted_script_decisions'):
        require(canonical(plan[name]) == canonical(old_plan[name]), 'changed old gate/budget: ' + name)
    require(plan['robots_per_environment'] == 3 and plan['gpu_calls'] == 0 and
            plan['optimizer_steps'] == 0, 'new training/robot scope')

    pin_path = W / 'mr3_learning/audit_ppo.py'
    read(pin_path)
    variables = static_assignments(pin_path)
    pins = {}
    for key in ('EVALUATOR_PHASE_PINS', 'PREPARATION_RUNTIME_PINS', 'EXECUTION_CONFIG_PINS'):
        pins.update(variables[key])
    require(len(pins) == 35, 'runtime reviewed pin count changed')
    for relative, expected in pins.items():
        require(sha(read(ROOT / relative)) == expected, 'runtime pin differs: ' + relative)
    require(sha(read(W / 'MR3_ENV_CONTRACT.md')) == variables['ENV_DOCUMENT_SHA256'],
            'ENV contract pin differs')

    safety = ROOT / RP / ('src/multi_robot_exploration/multi_robot_exploration/'
                          'mr3_motion_safety.py')
    read(safety)
    constants = static_assignments(safety)
    original_bounds = {'BODY_RADIUS_M': .25, 'COMMAND_SPEED_LIMIT': .20,
                       'MEASURED_SPEED_BOUND': .30, 'COMMAND_TURN_LIMIT': .8,
                       'MEASURED_TURN_BOUND': 1.2, 'TURN_ACCEL_BOUND_RADPS2': 7.,
                       'SOURCE_MAX_AGE_SEC': .5, 'REACTION_SEC': .16,
                       'BRAKING_DECEL_MPS2': .5, 'TURN_STOP_PADDING_SEC': .02,
                       'GEOMETRY_MARGIN_M': .02, 'PERIOD_SEC': .02,
                       'REST_SPEED_BOUND': .01, 'REST_SOURCE_GAP_NS': 100_000_000}
    for name, expected in original_bounds.items():
        require(constants[name] == expected, 'safety bound differs: ' + name)
    require(constants['STOP_HORIZON_SEC'] == .78 and
            constants['REST_DRIFT_BUDGET_M'] == .01 * .78,
            'unchanged stop/drift bound differs')

    build_ref = plan['drive_contract']['binary_build_receipt']
    build_raw = read(ROOT / build_ref['path'])
    require(sha(build_raw) == build_ref['sha256'], 'binary build receipt pin differs')
    build = json.loads(build_raw)
    binary = read(Path(build['library_path']))
    require(sha(binary) == build['library_sha256'] and len(binary) == build['library_bytes'],
            'actual build library differs')
    require(read(Path(build['installed_path'])) == binary, 'actual installed library differs')
    blob = read(ROOT / build['archived_library_gzip'])
    require(sha(blob) == build['archived_library_encoded_sha256'] and
            gzip.decompress(blob) == binary, 'lossless canonical library differs')
    require(sha(gzip.decompress(read(ROOT / build['canonical_build_checks_gzip']))) ==
            build['canonical_build_checks_decoded_sha256'], 'original build checks differ')
    compiled = {'compiled_source_sha256': 'src/mr3_gazebo_diff_drive.cpp',
                'compiled_header_sha256': 'include/multi_robot/mr3_gazebo_diff_drive.hpp',
                'compiled_helper_sha256': 'include/multi_robot/paired_wheel_slew.hpp',
                'compiled_target_contract_sha256': 'include/multi_robot/mr3_drive_target.hpp'}
    for field, relative in compiled.items():
        raw = read(ROOT / RP / 'src/multi_robot' / relative)
        require(sha(raw) == build[field] and build[field].encode() in binary,
                'compiled source macro differs: ' + field)

    diff_names = set(git('diff', '--name-only', BASE).decode().splitlines())
    untracked = set(git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')) - {''}
    asset_prefix = str(ASSET.relative_to(ROOT)) + '/'
    extras = sorted(name for name in diff_names | untracked
                    if name not in ALLOWED and not name.startswith(asset_prefix))
    require(not extras, 'changed path outside explicit V13 whitelist: ' + repr(extras))
    historical = sorted(name for name in diff_names | untracked
                        if name.startswith(WP + '/report/assets/') and
                        not name.startswith(asset_prefix))
    require(not historical, 'historical evidence changed: ' + repr(historical))
    old_log = git('show', BASE + ':' + WP + '/log.md')
    require(read(W / 'log.md').startswith(old_log), 'prior experiment log was rewritten')
    for relative in ('report/20261017_mr3_p2a0_v12.md',):
        require(read(W / relative) == git('show', BASE + ':' + WP + '/' + relative),
                'original V12 FAIL report changed')
    for folder in ('native', 'accounting'):
        require(not (ASSET / folder).exists(), 'prefreeze contains unrun native evidence directory')

    files, excluded_cache = [], []
    asset_paths = []
    for path in sorted(ASSET.rglob('*')):
        require(not path.is_symlink(), 'unexpected evidence symlink: ' + str(path))
        if not path.is_file() or path.resolve() == args.inventory.resolve():
            continue
        if '__pycache__' in path.parts or path.suffix == '.pyc':
            excluded_cache.append(str(path.relative_to(ASSET)))
            continue
        relative = str(path.relative_to(ASSET))
        require(not relative.startswith('binary/') or relative in EXPECTED_BINARY_FILES,
                'undeclared binary subtree asset: ' + relative)
        raw = read(path)
        require(not raw.startswith(b'\x7fELF'), 'raw CPU binary accidentally selected: ' + relative)
        entry = {'path': relative, 'bytes': len(raw), 'sha256': sha(raw)}
        if raw.startswith(b'\x1f\x8b'):
            decoded = gzip.decompress(raw)
            require(not decoded.startswith(b'\x7fELF') or
                    relative == 'binary/libmr3_gazebo_diff_drive.so.gz',
                    'undeclared encoded CPU binary selected: ' + relative)
            entry.update(decoded_bytes=len(decoded), decoded_sha256=sha(decoded))
        files.append(entry)
        asset_paths.append(path)

    manifest_counts = {}
    for path in asset_paths:
        if path.suffix != '.json' or 'manifest' not in path.name:
            continue
        document = json.loads(read(path))
        entries = document.get('entries', document.get('files', []))
        if not isinstance(entries, list):
            continue
        checked = 0
        for row in entries:
            if not isinstance(row, dict) or 'selected' not in row:
                continue
            selected = Path(row['selected'])
            if selected.is_absolute():
                target = selected
            elif str(selected).startswith(WP + '/'):
                target = ROOT / selected
            else:
                target = path.parent / selected
            require(target.resolve().is_relative_to(ASSET.resolve()),
                    'archive selected path escapes active evidence: ' + str(target))
            encoded = read(target)
            require(sha(encoded) == row['encoded_sha256'] and
                    len(encoded) == row['encoded_bytes'], 'archive encoded mismatch: ' + str(target))
            decoded = gzip.decompress(encoded) if encoded.startswith(b'\x1f\x8b') else encoded
            require(sha(decoded) == row['raw_sha256'] == row['decoded_sha256'] and
                    len(decoded) == row['raw_bytes'], 'archive decoded mismatch: ' + str(target))
            checked += 1
        manifest_counts[str(path.relative_to(ASSET))] = checked

    docs = {ROOT / relative for relative in ALLOWED if relative.endswith('.md')}
    docs.add(W / 'MR3_ADAPTER_CONTRACT.md')
    docs.add(W / 'MR3_TASK_CONTRACT.md')
    links = []
    for path in sorted(docs):
        if not path.exists():
            continue
        for target in re.findall(r'\]\(([^)]+)\)', read(path).decode()):
            target = target.strip()
            if target.startswith(('http:', 'https:', '#', 'app:', 'plugin:', 'mailto:')):
                continue
            if target.startswith('<') and '>' in target:
                target = target[1:target.index('>')]
            local = unquote(target.split('#', 1)[0])
            require((path.parent / local).exists(), 'missing local link: ' + str(path) + ' -> ' + target)
            links.append([str(path.relative_to(ROOT)), target])

    diff = subprocess.run(['git', 'diff', '--check'], cwd=ROOT, capture_output=True)
    require(diff.returncode == 0, 'git diff --check failed: ' + diff.stdout.decode() + diff.stderr.decode())
    # Final reread is deliberately after all evidence/link parsing and before
    # the exclusively-created outputs. It catches concurrent source/archive writes.
    for path, expected in bindings.items():
        require(sha(Path(path).read_bytes()) == expected['sha256'],
                'input changed before static verdict: ' + path)
    inventory = {'self_excluded': True, 'exclude_python_cache': True, 'files': files}
    report = {
        'schema': 'mr3-v13-prefreeze-inventory-whitelist-static-v1', 'passed': True,
        'base': BASE, 'head': git('rev-parse', 'HEAD').decode().strip(),
        'scope': 'Read-only working-source/static checks before clean pushed admission; '
                 'no new CPU suite/native/physical/task/PPO credit.',
        'plan_sha256': sha(read(plan_path)), 'independent_source_bindings': len(current),
        'retained_immutable_bindings': 73, 'authorized_updated_bindings': updated_old,
        'new_bindings': sorted(current.keys() - previous.keys()),
        'runtime_pins': len(pins), 'hard_bounds': original_bounds,
        'actual_library_sha256': build['library_sha256'], 'four_compiled_sources': compiled,
        'prior_experiment_log_prefix_preserved': True, 'prior_V12_FAIL_report_preserved': True,
        'historical_asset_changes': historical,
        'whitelist': {'explicit_non_asset_paths': sorted(ALLOWED),
                      'intentional_asset_subtree': asset_prefix,
                      'changed_non_asset_paths': sorted(name for name in diff_names | untracked
                                                       if not name.startswith(asset_prefix)),
                      'unexpected_paths': extras},
        'inventory': {'path': str(args.inventory), 'self_excluded': True,
                      'files': len(files), 'encoded_bytes': sum(row['bytes'] for row in files),
                      'excluded_cache': excluded_cache},
        'archive_manifest_rows_verified': manifest_counts,
        'local_links': links, 'git_diff_check': {'exit': diff.returncode, 'stdout_sha256': sha(diff.stdout),
                                                'stderr_sha256': sha(diff.stderr)},
        'all_parsed_inputs_stable_before_after': True, 'bindings': bindings,
    }
    with args.inventory.open('x') as output:
        json.dump(inventory, output, indent=2, allow_nan=False)
        output.write('\n')
    report['inventory']['sha256'] = sha(args.inventory.read_bytes())
    with args.report.open('x') as output:
        json.dump(report, output, indent=2, allow_nan=False)
        output.write('\n')
    print(json.dumps({'passed': True, 'asset_files': len(files),
                      'independent_bindings': len(current), 'runtime_pins': len(pins),
                      'links': len(links), 'manifest_rows': sum(manifest_counts.values()),
                      'inventory': str(args.inventory), 'report': str(args.report)}))


if __name__ == '__main__':
    main()
