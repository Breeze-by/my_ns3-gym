"""Static-only V26 whole-byte source inverse and actual stage metadata validation."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import os
import subprocess
import time

D = Path(__file__).resolve().parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
WORKER = ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
          'report/assets/20261018_mr3_p2a0_v25_smoother/independent/'
          'mr3_v25_stage_worker_bindings_v1.py')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def replace(source, before, after):
    assert source.count(before) == 1, (before[:100], source.count(before))
    return source.replace(before, after)


def inverse(source, name):
    if 'buildproof' in name or 'launch_stage' in name:
        block = (D / 'worker_checked_block_v1.txt').read_text().removesuffix('\n')
        source = replace(source, block,
                         '    from mr3_v26_stage_worker_bindings_v1 import validate_worker_bindings')
    if 'run_matrix' in name:
        source = replace(source, "    worker_helper = ROOT / '" + WORKER + "'",
                         "    worker_helper = A / 'independent/mr3_v26_stage_worker_bindings_v1.py'")
        block = """    worker_raw = worker_helper.read_bytes()
    worker_expected = '3b685448644d5e1ad50adf3f551107120e13c692865a4e7f6bc0facd2c844e70'
    require(sha(worker_raw) == sources[worker_helper] == worker_expected,
            'immutable A25 worker helper differs')
    worker_namespace = {}
    exec(compile(worker_raw, str(worker_helper), 'exec'), worker_namespace)
    validate_worker_bindings = worker_namespace['validate_worker_bindings']"""
        source = replace(source, block,
                         '    from mr3_v26_stage_worker_bindings_v1 import validate_worker_bindings')
        source = replace(source, 'four declared V26 launch/audit CLIs',
                         'four declared V22 launch/audit CLIs')
    if 'buildproof' in name:
        source = replace(source, 'independent/mr3_v26_smoother_custody_v2.py',
                         'independent/mr3_v26_smoother_custody_v1.py')
    if 'cross_stage_mapping' in name or 'multiepoch_closure' in name:
        source = replace(source, "relative = asset + 'independent/mr3_v26_smoother_custody_v2.py'",
                         "relative = asset + 'independent/mr3_v26_smoother_custody_v1.py'")
        source = replace(source, """expected_binding = ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
                        'report/assets/20261018_mr3_p2a0_v25_smoother/'
                        'independent/mr3_v25_smoother_binding_v1.json')""",
                         "expected_binding = asset + 'independent/mr3_v26_smoother_binding_v1.json'")
    if 'cross_stage_mapping' in name:
        source = replace(source,
                         "    smoother_binding_asset = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v25_smoother/independent'\n", '')
        source = replace(source,
                         "smoother_asset/'mr3_v26_smoother_custody_v2.py',smoother_binding_asset/'mr3_v25_smoother_binding_v1.json'",
                         "smoother_asset/'mr3_v26_smoother_custody_v1.py',smoother_asset/'mr3_v26_smoother_binding_v1.json'")
    return source


def main():
    started = time.monotonic()
    output = D / 'checks_static_v1'
    output.mkdir()
    sources, inputs = [], {}

    def read(path):
        before = path.stat()
        raw = path.read_bytes()
        after = path.stat()
        shape = lambda v: [v.st_dev, v.st_ino, v.st_size, v.st_mtime_ns, v.st_ctime_ns]
        assert shape(before) == shape(after)
        inputs[str(path)] = {'sha256': sha(raw), 'bytes': len(raw), 'stat': shape(after)}
        return raw

    for path in sorted((D / 'independent').glob('*.py')):
        raw = read(path)
        ast.parse(raw)
        mechanical = read(D / 'mechanical_v1' / path.name)
        old = read(D / 'baseline_v25' / path.name.replace('v26', 'v25'))
        generated = old.decode().replace('20261018_mr3_p2a0_v25_smoother',
                                         '20261018_mr3_p2a0_v26_capture')
        generated = generated.replace('v25', 'v26').replace('V25', 'V26').replace(
            'PRIOR_ENGINEERING_WALL_SECONDS = 572.9355761036277',
            'PRIOR_ENGINEERING_WALL_SECONDS = 1369.6459453934804')
        assert generated.encode() == mechanical, 'mechanical generation mismatch ' + path.name
        restored = inverse(raw.decode(), path.name)
        assert restored.encode() == mechanical, 'full inverse mismatch ' + path.name
        assert ast.dump(ast.parse(restored)) == ast.dump(ast.parse(mechanical))
        assert 'from mr3_v26_stage_worker_bindings_v1 import' not in raw.decode()
        patch = ''.join(difflib.unified_diff(mechanical.decode().splitlines(True),
                        raw.decode().splitlines(True), fromfile='mechanical/' + path.name,
                        tofile='proposed/' + path.name))
        (output / (path.name + '.patch')).write_text(patch)
        sources.append({'path': str(path), 'sha256': sha(raw), 'bytes': len(raw),
                        'old_source_sha256': sha(old), 'mechanical_sha256': sha(mechanical),
                        'whole_byte_and_AST_inverse': True})
    old_path = ROOT / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
                      'report/assets/20261018_mr3_p2a0_v25_smoother/predeclared_plan_v25.json')
    old = json.loads(read(old_path))
    plan = json.loads(read(D / 'predeclared_plan_v26.draft.json'))
    gate_fields = ('unchanged_gates', 'physical_response_criteria', 'angular_interface_criteria',
                   'angular_reset_criteria', 'settled_turn_criteria', 'full_execution_model_failfast',
                   'max_api_records', 'max_submitted_script_decisions', 'max_total_wall_seconds',
                   'pilot_budget_unchanged', 'new_execution_contracts', 'navigation_profile',
                   'native_ray_box_correction', 'drive_contract', 'shim_runtime_custody')
    assert all(plan[key] == old[key] for key in gate_fields)
    assert plan['smoother_runtime_custody']['binding'] == old['smoother_runtime_custody']['binding']
    assert plan['native_admission_granted'] is False and plan['readiness']['status'] != 'ready'
    assert [len(row['required_audit_receipts']) for row in plan['stages']] == [10, 7, 10, 7]
    worker_raw = read(ROOT / WORKER)
    assert sha(worker_raw) == '3b685448644d5e1ad50adf3f551107120e13c692865a4e7f6bc0facd2c844e70'
    namespace = {}
    exec(compile(worker_raw, str(ROOT / WORKER), 'exec'), namespace)
    for row, prior, wanted in zip(plan['stages'], old['stages'],
            [[(218, 13901)], [(220, 13911)], [(222, 13921), (223, 13922)], [(226, 13931)]]):
        actual = namespace['validate_worker_bindings'](row)
        assert [(x['domain'], x['port']) for x in actual] == wanted
        argv = row['command'].copy()
        for flag in ('--base-domain', '--base-port'):
            argv[argv.index(flag) + 1] = prior['command'][prior['command'].index(flag) + 1]
        assert [s.replace('v26', 'v25') for s in argv] == prior['command']
        assert row['wall_ceiling_seconds'] == prior['wall_ceiling_seconds']
        assert [s.replace('v26', 'v25') for s in row['required_audit_receipts']] == prior['required_audit_receipts']
    assert plan['prior_engineering_cost']['wall_seconds'] == 1369.6459453934804
    assert 572.9355761036277 + 796.7103692898527 == 1369.6459453934804
    command = ['/usr/bin/python3', '-m', 'flake8', '--select=E9,F63,F7,F82',
               *map(str, sorted((D / 'independent').glob('*.py')))]
    environment = dict(os.environ, PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1')
    result = subprocess.run(command, cwd=ROOT, env=environment, capture_output=True)
    (output / 'fatalstyle.stdout').write_bytes(result.stdout)
    (output / 'fatalstyle.stderr').write_bytes(result.stderr)
    assert result.returncode == 0
    for path, expected in inputs.items():
        current = Path(path).stat()
        assert [current.st_dev, current.st_ino, current.st_size, current.st_mtime_ns,
                current.st_ctime_ns] == expected['stat']
        assert sha(Path(path).read_bytes()) == expected['sha256']
    checks = {'passed': True, 'sources': sources, 'old_mathematics_and_gate_fields_same': gate_fields,
              'original34_required_counts': [10, 7, 10, 7], 'unchanged_reset8_pooled_math': True,
              'all_stages_actual_command_metadata_verified': True,
              'carried_wall_seconds': 1369.6459453934804,
              'opening_remaining_wall_seconds': 16630.35405460652,
              'worker_helper_immutable_checked_fixed_path': WORKER,
              'no_adjacent_import_or_duplicate_helper_source': True,
              'fatalstyle': {'argv': command, 'exit_code': result.returncode, 'cwd': str(ROOT),
                             'environment_delta': {'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1'}},
              'inputs': inputs, 'all_final_sha_stat_verified': True,
              'wall_seconds': time.monotonic() - started,
              'scope': 'Static wholebyte/AST inverse and fatal syntax once only; no ROS/DDS, '
                       'native, build, preflight, consumer or old fixture suite execution. '
                       'CI fixed observation module/loader identity remains separately reviewed.'}
    (output / 'checks.json').write_text(json.dumps(checks, indent=2) + '\n')
    print(json.dumps({'passed': True, 'checks': str(output / 'checks.json'),
                      'wall_seconds': checks['wall_seconds']}))


if __name__ == '__main__':
    main()
