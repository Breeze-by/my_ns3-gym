import json,os
from pathlib import Path
v=json.loads((Path(__file__).parent/'cpu_v4/spec_v4.json').read_bytes())
os.chdir(v['cwd'])
os.environ['PYTHONDONTWRITEBYTECODE']='1'
os.environ['CUDA_VISIBLE_DEVICES']=''
os.execv(v['actual_argv'][0],v['actual_argv'])
