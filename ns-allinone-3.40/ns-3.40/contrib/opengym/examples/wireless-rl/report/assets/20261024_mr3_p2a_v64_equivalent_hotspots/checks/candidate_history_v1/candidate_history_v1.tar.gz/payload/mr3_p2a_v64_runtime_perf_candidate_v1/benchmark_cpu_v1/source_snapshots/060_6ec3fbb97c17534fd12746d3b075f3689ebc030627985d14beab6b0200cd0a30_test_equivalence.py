import copy
import importlib.util
import random
from pathlib import Path
from multi_robot_exploration import mr3_reach_runtime as candidate
from multi_robot_exploration.mr3_drive_phase import DrivePhaseClient
from test_mr3_reach_runtime_independent import EPOCH, ROBOT, START, STEP, calibration, odometry, target, storage, applied

spec = importlib.util.spec_from_file_location('original_runtime', Path(__file__).with_name('original_runtime.py'))
original = importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)


def outcome(fn, *args):
    try:
        return ('return', fn(*copy.deepcopy(args)))
    except Exception as error:
        return (type(error).__name__, str(error))


def test_monotone_ingress_and_duplicate_conflicts_match_original():
    a, b = original.ReachTracker(EPOCH, ROBOT), candidate.ReachTracker(EPOCH, ROBOT)
    for i in range(1, 801):
        raw = odometry(START + (i-1)*STEP)
        cal = calibration(raw, i)
        pub = target(START + (i-1)*STEP, i)
        for method, args in [('receive_raw', (raw, i)), ('receive_calibration', (cal,)), ('publish_target', (pub,))]:
            assert outcome(getattr(a, method), *args) == outcome(getattr(b, method), *args)
        assert a.__dict__ == b.__dict__ or all(a.__dict__[k] == b.__dict__[k] for k in a.__dict__ if k != 'storage')
    # Same identity with changed content must still fail permanently.
    changed = calibration(raw, i); changed['coefficient_c'] = .5
    assert outcome(a.receive_calibration, changed) == outcome(b.receive_calibration, changed)
    assert a.fault == b.fault


def test_storage_latest_predicate_all_boundaries_and_consume():
    rng = random.Random(6401)
    for count in (1, 2, 19, 256):
        store = DrivePhaseClient(EPOCH)
        clock = START
        for i in range(1, count+1):
            clock += rng.choice((0, 0, 1, STEP))
            store.receive(storage(target(clock, i), 2*i))
        for source in {START-1, START, clock, clock+1, *[p['clock_ns'] for p in store.pending[ROBOT].values()]}:
            for cmd in range(0, 2*count+3):
                expected = any(p['cmd_seq'] > cmd and p['clock_ns'] < source for p in store.pending[ROBOT].values())
                actual = False
                for p in reversed(store.pending[ROBOT].values()):
                    if p['cmd_seq'] <= cmd:
                        break
                    if p['clock_ns'] < source:
                        actual = True
                        break
                assert actual == expected
        # Consume preserves the insertion ordering and all surviving rows.
        cutoff = count//2
        remaining = {k: v for k,v in store.pending[ROBOT].items() if k > cutoff}
        assert list(remaining) == sorted(remaining)


def test_actual_applied_return_and_latched_failure_match():
    for source_delta in (-1, 0, 1, STEP):
        for used in (1, 2, 3):
            a, b = original.ReachTracker(EPOCH, ROBOT), candidate.ReachTracker(EPOCH, ROBOT)
            for i in range(1, 4):
                pub = target(START, i)
                for tracker in (a, b):
                    tracker.publish_target(pub)
                    tracker.receive_storage(storage(pub, i))
            event = applied(target(START, used), START+source_delta, 1, used)
            assert outcome(a._applied, event) == outcome(b._applied, event)
            assert a.fault == b.fault


def test_all_prior_evidence_retained_at_long_frontier():
    a, b = original.ReachTracker(EPOCH, ROBOT), candidate.ReachTracker(EPOCH, ROBOT)
    for i in range(1, 1001):
        pub = target(START + i*STEP, i)
        for tracker in (a,b):
            tracker.publish_target(pub)
            tracker.receive_storage(storage(pub,i))
    assert a.ingress == b.ingress
    assert a.published == b.published
    assert a.storage.pending == b.storage.pending
