"""DRAFT: passive real-message archive only; no publishers, services or control inputs.

Installation into the canonical worker is not authorized/applied by this file.
CDR means serialize_message(real received ROS message), not a wire-packet capture.
"""
import gzip
import hashlib
import json
from pathlib import Path
import queue
import threading
import time

TOPICS = tuple((robot, name, message_type) for robot in ('tb1', 'tb2', 'tb3')
               for name, message_type in (
                   ('cmd_vel_nav', 'geometry_msgs/msg/Twist'),
                   ('received_global_plan', 'nav_msgs/msg/Path'),
                   ('transformed_global_plan', 'nav_msgs/msg/Path'),
                   ('local_plan', 'nav_msgs/msg/Path'),
                   ('evaluation', 'dwb_msgs/msg/LocalPlanEvaluation')))


class NativeNavigationArchive:
    """Freeze callback bytes immediately; one owned writer compresses off ROS thread."""

    def __init__(self, node, directory, epoch, clock_ns, on_error,
                 max_pending_bytes=64 * 1024 * 1024, max_pending_records=64):
        self.node = node
        self.directory = Path(directory)
        self.epoch = epoch
        self.clock_ns = clock_ns
        self.on_error = on_error
        self.max_pending_bytes = max_pending_bytes
        self.pending_bytes = 0
        self.queue = queue.Queue(maxsize=max_pending_records)
        self.lock = threading.Lock()
        self.topic_sequences = {}
        self.sequence = 0
        self.closed = False
        self.error = None
        self.last_graph = {}
        self.subscriptions = []
        self.output = (self.directory / 'native_navigation.jsonl').open('x', buffering=1)
        self.writer = threading.Thread(target=self._write, name='mr3_navigation_archive',
                                       daemon=True)
        self.writer.start()

    def install(self, callback_wrapper):
        from dwb_msgs.msg import LocalPlanEvaluation
        from geometry_msgs.msg import Twist
        from nav_msgs.msg import Path as ROSPath
        from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy

        types = {'geometry_msgs/msg/Twist': Twist, 'nav_msgs/msg/Path': ROSPath,
                 'dwb_msgs/msg/LocalPlanEvaluation': LocalPlanEvaluation}
        qos = QoSProfile(depth=10, reliability=ReliabilityPolicy.RELIABLE,
                         durability=DurabilityPolicy.VOLATILE)
        for robot, name, message_type in TOPICS:
            topic = '/' + robot + '/' + name
            self.subscriptions.append(self.node.create_subscription(
                types[message_type], topic, callback_wrapper(
                    lambda message, robot=robot, topic=topic, message_type=message_type:
                    self.record(robot, topic, message_type, message)), qos))
        return self.subscriptions

    def _publishers(self, topic):
        result = []
        for endpoint in self.node.get_publishers_info_by_topic(topic):
            qos = endpoint.qos_profile
            result.append(dict(namespace=endpoint.node_namespace, node=endpoint.node_name,
                               topic_type=endpoint.topic_type,
                               endpoint_gid=bytes(endpoint.endpoint_gid).hex(),
                               qos=dict(reliability=int(qos.reliability),
                                        durability=int(qos.durability),
                                        history=int(qos.history), depth=qos.depth)))
        return sorted(result, key=lambda row: (row['namespace'], row['node'],
                                               row['endpoint_gid']))

    def record(self, robot, topic, message_type, message):
        from rclpy.serialization import serialize_message

        # These times describe the actual callback, never publisher source time.
        wall = time.monotonic_ns()
        clock = self.clock_ns()
        raw = bytes(serialize_message(message))
        header = getattr(message, 'header', None)
        source_header = (dict(frame_id=header.frame_id,
                              stamp=dict(sec=header.stamp.sec, nanosec=header.stamp.nanosec))
                         if header is not None else None)
        # DDS graph snapshot only; it cannot identify a Twist's actual sender.
        previous = self.last_graph.get(topic)
        if previous is None or wall - previous['captured_wall_monotonic_ns'] >= 1_000_000_000:
            previous = dict(captured_wall_monotonic_ns=time.monotonic_ns(),
                            publishers=self._publishers(topic),
                            scope='DDS graph snapshot, not per-message publisher identity')
            self.last_graph[topic] = previous
        digest = hashlib.sha256(raw).hexdigest()
        with self.lock:
            if self.closed or self.error is not None:
                raise RuntimeError('navigation archive closed/failed')
            if self.pending_bytes + len(raw) > self.max_pending_bytes:
                raise RuntimeError('navigation archive byte queue overflow; no silent drop')
            sequence = self.sequence + 1
            topic_sequence = self.topic_sequences.get(topic, 0) + 1
            row = dict(schema='mr3-native-navigation-receipt-v1', epoch=self.epoch,
                       record_sequence=sequence, topic_sequence=topic_sequence,
                       robot=robot, topic=topic, message_type=message_type,
                       received_clock_ns=clock, received_wall_monotonic_ns=wall,
                       source_header=source_header,
                       source_time_scope='message_header_retained' if source_header else
                                         'no_source_stamp; receipt_time_only',
                       payload_encoding='rclpy.serialize_message CDR', payload_sha256=digest,
                       payload_bytes=len(raw),
                       artifact='execution_inputs/navigation_cdr/' + digest + '.cdr.gz',
                       publisher_graph=previous,
                       scope='Passive received diagnostic; no exact DWB-costmap consumption '
                             'or controller-to-smoother per-packet ACK')
            # No mutable ROS message, later clock, or later graph reaches the writer.
            self.queue.put_nowait((row, raw))
            self.pending_bytes += len(raw)
            self.sequence = sequence
            self.topic_sequences[topic] = topic_sequence

    def _write(self):
        seen = set()
        try:
            while True:
                item = self.queue.get()
                if item is None:
                    return
                row, raw = item
                digest = row['payload_sha256']
                if digest not in seen:
                    path = self.directory / row['artifact']
                    path.parent.mkdir(parents=True, exist_ok=True)
                    encoded = gzip.compress(raw, compresslevel=1, mtime=0)
                    with path.open('xb') as stream:
                        stream.write(encoded)
                    assert gzip.decompress(encoded) == raw
                    seen.add(digest)
                self.output.write(json.dumps(row, sort_keys=True, allow_nan=False) + '\n')
                with self.lock:
                    self.pending_bytes -= len(raw)
        except BaseException as error:
            with self.lock:
                self.error = repr(error)
            self.on_error(error)

    def close(self):
        # Worker stops its ROS executor first, so no callbacks can race close.
        with self.lock:
            self.closed = True
        deadline = time.monotonic() + 10.
        while self.writer.is_alive():
            if time.monotonic() >= deadline:
                raise TimeoutError('navigation archive close/drain exceeded 10 wall seconds')
            try:
                self.queue.put(None, timeout=.1)
                break
            except queue.Full:
                continue
        self.writer.join(timeout=max(0., deadline - time.monotonic()))
        if self.writer.is_alive():
            raise TimeoutError('navigation archive writer did not finish')
        self.output.close()
        if self.error is not None:
            raise RuntimeError('navigation archive write failure: ' + self.error)
