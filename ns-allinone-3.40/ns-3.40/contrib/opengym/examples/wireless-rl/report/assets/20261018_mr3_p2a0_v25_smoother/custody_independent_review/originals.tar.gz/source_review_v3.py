#!/usr/bin/python3
"""Final static versioned custody/loader review, sealed TMP sources only."""
from pathlib import Path
import ast
import hashlib
import json
import time

D=Path(__file__).parent
V1=Path('/tmp/mr3_p2a0_v25_smoother_custody_proposal_v1')
V2=Path('/tmp/mr3_p2a0_v25_smoother_custody_proposal_v2')
V3=Path('/tmp/mr3_p2a0_v25_smoother_custody_proposal_v3')
RT=Path('/tmp/mr3_p2a0_v25_smoother_clock_source_review_v1')


def bound(path):
    def ident(s):return [s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
    s=path.stat();raw=path.read_bytes()
    assert ident(s)==ident(path.stat())
    return raw,{'path':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'stat':ident(s)}


def main():
    started=time.monotonic()
    names=['mr3_v25_smoother_custody_v1.py','mr3_v25_stage_worker_bindings_v1.py',
           'test_smoother_custody_v1.py','source_manifest_v1.json','mr3_v25_smoother_binding_v1.json','audit_ppo.proposed_v25.py']
    paths=[Path(__file__),V3/'handoff_v3.json',*[V3/name for name in names],
           V1/'mr3_v25_smoother_custody_v1.py',V2/'mr3_v25_smoother_custody_v1.py',V1/'audit_ppo.base_v24.py',
           V3/'checks_v1.json',V3/'checks_v1.stderr',D/'reused_z_counterexample_v1.json',D/'reused_z_counterexample_v2.json',
           RT/'proposed_package/src/velocity_smoother.cpp',RT/'primary/tag_1_1_20_velocity_smoother.cpp',
           Path('/tmp/mr3_p2a0_v25_actual_probe_independent_review_v1/review_v1.json')]
    captured=[bound(p) for p in paths];data={str(p):raw for p,(raw,row) in zip(paths,captured)}
    handoff=json.loads(data[str(V3/'handoff_v3.json')])
    for row in handoff['files']:
        assert hashlib.sha256(data[row['source']]).hexdigest()==row['sha256']
    module=data[str(V3/names[0])]
    module2=data[str(V2/names[0])]
    # The two reviewed Z/worker fixes do not change any other source bytes.
    worker_delta=(b"            require(old['worker_actual_argv'] == worker_argv, 'original worker argv borrows another episode')\n"
                  b"            require(not actual_worker or actual_worker.decode().rstrip('\\0').split('\\0') == worker_argv,\n"
                  b"                    'nonempty worker argv borrows another episode')\n"
                  b"            fresh_worker = util.proc_identity(worker['pid'], proc_root)\n"
                  b"            if fresh_worker is None:\n"
                  b"                result['pending_reason'] = 'owned worker naturally disappeared; no credit'\n"
                  b"                continue\n"
                  b"            require(pair(fresh_worker) == pair(worker), 'worker PID reused')\n"
                  b"            if fresh_worker['state'] == 'Z' and not actual_worker:\n"
                  b"                result['pending_reason'] = 'same owned worker naturally closed; no credit'\n"
                  b"                continue\n")
    assert module.count(worker_delta)==1 and module.replace(worker_delta,b'',1)==module2
    # Exact inverse of the final loader additions, preserving all old110/runtime/math.
    loader=data[str(V3/names[-1])]
    base=data[str(V1/'audit_ppo.base_v24.py')]
    assert hashlib.sha256(base).hexdigest()=='cc467064ab66e04507ed4d4e805a4e23cdf09b3716fd85517ebb34fe7b2de521'
    begin=loader.index(b'\nSMOOTHER_OVERLAY_PINS = {')
    end=loader.index(b'def extend_snapshot_validator',begin)
    added=loader[begin:end]
    assert b'6edeb3a7e814fb024594be724ef98dce39e1d23a84af5d34d6d6faac0b5cb88b' in added
    assert b'61276e5b98a8fb641ecae464386a7f1403acc73789df5251cd82bb35ab83b5e0' in added
    inverse=loader[:begin]+loader[end:]
    call=b'    proof.update(verify_velocity_smoother_overlay(root, freeze))\n'
    assert inverse.count(call)==1
    inverse=inverse.replace(call,b'',1)
    replacements=[
        (b"ENV_DOCUMENT_SHA256 = '41feac9a6d76adb839a615d7703e78e1b1c9f2ce22d55aba805387643536380e'",b"ENV_DOCUMENT_SHA256 = 'f1e0be60d35db3677fb9194341c1ae4133a5c74ed7199056fe18f7e797f40416'"),
        (b"ENV_EXECUTION_APPENDIX_SHA256 = 'c281693ef4755ae4c6760a87ec675c34e2d56da67ccceb79cc34a4d2f2f941c0'",b"ENV_EXECUTION_APPENDIX_SHA256 = 'b9bae951da6102af67bb3e106b0136dd0067eca9677cfaf3394f5095f87124a3'"),
        (b'ENV_EXECUTION_APPENDIX_BYTES = 11913',b'ENV_EXECUTION_APPENDIX_BYTES = 9875')]
    for new,old in replacements:
        assert inverse.count(new)==1;inverse=inverse.replace(new,old,1)
    assert inverse==base
    # Independent narrow source projection of the two timer factory replacements.
    cpp=data[str(RT/'proposed_package/src/velocity_smoother.cpp')]
    expected_cpp=data[str(RT/'primary/tag_1_1_20_velocity_smoother.cpp')]
    inverse_cpp=cpp.replace(b'#include "rclcpp/create_timer.hpp"\n',b'',1)
    for indent in ('  ','        '):
        new=(indent+'timer_ = rclcpp::create_timer(\n'+indent+'  get_node_base_interface(), get_node_timers_interface(), get_clock(),\n'+indent+'  rclcpp::Duration(std::chrono::milliseconds(static_cast<int>(timer_duration_ms))),\n').encode()
        old=(indent+'timer_ = this->create_wall_timer(\n'+indent+'  std::chrono::milliseconds(static_cast<int>(timer_duration_ms)),\n').encode()
        assert inverse_cpp.count(new)==1;inverse_cpp=inverse_cpp.replace(new,old,1)
    assert inverse_cpp==expected_cpp
    actual=json.loads(data['/tmp/mr3_p2a0_v25_actual_probe_independent_review_v1/review_v1.json'])
    binding=json.loads(data[str(V3/'mr3_v25_smoother_binding_v1.json')])
    assert binding['installed']['core']['sha256']==actual['modes']['fixed']['library']['sha256']
    assert b'Ran 21 tests' in data[str(V3/'checks_v1.stderr')]
    result={'schema':'mr3-v25-smoother-custody-independent-source-review-v3','verdict':'no_identified_blocker_for_exact_promotion',
            'input_bindings':[row for raw,row in captured],
            'reviewed_module_sha256':hashlib.sha256(module).hexdigest(),'reviewed_loader_sha256':hashlib.sha256(loader).hexdigest(),
            'module_v3_to_v2_exact_byte_inverse':True,'loader_to_V24_exact_byte_inverse':True,
            'old_runtime110_and_math_unchanged_after_explicit_new_hook_ENV3inverse':True,
            'fixed_cpp_two_factory_inverse_to_official_exact':True,
            'actual_core_matches_previously_independently_reviewed_probe_library':True,
            'per_episode_custody_review':[
                'Fixed canonical source10files/build2ELF/gzip archive with full decoded bytes/currentinstalled and frozenGitbytes are required; no alternate underlay path accepted.',
                'Live proof starts from SHA-pinned originalA13 monitor source/unaltered snapshot; exactworkerargv/metadataepoch/freeze and own ancestry select3namespaces, actual /proc exe inode/device and core executablemaps bind installedELF.',
                'SamePID/start R/S changes legal; sameidentity naturalZ/disappearance yields no credit; newstart reuse and true hash/permission/ELF/mapping/argv mismatch hard. Reader firstbytes/lastSHA prevent changed receipt reuse.',
                'Closed reader requires at least1complete3smoother proof for every actualEP, matching that episode metadata/supervisor/worker and original inventory. Anotherworker or epoch cannot fill missing proof.',
                'Shared loader preserves original110paths and math; only3ENV literals, fixed newverifier/pins and one mandatorycall added. Runtime systembash ament/ExecutableInPackage/ldd must resolve exact overlay; noROSnode. Fullnative mapping is still separate.'],
            'history':{'v1_reuse_Z':'Independently reproduced e890 errors[]; originalred source/result retained.',
                       'v2_reuse_Z':'Independently reproduced exactsticky smootherPIDreused; matchingZ remainedpending.',
                       'v3_worker_Z':'Narrowdiff source and author2specifiedcases inspected; author21PASS originalread. No author21 rerun by reviewer.'},
            'author_checks_scope':'Original18/19/21 fakeproc/stdlb checks and source/archive checks; Git and runtime-resolution subprocess are explicit substitutes. Not fullactualpreflight or native proof.',
            'remaining_real_admission':'After root exactpromotion/commit, genuine sourcefreeze+systemROSresolution preflight and perEP livemapping/closedreview must run. This staticverdict does not fake futureGit/native/P2A0acceptance.',
            'build_ROS_DDS_native_or_author_suite_executed':False,'all_inputs_end_stable':True,
            'source_reads_STOP':True,'review_wall_seconds':time.monotonic()-started}
    assert [row for raw,row in captured]==[bound(p)[1] for p in paths]
    out=D/'source_review_v3.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'verdict':result['verdict']}))

if __name__=='__main__':main()
