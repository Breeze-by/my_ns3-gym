V24独立只读归因（冻结5d684c46f9f99a867a94f1fed8c52e923e2486ef）

V24仍为真实FAIL。本次仅复核原fixed angular/physics JSON、一段已缓存2MiB motion原字节和CI已封小subset；没有重跑正式消费者、新ROS/DDS/SDK/native、修改任何源码/ELF/Git或门。原motion整体SHA0c8b503b30ffd1f3de583b50fdcb8de96b469f341e19bd30c696f5e40d2a2087同时由原angular消费者与本次lossless custody绑定；2MiB缓存自己的SHA另为2f434febf6a11accc523ba53a4bc9e1a9e0cf91272603b681fc76938d8b022be。

原angular报告sampled_bounds=false，coverage=true。tb2在source56.968s、owninput1601的fullangularnorm=1.206191435678961，比1.2超0.006191435678960966；wx=wy=0，原始wz为负。56.98s normalcommit选入该12ms新鲜raw后明确拒绝，故障不是stale、符号归一或一ULP端点问题。相邻rawwz为56.900:-1.134176、56.934:-1.183773、56.968:-1.206191、57.002:-1.196656。此越界在真实taskrelease42s之后、faultstop之前。

三机原最大planar分别.199974/.199191/.200752，chord最大均<.30；原sampledangularaccel最大分别4.363028/3.586144/2.243555，均<7。这些采样事实不为超1.2免责，也不提升为连续物理定理。三机均已有原A制停信用，tb1/tb2另有B信用；最后56.98s的A均missing_rest_evidence，但只剩.20s物理尾段，原observed_nonrest_beyond_horizon均false，不能把该缺证写成已证.78s失败。39nativechildren正常退出/保存身份均gone，与worker强制-15/failedsample/strictclosurefalse并存，两个范围都保留。

56.50–56.96共24次普通tb2决策均clear，component_filter=null，输出逐值等于绑定raw请求。56.98另为model-invalid后的零输出stop。关键已选输入如下：

|sim时间|raw序号|raw(v,w)|final|说明|
|---|---:|---|---|---|
|56.66|3550|(0,-.8)|相同|普通clear|
|56.68|3556|(.1,-.6315789474)|相同|普通clear|
|56.70|3561|(.1578947368,-.6315789474)|相同|普通clear|
|56.74|3573|(.2,-.4631578947)|相同|普通clear|
|56.96|3636|(.2,-.3789473684)|相同|普通clear|
|56.98|3642|(.1894736842,-.2105263158)|(0,0)|faultstop|

因此本次快速转入平移已在unguarded输入中出现，不能归为guard解除线速度零值。56.66→56.68为20ms sim、299825384ns wall、已选callback序号+6。此subset只选了被decision引用的raw行，未声称分析全部中间发布；生产receive_request实际每callback都会record，原完整ledger与pack不缺省这些原件。图身份字段明确该topic的velocity_smoother endpoint，但该证据仍是graph-at-callback，不虚构wire级publisher身份。

本机包为ros-humble-nav2-velocity-smoother1.1.20-1jammy.20260326.004635。官方1.1.20tag源码与release/humble1.1.20-1源码逐字同SHA788822f4ac41a03a46e73b6a7a73f876a75792e093d6c3f7b3dceecb69bcc50d，tagheader/package.xml与installed逐字同；actualELF另行SHA绑定，未声称可重现编译attestation。源码的激活及动态频率路径均create_wall_timer，OPEN_LOOP current取last_cmd，单tick按accel/frequency累计而非实际simdt。actualparameterAPI原PASS确认OPEN_LOOP/20Hz/线加速度.5/角加速度3.2，与本次wholeattempt身体FAIL属于不同事实。源码机制与暂停physics时内部目标按wall推进、在很短sim区间递送大斜率输入一致，尚不唯一证明全部机体动力学因果或修复充分。

CI稳定64次实际actuation与latest真实target逐tuple匹配，命令均在.2/.8内。56.968s同刻desired(.2,-.378947)、currentwheelproxy-1.224470、appliedproxy-1.101559、bodyraw-1.206191；current→desired凸组合起点已在名义角速盒外，原逐rim增量性质并未被这一事实推翻，但它不保证body1.2。不能把wheel proxy冒充body，也不能直接投影applied回.8后假称原rim步长保持。

最小优先修复假设为实际simtime下的平滑积分/转入平移过渡，保留.8命令、1.2身体和全部原门，独立覆盖相同clock不重复积分、激活/动态频率/回退与timeout及真实输出。这里只记录root已选的prospective V25方向，未实施、未授新native或矩阵信用；不再以降低cap、删除样本、提高rest/速度限或更换物理参数来消除本次FAIL。

保留一次只读探索表对stop缺省component_filter的KeyError，以及V1直接primary下载20s TimeoutError。后者无重试，V2使用RT已下载的相同官方tag/release原文；两个失败均不是native或生产失败。可重现的小分析source/argv/env/exit/wall/原stdout/stderr与完整表均在同目录。原参数API PASS、身体FAIL、强制worker关闭、后续stage SKIP不相互覆盖。
