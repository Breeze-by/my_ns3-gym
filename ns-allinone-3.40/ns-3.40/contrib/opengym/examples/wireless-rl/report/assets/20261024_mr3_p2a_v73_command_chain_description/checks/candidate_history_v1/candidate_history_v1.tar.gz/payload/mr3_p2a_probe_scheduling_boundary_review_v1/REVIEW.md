# 后继刺激调度：规则边界与两条待证路线

本轮只读当前源码与要求文档；没有读取 V72 输出、任何科学原件或旧 derived，没有执行测试、World、PPO 或 reader。以下是预声明选择条件，不是新候选实现或原生可行性结论。V71 与所有历史 FAIL 不变。

**判断：可以研究分批输入，但先等 V72 的同一收到快照给出合法集合。** 如果实际三 GOAL 子集中最长的瓶颈路径仍短，而一/二 GOAL 子集存在更长路径，那么改变“GOAL 数量第一”的外部刺激排序有可检验动机。若各子集都没有改善，不能靠改排名、延拍或任意移动窗口保证取消覆盖。声明路径长仅是特征，绝不证明目标能活过 5 秒、会产生正速度或能安全停车。

## 不能越过的原门

| 类别 | 源码依据与必须保留的内容 |
|---|---|
| P2A 任务出口 | RESEARCH_PLAN.md:306–331：300 仿真秒内后端已交付融合图正确自由覆盖至少 .95，原 ROI/质量门、三台参与、零全机体非支撑接触、18 路持续新鲜监测和导航闭合。当前 qualification 的 32 步刺激不是完整任务成功。 |
| 目标协议 | RESEARCH_PLAN.md:230–249、MR3_ENV_CONTRACT.md:64/86、mr3_protocol.py:188–199/294–318：K8+KEEP/WAIT 原语、单 owner、真实 accepted 后 5 秒承诺、生成时间/观测 digest/版本/TTL2秒/FIFO。承诺内不能用普通 WAIT 或换目标截短；安全停止、自然终态例外。自然 SUCCEEDED 可以早于 5 秒，不能延迟/隐藏它以伪造 moving cancel。 |
| 原 actor 合法性与输入 | mr3_observation.py:744–813 的原 per-robot AND joint mask；KEEP 仍保留 active peer 的旧目标或 idle peer 的位置，不会消除目标净空冲突。audit_seed_inputs.py:176–186 从实际归档收到输入重建完整 snapshot；不能改 mask、补未来位姿/地图或把未观测 joint bit 当真。 |
| 原物理/角运动 | frozen physics leaf v3：A 实际 linear-zero 与 B 实际 native-cancel 分开；有意义片段 prior 非零输出至少 .10s、初始 raw planar speed 至少 .05m/s、gap≤.10s、连续三 raw rest≤.01m/s、取消至 rest≤.78s、观测 polyline≤.144m；任何 eligible 片段已观察到的停车超限及全部速度/chord违例都不能由另一事件 PASS 抵消，线速/chord .30、角范数1.2等仍检查。B 起点是真 native_cancel 调用，真实完成证据必需，不能换成 stopReady/ACK 时刻。frozen angular leaf v4（interface完整门；reset仍按原聚合范围）：范数1.2、相邻采样向量加速度7、gap .10s；每机有效转向段，团队正/负且至少一机顺序反向，不能用目标 bearing 软排名充实际转向。 |
| 当前 Reach/执行/资格 | R=39/5000、H=.78s、原一次 anchor、STOP 债务、paired slew、actual motor/APPLIED 披露、首次非零后 servo 永久退出、receiving authority 的真实 owner/cancel/stop 证据都保持。新输入不能旁路写速度或重置状态。新同 freeze 的12EP/30角色、9 probe 独立重放、12 authority 证明和完整其他 audits/关闭/source/newbuild 门仍必需；capacity=False 时不进入 policy，P2A 的真实学习/三场 strict95 出口不变。 |

## 后来添加的负载构造，不能冒称原安全定律

`benchmark.py` 的收到信息探针（约625–890行）另外规定：初始 GOAL 窗 `<1.5s`，第二轮 `[13,20)s`；accepted 在 task≤2/≤20；两轮各三机且每机各一次 GOAL/scientific WAIT，即六个 GOAL；moving WAIT 需 fresh/valid、same accepted active owner、收到的 `v>=.08`、accepted 后一次有效路径基线且新增 path≥.05、原 WAIT mask True；首次 scientific WAIT 不迟于10/28；初轮 terminal 后三次不同源新鲜 rest 且经过3秒后才交棒；cleanup WAIT 不授科学信用；32秒 final snapshot 检查所有状态，缺机会照FAIL。

这些窗口、六次 GOAL、3秒 handoff 是当前外部工作负载与独立 replay 的显式契约，不是原物理 `.78/.144` 定律。**本建议仍全部保留它们，不靠放宽窗口换 PASS。** 原物理的“三连续 raw rest”与当前探针的“三次策略采样收到 rest+初轮3秒”也不是同一证据。5秒承诺则是原协议硬门，不能归入可随意移动的 probe 参数。

32 步、reset 八 EP 等来自已冻结的资格 workload：V17 angular/reset physics wrapper 明确精确33条记录/32步及2worker八回合；angular reset只聚合 sampled bounds，physics reset逐事件保硬界并按既定跨回合 stop coverage 聚合。它们没有规定“每EP两轮六个 GOAL/accepted≤2/第二轮13–19”。不过这些 wrapper 与当前12EP30门已经是本活动的准入合同，新族不能用旧 literal/PASS 标签兼容，亦不能删原角色、缩短32或拼冻结。

## 两条可检验的前瞻路线

**A：两台先发、一台下一拍。** 初始 task0 仅从实际 perANDjoint=True 且恰有2个 GOAL 的原动作子集选择，用原声明 path 的最小值、第二轮原 reverse 软计数、path 总和与确定性 action 排名；其余机器人只能选原合法 KEEP。task1 仅尝试给尚未服务的一台发一次原合法 GOAL，已服务者 KEEP；不得重发、替换或刷新 accepted/baseline。第二轮在原13–19窗口按相同“先2后1”义务推进，前提是各机真实初轮 handoff 完成；WAIT 始终由原实际 moving 条件优先。无最小路径硬阈值，无新候选或方向筛选。

动机只可能来自 V72 **task0 原二GOAL集合**相对三GOAL集合的路径差异。它不能证明 task1 的剩余目标仍合法：此时机器人可能已动、peer 的旧目标仍参与 joint 冲突，mask 必须重新读取。task1无合法动作、accepted>2、目标在合法 WAIT 前自然结束、或其余任何原条件缺失，均明确 FAIL。不能退回假 joint、发第三拍初始 GOAL或把 cleanup 当科学 WAIT。

**B：单台先发、剩余两台下一拍。** 若 V72 显示原单GOAL集合比二GOAL集合有实质瓶颈路径优势，可另一个固定新版本在 task0 选1个 GOAL，task1 对未服务两台选原合法2GOAL；第二轮保持同样单/双批次。排名仍只使用实际收到的合法集合与 finite 非负 path（真实0保留，缺失/坏值dataFAIL），不假设“最长路径必定存活”。首次服务机器人应由预声明的收到路径/义务排序决定，不能看试跑结果手挑赢家。

这一路线比 A 更依赖 task1 的双GOAL joint 可用性与≤2秒接受期限；task0 的原单GOAL合法性不能代替这两个后继事实。它与 A 是互斥的、需在看过 V72 后选定一个固定族的设计选项，不是给正式 driver 添加在线自由调参/重试分支。

**时间边界：** 1秒决策加 `<1.5s` 初始窗口只有 task0、task1 两次机会，因此逐机三拍串行初发在当前合同下不可行；不可拿第三拍弥补。每台承诺从自己的真实 accept 起算，故第二拍发 GOAL 只有≤2的接受余量。初轮须在≤10科学 WAIT、真实终态和三fresh-rest/3秒交棒后，才可能进入13–19第二窗。第二轮 accepted≤20意味着承诺最早到其各自accept+5，仍必须在≤28观察到合法moving WAIT并在32终点前收到所需rest。`.78s`物理停止界不保证ROS回执交付在一拍内，也不保证目标当时仍active；不能由这些数字直接宣布排程能完成。

## V72 后的选择与停止规则

先看实际 task0/合法GOAL机会的1/2/3GOAL分布及每机器人瓶颈 path/目标、原 perANDjoint 和收到生命周期。只用同一快照说明输入备选，不外推改变轨迹后的未来银行/冲突。若 A 或 B 的合法路径优势不存在，停止这两条，不搜索距离阈值或盲改窗口。即使优势存在，CPU也只能证明选择、义务、同owner基线与失败分支；只有新显式 producer/reader/profile、旧V3/masked完整差分/负例、所有公开入口/metadata/newbuild/source闭包、预声明有界同freeze真实资格，才能检验实际覆盖。旧FAIL永久保留；未产生资格、容量或P2A成功结论。
