import hashlib
import importlib.util
import json
from pathlib import Path
from geometry_msgs.msg import TransformStamped
from nav_msgs.msg import Odometry
from std_msgs.msg import String
from tf2_msgs.msg import TFMessage
from multi_robot_exploration.mr3_information import restore_message
from multi_robot_exploration import peer_obstacles as peer

ROOT = Path('/home/zhuyulab/ns3-workspace')
TEST = ROOT / ('ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/'
               'test/test_peer_phase.py')
INFO = Path('/tmp/mr3_p2a0_v10_information_producer_fixture_v2/information_states.jsonl')
OUT = Path('/tmp/mr3_p2a0_v10_peer_producer_overlap_fixture_v1')
OUT.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location('actual_peer_test_fixture', TEST)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
rows = [json.loads(line) for line in INFO.read_text().splitlines()]
acks = [row['payload']['ack'] for row in rows if row['kind'] == 'state_phase_ack'
        and row['payload']['ack']['operation'] == 'commit'
        and row['payload']['ack']['ok'] is True and not row['payload']['cached']]
node, clock, _, _ = module.fixture()
node.epoch = acks[0]['epoch']
clock[0] = acks[0]['target_time_ns']
node.record_phase('configuration', {'stepped_mode': True, 'tf_source_lead_sec': .2,
                                   'input_topics': {k + ':' + n: v
                                                   for (k, n), v in node.phase_input_topics.items()}})
node.receive_phase_request(String(data=peer.canonical({
    'schema': 'mr3-peer-phase-request-v1', 'epoch': node.epoch,
    'request_id': 'takeover', 'target_time_ns': clock[0], 'operation': 'takeover'})))
results = []
for ack in acks:
    clock[0] = ack['target_time_ns']
    publication = next(row['payload'] for row in rows if row['kind'] == 'state_publish'
                       and row['payload']['message_sha256'] == ack['bundle_sha256'])
    for name in node.names:
        payload = publication['envelopes'][name]['payload']
        node.receive_odom(restore_message(Odometry(), payload['odometry']), name)
        tf = restore_message(TransformStamped(), payload['transform'])
        node.receive_tf(TFMessage(transforms=[tf]), name)
    node.receive_state_bundle(String(data=peer.canonical(publication['message'])))
    request = {'schema': 'mr3-peer-phase-request-v1', 'epoch': node.epoch,
               'request_id': ack['request_id'], 'target_time_ns': clock[0],
               'operation': 'commit', 'state_commit': ack}
    node.receive_phase_request(String(data=peer.canonical(request)))
    peer_ack = json.loads(node.phase_ack_pub.messages[-1].data)
    assert peer_ack['ok'] is False, peer_ack
    assert node.failed and module.output_count(node) == 0
    results.append(peer_ack)
ledger = OUT / 'peer_phase.jsonl'
ledger.write_text(node.phase_audit.getvalue())
result = {'passed': True, 'scope': 'Actual information ACK/raw payloads into actual peer callbacks '
          'and actual ROS scan/cloud construction with fake publishers; no ROSinit/DDS/native credit.',
          'information_fixture_sha256': hashlib.sha256(INFO.read_bytes()).hexdigest(),
          'peer_source_sha256': hashlib.sha256(Path(peer.__file__).read_bytes()).hexdigest(),
          'ledger_sha256': hashlib.sha256(ledger.read_bytes()).hexdigest(),
          'rejected_commit_count': len(results), 'acks': results,
          'failure': json.loads(node.failure_publisher.messages[0].data)}
(OUT / 'receipt.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({k: result[k] for k in ('passed', 'rejected_commit_count', 'ledger_sha256')}))
