"""Exact proposed production helper AST; Git I/O substituted with bound fixture bytes."""
import ast
import copy
import hashlib
import inspect
from pathlib import Path
import subprocess
from types import SimpleNamespace
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
TREE = ast.parse((HERE / 'proposed_audit_ppo.py').read_text())
NAMES = {'ROS', 'WIRELESS', 'EXECUTION_CONFIG_PINS', 'EXECUTION_NORMATIVE_FREEZE',
         'EXECUTION_NORMATIVE_PINS', 'SENSOR_DIAGNOSTIC_CONFIG_PINS', 'RAY_BOX_EXECUTION_PINS',
         'RAY_BOX_SOURCE_PINS', 'RAY_BOX_LICENSE_PINS', 'RAY_BOX_LAUNCH_CHANGES', 'RAY_BOX_CMAKE_ADDITION', 'RAY_CMAKE_ADDITION'}
FUNCTIONS = {'require', 'sha', 'verify_frozen_pins', 'project_sensor_diagnostic_runtime',
             'project_ray_box_runtime', 'verify_execution_configs'}
BODY = [node for node in TREE.body if (
    isinstance(node, ast.FunctionDef) and node.name in FUNCTIONS) or (
    isinstance(node, ast.Assign) and any(isinstance(target, ast.Name)
        and target.id in NAMES for target in node.targets))]

class ExecutionProjection(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.constants = {}
        exec(compile(ast.Module(body=[copy.deepcopy(n) for n in BODY if isinstance(n, ast.Assign)],
                               type_ignores=[]), '<constant fixture>', 'exec'), cls.constants)
        cls.normative = {path: subprocess.check_output(
            ['git', 'show', cls.constants['EXECUTION_NORMATIVE_FREEZE'] + ':' + path], cwd=ROOT)
            for path in cls.constants['EXECUTION_NORMATIVE_PINS']}

    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.root = Path(directory.name)
        self.freeze = 'e' * 40
        self.calls = []
        self.actual = {}
        self.ns = {'Path': Path, 'hashlib': hashlib,
                   'subprocess': SimpleNamespace(check_output=self.git_read)}
        exec(compile(ast.Module(body=copy.deepcopy(BODY), type_ignores=[]),
                     str(HERE / 'proposed_audit_ppo.py'), 'exec'), self.ns)
        for path in self.ns['EXECUTION_CONFIG_PINS']:
            if path in self.ns['RAY_BOX_EXECUTION_PINS']:
                source = Path('/tmp/mr3_p2a0_v22_launch_cmake_proposal_v1') / Path(path).name
            else:
                source = ROOT / path
            self.set_bytes(path, source.read_bytes())
        proposal = Path('/tmp/mr3_p2a0_v22_ray_box_corrector_proposal_v1')
        for path in {**self.ns['RAY_BOX_SOURCE_PINS'], **self.ns['RAY_BOX_LICENSE_PINS']}:
            source = (Path('/tmp/mr3_p2a0_v22_ray_box_corrector_native_readback_proposal_v2') / Path(path).name) if path.endswith('/mr3_ray_box_corrector.cpp') else (ROOT / path) if path.endswith('/LICENSE-BSD.TXT') else proposal / Path(path).name
            self.set_bytes(path, source.read_bytes())

    def set_bytes(self, path, raw, git=True, worktree=True):
        if git:
            self.actual[path] = raw
        if worktree:
            target = self.root / path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)

    def git_read(self, argv, cwd):
        self.assertEqual(Path(cwd), self.root)
        self.assertEqual(argv[:2], ['git', 'show'])
        revision, path = argv[2].split(':', 1)
        self.calls.append((revision, path))
        if revision == self.freeze:
            return self.actual[path]
        self.assertEqual(revision, self.ns['EXECUTION_NORMATIVE_FREEZE'])
        return self.normative[path]

    def review(self):
        return self.ns['verify_execution_configs'](self.root, self.freeze)

    def selected(self, suffix):
        return next(path for path in self.ns['RAY_BOX_EXECUTION_PINS'] if path.endswith(suffix))

    def test_exact_two_level_inverse_and_source_bindings(self):
        proof = self.review()
        self.assertEqual(set(proof), set(self.ns['EXECUTION_CONFIG_PINS']) | set(self.ns['RAY_BOX_SOURCE_PINS']) | set(self.ns['RAY_BOX_LICENSE_PINS']))
        for path in self.ns['RAY_BOX_EXECUTION_PINS']:
            self.assertEqual(proof[path]['sha256'], hashlib.sha256(self.actual[path]).hexdigest())
            self.assertEqual(proof[path]['normative_sha256'], hashlib.sha256(self.normative[path]).hexdigest())
            self.assertNotEqual(proof[path]['sha256'], proof[path]['normative_sha256'])
            self.assertIn((self.ns['EXECUTION_NORMATIVE_FREEZE'], path), self.calls)
        self.assertEqual(list(inspect.signature(self.ns['verify_execution_configs']).parameters), ['root', 'freeze'])

    def test_changed_retained_config_rejected(self):
        path = next(path for path in self.ns['EXECUTION_CONFIG_PINS'] if path.endswith('/config/nav2_params.yaml'))
        self.set_bytes(path, self.actual[path] + b'\n# changed')
        with self.assertRaisesRegex(ValueError, 'execution config source freeze/worktree'):
            self.review()

    def test_new_launch_git_and_worktree_both_required(self):
        path = self.selected('.launch.py')
        self.set_bytes(path, self.actual[path] + b'\n# changed', git=False)
        with self.assertRaisesRegex(ValueError, 'Git/worktree SHA mismatch'):
            self.review()

    def test_new_implementation_git_and_worktree_both_required(self):
        path = next(iter(self.ns['RAY_BOX_SOURCE_PINS']))
        self.set_bytes(path, self.actual[path] + b'\n// changed', worktree=False)
        with self.assertRaisesRegex(ValueError, 'ray-box implementation source freeze/worktree'):
            self.review()

    def test_changed_unrelated_launch_even_repinned_cannot_project(self):
        path = self.selected('.launch.py')
        raw = self.actual[path] + b'\n# unrelated launch behavior'
        self.set_bytes(path, raw)
        self.ns['RAY_BOX_EXECUTION_PINS'][path] = hashlib.sha256(raw).hexdigest()
        with self.assertRaisesRegex(ValueError, 'sensor diagnostic revision'):
            self.review()

    def test_changed_target_block_even_repinned_rejected(self):
        path = self.selected('/CMakeLists.txt')
        raw = self.actual[path].replace(b'CXX_STANDARD 17 CXX_STANDARD_REQUIRED', b'CXX_STANDARD 20 CXX_STANDARD_REQUIRED')
        self.assertNotEqual(raw, self.actual[path])
        self.set_bytes(path, raw)
        self.ns['RAY_BOX_EXECUTION_PINS'][path] = hashlib.sha256(raw).hexdigest()
        with self.assertRaisesRegex(ValueError, 'target addition differs'):
            self.review()

    def test_duplicate_target_block_even_repinned_rejected(self):
        path = self.selected('/CMakeLists.txt')
        raw = self.actual[path] + self.ns['RAY_BOX_CMAKE_ADDITION'].encode()
        self.set_bytes(path, raw)
        self.ns['RAY_BOX_EXECUTION_PINS'][path] = hashlib.sha256(raw).hexdigest()
        with self.assertRaisesRegex(ValueError, 'target addition differs'):
            self.review()

    def test_original_pins_not_arbitrary_caller_override(self):
        path = self.selected('.launch.py')
        self.ns['EXECUTION_CONFIG_PINS'][path] = self.ns['RAY_BOX_EXECUTION_PINS'][path]
        with self.assertRaisesRegex(ValueError, 'original execution config pins differ'):
            self.review()

    def test_normative_git_blob_independently_checked(self):
        path = self.selected('/CMakeLists.txt')
        self.normative = dict(self.normative)
        self.normative[path] += b'\n# wrong normative bytes'
        with self.assertRaisesRegex(ValueError, 'normative whole bytes'):
            self.review()

if __name__ == '__main__':
    unittest.main(verbosity=2)
