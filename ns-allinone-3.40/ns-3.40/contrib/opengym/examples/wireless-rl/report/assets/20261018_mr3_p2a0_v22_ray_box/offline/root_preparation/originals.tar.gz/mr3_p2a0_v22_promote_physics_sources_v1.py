"""Promote the sealed physics correction and exact launch/CMake increments."""
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/zhuyulab/ns3-workspace')
PKG = ROOT/'ros2_ws/ros2-multi-robot-automap/src/multi_robot'
P = Path('/tmp/mr3_p2a0_v22_ray_box_corrector_proposal_v1')
L = Path('/tmp/mr3_p2a0_v22_launch_cmake_proposal_v1')
rows = [
    (P/'mr3_ray_box_corrector.cpp',PKG/'src/mr3_ray_box_corrector.cpp','b9926b569d39dfe846483b11c6d1748f48aa9a48c561fbf8859a9dc59c7a51ca'),
    (P/'mr3_ray_box_collision.cpp',PKG/'src/mr3_ray_box_collision.cpp','d556dda57250da3680a7d5a9862416f6196cab9763e495ee75269307b87715cb'),
    (P/'include/multi_robot/mr3_ray_box_collision.hpp',PKG/'include/multi_robot/mr3_ray_box_collision.hpp','c619442d038e4bc6ea0695ada34d7074ee83d775b2137222ab9fb6bf8193879b'),
    (P/'LICENSE-BSD.TXT',PKG/'vendor/mr3_ray_box_corrector/LICENSE-BSD.TXT','fe012d262cf04a701cc856e2d12780261a60d7b17f4f7cb9cd589ff65b3f4f32'),
    (L/'CMakeLists.txt',PKG/'CMakeLists.txt','12b994e0fc0c01ec8761aaf23a7ae4722fe3026391b0622d13b842d0b425ebdc'),
    (L/'gazebo_multirobot_mapping_with_nav2.launch.py',PKG/'launch/gazebo_multirobot_mapping_with_nav2.launch.py','814f5b6256ac8badfb7f74dae21f0c66423c6e8ca7181266639d8865dc09cfd1'),
]
result=[]
for src,dst,expected in rows:
    raw=src.read_bytes()
    assert hashlib.sha256(raw).hexdigest()==expected
    before=dst.read_bytes() if dst.exists() else None
    if before is not None:
        old={'CMakeLists.txt':'170eb49947c4daa61d30f45ab8fde637aa12766182dddfda15c9ca6453d0cc0d',
             'gazebo_multirobot_mapping_with_nav2.launch.py':'6c76a4f0afbeb4c26f8c28b8e1139bbd12e5162a54ca3a193b99a156ef47a2d2'}
        assert hashlib.sha256(before).hexdigest()==old[dst.name]
    dst.parent.mkdir(parents=True,exist_ok=True)
    dst.write_bytes(raw)
    assert dst.read_bytes()==raw==src.read_bytes()
    result.append({'source':str(src),'canonical':str(dst.relative_to(ROOT)),'sha256':expected,'bytes':len(raw)})
Path('/tmp/mr3_p2a0_v22_physics_source_promotion_v1.json').write_text(json.dumps({'scope':'Source promotion only, no native; new execution gates still pending independent review and actual build/preflight.','files':result},indent=2)+'\n')
print('Promoted six sealed physics/launch/CMake/license files; no native executed')
