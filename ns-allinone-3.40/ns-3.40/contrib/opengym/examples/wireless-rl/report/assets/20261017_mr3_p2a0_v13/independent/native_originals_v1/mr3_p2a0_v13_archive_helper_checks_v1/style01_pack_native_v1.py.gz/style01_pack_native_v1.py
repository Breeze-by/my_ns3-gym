"""Losslessly select one fully closed V13 run; no canonical write or audit call."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import time

import mr3_p2a0_v13_archive_closed_v1 as CLOSED


def digest(path, decoded=False):
    checksum = hashlib.sha256()
    size = 0
    with (gzip.open if decoded else open)(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            checksum.update(block)
            size += len(block)
    return size, checksum.hexdigest()


def pack(stage):
    plan = CLOSED.load_context()
    spec = next(row for row in plan['stages'] if row['stage'] == stage)
    source = Path(spec['run_directory'])
    target = CLOSED.TEMP / (CLOSED.PREFIX + '_selected_native') / stage
    launch = CLOSED.read(CLOSED.TEMP / (CLOSED.PREFIX + '_' + stage + '_launch.json'))
    execution = CLOSED.read(CLOSED.TEMP / (
        CLOSED.PREFIX + '_' + stage + '_audit_execution_v1.json'))
    assert source.is_dir() and not source.is_symlink()
    assert launch['status'] in ('completed', 'failed')
    assert type(launch['passed']) is bool and type(execution['passed']) is bool
    assert launch['freeze'] == execution['freeze'] == CLOSED.FREEZE
    assert launch['plan_sha256'] == execution['plan_sha256'] == CLOSED.PLAN_SHA
    assert execution['all_submitted_jobs_finished'] is True
    outcome = dict(stage=stage, launch=launch, execution=execution,
                   run_directory=str(source), status='PASS' if (
                       launch['passed'] and execution['passed']) else 'FAIL')
    absence = CLOSED.closed_identities([outcome])
    CLOSED.verify_formals(outcome)
    assert not target.exists(), 'refuse overwrite: ' + str(target)
    target.mkdir(parents=True)
    started = time.monotonic()
    rows, duplicates, caches = [], [], []
    for path in sorted(source.rglob('*')):
        assert not path.is_symlink(), 'symlink is not raw original: ' + str(path)
        if not path.is_file():
            continue
        if path.suffix == '.pyc' or '__pycache__' in path.parts:
            caches.append(str(path.relative_to(source)))
            continue
        if (path.suffix == '.gz' and path.with_suffix('').is_file()
                and digest(path, True) == digest(path.with_suffix(''))):
            duplicates.append(str(path.relative_to(source)))
            continue
        relative = path.relative_to(source)
        compress = path.suffix in ('.log', '.jsonl', '.csv', '.zip') or path.name == 'resources.json'
        selected = target / (str(relative) + '.gz' if compress else relative)
        selected.parent.mkdir(parents=True, exist_ok=True)
        before = path.stat()
        with path.open('rb') as original, selected.open('xb') as output:
            if compress:
                with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as encoded:
                    shutil.copyfileobj(original, encoded, 1024 * 1024)
            else:
                shutil.copyfileobj(original, output, 1024 * 1024)
        after = path.stat()
        assert (before.st_ino, before.st_size, before.st_mtime_ns) == (
            after.st_ino, after.st_size, after.st_mtime_ns), str(path)
        raw, saved = digest(path), digest(selected)
        assert digest(selected, compress) == raw, str(selected)
        rows.append(dict(source=str(path), selected=str(selected.relative_to(target)),
                         encoding='gzip' if compress else 'identity',
                         raw_bytes=raw[0], raw_sha256=raw[1],
                         selected_bytes=saved[0], selected_sha256=saved[1]))
    manifest = dict(
        schema='mr3-p2a-selected-originals-v1', freeze=CLOSED.FREEZE, stage=stage,
        plan_sha256=CLOSED.PLAN_SHA, source=str(source),
        selection='All closed run files excluding byte-duplicate sibling gzip copies and Python '
                  'cache; originals retained in place. Lossless custody only, not a formal PASS.',
        source_files=len(rows), raw_bytes=sum(row['raw_bytes'] for row in rows),
        selected_bytes=sum(row['selected_bytes'] for row in rows), files=rows,
        duplicate_encoded_copies_not_selected=duplicates, excluded_python_cache=caches,
        original_launch_passed=launch['passed'], original_formal_passed=execution['passed'],
        saved_identity_absence=absence)
    CLOSED.new_json(target / 'manifest.json', manifest)
    CLOSED.verify_pack(stage, str(source))
    return dict(passed=True, scope='Lossless custody, not native/formal/parameter gate PASS.',
                freeze=CLOSED.FREEZE, plan_sha256=CLOSED.PLAN_SHA,
                stage=stage, original_launch_passed=launch['passed'],
                original_formal_passed=execution['passed'], source_files=len(rows),
                raw_bytes=manifest['raw_bytes'], selected_bytes=manifest['selected_bytes'],
                wall_seconds=time.monotonic() - started, manifest=str(target / 'manifest.json'),
                manifest_sha256=digest(target / 'manifest.json')[1])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=CLOSED.STAGES)
    args = parser.parse_args()
    print(json.dumps(pack(args.stage), allow_nan=False), flush=True)


if __name__ == '__main__':
    main()
