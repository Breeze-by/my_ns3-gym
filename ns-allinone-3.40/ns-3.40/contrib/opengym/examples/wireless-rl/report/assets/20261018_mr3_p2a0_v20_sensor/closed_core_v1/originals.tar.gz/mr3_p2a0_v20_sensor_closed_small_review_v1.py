#!/usr/bin/python3
"""Read only closed V20 small receipts and fresh saved PID/start identities."""
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re
import time


ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
RUN = ROOT / 'ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261018_v20_sensor_iters150'
EP = RUN / 'worker0/episode001_open_101'
OUT = Path('/tmp/mr3_p2a0_v20_sensor_closed_small_review_v1.json')
ERROR_LINES = Path('/tmp/mr3_p2a0_v20_sensor_launch_error_lines_v1.log')
FREEZE = 'b33ff70084be6419edc3d0d91a26d6db3936ff45'
inputs = {}
errors = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(path, expected_sha=None, json_lines=False, binary=False):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), str(path)
    before = path.stat()
    assert before.st_size <= 300_000, 'Refuse a large trace: ' + str(path)
    raw = path.read_bytes()
    after = path.stat()
    fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    snapshot = {k: getattr(before, k) for k in fields}
    assert snapshot == {k: getattr(after, k) for k in fields}
    digest = sha(raw)
    if expected_sha is not None:
        assert digest == expected_sha, str(path)
    inputs[str(path)] = {'bytes': len(raw), 'sha256': digest,
                         'before_stat': snapshot, 'after_stat': snapshot}
    if binary:
        return raw
    if json_lines:
        return [json.loads(row) for row in raw.splitlines()]
    return json.loads(raw)


started = time.monotonic()
execution = load('/tmp/mr3_p2a0_v20_sensor_execution_v1.json')
assert execution['freeze'] == FREEZE
plan = load(W / 'report/assets/20261018_mr3_p2a0_v20_sensor/predeclared_plan_v20_sensor.json',
            execution['plan_sha256'])
physical_ref = execution['original_physical_4step']['output']
physical = load(physical_ref['path'], physical_ref['sha256'])
assert physical['script_sha256'] == '2516e394f60eac5dd24fd66b51c4c48fc37245090eb1626ebe1c7a3a23f8bafb'
assert len(physical['episodes']) == 1
phy = physical['episodes'][0]
assert phy['directory'] == str(EP)
epoch = phy['epoch']
summary = load(EP / 'summary.json')
supervisor = load(EP / 'supervisor_shutdown.json')
supervisor_meta = load(EP / 'supervisor_metadata.json')
metadata = load(EP / 'metadata.json')
benchmark_ref = execution['benchmark_summary']
benchmark = load(benchmark_ref['path'], benchmark_ref['sha256'])
transitions_ref = execution['actual_workload']['protocol']
transitions = load(transitions_ref['path'], transitions_ref['sha256'], json_lines=True)
final_ref = execution['recorder_final']
final = load(final_ref['path'], final_ref['sha256'])
lifecycle_ref = execution['lifecycle']
lifecycle = load(lifecycle_ref['path'], lifecycle_ref['sha256'], json_lines=True)
launch = load(EP / 'launch.log', binary=True)
assert metadata['freeze'] == benchmark['freeze'] == FREEZE
assert all(x['epoch'] == epoch for x in (summary, supervisor, supervisor_meta))
assert final['epoch'] == epoch
assert len(transitions) == 5 and transitions[0]['kind'] == 'reset'
assert [r['kind'] for r in transitions[1:]] == ['step'] * 4
assert all(r['info']['epoch'] == epoch for r in transitions)
assert all(type(r['terminated']) is bool and type(r['truncated']) is bool for r in transitions)
assert all(not r['terminated'] and not r['truncated'] for r in transitions[:-1])
assert transitions[-1]['terminated'] is False and transitions[-1]['truncated'] is True
assert transitions[-1]['info']['reason'] == 'external_sampler_limit'
assert all(r['info']['dt'] == 1.0 for r in transitions[1:])
assert execution['capture_process_completed'] is True
assert final['capture_completed'] is True and final['normal_stop'] is True
assert final['failed'] is False
assert execution['benchmark_returncode'] == execution['recorder_returncode'] == 0
assert execution['errors'] == []
assert supervisor['forced_shutdown'] is False and supervisor['failed_sample'] is False
assert supervisor['remaining_owned_processes'] == supervisor['remaining_owned_zombies'] == []
assert summary['native_failures'] == summary['failures'] == []
assert summary['launch_returncode'] == supervisor['worker_returncode'] == 0
assert phy['closure']['passed'] is True and phy['closure']['errors'] == []

kind_rows = {r['kind']: r for r in lifecycle}
sequence = ['recorder_ready_received', 'benchmark_started_after_recorder_ready',
            'benchmark_naturally_closed', 'exclusive_stop_marker_after_benchmark_closed',
            'recorder_naturally_closed', 'capture_process_result']
walls = [kind_rows[k]['wall_monotonic_ns'] for k in sequence]
assert walls == sorted(walls) and len(set(walls)) == len(walls)

saved = {}


def remember(identity, source):
    pid, ticks = identity['pid'], identity['start_ticks']
    assert type(pid) is int and type(ticks) is int and pid > 0 and ticks > 0
    saved.setdefault((pid, ticks), set()).add(source)


for identity in supervisor['owned_processes_seen']:
    remember(identity, 'supervisor_shutdown.owned_processes_seen')
remember(supervisor_meta['worker_identity'], 'supervisor_metadata.worker_identity')
for key, expected in [('parent_identity', (3521739, 401856383)),
                      ('recorder_identity', (3521789, 401856477)),
                      ('benchmark_identity', (3521846, 401856617))]:
    identity = execution[key]
    assert (identity['pid'], identity['start_ticks']) == expected
    remember(identity, 'execution.' + key)
for row in lifecycle:
    if 'identity' in row:
        remember(row['identity'], 'lifecycle.' + row['kind'])

identities = []
for (pid, ticks), sources in sorted(saved.items()):
    path = Path('/proc') / str(pid) / 'stat'
    try:
        raw = path.read_text()
    except FileNotFoundError:
        raw = None
    current_ticks = int(raw.rsplit(')', 1)[1].split()[19]) if raw is not None else None
    present = current_ticks == ticks
    if present:
        errors.append('Saved owned identity still present: ' + str((pid, ticks)))
    identities.append({'pid': pid, 'saved_start_ticks': ticks, 'sources': sorted(sources),
                       'current_stat_raw': raw, 'current_start_ticks': current_ticks,
                       'same_saved_identity_present': present})

lines = launch.splitlines(keepends=True)
starts, exits, logged_errors = [], [], []
for number, row in enumerate(lines, 1):
    text = row.decode('utf-8')
    start_match = re.search(r'process started with pid \[(\d+)\]', text)
    exit_match = re.search(r'process has finished cleanly \[pid (\d+)\]', text)
    if start_match:
        starts.append({'line': number, 'pid': int(start_match.group(1))})
    if exit_match:
        exits.append({'line': number, 'pid': int(exit_match.group(1))})
    if '[ERROR]' in text or '[FATAL]' in text or 'process has died' in text:
        logged_errors.append({'line': number, 'raw_utf8': text, 'raw_sha256': sha(row)})
assert len(starts) == len(exits) == 39
assert len({r['pid'] for r in starts}) == 39
assert {r['pid'] for r in starts} == {r['pid'] for r in exits}
assert {r['pid'] for r in starts} <= {pid for pid, _ in saved}
with ERROR_LINES.open('xb') as stream:
    stream.write(b''.join(lines[r['line'] - 1] for r in logged_errors))

physical_projection = {}
for robot in ('tb1', 'tb2', 'tb3'):
    item = phy['robots'][robot]
    assert item['errors'] == []
    assert all(type(value) is int and value == 0 for value in item['bound_violation_counts'].values())
    assert item['eligible_stop_events'] == item['eligible_cancel_stop_events'] == 0
    assert item['physical_evidence_complete'] is False
    physical_projection[robot] = {key: item[key] for key in
        ('raw_unique_odom_samples', 'task_odom_samples', 'maximum_planar_speed_task',
         'maximum_angular_norm_task', 'maximum_raw_odom_chord_speed_task',
         'maximum_task_source_gap_ns', 'errors', 'bound_violation_counts',
         'linear_zero_events', 'eligible_stop_events', 'credited_sampled_stop_events',
         'native_cancel_events', 'eligible_cancel_stop_events',
         'credited_cancel_stop_events', 'cancel_stop_responses', 'stop_responses',
         'physical_evidence_complete')}

prior_paths = [Path('/tmp/mr3_p2a0_v18_baseline_execution.json'),
               Path('/tmp/mr3_p2a0_v19_baseline_execution.json'),
               Path('/tmp/mr3_p2a0_v19_iters150_execution.json')]
prior = [(p, load(p)) for p in prior_paths]
amounts = [Decimal(str(row['native_wall_seconds'])) for _, row in prior]
previous = sum(amounts, Decimal(0))
assert previous == Decimal(str(plan['budget']['previous_v18_v19_charged_wall_seconds']))
current = Decimal(str(execution['native_wall_seconds']))
ceiling = Decimal(str(plan['budget']['cumulative_diagnostic_ceiling_seconds']))
assert current <= Decimal(str(plan['budget']['max_native_launcher_wall_seconds']))
total = previous + current

for name, binding in inputs.items():
    path = Path(name)
    raw = path.read_bytes()
    after = path.stat()
    assert sha(raw) == binding['sha256']
    assert binding['before_stat'] == {k: getattr(after, k) for k in binding['before_stat']}

result = {
    'schema': 'mr3-v20-sensor-closed-small-independent-review-v1',
    'freeze': FREEZE, 'epoch': epoch, 'inputs': inputs,
    'source_sha256': sha(Path(__file__).read_bytes()),
    'scope': 'Closed small objects and fresh /proc identity checks only; no raw physics/CDR scan or formal re-execution.',
    'review_integrity_passed': not errors, 'errors': errors,
    'workload': {'resets': 1, 'returned_steps': 4, 'saved_api_records': 5,
                 'actual_dt_sec': [r['info']['dt'] for r in transitions[1:]],
                 'last_terminated': False, 'last_truncated': True,
                 'last_reason': 'external_sampler_limit',
                 'benchmark_returncode': 0, 'recorder_returncode': 0,
                 'benchmark_reported_passed': benchmark['passed'],
                 'capture_process_completed': execution['capture_process_completed'],
                 'strict_native_closure_passed': phy['closure']['passed'],
                 'e61c_32step_status': execution['e61c']['status']},
    'lifecycle_order': [{'kind': k, 'wall_monotonic_ns': kind_rows[k]['wall_monotonic_ns']}
                        for k in sequence],
    'fresh_saved_identity_union': {'count': len(identities), 'all_gone': not errors,
                                   'identities': identities},
    'native_exit_evidence': {'started': starts, 'clean_exits': exits,
                              'all_39_pid_sets_equal': True,
                              'all_started_pid_have_saved_start_identity': True,
                              'worker_returncode': supervisor['worker_returncode'],
                              'launch_returncode': summary['launch_returncode'],
                              'forced_shutdown': supervisor['forced_shutdown'],
                              'failed_sample': supervisor['failed_sample'],
                              'native_failures': summary['native_failures'],
                              'launch_error_lines_retained': logged_errors,
                              'selected_error_bytes_path': str(ERROR_LINES),
                              'selected_error_bytes_sha256': sha(ERROR_LINES.read_bytes())},
    'original_physical': {'passed': physical['passed'], 'unchanged_criteria': physical['criteria'],
                         'robots': physical_projection,
                         'interpretation': 'False for missing meaningful A/B stopping excitation in all three robots; original report errors and sampled bound-violation counts are zero. This does not demonstrate stopping response or repair.'},
    'accounting': {'native_runs': [
        {'receipt': str(path), 'native_wall_seconds': row['native_wall_seconds'],
         'original_diagnostic_passed': row['passed']}
        for path, row in prior] + [
        {'receipt': '/tmp/mr3_p2a0_v20_sensor_execution_v1.json',
         'native_wall_seconds': execution['native_wall_seconds'],
         'original_capture_process_passed': execution['passed']}],
        'native_attempt_count': 4, 'version_count': 3,
        'previous_v18_v19_exact_decimal_seconds': str(previous),
        'v20_native_exact_decimal_seconds': str(current),
        'cumulative_exact_decimal_seconds': str(total),
        'ceiling_exact_decimal_seconds': str(ceiling),
        'remaining_exact_decimal_seconds': str(ceiling - total),
        'charging_scope': 'Native launcher wall only. Recorder process/readers/CPU costs not silently added as native or used to erase any failed attempt.'},
    'limits': ['V18 original admission failure and V19 contrast physicalFalse remain preserved.',
               'V20 capture completion is not old32step/e61c/P2A.0 matrix/PPO/95% success or solver150 selection.',
               'Two real bt_navigator halt ERROR log lines remain even though all39 native processes exited cleanly.'],
    'wall_seconds': time.monotonic() - started
}
with OUT.open('x') as stream:
    json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False)
    stream.write('\n')
print(json.dumps({'output': str(OUT), 'sha256': sha(OUT.read_bytes()),
                  'review_integrity_passed': result['review_integrity_passed'],
                  'saved_identity_count': len(identities), 'all_saved_identities_gone': not errors,
                  'native_clean_exits': len(exits), 'preserved_launch_error_lines': len(logged_errors),
                  'physical_passed': physical['passed'],
                  'native_cumulative_exact_decimal_seconds': str(total),
                  'remaining_exact_decimal_seconds': str(ceiling - total)}, sort_keys=True))
