"""Artificial V4 lifecycle and per-call G720 V3 differential; no native inputs."""
import ast
import copy
import hashlib
import json
import math
from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import MagicMock,patch

from mr3_learning import benchmark as b,supervisor
from .test_reach_outward_cancel_v3_producer import Fixture
ROOT=Path('/home/zhuyulab/ns3-workspace')
HERE=Path(__file__).resolve().parents[9]
# Locate this explicit private artifact; no caller-controlled historical source.
BASE=next(p for p in Path(__file__).resolve().parents if (p/'golden/benchmark_G720.py.rawbytes').is_file())
G='720cd4e194eeb2e9f14a86ed9204f6110d72173b'
REL='ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/mr3_learning/benchmark.py'
GOLD=(BASE/'golden/benchmark_G720.py.rawbytes').read_bytes()
assert hashlib.sha256(GOLD).hexdigest()=='72360f3a786635a02e13d83d9afe9035afa556047e2ea50fe7c71d55c62b9e7b'
assert subprocess.check_output(['git','show',G+':'+REL],cwd=ROOT)==GOLD
NAMES={'_probe_v2_number','_probe_nonapproaching_goal_action','_probe_goal_order',
       'probe_action_reach_v3','record_probe_reach_v3_submission','finish_probe_reach_v3'}
old={'math':math}
tree=ast.parse(GOLD);nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in NAMES]
assert len(nodes)==len(NAMES)
exec(compile(ast.Module(body=nodes,type_ignores=[]),'G720:'+REL,'exec'),old)
EVENTS=[]

def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()

def outcome(fn,*args):
    try:return {'return':fn(*args),'error':None}
    except Exception as e:return {'return':None,'error':{'type':type(e).__name__,'message':str(e)}}

def compare(test,method,arguments,left,right,label):
    a=outcome(old[method],*copy.deepcopy(arguments),left)
    z=outcome(getattr(b,method),*copy.deepcopy(arguments),right)
    EVENTS.append(dict(label=label,method=method,old_outcome=a,new_outcome=z,
        old_diagnostics_sha256=hashlib.sha256(canon(left)).hexdigest(),new_diagnostics_sha256=hashlib.sha256(canon(right)).hexdigest(),
        whole_canonical_JSON_equal=canon(left)==canon(right)))
    test.assertEqual(a,z,label);test.assertEqual(canon(left),canon(right),label)
    return a

def finish_cancels(f,t):
    f.advance(t+.1);pending=[(n,s.goal_id) for n,s in f.dispatcher.states.items() if s.goal_id is not None and s.cancel_requested]
    for n,g in pending:f.dispatcher.on_cancel_response(n,g,True,t+.1)
    f.advance(t+.2)
    for n,g in pending:f.dispatcher.on_result(n,g,'CANCELED',t+.2)


def accept(f,when):
    f.advance(when)
    for n,s in f.dispatcher.states.items():
        if s.goal_id is not None and s.phase=='accepting':f.dispatcher.on_accept(n,s.goal_id,True,when)


class ProbeV4Tests(unittest.TestCase):
    def test_V3_each_call_matches_actual_G720_returns_full_JSON_and_errors(self):
        for variant in ('positive','zero','none','late_source','stale','natural_success','aborted','external_cancel'):
            with self.subTest(variant=variant):
                f=Fixture();left={};right={}
                for t in range(32):
                    if t==3 and variant in ('natural_success','aborted','external_cancel'):
                        f.complete_all({'natural_success':'SUCCEEDED','aborted':'ABORTED','external_cancel':'CANCELED'}[variant],2.5)
                    path=None if variant=='none' or t==0 else (0. if variant=='zero' else .1) if t<6 else .2 if t<14 else .25 if t<19 else .4
                    snap=f.snapshot(t,path=path,complete=t!=0 and variant!='none',speed=.08 if t in (6,19) else 0.,
                        path_source=.05 if variant=='late_source' and t==1 else None)
                    if variant=='stale' and t==6:snap['robots'][0]['fresh']=False
                    if t==2:snap['robots'][0]['w']=.2
                    snap['digest']=hashlib.sha256(canon({k:v for k,v in snap.items() if k!='digest'})).hexdigest()
                    a=compare(self,'probe_action_reach_v3',[snap],left,right,variant+':choose'+str(t));self.assertIsNone(a['error'])
                    info=f.apply(snap,a['return'])
                    a=outcome(old['record_probe_reach_v3_submission'],left,copy.deepcopy(info));z=outcome(b.record_probe_reach_v3_submission,right,copy.deepcopy(info))
                    EVENTS.append(dict(label=variant+':record'+str(t),method='record_probe_reach_v3_submission',old_outcome=a,new_outcome=z,
                        whole_canonical_JSON_equal=canon(left)==canon(right),old_diagnostics_sha256=hashlib.sha256(canon(left)).hexdigest(),new_diagnostics_sha256=hashlib.sha256(canon(right)).hexdigest()))
                    self.assertEqual(a,z);self.assertEqual(canon(left),canon(right))
                    if t in (0,13):accept(f,t+.1)
                    if t in (6,19):finish_cancels(f,t)
                last=f.snapshot(32,path=None if variant=='none' else .4,complete=variant!='none')
                compare(self,'finish_probe_reach_v3',[last],left,right,variant+':finish')

    def test_V3_pending_malformed_not_submitted_and_boundary_errors_match_G720(self):
        f=Fixture();s=f.snapshot(0,path=None,complete=False);left={};right={}
        compare(self,'probe_action_reach_v3',[s],left,right,'pending first')
        compare(self,'probe_action_reach_v3',[s],left,right,'pending duplicate')
        for variant in ('not_submitted','bad_command','badflag'):
            l=copy.deepcopy(left);r=copy.deepcopy(right)
            info={'action_submitted':False} if variant=='not_submitted' else {'command':{}} if variant=='bad_command' else {'action_submitted':0}
            a=outcome(old['record_probe_reach_v3_submission'],l,copy.deepcopy(info));z=outcome(b.record_probe_reach_v3_submission,r,copy.deepcopy(info))
            self.assertEqual(a,z);self.assertEqual(canon(l),canon(r));EVENTS.append(dict(label=variant,method='record',old_outcome=a,new_outcome=z,whole_canonical_JSON_equal=canon(l)==canon(r)))
        compare(self,'finish_probe_reach_v3',[f.snapshot(31,path=0.)],copy.deepcopy(left),copy.deepcopy(right),'bad final boundary')
        invalid=copy.deepcopy(s);invalid['task_elapsed_sec']=float('nan')
        compare(self,'probe_action_reach_v3',[invalid],{},{} ,'invalid clock')

    def test_old_V2_three_functions_remain_literal_G720_bytes(self):
        current=Path(b.__file__).read_text();ct=ast.parse(current);gt=ast.parse(GOLD)
        for name in ('probe_action_reach_v2','record_probe_reach_v2_submission','finish_probe_reach_v2'):
            a=next(n for n in ct.body if isinstance(n,ast.FunctionDef) and n.name==name)
            z=next(n for n in gt.body if isinstance(n,ast.FunctionDef) and n.name==name)
            self.assertEqual(ast.get_source_segment(current,a),ast.get_source_segment(GOLD.decode(),z))

    def test_V4_legal_KEEP0_then_GOAL1_with_real_once_reference_and_actor_GOAL0_retained(self):
        f=Fixture();d={};s=f.snapshot(0,path=None,complete=False)
        self.assertTrue(any(any(row[:8]) for row in s['per_robot_action_mask']))
        self.assertEqual(b.probe_action_reach_v4(s,d),888)
        state=d['reach_v4_stimulus'];self.assertNotIn('initial_keep_submission',state)
        self.assertTrue(all(x=={} for x in state['rounds']['initial'].values()))
        info=f.apply(s,888);b.record_probe_reach_v4_submission(d,info)
        self.assertEqual(state['initial_keep_submission']['command_id'],info['command']['command_id'])
        self.assertEqual(state['initial_keep_submission']['observation_digest'],s['digest'])
        s=f.snapshot(1,path=0.);action=b.probe_action_reach_v4(s,d)
        self.assertTrue(all(c<8 for c in (action//100,action//10%10,action%10)))
        self.assertTrue(s['joint_action_mask'][action]);self.assertNotIn('reach_v3_stimulus',d)

    def test_V4_complete32_two_round_six_goals_and_original_wait_commitment(self):
        f=Fixture();d={};actions=[]
        for t in range(32):
            path=None if t==0 else .1 if t<7 else .2 if t<14 else .25 if t<19 else .4
            s=f.snapshot(t,path=path,complete=t!=0,speed=.08 if t in (6,7,19) else 0.)
            a=b.probe_action_reach_v4(s,d);actions.append(a);b.record_probe_reach_v4_submission(d,f.apply(s,a))
            if t in (1,13):accept(f,t+.1)
            if t in (7,19):finish_cancels(f,t)
        b.finish_probe_reach_v4(f.snapshot(32,path=.4),d)
        state=d['reach_v4_stimulus'];self.assertTrue(state['coverage_passed']);self.assertEqual(actions[0],888)
        self.assertEqual(actions[6],888);self.assertEqual(actions[7],999)
        self.assertEqual(sum('goal_command_id' in s for r in state['rounds'].values() for s in r.values()),6)
        self.assertTrue(all(s['baseline_capture_count']==1 for r in state['rounds'].values() for s in r.values()))
        self.assertEqual(len(state['decisions']),32)

    def test_V4_initial_illegal_duplicate_or_not_submitted_KEEP_fails_without_relabel(self):
        f=Fixture();s=f.snapshot(0,path=None,complete=False);bad=copy.deepcopy(s);bad['joint_action_mask'][888]=False
        with self.assertRaisesRegex(ValueError,'not legal'):b.probe_action_reach_v4(bad,{})
        d={};b.probe_action_reach_v4(s,d);b.record_probe_reach_v4_submission(d,{'action_submitted':False})
        self.assertNotIn('initial_keep_submission',d['reach_v4_stimulus'])
        with self.assertRaisesRegex(ValueError,'real task0 KEEP'):b.probe_action_reach_v4(f.snapshot(1,path=0.),d)
        f=Fixture();s=f.snapshot(0,path=None,complete=False);d={};b.probe_action_reach_v4(s,d);b.record_probe_reach_v4_submission(d,f.apply(s,888))
        with self.assertRaisesRegex(ValueError,'only be planned once'):b.probe_action_reach_v4(s,d)
        for invalid in (True,2,5,'4',None):
            with self.assertRaises(ValueError):b._probe_reach_version_key(invalid)

    def test_V4_same_short_natural_goal_still_fails_coverage_without_retry(self):
        f=Fixture();d={}
        for t in range(32):
            if t==4:f.complete_all('SUCCEEDED',3.5)
            s=f.snapshot(t,path=None if t==0 else .1,complete=t!=0,speed=.08 if t in (2,3) else 0.)
            a=b.probe_action_reach_v4(s,d);b.record_probe_reach_v4_submission(d,f.apply(s,a))
            if t==1:accept(f,1.1)
        with self.assertRaisesRegex(ValueError,'coverage unavailable'):b.finish_probe_reach_v4(f.snapshot(32,path=.1),d)
        self.assertEqual(sum(e['type']=='send_goal' for e in f.events),3)
        self.assertTrue(all('wait_command_id' not in s for s in d['reach_v4_stimulus']['rounds']['initial'].values()))

    def test_fixed_V4_token_is_Reach_only_and_real_Supervisor_RPC_forwards_it(self):
        token=supervisor.PREPARATION_PROBE_REACH_V4;supervisor.validate_preparation_profile('mr3-reach-v1',token)
        with self.assertRaises(ValueError):supervisor.validate_preparation_profile('legacy',token)
        with tempfile.TemporaryDirectory() as tmp:
            su=supervisor.Supervisor(run_id='v4-toy',output_root=tmp,safety_contract='mr3-reach-v1',preparation_probe_version=token)
            calls=[];process=SimpleNamespace(pid=99999999,stdin=SimpleNamespace(fileno=lambda:0),stdout=SimpleNamespace(fileno=lambda:0))
            def rpc(op,**request):calls.append((op,request));return {'snapshot':{'epoch':su.episode.epoch}}
            with patch.object(su,'close'),patch.object(su,'_rpc',side_effect=rpc),patch.object(supervisor.subprocess,'Popen',return_value=process),patch.object(supervisor,'process_identity',return_value={'pid':99999999,'start_ticks':1}),patch.object(supervisor,'JsonLinePeer'),patch.object(supervisor.threading,'Thread',return_value=MagicMock()),patch.object(supervisor,'ros_environment',return_value={}):su.reset('open',101)
            try:self.assertEqual(calls[0][1]['preparation_probe_version'],token);self.assertEqual(calls[0][1]['quantum_steps'],20)
            finally:su.episode.output.close()


if __name__=='__main__':unittest.main()
