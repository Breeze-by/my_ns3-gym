// Finite Gazebo SDK lifecycle probe: no Run, Step, ROS, robot spawn, or plugin load.
#include <gazebo/gazebo.hh>
#include <gazebo/common/Events.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/physics/ode/ODEPhysics.hh>
#include <nlohmann/json.hpp>
#include <sdf/sdf.hh>
#include <iostream>
#include <stdexcept>

using Json = nlohmann::json;

Json Snapshot(const gazebo::physics::WorldPtr &world,
  const std::string &phase, bool counterInitialized)
{
  Json row{{"phase", phase}, {"world_lookup_succeeded", bool(world)},
    {"world_iterations_available", counterInitialized},
    {"world_iterations", nullptr}};
  if (!world) return row;
  const auto physics = world->Physics();
  const auto ode = boost::dynamic_pointer_cast<gazebo::physics::ODEPhysics>(physics);
  std::size_t sensorCount = 0;
  for (const auto &model : world->Models())
    for (const auto &link : model->GetLinks()) sensorCount += link->GetSensorCount();
  row["world"] = world->Name();
  row["world_load_completed"] = world->IsLoaded();
  row["world_sensors_initialized"] = world->SensorsInitialized();
  row["world_running_getter"] = world->Running();
  row["world_clock_ns"] = static_cast<std::int64_t>(world->SimTime().sec) *
    1000000000LL + world->SimTime().nsec;
  row["model_sensor_count"] = sensorCount;
  row["physics_available"] = bool(physics);
  row["physics_type"] = physics ? Json(physics->GetType()) : Json(nullptr);
  row["native_ode_world_available"] = bool(ode && ode->GetWorldId());
  if (ode && ode->GetWorldId())
    row["native_ode_quickstep_iterations"] = dWorldGetQuickStepNumIterations(ode->GetWorldId());
  if (physics) row["physics_max_step_size_sec"] = physics->GetMaxStepSize();
  // This is the only Iterations read: caller invokes it after init_world returns.
  if (counterInitialized) row["world_iterations"] = world->Iterations();
  return row;
}

int main(int argc, char **argv)
{
  if (argc != 2) return 2;
  bool setup = false;
  try
  {
    if (!gazebo::setupServer(std::vector<std::string>{"--minimal_comms"}))
      throw std::runtime_error("SDK setupServer failed");
    setup = true;
    std::size_t events = 0;
    auto created = gazebo::event::Events::ConnectWorldCreated([&events](const std::string &name)
    {
      ++events;
      std::cout << Snapshot(gazebo::physics::get_world(name),
        "world_created_during_load_before_world_init", false).dump() << std::endl;
    });
    sdf::SDFPtr document(new sdf::SDF);
    if (!sdf::init(document) || !sdf::readFile(argv[1], document))
      throw std::runtime_error("actual world SDF load failed");
    auto world = gazebo::physics::create_world();
    gazebo::physics::load_world(world, document->Root()->GetElement("world"));
    std::cout << Snapshot(world, "load_returned_before_world_init", false).dump() << std::endl;
    gazebo::physics::init_world(world);
    const auto initialized = Snapshot(world, "world_init_returned_no_run_no_step", true);
    std::cout << initialized.dump() << std::endl;
    if (events != 1 || initialized.at("world_iterations") != 0 ||
        initialized.at("world_clock_ns") != 0)
      throw std::runtime_error("finite SDK lifecycle evidence invalid");
    created.reset();
    world.reset();
    gazebo::shutdown();
    setup = false;
    std::cout << Json({{"phase", "fini_returned"}, {"world_created_events", events},
      {"run_calls", 0}, {"step_calls", 0}, {"robot_spawn_calls", 0}, {"ros_calls", 0}}).dump()
      << std::endl;
    return 0;
  }
  catch (const std::exception &error)
  {
    std::cerr << error.what() << std::endl;
    if (setup) gazebo::shutdown();
    return 1;
  }
}
