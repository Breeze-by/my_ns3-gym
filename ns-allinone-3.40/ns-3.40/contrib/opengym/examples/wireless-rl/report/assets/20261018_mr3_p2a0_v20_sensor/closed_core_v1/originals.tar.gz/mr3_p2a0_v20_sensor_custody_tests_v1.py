"""Tiny current-schema entry fixtures; original32MiB codec tests are not repeated."""
import contextlib
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch


HELPER_PATH = Path('/tmp/mr3_p2a0_v20_sensor_pack_closed_v1.py')
SPEC = importlib.util.spec_from_file_location('closed_sensor_custody', HELPER_PATH)
HELPER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(HELPER)
ENV = {'PATH': '/usr/bin:/bin', 'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1',
       'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'TZ': 'UTC'}
PREFIX = 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v20_sensor'


def store(path, value):
    raw = (json.dumps(value) + '\n').encode()
    path.write_bytes(raw)
    return {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest()}


class SensorCustodyTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory(prefix='mr3_v20_custody_cpu_')
        self.addCleanup(directory.cleanup)
        self.root = Path(directory.name)
        self.native = self.root / 'mr3_p2a0_20261018_v20_sensor_iters150'
        self.sensor = self.root / 'mr3_p2a0_v20_sensor_capture_v1'
        self.native.mkdir()
        self.sensor.mkdir()
        episode = self.native / 'worker0/episode001_open_101'
        episode.mkdir(parents=True)
        store(episode / 'metadata.json', {'freeze': 'b' * 40, 'epoch': 'cpu-only'})
        (episode / 'transitions.jsonl').write_bytes(b'{"kind":"reset"}\n')
        store(self.sensor / 'final.json', {'epoch': 'cpu-only', 'capture_completed': True,
                                         'normal_stop': True, 'failed': False})
        original_gzip = gzip.compress(b'original gzip bytes must remain gzip bytes\n', mtime=0)
        (self.sensor / 'original.gz').write_bytes(original_gzip)
        self.execution = {
            'schema': 'mr3-startup-sensor-execution-v1', 'status': 'completed',
            'stage': 'iters150', 'passed': True, 'errors': [], 'freeze': 'b' * 40,
            'plan_sha256': 'a' * 64, 'native_wall_seconds': .1,
            'benchmark_summary': store(self.native / 'benchmark_summary.json',
                                       {'freeze': 'b' * 40, 'passed': True}),
            'recorder_final': {'path': str(self.sensor / 'final.json'),
                               'sha256': hashlib.sha256((self.sensor / 'final.json').read_bytes()).hexdigest()},
            'actual_workload': {'requested_steps': 4, 'actual_returned_steps': 4,
                                'actual_saved_api_records': 5,
                                'protocol': {'path': str(episode / 'transitions.jsonl')}},
            'original_physical_4step': {'label': 'original_physical_4step', 'passed': False,
                                        'returncode': 1, 'errors': [],
                                        'output': store(self.root / 'physical.json', {'passed': False})},
            'original_physical_passed': False, 'strict_native_closure_passed': True,
            'e61c': {'status': 'SKIP', 'reason': 'Actual ordinary4 is not32step formal.'}}

    def invoke(self, kind):
        execution_path = self.root / ('execution_' + kind + '.json')
        store(execution_path, self.execution)
        source = self.native if kind == 'native' else self.sensor
        target = self.root / ('selected_' + kind)
        suffix = '/native/iters150' if kind == 'native' else '/sensor_capture'
        argv = [str(HELPER_PATH), '--source', str(source), '--target', str(target),
                '--execution', str(execution_path), '--source-kind', kind,
                '--prospective-prefix', PREFIX + suffix]
        with patch('sys.argv', argv), patch.dict(os.environ, ENV, clear=True), \
                contextlib.redirect_stdout(io.StringIO()):
            HELPER.main()
        return json.loads((target / 'manifest.json').read_bytes()), target

    def test_both_roots_keep_physical_false_fourstep_skip_and_original_gzip(self):
        for kind in ('native', 'sensor_capture'):
            result, target = self.invoke(kind)
            self.assertTrue(result['passed'])  # Byte custody only.
            self.assertFalse(result['original_physical_passed'])
            self.assertFalse(result['closed_consumer_artifacts'][0]['original_passed'])
            self.assertTrue(result['strict_native_closure_passed'])
            self.assertEqual(result['actual_workload_original']['actual_saved_api_records'], 5)
            self.assertEqual(result['e61c_original']['status'], 'SKIP')
            if kind == 'sensor_capture':
                row = next(row for row in result['files'] if row['relative_path'] == 'original.gz')
                actual = b''.join(gzip.decompress((target / piece['selected']).read_bytes())
                                  for piece in row['parts'])
                self.assertEqual(actual, (self.sensor / 'original.gz').read_bytes())

    def test_running_execution_rejected_before_inventory(self):
        self.execution['status'] = 'native_running'
        with patch.object(HELPER, 'inventory') as inventory:
            with self.assertRaises(AssertionError):
                self.invoke('native')
            inventory.assert_not_called()

    def test_recorder_final_digest_mismatch_rejected_before_inventory(self):
        self.execution['recorder_final']['sha256'] = '0' * 64
        with patch.object(HELPER, 'inventory') as inventory:
            with self.assertRaises(AssertionError):
                self.invoke('sensor_capture')
            inventory.assert_not_called()

    def test_epoch_mismatch_rejected_before_inventory(self):
        self.execution['recorder_final'] = store(self.sensor / 'final.json', {'epoch': 'wrong'})
        with patch.object(HELPER, 'inventory') as inventory:
            with self.assertRaises(AssertionError):
                self.invoke('native')
            inventory.assert_not_called()


if __name__ == '__main__':
    unittest.main(verbosity=2)
