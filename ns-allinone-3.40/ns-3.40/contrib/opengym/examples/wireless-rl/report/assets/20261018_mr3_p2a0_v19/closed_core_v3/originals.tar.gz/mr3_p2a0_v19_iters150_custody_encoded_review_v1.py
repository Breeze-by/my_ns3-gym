"""One-pass encoded-only custody review; no raw decode or native audit."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import os
import sys
import time

TARGET = Path('/tmp/mr3_p2a0_v19_selected_native_v1/iters150')
OUTPUT = Path('/tmp/mr3_p2a0_v19_iters150_custody_encoded_review_v1.json')
FREEZE = '72d0465ddd1bbee09af117cfd9d89b7e729f8578'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(value):
    return [value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns]


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def main():
    start = time.monotonic()
    small = {}

    def read(path, expected=None):
        path = Path(path)
        before = path.stat()
        raw = path.read_bytes()
        assert identity(before) == identity(path.stat())
        value = {'sha256': digest(raw), 'bytes': len(raw), 'stat_identity': identity(before)}
        assert expected is None or value['sha256'] == expected
        small[str(path)] = value
        return json.loads(raw)

    manifest = read(TARGET / 'manifest.json')
    configuration = read(TARGET / 'helper_configuration.json')
    assert manifest['schema'] == 'mr3-v19-native-byte-custody-v1'
    assert manifest['passed'] is True and manifest['stage'] == 'iters150'
    assert manifest['freeze'] == FREEZE
    assert manifest['no_new_formal_or_native'] is True
    assert manifest['no_missing_credit_filled'] is True
    assert manifest['source_statfinal_inventory_exact'] is True
    assert canonical(configuration) == canonical(manifest['helper_configuration'])
    assert manifest['source_files'] == 494 and type(manifest['source_files']) is int
    assert manifest['selected_parts'] == 565 and type(manifest['selected_parts']) is int
    assert manifest['selected_bytes'] == 194283176
    assert manifest['raw_bytes'] == 2588450699
    assert manifest['native_wall_seconds_original'] == 722.410109739285
    execution = read(manifest['original_execution']['source'],
                     manifest['original_execution']['sha256'])
    benchmark = read(manifest['original_benchmark_summary']['source'],
                     manifest['original_benchmark_summary']['sha256'])
    assert execution['freeze'] == manifest['freeze'] and execution['stage'] == 'iters150'
    assert execution['plan_sha256'] == manifest['plan_sha256']
    assert execution['native_wall_seconds'] == manifest['native_wall_seconds_original']
    assert execution['passed'] is manifest['original_stage_passed'] is True
    assert benchmark['passed'] is manifest['original_benchmark_passed'] is True
    assert canonical(execution['diagnostic_consumers']) == canonical(
        manifest['original_diagnostic_consumers'])
    assert canonical(execution['errors']) == canonical(manifest['original_execution_errors']) == '[]'
    original_verdicts = {}
    for artifact in manifest['closed_consumer_artifacts']:
        report = read(artifact['source'], artifact['sha256'])
        assert artifact['available'] is True
        assert small[artifact['source']]['bytes'] == artifact['bytes']
        assert report['passed'] is artifact['original_passed']
        original_verdicts[artifact['label']] = report['passed']
    assert original_verdicts == {'observer_1ms': True, 'original_physical': False}

    file_paths, selected_paths = set(), set()
    total_raw = 0
    total_encoded = 0
    part_count = 0
    encoded_records = []
    source_encoding_counts = {}
    for entry in manifest['files']:
        relative = PurePosixPath(entry['relative_path'])
        assert not relative.is_absolute() and '..' not in relative.parts
        assert str(relative) not in file_paths
        file_paths.add(str(relative))
        assert Path(entry['source']) == Path(manifest['source']) / str(relative)
        assert type(entry['raw_bytes']) is int and entry['raw_bytes'] >= 0
        assert entry['source_stat_initial'] == entry['source_stat_final']
        assert entry['raw_bytes'] == entry['source_stat_initial'][2]
        parts = entry['parts']
        assert type(parts) is list and len(parts) >= 1
        expected_encoding = 'gzip' if len(parts) == 1 else 'ordered_gzip_raw_byte_chunks'
        assert entry['encoding'] == expected_encoding
        source_encoding_counts[expected_encoding] = source_encoding_counts.get(expected_encoding, 0) + 1
        offset = 0
        for index, part in enumerate(parts):
            assert type(part['index']) is int and part['index'] == index
            assert type(part['raw_offset']) is int and part['raw_offset'] == offset
            assert type(part['raw_bytes']) is int and 0 <= part['raw_bytes'] <= 33554432
            if index < len(parts) - 1:
                assert part['raw_bytes'] == 33554432
            offset += part['raw_bytes']
            assert part['encoding'] == 'gzip'
            selected = PurePosixPath(part['selected'])
            assert not selected.is_absolute() and '..' not in selected.parts
            assert str(selected) not in selected_paths and selected.parts[0] == 'blobs'
            selected_paths.add(str(selected))
            assert part['prospective_canonical'] == manifest['prospective_prefix'] + '/' + str(selected)
            path = TARGET / str(selected)
            assert not path.is_symlink()
            before = path.stat()
            h = hashlib.sha256()
            size = 0
            first = None
            with path.open('rb') as stream:
                assert identity(before) == identity(os.fstat(stream.fileno()))
                while True:
                    block = stream.read(1024 * 1024)
                    if not block:
                        break
                    if first is None:
                        first = block[:3]
                    h.update(block)
                    size += len(block)
                after_fd = os.fstat(stream.fileno())
            assert identity(before) == identity(after_fd) == identity(path.stat())
            assert first == b'\x1f\x8b\x08'
            assert size == part['selected_bytes'] and type(part['selected_bytes']) is int
            assert h.hexdigest() == part['selected_sha256']
            total_encoded += size
            part_count += 1
            encoded_records.append({'path': str(path), 'bytes': size, 'sha256': h.hexdigest(),
                                    'stat_identity_before_after': identity(before)})
        assert offset == entry['raw_bytes']
        assert entry['empty_original'] is (entry['raw_bytes'] == 0)
        verification = entry['verification']
        assert verification['decoded_bytes'] == entry['raw_bytes']
        assert verification['reassembled_decoded_sha256'] == entry['raw_sha256']
        assert verification['all_part_encoded_and_decoded_sha_verified'] is True
        total_raw += entry['raw_bytes']
    assert len(file_paths) == 494
    assert part_count == 565 and total_encoded == 194283176 and total_raw == 2588450699
    actual_selected = {str(path.relative_to(TARGET)) for path in (TARGET / 'blobs').rglob('*')
                       if path.is_file()}
    assert actual_selected == selected_paths
    for path, initial in small.items():
        selected = Path(path)
        raw = selected.read_bytes()
        assert digest(raw) == initial['sha256'] and len(raw) == initial['bytes']
        assert identity(selected.stat()) == initial['stat_identity']
    result = {'schema': 'mr3-v19-iters150-encoded-custody-independent-review-v1',
              'encoded_custody_review_completed': True, 'inputs': small,
              'source_raw_files_in_manifest': 494, 'gzip_encoded_parts_verified': 565,
              'encoded_bytes_verified': total_encoded, 'raw_bytes_manifest_only': total_raw,
              'source_encoding_counts': source_encoding_counts,
              'native_wall_seconds_original': manifest['native_wall_seconds_original'],
              'original_verdicts': original_verdicts,
              'encoded_single_pass': encoded_records,
              'limits': ['Encoded bytes/SHA/gzip magic/stat verified exactly once per part.',
                         'No gzip decode, reassembly, raw-source scan or formal/native rerun.',
                         'Decoded/raw hashes are preserved prior packer assertions, not '
                         'independently re-decoded in this encoded-only review.',
                         'Single-file gzip and ordered multi-part gzip are both legitimate.',
                         'Capture/admission/closure stage success preserves physicalFALSE; '
                         'this review does not supply A/B coverage, task or policy credit.'],
              'execution': {'argv': sys.argv, 'cwd': str(Path.cwd()),
                            'wall_seconds': time.monotonic() - start,
                            'source_sha256': digest(Path(__file__).read_bytes())}}
    with OUTPUT.open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'review': str(OUTPUT), 'sha256': digest(OUTPUT.read_bytes()),
                      'encoded_parts': part_count, 'encoded_bytes': total_encoded,
                      'original_physical_passed': False, 'raw_decode': False}))


if __name__ == '__main__':
    main()
