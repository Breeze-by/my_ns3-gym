#!/bin/bash
set -euo pipefail
cd /home/zhuyulab/ns3-workspace/ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl
exec /usr/bin/python3 -B -m mr3_learning.reach_execution --scope cpu --output /tmp/p2a64_candidate_history_actual_wait_v1 --source /tmp/p2a64_candidate_history_cpu_v1.sh --source /tmp/p2a64_archive_histories_v1.py --source report/assets/20261024_mr3_p2a_v64_equivalent_hotspots/checks/runtime_and_record_review_v1.md --source mr3_learning/__init__.py --source mr3_learning/reach_execution.py -- /usr/bin/python3 -B /tmp/p2a64_archive_histories_v1.py --kind candidate
