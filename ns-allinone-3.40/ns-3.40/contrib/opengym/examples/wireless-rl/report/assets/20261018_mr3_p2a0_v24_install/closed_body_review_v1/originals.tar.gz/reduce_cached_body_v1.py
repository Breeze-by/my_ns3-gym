#!/usr/bin/python3
"""V24 descriptive forensic reduction: cached bounded bytes and original small leaves only."""
from pathlib import Path
import hashlib
import json
import math
import time

D = Path('/tmp/mr3_p2a0_v24_body_trigger_independent_v1')
ANGULAR = Path('/tmp/mr3_p2a0_v24_interface_fixed_angular_v1.json')
PHYSICS = Path('/tmp/mr3_p2a0_v24_interface_fixed_physics_v1.json')
NATIVE_MANIFEST = Path('/tmp/mr3_p2a0_v24_selected_closed_v1/native/interface/manifest.json')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def bind(path):
    def ident(s):
        return [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns]
    s = path.stat()
    raw = path.read_bytes()
    assert ident(s) == ident(path.stat())
    return raw, {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw), 'stat': ident(s)}


def main():
    start = time.monotonic()
    paths = [Path(__file__), D / 'bounded_motion_window.bin', D / 'window_metadata_v1.json',
             ANGULAR, PHYSICS, NATIVE_MANIFEST]
    captured = [bind(path) for path in paths]
    raw = captured[1][0]
    metadata = json.loads(captured[2][0])
    angular = json.loads(captured[3][0])
    physics = json.loads(captured[4][0])
    custody = json.loads(captured[5][0])
    assert sha(raw) == metadata['window_sha256']
    assert metadata['source_stat_before'] == metadata['source_stat_after']
    source = metadata['source']
    packed_source = next(x for x in custody['files'] if x['source'] == source)
    assert angular['inputs'][source] == {'bytes': packed_source['raw_bytes'], 'sha256': packed_source['raw_sha256']}
    assert packed_source['source_stat_initial'] == metadata['source_stat_before']
    assert len(physics['episodes']) == 1
    episode = physics['episodes'][0]
    assert episode['epoch'] == angular['epoch']
    release, end = angular['release_time_ns'], angular['final_physics_time_ns']
    assert release == 42000000000 and end == 57180000000
    first = raw.index(b'\n') + 1
    last = raw.rfind(b'\n') + 1
    offset = metadata['requested_start'] + first
    robots = {name: [] for name in ('tb1', 'tb2', 'tb3')}
    fault_rows = []
    selected = []
    for line in raw[first:last].splitlines(keepends=True):
        row = json.loads(line)
        assert row['epoch'] == angular['epoch']
        if row['kind'] == 'own_odom':
            payload = row['payload']
            message = payload['message']
            stamp = message['header']['stamp']
            source_ns = stamp['sec'] * 1000000000 + stamp['nanosec']
            linear = [message['twist']['twist']['linear'][x] for x in ('x', 'y', 'z')]
            turn = [message['twist']['twist']['angular'][x] for x in ('x', 'y', 'z')]
            assert all(type(x) in (float, int) and math.isfinite(x) for x in linear + turn)
            record = {'source_ns': source_ns, 'record_sequence': row['record_sequence'],
                      'input_sequence': payload['input_sequence'], 'offset': offset,
                      'raw_line_sha256': sha(line), 'linear_xyz': linear, 'angular_xyz': turn,
                      'planar_norm': math.hypot(*linear[:2]), 'angular_norm': math.hypot(*turn),
                      'node_clock_sec': row['sim_time_sec']}
            samples = robots[payload['robot']]
            if samples:
                previous = samples[-1]
                assert source_ns > previous['source_ns']
                dt = (source_ns - previous['source_ns']) / 1e9
                record.update(prior_source_ns=previous['source_ns'], dt_sec=dt,
                              sampled_angular_accel_norm=math.hypot(*(a-b for a,b in zip(turn, previous['angular_xyz']))) / dt)
            samples.append(record)
            selected.append(line)
        elif row['kind'] == 'normal_control_model_invalid':
            fault_rows.append({'offset': offset, 'raw_line_sha256': sha(line), 'row': row})
            selected.append(line)
        offset += len(line)
    assert len(fault_rows) == 1 and fault_rows[0]['offset'] == 126187148
    fault = fault_rows[0]['row']['payload']
    assert fault['reason'] == 'measured_angular_speed_exceeded'
    trigger = next(x for x in robots['tb2'] if x['input_sequence'] == fault['input_sequence'])
    assert trigger['source_ns'] == fault['odom_source_ns'] == 56968000000
    assert trigger['angular_norm'] == angular['robots']['tb2']['max_angular_norm_rad_s']
    assert fault['commit_clock_ns'] - trigger['source_ns'] == 12000000
    formal_robots = {}
    for name, a in angular['robots'].items():
        p = episode['robots'][name]
        formal_robots[name] = {
            'angular_bounds_passed': a['bounds_passed'], 'angular_errors': a['errors'],
            'maximum_angular_norm_rad_s': a['max_angular_norm_rad_s'],
            'max_sampled_angular_accel_rad_s2': a['max_sampled_angular_accel_rad_s2'],
            'max_source_gap_ns': a['max_source_gap_ns'],
            'maximum_planar_speed_task': p['maximum_planar_speed_task'],
            'maximum_raw_odom_chord_speed_task': p['maximum_raw_odom_chord_speed_task'],
            'bound_violation_counts': p['bound_violation_counts'], 'raw_consumer_errors': p['errors'],
            'eligible_A': p['eligible_stop_events'], 'credited_A': p['credited_sampled_stop_events'],
            'eligible_B': p['eligible_cancel_stop_events'], 'credited_B': p['credited_cancel_stop_events'],
            'credited_A_events': [x for x in p['stop_responses'] if x['status'] == 'sampled_response_within_declared_bounds'],
            'credited_B_events': [x for x in p['cancel_stop_responses'] if x['status'] == 'sampled_response_within_declared_bounds'],
            'final_A': p['stop_responses'][-1], 'final_B': p['cancel_stop_responses'][-1],
            'physical_evidence_complete': p['physical_evidence_complete']}
    result = {
        'schema': 'mr3-v24-body-trigger-independent-description-v1',
        'scope': 'Description of original fixed consumer FAIL and one cached 2MiB trigger window; no rerun, native, task PASS or counterfactual proof.',
        'input_bindings': [x[1] for x in captured], 'epoch': angular['epoch'],
        'whole_motion_identity_from_original_consumer_and_roundtrip_custody': angular['inputs'][source],
        'actual_interval_ns': {'release': release, 'final_physics': end},
        'formal_angular': {k: angular[k] for k in ('passed', 'sampled_bounds_passed', 'stimulus_coverage_passed',
                                                  'positive_span_robots', 'negative_span_robots', 'sequential_opposite_sign_span_robots')},
        'formal_physics_passed': physics['passed'], 'formal_closure': episode['closure'],
        'robots': formal_robots, 'bounded_samples': robots, 'fault': fault_rows[0],
        'trigger_sample': trigger, 'bound_excess_rad_s': trigger['angular_norm'] - 1.2,
        'fraction_of_bound_excess': (trigger['angular_norm'] - 1.2) / 1.2,
        'interpretation': [
            'Single full-task angular bound violation is tb2 at56.968s, before stop at56.98s; it is finite full norm with x=y=0, not numeric endpoint normalization.',
            'All three original sampled angular accelerations remain below7; planar and chord speeds remain below.30. These do not excuse the1.2 violation.',
            'Original stimulus coverage passed: each robot has sign spans, both global signs and all three have sequential opposite-sign spans. This does not cover sampled-bound failure.',
            'Earlier A credit exists for every robot; tb1 and tb2 also have B credit. Final56.98s stop is missing rest evidence in only.20s remaining physics, and original observed_nonrest_beyond_horizon is false; no proved.78s stop-horizon breach from this tail.',
            '39 native children exited zero and all saved identities gone coexist with original forced worker/sample failure. Strict closure remains false.',
            'A limited trigger suffix cannot establish unique plant cause, lack of external force, or successful revised controller profile. Driver/wheel join is separately being reviewed.'
        ],
        'repair_boundaries': [
            'Retain1.2/.30/7/.78/.144/.01-three-sample and received-information/actual-storage gates; keep the original attempt FAIL and invalid unreturned request.',
            'Use actual desired/applied/joint velocity chronology to distinguish wheel-kinematic excess, body-slip/inertial response and stale command. Current common-fraction wheel increment proof alone is not a body yaw bound.',
            'If legal desired commands still produce body turn over1.2, review a versioned actuator/controller admissibility or damping/profile change against this measured state trajectory; a lower nominal angular target is only a prospective experiment, not a proportional physical proof.',
            'Do not repair this by suppressing raw samples, increasing measured limit, hiding lateral components, changing rest coverage, or disabling the corrector without evidence.'
        ]}
    end_bindings = [bind(path)[1] for path in paths]
    assert result['input_bindings'] == end_bindings
    result['all_inputs_end_stable'] = True
    result['wall_seconds'] = time.monotonic() - start
    output = D / 'body_formal_review_v1.json'
    assert not output.exists()
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'output': str(output), 'sha256': sha(output.read_bytes()),
                      'formal_angular_passed': angular['passed'], 'formal_physics_passed': physics['passed'],
                      'angular_trigger': trigger['angular_norm'], 'input_bindings_stable': True}))

if __name__ == '__main__':
    main()
