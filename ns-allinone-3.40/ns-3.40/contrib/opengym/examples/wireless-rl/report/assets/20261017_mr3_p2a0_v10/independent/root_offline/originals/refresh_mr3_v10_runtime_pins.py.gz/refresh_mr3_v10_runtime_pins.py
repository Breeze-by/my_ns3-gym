from pathlib import Path
import ast
import hashlib

root=Path('/home/zhuyulab/ns3-workspace')
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
p=w/'mr3_learning/audit_ppo.py';s=p.read_text()
prefix='ros2_ws/ros2-multi-robot-automap/'
tree=ast.parse(s);lines=s.splitlines(keepends=True)
changes=[]
for node in tree.body:
    if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name):
        name=node.targets[0].id
        if name in ('EVALUATOR_PHASE_PINS','PREPARATION_RUNTIME_PINS','EXECUTION_CONFIG_PINS'):
            for key,value in zip(node.value.keys,node.value.values):
                base=prefix if key.left.id=='ROS' else str(w.relative_to(root))+'/'
                relative=base+ast.literal_eval(key.right)
                digest=hashlib.sha256((root/relative).read_bytes()).hexdigest()
                if value.value!=digest:
                    lines[value.lineno-1]=lines[value.lineno-1].replace(value.value,digest)
                    changes.append(relative)
        elif name=='ENV_DOCUMENT_SHA256':
            digest=hashlib.sha256((w/'MR3_ENV_CONTRACT.md').read_bytes()).hexdigest()
            lines[node.value.lineno-1]=lines[node.value.lineno-1].replace(node.value.value,digest)
p.write_text(''.join(lines))
print('reviewed changed pins',changes,'plus2 helper files and ENV')
