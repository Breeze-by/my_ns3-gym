## V12 原生结果草稿（reset正式审计尚未结束）

同一clean/pushed freeze `6b1b4a0108351f5bfb70ec0c96ba895248d4f7a8` 完成interface、terminal和reset三次原生benchmark。interface和terminal所有mandatory正式消费者均PASS。reset的benchmark返回0并完成八轮，但版本已FAIL：存在活动不足、真实机体速度超界及正式驱动数学门失败三个独立问题。其余reset正式审计仍在运行，完成后逐原receipt填写，不把尚未结束的门记为PASS。deadline按失败版停止规则SKIP，不同freeze补跑不能拼成同一矩阵通过。

| 阶段 | 实际episode/step API | 实际下发joint action command | 有效/返回物理任务秒 | launcher原生墙秒 | 正式结果 |
|---|---:|---:|---:|---:|---|
| interface | 1 / 32 | 32 | 32 / 32 | 729.1043533119373 | 全部mandatory PASS；真实9参数查询PASS |
| terminal | 2 / 8 | 7 | 6.02 / 6.02 | 404.5781407058239 | 全部mandatory PASS；保留一次zero-dt终态返回，不算新动作 |
| reset | 8 / 256 | 256 | 256 / 256 | 3281.1070701107383 | FAIL；其余正式结果待收齐 |
| deadline | 0 | 0 | 0 | 0 | SKIP，不授deadline/停止响应信用 |

共11个真实reset API、296个step API，合计307 API；其中295条实际提交的joint command，1条未提交动作的zero-dt终态返回。有效与返回物理任务时间均294.02秒。原physics receipts中的helper实际推进294.538秒，另分为release前0.338秒和任务结束后的真实cleanup0.180秒；free-running启动直到首次paused receipt的物理时间不包含在这项helper增量中。三次launcher墙秒合计4414.7895641284995；benchmark自身墙秒为同次运行的另一观测4413.4765489515848，二者不能相加，双worker episode墙秒也不能当串行成本累加。独立审计wrapper重读同一数据没有新增native样本。这些量由原summary/transitions/physics/launcher逐字节SHA绑定，见 `/tmp/mr3_p2a0_v12_report_accounting_draft_v1.json`；正式审计完成后补最终版本，不覆该pending草稿。

reset失败归因分别为：

1. `worker0/episode002_open_101` 的tb2实际received-odom活动量仅 `0.0032782531368285074 m < 0.05 m`，观测完整；tb1、tb3分别约3.07564、3.02260m。前段安全门拒绝平移与后段Nav2/平滑器零线速度请求同时存在；后段大量guard clear仍不能产生平移，因此不能把全部问题归给PPO或guard。原warn级Nav2日志没有controller错误/ABORTED记录，但未归档该已关闭episode内部DWB plans/evaluation与pre-smoother命令，现有原件不足以唯一归因critic/plan。20个角速度样本也不表示缺少0：实际OneDVelocityIterator跨0额外生成精确0。代价图BFS通路只用于诊断，不冒称原DWB消费的plan/costmap。
2. `worker0/episode003_rooms_101` tb2原始own odom在source `92.617s` 测得 `vx=0.25164306169129336`、`vy=-0.17380055821233364`，完整平面模长 `0.3058281617710947 > 0.30 m/s`。这是实际机体模型界失败，与前项活动不足及下项轮指令数值门不同；原0.30界、SDF物理参数和原件不修改。来源为SHA绑定的原rawforensics，最终原物理消费者仍须原样执行，不能以没有实际接触或没有线上错误替代该界。
3. 正式V5驱动reader在`worker1/episode002_open_101` tb1 line10508与`worker1/episode003_rooms_101` tb1 line10009拒绝 `common alpha is not nominal fraction rounded inward`。两实际行的轮rim精确步长均没有超过 `Fraction(binary64(1))*Fraction(binary64(.034))`，最大轮恰等预算；但alpha比真有理nominal分别大 `2.2777671087784488e-20`、`2.682064943173154e-21`。冻结C++ helper按原输入重放alpha/applied逐bit相同：64有效位long double除法将nominal舍入为该double本身，旧比较未做到真Fraction向内。故保留正式FAIL，不能只改reader容差。另纯CPU near-zero反例证实旧fastpath/within的LD等号还可能漏掉严格轮预算；它们不是本次native已测轮预算超界，不与真实两行混称。

原生关闭子事实：八轮reset均native_stop0、每轮18个Nav2 managed节点真实finalized；独立观察的动态saved identity union349及原父身份fresh全gone，不设固定count门。此为关闭/生命周期事实，不改变reset整体FAIL；正式closure/FIFO最终结果仍待root runner。interface和terminal独立union分别46、90；观察器早期错误及明确修正单独保留，不能替换native失败或正式结果。

失败后经授权加入了两个纯被动Nav2观察器，仅捕获剩余corridor后段的现有`cmd_vel_nav`、global/transformed/local plan和完整LocalPlanEvaluation CDR；不改参数、动作、门或控制publisher。该非预声明订阅会增加debug发布/IO负载，开始时间与额外负载如实记录，不追回已经关闭的w0/e2内部输入，也不授正式PASS信用。成功采集共5850+5556条CDR、6161份去重gzip payload（278119657 encoded bytes）；逐encoded/decoded SHA/长度、topic counts与关闭检查均核验，两个ROS observer自然退出。MessageInfo在本机Humble executor被丢弃，只有实际graph端点GID范围；raw记录wall/observer clock在压缩/解析后写入，不能当callback入口或DDS延迟。初Node.clients只读属性错误、两个launcher路径错误、初始/proc环境漏运行后DDS profile的失败均保留并显式更正。新corridor纯角候选后来恢复平移，没有重现旧永久小角平台；该新例不能证明旧episode同因。

本版原生工程矩阵没有PPO训练、GPU调用或optimizer更新；离线CPU synthetic optimizer测试属于各自测试来源，不混入该原生计数。95%任务、三机参与和所有碰撞/物理/接触门不降低；pilot累计仍2226决策/11494.045260453597墙秒，余额1870/2905.954739546403不重置。尚无可靠冻结策略或P2A/P2A.0全矩阵验收信用，P2B/gateway未启动。

待最终填写：reset full/input/angular/physics/closure和正式runner总表；controller实际deadline SKIP事件；最终canonical archive/inventory路径。禁止把该草稿中的待审计项改为猜测PASS。
