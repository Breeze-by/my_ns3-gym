"""Counterexample replay using actual v8 motion-subscriber callback values.

This is a concrete executable producer hazard, not evidence that the information
producer saw this other node's callback prefix in the same order.
"""
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path('/home/zhuyulab/ns3-workspace')
RAW = ROOT / ('ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/'
              'mr3_p2a0_20261017_v8_terminal/worker0/episode001_open_101/motion_safety.jsonl')
SOURCE = Path('/tmp/mr3_independent_information_v1.py')
OUTPUT = Path('/tmp/mr3_p2a0_v9_information_raw_counterexample_v1.json')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


bindings = {str(path): sha(path) for path in (RAW, SOURCE)}
spec = importlib.util.spec_from_file_location('independent_reader', SOURCE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
rows = [json.loads(line) for line in RAW.read_text().splitlines()]
clock = 68_000_000_000
boundary = next(row['record_sequence'] for row in rows if row['kind'] == 'received_states'
                and round(row['sim_time_sec'] * 1e9) == clock)
observed = [row for row in rows if row['kind'] == 'own_odom'
            and row['payload']['robot'] == 'tb3' and row['record_sequence'] < boundary]
latest = observed[-1]
causal = max((row for row in observed if module.header_ns(row['payload']['message']) <= clock),
             key=lambda row: module.header_ns(row['payload']['message']))
latest_ns = module.header_ns(latest['payload']['message'])
causal_ns = module.header_ns(causal['payload']['message'])
assert latest_ns == 68_002_000_000 and causal_ns == 67_968_000_000
assert causal_ns <= clock < latest_ns
# Feed the actual causal-then-future payload pair to the independent replay.
replay = module.LedgerReplay('counterexample')
replay.record({'schema': module.SCHEMA, 'epoch': 'counterexample', 'record_sequence': 1,
               'clock_ns': clock, 'wall_monotonic_ns': 1, 'kind': 'configuration',
               'payload': {'tf_validity_lead_sec': .2, 'pending_limit': 256,
                           'state_period_sec': .1, 'odom_pending_order': 'source_ns_ascending',
                           'tf_pending_order': 'accepted_header_ascending'}})
for seq, row in enumerate((causal, latest), 1):
    raw = row['payload']['message']
    replay.ingress('odom', {'robot': 'tb3', 'input_sequence': seq,
                            'source_ns': module.header_ns(raw), 'raw': raw,
                            'raw_sha256': module.digest(raw), 'admission': 'queued',
                            'matched_input_sequence': None}, clock)
selected = replay.promote('odom', 'tb3', clock)
assert selected['source_ns'] == causal_ns
assert [q['source_ns'] for q in replay.pending['odom', 'tb3']] == [latest_ns]
for name, expected in bindings.items():
    assert sha(Path(name)) == expected
result = {'schema': 'mr3-v9-information-raw-counterexample-v1', 'passed': True,
          'inputs': bindings, 'clock_ns': clock, 'boundary_record_sequence': boundary,
          'latest_actual_subscriber_row': latest, 'latest_causal_actual_subscriber_row': causal,
          'legacy_latest_only_would_skip_future': True,
          'new_independent_selection_source_ns': selected['source_ns'],
          'preserved_future_source_ns': latest_ns,
          'scope': 'Actual motion-subscriber raw values in a concrete producer-shaped replay; '
                   'does not prove original hub ingress ordering or eliminate the same-clock freshness race.'}
OUTPUT.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + '\n')
print(json.dumps({'passed': True, 'output': str(OUTPUT), 'sha256': sha(OUTPUT)}))
