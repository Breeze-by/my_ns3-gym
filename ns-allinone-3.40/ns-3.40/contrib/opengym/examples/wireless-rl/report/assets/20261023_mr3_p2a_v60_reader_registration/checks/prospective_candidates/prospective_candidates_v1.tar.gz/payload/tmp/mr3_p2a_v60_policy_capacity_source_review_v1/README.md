# V60 后继 minimum / pilot / final 容量复核（仅源码与已闭合小 metadata）

**当前没有容量资格。下一 driver 即使完整 native qualification PASS，也不能自动进入 pilot / final；须先有显式、真实的容量 gate proof。** 本报告没有执行 reader、native、World、模型或 profile，没有读取 raw 或仍在增长的 reset full 输出，不给成功率、学习或 P2A 信用。V60 已知 required physics FAIL 保持。

依据为 E=`935b466bd076002afdfe161b55a508938de2a8b0` 的 22 份静态源，以及获准读取的 11 份小 metadata，具体 SHA/字节/稳定性与派生数据见 `capacity_facts_v1.json`。三份 benchmark_summary 均先逐 SHA 对上对应真实 child_waited native receipt 的 output_sha256；并非借未经关联的同名 summary。matrix ledger 只作 closed child_waited 的路径定位，不把仍活动 ledger 整体声称为稳定 pin。真实 reset native receipt 名为 `reset/native.json`。

## 原 cap 的真实范围

| 阶段 | 原总 wall cap | 外部 finalizer 预留 | main cap | 字面 native ceiling | 实际 native 上限（尚未扣前耗时） |
|---|---:|---:|---:|---:|---:|
| minimum | 1800 | 0 | 1800 | 1150 | 1150 |
| pilot | 2905.9547395464029 | 300 | 2605.9547395464029 | 2100 | 2100 |
| validation | 9000 | 300 | 8700 | 8500 | **8200** |

`reach_policy_chain.native_budget` 的实际公式是 `floor_ms(min(native_ceiling, main_cap - elapsed_before_native - 500))`。500 是内部 tail 的**最低预算预留**，不是完整审计耗时的测量或保证。minimum 在 native 用满1150时，前后还有至多650秒；pilot 用满2100时，main 中其余仅505.9547秒；validation 的8500字面被300外尾和500内尾收紧到8200，再扣源核验、资格/前驱核验和 watcher ready 等前耗时。

main deadline 从 `execute_stage` 入口计，包含 source/qualification/predecessor admission、watcher、实际 PPO/native、原正常关闭、所有提交的完整科学审计、episode/policy artifacts、source/raw binding 重核与 summary。`reach_execution` 的真实 outer wait 另包含解释器/调用外层开销；finalizer 要求该完整 outer wall 也在 main cap 内。

pilot/final 的外部 finalizer 各在**自己原总额内**留300秒。`execute_chain_v1.py` 同时核 main+final 实际 scope-union 不超原 cap、从 main 开始到 final 结束的 endpoint 也不超 cap、final 单独不超300；不是把 finalizer 或审计挪到 engineering。minimum main 仍是1800，其后 finalizer 使用工程 external300 与 matrix_absence/qualification 共享余额。nested native/reader 时间只用于拆分，不能重复加入父区间费。

这些 cap 不是强杀硬期限：已提交长 reader 必须真实排空，超额保留全部费用并 FAIL。PPO 自身 wall cap 也不能替代完整阶段 cap；模型初始化、采集、optimizer/checkpoint、环境关闭均真实占时。

## 已闭合实际成本与可比较范围

| V60 已闭合项 | native command wall | 完整 stage wall | native 结束到全部审计结束 | full reader wall |
|---|---:|---:|---:|---:|
| interface，1 EP / 32 transitions | 1142.750379943 | 2053.863667255 | 896.844473675 | 895.529903519 |
| terminal，2 EP / 8 transitions | 448.623246726 | 812.906743691 | 350.018504020 | 349.193697446 |

reset native 已闭合：benchmark 内部4558.013913954608秒，真实 native command 父 wait4558.557234952秒；2 worker、8 EP、256 transitions。runtime command 已闭合且真实2017.196047829秒。**reset full 仍活动，其最终耗时 UNKNOWN，本报告没有读它，也不能把当前活动时长填进最终费用。**

interface 的 `dt_values` 合计真实 task 32秒，startup139.178305325秒、transition993.286312348秒、整EP1142.129358667秒。reset四个 open EP 也都是真实32 task秒，startup134.665–136.695秒、transition1007.940–1015.886秒；每 task sim 秒约31.50–31.75 wall秒。terminal 的两个4-transition回合 task跨度仅3.02和3.00秒，分别有132.672和126.414秒startup；不能把它当4秒普通推进。

因此，startup 是真实的每EP固定开销量，和推进率分开；worker并行使 reset八EP的总墙秒不等于八EP墙秒相加。当前 summary 没有足够字段给出 startup 的完整 sim 跨度；不能拿猜测的 startup sim 秒归一化 audit。审计还读 startup、20/34ms日志、地图/观测/协议/完整原件及结束证据，其成本不只由 task steps 决定。

9000秒完成3个并行300-task-second回合存在**明确高风险**：仅作条件比较，若 startup约135秒且没有模型/关闭等额外成本，8200-native cap 要求推进平均约≤26.88 wall秒/task秒。现有32秒 open 前缀约31–32；它显示需要改善，但不是300秒耗时的线性预测或不可达下界。长回合的地图、候选、意图/角色、I/O与资源争用会变化；任务也可能在300秒前成功，不能预先假定。

同样，单interface完整审计约896秒已大于500内尾，但它是 preparation full，不是未来 PPO full 的精确下界。PPO full 还要原 policy/rollout/GAE/optimizer/checkpoint gate；当前源码的原每EP native/scalar/cadence循环和新的每EP information/runtime/FIFO/archive/activity合取均串行于 full 进程，外层还另跑各EP FIFO/strict custody。完整 final 三EP成本未测，不能宣称500够。minimum16和pilot请求64也没有完整阶段实际容量证明；native能返回不代表尾部审计在余量内完成。

## 不动原余额/科学门的后继路线

1. 先完成一次有界 open101/8step 零学习的真实进程 CPU 分解，定位 motion_safety、worker、adapter/encoder 的主耗时。这里只准备设计，不执行。8step profile不是final容量证明。
2. 只选有实测支撑的恒等优化；用冻结原源、完整输出/JSON/SHA与独立oracle验证，再新freeze资格。native推进侧与完整audit侧都要实测；单kernel倍速不折算整链倍速。
3. 可以在**原9000内部**前瞻增加audit reserve、相应压低native allocation，并保留300外部finalizer或给出同总额的新明确分配。这是新resource版本，不能倒改A60的500/8500事实或增加final余额。分配本身不创造吞吐。
4. 容量 gate proof 必须明确新freeze、实际argv/worker数/原任务最大跨度与可比较激励、完整native与所有科学audits/finalizer的真实wait/parent endpoint、source稳定/身份关闭和预算余量。保留测量扰动与长回合不确定性。不能用32→300比例或短profile PASS填“足够”。在该proof实际成立以前，未来driver应前瞻停在工程侧，pilot/final自动入口禁用；不能靠一轮新qualification自动解锁。
5. 可评估保持全部独立科学结论的调度优化：不同EP的独立、只读gate有界并行，完整result按原EP确定顺序汇总；或在同reader内复用经过完整SHA/parse核验的不可变数值/解码数据，但每个gate仍执行自身原校验/数学，不缓存episode PASS、不以producer summary作oracle。当前外层已有4-slot调度，简单再加slot不证明更快；PPO full内部串行、重复扫描及文件绑定需分别测量。任何重排/共享均须新源审查与CPU，不能静默删cadence/runtime/FIFO或raw hash。

原12EP/30角色、固定R/anchor、20/34ms、95%/300秒、quality/safety/contact、received-only、真实motor语义、pilot final.zip/归一化与3个final-only open401/402/403全部保持；固定final seeds不得用作反复capacity调参样本。

## V48 / V39 能复用什么，不能再算什么

V48原9+9人工CPU、合同角域v2人工结果、source/profile与oracle仍可作精确数学回归材料。**当前 production `mr3_reach_support.py` 已逐字等于 V48 production candidate（SHA dc32cb48...），当前独立 `reach_support_replay.py` 也已逐字等于 reader candidate（SHA47ea22da...）。** required²复用、单次dot/cross/h、96bit exact sqrt bounded tuple cache、reader共同分母/Horner已经在当前路径；不能重复提出“安装V48”并再次计算旧1.238倍或21倍收益。

V39的AABB下界/零长度捷径也已在当前 `_segment_measurements`：遍历/计数所有原非free格；只有AABB下界严格小于当前minimum才算完整projection。旧冻结reference、逐字段/JSON、全格独立oracle与446人工CPU证明是后续回归基线；2.72倍只属于原固定微基准，不是新ENV提速。

HOLD/D 的纯数值常量可以再静态审：`reach_for` 先完整 `validate_safety` 后才返回disk；disk的buffer/longitudinal/no-directions支持值固定。可复用这类immutable小数值tuple，每次仍创建独立proof/output。但 `pair_checks` 目前使用**当次 received map/raw位置差**，不是anchor差；固定anchor/R约束不意味着delta完全相同，U又来自当次exact source ages。N/X的方向、符号、quaternion/TF与phi也会变化。不能按robot/anchor/角色或近似浮点桶缓存整个pair证书，更不能缓存安全decision。

后续纯kernel候选只列为待测：同一已验证输入内消除Q→str→Q往返、48bit outward-display整数floor/ceil、完整exact-key的immutable norm/代数中间量复用；完整公共dict、mode、异常、mutation隔离、full exact-frame SHA仍逐字不变。age/seq、来源/校准、pose-membership、intent/STOP债务、current/prospective两callsite、map/raw AND和sign-union每次都要核。reader保持独立数学，不能导入production结果自证。V51已测旧热点还包括严格JSON/canonical与声明/ACK扫描，不能继续把所有耗时归因support。
