"""Reversible version-only draft proof; no native or source-pin admission."""
import ast
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path('/home/zhuyulab/ns3-workspace')
GENERATOR = Path('/tmp/mr3_p2a0_v15_generate_matrix_draft_v1.py')
spec = importlib.util.spec_from_file_location('draft_generator', GENERATOR)
G = importlib.util.module_from_spec(spec)
spec.loader.exec_module(G)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def tree(raw):
    return ast.dump(ast.parse(raw), include_attributes=False)


def main():
    generated = json.loads((G.DRAFT / 'generation_v2.json').read_bytes())
    base = generated['source_commit']

    def git(path):
        return subprocess.check_output(['git', 'show', base + ':' + path], cwd=ROOT)

    source = {}
    proofs = []
    for record in generated['records']:
        old = git(record['source'])
        raw = Path(record['draft']).read_bytes()
        restored = G.unversion(raw)
        assert sha(raw) == record['draft_sha256']
        assert restored == old and tree(restored) == tree(old)
        source[record['draft']] = sha(raw)
        proofs.append(dict(source=record['source'], draft=record['draft'],
                           reverse_version_bytes_equal=True, reverse_version_ast_equal=True))
    parent = generated['parent']
    raw = Path(parent['path']).read_bytes()
    assert raw.count(G.NEW_REQUIRE.encode()) == 1
    restored = G.unversion(raw.replace(G.NEW_REQUIRE.encode(), G.OLD_REQUIRE.encode()))
    old = gzip.decompress(git(parent['source']))
    assert restored == old and tree(restored) == tree(old)
    source[parent['path']] = sha(raw)
    tests = generated['parent_tests']
    raw = Path(tests['path']).read_text()
    marker = "\n\nif __name__ == '__main__':"
    restored_tests = raw.replace('\n' + G.NEW_TESTS + marker, marker).replace(
        "'all_submitted_jobs_finished':behavior.get('unfinished_jobs')!=stage,",
        "'all_submitted_jobs_finished':True,")
    restored_tests = G.unversion(restored_tests.encode())
    old_tests = gzip.decompress(git(tests['source']))
    assert restored_tests == old_tests and tree(restored_tests) == tree(old_tests)
    source[tests['path']] = sha(raw.encode())
    closure = Path(next(r['draft'] for r in generated['records']
                        if 'multiepoch_closure' in r['draft'])).read_text()
    assert "original != Path('/tmp/mr3_p2a0_v13_binaryproof.json')" in closure
    assert "supplement.BINARY = Path('/tmp/mr3_p2a0_v15_binaryproof.json')" in closure
    assert 'mr3_v13_shim_mapping_review_v1.py' in closure
    old_plan = json.loads(git(G.A14 + 'predeclared_plan_v14.json'))
    plan_path = G.DRAFT / 'predeclared_plan_v15.json'
    plan = json.loads(plan_path.read_bytes())
    assert plan['readiness']['status'] == 'draft_pending_root_final_review'
    assert plan['readiness']['pending_bindings'] and plan['new_source_bindings_pending']
    assert plan['independent_source_bindings'] == old_plan['independent_source_bindings']
    for key in ('max_api_records', 'max_submitted_script_decisions', 'max_total_wall_seconds',
                'unchanged_gates', 'physical_response_criteria', 'angular_interface_criteria',
                'angular_reset_criteria', 'settled_turn_criteria', 'pilot_budget_unchanged'):
        assert plan[key] == old_plan[key], key
    for old, new in zip(old_plan['stages'], plan['stages']):
        assert old['stage'] == new['stage']
        assert json.loads(G.version(json.dumps(old['required_audits']).encode())) == (
            new['required_audits'])
        assert json.loads(G.version(json.dumps(old['required_audit_receipts']).encode())) == (
            new['required_audit_receipts'])
        assert old['command'][old['command'].index('--steps') + 1] == (
            new['command'][new['command'].index('--steps') + 1])
    result = dict(
        passed=True, source_commit=base, byte_ast_reversible=proofs,
        parent_reversible_except_exact_equivalent_diagnostic_requires=True,
        parent_tests_reversible_except_two_named_fake_cli_diagnostics=True,
        parent_boolean_truth_table_cases=generated['diagnostic_gate_boolean_truth_table_cases'],
        immutable_a13_shim_and_drive_references_preserved=True,
        original_binaryproof_default='v13', new_binaryproof_path='v15',
        all_original_mandatory_sets_and_hard_gates_preserved=True,
        original_105_bindings_retained_without_claiming_current_finality=True,
        unresolved_workload='v4 final producer and metadata wrapper bindings pending',
        plan_sha256=sha(plan_path.read_bytes()), native_admission=False,
        source_before=source, source_after={path: sha(Path(path).read_bytes()) for path in source},
        generator_source_sha256=sha(GENERATOR.read_bytes()),
        scope='Only /tmp draft source/AST/old Git comparison; no canonical changes, native, '
              'formal audit or new sourcefreeze. Plan must remain pending until root finalizes.')
    assert result['source_before'] == result['source_after']
    path = G.DRAFT / 'static_v2.json'
    with path.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ('source_before', 'source_after', 'byte_ast_reversible')}, indent=2))


if __name__ == '__main__':
    main()
