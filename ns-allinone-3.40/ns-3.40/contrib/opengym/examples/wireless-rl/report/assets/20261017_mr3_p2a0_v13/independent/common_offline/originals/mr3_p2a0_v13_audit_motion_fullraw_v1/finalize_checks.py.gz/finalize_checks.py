import difflib
import hashlib
import json
from pathlib import Path
import re


OUT = Path(__file__).resolve().parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
WORK = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'


def sha(data):
    return hashlib.sha256(data).hexdigest()


final = {}
for name, relative in [('audit_motion.py', 'mr3_learning/audit_motion.py'),
                       ('test_audit_motion.py', 'mr3_learning/tests/test_audit_motion.py')]:
    raw = (WORK / relative).read_bytes()
    with (OUT / ('final_' + name)).open('xb') as stream:
        stream.write(raw)
    final[relative] = {'path': str(WORK / relative), 'sha256': sha(raw),
                       'saved_bytes': str(OUT / ('final_' + name))}
    original = (OUT / name).read_text()
    patch = ''.join(difflib.unified_diff(original.splitlines(True), raw.decode().splitlines(True),
                                       fromfile='source_before/' + relative, tofile=relative))
    with (OUT / (name + '.patch')).open('x') as stream:
        stream.write(patch)

names = ['focused_red', 'focused_red_v2', 'focused_green', 'full_module', 'style',
         'full_module_final', 'style_final', 'diff_check', 'diff_final',
         'style_final_v2', 'diff_final_v2', 'full_module_final_v2']
checks = {name: json.loads((OUT / (name + '.json')).read_text()) for name in names}
final_names = ['style_final_v2', 'diff_final_v2', 'full_module_final_v2']
expected_sources = {value['path']: value['sha256'] for value in final.values()}
for name in final_names:
    assert checks[name]['returncode'] == 0
    assert checks[name]['source_before'] == checks[name]['source_after'] == expected_sources
text = (OUT / 'full_module_final_v2.log').read_text()
count = re.search(r'Ran (\d+) tests', text)
assert count and int(count.group(1)) == 25 and text.rstrip().endswith('OK')
summary = {
    'schema': 'mr3-p2a0-v13-audit-motion-fullraw-checks-v1', 'passed': True,
    'source_before': json.loads((OUT / 'source_before.json').read_text()),
    'source_final': final, 'unique_final_module_tests': 25, 'checks': checks,
    'scope': 'CPU consumer provenance replay only; no ROS build, simulator, GPU or PPO training',
    'normal_eligibility': ['selected causal local raw planar XY and angular XYZ',
                           'after actual release, retained causal local raw history through commit',
                           'actual received peer raw and scalar/v/w consistency'],
    'excluded_from_new_normal_history_rule': [
        'unselected pre-release source history', 'future pending raw sources',
        'takeover and explicit permanent zero stop operations'],
    'legacy': 'helper without measured_velocity_error does not enter the new normal check',
    'failure_provenance': {
        'focused_red': 'environment-only attempt: conda has no pytest; no test ran',
        'focused_red_v2': '8 unittest methods, 3 failures: 2 genuine old false PASS cases; '
                          '1 explicit model-invalid diagnostic label previously failed as unknown',
        'style': 'initial ignore list omitted repository W503 and found existing formatting',
        'style_final': 'one remaining old continuation indentation; corrected without AST change',
    },
    'preserved_input_failures': 'No V12 native/formal artifacts modified or rerun',
    'limitations': 'Normal eligibility is not source-window task attribution or a full body '
                   'physics audit; existing independent task/body/stop gates remain required',
}
with (OUT / 'checks_final.json').open('x') as stream:
    json.dump(summary, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({'path': str(OUT / 'checks_final.json'),
                  'sha256': sha((OUT / 'checks_final.json').read_bytes()),
                  'passed': True, 'source_final': final}, indent=2))
