import hashlib
import importlib.util
import json
from pathlib import Path

SOURCE = Path('/tmp/mr3_independent_information_v1.py')
FIXTURE = Path('/tmp/mr3_p2a0_v9_information_producer_fixture_v2')
ROOT = Path('/home/zhuyulab/ns3-workspace')
PRODUCER = ROOT / ('ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/'
                   'multi_robot_exploration/mr3_information.py')
OUT = Path('/tmp/mr3_p2a0_v9_information_consumer_compat_v1.json')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


spec = importlib.util.spec_from_file_location('independent_reader', SOURCE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
inputs = {str(path): sha(path) for path in [SOURCE, PRODUCER, *sorted(FIXTURE.iterdir())]}
results = []
for name, complete in (('information_states.jsonl', True), ('tf_duplicate_audit.jsonl', False)):
    path = FIXTURE / name
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    replay = module.LedgerReplay(rows[0]['epoch'])
    for row in rows:
        replay.record(row)
    counts = replay.finish() if complete else dict(replay.counts)
    if complete:
        assert counts['state_publish'] == 2 and counts['selections_retaining_future_odom'] == 3
        sends = [row['payload']['envelope']['payload'] for row in rows if row['kind'] == 'state_send']
        assert all(state['yaw'] != 0 and state['x'] != 0 and state['y'] != 0 for state in sends)
    else:
        assert counts['tf_ingress'] == 6000
        assert sum(row['payload'].get('admission') == 'ignored_pending_order' for row in rows) == 5999
    results.append({'path': str(path), 'sha256': sha(path), 'rows': len(rows), 'counts': counts,
                    'passed': True, 'complete_producer_replay': complete})
for name, expected in inputs.items():
    assert sha(Path(name)) == expected
result = {'schema': 'mr3-information-independent-producer-compat-v1', 'passed': True,
          'inputs': inputs, 'results': results,
          'scope': 'Real production methods/ROS messages with fake publishers, replayed independently; '
                   'no ROS initialization, DDS, simulator, physical, task or native acceptance credit.'}
OUT.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({'passed': True, 'output': str(OUT), 'sha256': sha(OUT)}))
