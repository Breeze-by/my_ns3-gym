# 后继探针 workload 边界：有限自然暖身的源码复核

结论：可以把“有限自然暖身GOAL，不计科学取消覆盖信用”研究为显式新probe版本；原P2A没有要求每回合必须恰好6个总GOAL、初轮一定task0/1、第二轮一定13–19秒。但当前masked-cancel-v1明确禁止额外GOAL/自然终态充覆盖，不能原profile直接加入暖身。这里只确认可提出新版本，不证明暖身可完成、可交接或之后moving WAIT可达。当前V74仍只做tb3 rejected checks引用描述，不因此提前World、改rank/plant或改判V71/V73。

本次仅源码/文档静态阅读，不import模块、不运行CPU/tests/reader/native/World、不读取旧科学输入或派生结果，不写canonical。下列W=wireless-rl，P=ROS multi_robot_exploration包；精确路径和本次所读字节SHA另列source_pins_v1.json。

| 必须保持的门 | 直接依据 |
|---|---|
| K8+KEEP/WAIT、原收到输入与per-robot AND joint masks、单owner、真实accept后5s承诺、TTL/生成时刻/FIFO/幂等；承诺内普通WAIT/换目标不能抢占，自然终态/真正安全停止例外 | W/RESEARCH_PLAN.md:229–255；MR3_ENV_CONTRACT.md:63–89；P/mr3_protocol.py:171–207、294–316；P/mr3_observation.py:745–803。安全停止例外不能用来包装暖身取消。 |
| 原Reach/物理与执行合同：R=.0078、2BODY=.5m、source最大龄.5s、H=.78s、STOP纵向.144m、D至少2R/X至少4R、原margin/geometry/backup debt、真实raw/storage/APPLIED/actualmotor披露、永久STOP和servo首次非零后永久disarm | P/mr3_reach_geometry.py:14–21、155–168、191–233；mr3_reach_runtime.py:30–34、417–454、534–540；multi_robot/mr3_initial_zero_encoder_servo.hpp:53–65。工作负载不能改这些量、清故障/债务或旁路cmd_vel。 |
| 300sim秒任务、交付融合图correct-free≥.95、原ROI/质量、三台参与、零非支撑接触、18路完整且持续新鲜、协议闭合 | W/RESEARCH_PLAN.md:306–330。短工程探针不能替代P2A任务/真实学习/三场strict95。 |
| 新同freeze完整12EP/30角色、9probe实质独立重放、12authority完整证明、source/newbuild/custody/严格关闭及原policy容量门 | W/mr3_learning/reach_preparation.py:660–667、713–723、840–865；旧PASS不能授新workload资格，不自动policy。 |

32steps/33条reset+step记录、初轮<1.5秒/accept≤2秒、第二窗[13,20)/accept≤20、WAIT≤10/28、恰好6个GOAL/6个moving WAIT、一次accepted后完整路径baseline、首轮三fresh rest+3秒handoff，是当前显式workload与reader合同。源码：benchmark.py:654–716、726–757、825–889；独立reach_probe_v3_replay.py:87–123；reach_probe_masked_cancel_replay.py:49–65、108–147、150–221。其v≥.08/path新增≥.05是真moving-WAIT选择门，不能用暖身较早的运动/累计path充后继GOAL。物理叶的raw≥.05/三rest/.78/.144等是另一层真实停车证据，不能由这两个收到谓词替代。

32步还进入已冻结reset workload adapter：physics_matrix_v17.py:45–62、78–95；angular_reset_matrix_v17.py:84–102、135起。因此这些数值虽非物理定律，却对现有版本强制。新版本若添加暖身或挪窗口，必须声明完整有限总步数/真实task clock/新元数据与独立workload eligibility；不能仅换token、去掉计数断言、默许额外行或给原32步PASS换标签。总步数本身可作为新workload前瞻声明，不把32冒称原P2A不可改阈值；每机两轮真实取消等覆盖义务保持。若另选择保留32个科学观察步，暖身必须是总episode额外明确时段，不能复位task_elapsed/epoch或隐去暖身。是否需要更多总步与工程容量须事前定额，不能跑到“刚好可取消”再结束。

原状态机存在自然接续路径：mr3_protocol.py:350–374对真实SUCCEEDED执行_release；331–348清原owner/commitment，未fault时回idle，203–205允许下一原合法GOAL。ABORTED或无请求的CANCELED触发failure，不能当作可丢弃的暖身成功。mr3_observation.py:752–803仍要求当前fresh、idle/合法phase与原joint mask；KEEP不移走peer目标冲突，旧一次合法不保证下一拍合法。

逻辑idle不等于新运动权限。mr3_adapter.py:819–840在当前owner真实终态先发REVOKE；776–790接收匹配stop_obligation_ready，880–896仅对实际accepted owner且ready的pending accept授grant。mr3_motion_authority.py:114–168要求真实zero publication/storage/causal APPLIED、三fresh calibrated raw rest等；实际非零应用后还要求实际rim为零。194–211不为ACTIVE生成stopready；267–275新grant拒绝overlap并要求≤100ms真实ready，更新callback floor。若ready、HOLD/N/D证据、mask、lease或原deadline不满足，方案就被原门阻断；不能设置ready=True、伪STOP、丢弃receipt或重开控制器来使其可用。

“不人工重锚”须按原代码精确表述：mr3_reach_runtime.py:417–419拒重复release，427–434记录初始anchor；现有466–472本来就有真实qualified→D自动anchor转换。它必须完整记录，不能被probe提前调用、强制或隐藏，亦不能额外禁止原状态机已有的合法转换。servo qref的一次捕获/永久disarm、旧物理诊断固定anchor的账与定义都不因此改变。HOLD/normal-stop证据只能来自原转换，不能把普通idle或目标自然成功直接改名为HOLD。

未来若实施新版本，最低仍须保留这些检查：

- 固定有限暖身次数、目标选择规则、截止与失败出口；同epoch/真实clock/原K8 masks/lease与所有权。额外GOAL是新有界workload内声明的尝试，不是重试旧活动，也不是无限retry-until-moving。
- 暖身有真实same-goal accept与自然SUCCEEDED记录、原authority revoke/ready/grant交接；无reset/release重入、人工改anchor/清债、servo rearm、隐藏实际非零或旁路速度。没有原合法接续则明确FAIL/不可用。
- 每机后续仍两次不同真实accepted GOAL、各自一次accepted后fresh完整path baseline、满5s且same active owner后合法moving WAIT、真实native cancel与终态、rest/HOLD/交棒/下一GOAL。暖身的GOAL/自然SUCCEEDED/运动/stop不填这些覆盖槽，不替代科学WAIT；自然提前结束的科学GOAL仍失败，不能改列暖身。
- producer和独立reader对暖身/科学/cleanup分类及全部命令行逐项重放，不仅相信producer标签；全部goal id/seq/raw/effective/storage/APPLIED保留，未知kind、缺依赖、越界或篡改不whitelist跳过。
- 全部暖身和qualified过程均在原安全/物理/18stream/full/authority/source/custody与费用窗口内。只有覆盖信用可标“不计”，不能排除暖身违规、延迟、真实接触、sample gap、永久fault或超时。总300sim任务与stage/parent审计收尾也不能借final额度或事后延长。

增加暖身/新步数不等于降低原数学，但须前瞻新producer/reader/profile、完整source闭包、真实current build与软件准入，以及可fund的stage/parent/native/audit收尾资源cap；仍需完整同freeze12EP/30roles、实质9probe与12authority证明。全部额外步骤进入原生/安全/物理/full审计。32步prefix或人工kernel不能线性外推final900/9000容量，不能自动policy或借final额度；本复核不计算新cap。

是否实际存在可行暖身目标、其终态能否在固定上限内到达、原stopready/几何能否交接，以及后继v≥.08/path≥.05和两轮moving WAIT能否发生，均UNKNOWN；必须等V74具体peer/拒绝条件证据再决定。自然release有代码路径不等于完整资格可达。本复核不修改当前生产、审计、预算或任何历史FAIL。
