"""Only existing small snapshot metadata and exact-mask hypothetical one-GOAL/two-WAIT."""
import ast
import hashlib
import json
import math
from pathlib import Path
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
BENCH = W / 'mr3_learning/benchmark.py'
EP = ROOT / ('ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/'
             'mr3_p2a0_20261017_v16_interface/worker0/episode001_open_101')
OUTPUT = Path('/tmp/mr3_p2a0_v16_interface_seed_latewait_v1.json')
started = time.monotonic()
code = BENCH.read_bytes()
payload = (EP / 'transitions.jsonl').read_bytes()
rows = [json.loads(line) for line in payload.splitlines()]
namespace = {'math': math}
definition = next(node for node in ast.parse(code).body if isinstance(node, ast.FunctionDef)
                  and node.name == '_probe_nonapproaching_goal_action')
exec(compile(ast.Module(body=[definition], type_ignores=[]), str(BENCH), 'exec'), namespace)
seeds, late = [], []
for row in rows:
    snap = row['snapshot']
    elapsed = snap['task_elapsed_sec']
    d = snap['diagnostics']
    if elapsed in (0., 1., 13., 14., 21., 22.):
        seeds.append({'elapsed': elapsed, 'snapshot_sequence': snap['sequence'],
                      'snapshot_digest': snap['digest'], 'path_map_tb1': snap['path_maps']['tb1'],
                      'candidate_rule': snap['candidate_rule'],
                      'seed_diagnostic_tb1': d['robot_seed_diagnostics'][0],
                      'robot_seed_traversable': d['robot_seed_traversable'],
                      'counts': {key: d.get(key) for key in (
                          'frontier_cells', 'frontier_groups', 'geometric_pool_size',
                          'candidate_truncated', 'per_robot_reachable_pool_counts',
                          'per_robot_reachable_selected_counts', 'per_robot_reachable_target_cells',
                          'per_robot_arrival_noop_cells', 'per_robot_staging_rejections')},
                      'tb1_mask_reasons': d['mask_reasons']['per_robot'][0]})
    if 22 <= elapsed <= 25:
        own = snap['robots'][0]
        options = []
        for choice, candidate in enumerate(snap['candidates']):
            if choice >= 8:
                continue
            action = choice * 100 + 99
            mask = snap['joint_action_mask'][action] is True
            geometry = namespace['_probe_nonapproaching_goal_action'](snap, action)
            gx, gy = candidate['x'] - own['x'], candidate['y'] - own['y']
            distance = math.hypot(gx, gy)
            margins = {}
            for peer in snap['robots'][1:]:
                px, py = peer['x'] - own['x'], peer['y'] - own['y']
                denominator = distance * math.hypot(px, py)
                margins[peer['name']] = -(gx * px + gy * py) / denominator if denominator else None
            options.append({'action': action, 'candidate': choice,
                            'original_joint_mask_allowed': mask,
                            'nonapproach_predicate': geometry,
                            'both_original_mask_and_V5_nonapproach': mask and geometry,
                            'goal_xy': [candidate['x'], candidate['y']],
                            'path_distance_m': candidate['path_distances_m'][0],
                            'relative_goal_bearing': math.atan2(math.sin(math.atan2(gy, gx) - own['yaw']),
                                                              math.cos(math.atan2(gy, gx) - own['yaw'])),
                            'straight_outward_margins': margins})
        late.append({'elapsed': elapsed, 'snapshot_sequence': snap['sequence'],
                     'actual_original_command_at_this_boundary': next(
                         (later['info']['command']['action'] for later in rows
                          if later['kind'] == 'step'
                          and later['info']['command']['observation_sequence'] == snap['sequence']), None),
                     'all8_TB1_GOAL_peerWAIT_choices': options,
                     'legal_nonapproaching_GOAL_peerWAIT_actions': [option['action'] for option in options
                                                                  if option['both_original_mask_and_V5_nonapproach']],
                     'hypothetical_5sec_commitment_until': elapsed + 5.,
                     'remaining_to_actual_end32_after_5sec': 32. - elapsed - 5.})
sha = lambda value: hashlib.sha256(value).hexdigest()
result = {'schema': 'mr3-v16-snapshot-seed-late-single-goal-wait-diagnostic-v1',
          'passed': code == BENCH.read_bytes() and payload == (EP / 'transitions.jsonl').read_bytes(),
          'scope': 'Only saved snapshot metadata and actual masks. No full raw map/costmap reads, '
                   'no actor/private guard/truth input, no changed source/actions or native rerun. '
                   'Hypothetical legal action existence is not observed Nav2 execution/stop credit.',
          'source_sha256': sha(code), 'transitions_sha256': sha(payload),
          'source_before_after_stable': code == BENCH.read_bytes(),
          'seed_metadata': seeds, 'late_goal_peer_WAIT_options': late,
          'diagnosis': 'Recorded seed_cell_body_clearance rejection supplies the proximate '
                       'candidate-path cause when TB1 reachable target/pool/selected counts are0. '
                       'It is not missing path map or absence of global frontier pool. Snapshot '
                       'metadata alone does not identify whether the nearby occupied cell was '
                       'a real obstacle, map alignment or another cause.',
          'tool_sha256': sha(Path(__file__).read_bytes()), 'wall_seconds': time.monotonic() - started}
with OUTPUT.open('x') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
print(json.dumps({'output': str(OUTPUT), 'sha256': sha(OUTPUT.read_bytes()),
                  'passed': result['passed'],
                  'seeds': [{'elapsed': value['elapsed'],
                             'reason': value['seed_diagnostic_tb1']['seed_rejection_reason'],
                             'clearance': value['seed_diagnostic_tb1']['seed_cell_clearance_m'],
                             'required': value['seed_diagnostic_tb1']['seed_required_clearance_m'],
                             'reachable_targets': value['counts']['per_robot_reachable_target_cells'][0],
                             'pool': value['counts']['geometric_pool_size']}
                            for value in seeds],
                  'late': [{'elapsed': value['elapsed'],
                            'legal_goal_peerWAIT': value['legal_nonapproaching_GOAL_peerWAIT_actions'],
                            'commits_until': value['hypothetical_5sec_commitment_until'],
                            'end_remainder': value['remaining_to_actual_end32_after_5sec']} for value in late]}, indent=2))
raise SystemExit(0 if result['passed'] else 1)
