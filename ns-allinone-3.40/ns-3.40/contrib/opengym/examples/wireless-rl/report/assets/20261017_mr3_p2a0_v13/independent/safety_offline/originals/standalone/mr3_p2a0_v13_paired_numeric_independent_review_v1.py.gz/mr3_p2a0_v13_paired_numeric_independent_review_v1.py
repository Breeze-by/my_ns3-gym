"""Targeted exact-Fraction review of an unchanged pure C++ draft, no native run."""

import ctypes
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import struct


ROOT = Path('/tmp/mr3_paired_wheel_numeric_proposal_v1')
OUTPUT = Path('/tmp/mr3_p2a0_v13_paired_numeric_independent_review_v1.json')
ROWS = Path('/tmp/mr3_p2a0_v12_drive_alpha_original_rows_v1.json')
PATHS = [ROOT / name for name in ('original.hpp', 'proposed.hpp', 'probe.cpp', 'probe.so',
                                  'checks_v2.json', 'explicit_comparisons_v1.json')]
PATHS.append(ROWS)
before = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in PATHS}
receipt = json.loads((ROOT / 'checks_v2.json').read_bytes())
for path in PATHS[:4]:
    assert before[str(path)] == receipt['bindings'][str(path)]
library = ctypes.CDLL(str(ROOT / 'probe.so'))
library.replay.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_double),
                          ctypes.POINTER(ctypes.c_double)]
assert library.long_double_digits() == 64
assert library.rounding_mode() == 0


def replay(values, old):
    inputs = (ctypes.c_double * 6)(*values)
    outputs = (ctypes.c_double * 3)()
    library.replay(old, inputs, outputs)
    return list(outputs)


def exact(values, outputs):
    current, desired, accel, dt = values[:2], values[2:4], values[4], values[5]
    actual, alpha = outputs[:2], outputs[2]
    f = Fraction.from_float
    if accel == 0:
        return {'disabled_semantics_unchanged': actual == desired and alpha == 1.}
    if dt == 0:
        return {'zero_dt_semantics_unchanged': actual == current and alpha == 0.}
    budget = f(accel) * f(dt)
    changes = [abs(f(d) - f(c)) for c, d in zip(current, desired)]
    largest = max(changes)
    nominal = min(Fraction(1), budget / largest) if largest else Fraction(1)
    return {'alpha_inward': 0 <= f(alpha) <= nominal,
            'each_exact_rim_budget': all(abs(f(v) - f(c)) <= budget
                                         for c, v in zip(current, actual)),
            'each_convex_segment': all(min(f(c), f(d)) <= f(v) <= max(f(c), f(d))
                                       for c, d, v in zip(current, desired, actual)),
            'exact_alpha_minus_nominal': str(f(alpha) - nominal)}


cases = []
for item in json.loads(ROWS.read_bytes())['items']:
    event = next(row for row in item['context'] if row['line'] == item['requested_line'])
    assert hashlib.sha256(event['original_line_utf8'].encode()).hexdigest() == \
        event['original_line_sha256']
    row = event['row']
    values = row['current_rim_mps'] + row['desired_rim_mps'] + [
        row['max_acceleration_mps2'], row['dt_sec']]
    old = replay(values, 1)
    assert all(struct.pack('>d', a) == struct.pack('>d', b) for a, b in
               zip(old, row['applied_rim_mps'] + [row['alpha']]))
    cases.append(('actual_line_' + str(item['requested_line']), values))
cases.extend([
    ('fastpath_ld_equality', [-1e-300, 0., .034, 0., 1., .034]),
    ('within_ld_equality', [-1e-300, 0., .068, 0., 1., .034]),
    ('opposite_equality', [1e-300, 0., -.034, 0., 1., .034]),
    ('exact_budget_endpoint', [0., 0., .034, 0., 1., .034]),
    ('zero_delta', [.1, -.2, .1, -.2, 1., .034]),
    ('disabled', [.1, -.2, .3, -.4, 0., .034]),
    ('zero_dt', [.1, -.2, .3, -.4, 1., 0.]),
])
results = []
for name, values in cases:
    old, new = replay(values, 1), replay(values, 0)
    checks = exact(values, new)
    results.append({'case': name, 'inputs': values,
                    'old': {'outputs': old, 'checks': exact(values, old)},
                    'new': {'outputs': new, 'checks': checks}})
    assert all(value for key, value in checks.items() if key != 'exact_alpha_minus_nominal')
after = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in PATHS}
assert before == after
result = {
    'schema': 'mr3-paired-wheel-numeric-independent-review-v1',
    'passed': True,
    'scope': 'Read-only pure finite CPU draft review; not native plant, body bound, '
             'universal-FPU or whole P2A.0 credit. Original formal failures remain unchanged.',
    'source_inputs': before,
    'source_inputs_unchanged': before == after,
    'native_floating_build_observed': {'long_double_digits': 64, 'rounding_mode': 0},
    'review': [
        'On this binary64/x87 extended, round-to-nearest build, stepping the rounded '
        'positive product down produces a conservative lower budget; stepping the '
        'rounded absolute wheel-difference maximum up produces an upper difference.',
        'Thus largest_upper<=budget_lower is a sufficient safe direct-desired fastpath; '
        'the old rounded equality lacked that implication.',
        'The proposed within predicate upper-bounds each rounded subtraction before '
        'comparing with the lower budget; acceptance implies each true binary64 '
        'output-current delta is within the exact binary64 accel*dt product.',
        'Stepping the binary64 fraction down unconditionally removes a possible upward '
        'rounding of the long-double ratio. This relies on the declared native build '
        'precision/rounding contract; no arbitrary compiler/FPU theorem is asserted.',
        'The alpha search keeps one common fraction, begins with exact-safe alpha0, '
        'and tests prospective outputs using the conservative predicate. Disabled '
        'acceleration and zero-dt paths retain their original explicit semantics.',
        'No new blocking numerical counterexample was found in this targeted review; '
        'the author 30085-case receipt was inspected, not rerun or claimed independent.',
        'Actual physical body speed/no-slip/response claims still require their '
        'unchanged independent native consumers; this header fixes arithmetic only.'
    ],
    'targeted_cases': results,
    'targeted_case_count': len(results),
}
OUTPUT.write_text(json.dumps(result, sort_keys=True, indent=2, allow_nan=False) + '\n')
print(json.dumps({'output': str(OUTPUT), 'passed': result['passed'],
                  'targeted_case_count': len(results),
                  'output_sha256': hashlib.sha256(OUTPUT.read_bytes()).hexdigest()}))
