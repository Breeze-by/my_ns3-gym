from pathlib import Path
import json

root=Path('/home/zhuyulab/ns3-workspace')
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
old=w/'report/assets/20261017_mr3_p2a0_v9'
asset=w/'report/assets/20261017_mr3_p2a0_v10'
ind=asset/'independent';ind.mkdir(exist_ok=True)
names=['mr3_p2a0_v9_buildproof_preflight.py','mr3_p2a0_v9_launch_stage.py','mr3_p2a0_v9_plan_launcher_tests_v1.py','mr3_readonly_v9_drive_process_monitor.py','mr3_readonly_v9_process_sampler.py','mr3_readonly_v9_body_live.py','mr3_v9_fifo_phase_review.py','mr3_v9_multiepoch_closure_binary_review_v1.py']
for name in names:
    src=(old/'independent'/name).read_text()
    s=src.replace('mr3_p2a0_v9','mr3_p2a0_v10').replace('mr3-p2a0-predeclaration-v9','mr3-p2a0-predeclaration-v10').replace('predeclared_plan_v9','predeclared_plan_v10').replace('mr3_readonly_v9','mr3_readonly_v10').replace('mr3_v9','mr3_v10').replace('/tmp v9 receipts','/tmp v10 receipts')
    if 'plan_launcher_tests' in name:
        s=s.replace('v9launcher','v10launcher').replace('mr3v9_','mr3v10_')
        s=s.replace("'/tmp/mr3_p2a0_v10_' + b['stage'] + '_information_review_v1.json'", "'/tmp/mr3_p2a0_v10_' + b['stage'] + '_control_review_v1.json'")
        s=s.replace("for b in new['independent_source_bindings'][27:]:", "for b in new['independent_source_bindings'][33:]:")
        s=s.replace("(DRAFT / Path(b['path']).name).read_bytes()", "(ROOT / b['path']).read_bytes()")
        s=s.replace('[(100, 12901), (102, 12911), (104, 12921), (108, 12931)]', '[(110, 13001), (112, 13011), (114, 13021), (118, 13031)]')
        s=s.replace(".replace('mr3_p2a0_v10', 'mr3_p2a0_v8')", ".replace('mr3_p2a0_v10', 'mr3_p2a0_v8')")
        # Existing exact normalization remains a strong unchanged preflight test.
        s=s.replace(".replace('predeclaration-v9', 'predeclaration-v8')", ".replace('predeclaration-v10', 'predeclaration-v8')")
    dst=ind/name.replace('v9','v10')
    assert not dst.exists(),dst
    dst.write_text(s)

plan=json.loads((old/'predeclared_plan_v9.json').read_text())
plan['schema']='mr3-p2a0-predeclaration-v10'
plan['authorization']='continue and complete P2A.0; all v1-v9 originals retained; no pilot'
plan['source_binding']='one new clean pushed reviewed v10 source commit for a complete new matrix; no legacy native PASS assembly; unchanged compiled driver sources/library rechecked against new freeze'
domains=[110,112,114,118];ports=[13001,13011,13021,13031]
for i,stage in enumerate(plan['stages']):
    stage['command']=[v.replace('mr3_p2a0_20261017_v9','mr3_p2a0_20261017_v10') for v in stage['command']]
    for flag,value in [('--base-domain',domains[i]),('--base-port',ports[i])]:
        stage['command'][stage['command'].index(flag)+1]=str(value)
    stage['run_directory']=stage['run_directory'].replace('20261017_v9','20261017_v10')
    stage['required_audit_receipts']=[v.replace('mr3_p2a0_v9','mr3_p2a0_v10') for v in stage['required_audit_receipts']]
    for key in ('settled_turn_audit_command_template','information_audit_command_template'):
        stage[key]=[v.replace('mr3_p2a0_20261017_v9','mr3_p2a0_20261017_v10').replace('/tmp/mr3_p2a0_v9','/tmp/mr3_p2a0_v10') for v in stage[key]]
    stage['information_audit_command_template'][1]=str(ind/'mr3_independent_information_v2.py')
    for j,b in enumerate(stage['worker_bindings']):b['domain']=domains[i]+j;b['port']=ports[i]+j
    stage['required_audits'].append('controlled state publication -> six actual peer callback/obstacle publication -> unique normal guard/self receipt -> native three stored targets -> physics; immutable normal and strict permanent-zero stop; exact one pre-release bootstrap20 with original actual zero takeover/storage; independent peer-only and complete control-chain review')
    for kind in ('peer','control'):
        out='/tmp/mr3_p2a0_v10_'+stage['stage']+'_'+kind+'_review_v1.json'
        stage['required_audit_receipts'].append(out)
        cmd=['/usr/bin/python3',str(ind/'mr3_independent_control_phase_v1.py'),stage['run_directory'],'--freeze','{freeze}','--output',out]
        if kind=='peer':cmd.append('--peer-only')
        stage[kind+'_audit_command_template']=cmd

plan['wall_budget_basis']['scope']='v10 engineering matrix only; pilot balance unchanged; explicit paused DDS phases may change throughput; old v8 figures are budget rationale only'
plan['information_selection_audit'].update(status='ready',producer_fix='actual causal own input selection; stepped explicit20ms publish after takeover; noncontrolled original10Hz and age<=500000000ns remain', cause_limit='v9 native ledger directly proves timer/callback paused starvation; new chain still requires full native validation',source_freeze='one new reviewed pushed v10 commit',consumer=str((ind/'mr3_independent_information_v2.py').relative_to(root)),consumer_sha256='PENDING_FINAL_PIN', tests_sha256='PENDING_FINAL_PIN')
plan['controlled_execution_audit']={'status':'pending','consumer':str((ind/'mr3_independent_control_phase_v1.py').relative_to(root)), 'normal':'one exact clock/request/epoch state publication -> actual main/sixside callbacks -> actual obstacle publication -> actual dependencies received and guard local receipt -> three native actual storage -> evaluator -> positive physics', 'precontrolled':'only original pre-release1ms alignment with actual zero storage and original bounds', 'bootstrap_zero':'exactly one pre-release20ticks after three takeover ACKs and actual oldclock three-zero self-receipt/storage; no fresh geometry, task or safety credit; newclock normal chain before release', 'stop':'permanent zero-only category may increase seq at sameclock; ready=false; dedicated status does not overwrite normal; every shutdown advance still three actual zero storage', 'terminal_drain':'only genuine matching task_terminal permits reuse of last real state commit references without new publication/source-age wash; no LIVE advance', 'wall_guard_seconds':10}
# Original33 bindings preserved exactly; root adds new tool/consumer bindings after finalization.
out=asset/'predeclared_plan_v10.json';assert not out.exists();out.write_text(json.dumps(plan,indent=2)+'\n')
print('v10 tools and prospective plan draft written; not native ready')
