"""Construct a review-only Nav2 profile under /tmp, never the checkout."""
from pathlib import Path
import ast
import copy
import difflib
import hashlib
import json
import pprint
import subprocess

ROOT = Path('/home/zhuyulab/ns3-workspace')
ROS = Path('ros2_ws/ros2-multi-robot-automap')
W = Path('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl')
OUT = Path('/tmp/mr3_p2a0_v13_navigation_profile_draft_v1')
BASE = '6b1b4a0108351f5bfb70ec0c96ba895248d4f7a8'
PROFILE = 'mr3-nav2-shim-dwb-020-v1-draft'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git_bytes(path):
    return subprocess.check_output(['git', 'show', BASE + ':' + str(path)], cwd=ROOT)


def write_new(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)


def patch_one(path, old, new):
    return ''.join(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
        fromfile='a/' + str(path), tofile='b/' + str(path)))


def main():
    OUT.mkdir()
    changes, entries = [], []
    shim = '''      plugin: "nav2_rotation_shim_controller::RotationShimController"
      primary_controller: "dwb_core::DWBLocalPlanner"
      angular_dist_threshold: 0.5
      angular_disengage_threshold: 0.5
      forward_sampling_distance: 0.3
      rotate_to_heading_angular_vel: 0.8
      max_angular_accel: 3.2
      simulate_ahead_time: 1.0
      rotate_to_goal_heading: False
      closed_loop: True
'''
    for robot in ('tb1', 'tb2', 'tb3'):
        path = ROS / 'src/multi_robot/params' / ('nav2_params_' + robot + '_0.yaml')
        raw = git_bytes(path)
        if (ROOT / path).read_bytes() != raw:
            raise ValueError('current source differs from V12 freeze: ' + str(path))
        old = raw.decode()
        new = old
        replacements = {
            '    # DWB parameters\n': '    # Rotation Shim delegates path tracking to the existing DWB controller.\n',
            '      plugin: "dwb_core::DWBLocalPlanner"\n': shim,
            '      max_vel_x: 0.26\n': '      max_vel_x: 0.20\n',
            '      max_speed_xy: 0.26\n': '      max_speed_xy: 0.20\n',
            '      acc_lim_x: 2.5\n': '      acc_lim_x: 0.5\n',
            '      decel_lim_x: -2.5\n': '      decel_lim_x: -0.5\n',
            '      # Add high threshold velocity for turtlebot 3 issue.\n      # https://github.com/ROBOTIS-GIT/turtlebot3_simulations/issues/75\n': '      # Match the explicitly configured smoother body-command acceleration.\n',
            '    max_velocity: [0.26, 0.0, 0.8]\n': '    max_velocity: [0.20, 0.0, 0.8]\n',
            '    min_velocity: [-0.26, 0.0, -0.8]\n': '    min_velocity: [-0.20, 0.0, -0.8]\n    max_accel: [0.5, 0.0, 3.2]\n    max_decel: [-0.5, 0.0, -3.2]\n',
        }
        for before, after in replacements.items():
            if new.count(before) != 1:
                raise ValueError('nonunique edit ' + repr(before) + ' in ' + str(path))
            new = new.replace(before, after)
        write_new(OUT / path.name, new.encode())
        changes.append(patch_one(path, old, new))
        entries.append({'path': str(path), 'base_sha256': sha(raw), 'draft_sha256': sha(new.encode()),
                        'draft': str(OUT / path.name)})
    path = ROS / 'src/multi_robot/package.xml'
    raw = git_bytes(path)
    old = raw.decode()
    before = '  <exec_depend>navigation2</exec_depend>\n'
    if old.count(before) != 1:
        raise ValueError('dependency anchor not unique')
    new = old.replace(before, before + '  <exec_depend>nav2_rotation_shim_controller</exec_depend>\n')
    write_new(OUT / 'package.xml', new.encode())
    changes.append(patch_one(path, old, new))
    entries.append({'path': str(path), 'base_sha256': sha(raw), 'draft_sha256': sha(new.encode()),
                    'draft': str(OUT / 'package.xml')})

    old_path = W / 'report/assets/20261017_mr3_p2a0_v4/independent/mr3_actual_nav2_parameters_v4.py'
    raw = git_bytes(old_path)
    old = raw.decode()
    tree = ast.parse(old)
    expected = ast.literal_eval(next(node.value for node in tree.body
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'EXPECTED' for t in node.targets)))
    expected = copy.deepcopy(expected)
    controller = expected['controller_server']
    controller['FollowPath.max_vel_x'] = (3, .20)
    controller['FollowPath.max_speed_xy'] = (3, .20)
    controller.update({
        'controller_frequency': (3, 10.),
        'controller_plugins': (9, ['FollowPath']),
        'FollowPath.plugin': (4, 'nav2_rotation_shim_controller::RotationShimController'),
        'FollowPath.primary_controller': (4, 'dwb_core::DWBLocalPlanner'),
        'FollowPath.angular_dist_threshold': (3, .5),
        'FollowPath.angular_disengage_threshold': (3, .5),
        'FollowPath.forward_sampling_distance': (3, .3),
        'FollowPath.rotate_to_heading_angular_vel': (3, .8),
        'FollowPath.max_angular_accel': (3, 3.2),
        'FollowPath.simulate_ahead_time': (3, 1.),
        'FollowPath.rotate_to_goal_heading': (1, False),
        'FollowPath.closed_loop': (1, True),
        'FollowPath.acc_lim_x': (3, .5),
        'FollowPath.decel_lim_x': (3, -.5),
        'FollowPath.acc_lim_theta': (3, 3.2),
        'FollowPath.decel_lim_theta': (3, -3.2),
        'FollowPath.min_speed_xy': (3, 0.),
        'FollowPath.min_speed_theta': (3, 0.),
        'FollowPath.critics': (9, ['RotateToGoal', 'Oscillation', 'BaseObstacle', 'GoalAlign', 'PathAlign', 'PathDist', 'GoalDist']),
        'FollowPath.BaseObstacle.scale': (3, .02),
        'FollowPath.PathAlign.scale': (3, 32.),
        'FollowPath.PathAlign.forward_point_distance': (3, .1),
        'FollowPath.GoalAlign.scale': (3, 24.),
        'FollowPath.GoalAlign.forward_point_distance': (3, .1),
        'FollowPath.PathDist.scale': (3, 32.),
        'FollowPath.GoalDist.scale': (3, 24.),
        'FollowPath.RotateToGoal.scale': (3, 32.),
        'FollowPath.RotateToGoal.slowing_factor': (3, 5.),
        'FollowPath.RotateToGoal.lookahead_time': (3, -1.),
        'goal_checker.xy_goal_tolerance': (3, .10),
        'goal_checker.yaw_goal_tolerance': (3, 3.14),
        'progress_checker.required_movement_radius': (3, .15),
        'progress_checker.movement_time_allowance': (3, 15.),
    })
    smoother = expected['velocity_smoother']
    smoother['max_velocity'] = (8, [.20, 0., .8])
    smoother['min_velocity'] = (8, [-.20, 0., -.8])
    smoother['max_accel'] = (8, [.5, 0., 3.2])
    smoother['max_decel'] = (8, [-.5, 0., -3.2])
    a, b = old.index('EXPECTED = {'), old.index('\n\ndef require')
    new = old[:a] + 'PROFILE = ' + repr(PROFILE) + '\nEXPECTED = ' + pprint.pformat(expected, sort_dicts=False, width=98) + '\nTYPE_FIELDS = {1: "bool_value", 3: "double_value", 4: "string_value",\n               8: "double_array_value", 9: "string_array_value"}\n' + old[b:]
    new = new.replace('if kind == 8:\n            value = list(value)', 'if kind in (8, 9):\n            value = list(value)\n        if kind == 9:\n            require(all(type(item) is str for item in value), name + ": nonstring array")')
    new = new.replace('Node("mr3_actual_nav2_parameters",', 'Node("mr3_actual_nav2_parameters_v13",')
    new = new.replace('"schema": "mr3-actual-nav2-parameter-readback-v1", "passed": False,', '"schema": "mr3-actual-nav2-parameter-readback-v2", "profile": PROFILE, "passed": False,')
    write_new(OUT / 'mr3_actual_nav2_parameters_v13_draft.py', new.encode())
    spec = {'scope': 'proposed typed expectations only; no service was called', 'profile': PROFILE,
            'nodes': ['/' + r + '/' + k for r in ('tb1', 'tb2', 'tb3') for k in expected],
            'expected_typed_parameters': expected, 'old_immutable_script': str(old_path),
            'old_immutable_script_sha256': sha(raw), 'old_script_changed': False,
            'draft_sha256': sha(new.encode()),
            'new_path_proposal': str(W / 'report/assets/20261017_mr3_p2a0_v13/independent/mr3_actual_nav2_parameters_v13.py'),
            'required_hook_change': 'root must version the fixed readback script path/hash in benchmark; preserve same frozen-Git and transport environment checks; old v4 bytes stay immutable'}
    write_new(OUT / 'actual9_readback_spec_v1.json', (json.dumps(spec, indent=2, allow_nan=False) + '\n').encode())
    changes.append(patch_one(Path('review-only/readback-v4-to-v13.py'), old, new))
    write_new(OUT / 'navigation_profile_v1.patch', ''.join(changes).encode())
    manifest = {'schema': 'mr3-navigation-profile-draft-v1', 'status': 'review_only_not_applied_not_executed', 'base_freeze': BASE,
                'profile': PROFILE, 'sources': entries,
                'readback_source_sha256': spec['old_immutable_script_sha256'],
                'generator_sha256': sha(Path(__file__).read_bytes()),
                'git_files_modified': False, 'ros_initialized': False, 'native_experiment_started': False}
    write_new(OUT / 'manifest_v1.json', (json.dumps(manifest, indent=2, allow_nan=False) + '\n').encode())
    print(json.dumps({'out': str(OUT), 'source_files': len(entries), 'profile': PROFILE}))


if __name__ == '__main__':
    main()
