"""Read-only current V15 source/math/binary readiness; never native admission."""
import ast
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import time

R = Path('/home/zhuyulab/ns3-workspace')
WP = 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
RP = 'ros2_ws/ros2-multi-robot-automap/'
W = R / WP
A = W / 'report/assets/20261017_mr3_p2a0_v15'
BASE = 'f7376d02b12da00c4bf44754c4b976c9fcf2b20c'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
started = time.monotonic()
observed = {}
def capture(relative):
    raw = (R / relative).read_bytes()
    digest = sha(raw)
    assert relative not in observed or observed[relative] == digest, relative
    observed[relative] = digest
    return raw
def old(relative):
    return subprocess.check_output(['git', 'show', BASE + ':' + relative], cwd=R)
def constants(raw):
    result = {}
    def value(node):
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Name):
            return {'ROS': RP, 'WIRELESS': WP}[node.id]
        assert isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add)
        return value(node.left) + value(node.right)
    for node in ast.parse(raw).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1:
            name = getattr(node.targets[0], 'id', None)
            if name in ('ENV_DOCUMENT_SHA256',):
                result[name] = value(node.value)
            if name in ('EVALUATOR_PHASE_PINS', 'PREPARATION_RUNTIME_PINS', 'EXECUTION_CONFIG_PINS'):
                result[name] = {value(k): value(v) for k, v in zip(node.value.keys, node.value.values)}
    return result
plan_path = str((A / 'predeclared_plan_v15.json').relative_to(R))
plan = json.loads(capture(plan_path))
assert plan['readiness']['status'] == 'ready' and not plan['readiness']['pending_bindings']
assert not plan['new_source_bindings_pending']
previous = json.loads(old(WP + 'report/assets/20261017_mr3_p2a0_v14/predeclared_plan_v14.json'))
bindings = {b['path']: b['sha256'] for b in plan['independent_source_bindings']}
prior = {b['path']: b['sha256'] for b in previous['independent_source_bindings']}
assert len(bindings) == len(plan['independent_source_bindings']) == 121
for path, digest in bindings.items():
    assert sha(capture(path)) == digest, path
changed = {p for p, digest in prior.items() if bindings[p] != digest}
assert changed == {WP + 'mr3_learning/audit_ppo.py', WP + 'mr3_learning/audit_preparation.py'}
for name in ('unchanged_gates', 'physical_response_criteria', 'settled_turn_criteria',
             'angular_interface_criteria', 'angular_reset_criteria',
             'full_execution_model_failfast', 'pilot_budget_unchanged',
             'max_api_records', 'max_submitted_script_decisions', 'max_total_wall_seconds'):
    assert plan[name] == previous[name], name
assert [s['stage'] for s in plan['stages']] == ['interface', 'terminal', 'reset', 'deadline']
for stage, prior_stage in zip(plan['stages'], previous['stages']):
    assert stage['required_audit_receipts'] == [p.replace('v14', 'v15') for p in prior_stage['required_audit_receipts']]
    expected = [p.replace('v14', 'v15') for p in prior_stage['command']]
    if stage['stage'] in ('interface', 'reset'):
        expected[expected.index('--preparation-probe-version') + 1] = 'mr3-p2a0-outward-cancel-v4'
    assert stage['command'] == expected
source = WP + 'mr3_learning/audit_ppo.py'
current, original = capture(source), old(source)
values, old_values = constants(current), constants(original)
pins = {}
for group in ('EVALUATOR_PHASE_PINS', 'PREPARATION_RUNTIME_PINS', 'EXECUTION_CONFIG_PINS'):
    for path, digest in values[group].items():
        assert path not in pins and sha(capture(path)) == digest
        pins[path] = digest
assert len(pins) == 36
assert sha(capture(WP + 'MR3_ENV_CONTRACT.md')) == values['ENV_DOCUMENT_SHA256']
control = RP + 'src/multi_robot_exploration/multi_robot_exploration/control.py'
restored = current.decode().replace(values['ENV_DOCUMENT_SHA256'], old_values['ENV_DOCUMENT_SHA256'])
restored = restored.replace(pins[control], old_values['PREPARATION_RUNTIME_PINS'][control])
assert ast.dump(ast.parse(restored), include_attributes=False) == ast.dump(ast.parse(original), include_attributes=False)
source = WP + 'mr3_learning/audit_preparation.py'
restored = capture(source).decode().replace('PREPARATION_PROBE_V4 = "mr3-p2a0-outward-cancel-v4"\n', '')
restored = restored.replace('v2/v3/v4 fixtures', 'v2/v3 fixtures')
restored = restored.replace('(PREPARATION_PROBE_VERSION, PREPARATION_PROBE_V3, PREPARATION_PROBE_V4)', '(PREPARATION_PROBE_VERSION, PREPARATION_PROBE_V3)')
restored = restored.replace('version in (PREPARATION_PROBE_V3, PREPARATION_PROBE_V4)', 'version == PREPARATION_PROBE_V3')
assert ast.dump(ast.parse(restored), include_attributes=False) == ast.dump(ast.parse(old(source)), include_attributes=False)
source = WP + 'mr3_learning/benchmark.py'
functions = lambda raw: {n.name: ast.dump(n, include_attributes=False) for n in ast.parse(raw).body if isinstance(n, ast.FunctionDef)}
now, before = functions(capture(source)), functions(old(source))
for name in ('_probe_goal_order', 'probe_action', 'probe_action_v3', '_new_preparation_abort', '_abort_requested', '_preparation_failure'):
    assert now[name] == before[name], name
runtime = json.loads(Path('/tmp/mr3_p2a0_v14_source_preflight.json').read_bytes())['source_bindings']
assert len(runtime) == 101
runtime_changes = {p for p, value in runtime.items() if sha(capture(p)) != value['sha256']}
assert runtime_changes == {control, WP + 'MR3_ENV_CONTRACT.md', WP + 'mr3_learning/audit_ppo.py', WP + 'mr3_learning/audit_preparation.py', WP + 'mr3_learning/benchmark.py'}
receipt = plan['drive_contract']['binary_build_receipt']
raw = capture(receipt['path'])
assert sha(raw) == receipt['sha256'] and raw == old(receipt['path'])
build = json.loads(raw)
library = Path(build['library_path']).read_bytes()
assert sha(library) == build['library_sha256'] and Path(build['installed_path']).read_bytes() == library
assert Path(build['installed_path']).resolve() == Path(build['library_path']).resolve()
assert gzip.decompress(capture(build['archived_library_gzip'])) == library
for key in ('compiled_source_sha256', 'compiled_header_sha256', 'compiled_helper_sha256', 'compiled_target_contract_sha256'):
    assert build[key].encode() in library
for path, digest in observed.items():
    assert sha((R / path).read_bytes()) == digest, path
result = dict(passed=True, source_readiness_only=True, native_admission=False,
              base_commit=BASE, plan_sha256=sha((R / plan_path).read_bytes()),
              binding_count=121, prior_unchanged=103, authorized_changed_bindings=sorted(changed),
              appended_bindings=16, runtime_paths=101, runtime_changed_paths=sorted(runtime_changes),
              pins=36, audit_ppo_two_digest_only_whole_AST=True,
              audit_preparation_V4_qualification_only_whole_AST=True,
              six_legacy_probe_abort_functions_AST_unchanged=True,
              hard_gates_and_budget_unchanged=True, actual_library_sha256=sha(library),
              source_before=observed, source_after=observed,
              wall_seconds=time.monotonic() - started, script_sha256=sha(Path(__file__).read_bytes()))
output = Path('/tmp/mr3_p2a0_v15_final_source_review_v1.json')
with output.open('x') as stream:
    stream.write(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ('passed', 'plan_sha256', 'binding_count', 'runtime_paths', 'pins', 'wall_seconds')}))
