"""Read-only source dependency review; no ROS initialization or runtime control."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
FREEZE = '6b1b4a0108351f5bfb70ec0c96ba895248d4f7a8'
BASE = 'ros2_ws/ros2-multi-robot-automap/'
paths = [BASE + 'scripts/mr3_env_worker.py'] + [BASE + 'src/multi_robot_exploration/multi_robot_exploration/' + name for name in ('task_evaluator.py', 'mr3_evaluator_phase.py', 'mr3_motion_control.py', 'motion_safety.py')]
sha = lambda b: hashlib.sha256(b).hexdigest()
captured = {name: (ROOT / name).read_bytes() for name in paths}
bindings = []
for name, raw in captured.items():
    old = subprocess.run(['git', 'show', FREEZE + ':' + name], cwd=ROOT, capture_output=True, check=True).stdout
    bindings.append({'path': name, 'sha256': sha(raw), 'frozen_sha256': sha(old), 'matches_reference_freeze': raw == old})
result = {
 'schema': 'mr3-control-model-failure-dependency-review-v1',
 'reference_freeze': FREEZE, 'wall_monotonic_ns': time.monotonic_ns(),
 'scope': 'Independent read-only architecture/source review. No source edit, ROS initialization, native run, gate change, actual body model validation or runtime credit.',
 'source_bindings': bindings,
 'observed_current_chain': [
  'step: consumed LIVE evaluator ACK(T-20ms) -> _physics(20)',
  '_physics: actual native 20-tick receipt -> exact /clock T -> _commit_boundary(T)',
  '_commit_boundary: actual state commit(T) -> peer commit(T) -> motion commit(T) -> local self receipt -> three native target storage ACKs',
  'step: _evaluator_phase(T) -> actual LIVE/TERMINAL -> next physics or terminal snapshot/reward',
  'reset: unique bootstrap zero -> state/peer/motion(T1) -> snapshot/release/reward sequence0 -> initial evaluator LIVE; no valid evaluator phase exists before release+reward binding',
  'cleanup: permanent stop path bypasses normal geometry/input readiness, obtains actual zero storage and may advance only closure ticks outside task/reward time'
 ],
 'actual_evaluator_dependency': {
  'request_callback': 'TaskEvaluator._evaluator_phase_callback is serialized on its own SingleThreadedExecutor. It checks actual evaluator clock, bound released reward task, and its already frozen terminal.',
  'not_a_producer_barrier': 'No received_states/side-odom/state-phase/peer-phase subscription or callback watermark drain in current TaskEvaluator. Its maps, contact, model-state, action-status and failure callbacks are independent DDS inputs.',
  'consequence': 'Moving evaluator before the whole state/peer publication stage neither proves those callbacks arrived nor preserves their existing wall order. A publication call return is not another process callback completion.'
 },
 'recommended_minimal_option': 'b: preserve all normal happy-path order; add a narrow explicit execution-model-invalid path from guard to worker, not a generic readiness timeout.',
 'recommended_exception_chain': [
  'At paused T, state and peer commits remain real and unchanged. Guard identifies fresh latest-causal own raw full-norm bound violation with original source stamp/input sequence and publishes only permanent zero targets plus explicit structured model-invalid ACK.',
  'Worker must not issue normal advance or wait ten wall seconds for impossible readiness. It records the specific fault and obtains real local zero self receipts and three native zero-storage ACKs at T.',
  'Only when reset/reward initialization already completed, worker obtains the real evaluator phase at the same paused T to distinguish a still-live task from an already-real terminal; no physics while classifying.',
  'If LIVE: explicit infrastructure invalid sample and ordered abort; no fabricated reward/terminal transition. If actual TERMINAL: retain original terminal/end/source times; classify whether raw offending source belongs to [release,end] or is strictly after terminal. Never relabel a task-time bound violation as cleanup, nor create a task sample from postterminal data.',
  'Before release: no evaluator phase request (it is invalid before bound reward task); preserve failed-reset/zero reward/ordered infra abort. During already stopped cleanup: no new normal input qualification or fake LIVE request.'
 ],
 'necessary_interface_cautions': [
  'Current receive_control_phase immediately raises on generic ok=False, making callback_error sticky. Subsequent _evaluator_phase waits call _healthy and cannot run. A narrowly typed model-invalid deferred classification must be explicit; ordinary negative ACK/timeout remains sticky failure.',
  'Current MotionSafety halted path publishes /exploration_failure; TaskEvaluator maps this to actual navigation_failure immediately. An execution-model fault cannot use that generic task-failure publication before the independent classification or it fabricates the very terminal being tested.',
  'A deliberate phase_kind=stop remains actual zero and no safety/task credit. It must not overwrite the immutable normal same-clock status.',
  'All raw physical failures remain FAIL evidence. None of this weakens .30/1.2/7/.78/.144 or produces new training authorization.'
 ],
 'alternative_a': {
  'chain': 'state -> peer -> evaluator/recorder exact-input receipt barrier -> guard/storage -> next physics',
  'valid_only_if': 'A new recorder/evaluator really requires producer(T) information and acknowledges actual callback watermarks. Do not infer that from publication return.',
  'cost': 'Changes every normal boundary, startup/evaluator pending target semantics and immutable consumer order; larger than needed for an exceptional model-invalid cause. Not recommended solely to eliminate the explicit guard negative.'
 },
 'unproven': ['No current source-level recorder phase requiring state/peer inputs was found in TaskEvaluator; a future dedicated recorder must state its own dependencies.', 'This is not an inter-process atomic-stop theorem or proof of native plant bounds. Existing DDS in-flight/20ms/160ms limitations remain.'],
 'source_bytes_unchanged_during_review': all((ROOT / name).read_bytes() == raw for name, raw in captured.items())
}
output = Path('/tmp/mr3_p2a0_v13_control_model_failure_dependency_review_v1.json')
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'output':str(output),'sha256':sha(output.read_bytes()),'source_bindings':bindings,'unchanged':result['source_bytes_unchanged_during_review']}))
