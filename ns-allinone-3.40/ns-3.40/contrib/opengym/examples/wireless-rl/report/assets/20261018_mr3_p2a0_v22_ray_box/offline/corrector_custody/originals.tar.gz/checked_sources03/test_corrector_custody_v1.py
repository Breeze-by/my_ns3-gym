#!/usr/bin/python3
"""Pure fake-/proc and closed-byte mutations; no native/ROS/loader is invoked."""
import copy
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest

SOURCE = Path(__file__).with_name('mr3_v22_corrector_custody_v1.py')
spec = importlib.util.spec_from_file_location('corrector_custody', SOURCE)
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
F = 'a' * 40


def dump(path, value):
    path.write_text(json.dumps(value, allow_nan=False) + '\n')


def encode(rows):
    return b''.join(h.canonical(row) + b'\n' for row in rows)


class CustodyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='mr3_v22_corrector_CPU_')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.run = self.root / 'run'
        self.ep = self.run / 'worker0/episode001_open_101'
        self.ep.mkdir(parents=True)
        self.proc = self.root / 'proc'
        self.proc.mkdir()
        self.prefix = self.root / 'stage'
        self.epoch = 'fixture_w0_e1'
        self.worker = {'pid': 100, 'parent': 50, 'start_ticks': 10, 'state': 'S'}
        self.launch = {'pid': 200, 'parent': 100, 'start_ticks': 20, 'state': 'S'}
        self.gz = {'pid': 300, 'parent': 200, 'start_ticks': 30, 'state': 'S'}
        for identity in [self.worker, self.launch, self.gz]:
            directory = self.proc / str(identity['pid'])
            directory.mkdir()
            fields = ['R', str(identity['parent'])] + ['0'] * 17 + [str(identity['start_ticks'])] + ['0'] * 8
            (directory / 'stat').write_text(str(identity['pid']) + ' (fake CPU process) ' + ' '.join(fields) + '\n')
        self.argv = ['/usr/bin/python3', str(h.WORKER), '--run-dir', str(self.ep)]
        (self.proc / '100/cmdline').write_bytes(('\0'.join(self.argv) + '\0').encode())
        self.sources = {}
        for index, key in enumerate(h.SOURCE_FIELDS):
            source = self.root / ('source' + str(index) + '.txt')
            source.write_text('explicit CPU fixture source' + str(index))
            self.sources[key] = {'path': str(source), 'sha256': h.sha(source.read_bytes())}
        self.library = self.root / 'fake_corrector.so'
        self.library.write_bytes(b'\x7fELF CPU fixture no load ' + b' '.join(v['sha256'].encode() for v in self.sources.values()))
        self.ode = self.root / 'fake_ode.so'
        self.ode.write_bytes(b'\x7fELF CPU fixture original ODE bytes')
        def library(path):
            return {'path': str(path), 'resolved': str(path.resolve()), 'sha256': h.sha(path.read_bytes()), 'bytes': path.stat().st_size}
        self.binding = {'schema': 'mr3-ray-box-corrector-binding-v1', 'status': 'ready',
            'monitor': {'path': str(h.MONITOR), 'sha256': h.MONITOR_SHA},
            'library': library(self.library), 'ode_library': library(self.ode),
            'sources': self.sources, 'ledger_filename': 'ray_box_corrector.jsonl',
            'world_names': {'open': 'p1c_open', 'rooms': 'p1c_rooms', 'corridors': 'p1c_corridors'}}
        receipt_path = self.root / 'binary_receipt.json'
        names = dict(zip(h.SOURCE_FIELDS, ('src/mr3_ray_box_corrector.cpp',
                     'src/mr3_ray_box_collision.cpp', 'include/multi_robot/mr3_ray_box_collision.hpp')))
        receipt = {'schema': 'mr3-v22-ray-box-actual-binary-custody-v1', 'passed': True,
                   'installed_library': self.binding['library'], 'actual_ode_library': self.binding['ode_library'],
                   'sources': {names[key]: value for key, value in self.sources.items()}}
        dump(receipt_path, receipt)
        self.binding['binary_receipt'] = {'path': str(receipt_path), 'sha256': h.sha(receipt_path.read_bytes())}
        self.binding_path = self.root / 'binding.json'
        dump(self.binding_path, self.binding)
        self.map_rows = []
        for i, path in enumerate([self.library, self.ode]):
            stat = path.stat()
            self.map_rows.append('%x-%x r-xp 00000000 %02x:%02x %d %s' % (
                4096 * (i + 1), 4096 * (i + 2), os.major(stat.st_dev), os.minor(stat.st_dev), stat.st_ino, path.resolve()))
        self.maps_path = self.proc / '300/maps'
        self.maps_path.write_text('\n'.join(self.map_rows) + '\n')
        dump(self.ep / 'metadata.json', {'freeze': F, 'epoch': self.epoch, 'scene': 'open'})
        dump(self.ep / 'supervisor_metadata.json', {'epoch': self.epoch, 'worker_identity': self.worker})
        dump(self.ep / 'supervisor_shutdown.json', {'epoch': self.epoch, 'worker_returncode': 0,
            'forced_shutdown': False, 'failed_sample': False, 'remaining_owned_processes': [],
            'remaining_owned_zombies': [], 'owned_processes_seen': [self.worker, self.launch, self.gz]})
        self.monitor = {'schema': 'mr3-v9-readonly-drive-mapping-monitor-v1', 'freeze': F, 'errors': [],
            'episodes': [{'directory': str(self.ep)}],
            'owned_current_processes': [{'identity': identity} for identity in [self.worker, self.launch, self.gz]],
            'gazebo_mapped_libraries': [{'identity': self.gz, 'new_drive_mapped': True,
                'old_system_drive_mapped': False, 'identity_still_same_after_maps': True,
                'mappings': [{'matches_declared_binary': True}]}],
            'shim_mapping': {'producer_source': str(h.MONITOR), 'producer_source_sha256': h.MONITOR_SHA,
                'episodes': [{'directory': str(self.ep), 'epoch': self.epoch, 'active_worker': True,
                    'complete': True, 'worker_identity': self.worker, 'worker_actual_argv': self.argv}]}}
        self.monitor_path = self.root / 'monitor.json'
        dump(self.monitor_path, self.monitor)
        common = {'schema': 'mr3-ray-box-corrector-audit-v1', 'epoch': self.epoch, 'process_id': 300}
        self.config = dict(common, kind='configuration', plugin_type='SystemPlugin',
                           loaded_library_path=str(self.library.resolve()), actual_ode_library_path=str(self.ode.resolve()),
                           **{key: value['sha256'] for key, value in self.sources.items()})
        install = dict(common, kind='installed', world='p1c_open', world_clock_ns=0,
                       world_iterations=0, registered_pair=['dRayClass', 'dBoxClass'],
                       native_ode_quickstep_iterations=150, physics_max_step_size_sec=.001)
        counts = {'callback_calls': 20, 'hits': 2, 'misses': 18, 'nonzero_nearparallel_calls': 1, 'callback_errors': 0}
        self.rows = [self.config, install,
                     dict(common, kind='plugin_destructor_snapshot', **counts),
                     dict(common, kind='process_lifetime_summary', **counts)]
        self.ledger = self.ep / 'ray_box_corrector.jsonl'
        self.ledger.write_bytes(encode(self.rows))

    def observe(self):
        reader = h.Reader()
        result = h.observe(self.monitor_path, self.binding_path, F, reader, proc_root=self.proc)
        reader.finish()
        return result

    def full_review(self):
        proof = self.observe()
        self.assertTrue(proof['passed'], proof)
        dump(Path(str(self.prefix) + '_corrector_mapping_001.json'), proof)
        reader = h.Reader()
        result = h.review(self.run, self.prefix, F, self.binding_path, reader)
        reader.finish()
        return result

    def ledger_review(self, rows=None):
        return h.ledger_review(encode(self.rows if rows is None else rows), self.binding,
            self.epoch, 300, 'p1c_open', h.sha(encode([self.config])))

    def test_positive_R_S_changes_and_optional_outside_branch_absent(self):
        result = self.full_review()
        self.assertTrue(result['passed'])
        self.assertEqual(len(result['episodes']), 1)
        self.assertIsNone(result['episodes'][0]['review']['first_outside_nearparallel_toward_slab'])

    def test_library_inode_mapping_mismatch(self):
        parts = self.map_rows[0].split(None, 5)
        parts[4] = str(int(parts[4]) + 1)
        self.maps_path.write_text(' '.join(parts) + '\n' + self.map_rows[1] + '\n')
        self.assertFalse(self.observe()['passed'])

    def test_only_nonexecutable_mapping_rejected(self):
        self.maps_path.write_text(self.maps_path.read_text().replace('r-xp', 'r--p'))
        self.assertFalse(self.observe()['passed'])

    def test_PID_reuse_and_other_worker_cannot_be_borrowed(self):
        for pid in (100, 300):
            path = self.proc / str(pid) / 'stat'
            original = path.read_text()
            fields = original[original.rfind(')') + 2:].split()
            fields[19] = '999'
            path.write_text(str(pid) + ' (fake) ' + ' '.join(fields))
            self.assertFalse(self.observe()['passed'])
            path.write_text(original)

    def test_wrong_worker_actual_argv(self):
        (self.proc / '100/cmdline').write_bytes(('\0'.join(self.argv[:-1] + ['/other/episode']) + '\0').encode())
        self.assertFalse(self.observe()['passed'])

    def test_config_wrong_macro_or_PID(self):
        for key, value in [('process_id', True), ('compiled_source_sha256', '0' * 64)]:
            rows = copy.deepcopy(self.rows)
            rows[0][key] = value
            self.ledger.write_bytes(encode(rows))
            self.assertFalse(self.observe()['passed'])
        self.ledger.write_bytes(encode(self.rows))

    def test_pending_binding_or_actual_ELF_changed(self):
        self.binding['status'] = 'pending'
        dump(self.binding_path, self.binding)
        with self.assertRaises(ValueError):
            self.observe()
        self.binding['status'] = 'ready'
        dump(self.binding_path, self.binding)
        self.library.write_bytes(self.library.read_bytes() + b'changed')
        with self.assertRaises(ValueError):
            self.observe()

    def test_source_mutation_rejected(self):
        Path(self.sources[h.SOURCE_FIELDS[0]]['path']).write_text('changed source')
        with self.assertRaises(ValueError):
            self.observe()

    def test_missing_or_partial_final_summary(self):
        with self.assertRaises(ValueError):
            self.ledger_review(self.rows[:-1])
        with self.assertRaises(ValueError):
            h.ledger_review(encode(self.rows)[:-1], self.binding, self.epoch, 300,
                            'p1c_open', h.sha(encode([self.config])))

    def test_unknown_epoch_error_and_typed_counter(self):
        for index, key, value in [(2, 'epoch', 'other'), (3, 'callback_errors', 1),
                                  (3, 'callback_calls', True), (3, 'callback_calls', 0)]:
            rows = copy.deepcopy(self.rows)
            rows[index][key] = value
            with self.assertRaises(ValueError):
                self.ledger_review(rows)

    def test_native_installed_readback_and_typed_zero(self):
        for key, value in [('native_ode_quickstep_iterations', 50),
                           ('native_ode_quickstep_iterations', 150.0),
                           ('physics_max_step_size_sec', .002),
                           ('world_iterations', False), ('world_clock_ns', False)]:
            rows = copy.deepcopy(self.rows)
            rows[1][key] = value
            with self.assertRaises(ValueError):
                self.ledger_review(rows)

    def test_final_ledger_changed_from_actual_mapped_header(self):
        proof = self.observe()
        dump(Path(str(self.prefix) + '_corrector_mapping_001.json'), proof)
        rows = copy.deepcopy(self.rows)
        rows[0]['epoch'] = 'false'
        self.ledger.write_bytes(encode(rows))
        with self.assertRaises(ValueError):
            h.review(self.run, self.prefix, F, self.binding_path, h.Reader())

    def test_mapping_cannot_relabel_another_episode(self):
        proof = self.observe()
        proof['episodes'][0]['worker_identity']['start_ticks'] += 1
        dump(Path(str(self.prefix) + '_corrector_mapping_001.json'), proof)
        with self.assertRaises(ValueError):
            h.review(self.run, self.prefix, F, self.binding_path, h.Reader())

    def test_false_returncode_not_integer_zero(self):
        proof = self.observe()
        dump(Path(str(self.prefix) + '_corrector_mapping_001.json'), proof)
        path = self.ep / 'supervisor_shutdown.json'
        shutdown = json.loads(path.read_bytes())
        shutdown['worker_returncode'] = False
        dump(path, shutdown)
        with self.assertRaises(ValueError):
            h.review(self.run, self.prefix, F, self.binding_path, h.Reader())

    def test_fatal_callback_event_cannot_be_hidden_by_zero_counters(self):
        rows = copy.deepcopy(self.rows)
        rows.insert(2, dict(rows[-1], kind='fatal_callback_input_error'))
        with self.assertRaises(ValueError):
            self.ledger_review(rows)
        rows = copy.deepcopy(self.rows)
        rows[0]['schema'] = 'unknown'
        self.ledger.write_bytes(encode(rows))
        self.assertFalse(self.observe()['passed'])

    def test_optional_primitive_NaN_or_bool_is_not_measurement(self):
        primitive = dict(self.config, kind='first_actual_callback',
            start_box_local=[0., 0., 0.], direction_box_local=[1., 0., 0.],
            box_lengths=[1., 1., 1.], ray_start_world=[0., 0., 0.],
            ray_direction_world=[1., 0., 0.], box_rotation=[0.] * 12,
            finite_ray_length=1., corrected_hit=False, corrected_depth=None,
            corrected_axis=None, ray_body_is_null=True, published_world_clock_ns=1)
        rows = copy.deepcopy(self.rows)
        rows.insert(2, primitive)
        self.ledger_review(rows)
        for invalid in [float('nan'), True]:
            rows[2]['direction_box_local'][1] = invalid
            raw = b''.join(json.dumps(row, allow_nan=True).encode() + b'\n' for row in rows)
            with self.assertRaises(ValueError):
                h.ledger_review(raw, self.binding, self.epoch, 300, 'p1c_open', h.sha(encode([self.config])))

    def test_old_snapshot_cannot_be_relabelled_even_if_SHA_updated(self):
        proof = self.observe()
        self.monitor['shim_mapping']['episodes'][0]['directory'] = '/other/episode'
        dump(self.monitor_path, self.monitor)
        proof['monitor']['sha256'] = h.sha(self.monitor_path.read_bytes())
        dump(Path(str(self.prefix) + '_corrector_mapping_001.json'), proof)
        with self.assertRaises(ValueError):
            h.review(self.run, self.prefix, F, self.binding_path, h.Reader())

    def test_binary_receipt_is_required_and_rechecked(self):
        receipt = Path(self.binding['binary_receipt']['path'])
        receipt.write_bytes(receipt.read_bytes() + b'changed')
        with self.assertRaises(ValueError):
            self.observe()

    def test_repeat_reader_detects_source_replacement(self):
        reader = h.Reader()
        reader(self.binding_path)
        self.binding_path.write_bytes(self.binding_path.read_bytes() + b' ')
        with self.assertRaises(ValueError):
            reader(self.binding_path)


if __name__ == '__main__':
    unittest.main()
