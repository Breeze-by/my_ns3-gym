"""Closed V19 received snapshots/typed commands and exact map provenance only."""
import ast
import copy
import datetime
import gzip
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
import numpy as np

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
BASE = ROOT / 'ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0'
PREFIX = Path('/tmp/mr3_p2a0_v19_candidate_stimulus_comparison_v1')
FREEZE = '72d0465ddd1bbee09af117cfd9d89b7e729f8578'
NAMES = ('tb1', 'tb2', 'tb3')
inputs = {}
map_cache = {}
patches = []
started = time.monotonic()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    path = Path(path)
    raw = path.read_bytes()
    proof = {'bytes': len(raw), 'sha256': sha(raw)}
    if str(path) in inputs:
        assert inputs[str(path)] == proof, 'input changed'
    inputs[str(path)] = proof
    return raw


def js(path):
    return json.loads(read(path))


def frozen(path):
    raw = read(path)
    assert subprocess.check_output(['git', 'show', FREEZE + ':' + str(
        path.relative_to(ROOT))], cwd=ROOT) == raw
    return raw


probe_path = W / 'mr3_learning/benchmark.py'
probe_raw = frozen(probe_path)
functions = {'_probe_goal_order', 'probe_action_v3', 'probe_action_v4',
             'record_probe_v4_submission', '_probe_nonapproaching_goal_action',
             'probe_action_v6'}
body = [n for n in ast.parse(probe_raw).body if isinstance(n, ast.FunctionDef)
        and n.name in functions]
assert len(body) == len(functions)
ns = {'math': math}
exec(compile(ast.Module(body=body, type_ignores=[]), str(probe_path), 'exec'), ns)
nav_path = W / 'mr3_learning/navigation_archive.py'
frozen(nav_path)
spec = importlib.util.spec_from_file_location('exact_numpy_map_projection', nav_path)
nav = importlib.util.module_from_spec(spec)
spec.loader.exec_module(nav)
observation_path = ROOT / ('ros2_ws/ros2-multi-robot-automap/src/'
                          'multi_robot_exploration/multi_robot_exploration/mr3_observation.py')
frozen(observation_path)


def counts(grid):
    return {'free_0': int(np.count_nonzero(grid == 0)),
            'unknown_minus1': int(np.count_nonzero(grid < 0)),
            'occupied_nonzero': int(np.count_nonzero(grid > 0)),
            'occupied100': int(np.count_nonzero(grid == 100))}


def payload(episode, binding):
    path = episode / 'observation_inputs' / binding['artifact']
    if str(path) not in map_cache:
        encoded = read(path)
        raw = gzip.decompress(encoded)
        value = json.loads(raw)
        assert sha(raw) == binding['payload_sha256']
        assert raw == json.dumps(value, sort_keys=True, separators=(',', ':'),
                                 allow_nan=False).encode()
        nav._validate(value)
        map_cache[str(path)] = value
    return map_cache[str(path)]


def projected_sources(source, left, bottom, resolution):
    info = source['info']
    rr = [int(math.floor((bottom - info['origin']['position']['y']) / resolution + 1e-9)),
          int(math.ceil((bottom + resolution - info['origin']['position']['y']) /
                        resolution - 1e-9)) - 1]
    cc = [int(math.floor((left - info['origin']['position']['x']) / resolution + 1e-9)),
          int(math.ceil((left + resolution - info['origin']['position']['x']) /
                        resolution - 1e-9)) - 1]
    cells = nav._validate(source)
    return [{'row': r, 'column': c, 'value': int(cells[r, c])
             if 0 <= r < info['height'] and 0 <= c < info['width'] else -1,
             'inside': 0 <= r < info['height'] and 0 <= c < info['width']}
            for r, c in sorted(set((r, c) for r in rr for c in cc))]


def seed_map(episode, snapshot, robot, bundle):
    name = robot['name']
    pm = snapshot['path_maps'][name]
    own, shared, actual = (payload(episode, bundle['maps'][role])
                           for role in (name, 'fused', 'navigation:' + name))
    assert bundle['maps']['navigation:' + name]['payload_sha256'] == pm['payload_sha256']
    assert bundle['maps'][name]['payload_sha256'] == pm['input_own_map_payload_sha256']
    assert bundle['maps']['fused']['payload_sha256'] == pm['input_shared_map_payload_sha256']
    grid = nav._validate(actual)
    info = actual['info']
    resolution = info['resolution']
    ox, oy = (info['origin']['position'][axis] for axis in ('x', 'y'))
    left = ox + np.arange(info['width']) * resolution
    bottom = oy + np.arange(info['height']) * resolution
    own_projected = nav._project(own, nav._validate(own), left, bottom, resolution)
    shared_projected = nav._project(shared, nav._validate(shared), left, bottom, resolution)
    rebuilt = np.where(own_projected >= 0, own_projected, shared_projected)
    assert np.array_equal(rebuilt, grid), 'actual nav differs from received-only reconstruction'
    r, c = pm['seed_cell']
    blocked = np.argwhere(grid != 0)
    distances2 = np.sum((blocked - np.array([r, c])) ** 2, axis=1)
    minimum2 = int(np.min(distances2))
    nearest = blocked[distances2 == minimum2]
    clearance = max(0., math.sqrt(minimum2) * resolution - resolution / math.sqrt(2.))
    assert abs(clearance - pm['seed_cell_clearance_m']) <= 1e-12
    nearest_rows = []
    for rr, cc in nearest:
        rr, cc = int(rr), int(cc)
        x, y = ox + (cc + .5) * resolution, oy + (rr + .5) * resolution
        lx = robot['x'] - .064 * math.cos(robot['yaw'])
        ly = robot['y'] - .064 * math.sin(robot['yaw'])
        nearest_rows.append({'row': rr, 'column': cc, 'world_cell_center_xy': [x, y],
            'navigation_value': int(grid[rr, cc]), 'own_projected_value': int(own_projected[rr, cc]),
            'shared_projected_value': int(shared_projected[rr, cc]),
            'authority': 'own_known' if own_projected[rr, cc] >= 0 else 'shared_fill_own_unknown',
            'own_native_contributors': projected_sources(own, left[cc], bottom[rr], resolution),
            'shared_native_contributors': projected_sources(shared, left[cc], bottom[rr], resolution),
            'distance_to_seed_cell_center_m': math.sqrt(minimum2) * resolution,
            'distance_to_received_pose_m': math.hypot(x - robot['x'], y - robot['y']),
            'distance_to_nominal_URDF_scan_origin_m': math.hypot(x - lx, y - ly),
            'within_nominal_scan_minrange_disk': math.hypot(x - lx, y - ly) < .12})
    radius = math.ceil(.29 / resolution)
    r0, r1 = max(0, r - radius), min(grid.shape[0], r + radius + 1)
    c0, c1 = max(0, c - radius), min(grid.shape[1], c + radius + 1)
    region = np.s_[r0:r1, c0:c1]
    patches.append({'stage': episode.parent.parent.name, 'sequence': snapshot['sequence'],
        'task_elapsed_sec': snapshot['task_elapsed_sec'], 'robot': name,
        'map_payloads': {k: bundle['maps'][k]['payload_sha256']
                         for k in (name, 'fused', 'navigation:' + name)},
        'origin_m': [ox, oy], 'resolution_m': resolution,
        'first_row_column': [r0, c0], 'seed_row_column': [r, c],
        'navigation': grid[region].tolist(), 'own_projected': own_projected[region].tolist(),
        'shared_projected': shared_projected[region].tolist(),
        'authority_0own_1shared': np.where(own_projected[region] >= 0, 0, 1).tolist()})
    return {'seed_value': int(grid[r, c]), 'seed_row_column': [r, c],
        'independently_recomputed_cell_clearance_m': clearance,
        'map_source_counts': {'navigation_window': counts(grid[region]),
                             'own_projected_window': counts(own_projected[region]),
                             'shared_projected_window': counts(shared_projected[region])},
        'window_first_row_column': [r0, c0], 'window_shape': [r1-r0, c1-c0],
        'nearest_blocked_cells': nearest_rows, 'navigation_exact_reconstruction': True,
        'raw_sources': {'navigation': bundle['maps']['navigation:' + name],
                       'own': bundle['maps'][name], 'shared': bundle['maps']['fused']}}


def life_info(snapshot, diagnostics):
    elapsed = snapshot['task_elapsed_sec']
    state = diagnostics['v4_stimulus']
    round_id = 'initial' if elapsed < 13. else 'second'
    current = state['rounds'][round_id]
    late = 15_000_000_000 <= round(elapsed * 1e9) < 26_000_000_000
    window = elapsed < 1.5 or 13. <= elapsed < 15. or late
    desired, result = [], []
    for i, robot in enumerate(snapshot['robots']):
        name, speed = robot['name'], robot.get('v')
        first_wait = state['rounds'].get('initial', {}).get('waits', {}).get(name)
        nav_state = robot['navigation']
        reasons = state['pending_submission']['reasons']
        reason = reasons.get(name)
        recovery = []
        if round_id == 'second':
            if first_wait is None: recovery.append('missing_first_submitted_WAIT')
            elif elapsed - first_wait['task_elapsed_sec'] < 3.: recovery.append('first_WAIT_less_than3s')
            if nav_state.get('phase') != 'idle': recovery.append('navigation_not_idle')
            if robot.get('fresh') is not True: recovery.append('received_state_not_fresh')
            if type(speed) not in (int, float) or not math.isfinite(speed): recovery.append('nonfinite_received_v')
            elif abs(speed) > .01: recovery.append('received_abs_v_above_.01')
        allowed = ((9,) if reason is not None and not reason.endswith('_wait_masked') else
                   tuple(range(9)) if window and not recovery else (8,))
        desired.append(allowed)
        result.append({'name': name, 'first_wait': first_wait, 'recovering_reasons': recovery,
            'received_v': speed, 'received_fresh': robot['fresh'], 'received_valid': robot['valid'],
            'navigation_phase': nav_state['phase'], 'owned': nav_state['owned'],
            'fixture_reason': reason, 'lifecycle_desired_digits': list(allowed)})
    original = [a for a, v in enumerate(snapshot['joint_action_mask']) if v]
    nonapproach = [a for a in original if ns['_probe_nonapproaching_goal_action'](snapshot, a)]
    final = [a for a in nonapproach if all(a // div % 10 in desired[i]
                                          for i, div in enumerate((100, 10, 1)))]
    for i, div in enumerate((100, 10, 1)):
        result[i].update(original_legal_GOAL_joint_actions=sum(a // div % 10 < 8 for a in original),
            after_nonapproach_GOAL_joint_actions=sum(a // div % 10 < 8 for a in nonapproach),
            after_lifecycle_and_nonapproach_GOAL_joint_actions=sum(a // div % 10 < 8 for a in final))
    return {'goal_window': window, 'late_window': late, 'original_allowed_count': len(original),
            'nonapproach_allowed_count': len(nonapproach), 'fixture_final_allowed_count': len(final),
            'robots': result}


stages = {}
for stage in ('baseline', 'iters150'):
    run = BASE / ('mr3_p2a0_20261018_v19_' + stage)
    episode = run / 'worker0/episode001_open_101'
    raw = read(episode / 'transitions.jsonl')
    full_rows = [json.loads(line) for line in raw.splitlines()]
    assert len(full_rows) == 33 and full_rows[0]['kind'] == 'reset'
    # Reward/evaluation/truth payloads are deliberately excluded from analysis.
    rows = [{'kind': r['kind'], 'snapshot': r['snapshot'],
             'info': {k: r['info'][k] for k in ('command', 'action_submitted') if k in r['info']}}
            for r in full_rows]
    benchmark = js(run / 'benchmark_summary.json')
    metadata = js(episode / 'metadata.json')
    assert benchmark['freeze'] == metadata['freeze'] == FREEZE
    recorded = benchmark['workers_results'][0]['episodes'][0]
    diagnostics = {}
    timeline = []
    for i, r in enumerate(rows):
        s = r['snapshot']
        d = s['diagnostics']
        entry = {'transition_line': i + 1, 'sequence': s['sequence'],
            'snapshot_digest': s['digest'], 'task_elapsed_sec': s['task_elapsed_sec'],
            'source_stamp': s['source_stamp'], 'map_version': s['map_version'],
            'valid_candidate_count': sum(c['valid'] for c in s['candidates']),
            'original_joint_allowed_count': sum(s['joint_action_mask']),
            'candidate_diagnostics': {k: d.get(k) for k in (
                'frontier_cells', 'frontier_groups', 'geometric_pool_size',
                'native_safe_cells', 'native_arrival_safe_cells',
                'per_robot_reachable_target_cells', 'per_robot_reachable_pool_counts',
                'per_robot_reachable_selected_counts', 'per_robot_staging_rejections',
                'robot_seed_traversable')},
            'per_robot_mask_reasons': d['mask_reasons']['per_robot'], 'robots': []}
        for j, robot in enumerate(s['robots']):
            div = (100, 10, 1)[j]
            entry['robots'].append({'name': robot['name'], 'pose_xy_yaw': [robot[k] for k in ('x','y','yaw')],
                'fresh': robot['fresh'], 'valid': robot['valid'],
                'v': robot['v'], 'w': robot['w'], 'source_stamp': robot['source_stamp'],
                'odom_source_stamp': robot['odom_source_stamp'], 'tf_source_stamp': robot['tf_source_stamp'],
                'reachable_candidate_count': sum(c['valid'] and c['reachable'][j] for c in s['candidates']),
                'per_robot_legal_GOAL_indices': [k for k, v in enumerate(s['per_robot_action_mask'][j][:8]) if v],
                'joint_legal_GOAL_indices': sorted({a // div % 10 for a,v in enumerate(s['joint_action_mask']) if v and a // div % 10 < 8}),
                'navigation': {k: robot['navigation'].get(k) for k in ('phase','owned','goal_id','goal_x','goal_y','accepted_goal_count','commitment_remaining_sec')},
                'activity': robot['activity'], 'path_map': s['path_maps'][robot['name']]})
        bundle_path = episode / 'observation_inputs/snapshots' / f"{s['sequence']:08d}_{s['digest']}.json"
        bundle = js(bundle_path)
        assert bundle['snapshot_digest'] == s['digest'] and bundle['sequence'] == s['sequence']
        for j, robot in enumerate(s['robots']):
            entry['robots'][j]['seed_map_provenance'] = seed_map(episode, s, robot, bundle)
        if i < 32:
            action = ns['probe_action_v6'](s, diagnostics)
            actual = rows[i+1]['info']
            assert action == actual['command']['action']
            assert actual['command']['observation_sequence'] == s['sequence']
            assert actual['command']['observation_digest'] == s['digest']
            entry['V6'] = life_info(s, diagnostics)
            entry['V6']['replayed_action'] = action
            entry['actual_returned_command'] = actual['command']
            entry['actual_step_command_line'] = i + 2
            ns['record_probe_v4_submission'](diagnostics, actual)
        timeline.append(entry)
    assert diagnostics == recorded['preparation_probe_diagnostics']
    geometry = []
    for robot in NAMES:
        actual_model = js if False else ET.fromstring(read(episode / ('drive_model_' + robot + '.sdf')))
        sensor = actual_model.find('.//sensor[@name="hls_lfcd_lds"]')
        geometry.append({'robot': robot, 'ray_pose_in_parent_link': sensor.findtext('pose'),
            'range_min_m': float(sensor.findtext('ray/range/min')),
            'range_max_m': float(sensor.findtext('ray/range/max')),
            'scan_frame_name': sensor.findtext('plugin/frame_name'),
            'sensor_update_rate_hz': float(sensor.findtext('update_rate'))})
    stages[stage] = {'episode': str(episode), 'epoch': timeline[0]['robots'][0]['activity']['epoch'],
        'release_time_ns': full_rows[0]['info']['release_time_ns'],
        'initial_inputs_ready_original': full_rows[0]['info']['initial_inputs_ready'],
        'source_stamp_at_release': timeline[0]['source_stamp'], 'snapshots': 33, 'steps': 32,
        'actual_V6_selector_and_typed_submission_replay_exact': True,
        'full_V6_diagnostics_equal_original_benchmark': True,
        'actual_actions': [x['actual_returned_command']['action'] for x in timeline[:-1]],
        'all_snapshot_valid_candidate_counts': [x['valid_candidate_count'] for x in timeline],
        'legal_GOAL_snapshots_per_robot': {n: sum(bool(x['robots'][j]['joint_legal_GOAL_indices']) for x in timeline) for j,n in enumerate(NAMES)},
        'final_received_activity_and_goal_counts': {n: {'activity': timeline[-1]['robots'][j]['activity'],
             'accepted_goal_count': timeline[-1]['robots'][j]['navigation']['accepted_goal_count']} for j,n in enumerate(NAMES)},
        'actual_effective_SDF_sensor_geometry': geometry, 'timeline': timeline}

urdf_path = ROOT / 'ros2_ws/ros2-multi-robot-automap/src/multi_robot/urdf/turtlebot3_waffle.urdf'
urdf = ET.fromstring(frozen(urdf_path))
scan_joint = urdf.find('./joint[@name="scan_joint"]')
scan_geometry = {'joint_type': scan_joint.get('type'), 'parent': scan_joint.find('parent').get('link'),
                 'child': scan_joint.find('child').get('link'),
                 'origin': scan_joint.find('origin').attrib,
                 'scope': 'frozen declared fixed TF plus effective SDF ray geometry; no received tf_static or raw LaserScan capture was analyzed'}
assert stages['baseline']['actual_effective_SDF_sensor_geometry'] == stages['iters150']['actual_effective_SDF_sensor_geometry']
for p, proof in inputs.items():
    raw = Path(p).read_bytes()
    assert len(raw) == proof['bytes'] and sha(raw) == proof['sha256']
patch_raw = b''.join((json.dumps(v, separators=(',', ':'), allow_nan=False)+'\n').encode() for v in patches)
patch_path = Path(str(PREFIX) + '_seed_neighborhoods.jsonl.gz')
with patch_path.open('xb') as f:
    f.write(gzip.compress(patch_raw, mtime=0))
result = {'schema': 'mr3-v19-received-candidate-stimulus-comparison-v1', 'analysis_completed': True,
    'freeze': FREEZE, 'stages': stages, 'fixed_scan_geometry': scan_geometry,
    'seed_neighborhoods': {'path': str(patch_path), 'encoded_sha256': sha(patch_path.read_bytes()),
        'decoded_sha256': sha(patch_raw), 'records': len(patches),
        'scope': 'Every received snapshot/robot13x13(ceil .29/res radius) map window; nav/own/shared projected values and per-cell authority. Exact original map payload SHA refs retained.'},
    'conclusions': [
        'iters150 had zero valid candidates and zero original-mask GOAL for all3robots in all33snapshots, including first32decision inputs. Every actual step was KEEP/WAIT; actual matching V6 replay and diagnostics agree. This is production candidate seed-clearance starvation before external nonapproach/lifecycle ranking, not a legal GOAL filtered by V6 or Nav2 rejection.',
        'All3 contrast seeds are FREE0 themselves, but nearest blocked cells are actually100, including own delivered map projected100; shared is100 too. Owner-known navigation preserves these100 cells. The .29 body certificate fails; no unknown promotion, seed snapping, obstacle removal or gate reduction is justified.',
        'baseline at release30.1 has8valid candidates and original joint GOAL for each robot. Contrast at release23.1 and its later snapshot at absolute30.1 still has0candidates; all33snapshots remain blocked. Release-time difference is observed, but a7s wait alone is not demonstrated to solve it, nor is unique solver/map/startup causality identified.',
        'The nearest contrast occupied cell centres lie inside the nominal fixed-TF ray minrange disk and physical footprint. This is a map/sensor-registration or near-body scan/mapping hypothesis only. Occupancy100 is not missing/unknown and cannot be erased on that hypothesis. Raw received scan/actual static TF/map-formation evidence would be needed for attribution.',
        'Baseline movement and stopping stimulation differs fundamentally from unstimulated contrast. A correctly captured contrast no-response-credit result cannot demonstrate the150 solver repairs stopping; no task/PPO/matrix or causal matched-trajectory credit is claimed.'
    ],
    'source_functions_executed_exact_AST': sorted(functions),
    'scope': 'Only received snapshots, actual typed step commands, archived delivered own/shared/navigation maps and static/effective source geometry. No truth or reward/evaluator fields used for decisions/analysis; no full physics/motion/adapter raw scan or native/formal invocation.',
    'inputs_before_after': inputs, 'all_inputs_unchanged': True,
    'execution': {'argv': sys.argv, 'cwd': str(Path.cwd()), 'source_sha256': sha(Path(__file__).read_bytes()),
                  'wall_seconds': time.monotonic()-started, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat()},
    'initial_small_preview_diagnostic': 'An early compact preview command had a Python whitespace typo (or0) and produced SyntaxError; no dataset/source mutation or partial result was used.',
    'writers': 'STOP'}
output = Path(str(PREFIX)+'.json')
with output.open('x') as f:
    f.write(json.dumps(result, indent=2, allow_nan=False)+'\n')
print(json.dumps({'analysis_completed': True, 'output': str(output), 'sha256': sha(output.read_bytes()),
    'seed_neighborhood_records': len(patches), 'map_blob_inputs': len(map_cache),
    'baseline_legal_GOAL_snapshots': stages['baseline']['legal_GOAL_snapshots_per_robot'],
    'contrast_legal_GOAL_snapshots': stages['iters150']['legal_GOAL_snapshots_per_robot'],
    'wall_seconds': result['execution']['wall_seconds']}))
