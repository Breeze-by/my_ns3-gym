#!/usr/bin/env python3
"""Losslessly seal stopped V26 author proposals; no tests or consumers run."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tarfile
import time

OUT = Path(__file__).resolve().parent
ROOTS = (
    Path('/tmp/mr3_p2a0_v26_capture_consistency_proposal_v1'),
    Path('/tmp/mr3_p2a0_v26_capture_consistency_proposal_v2'),
)

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def signature(st):
    return [st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns]

def capture(path):
    initial = path.lstat()
    if not stat.S_ISREG(initial.st_mode):
        raise ValueError('Nonregular original: ' + str(path))
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        raw = stream.read()
        final_fd = os.fstat(stream.fileno())
    final_path = path.lstat()
    if not (signature(initial) == signature(opened) == signature(final_fd) == signature(final_path)):
        raise ValueError('Unstable source: ' + str(path))
    if len(raw) != initial.st_size:
        raise ValueError('Source size mismatch: ' + str(path))
    return raw, signature(initial), stat.S_IMODE(initial.st_mode)

def selected():
    paths, excluded = [], []
    for root in ROOTS:
        if not root.is_dir() or root.is_symlink():
            raise ValueError('Missing/nonregular source root: ' + str(root))
        for path in sorted(root.rglob('*')):
            relative = path.relative_to(root)
            if '__pycache__' in relative.parts or path.suffix == '.pyc':
                if path.is_file() or path.is_symlink():
                    excluded.append(str(path))
                continue
            if path.is_symlink():
                raise ValueError('Symlink source rejected: ' + str(path))
            if path.is_file():
                paths.append((path, 'originals/' + root.name + '/' + relative.as_posix()))
    paths.append((Path(__file__).resolve(), 'archive_helper/' + Path(__file__).name))
    return paths, excluded

def write_json_exclusive(path, value):
    raw = (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode()
    with path.open('xb') as stream:
        stream.write(raw)
    return {'path': str(path), 'sha256': digest(raw), 'bytes': len(raw)}

start = time.monotonic()
chosen, excluded = selected()
entries, payloads = [], {}
for path, member in chosen:
    raw, before, mode = capture(path)
    entries.append({'source': str(path), 'member': member, 'sha256': digest(raw),
                    'bytes': len(raw), 'source_stat_before': before, 'mode': mode})
    payloads[member] = raw
archive = OUT / 'originals.tar.gz'
with archive.open('xb') as compressed:
    with gzip.GzipFile(filename='', mode='wb', fileobj=compressed, mtime=0, compresslevel=9) as zipped:
        with tarfile.open(mode='w', fileobj=zipped, format=tarfile.PAX_FORMAT) as tar:
            for row in entries:
                info = tarfile.TarInfo(row['member'])
                info.size = row['bytes']
                info.mode = row['mode']
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                info.mtime = 0
                tar.addfile(info, io.BytesIO(payloads[row['member']]))
expected = {row['member']: row for row in entries}
roundtrip = []
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    if len(members) != len(expected) or len({m.name for m in members}) != len(members):
        raise ValueError('Archive member cardinality/uniqueness mismatch')
    for member in members:
        if not member.isfile() or member.name not in expected:
            raise ValueError('Unexpected archive member')
        raw = tar.extractfile(member).read()
        row = expected[member.name]
        if len(raw) != row['bytes'] or digest(raw) != row['sha256'] or raw != payloads[member.name]:
            raise ValueError('Archive roundtrip failed: ' + member.name)
        roundtrip.append({'member': member.name, 'bytes': len(raw), 'sha256': digest(raw), 'passed': True})
chosen_after, excluded_after = selected()
if [(str(p), m) for p, m in chosen_after] != [(str(p), m) for p, m in chosen] or excluded_after != excluded:
    raise ValueError('Source selection changed while packing')
for row in entries:
    raw, after, unused_mode = capture(Path(row['source']))
    if after != row['source_stat_before'] or digest(raw) != row['sha256']:
        raise ValueError('Final source verification failed: ' + row['source'])
    row['source_stat_final'] = after
    row['source_final_sha256'] = digest(raw)
    row['source_final_verification_passed'] = True
encoded_raw = archive.read_bytes()
with gzip.open(archive, 'rb') as stream:
    decoded_raw = stream.read()
archive_record = {'path': str(archive), 'sha256': digest(encoded_raw), 'bytes': len(encoded_raw),
                  'encoding': 'gzip_tar', 'decoded_tar_sha256': digest(decoded_raw),
                  'decoded_tar_bytes': len(decoded_raw), 'member_count': len(entries),
                  'original_payload_bytes': sum(row['bytes'] for row in entries)}
manifest = {
    'schema': 'mr3-v26-capture-consistency-author-offline-manifest-v1',
    'source_roots': [str(root) for root in ROOTS],
    'source_status': 'STOP', 'metadata_status': 'STOP',
    'scope': 'Stopped author V1 (including later fixed-loader addendum) and V2 only, plus exact archive helper. No tests, consumers, ROS, build or native run by this helper.',
    'exclusions': {'rules': ['__pycache__', '*.pyc'], 'actual_paths': excluded},
    'self_excluded': ['manifest.json', 'final_handoff_v1.json', 'originals.tar.gz'],
    'preservation': {
        'all_original_proposal_files_preserved': True,
        'all_patch_and_executed_source_snapshots_preserved': True,
        'inherited_caption_preserved': 'V2 original result inherited nine-case caption; actual case_count=1/calls=2. Executed snapshot retained. Final portable harness caption was corrected statically, without reexecution.',
        'old_failure_scope': 'V25 original035/stageFAIL is not changed or reclassified. Synthetic cases do not identify which native035 conjunction failed.',
        'historical_originals': 'V1 initial source 7ff18 and loader08d5, V2 final sourceac90 and loaderf45, and all stored receipts/handoffs remain byte exact.',
        'separate_independent_review': 'Safety independent review originals are separately sealed by its author; they are not duplicated here.'
    },
    'archive': archive_record, 'entries': entries,
    'verification': {'all_members_byte_exact': True, 'roundtrip': roundtrip,
                     'all_source_sha_stat_final_unchanged': True, 'selection_unchanged': True},
    'packing_wall_seconds': time.monotonic() - start,
}
manifest_record = write_json_exclusive(OUT / 'manifest.json', manifest)
handoff = {
    'schema': 'mr3-v26-capture-consistency-author-seal-handoff-v1',
    'source_status': 'STOP', 'metadata_status': 'STOP', 'writer_status': 'STOP',
    'archive': archive_record, 'manifest': manifest_record,
    'proposal_file_count': len(entries) - 1, 'packing_helper_file_count': 1,
    'source_roots': [str(root) for root in ROOTS],
    'final_module': {'source': str(ROOTS[1] / 'mr3_v26_smoother_custody_v2.py'),
                     'sha256': 'ac90b7f896592a5a08430ee859ad73332a4e0cd3292e53e20ada310179841c30'},
    'final_auditor': {'source': str(ROOTS[1] / 'audit_ppo.proposed_v26.py'),
                      'sha256': 'f45c214856d73f57ebc0622c2da20c6c96b663a975f14a2d00215cbe088377c2'},
    'byte_custody_passed': True,
    'execution_scope': 'Packing and byte/stat roundtrip only. No tests, formal consumer, build, ROS/DDS, native or canonical/Git mutation; no old failures rewritten.',
    'canonical_publication': 'Root may copy this archive, manifest and final handoff into A26 offline custody; not published by author.'
}
handoff_record = write_json_exclusive(OUT / 'final_handoff_v1.json', handoff)
print(json.dumps({'archive': archive_record, 'manifest': manifest_record, 'handoff': handoff_record,
                  'proposal_files': len(entries) - 1, 'helper_files': 1,
                  'roundtrip_passed': True, 'source_sha_stat_unchanged': True,
                  'writer_status': 'STOP'}, ensure_ascii=False))
