"""Read-only V13 source/gate comparison; no ROS imports or native execution."""

import argparse
import ast
import copy
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time


BASE = '6b1b4a0108351f5bfb70ec0c96ba895248d4f7a8'
WIRELESS = 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
ROS = 'ros2_ws/ros2-multi-robot-automap/'
PURE = ROS + 'src/multi_robot_exploration/multi_robot_exploration/'
A12 = WIRELESS + 'report/assets/20261017_mr3_p2a0_v12/'
A13 = WIRELESS + 'report/assets/20261017_mr3_p2a0_v13/'
SHA = re.compile('[0-9a-f]{64}')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def syntax(node):
    return ast.dump(node, include_attributes=False)


class RemoveDocstrings(ast.NodeTransformer):
    def generic_visit(self, node):
        node = super().generic_visit(node)
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.body and isinstance(node.body[0], ast.Expr) and isinstance(
                    node.body[0].value, ast.Constant) and isinstance(node.body[0].value.value, str):
                node.body.pop(0)
        return node


def tree(raw):
    return RemoveDocstrings().visit(ast.parse(raw))


def functions(module):
    result = {}
    for node in module.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            result[node.name] = node
        elif isinstance(node, ast.ClassDef):
            for member in node.body:
                if isinstance(member, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    result[node.name + '.' + member.name] = member
    return result


def value(node, known):
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.Name):
        return known[node.id]
    if isinstance(node, (ast.Tuple, ast.List)):
        items = [value(item, known) for item in node.elts]
        return tuple(items) if isinstance(node, ast.Tuple) else items
    if isinstance(node, ast.Dict):
        return {value(key, known): value(item, known) for key, item in zip(node.keys, node.values)}
    if isinstance(node, ast.BinOp):
        left, right = value(node.left, known), value(node.right, known)
        operations = {ast.Add: lambda: left + right, ast.Sub: lambda: left - right,
                      ast.Mult: lambda: left * right, ast.Div: lambda: left / right}
        return operations[type(node.op)]()
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        return -value(node.operand, known)
    raise ValueError('nonliteral assignment')


def assignments(module):
    result = {}
    for node in module.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(
                node.targets[0], ast.Name):
            try:
                result[node.targets[0].id] = value(node.value, result)
            except (KeyError, TypeError, ValueError):
                pass
    return result


def ast_differences(before, after, path='module'):
    if type(before) is not type(after):
        return [{'path': path, 'before_type': type(before).__name__,
                 'after_type': type(after).__name__}]
    if isinstance(before, ast.AST):
        result = []
        for name in before._fields:
            result.extend(ast_differences(getattr(before, name), getattr(after, name), path + '.' + name))
        return result
    if isinstance(before, list):
        if len(before) != len(after):
            return [{'path': path, 'before_length': len(before), 'after_length': len(after)}]
        result = []
        for index, (left, right) in enumerate(zip(before, after)):
            result.extend(ast_differences(left, right, f'{path}[{index}]'))
        return result
    return [] if before == after else [{'path': path, 'before': before, 'after': after}]


class StripRawKeyword(ast.NodeTransformer):
    def __init__(self, peer_only=False):
        self.count = 0
        self.peer_only = peer_only

    def visit_Call(self, node):
        self.generic_visit(node)
        if isinstance(node.func, ast.Name) and node.func.id == 'valid_state' and (
                not self.peer_only or isinstance(node.args[0], ast.Name)
                and node.args[0].id == 'peer'):
            kept = []
            for keyword in node.keywords:
                if keyword.arg == 'require_raw' and isinstance(keyword.value, ast.Constant) \
                        and keyword.value.value is True:
                    self.count += 1
                else:
                    kept.append(keyword)
            node.keywords = kept
        return node


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=Path('/home/zhuyulab/ns3-workspace'))
    parser.add_argument('--base', default=BASE)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--require-final-plan', action='store_true')
    args = parser.parse_args()
    start = time.monotonic()
    inputs, results, commands = {}, {}, []

    def read(relative):
        path = args.root / relative
        raw = path.read_bytes()
        digest = sha(raw)
        if relative in inputs and inputs[relative]['sha256'] != digest:
            raise ValueError('input changed during check: ' + relative)
        inputs[relative] = {'sha256': digest, 'bytes': len(raw)}
        return raw

    def git(*argv):
        command = ['git', *argv]
        commands.append({'argv': command, 'cwd': str(args.root)})
        return subprocess.check_output(command, cwd=args.root)

    def before(relative):
        return git('show', args.base + ':' + relative)

    def check(name, condition, details):
        results[name] = {'passed': bool(condition), 'details': details}

    core_paths = [WIRELESS + 'mr3_learning/' + name for name in (
        'model.py', 'policy.py', 'ppo.py', 'rollout.py', 'observation.py', 'env.py',
        'supervisor.py', 'ipc.py', 'audit_scalar.py', 'audit_protocol.py',
        'audit_evaluator_phase.py', 'audit_preparation.py', 'audit_controlled_physics.py')]
    core_paths += [PURE + name for name in (
        'mr3_observation.py', 'mr3_adapter.py', 'mr3_reward.py', 'mr3_task_contract.py',
        'mr3_contacts.py', 'task_evaluator.py', 'mr3_evaluator_phase.py', 'mr3_activity.py',
        'mr3_information.py', 'peer_obstacles.py', 'mr3_observation_archive.py',
        'mr3_episode.py', 'mr3_control_phase.py', 'mr3_drive_phase.py', 'control.py')]
    core_paths += [WIRELESS + 'MR3_TASK_CONTRACT.md', WIRELESS + 'MR3_ADAPTER_CONTRACT.md',
                   ROS + 'scripts/mr3_env_worker.py', ROS + 'scripts/audit_mr3_env.py',
                   ROS + 'scripts/audit_mr3_adapter_probe.py',
                   ROS + 'src/multi_robot/models/turtlebot3_waffle/model.sdf',
                   ROS + 'src/multi_robot/config/mr3_step_clock.yaml',
                   ROS + 'src/multi_robot/src/mr3_gazebo_step_plugin.cpp',
                   ROS + 'src/multi_robot/include/multi_robot/mr3_step_contract.hpp',
                   ROS + 'src/multi_robot/src/mr3_gazebo_diff_drive.cpp',
                   ROS + 'src/multi_robot/include/multi_robot/mr3_gazebo_diff_drive.hpp']
    protected = {}
    for path in core_paths:
        old, current = before(path), read(path)
        protected[path] = {'base_sha256': sha(old), 'current_sha256': sha(current),
                           'unchanged': old == current}
    scopes = [ROS + 'src/slam_toolbox', ROS + 'src/multi_robot/worlds',
              ROS + 'src/multi_robot/maps', ROS + 'src/multi_robot/models',
              ROS + 'src/merge_map', ROS + 'src/multi_robot/config/mr3_p1a']
    tree_changes = git('diff', '--name-only', args.base, '--', *scopes).decode().splitlines()
    check('actor_reward_candidate_task_evaluator_contact_scene_sdf_slam_unchanged',
          all(item['unchanged'] for item in protected.values()) and not tree_changes,
          {'exact_files': protected, 'protected_tree_scopes': scopes,
           'protected_tree_changes': tree_changes})
    objective = assignments(tree(read(WIRELESS + 'mr3_learning/ppo.py')))
    check('unchanged_finite_task_ppo_gamma_and_lambda_are_one',
          objective.get('GAMMA_PER_SECOND') == objective.get('GAE_LAMBDA_PER_SECOND') == 1.,
          {key: objective.get(key) for key in ('GAMMA_PER_SECOND', 'GAE_LAMBDA_PER_SECOND')})

    audit_path = WIRELESS + 'mr3_learning/audit_ppo.py'
    old_audit, current_audit = tree(before(audit_path)), tree(read(audit_path))
    av, cv = assignments(old_audit), assignments(current_audit)
    allowed = {
        'PREPARATION_RUNTIME_PINS': {PURE + name for name in
                                   ('mr3_motion_safety.py', 'motion_safety.py', 'mr3_motion_control.py')},
        'EXECUTION_CONFIG_PINS': {ROS + path for path in (
            'src/multi_robot/params/nav2_params_tb1_0.yaml',
            'src/multi_robot/params/nav2_params_tb2_0.yaml',
            'src/multi_robot/params/nav2_params_tb3_0.yaml',
            'src/multi_robot/config/nav2_params.yaml', 'src/multi_robot/package.xml',
            'src/multi_robot/include/multi_robot/paired_wheel_slew.hpp',
            'src/multi_robot/include/multi_robot/mr3_drive_target.hpp',
            'src/multi_robot/vendor/gazebo_ros_diff_drive.PROVENANCE.md')},
    }
    changed_pins = []
    valid_pin_locations = True
    for group, permitted in allowed.items():
        keys = {key for key in av[group] if av[group][key] != cv[group].get(key)}
        valid_pin_locations &= set(av[group]) == set(cv[group]) and keys == permitted
        changed_pins.extend({'group': group, 'path': key,
                             'before': av[group][key], 'after': cv[group][key]} for key in sorted(keys))
    changed_pins.append({'group': 'ENV_DOCUMENT_SHA256', 'path': WIRELESS + 'MR3_ENV_CONTRACT.md',
                         'before': av['ENV_DOCUMENT_SHA256'], 'after': cv['ENV_DOCUMENT_SHA256']})
    differences = ast_differences(old_audit, current_audit)
    expected = sorted((item['before'], item['after']) for item in changed_pins)
    actual = sorted((item.get('before', ''), item.get('after', '')) for item in differences)
    check('audit_ppo_only_twelve_explicit_reviewed_sha_literals_changed',
          valid_pin_locations and len(differences) == 12 and actual == expected
          and all(SHA.fullmatch(left) and SHA.fullmatch(right) for left, right in actual),
          {'changed_pins': changed_pins, 'ast_differences': differences})
    pins = {}
    for group in ('EVALUATOR_PHASE_PINS', 'PREPARATION_RUNTIME_PINS', 'EXECUTION_CONFIG_PINS'):
        for path, expected_hash in cv[group].items():
            pins[path] = {'expected': expected_hash, 'actual': sha(read(path))}
    env_path = WIRELESS + 'MR3_ENV_CONTRACT.md'
    env_sha = sha(read(env_path))
    check('all_35_explicit_current_pins_and_env_document_match',
          len(pins) == 35 and all(item['expected'] == item['actual'] for item in pins.values())
          and env_sha == cv['ENV_DOCUMENT_SHA256'],
          {'pins': pins, 'count': len(pins), 'env_expected': cv['ENV_DOCUMENT_SHA256'],
           'env_actual': env_sha})

    safety_path = PURE + 'mr3_motion_safety.py'
    old_safety, current_safety = tree(before(safety_path)), tree(read(safety_path))
    sf_old, sf_new = functions(old_safety), functions(current_safety)
    constants_old, constants_new = assignments(old_safety), assignments(current_safety)
    constant_changes = {key: {'before': constants_old[key], 'after': constants_new.get(key)}
                        for key in constants_old if canonical(constants_old[key])
                        != canonical(constants_new.get(key))}
    check('all_guard_model_bound_constants_unchanged_except_tighter_command_cap',
          set(constants_old) == set(constants_new) and constant_changes
          == {'COMMAND_SPEED_LIMIT': {'before': .26, 'after': .20}},
          {'changes': constant_changes, 'base_constants': constants_old,
           'current_constants': constants_new})
    guard = copy.deepcopy(sf_new['guard_motion'])
    stripper = StripRawKeyword(peer_only=True)
    guard = stripper.visit(guard)
    check('guard_geometry_braking_settled_math_ast_unchanged',
          stripper.count == 1 and syntax(guard) == syntax(sf_old['guard_motion']),
          {'sole_extra_keyword': 'peer valid_state(require_raw=True)',
           'stripped_keyword_count': stripper.count})
    changed = {name for name in sf_old if syntax(sf_old[name]) != syntax(sf_new.get(name))}
    check('all_other_pure_guard_and_tracker_functions_ast_unchanged',
          set(sf_new) - set(sf_old) == {'measured_velocity_error'}
          and not set(sf_old) - set(sf_new) and changed == {'valid_state', 'guard_motion'},
          {'added': sorted(set(sf_new) - set(sf_old)), 'changed': sorted(changed),
           'unchanged_count': len(sf_old) - len(changed)})
    valid = copy.deepcopy(sf_new['valid_state'])
    raw_index = [index for index, argument in enumerate(valid.args.kwonlyargs)
                 if argument.arg == 'require_raw']
    raw_default = (len(raw_index) == 1 and isinstance(valid.args.kw_defaults[raw_index[0]],
                   ast.Constant) and valid.args.kw_defaults[raw_index[0]].value is False)
    if raw_default:
        valid.args.kwonlyargs.pop(raw_index[0])
        valid.args.kw_defaults.pop(raw_index[0])
    strengthening = ast.parse('measured_velocity_error(state, require_raw=require_raw) is None',
                              mode='eval').body
    removed_strengthening = 0
    for node in ast.walk(valid):
        if isinstance(node, ast.BoolOp):
            old_values = node.values
            node.values = [item for item in old_values if syntax(item) != syntax(strengthening)]
            removed_strengthening += len(old_values) - len(node.values)
    check('valid_state_only_adds_explicit_raw_velocity_strengthening',
          raw_default and removed_strengthening == 1 and syntax(valid) == syntax(sf_old['valid_state']),
          {'new_keyword_default_false': raw_default,
           'removed_exact_strengthening_count': removed_strengthening})

    method_details = {}
    for name, allowed_changes, allowed_additions in (
            ('motion_safety.py', {'MotionSafety.__init__', 'MotionSafety.control_inputs_ready',
                                  'MotionSafety.emit_motion'}, {'MotionSafety.normal_velocity_fault'}),
            ('mr3_motion_control.py', {'MotionControlPhase.poll_once'}, set())):
        old_tree, new_tree = tree(before(PURE + name)), tree(read(PURE + name))
        left, right = functions(old_tree), functions(new_tree)
        changed = {key for key in left if key not in right or syntax(left[key]) != syntax(right[key])}
        additions, removals = set(right) - set(left), set(left) - set(right)
        method_details[name] = {'changed': sorted(changed), 'added': sorted(additions),
                                'removed': sorted(removals),
                                'unchanged_method_count': len(left) - len(changed)}
        method_details[name]['passed'] = (changed == allowed_changes and additions == allowed_additions
                                          and not removals)
    check('motion_node_and_control_non_authorized_methods_ast_unchanged',
          all(item['passed'] for item in method_details.values()), method_details)

    receipt_path = A13 + 'binary/mr3_p2a0_v13_drive_build_receipt_v1.json'
    receipt = json.loads(read(receipt_path))
    macro_paths = {
        'compiled_source_sha256': ROS + 'src/multi_robot/src/mr3_gazebo_diff_drive.cpp',
        'compiled_header_sha256': ROS + 'src/multi_robot/include/multi_robot/mr3_gazebo_diff_drive.hpp',
        'compiled_helper_sha256': ROS + 'src/multi_robot/include/multi_robot/paired_wheel_slew.hpp',
        'compiled_target_contract_sha256': ROS + 'src/multi_robot/include/multi_robot/mr3_drive_target.hpp'}
    source_hashes = {key: sha(read(path)) for key, path in macro_paths.items()}
    library = Path(receipt['library_path'])
    installed = Path(receipt['installed_path'])
    actual_binary = read(str(library.relative_to(args.root)))
    encoded = read(receipt['archived_library_gzip'])
    checks_raw = gzip.decompress(read(receipt['canonical_build_checks_gzip']))
    build_checks = json.loads(checks_raw)
    flags_path = ROS + 'build/multi_robot/CMakeFiles/mr3_gazebo_diff_drive.dir/flags.make'
    flags = read(flags_path).decode()
    macros = {}
    for key, definition in zip(macro_paths, ('MR3_DRIVE_SOURCE_SHA256', 'MR3_DRIVE_HEADER_SHA256',
                                            'MR3_DRIVE_HELPER_SHA256', 'MR3_DRIVE_TARGET_SHA256')):
        matches = re.findall(definition + r'=\\?"([0-9a-f]{64})\\?"', flags)
        macros[definition] = matches
    check('actual_so_four_compiled_sources_and_canonical_archive_match',
          all(receipt[key] == digest for key, digest in source_hashes.items())
          and all(macros[name] == [digest] for name, digest in zip(macros, source_hashes.values()))
          and all(digest.encode() in actual_binary for digest in source_hashes.values())
          and sha(actual_binary) == receipt['library_sha256']
          and len(actual_binary) == receipt['library_bytes']
          and sha(encoded) == receipt['archived_library_encoded_sha256']
          and gzip.decompress(encoded) == actual_binary and installed.is_symlink()
          and installed.resolve() == library.resolve()
          and sha(checks_raw) == receipt['canonical_build_checks_decoded_sha256']
          and build_checks['passed'] is True
          and build_checks['library']['sha256'] == receipt['library_sha256'],
          {'receipt': receipt_path, 'receipt_sha256': inputs[receipt_path]['sha256'],
           'source_hashes': source_hashes, 'actual_flags_macros': macros,
           'installed_symlink': str(installed), 'resolved_library': str(installed.resolve()),
           'actual_library_sha256': sha(actual_binary), 'actual_library_bytes': len(actual_binary),
           'archived_gzip_sha256': sha(encoded)})

    old_plan = json.loads(read(A12 + 'predeclared_plan_v12.json'))
    plan = json.loads(read(A13 + 'predeclared_plan_v13.json'))
    gate_keys = ['unchanged_gates', 'physical_response_criteria', 'angular_interface_criteria',
                 'angular_reset_criteria', 'settled_turn_criteria', 'pilot_budget_unchanged',
                 'robots_per_environment', 'gpu_calls', 'optimizer_steps', 'max_api_records',
                 'max_submitted_script_decisions', 'max_total_wall_seconds', 'api_budget_breakdown']
    gate_results = {key: canonical(plan[key]) == canonical(old_plan[key]) for key in gate_keys}
    drive_keys = ['unchanged_physics', 'native_gate', 'model_limit', 'terminal_coverage_limit',
                  'first_prerelease_interval', 'full_latency_bound_seconds',
                  'release_timestamp_phase', 'prewarm_command_scope', 'stop_interface']
    gate_results.update({'drive_contract.' + key: canonical(plan['drive_contract'][key])
                         == canonical(old_plan['drive_contract'][key]) for key in drive_keys})
    check('prospective_task_physical_settled_angular_source_age_and_pilot_gates_unchanged',
          all(gate_results.values()), {'exact_value_comparisons': gate_results,
                                      'draft_readiness': plan.get('readiness')})
    old_bindings = old_plan['independent_source_bindings']
    current_bindings = plan['independent_source_bindings']
    mutable_auditor_paths = {WIRELESS + path for path in (
        'mr3_learning/audit_motion.py', 'mr3_learning/audit_ppo.py',
        'mr3_learning/tests/test_audit_motion.py')}
    by_path = {item['path']: item for item in current_bindings}
    immutable = [binding for binding in old_bindings
                 if binding['path'] not in mutable_auditor_paths]
    history_kept = all(by_path.get(binding['path']) == binding for binding in immutable)
    mutable_kept = all(path in by_path for path in mutable_auditor_paths)
    binding_results = []
    for item in current_bindings:
        digest = sha(read(item['path']))
        binding_results.append({'path': item['path'], 'expected': item['sha256'],
                                'actual': digest, 'passed': digest == item['sha256']})
    check('original_73_immutable_bindings_and_three_reviewed_current_auditors_match',
          len(old_bindings) == 76 and len(immutable) == 73 and history_kept and mutable_kept
          and len({item['path'] for item in current_bindings})
          == len(current_bindings) and all(item['passed'] for item in binding_results),
          {'old_count': len(old_bindings), 'current_count': len(current_bindings),
           'immutable_count': len(immutable), 'mutable_auditor_paths': sorted(mutable_auditor_paths),
           'binding_results': binding_results})
    readiness = plan.get('readiness', {})
    readiness_status = readiness.get('status', '')
    plan_final = (not plan.get('new_source_bindings_pending') and not readiness.get('pending_bindings')
                  and isinstance(readiness_status, str) and 'ready' in readiness_status.lower()
                  and not re.search('draft|pending', readiness_status.lower()))
    if args.require_final_plan:
        check('final_plan_has_no_pending_source_bindings', plan_final, {
            'new_source_bindings_pending': plan.get('new_source_bindings_pending'),
            'readiness': plan.get('readiness')})
        linked = {}
        for document in ('MR3_ENV_CONTRACT.md', 'MR3_ADAPTER_CONTRACT.md', 'MR3_TASK_CONTRACT.md'):
            path = WIRELESS + document
            text = read(path).decode()
            for match in re.finditer(r'(?<!!)\[[^\]]*\]\(([^)]+)\)', text):
                target = match.group(1).split('#', 1)[0].strip('<>')
                if not target or '://' in target or target.startswith('mailto:'):
                    continue
                target_path = (args.root / path).parent / target
                linked[path + ' -> ' + target] = target_path.exists()
        check('contract_local_markdown_links_exist', all(linked.values()), linked)

    unchanged_inputs = all(sha((args.root / path).read_bytes()) == item['sha256']
                           for path, item in inputs.items())
    check('all_captured_static_inputs_unchanged_through_check', unchanged_inputs,
          {'count': len(inputs)})
    result = {'schema': 'mr3-p2a0-v13-research-gates-static-v2',
              'passed': all(item['passed'] for item in results.values()),
              'scope': 'read-only CPU/source/AST/byte/binary provenance check; no native credit',
              'base': args.base, 'argv': [sys.executable, *sys.argv], 'cwd': str(Path.cwd()),
              'script_sha256': sha(Path(__file__).read_bytes()), 'git_commands': commands,
              'checks': results, 'inputs': inputs, 'plan_final_bindings_checked': args.require_final_plan,
              'plan_bindings_pending': not plan_final, 'native_admission_granted': False,
              'wall_seconds': time.monotonic() - start}
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps({'passed': result['passed'], 'output': str(args.output),
                      'output_sha256': sha(args.output.read_bytes()),
                      'failed_checks': [key for key, item in results.items() if not item['passed']],
                      'plan_bindings_pending': result['plan_bindings_pending'],
                      'wall_seconds': result['wall_seconds']}))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
