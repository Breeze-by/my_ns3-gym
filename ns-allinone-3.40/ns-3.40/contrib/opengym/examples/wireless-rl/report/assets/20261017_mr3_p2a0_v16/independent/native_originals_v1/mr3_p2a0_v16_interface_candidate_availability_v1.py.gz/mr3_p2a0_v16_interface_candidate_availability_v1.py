"""Small completed returned-snapshot ledger only; no raw maps or new auditor."""
import hashlib
import json
from pathlib import Path
import time

EP = Path('/home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/'
          'mr3_p2a0_20261017_v16_interface/worker0/episode001_open_101')
OUTPUT = Path('/tmp/mr3_p2a0_v16_interface_candidate_availability_v1.json')
started = time.monotonic()
source = EP / 'transitions.jsonl'
payload = source.read_bytes()
records = []
for row in (json.loads(line) for line in payload.splitlines()):
    snap = row['snapshot']
    robot = snap['robots'][0]
    joint_goals = sorted({action // 100 for action, valid in enumerate(snap['joint_action_mask'])
                          if valid and action // 100 < 8})
    records.append({'elapsed': snap['task_elapsed_sec'], 'snapshot_sequence': snap['sequence'],
                    'snapshot_digest': snap['digest'],
                    'tb1_original_per_robot_GOAL_choices': [index for index, valid in
                                                           enumerate(snap['per_robot_action_mask'][0][:8]) if valid],
                    'tb1_original_joint_GOAL_choices': joint_goals,
                    'tb1_candidate_path_distances_m': [candidate['path_distances_m'][0]
                                                     for candidate in snap['candidates']],
                    'tb1_navigation_phase': robot['navigation']['phase'],
                    'tb1_accepted_goal_count': robot['navigation'].get('accepted_goal_count'),
                    'tb1_received_v': robot['v'], 'tb1_fresh': robot['fresh'], 'tb1_valid': robot['valid'],
                    'tb1_path_m': robot['activity']['estimated_path_m']})
digest = lambda value: hashlib.sha256(value).hexdigest()
result = {'schema': 'mr3-v16-returned-tb1-goal-availability-v1', 'passed': True,
          'scope': 'Returned received snapshots only. Candidate path null establishes original '
                   'interface ineligibility, not the raw-map/navigation cause. No hypothetical '
                   'window change or new execution credit.',
          'source': str(source), 'source_sha256': digest(payload),
          'source_before_after_stable': digest(source.read_bytes()) == digest(payload),
          'records': records,
          'actual_later_second_window_eligible_times': [r['elapsed'] for r in records
                                                      if 15 <= r['elapsed'] < 28
                                                      and r['tb1_original_joint_GOAL_choices']],
          'interpretation': 'Extending the second goal window alone cannot create a GOAL at any '
                            'recorded later boundary with no original legal GOAL. Raw full-map '
                            'replay would be needed to distinguish occupied-start/path-map or '
                            'other candidate feasibility causes.',
          'tool_sha256': digest(Path(__file__).read_bytes()),
          'wall_seconds': time.monotonic() - started}
result['passed'] = result['source_before_after_stable']
with OUTPUT.open('x') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
print(json.dumps({'path': str(OUTPUT), 'sha256': digest(OUTPUT.read_bytes()),
                  'passed': result['passed'], 'actual_later_second_window_eligible_times':
                  result['actual_later_second_window_eligible_times'],
                  'per_time_legal_GOAL_counts': {r['elapsed']: len(r['tb1_original_joint_GOAL_choices'])
                                               for r in records}}, indent=2))
raise SystemExit(0 if result['passed'] else 1)
