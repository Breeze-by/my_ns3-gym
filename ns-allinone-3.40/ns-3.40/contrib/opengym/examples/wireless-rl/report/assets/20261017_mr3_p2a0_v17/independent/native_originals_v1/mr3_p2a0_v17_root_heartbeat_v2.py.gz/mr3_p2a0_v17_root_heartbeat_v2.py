import json
from pathlib import Path
T=Path('/tmp'); R=Path('/home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0')
l=T/'mr3_p2a0_v17_remaining_matrix_v1.jsonl'
rows=[json.loads(x) for x in l.read_text().splitlines()]
print('ledger',json.dumps({k:v for k,v in rows[-1].items() if k in ('event','stage','operation','utc','passed','error')}))
active = next((r.get('stage') for r in reversed(rows) if r.get('stage')), None)
for stage in ('interface','terminal','reset','deadline'):
 if stage != active:continue
 d=R/('mr3_p2a0_20261017_v17_'+stage)
 if not d.exists():continue
 for p in sorted(d.glob('worker*/episode*/transitions.jsonl')):
  with p.open('rb') as f:
   f.seek(max(0,p.stat().st_size-1500000)); raw=f.read()
  lines=raw.splitlines(); last=None
  for line in reversed(lines):
   try:last=json.loads(line);break
   except (ValueError,UnicodeError):pass
  if last:
   s=last.get('snapshot',{});robots=s.get('robots',[])
   print(stage,p.parent.parent.name,p.parent.name,json.dumps(dict(kind=last.get('kind'),elapsed=s.get('task_elapsed_sec'),action=last.get('info',{}).get('command',{}).get('action'),reason=last.get('info',{}).get('reason'),terminated=last.get('terminated'),truncated=last.get('truncated'),robots=[dict(name=x.get('robot'),path=x.get('activity',{}).get('estimated_path_m')) for x in robots])))
 for suffix in ('_launch.json','_audit_execution_v1.json'):
  p=T/('mr3_p2a0_v17_'+stage+suffix)
  if p.exists():
   v=json.loads(p.read_text());print(p.name,{k:v.get(k) for k in ('status','passed','returncode','all_submitted_jobs_finished','runner_errors') if k in v})
