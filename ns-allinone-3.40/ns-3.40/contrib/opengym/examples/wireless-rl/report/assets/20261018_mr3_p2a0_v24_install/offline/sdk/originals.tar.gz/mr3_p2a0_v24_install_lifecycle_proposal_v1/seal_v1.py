"""Seal stopped lifecycle source/probe evidence, excluding CPU ELF bytes."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tarfile
import time

P = Path(__file__).parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
ROS = ROOT / 'ros2_ws/ros2-multi-robot-automap/src/multi_robot'
sha = lambda data: hashlib.sha256(data).hexdigest()
started = time.monotonic()
original = (P / 'source_b165_original.cpp').read_bytes()
source = (P / 'mr3_ray_box_corrector.proposed.cpp').read_bytes()
begin = original.index(b'    created = gazebo::event::Events::ConnectWorldCreated')
end = original.index(b'    ended = gazebo::event::Events::ConnectWorldUpdateEnd', begin)
callback = (P / 'created_callback_v1.txt').read_bytes()
assert source == original[:begin] + callback + original[end:]
assert source.replace(callback, original[begin:end], 1) == original
assert b'world->Iterations()' not in source
assert sha(source) == 'f82646c8434b77c42f585ac1828eda84640bac873f70cc7de6848cfbd6493473'
unchanged = {}
for relative, expected in [('src/mr3_ray_box_collision.cpp', 'd556dda57250da3680a7d5a9862416f6196cab9763e495ee75269307b87715cb'),
                           ('include/multi_robot/mr3_ray_box_collision.hpp', 'c619442d038e4bc6ea0695ada34d7074ee83d775b2137222ab9fb6bf8193879b')]:
    path = ROS / relative
    data = path.read_bytes()
    assert sha(data) == expected
    target = P / ('unchanged_' + path.name)
    target.write_bytes(data)
    unchanged[relative] = dict(path=str(path), sha256=expected, bytes=len(data))
compile_result = json.loads((P / 'compile_v1.json').read_text())
probe = json.loads((P / 'probe_v1.json').read_text())
syntax = json.loads((P / 'syntax_v2.json').read_text())
assert compile_result['returncode'] == probe['returncode'] == syntax['returncode'] == 0
assert probe['wall_seconds'] <= 20
rows = [json.loads(line) for line in (P / 'probe_v1.stdout.log').read_bytes().splitlines()]
assert len(rows) == 4
created, loaded, initialized, fini = rows
assert created['phase'] == 'world_created_during_load_before_world_init'
assert created['world_lookup_succeeded'] is True and created['physics_type'] == 'ode'
assert created['world_load_completed'] is False and created['world_sensors_initialized'] is False
assert created['world_clock_ns'] == created['model_sensor_count'] == 0
assert created['world_iterations'] is None and created['world_iterations_available'] is False
assert created['world_running_getter'] is True
assert created['native_ode_quickstep_iterations'] == 150 and created['physics_max_step_size_sec'] == .001
assert loaded['world_load_completed'] is True and loaded['world_iterations'] is None
assert initialized['world_iterations'] == 0 and initialized['world_iterations_available'] is True
assert all(fini[key] == 0 for key in ('run_calls', 'step_calls', 'robot_spawn_calls', 'ros_calls'))
review = dict(schema='mr3-v24-created-preinit-lifecycle-source-proposal-v1', passed=True,
              source_sha256=sha(source), original_source_sha256=sha(original),
              only_created_callback_changed=True, exact_inverse_restores_original_whole_bytes=True,
              hot_callback_and_all_other_cpp_bytes_unchanged=True, unchanged_core_header=unchanged,
              original_V23_failure='Actual log only records aggregate precondition exception. No individual guard values were captured; the precise original runtime value is unknown.',
              necessary_source_defect='WorldPrivate uint64_t iterations has no default initializer; World constructor does not assign it. World.Load emits worldCreated before World.Init assigns iterations=0. Reading this counter in the old callback was invalid regardless of the observed opaque abort.',
              retracted_prior_claim='WorldCreated does not imply an initialized actual iteration counter of zero. Prior review/source comments and installed row claiming such a readback are superseded, with original bytes preserved.',
              source_chain=[dict(path='primary/PhysicsIface_11.10.2.cc', lines='50-54 create_world registers before returning; load_world calls World.Load'),
                            dict(path='primary/World_11.10.2.cc', lines='constructor127-176 initialized flags; 337-347 ODE creation/load; 414 worldCreated; 497 initialized iterations=0; 564 Running=!stop; 2967 IsLoaded; 3091 Iterations raw backing read'),
                            dict(path='primary/WorldPrivate.hh', lines='81 common::Time simTime; 307 uninitialized uint64_t iterations'),
                            dict(path='primary/gazebo_shared.cc', lines='SystemPlugin Load and Init both occur during setup before Server creates/loads the world; Init is not a later-world hook'),
                            dict(path='primary/ODEPhysics_11.10.2.cc', lines='141 dInitODE2 constructor; 349 ODEPhysics.Init is empty, so it does not reset the registered collider table'),
                            dict(path='primary/Link_11.10.2.cc', lines='59 constructed sensors vector; 1117 GetSensorCount returns vector.size'),
                            dict(path='primary/Time_11.10.2.cc', lines='Time default constructor initializes sec/nsec zero')],
              new_installed_contract=dict(installation_phase='world_created_during_load_before_world_init', world_clock_ns=0,
                                          world_iterations=None, world_iterations_available=False,
                                          world_iterations_unavailable_reason='counter_initialized_only_in_World_Init',
                                          world_load_completed=False, world_sensors_initialized=False, model_sensor_count=0,
                                          world_running_getter='Actual typed bool, diagnostic only: Running=!stop; true is valid before Run.',
                                          native_ode_quickstep_iterations=150, physics_max_step_size_sec=.001,
                                          other_fields='Actual lookup/physics/nativeODE booleans, physics_type=ode, fixed source/epoch/PID/library/pair and failed_preconditions=[]'),
              failure_evidence='fatal_installation_precondition emits actual defined fields and failed_preconditions before throwing; duplicate install remains fatal. No Iterations getter is called.',
              sdk_probe=dict(actual_created=created, actual_after_load=loaded, actual_after_init=initialized, actual_fini=fini,
                             compiled_executable_sha256=sha((P / 'lifecycle_probe').read_bytes()),
                             compile_wall_seconds=compile_result['wall_seconds'], run_wall_seconds=probe['wall_seconds'],
                             total_charged_by_root=compile_result['wall_seconds'] + probe['wall_seconds'],
                             scope='One authorized Gazebo SDK create/load/init/fini of actual open world; no Run/Step/ROS/robot spawn/actual corrector plugin load or new library build. The probe never reads the preInit counter; this is not a reexecution of the original V23 guard or proof of its exact failed branch.'),
              syntax=dict(initial_failure='syntax_v1 external Gazebo/ODE -I headers promoted old warnings by -Werror; source unchanged.',
                          corrected='syntax_v2 uses external SDK -isystem exactly as prior SDK builds; strict source syntax PASS, no shared library produced.',
                          source_sha256=syntax['source_sha256'], cpu_wall_seconds=syntax['wall_seconds']),
              unchanged_scope='No source canonical/Git/actual library changes, core/header/hot collider/physics values/control/task/geometry/threshold/mask changes; no new matrix/native experiment.',
              pending='Independent source/consumer review, root exact canonical promotion/new actual library build and new frozen full matrix. This proposal grants no native repair/task/PPO credit.')
(P / 'source_review_v1.json').write_text(json.dumps(review, indent=2) + '\n')


def metadata(path):
    value = path.stat()
    return [value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns]


selected, excluded, contents = [], [], {}
for path in sorted(P.rglob('*')):
    if not path.is_file():
        continue
    before = metadata(path)
    raw = path.read_bytes()
    assert metadata(path) == before
    entry = dict(path=str(path), member=str(path.relative_to('/tmp')), sha256=sha(raw), bytes=len(raw), stat=before)
    if raw.startswith(b'\x7fELF') or '__pycache__' in path.parts or path.suffix in ('.pyc', '.pyo'):
        entry['reason'] = 'CPU executable/cache bytes excluded; exact identity retained.'
        excluded.append(entry)
    else:
        selected.append(entry)
        contents[entry['member']] = raw
manifest = dict(schema='mr3-v24-install-lifecycle-proposal-manifest-v1', files=selected, exclusions=excluded,
                selected_files=len(selected), selected_raw_bytes=sum(row['bytes'] for row in selected),
                self_excluded=True, source_and_probe_writers_stopped=True)
manifest_raw = (json.dumps(manifest, indent=2) + '\n').encode()
manifest_path = P / 'manifest_v1.json'
with manifest_path.open('xb') as stream:
    stream.write(manifest_raw)
archive = P.parent / 'mr3_p2a0_v24_install_lifecycle_sealed_v1.tar.gz'
with archive.open('xb') as output:
    with gzip.GzipFile(fileobj=output, filename='', mode='wb', mtime=0) as encoded:
        with tarfile.open(fileobj=encoded, mode='w') as tar:
            for member, raw in [*contents.items(), (str(manifest_path.relative_to('/tmp')), manifest_raw)]:
                info = tarfile.TarInfo(member)
                info.size = len(raw)
                info.mtime = 0
                info.mode = 0o644
                tar.addfile(info, io.BytesIO(raw))
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(selected) + 1
    for entry in selected:
        raw = tar.extractfile(entry['member']).read()
        assert sha(raw) == entry['sha256'] and len(raw) == entry['bytes']
    assert tar.extractfile(str(manifest_path.relative_to('/tmp'))).read() == manifest_raw
for entry in selected + excluded:
    path = Path(entry['path'])
    assert metadata(path) == entry['stat'] and sha(path.read_bytes()) == entry['sha256']
handoff = dict(schema='mr3-v24-install-lifecycle-proposal-handoff-v1', passed=True,
               source_path=str(P / 'mr3_ray_box_corrector.proposed.cpp'), source_sha256=sha(source),
               source_review_path=str(P / 'source_review_v1.json'), source_review_sha256=sha((P / 'source_review_v1.json').read_bytes()),
               manifest_path=str(manifest_path), manifest_sha256=sha(manifest_raw),
               archive_path=str(archive), archive_sha256=sha(archive.read_bytes()), archive_bytes=archive.stat().st_size,
               files=len(selected), raw_bytes=manifest['selected_raw_bytes'], excluded=len(excluded),
               roundtrip_members=len(selected)+1, all_source_final_sha_stat_stable=True,
               author_source_and_metadata_STOP=True, canonical_or_installed_binary_changed=False,
               execution=dict(argv=os.sys.argv, wall_seconds=time.monotonic()-started),
               sdk_probe_compile_wall=compile_result['wall_seconds'], sdk_probe_runtime_wall=probe['wall_seconds'],
               scope='TMP proposal/custody only; all earlier failed warnings and original failure semantics retained.')
with (P / 'handoff_v1.json').open('x') as stream:
    json.dump(handoff, stream, indent=2)
    stream.write('\n')
print(json.dumps(handoff))
