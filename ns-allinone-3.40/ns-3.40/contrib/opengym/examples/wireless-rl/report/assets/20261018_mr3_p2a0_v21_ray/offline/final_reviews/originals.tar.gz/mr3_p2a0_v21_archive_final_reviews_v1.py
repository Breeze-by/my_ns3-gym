import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path('/home/zhuyulab/ns3-workspace')
A = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v21_ray'
target = A / 'offline/final_reviews'
assert not target.exists()
files = list(Path('/tmp').glob('mr3_p2a0_v21_ray_source_independent_review_v2*'))
files += [p for p in Path('/tmp/mr3_p2a0_v21_ray_identity_counterexample_v1').rglob('*') if p.is_file()]
files += [Path('/tmp/mr3_p2a0_v21_ray_review_canonical_snapshot_v2.json'),
          Path('/tmp/mr3_p2a0_v21_actual_invoked_chain_readonly_review_v1.json'),
          Path('/tmp/mr3_p2a0_v21_promote_sources_v1.py'), Path(__file__)]
assert all(p.is_file() for p in files)
report = Path('/tmp/mr3_p2a0_v21_ray_source_independent_review_v2.json')
assert hashlib.sha256(report.read_bytes()).hexdigest() == 'b12cff4f199678d5fabc6de579200c901df488ed673b1a881f1dc80a1d0f4543'
buffer = io.BytesIO()
entries = []
with tarfile.open(fileobj=buffer, mode='w') as tar:
    for path in sorted(set(files)):
        before = path.stat()
        raw = path.read_bytes()
        info = tarfile.TarInfo(str(path.relative_to('/tmp')))
        info.size, info.mtime, info.mode = len(raw), 0, 0o644
        tar.addfile(info, io.BytesIO(raw))
        entries.append({'source': str(path), 'member': info.name, 'bytes': len(raw),
                        'sha256': hashlib.sha256(raw).hexdigest(),
                        'stat': [before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns]})
encoded = gzip.compress(buffer.getvalue(), compresslevel=6, mtime=0)
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(encoded))) as tar:
    assert tar.getnames() == [row['member'] for row in entries]
    for row in entries:
        assert hashlib.sha256(tar.extractfile(row['member']).read()).hexdigest() == row['sha256']
        path = Path(row['source'])
        value = path.stat()
        assert [value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns] == row['stat']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
target.mkdir()
(target / 'originals.tar.gz').write_bytes(encoded)
result = {'schema': 'mr3-v21-final-review-custody-v1',
          'scope': 'Source-only independent review, original identity counterexample, stable pre-promotion canonical snapshot and promotion helper. No native admission claim.',
          'files': entries, 'original_count': len(entries),
          'original_bytes': sum(row['bytes'] for row in entries),
          'archive': 'originals.tar.gz', 'archive_bytes': len(encoded),
          'archive_sha256': hashlib.sha256(encoded).hexdigest(),
          'full_roundtrip_and_source_final_sha_stat_verified': True}
(target / 'manifest_v1.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ('original_count', 'original_bytes', 'archive_bytes', 'archive_sha256')}))
