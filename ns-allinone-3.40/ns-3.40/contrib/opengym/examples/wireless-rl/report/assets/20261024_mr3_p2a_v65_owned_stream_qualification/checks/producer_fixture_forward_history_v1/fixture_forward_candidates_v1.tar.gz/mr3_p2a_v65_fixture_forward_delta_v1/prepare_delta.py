"""Forward test fixtures only; no canonical writes or production-gate changes."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

ROOT=Path('/home/zhuyulab/ns3-workspace')
HERE=Path(__file__).resolve().parent
R=Path('ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/test')
W=Path('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/mr3_learning/tests')
paths=[R/'test_motion_safety_reach.py',R/'test_mr3_reach_support_wiring.py',
       R/'test_mr3_worker_startup_readiness.py',W/'test_mr3_probe_lifecycle_fixture.py',
       W/'test_reach_outward_cancel_v2_producer.py']
before={str(p):(ROOT/p).read_text() for p in paths};after=dict(before)


def change(p,a,b,count=1):
    key=str(p);assert after[key].count(a)==count,(key,a[:75],after[key].count(a),count)
    after[key]=after[key].replace(a,b)


p=R/'test_motion_safety_reach.py'
change(p,'from multi_robot_exploration.mr3_safety_intent import payload_sha256\n',
       'from multi_robot_exploration.mr3_safety_intent import payload_sha256\n'
       'from multi_robot_exploration.mr3_motion_authority import PROFILE as MOTION_AUTHORITY_PROFILE\n')
change(p,'    node.reach_enabled = True\n','''    node.reach_enabled = True
    node.motion_authority_profile = MOTION_AUTHORITY_PROFILE
    # This fixture already substitutes Owner.decide to isolate joint publication
    # ordering. Supply the corresponding explicitly artificial receiver result;
    # real owner/stop/receipt handshakes are covered by the callback suite.
    node.receiving_permission = lambda name, tracker, request, clock_ns: {
        "effective_request": [request["v"], request["w"]] if request is not None else [0., 0.],
        "permission": "normal_reach" if request is not None else "zero_only",
        "state": "ACTIVE", "raw_goal_generation": None,
        "raw_goal_association": "UNKNOWN_UNSTAMPED_TWIST",
        "scope": "ARTIFICIAL_RECEIVER_RESULT_FOR_JOINT_PUBLICATION_ONLY"}
''')

p=R/'test_mr3_reach_support_wiring.py'
change(p,'from multi_robot_exploration import motion_safety as guard\n',
       'from multi_robot_exploration import motion_safety as guard\n'
       'from multi_robot_exploration.mr3_motion_authority import PROFILE as MOTION_AUTHORITY_PROFILE\n')
change(p,"              'safety_contract': contract}\n",
       "              'safety_contract': contract,\n"
       "              'motion_authority_profile': MOTION_AUTHORITY_PROFILE if contract == 'mr3-reach-v1' else ''}\n")
# Every Reach reset in this file tests geometry selection, not missing authority.
change(p,"'safety_contract': 'mr3-reach-v1', 'reach_geometry_rule': value}",
       "'safety_contract': 'mr3-reach-v1', 'motion_authority_profile': MOTION_AUTHORITY_PROFILE,\n"
       "               'reach_geometry_rule': value}")
change(p,"        safety_contract='mr3-reach-v1', reach_geometry_rule=rule,\n",
       "        safety_contract='mr3-reach-v1', motion_authority_profile=MOTION_AUTHORITY_PROFILE,\n"
       "        reach_geometry_rule=rule,\n")
change(p,"'safety_contract':'mr3-reach-v1','reach_geometry_rule':rule}",
       "'safety_contract':'mr3-reach-v1','motion_authority_profile':MOTION_AUTHORITY_PROFILE,\n"
       "            'reach_geometry_rule':rule}")
change(p,"'safety_contract':'mr3-reach-v1'})",
       "'safety_contract':'mr3-reach-v1',\n"
       "                                                'motion_authority_profile':MOTION_AUTHORITY_PROFILE})")

p=R/'test_mr3_worker_startup_readiness.py'
change(p,"    worker.safety_contract = 'mr3-reach-v1' if reach else 'legacy'\n",
       "    worker.safety_contract = 'mr3-reach-v1' if reach else 'legacy'\n"
       "    worker.motion_authority_profile = WORKER.MOTION_AUTHORITY_PROFILE if reach else None\n")
change(p,"'safety_contract': 'mr3-reach-v1',\n",
       "'safety_contract': 'mr3-reach-v1',\n"
       "            'motion_authority_profile': WORKER.MOTION_AUTHORITY_PROFILE,\n")
change(p,"'safety_contract': 'mr3-reach-v1', 'startup_readiness_protocol': WORKER.STARTUP_READINESS_PROTOCOL,\n",
       "'safety_contract': 'mr3-reach-v1', 'motion_authority_profile': WORKER.MOTION_AUTHORITY_PROFILE,\n"
       "        'startup_readiness_protocol': WORKER.STARTUP_READINESS_PROTOCOL,\n",count=2)
change(p,"    request['safety_contract'] = 'legacy'\n",
       "    request['safety_contract'] = 'legacy'\n"
       "    request.pop('motion_authority_profile')\n")

p=W/'test_mr3_probe_lifecycle_fixture.py'
change(p,'from pathlib import Path\nimport sys\n',
       'import ast\nimport builtins\nimport hashlib\nfrom pathlib import Path\nimport symtable\nimport sys\n')
change(p,'from multi_robot_exploration.mr3_observation import _action_masks\n','''
def _canonical_action_masks():
    """Execute the exact canonical mask/dependency AST without importing SLAM.

    The complete original file is read once and SHA-bound; all constants are
    extracted from its original assignments, never copied/replaced in tests.
    Unexpected dependencies fail rather than inventing an alternate mask.
    """
    path=COMP/'multi_robot_exploration/mr3_observation.py'
    data=path.read_bytes();text=data.decode();tree=ast.parse(text,filename=str(path))
    declarations={}
    for statement in tree.body:
        if isinstance(statement,ast.FunctionDef):declarations[statement.name]=statement
        elif isinstance(statement,ast.Assign):
            for target in statement.targets:
                if isinstance(target,ast.Name):declarations[target.id]=statement
        elif isinstance(statement,(ast.Import,ast.ImportFrom)):
            for alias in statement.names:declarations[alias.asname or alias.name.split('.')[0]]=statement
    required=['_action_masks'];selected={};seen=set()
    def globals_in(table):
        names={symbol.get_name() for symbol in table.get_symbols()
               if symbol.is_referenced() and symbol.is_global()}
        for child in table.get_children():names.update(globals_in(child))
        return names
    while required:
        name=required.pop()
        if name in seen or name in vars(builtins):continue
        seen.add(name)
        if name not in declarations:raise AssertionError('unbound canonical mask dependency: '+name)
        statement=declarations[name];selected[id(statement)]=statement
        if isinstance(statement,(ast.Import,ast.ImportFrom)):
            if name not in {'math','np','timestamp_ns'}:
                raise AssertionError('unexpected canonical mask import: '+name)
        elif isinstance(statement,ast.FunctionDef):
            required.extend(globals_in(symtable.symtable(ast.get_source_segment(text,statement),str(path),'exec')))
        else:
            required.extend(n.id for n in ast.walk(statement.value)
                            if isinstance(n,ast.Name) and isinstance(n.ctx,ast.Load))
    body=[n for n in tree.body if id(n) in selected]
    namespace={'__name__':'canonical_action_mask_fixture','__file__':str(path)}
    exec(compile(ast.Module(body=body,type_ignores=[]),str(path),'exec'),namespace)
    assert namespace['_action_masks'].__code__.co_filename==str(path)
    return namespace['_action_masks'],str(path),hashlib.sha256(data).hexdigest(),tuple(sorted(seen))


_action_masks,ACTION_MASK_SOURCE_PATH,ACTION_MASK_WHOLE_FILE_SHA256,ACTION_MASK_DEPENDENCIES=_canonical_action_masks()
''')
p=W/'test_reach_outward_cancel_v2_producer.py'
change(p,'            from multi_robot_exploration.mr3_observation import _action_masks\n',
       '            from .test_mr3_probe_lifecycle_fixture import _action_masks\n')

rows=[];patch=[]
for relative,text in after.items():
    ast.parse(text,filename=relative)
    dest=HERE/'candidate'/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(text)
    old=before[relative];rows.append({'target':relative,'source':str(dest),'bytes':len(text.encode()),
        'sha256':hashlib.sha256(text.encode()).hexdigest(),'expected_current_sha256':hashlib.sha256(old.encode()).hexdigest()})
    patch+=difflib.unified_diff(old.splitlines(True),text.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative)
(HERE/'forward_fixture_delta.patch').write_text(''.join(patch))
(HERE/'install_manifest_v1.json').write_text(json.dumps({'schema':'mr3-v65-forward-test-fixture-delta-v1',
    'status':'AST_REVIEW_ONLY_NOT_CANONICAL_INSTALLED_OR_TESTED','files':rows,
    'production_gate_modified':False,'old_failure_overwritten':False,'new_dependency_installed':False,
    'mask_source_whole_file_bound':True,'mask_AST_uses_original_constants_and_dependency_closure':True},indent=2)+'\n')
print(json.dumps({'AST_PASS':True,'test_fixture_files':len(rows),'patch_bytes':len(''.join(patch).encode())}))
