"""Capture CPU review evidence for an unapplied profile draft."""
from pathlib import Path
from fractions import Fraction
import ast
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
OUT = Path('/tmp/mr3_p2a0_v13_navigation_profile_draft_v1')
ROS = Path('ros2_ws/ros2-multi-robot-automap')
W = Path('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def main():
    command = ['/usr/bin/python3', '/tmp/mr3_p2a0_v13_navigation_profile_draft_v1_tests.py']
    start = time.monotonic()
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONNOUSERSITE': '1'}, check=False)
    wall = time.monotonic() - start
    for suffix, payload in [('stdout', result.stdout), ('stderr', result.stderr)]:
        with (OUT / ('checks_v1.' + suffix)).open('xb') as stream:
            stream.write(payload)
    changed = subprocess.run(['git', 'diff', '--exit-code', '--',
        *[str(ROS / 'src/multi_robot/params' / ('nav2_params_' + r + '_0.yaml'))
          for r in ('tb1', 'tb2', 'tb3')], str(ROS / 'src/multi_robot/package.xml')],
        cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    for p in [OUT / 'mr3_actual_nav2_parameters_v13_draft.py', Path(command[1]), Path(__file__)]:
        ast.parse(p.read_bytes(), filename=str(p))
    tracked_old = W / 'report/assets/20261017_mr3_p2a0_v4/independent/mr3_actual_nav2_parameters_v4.py'
    paths = [OUT / 'navigation_profile_v1.patch', OUT / 'actual9_readback_spec_v1.json',
             OUT / 'manifest_v1.json', OUT / 'mr3_actual_nav2_parameters_v13_draft.py',
             Path(command[1]), Path('/tmp/mr3_p2a0_v13_navigation_profile_prepare_v1.py'), Path(__file__)]
    evidence = {
        'schema': 'mr3-nav2-profile-draft-cpu-checks-v1',
        'passed': result.returncode == 0 and changed.returncode == 0,
        'scope': 'CPU-only YAML semantic diff, typed readback matcher/mutations, unchanged checkout targets; no ROS init/services/native',
        'base_freeze': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(),
        'command': command, 'environment_overrides': {'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONNOUSERSITE': '1'},
        'exit_code': result.returncode, 'wall_duration_sec': wall, 'test_methods': 8,
        'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
        'stderr_sha256': hashlib.sha256(result.stderr).hexdigest(),
        'checkout_target_diff_exit': changed.returncode,
        'initial_construction_attempt': {'exit_code': 2, 'cause': 'shell outer quoting syntax error before source generation',
            'raw_tool_output_archived': False, 'scope': 'construction wrapper only; final generator and outputs retained'},
        'earlier_direct_test_call': {'exit_code': 0, 'test_methods': 8,
            'raw_tool_output_archived': False, 'scope': 'same final test source; this record captures a second actual call with raw stdout/stderr'},
        'bindings': [{'path': str(p), 'sha256': sha(p)} for p in paths],
        'old_immutable_readback_sha256': sha(ROOT / tracked_old),
        'no_native_or_simulator_run': True,
    }
    write_json(OUT / 'checks_v1.json', evidence)

    command_acc = Fraction(1, 2) + Fraction(287, 2000) * Fraction(16, 5)
    assert command_acc == Fraction(1199, 1250) and command_acc < 1
    observation = ROOT / ROS / 'src/multi_robot_exploration/multi_robot_exploration/mr3_observation.py'
    shim_cpp = Path('/tmp/mr3_p2a0_v13_local_control_sources_v1/nav2_rotation_shim_controller.cpp')
    smoother_cpp = Path('/tmp/mr3_p2a0_v13_local_control_sources_v1/velocity_smoother.cpp')
    bt = Path('/opt/ros/humble/share/nav2_bt_navigator/behavior_trees/navigate_to_pose_w_replanning_and_recovery.xml')
    lib = Path('/opt/ros/humble/lib/libnav2_rotation_shim_controller.so')
    design = {
        'schema': 'mr3-nav2-profile-review-basis-v1', 'status': 'proposal_only_not_applied',
        'profile': 'mr3-nav2-shim-dwb-020-v1-draft',
        'requested_changes': {'command_linear_limit_mps': .2, 'dwb_primary_unchanged': 'dwb_core::DWBLocalPlanner',
            'shim_angle_rad': .5, 'shim_sample_distance_m': .3, 'shim_desired_angular_radps': .8,
            'shim_angular_accel_radps2': 3.2, 'shim_closed_loop': True,
            'smoother_feedback_unchanged': 'OPEN_LOOP', 'explicit_dwb_and_smoother_linear_accel_mps2': .5},
        'general_basis': [
            'An actual received path with +2.5855rad local heading nevertheless selected CW -.2105rad/s under original finite-horizon DWB critics. This supports explicit path-heading alignment as a general method, not a unique attribution for old open w0e2.',
            'Installed Nav2 RotationShimController delegates ordinary path following to the same DWB plugin and same FollowPath parameter namespace; all original critics/scales and main global planner remain unchanged.',
            'The installed default BT replans nominally at 1Hz. New commanded .20m/s times one nominal second plus .10m arrival tolerance gives a .30m local design scale. This is not a hard trajectory/timing bound.',
            'A .5rad trigger/disengage threshold is a uniform roughly29degree heading error threshold, independent of scene/seed/goal coordinates.',
            'Explicit .5m/s2 linear and3.2rad/s2 angular command slew require at most .9592m/s2 combined differential-wheel rim slew for .287m separation, below unchanged rim maxa1; actual-current paired slew and body verification remain required.',
        ],
        'wheel_command_slew_math': {'expression': '1/2 + (287/2000)*(16/5)',
            'exact_fraction': str(command_acc), 'decimal_mps2': float(command_acc),
            'unchanged_driver_maxa_mps2': 1.,
            'scope': 'command kinematic compatibility only; no world-body response or arrival proof'},
        'critical_limits': [
            'Legal new goals are only strictly farther than .10m. A path with no point .30m from its first pose bypasses Shim and uses original DWB; no .30m candidate minimum was introduced.',
            'The sampled distance is measured from path.front, not the latest robot pose. Nominal replanning rate and command cap do not prove sample remains ahead under stale paths, tracking error or actual-body overshoot.',
            'Shim closed_loop uses supplied actual angular velocity. Its feasibility clamp can return .88rad/s for current1.2, target.8, accel3.2 and period.1; final smoother/guard caps remain required. Parameter readback is not an absolute raw-output proof.',
            'The .5 linear acceleration is newly explicit. Old effective YAML omitted smoother max_accel/max_decel; official1.1.20 defaults were +/-2.5m/s2. Driver limit remains rim1, not guaranteed body.5.',
            'TF/sample/rotation collision failures can delegate to DWB. Repeated path updates may re-enter alignment. Shim alone does not prove progress or candidate executability.',
            'Existing final guard peer geometry, measured speed bound .30 and stopping reserve .144 remain unchanged; legitimate peer stopping can still prevent translation. A controller improvement cannot be credited as all-three movement without native body/received activity evidence.',
            'Original FollowPath trans_stopped_velocity .25 is retained and exceeds proposed .20 maximum; original RotateToGoal/goal-check semantics remain, with that interaction explicitly unchanged.',
        ],
        'acceptance_dependencies': [
            'Root must change COMMAND_SPEED_LIMIT from .26 to .20 in the received-only motion guard and update focused tests/pins/docs; this draft does not edit that source.',
            'Install/rebuild the three canonical YAMLs and package runtime dependency; verify active launch chooses those installed files and archives effective parameters.',
            'Freeze a new readback script asset, bind its exact Git bytes in benchmark hook, and retain current exact transport profile and nine-node paused-release validation. Preserve immutable v4 script and all older failures.',
            'Bind installed shim package version, plugin XML and actual mapped shim library for native evidence. Same-tag official source is explanatory, not an attestation of binary compilation.',
            'Update exact source hashes in preparation/protocol/PPO auditors and build/source preflights where applicable; freeze commands/contracts before a new native matrix.',
            'Retain original raw/body angular, wheel-math, contact, phase, source-age, nativegoal, received activity and strict close gates. Preserve oldV12FAIL and laterSKIP, no inherited PASS.',
            'A short engineering fixture is not a 95% three-robot mapping task or proof of PPO effectiveness. Pilot quota remains unchanged, no training was started.',
        ],
        'source_bindings': [{'path': str(p), 'sha256': sha(p)} for p in [observation, shim_cpp, smoother_cpp, bt, lib]],
        'shim_package_version': subprocess.check_output(['dpkg-query', '-W', '-f=${Version}', 'ros-humble-nav2-rotation-shim-controller']).decode(),
        'official_sources': [
            'https://raw.githubusercontent.com/ros-navigation/navigation2/1.1.20/nav2_rotation_shim_controller/src/nav2_rotation_shim_controller.cpp',
            'https://raw.githubusercontent.com/ros-navigation/navigation2/1.1.20/nav2_velocity_smoother/src/velocity_smoother.cpp'],
        'native_or_ros_execution_performed': False,
    }
    write_json(OUT / 'basis_and_acceptance_v1.json', design)
    print(json.dumps({'passed': evidence['passed'], 'checks': str(OUT / 'checks_v1.json'),
        'patch_sha256': sha(OUT / 'navigation_profile_v1.patch'),
        'readback_draft_sha256': sha(OUT / 'mr3_actual_nav2_parameters_v13_draft.py'),
        'basis_sha256': sha(OUT / 'basis_and_acceptance_v1.json')}))


if __name__ == '__main__':
    main()
