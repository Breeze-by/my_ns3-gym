"""Small synthetic entry gates only; never opens the actual iters150 receipt/raw."""
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest import mock

PATH = Path('/tmp/mr3_p2a0_v19_pack_closed_iters150_v1.py')
SPEC = importlib.util.spec_from_file_location('iters150_custody_candidate', PATH)
HELPER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(HELPER)
SAFE_ENV = {'PATH': '/usr/bin:/bin', 'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1',
            'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'TZ': 'UTC'}
PREFIX = ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/'
          '20261018_mr3_p2a0_v19/native/iters150')


class ClosedEntryGates(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(prefix='mr3_v19_iters150_entry_cpu_')
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.source = self.root / 'mr3_p2a0_20261018_v19_iters150'
        self.source.mkdir()
        self.target = self.root / 'selected'
        self.execution_path = self.root / 'synthetic_execution.json'
        self.execution = {'status': 'completed', 'stage': 'iters150', 'passed': True,
                          'freeze': 'e' * 40, 'plan_sha256': 'a' * 64,
                          'returncode': 0, 'errors': [], 'native_wall_seconds': 0.1,
                          'diagnostic_consumers': []}

    def store_execution(self):
        self.execution_path.write_text(json.dumps(self.execution) + '\n')

    def invoke(self):
        self.store_execution()
        argv = [str(PATH), '--source', str(self.source), '--target', str(self.target),
                '--execution', str(self.execution_path), '--prospective-prefix', PREFIX]
        with mock.patch('sys.argv', argv), mock.patch.dict(os.environ, SAFE_ENV, clear=True), \
                contextlib.redirect_stdout(io.StringIO()):
            HELPER.main()
        return json.loads((self.target / 'manifest.json').read_bytes())

    def summary(self, passed=True):
        (self.source / 'benchmark_summary.json').write_text(
            json.dumps({'freeze': self.execution['freeze'], 'passed': passed}) + '\n')
        (self.source / 'tiny_original.txt').write_text('synthetic source bytes only\n')

    def consumer(self, label, passed):
        path = self.root / (label + '.json')
        raw = (json.dumps({'passed': passed, 'synthetic': True}) + '\n').encode()
        path.write_bytes(raw)
        self.execution['diagnostic_consumers'].append({
            'label': label, 'passed': passed, 'returncode': 0 if passed else 1,
            'errors': [], 'output': {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest()}})

    def test_running_receipt_rejected_before_summary_artifacts_or_raw_inventory(self):
        self.execution['status'] = 'native_closed'
        with mock.patch.object(HELPER, 'inventory', side_effect=RuntimeError('must not inventory')) as inv:
            with self.assertRaises(AssertionError):
                self.invoke()
            inv.assert_not_called()
        self.assertFalse(self.target.exists())

    def test_wrong_stage_rejected_before_raw_inventory(self):
        self.execution['stage'] = 'baseline'
        with mock.patch.object(HELPER, 'inventory') as inv:
            with self.assertRaises(AssertionError):
                self.invoke()
            inv.assert_not_called()

    def test_bool_verdict_required_without_coercing_one_to_true(self):
        self.execution['passed'] = 1
        with self.assertRaises(AssertionError):
            self.invoke()
        self.assertFalse(self.target.exists())

    def test_scientific_physical_fail_is_preserved_in_successful_byte_custody(self):
        self.summary()
        self.consumer('observer_1ms', True)
        self.consumer('original_physical', False)
        result = self.invoke()
        self.assertTrue(result['passed'])
        self.assertTrue(result['original_stage_passed'])
        self.assertFalse(result['closed_consumer_artifacts'][1]['original_passed'])
        self.assertFalse(result['original_diagnostic_consumers'][1]['passed'])
        self.assertNotIn('followup_iters150_originally_skipped', result)

    def test_closed_stage_capture_fail_keeps_its_actual_false_and_errors(self):
        self.summary()
        self.execution.update(passed=False, returncode=1, errors=['synthetic capture failed'])
        self.consumer('observer_1ms', False)
        self.consumer('original_physical', False)
        result = self.invoke()
        self.assertTrue(result['passed'])
        self.assertFalse(result['original_stage_passed'])
        self.assertEqual(result['original_execution_errors'], ['synthetic capture failed'])
        self.assertTrue(all(row['original_passed'] is False
                            for row in result['closed_consumer_artifacts']))

    def test_failed_benchmark_is_preserved_without_native_acceptance_claim(self):
        self.summary(False)
        self.execution.update(passed=False, returncode=1, errors=['synthetic native failed'])
        result = self.invoke()
        self.assertFalse(result['original_benchmark_passed'])
        self.assertFalse(result['original_stage_passed'])
        self.assertIn('byte custody', result['pass_scope'])

    def test_missing_output_from_original_skipped_job_is_explicit_not_invented(self):
        self.summary()
        self.execution.update(passed=False, errors=['synthetic missing proof'])
        self.execution['diagnostic_consumers'] = [
            {'label': 'observer_1ms', 'status': 'skipped_missing_live_proof', 'passed': False}]
        result = self.invoke()
        self.assertFalse(result['closed_consumer_artifacts'][0]['available'])
        self.assertFalse(result['closed_consumer_artifacts'][0]['original_passed'])
        self.assertFalse(result['original_stage_passed'])

    def test_artifact_sha_tamper_rejected_before_source_inventory(self):
        self.summary()
        self.consumer('observer_1ms', False)
        self.execution['diagnostic_consumers'][0]['output']['sha256'] = '0' * 64
        with mock.patch.object(HELPER, 'inventory') as inv:
            with self.assertRaises(AssertionError):
                self.invoke()
            inv.assert_not_called()


if __name__ == '__main__':
    unittest.main(verbosity=2)
