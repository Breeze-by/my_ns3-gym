# V72 后路线判定：暂停“只求长路径”的分批试跑

**建议：不以提高总体 min-path 为由继续2+1/1+2，也不直接重跑完整资格。** 当前失败是三机未产生足够收到平移，不是目标在5秒承诺前自然完成。我前一份分批建议是等证据的条件提案；V72不支持其“让tb3目标变长以存活”的动机。分批可能改变后续交互，但这个作用尚未观测，不能作为启动新World的证明。

只读新派生JSON `/tmp/mr3_p2a_v72_masked_stimulus_description_v1.json`，834713B / SHA `56fb198f793c2450fd63b4bbc325181964a7b7ca9c3e2ebf0be2b1c94c7cdcd9`。四个重建比较全True；没有重开两原件、motion/drive或旧raw，没有执行reader/World。原V71资格FAIL保持，V72成功仅是描述完整。

## 支持该判断的收到事实

- `$.goal_opportunity_bank_and_joint_distributions[0].selected`：初始056，即(0,5,6)，path为 .522617/.422617/.467848m，相对当前朝向的目标方位为3.0440/3.0200/1.4673rad。
- `$.received_timeline[5:11].robots[*].current_round.moving_WAIT`：task5至10共6个观测，三机都已 active/owned，原WAITmask与承诺到期为True；全部moving谓词中恰好只有`forward_speed_ge_0_08`和`path_delta_ge_0_05`为False。期间最大正收到v依次 .00089972/.00090482/.00012876m/s；t10新增path依次 .00645377/.00649674/.00297707m。
- 同段收到角运动明显：tb1/tb2的w约−.27至−.34rad/s，yaw从约−1.09/−1.11变为−2.60/−2.62；tb3先有正转，随后小幅改变符号，t5/t10 yaw约1.081/1.069。这个状态支持“先转动、尚未进入足够平移”的描述，**不证明原raw请求/guard输出、实际motor或plant原因**。
- `$.received_timeline[10].command`为cleanup999。三机首次收到终态均在task12、snapshot13，分类为`received_CANCELED_without_matching_scientific_WAIT`。33个收到状态里无SUCCEEDED；不能把cleanup取消当moving取消，也不能推断实际终态生成/交付的精确时刻。

## 为什么集合 min-path 提高不是解决证据

原perANDjoint集合的best单/双/三GOAL最小path分别.522617/.499379/.422617m，但单GOAL最佳088只服务tb1，双GOAL最佳018只服务tb1和tb2；它们提高统计最小值时排除了tb3。

tb3的全部per-legal候选仅c2(.396656m，初始方位−.001876rad)和c6(.467848m，1.467306rad)。当前已选c6就是其最大path。原单GOAL joint只允许它选c2（882）；原双GOAL可选c6（856），三GOAL056同样可选c6。因此两种分批都没有给tb3更长的已观察路径；单独发它甚至缩短。task1在另一task0动作后的mask、银行和peer目标状态仍UNKNOWN，不能由本次实际三机同时active后的快照替代。

## 后续应区分“刺激需求”和“执行链原因”

可以前瞻研究显式alignment/warmup刺激合同，或减少初始转向需求的**软排名**，保原perANDjoint而不加方向硬filter。存在实际同帧合法备选：三GOAL142的方位约[1.5732,−1.4386,−.001876]、path[1.3994,.3689,.3967]；它在这12个原三GOAL动作中最大绝对目标方位最小。双GOAL382方位约[−.4701,−.001876]、path[.3588,.3967]。这些是原bit=True的输入备选，不是新轨迹、Nav2路径初始切向、平移可用性或未来joint合法性证明；不能据此直接再花完整matrix费用。

在新World前，建议先对已闭合A71另立有限scope，看同一task1–10附近的真实因果链，**此报告没有消费那些日志**：

1. 若实际有效请求持续只要求旋转，guard/motor如实旋转，之后才出现正常平移请求，则“原10秒cleanup打断旋转/启动”才有继续研究warmup或重新预声明刺激时间布局的依据。需要实际收到平移机会证据，不能只按目标方位除以角速度推保证。
2. 若raw已有正v而authority/Reach/guard实际压零，应先解释真实owner/lease/几何/安全判据；延长warmup不能作为修复证明。
3. 若实际APPLIED/电机目标已有正向合成平移而收到v仍很小，应转向传输/plant/观测核对，不能靠重排目标掩盖。

只有第一类被观测支持，才考虑一个显式新族：旧V3/masked不改，新producer/独立reader完整登记，预声明warmup/科学moving-WAIT机会与失败截止，保真实sameowner、一次baseline、v≥.08与新增path≥.05、5秒承诺、原B/R/STOP/contact与所有角色。收到自然终态立即按真实结果处理，不延迟来造active；cleanup不授信用。若32秒/两轮/三rest+交棒在实测时序下没有可靠机会，应先报告该刺激合同不适配、再明确设计与审核，不能临场挪窗或加步冒原profile PASS。capacityFalse、原pilot/final额度和P2A strict95出口均不变。
