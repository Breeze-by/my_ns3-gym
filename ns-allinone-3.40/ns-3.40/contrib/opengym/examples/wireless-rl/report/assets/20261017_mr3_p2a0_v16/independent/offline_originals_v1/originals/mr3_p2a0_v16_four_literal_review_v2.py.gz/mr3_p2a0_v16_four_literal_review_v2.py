import ast,hashlib,json,pathlib,subprocess
R=pathlib.Path("/home/zhuyulab/ns3-workspace");A=R/"ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v16/independent";T=pathlib.Path("/tmp");D=T/"mr3_p2a0_v16_matrix_draft_v1";base="17ef3cb212aacd6e9e4fcde65783bdf2528da955"
rows=[];changes=[]
for path in sorted(A.glob("*.py")):
 if not (D/"independent"/path.name).exists():continue
 new=path.read_bytes();assert new==(D/"independent"/path.name).read_bytes()
 oldrelative=str(path.relative_to(R)).replace("v16","v15");old=subprocess.check_output(["git","show",base+":"+oldrelative],cwd=R);oldtree=ast.parse(old);newtree=ast.parse(new)
 mapping={"20261017_mr3_p2a0_v15/independent/mr3_independent_angular_reset_matrix_v15.py":"20261017_mr3_p2a0_v16/independent/mr3_independent_angular_reset_matrix_v16.py","20261017_mr3_p2a0_v15/independent/mr3_independent_physics_matrix_v15.py":"20261017_mr3_p2a0_v16/independent/mr3_independent_physics_matrix_v16.py","mr3_independent_physics_matrix_v15.py":"mr3_independent_physics_matrix_v16.py"}
 baseline=ast.parse(old.decode().replace("v15","v16").replace("V15","V16"))
 class RevertTools(ast.NodeTransformer):
  def visit_Constant(self,node):
   reverse={v:k for k,v in mapping.items()}
   if isinstance(node.value,str) and node.value in reverse:
    changes.append(dict(path=str(path.relative_to(R)),previous=reverse[node.value],current=node.value));return ast.copy_location(ast.Constant(reverse[node.value]),node)
   return node
 normalized=RevertTools().visit(newtree)
 marker=len(changes);baseline=RevertTools().visit(baseline);del changes[marker:]
 assert ast.dump(normalized,include_attributes=False)==ast.dump(baseline,include_attributes=False),str(path)
 rows.append(dict(path=str(path.relative_to(R)),sha256=hashlib.sha256(new).hexdigest()))
assert len(rows)==9 and len(changes)==4
assert sum(x["path"].endswith("audit_stage.py") for x in changes)==2 and sum(x["path"].endswith("audit_stage_tests_v1.py") for x in changes)==2
plan=json.loads((D/"predeclared_plan_v16.json").read_bytes());assert plan["readiness"]["status"]=="draft_pending_root_final_review"
for s in plan["stages"]:
 c=s["command"]
 if "--preparation-motion-probe" in c:assert c[c.index("--preparation-probe-version")+1]=="mr3-p2a0-outward-cancel-v5" and c[c.index("--steps")+1]=="32"
assert [plan[k] for k in ["max_api_records","max_submitted_script_decisions","max_total_wall_seconds"]]==[608,596,18000]
result=dict(passed=True,canonical_nine_files=rows,extra_tool_literals=changes,extra_tool_literal_count=4,rest_whole_AST_same=True,scope="Nine mechanical versioned coordinators: only two reset-wrapper paths plus two fake physics basenames are tool-dependency changes beyond core version strings. All immutable readers, math, schedulers, pool/receipt gates and finite cleanup semantics retained. Draft plan only V5/32, never admission.")
output=T/"mr3_p2a0_v16_four_literal_review_v2.json"
with output.open("x") as f:json.dump(result,f,indent=2);f.write("\n")
print(json.dumps(result,indent=2))
