"""Produce /tmp-only review artifacts; does not promote or execute native."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
HERE = Path(__file__).resolve().parent
ASSETS = W / 'report/assets'
TARGET = ASSETS / '20261017_mr3_p2a0_v17/independent'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


files = [(HERE / 'benchmark.py', W / 'mr3_learning/benchmark.py'),
         (HERE / 'audit_preparation.py', W / 'mr3_learning/audit_preparation.py'),
         (HERE / 'test_preparation_comparison.py',
          W / 'mr3_learning/tests/test_preparation_comparison.py'),
         (HERE / 'test_benchmark_stimulus_v6.py',
          W / 'mr3_learning/tests/test_benchmark_stimulus_v6.py')]
wrapper_proof = []
for stem in ('mr3_independent_angular_reset_matrix', 'mr3_independent_physics_matrix'):
    name = stem + '_v17.py'
    source = HERE / 'assets/20261017_mr3_p2a0_v17/independent' / name
    previous = ASSETS / '20261017_mr3_p2a0_v16/independent' / (stem + '_v16.py')
    normalized = source.read_text().replace('v17', 'v16').replace('v6', 'v5')
    assert normalized == previous.read_text()
    assert ast.dump(ast.parse(normalized)) == ast.dump(ast.parse(previous.read_text()))
    wrapper_proof.append({'old': str(previous), 'old_sha256': sha(previous),
                          'new': str(source), 'new_sha256': sha(source),
                          'inverse_version_labels_text_and_ast_equal': True})
    files.append((source, TARGET / name))
name = 'mr3_independent_reset_wrappers_v17_tests.py'
files.append((HERE / 'assets/20261017_mr3_p2a0_v17/independent' / name, TARGET / name))
entries, patch = [], []
for source, destination in files:
    relative = destination.relative_to(ROOT).as_posix()
    previous = destination.read_text() if destination.exists() else ''
    patch.extend(difflib.unified_diff(previous.splitlines(True), source.read_text().splitlines(True),
                                    fromfile='a/' + relative if destination.exists() else '/dev/null',
                                    tofile='b/' + relative))
    entries.append({'source': str(source), 'proposed_canonical_path': relative,
                    'sha256': sha(source), 'bytes': source.stat().st_size,
                    'base_sha256': sha(destination) if destination.exists() else None})
patch_path = HERE / 'review_only.patch'
with patch_path.open('x') as handle:
    handle.writelines(patch)
checks = HERE / 'checks_v2.json'
result = {
    'schema': 'mr3-v17-stimulus-v6-handoff-v1', 'state': 'prototype_only_not_promoted',
    'source_writers_stopped': True, 'native_run_performed': False,
    'formal_audit_performed': False, 'fixture_version': 'mr3-p2a0-outward-cancel-v6',
    'steps_per_episode': 32,
    'cli_suffix': ['--preparation-motion-probe', '--preparation-probe-version',
                   'mr3-p2a0-outward-cancel-v6', '--steps', '32'],
    'files': entries, 'review_patch': {'path': str(patch_path), 'sha256': sha(patch_path)},
    'checks': {'path': str(checks), 'sha256': sha(checks),
               'passed': json.loads(checks.read_bytes())['passed'],
               'fresh_methods': {'actual_default_boundary_replay': 4, 'portable_lifecycle': 11},
               'unchanged_checks_v1_successful_commands': {'capacity': 10, 'reset_wrappers': 19},
               'note': 'Original checks_v1 overall FAIL retained: one new test omitted second '
                       'baseline initialization, plus two style issues. Corresponding qualification '
                       'and wrapper commands passed with unchanged sources, so not rerun.'},
    'wrapper_inverse_proof': wrapper_proof,
    'minimal_design': [
        'Shared probe_action_v4 gains late_goal_window=False. Existing V4/V5 default behavior '
        'and complete diagnostics remain unchanged; V6 wrapper enables nonapproach and late.',
        'Only new late predicate uses integer source-time contract '
        '15e9<=round(original_task_elapsed_sec*1e9)<26e9. Original elapsed is not changed or '
        'passed under a fake clock; default V4/V5 float windows and original V3 stay untouched.',
        'Original initial and13..15 windows retain V3 reverse/outward ranking. New late branch '
        'directly ranks same original-mask+lifecycle+nonapproach subset by unchanged outward '
        'maxGOAL/minMargin/sumMargin/path/action; no reverse preference there.',
        'Late phase records separate late_goal_decisions with true snapshot/time and original '
        'versus filtered counts. Existing goal_decisions refer to the inherited V5 subset; '
        'these are engineering fixture availability counts, not actor interface availability.',
        'Same original firstWAIT>=3s/received fresh idle abs(v)<=.01 recovery; same active '
        'accepted motion .08m/s+.05m trigger; same typed returned-command latch; original '
        '5s mask and28s final WAIT remain authoritative. A submitted WAIT stays held.',
        'ExactV6/32 capacity exclusion and two new A17 metadata adapters only. Old V2..V5 '
        'eligibility/math unchanged. Unknown-version mutation advances knownV6 to unknownV7.'],
    'cpu_facts': {
        'legacy_functions_AST_unchanged': ['_probe_goal_order', 'probe_action', 'probe_action_v3',
                                          'probe_action_v5', '_probe_nonapproaching_goal_action',
                                          'record_probe_v4_submission'],
        'V4_V5_actual_input_equivalence': 'Each old/new selector replays all32 V15 and V16 '
        'snapshots with equal actions and complete diagnostics. V4/V15 and V5/V16 use original '
        'real command info and match every actual command; cross-version pairs explicitly use '
        'hypothetical matching typed command receipts.',
        'actual_V16_V6_prefix': {'first_counterfactual_difference_sec': 22.,
                                'V6_action': 499, 'original_V5_action': 899,
                                'scope': 'No changed trajectory after22 simulated; no native credit.'},
        'real_double_boundary': {'release': 20.12, 'after26': 46.12,
                                'elapsed': 46.12 - 20.12, 'initial_float_prototype_action': 27,
                                'new_ns_predicate_action': 888},
        'latest25_fixture': 'Original mask holds KEEP26..29, allows WAIT30, then held WAIT31; '
                           '2s remaining at32 is an observation budget, not rest evidence.'},
    'original_mandatory_gates': {
        'angular': 'Each robot>=1 qualifying sign span; aggregate both signs; >=1 same robot '
                   'with both signs. No added each-robot reverse condition.',
        'physics': 'Per robot at least one credited A OR B plus all original bounds/errors/'
                   'nonrest and closure gates; A/B remain separate, no new AND.',
        'math_sources': ['7a472ba7efdd55addc710b98c66c89feff7f5092f214f76fd76cd4ca526343d0',
                         '2516e394f60eac5dd24fd66b51c4c48fc37245090eb1626ebe1c7a3a23f8bafb']},
    'risks': [
        'A later legal received GOAL opportunity does not establish Nav2 execution, guard-clear '
        'motion,>=.1s prior linear output or credited A/B physical response.',
        'Original candidate seed body-clearance gate remains unchanged; no raw-map/truth '
        'special case or production exploration fallback is added.',
        'Peer motion can invalidate direction later. Late outward ranking intentionally '
        'does not predict angular reverse; original full angular/physical gates still mandatory.',
        'Latest integer25 permits5s commitment to30 and2s observation to32. Original .78s/3fresh '
        'rest requirements still need real measurements; no sampling theorem claimed.',
        'New complete four-stage same-freeze native matrix remains required. No PPO training/'
        'effectiveness or95% mapping credit; previousV16 FAIL unchanged.'],
    'root_owned_followup': [
        'Review then explicitly authorize promotion; no canonical changes by proposal.',
        'ENV/audit_ppo/plan/coordinator metadata/sourcepins and exact A17 wrapper paths.',
        'PARAMETER_REVIEW_SCRIPT remains originalA13 source path; no reader/profile/physics '
        'parameter or actor observation/mask changes. Pilot budget unchanged.'],
    'preserved_initial_artifacts': [
        'initial_float_boundary_benchmark.py: rejected first prototype with binary64 late26 bug.',
        'checks_v1.json/all stdout/checks_v1_source_*.py: initial test setup/style failures.',
        'Actual V15/V16 raw records are read-only original evidence, never overwritten.']}
with (HERE / 'handoff_v1.json').open('x') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
print(json.dumps({'handoff': str(HERE / 'handoff_v1.json'),
                  'sha256': sha(HERE / 'handoff_v1.json'), 'files': entries}, indent=2))
