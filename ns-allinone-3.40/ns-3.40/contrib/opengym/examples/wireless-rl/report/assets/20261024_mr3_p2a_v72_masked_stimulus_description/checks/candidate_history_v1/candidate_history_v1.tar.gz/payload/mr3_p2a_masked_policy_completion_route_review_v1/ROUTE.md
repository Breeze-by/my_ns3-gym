# Masked 资格之后：容量、minimum、pilot、final 的最小执行路线

当前没有假定 A71 matrix PASS，也没有 policy 容量资格。本次仅读当前代码、A71 准备模板、已生成的 V69 plan 配置、V70 末账和既有容量派生报告；没有调用 reader、PPO、模型、World，或重读旧科学 raw、pstats、342 库。V69 plan 仅说明仍相同的 policy 配额/注册形状，不能给 masked family 任何旧资格信用。

**先解决两个接线边界。** 当前 `reach_policy_chain.stage_spec/execute_stage` 和 `ppo.main` 没有读取 capacity proof 的代码门；`capacity=False` / no-auto-policy 由 A71 matrix-only driver 与 Root 外部逐阶段准入执行。A71 没有完整 policy main→finalizer→费用结算 parent。已有 policy finalizer 明示其 passed 不包括自己的执行费用。故本轮 qualification PASS 只能解锁“考虑下一阶段”，不能直接启动 policy，不能把任一 summary.passed 当作最终资源通过。Root 需先声明一个只编排现成模块的固定外部 parent：实际 wait、全部 submitted child 排空、typed 保存身份、连续端点及 source 前后，严格按相应 scope 收费；自身源/SHA、scope、资源和实际 argv 预封，不给任意目标接口，也不改科学模块。若选择把新 parent 放 canonical，则必须在新 source freeze 前完成，不能在资格通过后插装源码并给旧 qualification 改 freeze。

**同 freeze 是强制条件。** `execute_stage` 要求 clean source gate、实际同 freeze qualification；`ppo.main` 用当前 HEAD 重验资格，再拒 dirty tree。成功 matrix 后先只在 `/tmp` 留容量/账/关闭事实，保持 HEAD==origin==G、plan/binding/source/ELF 不变。不要先 canonical archive/docs/commit 再尝试同一资格的 policy。可预先做关闭 metadata 到 `/tmp`，不得重写旧 verdict；任何算法/资源/plan/source 调整需要显式新版本/新 freeze 和必要 fresh CPU/资格，不得回填旧活动。实际保存原件与源稳定义务继续执行。

## 1. 实际资格与前账

资格须是新 G 的完整12EP/30roles，所有 required PASS，无 FAIL/SKIP/UNKNOWN，实际 native/outer waits/source/ELF/保存身份闭合；masked interface1+reset8 共9EP必须有真正独立 selector/lifecycle proof，authority12、compound motor、Reach、clock/cadence、物理/contact 及原其他门同时成立。原 V69/V67 等失败不复判。现有 A71 driver 只 matrix→absence→qualify，policy 不自动提交。

V70 实际入账 U=111365.9618345326018，C=180000，R=68634.0381654673982；ledger6688B/SHA1b354545c34bc4165fc5f6f128f947c09262a7b2945bebf0f589f066963cee7a。描述活动 PASS 与原 native False 的 presence 对象分开，不是物理/学习资格。A71 后必须使用实际完整 parent 费用 F 得到 R_after=68634.0381654673982−F，不能继续用入场余额。若实际 F≤47220，才有条件得到 R_after≥21414.0381654673982；这不是对合作式上限的硬实时保证。工程总额仍为代理受持续委托选择，非数值用户批准。

原独立 pilot 余额1870 decisions/2905.9547395464029秒、final-only900 decisions上限/9000秒保持；不得借它们做工程、容量调参或失败重试。minimum 工程1800，加上实际未花的 external300余额 e；旧计划 balance 条件 R_after≥1800+e 只是资金门，不是耗时充足证明。e 用真实 external waits/完整端点核，不能把必要 finalizer 当0秒；若没有足够实际尾部额度，应暂缓或在工程 C 内前瞻重新声明，不向 pilot/final 转账。

## 2. 原 cap 覆盖什么

| 阶段 | 总额 | 外部finalizer | main上限 | native字面 | 动态实际native最高值 |
|---|---:|---:|---:|---:|---|
| minimum | 工程1800 | 工程external余量e，另实收 | 1800 |1150| min(1150,1800−prework−500) |
| pilot | 2905.9547395464029 |300在原总额内|2605.9547395464029|2100|min(2100,2105.9547395464029−prework)|
| final validation |9000|300在原总额内|8700|8500|8200−prework（再向下取整到毫秒）|

500只是最低内部 tail 预算预留，不是完整 audit 的容量证据。完整费用包括进程/模型启动、资格及前驱重验、watcher、实际 native、正常关闭、完整 PPO full/每EP FIFO/manifest/strict custody、source/raw/episode/checkpoint 绑定重核及最终摘要。PPO 自己的 wall 计时在资格验证之后才开始；reach_execution 的 child wait 也不含它自己的 source before/after。必须收完整外部 parent bootstrap→post-source，包含 gaps，nested wait 只作分解而不叠加。

另一个成本来源是递归：minimum execute/finalize各至少1次完整资格重验；pilot execute/finalize各至少2次；validation execute/finalize各至少3次，并重复前驱 policy/artifact 绑定。`stage_evidence` 不仅查PID，还递归 `_validate_predecessor` 并完整 SHA 重核。300秒 finalizer 因而不是免费的元数据尾。最终须合 actual main+finalizer 的 scope union、从 main起点到final结束的连续端点均≤原总额，finalizer本身≤300；actual tool reap/所有保存身份 gone 仍必需。超额全费 FAIL，不得把科学审计移到CPU0关闭阶段。

Root 已提供 V69 closed native interface1036.994759473秒/32返回，整 parent1166.99234597秒。这是当前明确风险，不能忽略；但 native 包含启动/关闭，且原 required audits 未派发，不能把它除以32再乘300预测 final。V60 容量报告中的旧真实成本也只是历史不同 source/profile 输入范围，不能授予当前资格。source/kernel提速或32-step前缀都不能代替当前完整链测量。

## 3. 逐段推进，不一次放行

1. **minimum**：仅在本轮资格真实通过、同G稳定、实际工程余额及尾部 funded、Root明确记录本次有限准入后，调用既有 `reach_policy_chain --stage minimum`。这是工程侧16样本学习/整链能力试验，不承诺一定容纳。要求恰好16 eligible decisions、所有 native attempts 对齐关闭episode、正整数 optimizer.step 和真实参数变化、完整原 PPO/full/FIFO/custody/最终身份及费用通过。任何 failure 保留，跳后继。实际测得模型/训练/PPO full/finalizer成本后再判断 pilot。当前 pilot 训练是重新从 seed41 初始化，**不续用 minimum checkpoint**；不能暗加 --checkpoint。
2. **pilot准入**：结合 minimum 完整端点及本轮实际2-worker负载证据，填单独容量判断；没有依据就暂缓，不把16→64线性放大。当前声明请求64、workers2、episode-steps64；代码首轮实际把总64分到两个各最多32的任务，早终止可能增加后续 reset。只有实际2≤eligible≤64、正更新、完整审计/关闭/原2905.9547395464029总费用均通过才是 pilot PASS。64是请求上限，1870是原余额，不可静默扩请求。固定保存其 `final.zip` SHA；不得手挑中间checkpoint、未声明续训或看 final-only seeds 后重选模型。
3. **final容量工程测量**：在 pilot final.zip 真正关闭后，仍保 clean G/原plan/原qualification，用单独预声明工程scope和独占输出，执行下节固定非final容量活动。该活动不花 final-only9000、不训练、不改checkpoint、不选择更好模型。不足就工程侧恒等提速/新版本/新qual，不扩政策额度或减少任务/门。
4. **final准入/验收**：只有实际容量 proof 足以支持本次完整负载并有明确余量，Root才单独准入一次已声明 validation。从同一个 pilot final.zip 精确SHA、同G物理tensor归一化、deterministic=True、optimizer updates=0运行open401/402/403。workers4在这3个任务上实际最多3活跃环境，每个300-step上限、总900上限；真正提前成功可正常终止，不能为了容量计数继续已终止任务。最终必须3个真实严格任务成功、correct_free_coverage≥.95、quality/参与PASS、0 contact且监控fresh、nav协议closed、原elapsed<300以及全部Reach/authority/compound/clock/source/fee门成立。0更新和权重不变要由实际hook+独立checkpoint重放证明。evaluation保存的zip可有不同序列化metadata，要求原input checkpoint文件SHA不变及policy weights相等，不凭空要求重保存zip与输入zip字节相同。

## 4. 同G、工程收费的实际容量活动

这是下一步需要预声明的固定编排，不是已执行或已安装的入口。复用当前 canonical PPO evaluate 与所有原审计，不增加新 sampler/控制律/数学 reader；不使用 `reach_policy_chain --stage validation` 冒跑非final schedule（它会正确拒绝）。固定scope示例：同G/PLAN/QUAL、已锁 pilot final.zip SHA，`open:101,open:102,open:103`、workers4实际3环境、900 decisions上限、episode-steps300、evaluate、seed41、原 seed/start/support/actuation/authority/normalization。禁止401/402/403，禁止optimizer更新、改权重、按结果换checkpoint或重试调seed。

固定 parent 自身源/SHA/scope/argv/工程前账先封，外部编排仅调用已有模块；如需 canonical 新入口，应前置进新freeze，不能事后改既有资格。完整parent可用与final相同的**工程9000**测量上限（main8700/外尾300/内尾500，native仍按现有向下公式），但实际是否funded必须先扣本轮matrix、minimum和其他实际工程费用，确保 C 内有这笔完整预约；这是新工程活动，不从 final-only预算出账。Root必须另作明确实际准入，本任务未启动它。

现成 native CLI形状（仅说明，不执行）：`PY -m mr3_learning.ppo --safety-contract mr3-reach-v1 --reach-plan PLAN --reach-qualification QUAL --mode evaluate --checkpoint PILOT_FINAL --workers 4 --schedule open:101,open:102,open:103 --decisions 900 --episode-steps 300 --wall-seconds EFFECTIVE_NATIVE --seed 41 --batch-size 64 --epochs 4 --device cuda:0 --seed-rule exact-point-bridge-v2 --start-graph-rule point-attachment-3x3-v1 --reach-geometry-rule cone-support-v2 --base-domain FIXED_UNIQUE --base-port FIXED_UNIQUE --output-root ENGINEERING_ROOT --run-id FIXED_CAPACITY_RUN`。

Parent须同时保留实际watcher、运行原 `audit_reach_ppo`、每EP `audit_reach_peer_control`/FIFO manifest、`native_custody_reach review`、所有输入/权重/source和typed保存身份复核，完整actualwait/rc、读字节与末费用。可以复用 policy_chain 的纯预算和job构造函数，但不得调用 validation 的成功判据假装非final任务是final。容量结论是性能/完整性范围；原任务 timeout/False保留，不能充作95%成功。安全/科学计算/闭合错误仍不能借容量标签洗掉。

准入 proof 必须写实际三EP各自 dt总和/API数/正时步数、并发环境数、startup/native/模型/full/FIFO/closure/递归资格核验/源重核/finalizer真实完整端点及source/G/ckpt/normalization绑定。若提前成功使实际负载小于3×300，记录真实覆盖范围，**不声明未测900上限容量**；若任何required失败/partial/unknown、超9000或300尾、仍有身份/输出漂移，容量拒绝/未覆盖，final-only保持未动。通过一次代表性工程负载也不是硬实时或跨seed成功保证，应留预先说明的余量，最终仍按原实际cap判。容量不足必须先工程提速及必要新freeze/资格，不能改300、95%、安全门或增加policy总额。

## 5. 固定 policy 入口与最终结算

每段只用已有 `reach_policy_chain --plan PLAN --freeze G --qualification QUAL --stage minimum|pilot|validation`，外层 `reach_execution --scope engineering|pilot|validation`；child argv必须是 `[learner_python,-m,mr3_learning.reach_policy_chain,...]`，不要在child `-m`前插-B（outer可-B，环境PYTHONDONTWRITEBYTECODE=1）。真实main退出后立即在同段固定parent内调用 `--finalize-outer-wait MAIN/actual_wait.json --output FINAL`，不要留交互等待耗掉300尾；finalizer也要实际wait、source绑定及scope收费。

`stage_evidence`会重建完整科学验收/保存身份/前驱/最终checkpoint并要求与保存final receipt完全相等。pilot/final不能跳过这个实际前驱门。外部parent还须独立合并完整main/final scope费用与连续端点、所有实际wait/源码前后/资源余额；finalizer.passed本身不含它自己的总费用，不是P2A最终PASS。直到三严格final成功、0 eval更新、同pilot checkpoint/归一化、所有完整审计、actual手续费/身份/源闭合真实成立，才有P2A完成依据；文档/归档留到clean-G科学合取完成之后，旧FAIL原字节保留。
