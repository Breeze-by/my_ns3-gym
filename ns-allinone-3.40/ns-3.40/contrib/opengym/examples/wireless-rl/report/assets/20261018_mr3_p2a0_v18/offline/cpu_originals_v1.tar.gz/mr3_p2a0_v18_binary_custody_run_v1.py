from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

script=Path('/tmp/mr3_p2a0_v18_binary_custody_v1.py')
env=dict(os.environ)
removed=[]
for key in list(env):
    if key.startswith('CONDA') or key in ('PYTHONPATH','PYTHONHOME','VIRTUAL_ENV','LD_LIBRARY_PATH',
        'AMENT_PREFIX_PATH','CMAKE_PREFIX_PATH','COLCON_PREFIX_PATH','ROS_PACKAGE_PATH'):
        removed.append(key)
        del env[key]
env.update(PATH='/usr/bin:/bin:/usr/sbin:/sbin',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1')
argv=['/bin/bash','--noprofile','--norc','-c',
      'source "$1" && source "$2" && exec /usr/bin/python3 "$3"',
      'mr3-binary-custody','/opt/ros/humble/setup.bash',
      '/home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/install/setup.bash',str(script)]
log=Path('/tmp/mr3_p2a0_v18_binary_custody_v1.log')
start=time.monotonic()
utc=datetime.now(timezone.utc).isoformat()
with log.open('xb') as output:
    result=subprocess.run(argv,cwd='/home/zhuyulab/ns3-workspace',env=env,stdout=output,stderr=subprocess.STDOUT)
receipt={'argv':argv,'cwd':'/home/zhuyulab/ns3-workspace','removed_inherited_environment_keys':removed,
    'environment_override':{'PATH':'/usr/bin:/bin:/usr/sbin:/sbin','PYTHONNOUSERSITE':'1','PYTHONDONTWRITEBYTECODE':'1'},
    'helper_source_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),
    'start_utc':utc,'end_utc':datetime.now(timezone.utc).isoformat(),
    'wall_sec':time.monotonic()-start,'exit_code':result.returncode,
    'stdout':str(log),'stdout_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
with Path('/tmp/mr3_p2a0_v18_binary_custody_execution_v1.json').open('x') as output:
    json.dump(receipt,output,indent=2)
    output.write('\n')
print(json.dumps(receipt,indent=2))
raise SystemExit(result.returncode)
