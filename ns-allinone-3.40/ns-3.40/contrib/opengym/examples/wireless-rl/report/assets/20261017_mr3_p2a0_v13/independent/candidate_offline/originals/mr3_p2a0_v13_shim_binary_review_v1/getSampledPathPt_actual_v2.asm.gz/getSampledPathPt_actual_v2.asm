0000000000019b20 <nav2_rotation_shim_controller::RotationShimController::getSampledPathPt()@@Base>:
   19b20:	f3 0f 1e fa          	endbr64 
   19b24:	48 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rdx
   19b2b:	aa aa aa 
   19b2e:	41 57                	push   %r15
   19b30:	41 56                	push   %r14
   19b32:	41 55                	push   %r13
   19b34:	41 54                	push   %r12
   19b36:	55                   	push   %rbp
   19b37:	53                   	push   %rbx
   19b38:	48 83 ec 78          	sub    $0x78,%rsp
   19b3c:	4c 8b a6 80 01 00 00 	mov    0x180(%rsi),%r12
   19b43:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
   19b4a:	00 00 
   19b4c:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   19b51:	31 c0                	xor    %eax,%eax
   19b53:	48 8b 86 88 01 00 00 	mov    0x188(%rsi),%rax
   19b5a:	4c 29 e0             	sub    %r12,%rax
   19b5d:	49 89 c5             	mov    %rax,%r13
   19b60:	49 c1 fd 05          	sar    $0x5,%r13
   19b64:	4c 0f af ea          	imul   %rdx,%r13
   19b68:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
   19b6d:	48 83 f8 60          	cmp    $0x60,%rax
   19b71:	0f 86 ca 78 ff ff    	jbe    11441 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0xf71>
   19b77:	f2 41 0f 10 64 24 28 	movsd  0x28(%r12),%xmm4
   19b7e:	f2 41 0f 10 6c 24 30 	movsd  0x30(%r12),%xmm5
   19b85:	48 89 f5             	mov    %rsi,%rbp
   19b88:	48 83 7c 24 18 01    	cmpq   $0x1,0x18(%rsp)
   19b8e:	f2 0f 11 64 24 10    	movsd  %xmm4,0x10(%rsp)
   19b94:	f2 0f 11 6c 24 08    	movsd  %xmm5,0x8(%rsp)
   19b9a:	0f 84 16 78 ff ff    	je     113b6 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0xee6>
   19ba0:	49 89 fe             	mov    %rdi,%r14
   19ba3:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   19ba9:	b8 01 00 00 00       	mov    $0x1,%eax
   19bae:	eb 12                	jmp    19bc2 <nav2_rotation_shim_controller::RotationShimController::getSampledPathPt()@@Base+0xa2>
   19bb0:	41 8d 45 01          	lea    0x1(%r13),%eax
   19bb4:	49 89 c5             	mov    %rax,%r13
   19bb7:	48 3b 44 24 18       	cmp    0x18(%rsp),%rax
   19bbc:	0f 84 f4 77 ff ff    	je     113b6 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0xee6>
   19bc2:	48 8d 1c 40          	lea    (%rax,%rax,2),%rbx
   19bc6:	48 c1 e3 05          	shl    $0x5,%rbx
   19bca:	4d 8d 3c 1c          	lea    (%r12,%rbx,1),%r15
   19bce:	f2 41 0f 10 4f 30    	movsd  0x30(%r15),%xmm1
   19bd4:	f2 41 0f 10 47 28    	movsd  0x28(%r15),%xmm0
   19bda:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
   19be0:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
   19be6:	e8 c5 5f ff ff       	call   fbb0 <hypot@plt>
   19beb:	66 0f 2f 85 98 01 00 	comisd 0x198(%rbp),%xmm0
   19bf2:	00 
   19bf3:	72 bb                	jb     19bb0 <nav2_rotation_shim_controller::RotationShimController::getSampledPathPt()@@Base+0x90>
   19bf5:	48 8d b5 60 01 00 00 	lea    0x160(%rbp),%rsi
   19bfc:	49 8d 7f 08          	lea    0x8(%r15),%rdi
   19c00:	e8 5b 61 ff ff       	call   fd60 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_assign(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&)@plt>
   19c05:	4c 8d 64 24 20       	lea    0x20(%rsp),%r12
   19c0a:	48 8b 75 58          	mov    0x58(%rbp),%rsi
   19c0e:	4c 89 e7             	mov    %r12,%rdi
   19c11:	e8 ca 62 ff ff       	call   fee0 <rclcpp::Clock::now()@plt>
   19c16:	4c 89 e7             	mov    %r12,%rdi
   19c19:	e8 82 61 ff ff       	call   fda0 <rclcpp::Time::operator builtin_interfaces::msg::Time_<std::allocator<void> >() const@plt>
   19c1e:	48 8b 95 80 01 00 00 	mov    0x180(%rbp),%rdx
   19c25:	4c 89 e7             	mov    %r12,%rdi
   19c28:	48 89 04 1a          	mov    %rax,(%rdx,%rbx,1)
   19c2c:	e8 df 63 ff ff       	call   10010 <rclcpp::Time::~Time()@plt>
   19c31:	48 03 9d 80 01 00 00 	add    0x180(%rbp),%rbx
   19c38:	49 8d 7e 08          	lea    0x8(%r14),%rdi
   19c3c:	48 8b 03             	mov    (%rbx),%rax
   19c3f:	48 8b 53 10          	mov    0x10(%rbx),%rdx
   19c43:	49 89 06             	mov    %rax,(%r14)
   19c46:	49 8d 46 18          	lea    0x18(%r14),%rax
   19c4a:	49 89 46 08          	mov    %rax,0x8(%r14)
   19c4e:	48 8b 73 08          	mov    0x8(%rbx),%rsi
   19c52:	48 01 f2             	add    %rsi,%rdx
   19c55:	e8 a6 cf 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   19c5a:	48 8b 43 58          	mov    0x58(%rbx),%rax
   19c5e:	f3 0f 6f 73 28       	movdqu 0x28(%rbx),%xmm6
   19c63:	f3 0f 6f 7b 38       	movdqu 0x38(%rbx),%xmm7
   19c68:	f3 0f 6f 63 48       	movdqu 0x48(%rbx),%xmm4
   19c6d:	49 89 46 58          	mov    %rax,0x58(%r14)
   19c71:	41 0f 11 76 28       	movups %xmm6,0x28(%r14)
   19c76:	41 0f 11 7e 38       	movups %xmm7,0x38(%r14)
   19c7b:	41 0f 11 66 48       	movups %xmm4,0x48(%r14)
   19c80:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   19c85:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
   19c8c:	00 00 
   19c8e:	75 12                	jne    19ca2 <nav2_rotation_shim_controller::RotationShimController::getSampledPathPt()@@Base+0x182>
   19c90:	48 83 c4 78          	add    $0x78,%rsp
   19c94:	4c 89 f0             	mov    %r14,%rax
   19c97:	5b                   	pop    %rbx
   19c98:	5d                   	pop    %rbp
   19c99:	41 5c                	pop    %r12
   19c9b:	41 5d                	pop    %r13
   19c9d:	41 5e                	pop    %r14
   19c9f:	41 5f                	pop    %r15
   19ca1:	c3                   	ret    
   19ca2:	e8 b9 63 ff ff       	call   10060 <__stack_chk_fail@plt>
   19ca7:	f3 0f 1e fa          	endbr64 
   19cab:	48 89 c5             	mov    %rax,%rbp
   19cae:	e9 e3 77 ff ff       	jmp    11496 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0xfc6>
   19cb3:	90                   	nop
   19cb4:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   19cbb:	00 00 00 00 
   19cbf:	90                   	nop
