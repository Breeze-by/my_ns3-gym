"""One finite synthetic-only CPU run; never invokes extraction main or V60 raw."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A = Path(__file__).resolve().parent
P = W / 'mr3_learning'


def main():
    spec_path = A / 'artificial_cpu_spec_v1.json'
    spec = json.loads(spec_path.read_text())
    sources = sorted([*P.glob('*.py'), Path(__file__), A / 'cancel_window_extract_draft_v2.py',
                      A / 'test_cancel_window_extract_draft_v1.py',
                      A / 'pending_extraction_spec_v4.json', spec_path])
    freeze = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    if freeze != spec['repository_source_freeze']:
        raise ValueError('artificial CPU source freeze differs')
    snapshots = A / 'artificial_cpu_source_snapshots_v1'
    snapshots.mkdir(exist_ok=False)
    rows = []
    for source in sources:
        raw = source.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        row = dict(path=str(source), sha256=digest, bytes=len(raw))
        if source.is_relative_to(ROOT):
            relative = str(source.relative_to(ROOT))
            old = subprocess.check_output(['git', 'show', freeze + ':' + relative], cwd=ROOT)
            if old != raw:
                raise ValueError('repository CPU source differs from fixed E')
            row.update(kind='git_blob', freeze=freeze, relative_path=relative)
        else:
            snapshot = snapshots / (digest + '_' + source.name)
            snapshot.open('xb').write(raw)
            row.update(kind='snapshot', snapshot=str(snapshot))
        rows.append(row)
    recovery = A / 'artificial_cpu_source_recovery_v1.json'
    recovery.open('x').write(json.dumps(dict(source_freeze=freeze, sources=rows), indent=2) + '\n')
    argv = [sys.executable, '-B', '-m', 'mr3_learning.reach_execution', '--scope', 'cpu',
            '--output', str(A / 'artificial_cpu_v1')]
    for source in sources:
        argv.extend(['--source', str(source)])
    argv.extend(['--', *spec['actual_argv']])
    env = dict(os.environ, PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1')
    env.pop('PYTHONPATH', None)
    env.pop('PYTHONHOME', None)
    return subprocess.call(argv, cwd=W, env=env)


if __name__ == '__main__':
    raise SystemExit(main())
