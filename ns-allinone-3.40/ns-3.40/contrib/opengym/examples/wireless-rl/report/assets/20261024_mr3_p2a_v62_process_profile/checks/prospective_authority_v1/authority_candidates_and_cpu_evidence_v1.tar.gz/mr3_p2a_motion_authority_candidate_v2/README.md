# 最小 typed receiving authority：独立未接线核心候选

该目录只在/tmp写入。派生说明已单独封停在`/tmp/mr3_p2a_v61_adapter_cancel_findings_v1`，不再改动，不阻塞V61 archive。此处未改Root、未跑main/native/raw，已完成v2人工CPU但不提供新原生/容量资格。A62仍独立测原production。

判断：当前MR3契约没有逐Twist归goal的既有证明门。最小正确版本可以只授予“当前谁可接收该独占Nav2流”的权限；raw_goal_generation始终null/UNKNOWN_UNSTAMPED_TWIST。GRANT之后迟到的旧生成Twist也仍UNKNOWN，可能经原Reach获准；不声称严格freshgoal、不为这一更强问题扩全Nav2 producer generation。功能和物理正确性必须经新资格验证。

核心文件与patch：

- files/mr3_motion_authority.py：实际owner/UUID构造、grant/renew/revoke、有序/幂等/退休owner、默认/异常/过期zero-only、接收floor、真实Reach storage/APPLIED/rest witness。
- files/test_mr3_motion_authority.py：8组具体人工CPU草稿，使用真实GoalDispatcher和原ReachTracker的合成Feed；无手设active/ready bool。包括59个fresh正请求仍压零、原5秒承诺、取消publish失败仍尝试native、缺storage/APPLIED/rest、旧grant/旧cancel/重号/overlap、无owner、错误epoch/publisher、lease过期、恢复后UNKNOWN反例。
- core_candidate.patch：仅增加上述helper和tests，AST与git apply --check通过；尚未ROS接线。
- protocol_and_wiring_contract_v1.json：具体接线点和CPU/独立reader/metadata准入清单，不能把core patch独自应用后称完整功能。

取消原时序不变：合法owned cancel事件立即发布revoke并调用真实cancel_goal_async，同一个原simclock；不等storage/APPLIED/rest再call，也不把B起点挪到ACK。publish不是delivery；分别记录actual callback、zero target存储、actual APPLIED、body rest。RPC拒绝/异常不恢复权限、不隐藏retry。普通cancel只把effective请求送原tracker.decide([0,0])，不触发tracker.stop永久锁，不瞬切motor，不改anchor/encoder capture/disarm。

恢复须同时有真实terminal及匹配的原正常停止义务，下一真实owner accept后才grant。source grant引用原实际接受回执时间，原始raw记录不变。接收floor只拒已收到旧缓存；GRANT后才回调的旧生成Twist无从区分，测试明确保留UNKNOWN。旧owner迟到消息不得撤销新owner；认可的重放/重复不刷新停止债时钟。

初始zero encoder-hold实际rim纠偏可能非零，所以初始witness记录真实APPLIED并走原合格rest，绝不声称“target0=actualrim0”。有真实非零target application后，cancel handoff额外等真实actual rim零和原rest；目标/源码/回执仍独立核对。witness只读，未刷新任何anchor，不作连续物理证明。

A62 baseline实际结束后，v2人工核心CPU已真实tool21698 reap0/7.53050843秒，8PASS/0错误失败跳过；49源before/after/current相同、恢复快照核实、coordinator+child两保存身份freshgone，scope CPU/工程0。v1首轮2PASS/6ERROR原件保留：人工fixture误构造单台GoalDispatcher；v2仅改为其真实强制三机默认，核心字节未变。此PASS不包含ROS接线或原生/容量资格。具体ROS接线必须与新profile的producer、reader、plan/qual/PPO metadata一并整合，完整科学门及capacityFalse保持。

修订v2：仅两处人工fixture由单机构造改真实三机默认；core同v1原字节。实际CPU证据：/tmp/mr3_p2a_motion_authority_core_cpu_v2。v1候选与v1失败回执/49源快照均完整保留。
