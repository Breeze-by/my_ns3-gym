"""Run the full existing conda CPU scope plus the new portable v6 module."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
REFERENCE = Path('/tmp/mr3_p2a0_v16_conda_cpu_full_v1/checks_v1.json')
OUT = Path('/tmp/mr3_p2a0_v17_conda_cpu_full_v1')
reference = json.loads(REFERENCE.read_text())
paths = sorted(set(reference['source_before']) | {
    'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
    'mr3_learning/tests/test_benchmark_stimulus_v5.py',
    'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
    'mr3_learning/tests/test_benchmark_stimulus_v6.py'})
sha = lambda raw: hashlib.sha256(raw).hexdigest()
before = {path: sha((ROOT / path).read_bytes()) for path in paths}
environment = dict(os.environ, PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1',
                   CUDA_VISIBLE_DEVICES='')
environment.pop('PYTHONPATH', None)
OUT.mkdir()
log = OUT / 'unittest.log'
start_utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
start = time.monotonic()
with log.open('x') as output:
    process = subprocess.run(reference['argv'], cwd=reference['cwd'], env=environment,
                             stdout=output, stderr=subprocess.STDOUT)
duration = time.monotonic() - start
after = {path: sha((ROOT / path).read_bytes()) for path in paths}
raw = log.read_bytes()
match = re.search(r'Ran (\d+) tests in ([0-9.]+)s', raw.decode())
result = dict(passed=process.returncode == 0 and before == after,
              argv=reference['argv'], cwd=reference['cwd'], env=reference['env'],
              returncode=process.returncode, wall_seconds=duration,
              start_utc=start_utc,
              end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              source_path_scope='Same46 runner-bound V16 paths plus V5 and new V6 portable test modules (48 total).',
              source_before=before, source_after=after, sources_stable=before == after,
              stdout_path=str(log), stdout_sha256=sha(raw),
              unittest_count=None if match is None else int(match.group(1)),
              unittest_seconds=None if match is None else float(match.group(2)),
              script_sha256=sha(Path(__file__).read_bytes()),
              scope='Offline conda CPU suite, including synthetic SB3 optimizer tests; '
                    'no native/GPU/PPO/pilot execution.')
(OUT / 'checks_v1.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ('passed', 'returncode', 'wall_seconds',
                  'unittest_count', 'unittest_seconds', 'sources_stable')}))
print(raw.decode()[-1200:])
raise SystemExit(0 if result['passed'] else 1)
