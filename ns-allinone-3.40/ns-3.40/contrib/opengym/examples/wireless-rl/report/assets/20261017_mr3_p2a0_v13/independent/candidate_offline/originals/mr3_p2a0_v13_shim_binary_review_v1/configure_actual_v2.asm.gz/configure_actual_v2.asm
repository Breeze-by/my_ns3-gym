000000000001b1d0 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base>:
   1b1d0:	f3 0f 1e fa          	endbr64 
   1b1d4:	41 57                	push   %r15
   1b1d6:	41 56                	push   %r14
   1b1d8:	41 55                	push   %r13
   1b1da:	41 54                	push   %r12
   1b1dc:	55                   	push   %rbp
   1b1dd:	53                   	push   %rbx
   1b1de:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
   1b1e5:	48 83 0c 24 00       	orq    $0x0,(%rsp)
   1b1ea:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
   1b1f1:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
   1b1f6:	48 89 fb             	mov    %rdi,%rbx
   1b1f9:	bf 50 00 00 00       	mov    $0x50,%edi
   1b1fe:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
   1b203:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
   1b208:	4c 89 44 24 40       	mov    %r8,0x40(%rsp)
   1b20d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
   1b214:	00 00 
   1b216:	48 89 84 24 18 11 00 	mov    %rax,0x1118(%rsp)
   1b21d:	00 
   1b21e:	31 c0                	xor    %eax,%eax
   1b220:	e8 6b 4d ff ff       	call   ff90 <operator new(unsigned long)@plt>
   1b225:	48 89 c7             	mov    %rax,%rdi
   1b228:	49 89 c4             	mov    %rax,%r12
   1b22b:	e8 50 4b ff ff       	call   fd80 <nav2_controller::PositionGoalChecker::PositionGoalChecker()@plt>
   1b230:	48 8b bb 18 02 00 00 	mov    0x218(%rbx),%rdi
   1b237:	4c 89 a3 18 02 00 00 	mov    %r12,0x218(%rbx)
   1b23e:	48 85 ff             	test   %rdi,%rdi
   1b241:	74 0d                	je     1b250 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x80>
   1b243:	48 8b 07             	mov    (%rdi),%rax
   1b246:	ff 50 08             	call   *0x8(%rax)
   1b249:	4c 8b a3 18 02 00 00 	mov    0x218(%rbx),%r12
   1b250:	49 8b 04 24          	mov    (%r12),%rax
   1b254:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   1b259:	4c 8b 70 10          	mov    0x10(%rax),%r14
   1b25d:	48 8b 01             	mov    (%rcx),%rax
   1b260:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
   1b267:	00 
   1b268:	48 8b 41 08          	mov    0x8(%rcx),%rax
   1b26c:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
   1b273:	00 
   1b274:	48 85 c0             	test   %rax,%rax
   1b277:	74 14                	je     1b28d <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xbd>
   1b279:	48 8b 15 f8 bb 02 00 	mov    0x2bbf8(%rip),%rdx        # 46e78 <__libc_single_threaded@GLIBC_2.32>
   1b280:	80 3a 00             	cmpb   $0x0,(%rdx)
   1b283:	0f 84 c9 1e 00 00    	je     1d152 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1f82>
   1b289:	83 40 08 01          	addl   $0x1,0x8(%rax)
   1b28d:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   1b291:	48 8b 53 30          	mov    0x30(%rbx),%rdx
   1b295:	4c 8d 6b 28          	lea    0x28(%rbx),%r13
   1b299:	48 8d ac 24 10 0d 00 	lea    0xd10(%rsp),%rbp
   1b2a0:	00 
   1b2a1:	48 8d 84 24 20 0d 00 	lea    0xd20(%rsp),%rax
   1b2a8:	00 
   1b2a9:	48 89 ef             	mov    %rbp,%rdi
   1b2ac:	48 01 f2             	add    %rsi,%rdx
   1b2af:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   1b2b4:	48 89 84 24 10 0d 00 	mov    %rax,0xd10(%rsp)
   1b2bb:	00 
   1b2bc:	e8 3f b9 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1b2c1:	48 b8 ff ff ff ff ff 	movabs $0x3fffffffffffffff,%rax
   1b2c8:	ff ff 3f 
   1b2cb:	48 2b 84 24 18 0d 00 	sub    0xd18(%rsp),%rax
   1b2d2:	00 
   1b2d3:	48 83 f8 10          	cmp    $0x10,%rax
   1b2d7:	0f 86 f0 21 00 00    	jbe    1d4cd <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x22fd>
   1b2dd:	ba 11 00 00 00       	mov    $0x11,%edx
   1b2e2:	48 8d 35 6f de 01 00 	lea    0x1de6f(%rip),%rsi        # 39158 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2fb8>
   1b2e9:	48 89 ef             	mov    %rbp,%rdi
   1b2ec:	e8 ef 48 ff ff       	call   fbe0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_append(char const*, unsigned long)@plt>
   1b2f1:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
   1b2f8:	00 
   1b2f9:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
   1b2fe:	48 89 ea             	mov    %rbp,%rdx
   1b301:	4c 89 e7             	mov    %r12,%rdi
   1b304:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   1b309:	48 89 c1             	mov    %rax,%rcx
   1b30c:	41 ff d6             	call   *%r14
   1b30f:	48 8b bc 24 10 0d 00 	mov    0xd10(%rsp),%rdi
   1b316:	00 
   1b317:	48 3b 7c 24 18       	cmp    0x18(%rsp),%rdi
   1b31c:	74 11                	je     1b32f <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x15f>
   1b31e:	48 8b 84 24 20 0d 00 	mov    0xd20(%rsp),%rax
   1b325:	00 
   1b326:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1b32a:	e8 91 4c ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1b32f:	48 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%rdi
   1b336:	00 
   1b337:	48 85 ff             	test   %rdi,%rdi
   1b33a:	74 05                	je     1b341 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x171>
   1b33c:	e8 9f b1 ff ff       	call   164e0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x770>
   1b341:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
   1b346:	4c 89 ef             	mov    %r13,%rdi
   1b349:	e8 12 4a ff ff       	call   fd60 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_assign(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&)@plt>
   1b34e:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
   1b353:	48 8b 01             	mov    (%rcx),%rax
   1b356:	4c 8b 61 08          	mov    0x8(%rcx),%r12
   1b35a:	48 89 43 08          	mov    %rax,0x8(%rbx)
   1b35e:	4d 85 e4             	test   %r12,%r12
   1b361:	74 6a                	je     1b3cd <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1fd>
   1b363:	48 8b 05 0e bb 02 00 	mov    0x2bb0e(%rip),%rax        # 46e78 <__libc_single_threaded@GLIBC_2.32>
   1b36a:	80 38 00             	cmpb   $0x0,(%rax)
   1b36d:	74 57                	je     1b3c6 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1f6>
   1b36f:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
   1b373:	41 83 44 24 0c 01    	addl   $0x1,0xc(%r12)
   1b379:	48 85 ff             	test   %rdi,%rdi
   1b37c:	74 0e                	je     1b38c <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1bc>
   1b37e:	8b 47 0c             	mov    0xc(%rdi),%eax
   1b381:	8d 50 ff             	lea    -0x1(%rax),%edx
   1b384:	89 57 0c             	mov    %edx,0xc(%rdi)
   1b387:	83 f8 01             	cmp    $0x1,%eax
   1b38a:	74 65                	je     1b3f1 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x221>
   1b38c:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   1b391:	4c 89 63 10          	mov    %r12,0x10(%rbx)
   1b395:	48 8b 40 08          	mov    0x8(%rax),%rax
   1b399:	48 89 04 24          	mov    %rax,(%rsp)
   1b39d:	48 85 c0             	test   %rax,%rax
   1b3a0:	74 57                	je     1b3f9 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x229>
   1b3a2:	48 8d 50 08          	lea    0x8(%rax),%rdx
   1b3a6:	8b 40 08             	mov    0x8(%rax),%eax
   1b3a9:	85 c0                	test   %eax,%eax
   1b3ab:	74 4c                	je     1b3f9 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x229>
   1b3ad:	8d 48 01             	lea    0x1(%rax),%ecx
   1b3b0:	f0 0f b1 0a          	lock cmpxchg %ecx,(%rdx)
   1b3b4:	75 f3                	jne    1b3a9 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1d9>
   1b3b6:	8b 02                	mov    (%rdx),%eax
   1b3b8:	85 c0                	test   %eax,%eax
   1b3ba:	74 45                	je     1b401 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x231>
   1b3bc:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   1b3c1:	4c 8b 20             	mov    (%rax),%r12
   1b3c4:	eb 3e                	jmp    1b404 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x234>
   1b3c6:	f0 41 83 44 24 0c 01 	lock addl $0x1,0xc(%r12)
   1b3cd:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
   1b3d1:	48 85 ff             	test   %rdi,%rdi
   1b3d4:	74 b6                	je     1b38c <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1bc>
   1b3d6:	48 8b 05 9b ba 02 00 	mov    0x2ba9b(%rip),%rax        # 46e78 <__libc_single_threaded@GLIBC_2.32>
   1b3dd:	80 38 00             	cmpb   $0x0,(%rax)
   1b3e0:	75 9c                	jne    1b37e <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1ae>
   1b3e2:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   1b3e7:	f0 0f c1 47 0c       	lock xadd %eax,0xc(%rdi)
   1b3ec:	83 f8 01             	cmp    $0x1,%eax
   1b3ef:	75 9b                	jne    1b38c <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1bc>
   1b3f1:	48 8b 07             	mov    (%rdi),%rax
   1b3f4:	ff 50 18             	call   *0x18(%rax)
   1b3f7:	eb 93                	jmp    1b38c <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1bc>
   1b3f9:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   1b400:	00 
   1b401:	45 31 e4             	xor    %r12d,%r12d
   1b404:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   1b409:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
   1b40d:	48 8b 01             	mov    (%rcx),%rax
   1b410:	4c 8b 69 08          	mov    0x8(%rcx),%r13
   1b414:	48 89 43 18          	mov    %rax,0x18(%rbx)
   1b418:	49 39 fd             	cmp    %rdi,%r13
   1b41b:	74 28                	je     1b445 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x275>
   1b41d:	4d 85 ed             	test   %r13,%r13
   1b420:	74 15                	je     1b437 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x267>
   1b422:	48 8b 05 4f ba 02 00 	mov    0x2ba4f(%rip),%rax        # 46e78 <__libc_single_threaded@GLIBC_2.32>
   1b429:	80 38 00             	cmpb   $0x0,(%rax)
   1b42c:	0f 84 bc 1d 00 00    	je     1d1ee <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x201e>
   1b432:	41 83 45 08 01       	addl   $0x1,0x8(%r13)
   1b437:	48 85 ff             	test   %rdi,%rdi
   1b43a:	74 05                	je     1b441 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x271>
   1b43c:	e8 9f b0 ff ff       	call   164e0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x770>
   1b441:	4c 89 6b 20          	mov    %r13,0x20(%rbx)
   1b445:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   1b44a:	48 8b 7b 70          	mov    0x70(%rbx),%rdi
   1b44e:	48 8b 01             	mov    (%rcx),%rax
   1b451:	4c 8b 69 08          	mov    0x8(%rcx),%r13
   1b455:	48 89 43 68          	mov    %rax,0x68(%rbx)
   1b459:	49 39 fd             	cmp    %rdi,%r13
   1b45c:	74 28                	je     1b486 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2b6>
   1b45e:	4d 85 ed             	test   %r13,%r13
   1b461:	74 15                	je     1b478 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2a8>
   1b463:	48 8b 05 0e ba 02 00 	mov    0x2ba0e(%rip),%rax        # 46e78 <__libc_single_threaded@GLIBC_2.32>
   1b46a:	80 38 00             	cmpb   $0x0,(%rax)
   1b46d:	0f 84 93 1d 00 00    	je     1d206 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2036>
   1b473:	41 83 45 08 01       	addl   $0x1,0x8(%r13)
   1b478:	48 85 ff             	test   %rdi,%rdi
   1b47b:	74 05                	je     1b482 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2b2>
   1b47d:	e8 5e b0 ff ff       	call   164e0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x770>
   1b482:	4c 89 6b 70          	mov    %r13,0x70(%rbx)
   1b486:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   1b48d:	00 
   1b48e:	4c 89 e6             	mov    %r12,%rsi
   1b491:	e8 7a 4d ff ff       	call   10210 <rclcpp_lifecycle::LifecycleNode::get_logger() const@plt>
   1b496:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
   1b49d:	00 
   1b49e:	4c 8b ac 24 a8 00 00 	mov    0xa8(%rsp),%r13
   1b4a5:	00 
   1b4a6:	48 8b 7b 50          	mov    0x50(%rbx),%rdi
   1b4aa:	48 89 43 48          	mov    %rax,0x48(%rbx)
   1b4ae:	49 39 fd             	cmp    %rdi,%r13
   1b4b1:	74 30                	je     1b4e3 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x313>
   1b4b3:	4d 85 ed             	test   %r13,%r13
   1b4b6:	74 15                	je     1b4cd <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2fd>
   1b4b8:	48 8b 05 b9 b9 02 00 	mov    0x2b9b9(%rip),%rax        # 46e78 <__libc_single_threaded@GLIBC_2.32>
   1b4bf:	80 38 00             	cmpb   $0x0,(%rax)
   1b4c2:	0f 84 0e 1d 00 00    	je     1d1d6 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2006>
   1b4c8:	41 83 45 08 01       	addl   $0x1,0x8(%r13)
   1b4cd:	48 85 ff             	test   %rdi,%rdi
   1b4d0:	74 05                	je     1b4d7 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x307>
   1b4d2:	e8 09 b0 ff ff       	call   164e0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x770>
   1b4d7:	4c 89 6b 50          	mov    %r13,0x50(%rbx)
   1b4db:	48 8b bc 24 a8 00 00 	mov    0xa8(%rsp),%rdi
   1b4e2:	00 
   1b4e3:	48 85 ff             	test   %rdi,%rdi
   1b4e6:	74 05                	je     1b4ed <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x31d>
   1b4e8:	e8 f3 af ff ff       	call   164e0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x770>
   1b4ed:	48 8d 84 24 b0 00 00 	lea    0xb0(%rsp),%rax
   1b4f4:	00 
   1b4f5:	4c 89 e6             	mov    %r12,%rsi
   1b4f8:	48 89 c7             	mov    %rax,%rdi
   1b4fb:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   1b500:	e8 7b 4e ff ff       	call   10380 <rclcpp_lifecycle::LifecycleNode::get_clock()@plt>
   1b505:	48 8b 94 24 b0 00 00 	mov    0xb0(%rsp),%rdx
   1b50c:	00 
   1b50d:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
   1b514:	00 
   1b515:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
   1b51c:	00 00 00 00 00 
   1b521:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
   1b528:	00 00 00 00 00 
   1b52d:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
   1b531:	48 89 53 58          	mov    %rdx,0x58(%rbx)
   1b535:	48 89 43 60          	mov    %rax,0x60(%rbx)
   1b539:	48 85 ff             	test   %rdi,%rdi
   1b53c:	74 17                	je     1b555 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x385>
   1b53e:	e8 9d af ff ff       	call   164e0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x770>
   1b543:	48 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%rdi
   1b54a:	00 
   1b54b:	48 85 ff             	test   %rdi,%rdi
   1b54e:	74 05                	je     1b555 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x385>
   1b550:	e8 8b af ff ff       	call   164e0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x770>
   1b555:	48 8d 84 24 00 01 00 	lea    0x100(%rsp),%rax
   1b55c:	00 
   1b55d:	48 8d bc 24 10 09 00 	lea    0x910(%rsp),%rdi
   1b564:	00 
   1b565:	48 c7 84 24 f8 00 00 	movq   $0x0,0xf8(%rsp)
   1b56c:	00 00 00 00 00 
   1b571:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   1b576:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
   1b57d:	00 
   1b57e:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
   1b585:	00 
   1b586:	c6 84 24 00 01 00 00 	movb   $0x0,0x100(%rsp)
   1b58d:	00 
   1b58e:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
   1b593:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   1b598:	e8 83 b4 01 00       	call   36a20 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x880>
   1b59d:	48 8b 05 3c f6 01 00 	mov    0x1f63c(%rip),%rax        # 3abe0 <typeinfo name for nav2_core::Controller*@@Base+0x80>
   1b5a4:	48 89 ef             	mov    %rbp,%rdi
   1b5a7:	66 48 0f 6e c0       	movq   %rax,%xmm0
   1b5ac:	e8 3f 47 ff ff       	call   fcf0 <rclcpp::ParameterValue::ParameterValue(double)@plt>
   1b5b1:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   1b5b5:	48 8b 53 30          	mov    0x30(%rbx),%rdx
   1b5b9:	4c 8d b4 24 10 05 00 	lea    0x510(%rsp),%r14
   1b5c0:	00 
   1b5c1:	4c 8d ac 24 20 05 00 	lea    0x520(%rsp),%r13
   1b5c8:	00 
   1b5c9:	4c 89 f7             	mov    %r14,%rdi
   1b5cc:	4c 89 ac 24 10 05 00 	mov    %r13,0x510(%rsp)
   1b5d3:	00 
   1b5d4:	48 01 f2             	add    %rsi,%rdx
   1b5d7:	e8 24 b6 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1b5dc:	48 b8 ff ff ff ff ff 	movabs $0x3fffffffffffffff,%rax
   1b5e3:	ff ff 3f 
   1b5e6:	48 2b 84 24 18 05 00 	sub    0x518(%rsp),%rax
   1b5ed:	00 
   1b5ee:	48 83 f8 16          	cmp    $0x16,%rax
   1b5f2:	0f 86 c9 1e 00 00    	jbe    1d4c1 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x22f1>
   1b5f8:	ba 17 00 00 00       	mov    $0x17,%edx
   1b5fd:	48 8d 35 5f da 01 00 	lea    0x1da5f(%rip),%rsi        # 39063 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2ec3>
   1b604:	4c 89 f7             	mov    %r14,%rdi
   1b607:	e8 d4 45 ff ff       	call   fbe0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_append(char const*, unsigned long)@plt>
   1b60c:	48 8b 0c 24          	mov    (%rsp),%rcx
   1b610:	48 85 c9             	test   %rcx,%rcx
   1b613:	74 14                	je     1b629 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x459>
   1b615:	48 8b 05 5c b8 02 00 	mov    0x2b85c(%rip),%rax        # 46e78 <__libc_single_threaded@GLIBC_2.32>
   1b61c:	80 38 00             	cmpb   $0x0,(%rax)
   1b61f:	0f 84 37 1b 00 00    	je     1d15c <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1f8c>
   1b625:	83 41 08 01          	addl   $0x1,0x8(%rcx)
   1b629:	4c 89 f6             	mov    %r14,%rsi
   1b62c:	4c 89 e7             	mov    %r12,%rdi
   1b62f:	e8 fc 46 ff ff       	call   fd30 <rclcpp_lifecycle::LifecycleNode::has_parameter(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&) const@plt>
   1b634:	84 c0                	test   %al,%al
   1b636:	0f 84 45 19 00 00    	je     1cf81 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1db1>
   1b63c:	48 8b 04 24          	mov    (%rsp),%rax
   1b640:	48 85 c0             	test   %rax,%rax
   1b643:	74 08                	je     1b64d <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x47d>
   1b645:	48 89 c7             	mov    %rax,%rdi
   1b648:	e8 93 ae ff ff       	call   164e0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x770>
   1b64d:	48 8b bc 24 10 05 00 	mov    0x510(%rsp),%rdi
   1b654:	00 
   1b655:	4c 39 ef             	cmp    %r13,%rdi
   1b658:	74 11                	je     1b66b <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x49b>
   1b65a:	48 8b 84 24 20 05 00 	mov    0x520(%rsp),%rax
   1b661:	00 
   1b662:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1b666:	e8 55 49 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1b66b:	48 89 ef             	mov    %rbp,%rdi
   1b66e:	e8 5d aa ff ff       	call   160d0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x360>
   1b673:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
   1b678:	4c 89 ff             	mov    %r15,%rdi
   1b67b:	e8 00 9f ff ff       	call   15580 <nav2_rotation_shim_controller::RotationShimController::setSpeedLimit(double const&, bool const&)@@Base+0xe0>
   1b680:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
   1b687:	00 
   1b688:	4c 89 ff             	mov    %r15,%rdi
   1b68b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   1b690:	e8 8b b3 01 00       	call   36a20 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x880>
   1b695:	48 8b 05 44 f5 01 00 	mov    0x1f544(%rip),%rax        # 3abe0 <typeinfo name for nav2_core::Controller*@@Base+0x80>
   1b69c:	48 89 ef             	mov    %rbp,%rdi
   1b69f:	66 48 0f 6e c0       	movq   %rax,%xmm0
   1b6a4:	e8 47 46 ff ff       	call   fcf0 <rclcpp::ParameterValue::ParameterValue(double)@plt>
   1b6a9:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   1b6ad:	48 8b 53 30          	mov    0x30(%rbx),%rdx
   1b6b1:	4c 89 f7             	mov    %r14,%rdi
   1b6b4:	4c 89 ac 24 10 05 00 	mov    %r13,0x510(%rsp)
   1b6bb:	00 
   1b6bc:	48 01 f2             	add    %rsi,%rdx
   1b6bf:	e8 3c b5 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1b6c4:	48 b8 ff ff ff ff ff 	movabs $0x3fffffffffffffff,%rax
   1b6cb:	ff ff 3f 
   1b6ce:	48 2b 84 24 18 05 00 	sub    0x518(%rsp),%rax
   1b6d5:	00 
   1b6d6:	48 83 f8 1b          	cmp    $0x1b,%rax
   1b6da:	0f 86 59 1e 00 00    	jbe    1d539 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2369>
   1b6e0:	ba 1c 00 00 00       	mov    $0x1c,%edx
   1b6e5:	48 8d 35 7e da 01 00 	lea    0x1da7e(%rip),%rsi        # 3916a <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2fca>
   1b6ec:	4c 89 f7             	mov    %r14,%rdi
   1b6ef:	e8 ec 44 ff ff       	call   fbe0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_append(char const*, unsigned long)@plt>
   1b6f4:	48 8b 0c 24          	mov    (%rsp),%rcx
   1b6f8:	48 85 c9             	test   %rcx,%rcx
   1b6fb:	74 14                	je     1b711 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x541>
   1b6fd:	48 8b 05 74 b7 02 00 	mov    0x2b774(%rip),%rax        # 46e78 <__libc_single_threaded@GLIBC_2.32>
   1b704:	80 38 00             	cmpb   $0x0,(%rax)
   1b707:	0f 84 29 1a 00 00    	je     1d136 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1f66>
   1b70d:	83 41 08 01          	addl   $0x1,0x8(%rcx)
   1b711:	4c 89 f6             	mov    %r14,%rsi
   1b714:	4c 89 e7             	mov    %r12,%rdi
   1b717:	e8 14 46 ff ff       	call   fd30 <rclcpp_lifecycle::LifecycleNode::has_parameter(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&) const@plt>
   1b71c:	84 c0                	test   %al,%al
   1b71e:	0f 84 78 18 00 00    	je     1cf9c <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1dcc>
   1b724:	48 8b 04 24          	mov    (%rsp),%rax
   1b728:	48 85 c0             	test   %rax,%rax
   1b72b:	74 08                	je     1b735 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x565>
   1b72d:	48 89 c7             	mov    %rax,%rdi
   1b730:	e8 ab ad ff ff       	call   164e0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x770>
   1b735:	48 8b bc 24 10 05 00 	mov    0x510(%rsp),%rdi
   1b73c:	00 
   1b73d:	4c 39 ef             	cmp    %r13,%rdi
   1b740:	74 11                	je     1b753 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x583>
   1b742:	48 8b 84 24 20 05 00 	mov    0x520(%rsp),%rax
   1b749:	00 
   1b74a:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1b74e:	e8 6d 48 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1b753:	48 89 ef             	mov    %rbp,%rdi
   1b756:	e8 75 a9 ff ff       	call   160d0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x360>
   1b75b:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
   1b760:	4c 89 ff             	mov    %r15,%rdi
   1b763:	e8 18 9e ff ff       	call   15580 <nav2_rotation_shim_controller::RotationShimController::setSpeedLimit(double const&, bool const&)@@Base+0xe0>
   1b768:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
   1b76f:	00 
   1b770:	4c 89 ff             	mov    %r15,%rdi
   1b773:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   1b778:	e8 a3 b2 01 00       	call   36a20 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x880>
   1b77d:	f2 0f 10 05 63 f4 01 	movsd  0x1f463(%rip),%xmm0        # 3abe8 <typeinfo name for nav2_core::Controller*@@Base+0x88>
   1b784:	00 
   1b785:	48 89 ef             	mov    %rbp,%rdi
   1b788:	e8 63 45 ff ff       	call   fcf0 <rclcpp::ParameterValue::ParameterValue(double)@plt>
   1b78d:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   1b791:	48 8b 53 30          	mov    0x30(%rbx),%rdx
   1b795:	4c 89 f7             	mov    %r14,%rdi
   1b798:	4c 89 ac 24 10 05 00 	mov    %r13,0x510(%rsp)
   1b79f:	00 
   1b7a0:	48 01 f2             	add    %rsi,%rdx
   1b7a3:	e8 58 b4 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1b7a8:	48 b8 ff ff ff ff ff 	movabs $0x3fffffffffffffff,%rax
   1b7af:	ff ff 3f 
   1b7b2:	48 2b 84 24 18 05 00 	sub    0x518(%rsp),%rax
   1b7b9:	00 
   1b7ba:	48 83 f8 19          	cmp    $0x19,%rax
   1b7be:	0f 86 81 1d 00 00    	jbe    1d545 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2375>
   1b7c4:	ba 1a 00 00 00       	mov    $0x1a,%edx
   1b7c9:	48 8d 35 ab d8 01 00 	lea    0x1d8ab(%rip),%rsi        # 3907b <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2edb>
   1b7d0:	4c 89 f7             	mov    %r14,%rdi
   1b7d3:	e8 08 44 ff ff       	call   fbe0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_append(char const*, unsigned long)@plt>
   1b7d8:	48 8b 0c 24          	mov    (%rsp),%rcx
   1b7dc:	48 85 c9             	test   %rcx,%rcx
   1b7df:	74 14                	je     1b7f5 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x625>
   1b7e1:	48 8b 05 90 b6 02 00 	mov    0x2b690(%rip),%rax        # 46e78 <__libc_single_threaded@GLIBC_2.32>
   1b7e8:	80 38 00             	cmpb   $0x0,(%rax)
   1b7eb:	0f 84 53 19 00 00    	je     1d144 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1f74>
   1b7f1:	83 41 08 01          	addl   $0x1,0x8(%rcx)
   1b7f5:	4c 89 f6             	mov    %r14,%rsi
   1b7f8:	4c 89 e7             	mov    %r12,%rdi
   1b7fb:	e8 30 45 ff ff       	call   fd30 <rclcpp_lifecycle::LifecycleNode::has_parameter(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&) const@plt>
   1b800:	84 c0                	test   %al,%al
   1b802:	0f 84 38 18 00 00    	je     1d040 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1e70>
   1b808:	48 8b 04 24          	mov    (%rsp),%rax
   1b80c:	48 85 c0             	test   %rax,%rax
   1b80f:	74 08                	je     1b819 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x649>
   1b811:	48 89 c7             	mov    %rax,%rdi
   1b814:	e8 c7 ac ff ff       	call   164e0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x770>
   1b819:	48 8b bc 24 10 05 00 	mov    0x510(%rsp),%rdi
   1b820:	00 
   1b821:	4c 39 ef             	cmp    %r13,%rdi
   1b824:	74 11                	je     1b837 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x667>
   1b826:	48 8b 84 24 20 05 00 	mov    0x520(%rsp),%rax
   1b82d:	00 
   1b82e:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1b832:	e8 89 47 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1b837:	48 89 ef             	mov    %rbp,%rdi
   1b83a:	e8 91 a8 ff ff       	call   160d0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x360>
   1b83f:	48 8b bc 24 98 09 00 	mov    0x998(%rsp),%rdi
   1b846:	00 
   1b847:	48 85 ff             	test   %rdi,%rdi
   1b84a:	74 10                	je     1b85c <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x68c>
   1b84c:	48 8b b4 24 a8 09 00 	mov    0x9a8(%rsp),%rsi
   1b853:	00 
   1b854:	48 29 fe             	sub    %rdi,%rsi
   1b857:	e8 64 47 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1b85c:	48 8b bc 24 80 09 00 	mov    0x980(%rsp),%rdi
   1b863:	00 
   1b864:	48 85 ff             	test   %rdi,%rdi
   1b867:	74 10                	je     1b879 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x6a9>
   1b869:	48 8b b4 24 90 09 00 	mov    0x990(%rsp),%rsi
   1b870:	00 
   1b871:	48 29 fe             	sub    %rdi,%rsi
   1b874:	e8 47 47 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1b879:	48 8b bc 24 58 09 00 	mov    0x958(%rsp),%rdi
   1b880:	00 
   1b881:	48 8d 84 24 68 09 00 	lea    0x968(%rsp),%rax
   1b888:	00 
   1b889:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   1b88e:	48 39 c7             	cmp    %rax,%rdi
   1b891:	74 11                	je     1b8a4 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x6d4>
   1b893:	48 8b 84 24 68 09 00 	mov    0x968(%rsp),%rax
   1b89a:	00 
   1b89b:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1b89f:	e8 1c 47 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1b8a4:	48 8b bc 24 38 09 00 	mov    0x938(%rsp),%rdi
   1b8ab:	00 
   1b8ac:	48 8d 84 24 48 09 00 	lea    0x948(%rsp),%rax
   1b8b3:	00 
   1b8b4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   1b8b9:	48 39 c7             	cmp    %rax,%rdi
   1b8bc:	74 11                	je     1b8cf <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x6ff>
   1b8be:	48 8b 84 24 48 09 00 	mov    0x948(%rsp),%rax
   1b8c5:	00 
   1b8c6:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1b8ca:	e8 f1 46 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1b8cf:	48 8b bc 24 10 09 00 	mov    0x910(%rsp),%rdi
   1b8d6:	00 
   1b8d7:	4c 8d bc 24 20 09 00 	lea    0x920(%rsp),%r15
   1b8de:	00 
   1b8df:	4c 39 ff             	cmp    %r15,%rdi
   1b8e2:	74 11                	je     1b8f5 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x725>
   1b8e4:	48 8b 84 24 20 09 00 	mov    0x920(%rsp),%rax
   1b8eb:	00 
   1b8ec:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1b8f0:	e8 cb 46 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1b8f5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   1b8fa:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
   1b901:	00 
   1b902:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   1b907:	e8 14 b1 01 00       	call   36a20 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x880>
   1b90c:	f2 0f 10 05 dc f2 01 	movsd  0x1f2dc(%rip),%xmm0        # 3abf0 <typeinfo name for nav2_core::Controller*@@Base+0x90>
   1b913:	00 
   1b914:	48 89 ef             	mov    %rbp,%rdi
   1b917:	e8 d4 43 ff ff       	call   fcf0 <rclcpp::ParameterValue::ParameterValue(double)@plt>
   1b91c:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   1b920:	48 8b 53 30          	mov    0x30(%rbx),%rdx
   1b924:	4c 89 f7             	mov    %r14,%rdi
   1b927:	4c 89 ac 24 10 05 00 	mov    %r13,0x510(%rsp)
   1b92e:	00 
   1b92f:	48 01 f2             	add    %rsi,%rdx
   1b932:	e8 c9 b2 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1b937:	48 b8 ff ff ff ff ff 	movabs $0x3fffffffffffffff,%rax
   1b93e:	ff ff 3f 
   1b941:	48 2b 84 24 18 05 00 	sub    0x518(%rsp),%rax
   1b948:	00 
   1b949:	48 83 f8 1d          	cmp    $0x1d,%rax
   1b94d:	0f 86 2d 1b 00 00    	jbe    1d480 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x22b0>
   1b953:	ba 1e 00 00 00       	mov    $0x1e,%edx
   1b958:	48 8d 35 89 dc 01 00 	lea    0x1dc89(%rip),%rsi        # 395e8 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3448>
   1b95f:	4c 89 f7             	mov    %r14,%rdi
   1b962:	e8 79 42 ff ff       	call   fbe0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_append(char const*, unsigned long)@plt>
   1b967:	48 8b 0c 24          	mov    (%rsp),%rcx
   1b96b:	48 85 c9             	test   %rcx,%rcx
   1b96e:	74 14                	je     1b984 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x7b4>
   1b970:	48 8b 05 01 b5 02 00 	mov    0x2b501(%rip),%rax        # 46e78 <__libc_single_threaded@GLIBC_2.32>
   1b977:	80 38 00             	cmpb   $0x0,(%rax)
   1b97a:	0f 84 9a 17 00 00    	je     1d11a <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1f4a>
   1b980:	83 41 08 01          	addl   $0x1,0x8(%rcx)
   1b984:	4c 89 f6             	mov    %r14,%rsi
   1b987:	4c 89 e7             	mov    %r12,%rdi
   1b98a:	e8 a1 43 ff ff       	call   fd30 <rclcpp_lifecycle::LifecycleNode::has_parameter(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&) const@plt>
   1b98f:	84 c0                	test   %al,%al
   1b991:	0f 84 20 16 00 00    	je     1cfb7 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1de7>
   1b997:	48 8b 04 24          	mov    (%rsp),%rax
   1b99b:	48 85 c0             	test   %rax,%rax
   1b99e:	74 08                	je     1b9a8 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x7d8>
   1b9a0:	48 89 c7             	mov    %rax,%rdi
   1b9a3:	e8 38 ab ff ff       	call   164e0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x770>
   1b9a8:	48 8b bc 24 10 05 00 	mov    0x510(%rsp),%rdi
   1b9af:	00 
   1b9b0:	4c 39 ef             	cmp    %r13,%rdi
   1b9b3:	74 11                	je     1b9c6 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x7f6>
   1b9b5:	48 8b 84 24 20 05 00 	mov    0x520(%rsp),%rax
   1b9bc:	00 
   1b9bd:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1b9c1:	e8 fa 45 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1b9c6:	48 89 ef             	mov    %rbp,%rdi
   1b9c9:	e8 02 a7 ff ff       	call   160d0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x360>
   1b9ce:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   1b9d3:	e8 a8 9b ff ff       	call   15580 <nav2_rotation_shim_controller::RotationShimController::setSpeedLimit(double const&, bool const&)@@Base+0xe0>
   1b9d8:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   1b9dd:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
   1b9e4:	00 
   1b9e5:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   1b9ea:	e8 31 b0 01 00       	call   36a20 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x880>
   1b9ef:	f2 0f 10 05 01 f2 01 	movsd  0x1f201(%rip),%xmm0        # 3abf8 <typeinfo name for nav2_core::Controller*@@Base+0x98>
   1b9f6:	00 
   1b9f7:	48 89 ef             	mov    %rbp,%rdi
   1b9fa:	e8 f1 42 ff ff       	call   fcf0 <rclcpp::ParameterValue::ParameterValue(double)@plt>
   1b9ff:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   1ba03:	48 8b 53 30          	mov    0x30(%rbx),%rdx
   1ba07:	4c 89 f7             	mov    %r14,%rdi
   1ba0a:	4c 89 ac 24 10 05 00 	mov    %r13,0x510(%rsp)
   1ba11:	00 
   1ba12:	48 01 f2             	add    %rsi,%rdx
   1ba15:	e8 e6 b1 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1ba1a:	48 b8 ff ff ff ff ff 	movabs $0x3fffffffffffffff,%rax
   1ba21:	ff ff 3f 
   1ba24:	48 2b 84 24 18 05 00 	sub    0x518(%rsp),%rax
   1ba2b:	00 
   1ba2c:	48 83 f8 11          	cmp    $0x11,%rax
   1ba30:	0f 86 27 1b 00 00    	jbe    1d55d <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x238d>
   1ba36:	ba 12 00 00 00       	mov    $0x12,%edx
   1ba3b:	48 8d 35 54 d6 01 00 	lea    0x1d654(%rip),%rsi        # 39096 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2ef6>
   1ba42:	4c 89 f7             	mov    %r14,%rdi
   1ba45:	e8 96 41 ff ff       	call   fbe0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_append(char const*, unsigned long)@plt>
   1ba4a:	48 8b 0c 24          	mov    (%rsp),%rcx
   1ba4e:	48 85 c9             	test   %rcx,%rcx
   1ba51:	74 14                	je     1ba67 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x897>
   1ba53:	48 8b 05 1e b4 02 00 	mov    0x2b41e(%rip),%rax        # 46e78 <__libc_single_threaded@GLIBC_2.32>
   1ba5a:	80 38 00             	cmpb   $0x0,(%rax)
   1ba5d:	0f 84 c5 16 00 00    	je     1d128 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1f58>
   1ba63:	83 41 08 01          	addl   $0x1,0x8(%rcx)
   1ba67:	4c 89 f6             	mov    %r14,%rsi
   1ba6a:	4c 89 e7             	mov    %r12,%rdi
   1ba6d:	e8 be 42 ff ff       	call   fd30 <rclcpp_lifecycle::LifecycleNode::has_parameter(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&) const@plt>
   1ba72:	84 c0                	test   %al,%al
   1ba74:	0f 84 58 15 00 00    	je     1cfd2 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1e02>
   1ba7a:	48 8b 04 24          	mov    (%rsp),%rax
   1ba7e:	48 85 c0             	test   %rax,%rax
   1ba81:	74 08                	je     1ba8b <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x8bb>
   1ba83:	48 89 c7             	mov    %rax,%rdi
   1ba86:	e8 55 aa ff ff       	call   164e0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x770>
   1ba8b:	48 8b bc 24 10 05 00 	mov    0x510(%rsp),%rdi
   1ba92:	00 
   1ba93:	4c 39 ef             	cmp    %r13,%rdi
   1ba96:	74 11                	je     1baa9 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x8d9>
   1ba98:	48 8b 84 24 20 05 00 	mov    0x520(%rsp),%rax
   1ba9f:	00 
   1baa0:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1baa4:	e8 17 45 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1baa9:	48 89 ef             	mov    %rbp,%rdi
   1baac:	e8 1f a6 ff ff       	call   160d0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x360>
   1bab1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   1bab6:	e8 c5 9a ff ff       	call   15580 <nav2_rotation_shim_controller::RotationShimController::setSpeedLimit(double const&, bool const&)@@Base+0xe0>
   1babb:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   1bac0:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
   1bac7:	00 
   1bac8:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   1bacd:	e8 4e af 01 00       	call   36a20 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x880>
   1bad2:	48 8b 05 c7 f0 01 00 	mov    0x1f0c7(%rip),%rax        # 3aba0 <typeinfo name for nav2_core::Controller*@@Base+0x40>
   1bad9:	48 89 ef             	mov    %rbp,%rdi
   1badc:	66 48 0f 6e c0       	movq   %rax,%xmm0
   1bae1:	e8 0a 42 ff ff       	call   fcf0 <rclcpp::ParameterValue::ParameterValue(double)@plt>
   1bae6:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   1baea:	48 8b 53 30          	mov    0x30(%rbx),%rdx
   1baee:	4c 89 f7             	mov    %r14,%rdi
   1baf1:	4c 89 ac 24 10 05 00 	mov    %r13,0x510(%rsp)
   1baf8:	00 
   1baf9:	48 01 f2             	add    %rsi,%rdx
   1bafc:	e8 ff b0 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1bb01:	48 b8 ff ff ff ff ff 	movabs $0x3fffffffffffffff,%rax
   1bb08:	ff ff 3f 
   1bb0b:	48 2b 84 24 18 05 00 	sub    0x518(%rsp),%rax
   1bb12:	00 
   1bb13:	48 83 f8 13          	cmp    $0x13,%rax
   1bb17:	0f 86 98 19 00 00    	jbe    1d4b5 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x22e5>
   1bb1d:	ba 14 00 00 00       	mov    $0x14,%edx
   1bb22:	48 8d 35 80 d5 01 00 	lea    0x1d580(%rip),%rsi        # 390a9 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2f09>
   1bb29:	4c 89 f7             	mov    %r14,%rdi
   1bb2c:	e8 af 40 ff ff       	call   fbe0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_append(char const*, unsigned long)@plt>
   1bb31:	48 8b 0c 24          	mov    (%rsp),%rcx
   1bb35:	48 85 c9             	test   %rcx,%rcx
   1bb38:	74 14                	je     1bb4e <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x97e>
   1bb3a:	48 8b 05 37 b3 02 00 	mov    0x2b337(%rip),%rax        # 46e78 <__libc_single_threaded@GLIBC_2.32>
   1bb41:	80 38 00             	cmpb   $0x0,(%rax)
   1bb44:	0f 84 c2 15 00 00    	je     1d10c <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1f3c>
   1bb4a:	83 41 08 01          	addl   $0x1,0x8(%rcx)
   1bb4e:	4c 89 f6             	mov    %r14,%rsi
   1bb51:	4c 89 e7             	mov    %r12,%rdi
   1bb54:	e8 d7 41 ff ff       	call   fd30 <rclcpp_lifecycle::LifecycleNode::has_parameter(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&) const@plt>
   1bb59:	84 c0                	test   %al,%al
   1bb5b:	0f 84 fa 14 00 00    	je     1d05b <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1e8b>
   1bb61:	48 8b 04 24          	mov    (%rsp),%rax
   1bb65:	48 85 c0             	test   %rax,%rax
   1bb68:	74 08                	je     1bb72 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x9a2>
   1bb6a:	48 89 c7             	mov    %rax,%rdi
   1bb6d:	e8 6e a9 ff ff       	call   164e0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x770>
   1bb72:	48 8b bc 24 10 05 00 	mov    0x510(%rsp),%rdi
   1bb79:	00 
   1bb7a:	4c 39 ef             	cmp    %r13,%rdi
   1bb7d:	74 11                	je     1bb90 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x9c0>
   1bb7f:	48 8b 84 24 20 05 00 	mov    0x520(%rsp),%rax
   1bb86:	00 
   1bb87:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1bb8b:	e8 30 44 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1bb90:	48 89 ef             	mov    %rbp,%rdi
   1bb93:	e8 38 a5 ff ff       	call   160d0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x360>
   1bb98:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   1bb9d:	e8 de 99 ff ff       	call   15580 <nav2_rotation_shim_controller::RotationShimController::setSpeedLimit(double const&, bool const&)@@Base+0xe0>
   1bba2:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
   1bba9:	00 
   1bbaa:	48 89 ef             	mov    %rbp,%rdi
   1bbad:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   1bbb2:	e8 69 ae 01 00       	call   36a20 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x880>
   1bbb7:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   1bbbb:	48 8b 53 30          	mov    0x30(%rbx),%rdx
   1bbbf:	4c 89 bc 24 10 09 00 	mov    %r15,0x910(%rsp)
   1bbc6:	00 
   1bbc7:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   1bbcc:	48 01 f2             	add    %rsi,%rdx
   1bbcf:	e8 2c b0 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1bbd4:	48 b8 ff ff ff ff ff 	movabs $0x3fffffffffffffff,%rax
   1bbdb:	ff ff 3f 
   1bbde:	48 2b 84 24 18 09 00 	sub    0x918(%rsp),%rax
   1bbe5:	00 
   1bbe6:	48 83 f8 12          	cmp    $0x12,%rax
   1bbea:	0f 86 3d 19 00 00    	jbe    1d52d <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x235d>
   1bbf0:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   1bbf5:	ba 13 00 00 00       	mov    $0x13,%edx
   1bbfa:	48 8d 35 86 d5 01 00 	lea    0x1d586(%rip),%rsi        # 39187 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2fe7>
   1bc01:	e8 da 3f ff ff       	call   fbe0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_append(char const*, unsigned long)@plt>
   1bc06:	48 8b 0c 24          	mov    (%rsp),%rcx
   1bc0a:	48 85 c9             	test   %rcx,%rcx
   1bc0d:	74 14                	je     1bc23 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xa53>
   1bc0f:	48 8b 05 62 b2 02 00 	mov    0x2b262(%rip),%rax        # 46e78 <__libc_single_threaded@GLIBC_2.32>
   1bc16:	80 38 00             	cmpb   $0x0,(%rax)
   1bc19:	0f 84 df 14 00 00    	je     1d0fe <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1f2e>
   1bc1f:	83 41 08 01          	addl   $0x1,0x8(%rcx)
   1bc23:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   1bc28:	4c 89 e7             	mov    %r12,%rdi
   1bc2b:	e8 00 41 ff ff       	call   fd30 <rclcpp_lifecycle::LifecycleNode::has_parameter(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&) const@plt>
   1bc30:	84 c0                	test   %al,%al
   1bc32:	0f 84 b5 13 00 00    	je     1cfed <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1e1d>
   1bc38:	48 8b 04 24          	mov    (%rsp),%rax
   1bc3c:	48 85 c0             	test   %rax,%rax
   1bc3f:	74 08                	je     1bc49 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xa79>
   1bc41:	48 89 c7             	mov    %rax,%rdi
   1bc44:	e8 97 a8 ff ff       	call   164e0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x770>
   1bc49:	48 8b bc 24 10 09 00 	mov    0x910(%rsp),%rdi
   1bc50:	00 
   1bc51:	4c 39 ff             	cmp    %r15,%rdi
   1bc54:	74 11                	je     1bc67 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xa97>
   1bc56:	48 8b 84 24 20 09 00 	mov    0x920(%rsp),%rax
   1bc5d:	00 
   1bc5e:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1bc62:	e8 59 43 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1bc67:	48 89 ef             	mov    %rbp,%rdi
   1bc6a:	e8 11 99 ff ff       	call   15580 <nav2_rotation_shim_controller::RotationShimController::setSpeedLimit(double const&, bool const&)@@Base+0xe0>
   1bc6f:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   1bc74:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
   1bc7b:	00 
   1bc7c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   1bc81:	e8 9a ad 01 00       	call   36a20 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x880>
   1bc86:	31 f6                	xor    %esi,%esi
   1bc88:	48 89 ef             	mov    %rbp,%rdi
   1bc8b:	e8 f0 42 ff ff       	call   ff80 <rclcpp::ParameterValue::ParameterValue(bool)@plt>
   1bc90:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   1bc94:	48 8b 53 30          	mov    0x30(%rbx),%rdx
   1bc98:	4c 89 f7             	mov    %r14,%rdi
   1bc9b:	4c 89 ac 24 10 05 00 	mov    %r13,0x510(%rsp)
   1bca2:	00 
   1bca3:	48 01 f2             	add    %rsi,%rdx
   1bca6:	e8 55 af 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1bcab:	48 b8 ff ff ff ff ff 	movabs $0x3fffffffffffffff,%rax
   1bcb2:	ff ff 3f 
   1bcb5:	48 2b 84 24 18 05 00 	sub    0x518(%rsp),%rax
   1bcbc:	00 
   1bcbd:	48 83 f8 16          	cmp    $0x16,%rax
   1bcc1:	0f 86 a2 18 00 00    	jbe    1d569 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2399>
   1bcc7:	ba 17 00 00 00       	mov    $0x17,%edx
   1bccc:	48 8d 35 eb d3 01 00 	lea    0x1d3eb(%rip),%rsi        # 390be <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2f1e>
   1bcd3:	4c 89 f7             	mov    %r14,%rdi
   1bcd6:	e8 05 3f ff ff       	call   fbe0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_append(char const*, unsigned long)@plt>
   1bcdb:	48 8b 0c 24          	mov    (%rsp),%rcx
   1bcdf:	48 85 c9             	test   %rcx,%rcx
   1bce2:	74 14                	je     1bcf8 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xb28>
   1bce4:	48 8b 05 8d b1 02 00 	mov    0x2b18d(%rip),%rax        # 46e78 <__libc_single_threaded@GLIBC_2.32>
   1bceb:	80 38 00             	cmpb   $0x0,(%rax)
   1bcee:	0f 84 fc 13 00 00    	je     1d0f0 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1f20>
   1bcf4:	83 41 08 01          	addl   $0x1,0x8(%rcx)
   1bcf8:	4c 89 f6             	mov    %r14,%rsi
   1bcfb:	4c 89 e7             	mov    %r12,%rdi
   1bcfe:	e8 2d 40 ff ff       	call   fd30 <rclcpp_lifecycle::LifecycleNode::has_parameter(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&) const@plt>
   1bd03:	84 c0                	test   %al,%al
   1bd05:	0f 84 1a 13 00 00    	je     1d025 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1e55>
   1bd0b:	48 8b 04 24          	mov    (%rsp),%rax
   1bd0f:	48 85 c0             	test   %rax,%rax
   1bd12:	74 08                	je     1bd1c <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xb4c>
   1bd14:	48 89 c7             	mov    %rax,%rdi
   1bd17:	e8 c4 a7 ff ff       	call   164e0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x770>
   1bd1c:	48 8b bc 24 10 05 00 	mov    0x510(%rsp),%rdi
   1bd23:	00 
   1bd24:	4c 39 ef             	cmp    %r13,%rdi
   1bd27:	74 11                	je     1bd3a <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xb6a>
   1bd29:	48 8b 84 24 20 05 00 	mov    0x520(%rsp),%rax
   1bd30:	00 
   1bd31:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1bd35:	e8 86 42 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1bd3a:	48 89 ef             	mov    %rbp,%rdi
   1bd3d:	e8 8e a3 ff ff       	call   160d0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x360>
   1bd42:	48 8b bc 24 98 09 00 	mov    0x998(%rsp),%rdi
   1bd49:	00 
   1bd4a:	48 85 ff             	test   %rdi,%rdi
   1bd4d:	74 10                	je     1bd5f <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xb8f>
   1bd4f:	48 8b b4 24 a8 09 00 	mov    0x9a8(%rsp),%rsi
   1bd56:	00 
   1bd57:	48 29 fe             	sub    %rdi,%rsi
   1bd5a:	e8 61 42 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1bd5f:	48 8b bc 24 80 09 00 	mov    0x980(%rsp),%rdi
   1bd66:	00 
   1bd67:	48 85 ff             	test   %rdi,%rdi
   1bd6a:	74 10                	je     1bd7c <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xbac>
   1bd6c:	48 8b b4 24 90 09 00 	mov    0x990(%rsp),%rsi
   1bd73:	00 
   1bd74:	48 29 fe             	sub    %rdi,%rsi
   1bd77:	e8 44 42 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1bd7c:	48 8b bc 24 58 09 00 	mov    0x958(%rsp),%rdi
   1bd83:	00 
   1bd84:	48 3b 7c 24 28       	cmp    0x28(%rsp),%rdi
   1bd89:	74 11                	je     1bd9c <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xbcc>
   1bd8b:	48 8b 84 24 68 09 00 	mov    0x968(%rsp),%rax
   1bd92:	00 
   1bd93:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1bd97:	e8 24 42 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1bd9c:	48 8b bc 24 38 09 00 	mov    0x938(%rsp),%rdi
   1bda3:	00 
   1bda4:	48 3b 7c 24 20       	cmp    0x20(%rsp),%rdi
   1bda9:	74 11                	je     1bdbc <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xbec>
   1bdab:	48 8b 84 24 48 09 00 	mov    0x948(%rsp),%rax
   1bdb2:	00 
   1bdb3:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1bdb7:	e8 04 42 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1bdbc:	48 8b bc 24 10 09 00 	mov    0x910(%rsp),%rdi
   1bdc3:	00 
   1bdc4:	4c 39 ff             	cmp    %r15,%rdi
   1bdc7:	74 11                	je     1bdda <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xc0a>
   1bdc9:	48 8b 84 24 20 09 00 	mov    0x920(%rsp),%rax
   1bdd0:	00 
   1bdd1:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1bdd5:	e8 e6 41 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1bdda:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   1bddf:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
   1bde6:	00 
   1bde7:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   1bdec:	e8 2f ac 01 00       	call   36a20 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x880>
   1bdf1:	be 01 00 00 00       	mov    $0x1,%esi
   1bdf6:	48 89 ef             	mov    %rbp,%rdi
   1bdf9:	e8 82 41 ff ff       	call   ff80 <rclcpp::ParameterValue::ParameterValue(bool)@plt>
   1bdfe:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   1be02:	48 8b 53 30          	mov    0x30(%rbx),%rdx
   1be06:	4c 89 f7             	mov    %r14,%rdi
   1be09:	4c 89 ac 24 10 05 00 	mov    %r13,0x510(%rsp)
   1be10:	00 
   1be11:	48 01 f2             	add    %rsi,%rdx
   1be14:	e8 e7 ad 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1be19:	48 b8 ff ff ff ff ff 	movabs $0x3fffffffffffffff,%rax
   1be20:	ff ff 3f 
   1be23:	48 2b 84 24 18 05 00 	sub    0x518(%rsp),%rax
   1be2a:	00 
   1be2b:	48 83 f8 0b          	cmp    $0xb,%rax
   1be2f:	0f 86 74 16 00 00    	jbe    1d4a9 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x22d9>
   1be35:	ba 0c 00 00 00       	mov    $0xc,%edx
   1be3a:	48 8d 35 95 d2 01 00 	lea    0x1d295(%rip),%rsi        # 390d6 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2f36>
   1be41:	4c 89 f7             	mov    %r14,%rdi
   1be44:	e8 97 3d ff ff       	call   fbe0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_append(char const*, unsigned long)@plt>
   1be49:	48 8b 0c 24          	mov    (%rsp),%rcx
   1be4d:	48 85 c9             	test   %rcx,%rcx
   1be50:	74 14                	je     1be66 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xc96>
   1be52:	48 8b 05 1f b0 02 00 	mov    0x2b01f(%rip),%rax        # 46e78 <__libc_single_threaded@GLIBC_2.32>
   1be59:	80 38 00             	cmpb   $0x0,(%rax)
   1be5c:	0f 84 80 12 00 00    	je     1d0e2 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1f12>
   1be62:	83 41 08 01          	addl   $0x1,0x8(%rcx)
   1be66:	4c 89 f6             	mov    %r14,%rsi
   1be69:	4c 89 e7             	mov    %r12,%rdi
   1be6c:	e8 bf 3e ff ff       	call   fd30 <rclcpp_lifecycle::LifecycleNode::has_parameter(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&) const@plt>
   1be71:	84 c0                	test   %al,%al
   1be73:	0f 84 91 11 00 00    	je     1d00a <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1e3a>
   1be79:	48 8b 04 24          	mov    (%rsp),%rax
   1be7d:	48 85 c0             	test   %rax,%rax
   1be80:	74 08                	je     1be8a <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xcba>
   1be82:	48 89 c7             	mov    %rax,%rdi
   1be85:	e8 56 a6 ff ff       	call   164e0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x770>
   1be8a:	48 8b bc 24 10 05 00 	mov    0x510(%rsp),%rdi
   1be91:	00 
   1be92:	4c 39 ef             	cmp    %r13,%rdi
   1be95:	74 11                	je     1bea8 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xcd8>
   1be97:	48 8b 84 24 20 05 00 	mov    0x520(%rsp),%rax
   1be9e:	00 
   1be9f:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1bea3:	e8 18 41 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1bea8:	48 89 ef             	mov    %rbp,%rdi
   1beab:	4c 8d ab a0 01 00 00 	lea    0x1a0(%rbx),%r13
   1beb2:	e8 19 a2 ff ff       	call   160d0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x360>
   1beb7:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   1bebc:	e8 bf 96 ff ff       	call   15580 <nav2_rotation_shim_controller::RotationShimController::setSpeedLimit(double const&, bool const&)@@Base+0xe0>
   1bec1:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   1bec5:	48 8b 53 30          	mov    0x30(%rbx),%rdx
   1bec9:	48 89 ef             	mov    %rbp,%rdi
   1becc:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   1bed1:	48 01 f2             	add    %rsi,%rdx
   1bed4:	48 89 84 24 10 0d 00 	mov    %rax,0xd10(%rsp)
   1bedb:	00 
   1bedc:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
   1bee3:	00 
   1bee4:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   1bee9:	e8 12 ad 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1beee:	48 b8 ff ff ff ff ff 	movabs $0x3fffffffffffffff,%rax
   1bef5:	ff ff 3f 
   1bef8:	48 2b 84 24 18 0d 00 	sub    0xd18(%rsp),%rax
   1beff:	00 
   1bf00:	48 83 f8 16          	cmp    $0x16,%rax
   1bf04:	0f 86 47 16 00 00    	jbe    1d551 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2381>
   1bf0a:	ba 17 00 00 00       	mov    $0x17,%edx
   1bf0f:	48 8d 35 4d d1 01 00 	lea    0x1d14d(%rip),%rsi        # 39063 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2ec3>
   1bf16:	48 89 ef             	mov    %rbp,%rdi
   1bf19:	e8 c2 3c ff ff       	call   fbe0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_append(char const*, unsigned long)@plt>
   1bf1e:	4c 89 ea             	mov    %r13,%rdx
   1bf21:	48 89 ee             	mov    %rbp,%rsi
   1bf24:	4c 89 e7             	mov    %r12,%rdi
   1bf27:	e8 e4 d5 ff ff       	call   19510 <nav2_rotation_shim_controller::RotationShimController::dynamicParametersCallback(std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> >)@@Base+0xd80>
   1bf2c:	48 8b bc 24 10 0d 00 	mov    0xd10(%rsp),%rdi
   1bf33:	00 
   1bf34:	48 3b 7c 24 18       	cmp    0x18(%rsp),%rdi
   1bf39:	74 11                	je     1bf4c <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xd7c>
   1bf3b:	48 8b 84 24 20 0d 00 	mov    0xd20(%rsp),%rax
   1bf42:	00 
   1bf43:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1bf47:	e8 74 40 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1bf4c:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   1bf51:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   1bf55:	48 89 ef             	mov    %rbp,%rdi
   1bf58:	4c 8d ab a8 01 00 00 	lea    0x1a8(%rbx),%r13
   1bf5f:	48 8b 53 30          	mov    0x30(%rbx),%rdx
   1bf63:	48 89 84 24 10 0d 00 	mov    %rax,0xd10(%rsp)
   1bf6a:	00 
   1bf6b:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
   1bf72:	00 
   1bf73:	48 01 f2             	add    %rsi,%rdx
   1bf76:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   1bf7b:	e8 80 ac 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1bf80:	48 b8 ff ff ff ff ff 	movabs $0x3fffffffffffffff,%rax
   1bf87:	ff ff 3f 
   1bf8a:	48 2b 84 24 18 0d 00 	sub    0xd18(%rsp),%rax
   1bf91:	00 
   1bf92:	48 83 f8 1b          	cmp    $0x1b,%rax
   1bf96:	0f 86 3d 15 00 00    	jbe    1d4d9 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2309>
   1bf9c:	ba 1c 00 00 00       	mov    $0x1c,%edx
   1bfa1:	48 8d 35 c2 d1 01 00 	lea    0x1d1c2(%rip),%rsi        # 3916a <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2fca>
   1bfa8:	48 89 ef             	mov    %rbp,%rdi
   1bfab:	e8 30 3c ff ff       	call   fbe0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_append(char const*, unsigned long)@plt>
   1bfb0:	4c 89 ea             	mov    %r13,%rdx
   1bfb3:	48 89 ee             	mov    %rbp,%rsi
   1bfb6:	4c 89 e7             	mov    %r12,%rdi
   1bfb9:	e8 52 d5 ff ff       	call   19510 <nav2_rotation_shim_controller::RotationShimController::dynamicParametersCallback(std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> >)@@Base+0xd80>
   1bfbe:	48 8b bc 24 10 0d 00 	mov    0xd10(%rsp),%rdi
   1bfc5:	00 
   1bfc6:	48 3b 7c 24 18       	cmp    0x18(%rsp),%rdi
   1bfcb:	74 11                	je     1bfde <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xe0e>
   1bfcd:	48 8b 84 24 20 0d 00 	mov    0xd20(%rsp),%rax
   1bfd4:	00 
   1bfd5:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1bfd9:	e8 e2 3f ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1bfde:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   1bfe3:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   1bfe7:	48 89 ef             	mov    %rbp,%rdi
   1bfea:	4c 8d ab 98 01 00 00 	lea    0x198(%rbx),%r13
   1bff1:	48 8b 53 30          	mov    0x30(%rbx),%rdx
   1bff5:	48 89 84 24 10 0d 00 	mov    %rax,0xd10(%rsp)
   1bffc:	00 
   1bffd:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
   1c004:	00 
   1c005:	48 01 f2             	add    %rsi,%rdx
   1c008:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   1c00d:	e8 ee ab 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1c012:	48 b8 ff ff ff ff ff 	movabs $0x3fffffffffffffff,%rax
   1c019:	ff ff 3f 
   1c01c:	48 2b 84 24 18 0d 00 	sub    0xd18(%rsp),%rax
   1c023:	00 
   1c024:	48 83 f8 19          	cmp    $0x19,%rax
   1c028:	0f 86 f3 14 00 00    	jbe    1d521 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2351>
   1c02e:	ba 1a 00 00 00       	mov    $0x1a,%edx
   1c033:	48 8d 35 41 d0 01 00 	lea    0x1d041(%rip),%rsi        # 3907b <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2edb>
   1c03a:	48 89 ef             	mov    %rbp,%rdi
   1c03d:	e8 9e 3b ff ff       	call   fbe0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_append(char const*, unsigned long)@plt>
   1c042:	4c 89 ea             	mov    %r13,%rdx
   1c045:	48 89 ee             	mov    %rbp,%rsi
   1c048:	4c 89 e7             	mov    %r12,%rdi
   1c04b:	e8 c0 d4 ff ff       	call   19510 <nav2_rotation_shim_controller::RotationShimController::dynamicParametersCallback(std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> >)@@Base+0xd80>
   1c050:	48 8b bc 24 10 0d 00 	mov    0xd10(%rsp),%rdi
   1c057:	00 
   1c058:	48 3b 7c 24 18       	cmp    0x18(%rsp),%rdi
   1c05d:	74 11                	je     1c070 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xea0>
   1c05f:	48 8b 84 24 20 0d 00 	mov    0xd20(%rsp),%rax
   1c066:	00 
   1c067:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1c06b:	e8 50 3f ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1c070:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   1c075:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   1c079:	48 89 ef             	mov    %rbp,%rdi
   1c07c:	4c 8d ab b0 01 00 00 	lea    0x1b0(%rbx),%r13
   1c083:	48 8b 53 30          	mov    0x30(%rbx),%rdx
   1c087:	48 89 84 24 10 0d 00 	mov    %rax,0xd10(%rsp)
   1c08e:	00 
   1c08f:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
   1c096:	00 
   1c097:	48 01 f2             	add    %rsi,%rdx
   1c09a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   1c09f:	e8 5c ab 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1c0a4:	48 b8 ff ff ff ff ff 	movabs $0x3fffffffffffffff,%rax
   1c0ab:	ff ff 3f 
   1c0ae:	48 2b 84 24 18 0d 00 	sub    0xd18(%rsp),%rax
   1c0b5:	00 
   1c0b6:	48 83 f8 1d          	cmp    $0x1d,%rax
   1c0ba:	0f 86 55 14 00 00    	jbe    1d515 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2345>
   1c0c0:	ba 1e 00 00 00       	mov    $0x1e,%edx
   1c0c5:	48 8d 35 1c d5 01 00 	lea    0x1d51c(%rip),%rsi        # 395e8 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3448>
   1c0cc:	48 89 ef             	mov    %rbp,%rdi
   1c0cf:	e8 0c 3b ff ff       	call   fbe0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_append(char const*, unsigned long)@plt>
   1c0d4:	4c 89 ea             	mov    %r13,%rdx
   1c0d7:	48 89 ee             	mov    %rbp,%rsi
   1c0da:	4c 89 e7             	mov    %r12,%rdi
   1c0dd:	e8 2e d4 ff ff       	call   19510 <nav2_rotation_shim_controller::RotationShimController::dynamicParametersCallback(std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> >)@@Base+0xd80>
   1c0e2:	48 8b bc 24 10 0d 00 	mov    0xd10(%rsp),%rdi
   1c0e9:	00 
   1c0ea:	48 3b 7c 24 18       	cmp    0x18(%rsp),%rdi
   1c0ef:	74 11                	je     1c102 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xf32>
   1c0f1:	48 8b 84 24 20 0d 00 	mov    0xd20(%rsp),%rax
   1c0f8:	00 
   1c0f9:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1c0fd:	e8 be 3e ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1c102:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   1c107:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   1c10b:	48 89 ef             	mov    %rbp,%rdi
   1c10e:	4c 8d ab b8 01 00 00 	lea    0x1b8(%rbx),%r13
   1c115:	48 8b 53 30          	mov    0x30(%rbx),%rdx
   1c119:	48 89 84 24 10 0d 00 	mov    %rax,0xd10(%rsp)
   1c120:	00 
   1c121:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
   1c128:	00 
   1c129:	48 01 f2             	add    %rsi,%rdx
   1c12c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   1c131:	e8 ca aa 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1c136:	48 b8 ff ff ff ff ff 	movabs $0x3fffffffffffffff,%rax
   1c13d:	ff ff 3f 
   1c140:	48 2b 84 24 18 0d 00 	sub    0xd18(%rsp),%rax
   1c147:	00 
   1c148:	48 83 f8 11          	cmp    $0x11,%rax
   1c14c:	0f 86 3f 13 00 00    	jbe    1d491 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x22c1>
   1c152:	ba 12 00 00 00       	mov    $0x12,%edx
   1c157:	48 8d 35 38 cf 01 00 	lea    0x1cf38(%rip),%rsi        # 39096 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2ef6>
   1c15e:	48 89 ef             	mov    %rbp,%rdi
   1c161:	e8 7a 3a ff ff       	call   fbe0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_append(char const*, unsigned long)@plt>
   1c166:	4c 89 ea             	mov    %r13,%rdx
   1c169:	48 89 ee             	mov    %rbp,%rsi
   1c16c:	4c 89 e7             	mov    %r12,%rdi
   1c16f:	e8 9c d3 ff ff       	call   19510 <nav2_rotation_shim_controller::RotationShimController::dynamicParametersCallback(std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> >)@@Base+0xd80>
   1c174:	48 8b bc 24 10 0d 00 	mov    0xd10(%rsp),%rdi
   1c17b:	00 
   1c17c:	48 3b 7c 24 18       	cmp    0x18(%rsp),%rdi
   1c181:	74 11                	je     1c194 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xfc4>
   1c183:	48 8b 84 24 20 0d 00 	mov    0xd20(%rsp),%rax
   1c18a:	00 
   1c18b:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1c18f:	e8 2c 3e ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1c194:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   1c199:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   1c19d:	48 89 ef             	mov    %rbp,%rdi
   1c1a0:	4c 8d ab c8 01 00 00 	lea    0x1c8(%rbx),%r13
   1c1a7:	48 8b 53 30          	mov    0x30(%rbx),%rdx
   1c1ab:	48 89 84 24 10 0d 00 	mov    %rax,0xd10(%rsp)
   1c1b2:	00 
   1c1b3:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
   1c1ba:	00 
   1c1bb:	48 01 f2             	add    %rsi,%rdx
   1c1be:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   1c1c3:	e8 38 aa 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1c1c8:	48 b8 ff ff ff ff ff 	movabs $0x3fffffffffffffff,%rax
   1c1cf:	ff ff 3f 
   1c1d2:	48 2b 84 24 18 0d 00 	sub    0xd18(%rsp),%rax
   1c1d9:	00 
   1c1da:	48 83 f8 13          	cmp    $0x13,%rax
   1c1de:	0f 86 25 13 00 00    	jbe    1d509 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2339>
   1c1e4:	ba 14 00 00 00       	mov    $0x14,%edx
   1c1e9:	48 8d 35 b9 ce 01 00 	lea    0x1ceb9(%rip),%rsi        # 390a9 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2f09>
   1c1f0:	48 89 ef             	mov    %rbp,%rdi
   1c1f3:	e8 e8 39 ff ff       	call   fbe0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_append(char const*, unsigned long)@plt>
   1c1f8:	4c 89 ea             	mov    %r13,%rdx
   1c1fb:	48 89 ee             	mov    %rbp,%rsi
   1c1fe:	4c 89 e7             	mov    %r12,%rdi
   1c201:	e8 0a d3 ff ff       	call   19510 <nav2_rotation_shim_controller::RotationShimController::dynamicParametersCallback(std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> >)@@Base+0xd80>
   1c206:	48 8b bc 24 10 0d 00 	mov    0xd10(%rsp),%rdi
   1c20d:	00 
   1c20e:	48 3b 7c 24 18       	cmp    0x18(%rsp),%rdi
   1c213:	74 11                	je     1c226 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1056>
   1c215:	48 8b 84 24 20 0d 00 	mov    0xd20(%rsp),%rax
   1c21c:	00 
   1c21d:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1c221:	e8 9a 3d ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1c226:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   1c22a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
   1c22e:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
   1c235:	00 
   1c236:	4c 89 bc 24 10 09 00 	mov    %r15,0x910(%rsp)
   1c23d:	00 
   1c23e:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   1c243:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   1c248:	48 01 f2             	add    %rsi,%rdx
   1c24b:	e8 b0 a9 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1c250:	48 b8 ff ff ff ff ff 	movabs $0x3fffffffffffffff,%rax
   1c257:	ff ff 3f 
   1c25a:	48 2b 84 24 18 09 00 	sub    0x918(%rsp),%rax
   1c261:	00 
   1c262:	48 83 f8 12          	cmp    $0x12,%rax
   1c266:	0f 86 91 12 00 00    	jbe    1d4fd <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x232d>
   1c26c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   1c271:	ba 13 00 00 00       	mov    $0x13,%edx
   1c276:	48 8d 35 0a cf 01 00 	lea    0x1cf0a(%rip),%rsi        # 39187 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2fe7>
   1c27d:	e8 5e 39 ff ff       	call   fbe0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_append(char const*, unsigned long)@plt>
   1c282:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   1c287:	4c 89 e6             	mov    %r12,%rsi
   1c28a:	48 89 ef             	mov    %rbp,%rdi
   1c28d:	e8 de 3f ff ff       	call   10270 <rclcpp_lifecycle::LifecycleNode::get_parameter(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&) const@plt>
   1c292:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
   1c299:	00 
   1c29a:	48 89 ef             	mov    %rbp,%rdi
   1c29d:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   1c2a2:	e8 09 42 ff ff       	call   104b0 <rclcpp::Parameter::as_string[abi:cxx11]() const@plt>
   1c2a7:	48 89 c6             	mov    %rax,%rsi
   1c2aa:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
   1c2b1:	00 
   1c2b2:	48 89 c7             	mov    %rax,%rdi
   1c2b5:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   1c2ba:	e8 a1 3a ff ff       	call   fd60 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_assign(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&)@plt>
   1c2bf:	48 8d bc 24 30 0d 00 	lea    0xd30(%rsp),%rdi
   1c2c6:	00 
   1c2c7:	e8 04 9e ff ff       	call   160d0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x360>
   1c2cc:	48 8b bc 24 10 0d 00 	mov    0xd10(%rsp),%rdi
   1c2d3:	00 
   1c2d4:	48 3b 7c 24 18       	cmp    0x18(%rsp),%rdi
   1c2d9:	74 11                	je     1c2ec <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x111c>
   1c2db:	48 8b 84 24 20 0d 00 	mov    0xd20(%rsp),%rax
   1c2e2:	00 
   1c2e3:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1c2e7:	e8 d4 3c ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1c2ec:	48 8b bc 24 10 09 00 	mov    0x910(%rsp),%rdi
   1c2f3:	00 
   1c2f4:	4c 39 ff             	cmp    %r15,%rdi
   1c2f7:	74 11                	je     1c30a <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x113a>
   1c2f9:	48 8b 84 24 20 09 00 	mov    0x920(%rsp),%rax
   1c300:	00 
   1c301:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1c305:	e8 b6 3c ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1c30a:	48 8d 35 8a ce 01 00 	lea    0x1ce8a(%rip),%rsi        # 3919b <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2ffb>
   1c311:	48 89 ef             	mov    %rbp,%rdi
   1c314:	e8 07 a8 01 00       	call   36b20 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x980>
   1c319:	48 8d 94 24 90 00 00 	lea    0x90(%rsp),%rdx
   1c320:	00 
   1c321:	48 89 ee             	mov    %rbp,%rsi
   1c324:	4c 89 e7             	mov    %r12,%rdi
   1c327:	e8 e4 d1 ff ff       	call   19510 <nav2_rotation_shim_controller::RotationShimController::dynamicParametersCallback(std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> >)@@Base+0xd80>
   1c32c:	48 8b bc 24 10 0d 00 	mov    0xd10(%rsp),%rdi
   1c333:	00 
   1c334:	48 3b 7c 24 18       	cmp    0x18(%rsp),%rdi
   1c339:	74 11                	je     1c34c <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x117c>
   1c33b:	48 8b 84 24 20 0d 00 	mov    0xd20(%rsp),%rax
   1c342:	00 
   1c343:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1c347:	e8 74 3c ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1c34c:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   1c350:	48 8b 53 30          	mov    0x30(%rbx),%rdx
   1c354:	48 89 ef             	mov    %rbp,%rdi
   1c357:	4c 8d ab d0 01 00 00 	lea    0x1d0(%rbx),%r13
   1c35e:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   1c363:	f2 0f 10 05 35 e8 01 	movsd  0x1e835(%rip),%xmm0        # 3aba0 <typeinfo name for nav2_core::Controller*@@Base+0x40>
   1c36a:	00 
   1c36b:	f2 0f 5e 84 24 90 00 	divsd  0x90(%rsp),%xmm0
   1c372:	00 00 
   1c374:	f2 0f 11 83 c0 01 00 	movsd  %xmm0,0x1c0(%rbx)
   1c37b:	00 
   1c37c:	48 01 f2             	add    %rsi,%rdx
   1c37f:	48 89 84 24 10 0d 00 	mov    %rax,0xd10(%rsp)
   1c386:	00 
   1c387:	e8 74 a8 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1c38c:	48 b8 ff ff ff ff ff 	movabs $0x3fffffffffffffff,%rax
   1c393:	ff ff 3f 
   1c396:	48 2b 84 24 18 0d 00 	sub    0xd18(%rsp),%rax
   1c39d:	00 
   1c39e:	48 83 f8 16          	cmp    $0x16,%rax
   1c3a2:	0f 86 49 11 00 00    	jbe    1d4f1 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2321>
   1c3a8:	ba 17 00 00 00       	mov    $0x17,%edx
   1c3ad:	48 8d 35 0a cd 01 00 	lea    0x1cd0a(%rip),%rsi        # 390be <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2f1e>
   1c3b4:	48 89 ef             	mov    %rbp,%rdi
   1c3b7:	e8 24 38 ff ff       	call   fbe0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_append(char const*, unsigned long)@plt>
   1c3bc:	4c 89 ea             	mov    %r13,%rdx
   1c3bf:	48 89 ee             	mov    %rbp,%rsi
   1c3c2:	4c 89 e7             	mov    %r12,%rdi
   1c3c5:	e8 26 d4 ff ff       	call   197f0 <nav2_rotation_shim_controller::RotationShimController::dynamicParametersCallback(std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> >)@@Base+0x1060>
   1c3ca:	48 8b bc 24 10 0d 00 	mov    0xd10(%rsp),%rdi
   1c3d1:	00 
   1c3d2:	48 3b 7c 24 18       	cmp    0x18(%rsp),%rdi
   1c3d7:	74 11                	je     1c3ea <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x121a>
   1c3d9:	48 8b 84 24 20 0d 00 	mov    0xd20(%rsp),%rax
   1c3e0:	00 
   1c3e1:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1c3e5:	e8 d6 3b ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1c3ea:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   1c3ee:	48 8b 53 30          	mov    0x30(%rbx),%rdx
   1c3f2:	48 89 ef             	mov    %rbp,%rdi
   1c3f5:	4c 8d ab d2 01 00 00 	lea    0x1d2(%rbx),%r13
   1c3fc:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   1c401:	48 01 f2             	add    %rsi,%rdx
   1c404:	48 89 84 24 10 0d 00 	mov    %rax,0xd10(%rsp)
   1c40b:	00 
   1c40c:	e8 ef a7 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1c411:	48 b8 ff ff ff ff ff 	movabs $0x3fffffffffffffff,%rax
   1c418:	ff ff 3f 
   1c41b:	48 2b 84 24 18 0d 00 	sub    0xd18(%rsp),%rax
   1c422:	00 
   1c423:	48 83 f8 0b          	cmp    $0xb,%rax
   1c427:	0f 86 b8 10 00 00    	jbe    1d4e5 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2315>
   1c42d:	ba 0c 00 00 00       	mov    $0xc,%edx
   1c432:	48 8d 35 9d cc 01 00 	lea    0x1cc9d(%rip),%rsi        # 390d6 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2f36>
   1c439:	48 89 ef             	mov    %rbp,%rdi
   1c43c:	e8 9f 37 ff ff       	call   fbe0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_append(char const*, unsigned long)@plt>
   1c441:	4c 89 ea             	mov    %r13,%rdx
   1c444:	48 89 ee             	mov    %rbp,%rsi
   1c447:	4c 89 e7             	mov    %r12,%rdi
   1c44a:	e8 a1 d3 ff ff       	call   197f0 <nav2_rotation_shim_controller::RotationShimController::dynamicParametersCallback(std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> >)@@Base+0x1060>
   1c44f:	48 8b bc 24 10 0d 00 	mov    0xd10(%rsp),%rdi
   1c456:	00 
   1c457:	48 3b 7c 24 18       	cmp    0x18(%rsp),%rdi
   1c45c:	74 11                	je     1c46f <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x129f>
   1c45e:	48 8b 84 24 20 0d 00 	mov    0xd20(%rsp),%rax
   1c465:	00 
   1c466:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1c46a:	e8 51 3b ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1c46f:	48 8b 05 6a a7 02 00 	mov    0x2a76a(%rip),%rax        # 46be0 <g_rcutils_logging_initialized@Base>
   1c476:	4c 8d a3 80 00 00 00 	lea    0x80(%rbx),%r12
   1c47d:	80 38 00             	cmpb   $0x0,(%rax)
   1c480:	0f 84 af 0e 00 00    	je     1d335 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2165>
   1c486:	be 0a 00 00 00       	mov    $0xa,%esi
   1c48b:	48 8d 3d 72 cc 01 00 	lea    0x1cc72(%rip),%rdi        # 39104 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2f64>
   1c492:	e8 59 3a ff ff       	call   fef0 <rcutils_logging_logger_is_enabled_for@plt>
   1c497:	84 c0                	test   %al,%al
   1c499:	0f 85 d7 0b 00 00    	jne    1d076 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1ea6>
   1c49f:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
   1c4a4:	4c 89 e7             	mov    %r12,%rdi
   1c4a7:	4c 89 fe             	mov    %r15,%rsi
   1c4aa:	e8 f1 4b 00 00       	call   210a0 <std::_Function_handler<rcl_interfaces::msg::SetParametersResult_<std::allocator<void> > (std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> > const&), std::_Bind<rcl_interfaces::msg::SetParametersResult_<std::allocator<void> > (nav2_rotation_shim_controller::RotationShimController::*(nav2_rotation_shim_controller::RotationShimController*, std::_Placeholder<1>))(std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> >)> >::_M_invoke(std::_Any_data const&, std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> > const&)@@Base+0x28b0>
   1c4af:	84 c0                	test   %al,%al
   1c4b1:	0f 84 fa 01 00 00    	je     1c6b1 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x14e1>
   1c4b7:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   1c4bc:	48 8d bb a0 00 00 00 	lea    0xa0(%rbx),%rdi
   1c4c3:	e8 f8 31 00 00       	call   1f6c0 <std::_Function_handler<rcl_interfaces::msg::SetParametersResult_<std::allocator<void> > (std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> > const&), std::_Bind<rcl_interfaces::msg::SetParametersResult_<std::allocator<void> > (nav2_rotation_shim_controller::RotationShimController::*(nav2_rotation_shim_controller::RotationShimController*, std::_Placeholder<1>))(std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> >)> >::_M_invoke(std::_Any_data const&, std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> > const&)@@Base+0xed0>
   1c4c8:	48 8d 93 a8 00 00 00 	lea    0xa8(%rbx),%rdx
   1c4cf:	48 39 d0             	cmp    %rdx,%rax
   1c4d2:	0f 84 e9 0b 00 00    	je     1d0c1 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1ef1>
   1c4d8:	48 8d 94 24 20 01 00 	lea    0x120(%rsp),%rdx
   1c4df:	00 
   1c4e0:	48 8d bc 24 10 01 00 	lea    0x110(%rsp),%rdi
   1c4e7:	00 
   1c4e8:	48 89 94 24 10 01 00 	mov    %rdx,0x110(%rsp)
   1c4ef:	00 
   1c4f0:	48 8b 50 68          	mov    0x68(%rax),%rdx
   1c4f4:	48 8b 70 60          	mov    0x60(%rax),%rsi
   1c4f8:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
   1c4fd:	48 01 f2             	add    %rsi,%rdx
   1c500:	e8 fb a6 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1c505:	48 8b 05 d4 a6 02 00 	mov    0x2a6d4(%rip),%rax        # 46be0 <g_rcutils_logging_initialized@Base>
   1c50c:	80 38 00             	cmpb   $0x0,(%rax)
   1c50f:	0f 84 ad 0e 00 00    	je     1d3c2 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x21f2>
   1c515:	be 0a 00 00 00       	mov    $0xa,%esi
   1c51a:	48 8d 3d e3 cb 01 00 	lea    0x1cbe3(%rip),%rdi        # 39104 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2f64>
   1c521:	e8 ca 39 ff ff       	call   fef0 <rcutils_logging_logger_is_enabled_for@plt>
   1c526:	4c 8b 84 24 10 01 00 	mov    0x110(%rsp),%r8
   1c52d:	00 
   1c52e:	84 c0                	test   %al,%al
   1c530:	0f 85 42 01 00 00    	jne    1c678 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x14a8>
   1c536:	48 8d 0d e3 d7 01 00 	lea    0x1d7e3(%rip),%rcx        # 39d20 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3b80>
   1c53d:	31 d2                	xor    %edx,%edx
   1c53f:	be 92 00 00 00       	mov    $0x92,%esi
   1c544:	31 c0                	xor    %eax,%eax
   1c546:	48 8d 3d 2b d8 01 00 	lea    0x1d82b(%rip),%rdi        # 39d78 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3bd8>
   1c54d:	4c 8d a3 30 01 00 00 	lea    0x130(%rbx),%r12
   1c554:	e8 37 3d ff ff       	call   10290 <console_bridge::log(char const*, int, console_bridge::LogLevel, char const*, ...)@plt>
   1c559:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   1c55e:	4c 89 e6             	mov    %r12,%rsi
   1c561:	e8 5a 3c ff ff       	call   101c0 <class_loader::MultiLibraryClassLoader::getAllAvailableClassLoaders() const@plt>
   1c566:	4c 8b ac 24 b0 00 00 	mov    0xb0(%rsp),%r13
   1c56d:	00 
   1c56e:	48 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%rdi
   1c575:	00 
   1c576:	49 39 fd             	cmp    %rdi,%r13
   1c579:	0f 84 b8 00 00 00    	je     1c637 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1467>
   1c57f:	90                   	nop
   1c580:	49 8b 7d 00          	mov    0x0(%r13),%rdi
   1c584:	e8 27 39 ff ff       	call   feb0 <class_loader::ClassLoader::isLibraryLoaded() const@plt>
   1c589:	49 8b 7d 00          	mov    0x0(%r13),%rdi
   1c58d:	84 c0                	test   %al,%al
   1c58f:	75 05                	jne    1c596 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x13c6>
   1c591:	e8 7a 3e ff ff       	call   10410 <class_loader::ClassLoader::loadLibrary()@plt>
   1c596:	49 8b 75 00          	mov    0x0(%r13),%rsi
   1c59a:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   1c59f:	e8 7c 48 00 00       	call   20e20 <std::_Function_handler<rcl_interfaces::msg::SetParametersResult_<std::allocator<void> > (std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> > const&), std::_Bind<rcl_interfaces::msg::SetParametersResult_<std::allocator<void> > (nav2_rotation_shim_controller::RotationShimController::*(nav2_rotation_shim_controller::RotationShimController*, std::_Placeholder<1>))(std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> >)> >::_M_invoke(std::_Any_data const&, std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> > const&)@@Base+0x2630>
   1c5a4:	4c 8b a4 24 d8 00 00 	mov    0xd8(%rsp),%r12
   1c5ab:	00 
   1c5ac:	4c 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%r15
   1c5b3:	00 
   1c5b4:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
   1c5b9:	4c 89 e6             	mov    %r12,%rsi
   1c5bc:	4c 89 ff             	mov    %r15,%rdi
   1c5bf:	e8 ec 2e 00 00       	call   1f4b0 <std::_Function_handler<rcl_interfaces::msg::SetParametersResult_<std::allocator<void> > (std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> > const&), std::_Bind<rcl_interfaces::msg::SetParametersResult_<std::allocator<void> > (nav2_rotation_shim_controller::RotationShimController::*(nav2_rotation_shim_controller::RotationShimController*, std::_Placeholder<1>))(std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> >)> >::_M_invoke(std::_Any_data const&, std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> > const&)@@Base+0xcc0>
   1c5c4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   1c5c9:	4d 39 fc             	cmp    %r15,%r12
   1c5cc:	74 2c                	je     1c5fa <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x142a>
   1c5ce:	66 90                	xchg   %ax,%ax
   1c5d0:	49 8b 3f             	mov    (%r15),%rdi
   1c5d3:	49 8d 47 10          	lea    0x10(%r15),%rax
   1c5d7:	48 39 c7             	cmp    %rax,%rdi
   1c5da:	74 0d                	je     1c5e9 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1419>
   1c5dc:	49 8b 47 10          	mov    0x10(%r15),%rax
   1c5e0:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1c5e4:	e8 d7 39 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1c5e9:	49 83 c7 20          	add    $0x20,%r15
   1c5ed:	4d 39 fc             	cmp    %r15,%r12
   1c5f0:	75 de                	jne    1c5d0 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1400>
   1c5f2:	4c 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%r15
   1c5f9:	00 
   1c5fa:	4d 85 ff             	test   %r15,%r15
   1c5fd:	74 13                	je     1c612 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1442>
   1c5ff:	48 8b b4 24 e0 00 00 	mov    0xe0(%rsp),%rsi
   1c606:	00 
   1c607:	4c 89 ff             	mov    %r15,%rdi
   1c60a:	4c 29 fe             	sub    %r15,%rsi
   1c60d:	e8 ae 39 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1c612:	4c 3b 64 24 20       	cmp    0x20(%rsp),%r12
   1c617:	0f 85 a4 00 00 00    	jne    1c6c1 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x14f1>
   1c61d:	49 83 c5 08          	add    $0x8,%r13
   1c621:	4c 39 ac 24 b8 00 00 	cmp    %r13,0xb8(%rsp)
   1c628:	00 
   1c629:	0f 85 51 ff ff ff    	jne    1c580 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x13b0>
   1c62f:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
   1c636:	00 
   1c637:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   1c63e:	00 
   1c63f:	48 29 fe             	sub    %rdi,%rsi
   1c642:	48 85 ff             	test   %rdi,%rdi
   1c645:	74 05                	je     1c64c <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x147c>
   1c647:	e8 74 39 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1c64c:	bf 10 00 00 00       	mov    $0x10,%edi
   1c651:	e8 aa 36 ff ff       	call   fd00 <__cxa_allocate_exception@plt>
   1c656:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
   1c65b:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   1c660:	48 8d 35 69 d7 01 00 	lea    0x1d769(%rip),%rsi        # 39dd0 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3c30>
   1c667:	49 89 c7             	mov    %rax,%r15
   1c66a:	e8 01 ce ff ff       	call   19470 <nav2_rotation_shim_controller::RotationShimController::dynamicParametersCallback(std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> >)@@Base+0xce0>
   1c66f:	e9 c1 59 ff ff       	jmp    12035 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1b65>
   1c674:	0f 1f 40 00          	nopl   0x0(%rax)
   1c678:	4d 89 c1             	mov    %r8,%r9
   1c67b:	48 8b 3d b6 a6 02 00 	mov    0x2a6b6(%rip),%rdi        # 46d38 <pluginlib::ClassLoader<nav2_core::Controller>::createUniqueInstance(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&)::__rcutils_logging_location@@Base-0x998>
   1c682:	31 c0                	xor    %eax,%eax
   1c684:	4c 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%r8
   1c68b:	00 
   1c68c:	48 8d 0d 1d cb 01 00 	lea    0x1cb1d(%rip),%rcx        # 391b0 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3010>
   1c693:	48 8d 15 6a ca 01 00 	lea    0x1ca6a(%rip),%rdx        # 39104 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2f64>
   1c69a:	be 0a 00 00 00       	mov    $0xa,%esi
   1c69f:	e8 3c 39 ff ff       	call   ffe0 <rcutils_log@plt>
   1c6a4:	4c 8b 84 24 10 01 00 	mov    0x110(%rsp),%r8
   1c6ab:	00 
   1c6ac:	e9 85 fe ff ff       	jmp    1c536 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1366>
   1c6b1:	4c 89 fe             	mov    %r15,%rsi
   1c6b4:	4c 89 e7             	mov    %r12,%rdi
   1c6b7:	e8 74 31 00 00       	call   1f830 <std::_Function_handler<rcl_interfaces::msg::SetParametersResult_<std::allocator<void> > (std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> > const&), std::_Bind<rcl_interfaces::msg::SetParametersResult_<std::allocator<void> > (nav2_rotation_shim_controller::RotationShimController::*(nav2_rotation_shim_controller::RotationShimController*, std::_Placeholder<1>))(std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> >)> >::_M_invoke(std::_Any_data const&, std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> > const&)@@Base+0x1040>
   1c6bc:	e9 f6 fd ff ff       	jmp    1c4b7 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x12e7>
   1c6c1:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
   1c6c8:	00 
   1c6c9:	4d 8b 7d 00          	mov    0x0(%r13),%r15
   1c6cd:	48 85 ff             	test   %rdi,%rdi
   1c6d0:	0f 85 8e 0d 00 00    	jne    1d464 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2294>
   1c6d6:	4d 85 ff             	test   %r15,%r15
   1c6d9:	0f 84 6d ff ff ff    	je     1c64c <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x147c>
   1c6df:	e8 1c 39 ff ff       	call   10000 <class_loader::ClassLoader::hasUnmanagedInstanceBeenCreated()@plt>
   1c6e4:	84 c0                	test   %al,%al
   1c6e6:	0f 85 4d 08 00 00    	jne    1cf39 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1d69>
   1c6ec:	4c 89 ff             	mov    %r15,%rdi
   1c6ef:	e8 bc 37 ff ff       	call   feb0 <class_loader::ClassLoader::isLibraryLoaded() const@plt>
   1c6f4:	84 c0                	test   %al,%al
   1c6f6:	0f 84 78 08 00 00    	je     1cf74 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1da4>
   1c6fc:	e8 ef 36 ff ff       	call   fdf0 <class_loader::impl::getPluginBaseToFactoryMapMapMutex()@plt>
   1c701:	48 89 c7             	mov    %rax,%rdi
   1c704:	e8 57 3b ff ff       	call   10260 <pthread_mutex_lock@plt>
   1c709:	85 c0                	test   %eax,%eax
   1c70b:	0f 85 91 0d 00 00    	jne    1d4a2 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x22d2>
   1c711:	e8 2a 23 00 00       	call   1ea40 <std::_Function_handler<rcl_interfaces::msg::SetParametersResult_<std::allocator<void> > (std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> > const&), std::_Bind<rcl_interfaces::msg::SetParametersResult_<std::allocator<void> > (nav2_rotation_shim_controller::RotationShimController::*(nav2_rotation_shim_controller::RotationShimController*, std::_Placeholder<1>))(std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> >)> >::_M_invoke(std::_Any_data const&, std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> > const&)@@Base+0x250>
   1c716:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   1c71b:	4c 8d 60 08          	lea    0x8(%rax),%r12
   1c71f:	48 89 c7             	mov    %rax,%rdi
   1c722:	49 89 c5             	mov    %rax,%r13
   1c725:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   1c72a:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
   1c72f:	e8 0c 25 00 00       	call   1ec40 <std::_Function_handler<rcl_interfaces::msg::SetParametersResult_<std::allocator<void> > (std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> > const&), std::_Bind<rcl_interfaces::msg::SetParametersResult_<std::allocator<void> > (nav2_rotation_shim_controller::RotationShimController::*(nav2_rotation_shim_controller::RotationShimController*, std::_Placeholder<1>))(std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> >)> >::_M_invoke(std::_Any_data const&, std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> > const&)@@Base+0x450>
   1c734:	4c 89 e1             	mov    %r12,%rcx
   1c737:	49 39 c4             	cmp    %rax,%r12
   1c73a:	0f 84 6c 07 00 00    	je     1ceac <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1cdc>
   1c740:	4d 8b 45 10          	mov    0x10(%r13),%r8
   1c744:	4d 85 c0             	test   %r8,%r8
   1c747:	0f 84 fb 0c 00 00    	je     1d448 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2278>
   1c74d:	4c 8b ac 24 18 01 00 	mov    0x118(%rsp),%r13
   1c754:	00 
   1c755:	48 89 5c 24 78       	mov    %rbx,0x78(%rsp)
   1c75a:	48 89 cb             	mov    %rcx,%rbx
   1c75d:	48 89 ac 24 80 00 00 	mov    %rbp,0x80(%rsp)
   1c764:	00 
   1c765:	4c 8b a4 24 10 01 00 	mov    0x110(%rsp),%r12
   1c76c:	00 
   1c76d:	4c 89 ed             	mov    %r13,%rbp
   1c770:	4c 89 b4 24 88 00 00 	mov    %r14,0x88(%rsp)
   1c777:	00 
   1c778:	4d 89 c5             	mov    %r8,%r13
   1c77b:	eb 0c                	jmp    1c789 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x15b9>
   1c77d:	0f 1f 00             	nopl   (%rax)
   1c780:	4d 8b 6d 18          	mov    0x18(%r13),%r13
   1c784:	4d 85 ed             	test   %r13,%r13
   1c787:	74 54                	je     1c7dd <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x160d>
   1c789:	4d 8b 75 28          	mov    0x28(%r13),%r14
   1c78d:	48 89 ea             	mov    %rbp,%rdx
   1c790:	49 8b 7d 20          	mov    0x20(%r13),%rdi
   1c794:	49 39 ee             	cmp    %rbp,%r14
   1c797:	49 0f 46 d6          	cmovbe %r14,%rdx
   1c79b:	48 85 d2             	test   %rdx,%rdx
   1c79e:	74 0c                	je     1c7ac <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x15dc>
   1c7a0:	4c 89 e6             	mov    %r12,%rsi
   1c7a3:	e8 18 35 ff ff       	call   fcc0 <memcmp@plt>
   1c7a8:	85 c0                	test   %eax,%eax
   1c7aa:	75 21                	jne    1c7cd <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x15fd>
   1c7ac:	4c 89 f1             	mov    %r14,%rcx
   1c7af:	b8 00 00 00 80       	mov    $0x80000000,%eax
   1c7b4:	48 29 e9             	sub    %rbp,%rcx
   1c7b7:	48 39 c1             	cmp    %rax,%rcx
   1c7ba:	7d 15                	jge    1c7d1 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1601>
   1c7bc:	48 b8 ff ff ff 7f ff 	movabs $0xffffffff7fffffff,%rax
   1c7c3:	ff ff ff 
   1c7c6:	48 39 c1             	cmp    %rax,%rcx
   1c7c9:	7e b5                	jle    1c780 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x15b0>
   1c7cb:	89 c8                	mov    %ecx,%eax
   1c7cd:	85 c0                	test   %eax,%eax
   1c7cf:	78 af                	js     1c780 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x15b0>
   1c7d1:	4c 89 eb             	mov    %r13,%rbx
   1c7d4:	4d 8b 6d 10          	mov    0x10(%r13),%r13
   1c7d8:	4d 85 ed             	test   %r13,%r13
   1c7db:	75 ac                	jne    1c789 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x15b9>
   1c7dd:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   1c7e2:	49 89 ed             	mov    %rbp,%r13
   1c7e5:	48 89 d8             	mov    %rbx,%rax
   1c7e8:	48 8b ac 24 80 00 00 	mov    0x80(%rsp),%rbp
   1c7ef:	00 
   1c7f0:	48 8b 5c 24 78       	mov    0x78(%rsp),%rbx
   1c7f5:	4c 8b b4 24 88 00 00 	mov    0x88(%rsp),%r14
   1c7fc:	00 
   1c7fd:	48 39 44 24 68       	cmp    %rax,0x68(%rsp)
   1c802:	74 39                	je     1c83d <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x166d>
   1c804:	48 8b 48 28          	mov    0x28(%rax),%rcx
   1c808:	4c 89 ea             	mov    %r13,%rdx
   1c80b:	48 8b 70 20          	mov    0x20(%rax),%rsi
   1c80f:	4c 39 e9             	cmp    %r13,%rcx
   1c812:	48 0f 46 d1          	cmovbe %rcx,%rdx
   1c816:	48 85 d2             	test   %rdx,%rdx
   1c819:	0f 84 d9 00 00 00    	je     1c8f8 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1728>
   1c81f:	4c 89 e7             	mov    %r12,%rdi
   1c822:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
   1c827:	e8 94 34 ff ff       	call   fcc0 <memcmp@plt>
   1c82c:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
   1c831:	85 c0                	test   %eax,%eax
   1c833:	0f 84 bf 00 00 00    	je     1c8f8 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1728>
   1c839:	85 c0                	test   %eax,%eax
   1c83b:	79 29                	jns    1c866 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1696>
   1c83d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   1c842:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
   1c847:	48 8d 94 24 98 00 00 	lea    0x98(%rsp),%rdx
   1c84e:	00 
   1c84f:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
   1c854:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
   1c85b:	00 
   1c85c:	e8 1f a6 01 00       	call   36e80 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xce0>
   1c861:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   1c866:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   1c86b:	48 8b 78 40          	mov    0x40(%rax),%rdi
   1c86f:	48 85 ff             	test   %rdi,%rdi
   1c872:	0f 84 5b 06 00 00    	je     1ced3 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1d03>
   1c878:	48 8b 15 d9 a4 02 00 	mov    0x2a4d9(%rip),%rdx        # 46d58 <typeinfo for class_loader::impl::AbstractMetaObject<nav2_core::Controller>@@Base+0x8b8>
   1c87f:	48 8b 35 ba a6 02 00 	mov    0x2a6ba(%rip),%rsi        # 46f40 <typeinfo for class_loader::impl::AbstractMetaObjectBase@@Base+0xa88>
   1c886:	31 c9                	xor    %ecx,%ecx
   1c888:	e8 03 38 ff ff       	call   10090 <__dynamic_cast@plt>
   1c88d:	49 89 c4             	mov    %rax,%r12
   1c890:	e8 5b 35 ff ff       	call   fdf0 <class_loader::impl::getPluginBaseToFactoryMapMapMutex()@plt>
   1c895:	48 89 c7             	mov    %rax,%rdi
   1c898:	e8 f3 35 ff ff       	call   fe90 <pthread_mutex_unlock@plt>
   1c89d:	4d 85 e4             	test   %r12,%r12
   1c8a0:	0f 84 3a 06 00 00    	je     1cee0 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1d10>
   1c8a6:	4c 89 fe             	mov    %r15,%rsi
   1c8a9:	4c 89 e7             	mov    %r12,%rdi
   1c8ac:	e8 ef 3a ff ff       	call   103a0 <class_loader::impl::AbstractMetaObjectBase::isOwnedBy(class_loader::ClassLoader const*) const@plt>
   1c8b1:	84 c0                	test   %al,%al
   1c8b3:	74 6b                	je     1c920 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1750>
   1c8b5:	49 8b 04 24          	mov    (%r12),%rax
   1c8b9:	48 8d 15 20 a1 01 00 	lea    0x1a120(%rip),%rdx        # 369e0 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x840>
   1c8c0:	48 8b 40 08          	mov    0x8(%rax),%rax
   1c8c4:	48 39 d0             	cmp    %rdx,%rax
   1c8c7:	0f 85 8a 0b 00 00    	jne    1d457 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2287>
   1c8cd:	bf 20 02 00 00       	mov    $0x220,%edi
   1c8d2:	e8 b9 36 ff ff       	call   ff90 <operator new(unsigned long)@plt>
   1c8d7:	48 89 c7             	mov    %rax,%rdi
   1c8da:	49 89 c5             	mov    %rax,%r13
   1c8dd:	e8 7e 36 ff ff       	call   ff60 <nav2_rotation_shim_controller::RotationShimController::RotationShimController()@plt>
   1c8e2:	4d 85 ed             	test   %r13,%r13
   1c8e5:	74 39                	je     1c920 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1750>
   1c8e7:	48 8d 05 a2 d7 01 00 	lea    0x1d7a2(%rip),%rax        # 3a090 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3ef0>
   1c8ee:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   1c8f3:	e9 92 00 00 00       	jmp    1c98a <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x17ba>
   1c8f8:	4d 89 e9             	mov    %r13,%r9
   1c8fb:	49 29 c9             	sub    %rcx,%r9
   1c8fe:	49 81 f9 ff ff ff 7f 	cmp    $0x7fffffff,%r9
   1c905:	0f 8f 5b ff ff ff    	jg     1c866 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1696>
   1c90b:	49 81 f9 00 00 00 80 	cmp    $0xffffffff80000000,%r9
   1c912:	0f 8c 25 ff ff ff    	jl     1c83d <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x166d>
   1c918:	44 89 c8             	mov    %r9d,%eax
   1c91b:	e9 19 ff ff ff       	jmp    1c839 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1669>
   1c920:	31 f6                	xor    %esi,%esi
   1c922:	4c 89 e7             	mov    %r12,%rdi
   1c925:	e8 76 3a ff ff       	call   103a0 <class_loader::impl::AbstractMetaObjectBase::isOwnedBy(class_loader::ClassLoader const*) const@plt>
   1c92a:	84 c0                	test   %al,%al
   1c92c:	0f 84 ae 05 00 00    	je     1cee0 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1d10>
   1c932:	48 8d 05 57 d7 01 00 	lea    0x1d757(%rip),%rax        # 3a090 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3ef0>
   1c939:	4c 8d 05 c0 d7 01 00 	lea    0x1d7c0(%rip),%r8        # 3a100 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3f60>
   1c940:	31 d2                	xor    %edx,%edx
   1c942:	be 2e 01 00 00       	mov    $0x12e,%esi
   1c947:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   1c94c:	48 89 c7             	mov    %rax,%rdi
   1c94f:	48 8d 0d 75 c8 01 00 	lea    0x1c875(%rip),%rcx        # 391cb <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x302b>
   1c956:	31 c0                	xor    %eax,%eax
   1c958:	e8 33 39 ff ff       	call   10290 <console_bridge::log(char const*, int, console_bridge::LogLevel, char const*, ...)@plt>
   1c95d:	49 8b 04 24          	mov    (%r12),%rax
   1c961:	48 8d 15 78 a0 01 00 	lea    0x1a078(%rip),%rdx        # 369e0 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x840>
   1c968:	48 8b 40 08          	mov    0x8(%rax),%rax
   1c96c:	48 39 d0             	cmp    %rdx,%rax
   1c96f:	0f 85 54 08 00 00    	jne    1d1c9 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1ff9>
   1c975:	bf 20 02 00 00       	mov    $0x220,%edi
   1c97a:	e8 11 36 ff ff       	call   ff90 <operator new(unsigned long)@plt>
   1c97f:	48 89 c7             	mov    %rax,%rdi
   1c982:	49 89 c5             	mov    %rax,%r13
   1c985:	e8 d6 35 ff ff       	call   ff60 <nav2_rotation_shim_controller::RotationShimController::RotationShimController()@plt>
   1c98a:	4c 8b 05 df a4 02 00 	mov    0x2a4df(%rip),%r8        # 46e70 <typeinfo name for nav2_core::Controller*@@Base+0xc310>
   1c991:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
   1c996:	31 d2                	xor    %edx,%edx
   1c998:	31 c0                	xor    %eax,%eax
   1c99a:	4d 89 e9             	mov    %r13,%r9
   1c99d:	48 8d 0d 6c d9 01 00 	lea    0x1d96c(%rip),%rcx        # 3a310 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x4170>
   1c9a4:	be 41 01 00 00       	mov    $0x141,%esi
   1c9a9:	e8 e2 38 ff ff       	call   10290 <console_bridge::log(char const*, int, console_bridge::LogLevel, char const*, ...)@plt>
   1c9ae:	4d 8d 67 68          	lea    0x68(%r15),%r12
   1c9b2:	4c 89 e7             	mov    %r12,%rdi
   1c9b5:	e8 a6 38 ff ff       	call   10260 <pthread_mutex_lock@plt>
   1c9ba:	85 c0                	test   %eax,%eax
   1c9bc:	0f 85 b7 0a 00 00    	jne    1d479 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x22a9>
   1c9c2:	41 83 47 60 01       	addl   $0x1,0x60(%r15)
   1c9c7:	4c 89 e7             	mov    %r12,%rdi
   1c9ca:	e8 c1 34 ff ff       	call   fe90 <pthread_mutex_unlock@plt>
   1c9cf:	66 0f ef c0          	pxor   %xmm0,%xmm0
   1c9d3:	bf 18 00 00 00       	mov    $0x18,%edi
   1c9d8:	48 c7 84 24 20 0d 00 	movq   $0x0,0xd20(%rsp)
   1c9df:	00 00 00 00 00 
   1c9e4:	48 c7 84 24 28 0d 00 	movq   $0x0,0xd28(%rsp)
   1c9eb:	00 00 00 00 00 
   1c9f0:	0f 29 84 24 10 0d 00 	movaps %xmm0,0xd10(%rsp)
   1c9f7:	00 
   1c9f8:	e8 93 35 ff ff       	call   ff90 <operator new(unsigned long)@plt>
   1c9fd:	48 8b 15 a4 a4 02 00 	mov    0x2a4a4(%rip),%rdx        # 46ea8 <void class_loader::ClassLoader::onPluginDeletion<nav2_core::Controller>(nav2_core::Controller*)@@Base+0x287d8>
   1ca04:	48 89 84 24 10 0d 00 	mov    %rax,0xd10(%rsp)
   1ca0b:	00 
   1ca0c:	66 0f 6f 8c 24 10 0d 	movdqa 0xd10(%rsp),%xmm1
   1ca13:	00 00 
   1ca15:	48 c7 40 08 00 00 00 	movq   $0x0,0x8(%rax)
   1ca1c:	00 
   1ca1d:	48 89 10             	mov    %rdx,(%rax)
   1ca20:	4c 89 78 10          	mov    %r15,0x10(%rax)
   1ca24:	48 8b 05 15 a4 02 00 	mov    0x2a415(%rip),%rax        # 46e40 <std::_Function_handler<void (nav2_core::Controller*), std::_Bind<void (class_loader::ClassLoader::*(class_loader::ClassLoader*, std::_Placeholder<1>))(nav2_core::Controller*)> >::_M_invoke(std::_Any_data const&, nav2_core::Controller*&&)@@Base+0x294f0>
   1ca2b:	4c 89 ac 24 30 05 00 	mov    %r13,0x530(%rsp)
   1ca32:	00 
   1ca33:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
   1ca3a:	00 
   1ca3b:	48 8b 05 c6 a1 02 00 	mov    0x2a1c6(%rip),%rax        # 46c08 <std::_Function_handler<void (nav2_core::Controller*), std::_Bind<void (class_loader::ClassLoader::*(class_loader::ClassLoader*, std::_Placeholder<1>))(nav2_core::Controller*)> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x29048>
   1ca42:	0f 29 8c 24 10 05 00 	movaps %xmm1,0x510(%rsp)
   1ca49:	00 
   1ca4a:	48 89 84 24 20 05 00 	mov    %rax,0x520(%rsp)
   1ca51:	00 
   1ca52:	48 8b 05 87 a1 02 00 	mov    0x2a187(%rip),%rax        # 46be0 <g_rcutils_logging_initialized@Base>
   1ca59:	80 38 00             	cmpb   $0x0,(%rax)
   1ca5c:	0f 84 4d 08 00 00    	je     1d2af <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x20df>
   1ca62:	be 0a 00 00 00       	mov    $0xa,%esi
   1ca67:	48 8d 3d 96 c6 01 00 	lea    0x1c696(%rip),%rdi        # 39104 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2f64>
   1ca6e:	e8 7d 34 ff ff       	call   fef0 <rcutils_logging_logger_is_enabled_for@plt>
   1ca73:	84 c0                	test   %al,%al
   1ca75:	74 29                	je     1caa0 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x18d0>
   1ca77:	4c 8b 84 24 10 01 00 	mov    0x110(%rsp),%r8
   1ca7e:	00 
   1ca7f:	48 8b 3d 5a a5 02 00 	mov    0x2a55a(%rip),%rdi        # 46fe0 <pluginlib::ClassLoader<nav2_core::Controller>::createUniqueInstance(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&)::__rcutils_logging_location@@Base-0x6d0>
   1ca86:	31 c0                	xor    %eax,%eax
   1ca88:	48 8d 0d 39 d9 01 00 	lea    0x1d939(%rip),%rcx        # 3a3c8 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x4228>
   1ca8f:	48 8d 15 6e c6 01 00 	lea    0x1c66e(%rip),%rdx        # 39104 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2f64>
   1ca96:	be 0a 00 00 00       	mov    $0xa,%esi
   1ca9b:	e8 40 35 ff ff       	call   ffe0 <rcutils_log@plt>
   1caa0:	48 8b 84 24 28 05 00 	mov    0x528(%rsp),%rax
   1caa7:	00 
   1caa8:	66 0f ef c0          	pxor   %xmm0,%xmm0
   1caac:	48 c7 84 24 20 0d 00 	movq   $0x0,0xd20(%rsp)
   1cab3:	00 00 00 00 00 
   1cab8:	0f 29 84 24 10 0d 00 	movaps %xmm0,0xd10(%rsp)
   1cabf:	00 
   1cac0:	48 89 84 24 28 0d 00 	mov    %rax,0xd28(%rsp)
   1cac7:	00 
   1cac8:	48 8b 84 24 20 05 00 	mov    0x520(%rsp),%rax
   1cacf:	00 
   1cad0:	48 85 c0             	test   %rax,%rax
   1cad3:	0f 84 d3 05 00 00    	je     1d0ac <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1edc>
   1cad9:	48 89 84 24 20 0d 00 	mov    %rax,0xd20(%rsp)
   1cae0:	00 
   1cae1:	48 8b 84 24 30 05 00 	mov    0x530(%rsp),%rax
   1cae8:	00 
   1cae9:	66 0f 6f 94 24 10 05 	movdqa 0x510(%rsp),%xmm2
   1caf0:	00 00 
   1caf2:	48 89 84 24 30 0d 00 	mov    %rax,0xd30(%rsp)
   1caf9:	00 
   1cafa:	0f 29 94 24 10 0d 00 	movaps %xmm2,0xd10(%rsp)
   1cb01:	00 
   1cb02:	48 8b bc 24 10 01 00 	mov    0x110(%rsp),%rdi
   1cb09:	00 
   1cb0a:	48 8d 84 24 20 01 00 	lea    0x120(%rsp),%rax
   1cb11:	00 
   1cb12:	48 39 c7             	cmp    %rax,%rdi
   1cb15:	74 11                	je     1cb28 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1958>
   1cb17:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
   1cb1e:	00 
   1cb1f:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1cb23:	e8 98 34 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1cb28:	4c 8b a4 24 30 0d 00 	mov    0xd30(%rsp),%r12
   1cb2f:	00 
   1cb30:	4d 85 e4             	test   %r12,%r12
   1cb33:	0f 84 6b 05 00 00    	je     1d0a4 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1ed4>
   1cb39:	bf 38 00 00 00       	mov    $0x38,%edi
   1cb3e:	e8 4d 34 ff ff       	call   ff90 <operator new(unsigned long)@plt>
   1cb43:	49 89 c5             	mov    %rax,%r13
   1cb46:	48 8b 94 24 20 0d 00 	mov    0xd20(%rsp),%rdx
   1cb4d:	00 
   1cb4e:	48 8b 84 24 28 0d 00 	mov    0xd28(%rsp),%rax
   1cb55:	00 
   1cb56:	66 0f ef c0          	pxor   %xmm0,%xmm0
   1cb5a:	48 8b 8c 24 30 0d 00 	mov    0xd30(%rsp),%rcx
   1cb61:	00 
   1cb62:	0f 29 84 24 10 05 00 	movaps %xmm0,0x510(%rsp)
   1cb69:	00 
   1cb6a:	48 c7 84 24 30 0d 00 	movq   $0x0,0xd30(%rsp)
   1cb71:	00 00 00 00 00 
   1cb76:	48 c7 84 24 20 05 00 	movq   $0x0,0x520(%rsp)
   1cb7d:	00 00 00 00 00 
   1cb82:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
   1cb89:	00 
   1cb8a:	48 85 d2             	test   %rdx,%rdx
   1cb8d:	0f 84 d7 05 00 00    	je     1d16a <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1f9a>
   1cb93:	48 be 01 00 00 00 01 	movabs $0x100000001,%rsi
   1cb9a:	00 00 00 
   1cb9d:	49 89 45 28          	mov    %rax,0x28(%r13)
   1cba1:	66 0f 6f 84 24 10 0d 	movdqa 0xd10(%rsp),%xmm0
   1cba8:	00 00 
   1cbaa:	49 89 75 08          	mov    %rsi,0x8(%r13)
   1cbae:	48 8d 35 f3 95 02 00 	lea    0x295f3(%rip),%rsi        # 461a8 <std::_Sp_make_shared_tag::_S_ti()::__tag@@Base+0x8558>
   1cbb5:	48 c7 84 24 20 0d 00 	movq   $0x0,0xd20(%rsp)
   1cbbc:	00 00 00 00 00 
   1cbc1:	48 c7 84 24 28 0d 00 	movq   $0x0,0xd28(%rsp)
   1cbc8:	00 00 00 00 00 
   1cbcd:	49 89 75 00          	mov    %rsi,0x0(%r13)
   1cbd1:	48 c7 84 24 28 05 00 	movq   $0x0,0x528(%rsp)
   1cbd8:	00 00 00 00 00 
   1cbdd:	49 89 55 20          	mov    %rdx,0x20(%r13)
   1cbe1:	48 c7 84 24 20 09 00 	movq   $0x0,0x920(%rsp)
   1cbe8:	00 00 00 00 00 
   1cbed:	48 c7 84 24 28 09 00 	movq   $0x0,0x928(%rsp)
   1cbf4:	00 00 00 00 00 
   1cbf9:	0f 29 84 24 10 05 00 	movaps %xmm0,0x510(%rsp)
   1cc00:	00 
   1cc01:	0f 29 84 24 10 09 00 	movaps %xmm0,0x910(%rsp)
   1cc08:	00 
   1cc09:	41 0f 11 45 10       	movups %xmm0,0x10(%r13)
   1cc0e:	49 89 4d 30          	mov    %rcx,0x30(%r13)
   1cc12:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   1cc17:	e8 84 94 ff ff       	call   160a0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x330>
   1cc1c:	4c 89 f7             	mov    %r14,%rdi
   1cc1f:	e8 7c 94 ff ff       	call   160a0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x330>
   1cc24:	48 8b 05 4d a2 02 00 	mov    0x2a24d(%rip),%rax        # 46e78 <__libc_single_threaded@GLIBC_2.32>
   1cc2b:	80 38 00             	cmpb   $0x0,(%rax)
   1cc2e:	0f 84 ea 05 00 00    	je     1d21e <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x204e>
   1cc34:	41 83 45 08 01       	addl   $0x1,0x8(%r13)
   1cc39:	4c 89 ef             	mov    %r13,%rdi
   1cc3c:	e8 9f 98 ff ff       	call   164e0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x770>
   1cc41:	48 8b bb 48 01 00 00 	mov    0x148(%rbx),%rdi
   1cc48:	4c 89 a3 40 01 00 00 	mov    %r12,0x140(%rbx)
   1cc4f:	4c 89 ab 48 01 00 00 	mov    %r13,0x148(%rbx)
   1cc56:	48 85 ff             	test   %rdi,%rdi
   1cc59:	74 05                	je     1cc60 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1a90>
   1cc5b:	e8 80 98 ff ff       	call   164e0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x770>
   1cc60:	48 8b 94 24 30 0d 00 	mov    0xd30(%rsp),%rdx
   1cc67:	00 
   1cc68:	48 8b 84 24 20 0d 00 	mov    0xd20(%rsp),%rax
   1cc6f:	00 
   1cc70:	48 85 d2             	test   %rdx,%rdx
   1cc73:	74 28                	je     1cc9d <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1acd>
   1cc75:	48 89 94 24 d0 00 00 	mov    %rdx,0xd0(%rsp)
   1cc7c:	00 
   1cc7d:	48 85 c0             	test   %rax,%rax
   1cc80:	0f 84 17 08 00 00    	je     1d49d <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x22cd>
   1cc86:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   1cc8b:	48 89 ef             	mov    %rbp,%rdi
   1cc8e:	ff 94 24 28 0d 00 00 	call   *0xd28(%rsp)
   1cc95:	48 8b 84 24 20 0d 00 	mov    0xd20(%rsp),%rax
   1cc9c:	00 
   1cc9d:	48 c7 84 24 30 0d 00 	movq   $0x0,0xd30(%rsp)
   1cca4:	00 00 00 00 00 
   1cca9:	48 85 c0             	test   %rax,%rax
   1ccac:	74 0d                	je     1ccbb <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1aeb>
   1ccae:	ba 03 00 00 00       	mov    $0x3,%edx
   1ccb3:	48 89 ee             	mov    %rbp,%rsi
   1ccb6:	48 89 ef             	mov    %rbp,%rdi
   1ccb9:	ff d0                	call   *%rax
   1ccbb:	48 8b 05 1e 9f 02 00 	mov    0x29f1e(%rip),%rax        # 46be0 <g_rcutils_logging_initialized@Base>
   1ccc2:	80 38 00             	cmpb   $0x0,(%rax)
   1ccc5:	0f 84 5e 05 00 00    	je     1d229 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2059>
   1cccb:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
   1cccf:	48 85 ff             	test   %rdi,%rdi
   1ccd2:	74 03                	je     1ccd7 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1b07>
   1ccd4:	48 8b 3f             	mov    (%rdi),%rdi
   1ccd7:	be 14 00 00 00       	mov    $0x14,%esi
   1ccdc:	e8 0f 32 ff ff       	call   fef0 <rcutils_logging_logger_is_enabled_for@plt>
   1cce1:	84 c0                	test   %al,%al
   1cce3:	74 32                	je     1cd17 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1b47>
   1cce5:	48 8b 53 48          	mov    0x48(%rbx),%rdx
   1cce9:	4c 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%r9
   1ccf0:	00 
   1ccf1:	4c 8b 43 28          	mov    0x28(%rbx),%r8
   1ccf5:	48 85 d2             	test   %rdx,%rdx
   1ccf8:	74 03                	je     1ccfd <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1b2d>
   1ccfa:	48 8b 12             	mov    (%rdx),%rdx
   1ccfd:	48 8d 0d 34 d8 01 00 	lea    0x1d834(%rip),%rcx        # 3a538 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x4398>
   1cd04:	be 14 00 00 00       	mov    $0x14,%esi
   1cd09:	48 8d 3d 20 aa 02 00 	lea    0x2aa20(%rip),%rdi        # 47730 <pluginlib::ClassLoader<nav2_core::Controller>::createUniqueInstance(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&)::__rcutils_logging_location@@Base+0x40>
   1cd10:	31 c0                	xor    %eax,%eax
   1cd12:	e8 c9 32 ff ff       	call   ffe0 <rcutils_log@plt>
   1cd17:	4c 8b a3 40 01 00 00 	mov    0x140(%rbx),%r12
   1cd1e:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   1cd23:	49 8b 04 24          	mov    (%r12),%rax
   1cd27:	4c 8b 68 10          	mov    0x10(%rax),%r13
   1cd2b:	48 8b 01             	mov    (%rcx),%rax
   1cd2e:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   1cd35:	00 
   1cd36:	48 8b 41 08          	mov    0x8(%rcx),%rax
   1cd3a:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
   1cd41:	00 
   1cd42:	48 85 c0             	test   %rax,%rax
   1cd45:	74 14                	je     1cd5b <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1b8b>
   1cd47:	48 8b 15 2a a1 02 00 	mov    0x2a12a(%rip),%rdx        # 46e78 <__libc_single_threaded@GLIBC_2.32>
   1cd4e:	80 3a 00             	cmpb   $0x0,(%rdx)
   1cd51:	0f 84 68 04 00 00    	je     1d1bf <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1fef>
   1cd57:	83 40 08 01          	addl   $0x1,0x8(%rax)
   1cd5b:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   1cd60:	48 8b 01             	mov    (%rcx),%rax
   1cd63:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
   1cd6a:	00 
   1cd6b:	48 8b 41 08          	mov    0x8(%rcx),%rax
   1cd6f:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
   1cd76:	00 
   1cd77:	48 85 c0             	test   %rax,%rax
   1cd7a:	74 14                	je     1cd90 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1bc0>
   1cd7c:	48 8b 15 f5 a0 02 00 	mov    0x2a0f5(%rip),%rdx        # 46e78 <__libc_single_threaded@GLIBC_2.32>
   1cd83:	80 3a 00             	cmpb   $0x0,(%rdx)
   1cd86:	0f 84 29 04 00 00    	je     1d1b5 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1fe5>
   1cd8c:	83 40 08 01          	addl   $0x1,0x8(%rax)
   1cd90:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   1cd95:	4c 8b 74 24 18       	mov    0x18(%rsp),%r14
   1cd9a:	48 89 ef             	mov    %rbp,%rdi
   1cd9d:	48 8b 30             	mov    (%rax),%rsi
   1cda0:	48 8b 50 08          	mov    0x8(%rax),%rdx
   1cda4:	4c 89 b4 24 10 0d 00 	mov    %r14,0xd10(%rsp)
   1cdab:	00 
   1cdac:	48 01 f2             	add    %rsi,%rdx
   1cdaf:	e8 4c 9e 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1cdb4:	4c 8b 44 24 58       	mov    0x58(%rsp),%r8
   1cdb9:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
   1cdbe:	48 89 ea             	mov    %rbp,%rdx
   1cdc1:	4c 89 e7             	mov    %r12,%rdi
   1cdc4:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
   1cdc9:	41 ff d5             	call   *%r13
   1cdcc:	48 8b bc 24 10 0d 00 	mov    0xd10(%rsp),%rdi
   1cdd3:	00 
   1cdd4:	4c 39 f7             	cmp    %r14,%rdi
   1cdd7:	74 11                	je     1cdea <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1c1a>
   1cdd9:	48 8b 84 24 20 0d 00 	mov    0xd20(%rsp),%rax
   1cde0:	00 
   1cde1:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1cde5:	e8 d6 31 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1cdea:	48 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%rdi
   1cdf1:	00 
   1cdf2:	48 85 ff             	test   %rdi,%rdi
   1cdf5:	74 05                	je     1cdfc <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1c2c>
   1cdf7:	e8 e4 96 ff ff       	call   164e0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x770>
   1cdfc:	48 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%rdi
   1ce03:	00 
   1ce04:	48 85 ff             	test   %rdi,%rdi
   1ce07:	74 05                	je     1ce0e <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1c3e>
   1ce09:	e8 d2 96 ff ff       	call   164e0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x770>
   1ce0e:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   1ce13:	bf 08 00 00 00       	mov    $0x8,%edi
   1ce18:	48 8b 00             	mov    (%rax),%rax
   1ce1b:	4c 8b a0 d8 03 00 00 	mov    0x3d8(%rax),%r12
   1ce22:	49 83 c4 40          	add    $0x40,%r12
   1ce26:	e8 65 31 ff ff       	call   ff90 <operator new(unsigned long)@plt>
   1ce2b:	4c 89 e6             	mov    %r12,%rsi
   1ce2e:	48 89 c7             	mov    %rax,%rdi
   1ce31:	48 89 c5             	mov    %rax,%rbp
   1ce34:	e8 67 30 ff ff       	call   fea0 <nav2_costmap_2d::FootprintCollisionChecker<nav2_costmap_2d::Costmap2D*>::FootprintCollisionChecker(nav2_costmap_2d::Costmap2D*)@plt>
   1ce39:	48 8b 7b 78          	mov    0x78(%rbx),%rdi
   1ce3d:	48 89 6b 78          	mov    %rbp,0x78(%rbx)
   1ce41:	48 85 ff             	test   %rdi,%rdi
   1ce44:	74 0a                	je     1ce50 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1c80>
   1ce46:	be 08 00 00 00       	mov    $0x8,%esi
   1ce4b:	e8 70 31 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1ce50:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
   1ce57:	00 
   1ce58:	48 3b 7c 24 60       	cmp    0x60(%rsp),%rdi
   1ce5d:	74 11                	je     1ce70 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1ca0>
   1ce5f:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
   1ce66:	00 
   1ce67:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1ce6b:	e8 50 31 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1ce70:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   1ce75:	0f 84 95 00 00 00    	je     1cf10 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1d40>
   1ce7b:	48 8b 84 24 18 11 00 	mov    0x1118(%rsp),%rax
   1ce82:	00 
   1ce83:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
   1ce8a:	00 00 
   1ce8c:	0f 85 fa 05 00 00    	jne    1d48c <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x22bc>
   1ce92:	48 8b 3c 24          	mov    (%rsp),%rdi
   1ce96:	48 81 c4 28 11 00 00 	add    $0x1128,%rsp
   1ce9d:	5b                   	pop    %rbx
   1ce9e:	5d                   	pop    %rbp
   1ce9f:	41 5c                	pop    %r12
   1cea1:	41 5d                	pop    %r13
   1cea3:	41 5e                	pop    %r14
   1cea5:	41 5f                	pop    %r15
   1cea7:	e9 34 96 ff ff       	jmp    164e0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x770>
   1ceac:	4c 8b 84 24 10 01 00 	mov    0x110(%rsp),%r8
   1ceb3:	00 
   1ceb4:	48 8d 0d 95 d1 01 00 	lea    0x1d195(%rip),%rcx        # 3a050 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3eb0>
   1cebb:	31 c0                	xor    %eax,%eax
   1cebd:	ba 03 00 00 00       	mov    $0x3,%edx
   1cec2:	be 22 01 00 00       	mov    $0x122,%esi
   1cec7:	48 8d 3d c2 d1 01 00 	lea    0x1d1c2(%rip),%rdi        # 3a090 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3ef0>
   1cece:	e8 bd 33 ff ff       	call   10290 <console_bridge::log(char const*, int, console_bridge::LogLevel, char const*, ...)@plt>
   1ced3:	e8 18 2f ff ff       	call   fdf0 <class_loader::impl::getPluginBaseToFactoryMapMapMutex()@plt>
   1ced8:	48 89 c7             	mov    %rax,%rdi
   1cedb:	e8 b0 2f ff ff       	call   fe90 <pthread_mutex_unlock@plt>
   1cee0:	bf 10 00 00 00       	mov    $0x10,%edi
   1cee5:	e8 16 2e ff ff       	call   fd00 <__cxa_allocate_exception@plt>
   1ceea:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
   1ceef:	48 8d 35 e2 d1 01 00 	lea    0x1d1e2(%rip),%rsi        # 3a0d8 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3f38>
   1cef6:	48 89 ef             	mov    %rbp,%rdi
   1cef9:	49 89 c7             	mov    %rax,%r15
   1cefc:	e8 6f c5 ff ff       	call   19470 <nav2_rotation_shim_controller::RotationShimController::dynamicParametersCallback(std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> >)@@Base+0xce0>
   1cf01:	e9 c9 4d ff ff       	jmp    11ccf <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x17ff>
   1cf06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   1cf0d:	00 00 00 
   1cf10:	48 8b 84 24 18 11 00 	mov    0x1118(%rsp),%rax
   1cf17:	00 
   1cf18:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
   1cf1f:	00 00 
   1cf21:	0f 85 65 05 00 00    	jne    1d48c <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x22bc>
   1cf27:	48 81 c4 28 11 00 00 	add    $0x1128,%rsp
   1cf2e:	5b                   	pop    %rbx
   1cf2f:	5d                   	pop    %rbp
   1cf30:	41 5c                	pop    %r12
   1cf32:	41 5d                	pop    %r13
   1cf34:	41 5e                	pop    %r14
   1cf36:	41 5f                	pop    %r15
   1cf38:	c3                   	ret    
   1cf39:	4c 89 ff             	mov    %r15,%rdi
   1cf3c:	e8 ef 30 ff ff       	call   10030 <class_loader::ClassLoader::isOnDemandLoadUnloadEnabled() const@plt>
   1cf41:	84 c0                	test   %al,%al
   1cf43:	0f 84 a3 f7 ff ff    	je     1c6ec <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x151c>
   1cf49:	4c 8d 05 50 cf 01 00 	lea    0x1cf50(%rip),%r8        # 39ea0 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3d00>
   1cf50:	48 8d 0d 74 c2 01 00 	lea    0x1c274(%rip),%rcx        # 391cb <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x302b>
   1cf57:	31 c0                	xor    %eax,%eax
   1cf59:	ba 01 00 00 00       	mov    $0x1,%edx
   1cf5e:	be 3a 01 00 00       	mov    $0x13a,%esi
   1cf63:	48 8d 3d 9e d0 01 00 	lea    0x1d09e(%rip),%rdi        # 3a008 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3e68>
   1cf6a:	e8 21 33 ff ff       	call   10290 <console_bridge::log(char const*, int, console_bridge::LogLevel, char const*, ...)@plt>
   1cf6f:	e9 78 f7 ff ff       	jmp    1c6ec <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x151c>
   1cf74:	4c 89 ff             	mov    %r15,%rdi
   1cf77:	e8 94 34 ff ff       	call   10410 <class_loader::ClassLoader::loadLibrary()@plt>
   1cf7c:	e9 7b f7 ff ff       	jmp    1c6fc <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x152c>
   1cf81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   1cf86:	45 31 c0             	xor    %r8d,%r8d
   1cf89:	48 89 ea             	mov    %rbp,%rdx
   1cf8c:	4c 89 f6             	mov    %r14,%rsi
   1cf8f:	4c 89 e7             	mov    %r12,%rdi
   1cf92:	e8 d9 2f ff ff       	call   ff70 <rclcpp_lifecycle::LifecycleNode::declare_parameter(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, rclcpp::ParameterValue const&, rcl_interfaces::msg::ParameterDescriptor_<std::allocator<void> > const&, bool)@plt>
   1cf97:	e9 a0 e6 ff ff       	jmp    1b63c <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x46c>
   1cf9c:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   1cfa1:	45 31 c0             	xor    %r8d,%r8d
   1cfa4:	48 89 ea             	mov    %rbp,%rdx
   1cfa7:	4c 89 f6             	mov    %r14,%rsi
   1cfaa:	4c 89 e7             	mov    %r12,%rdi
   1cfad:	e8 be 2f ff ff       	call   ff70 <rclcpp_lifecycle::LifecycleNode::declare_parameter(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, rclcpp::ParameterValue const&, rcl_interfaces::msg::ParameterDescriptor_<std::allocator<void> > const&, bool)@plt>
   1cfb2:	e9 6d e7 ff ff       	jmp    1b724 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x554>
   1cfb7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   1cfbc:	45 31 c0             	xor    %r8d,%r8d
   1cfbf:	48 89 ea             	mov    %rbp,%rdx
   1cfc2:	4c 89 f6             	mov    %r14,%rsi
   1cfc5:	4c 89 e7             	mov    %r12,%rdi
   1cfc8:	e8 a3 2f ff ff       	call   ff70 <rclcpp_lifecycle::LifecycleNode::declare_parameter(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, rclcpp::ParameterValue const&, rcl_interfaces::msg::ParameterDescriptor_<std::allocator<void> > const&, bool)@plt>
   1cfcd:	e9 c5 e9 ff ff       	jmp    1b997 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x7c7>
   1cfd2:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   1cfd7:	45 31 c0             	xor    %r8d,%r8d
   1cfda:	48 89 ea             	mov    %rbp,%rdx
   1cfdd:	4c 89 f6             	mov    %r14,%rsi
   1cfe0:	4c 89 e7             	mov    %r12,%rdi
   1cfe3:	e8 88 2f ff ff       	call   ff70 <rclcpp_lifecycle::LifecycleNode::declare_parameter(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, rclcpp::ParameterValue const&, rcl_interfaces::msg::ParameterDescriptor_<std::allocator<void> > const&, bool)@plt>
   1cfe8:	e9 8d ea ff ff       	jmp    1ba7a <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x8aa>
   1cfed:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   1cff2:	45 31 c0             	xor    %r8d,%r8d
   1cff5:	48 89 e9             	mov    %rbp,%rcx
   1cff8:	ba 04 00 00 00       	mov    $0x4,%edx
   1cffd:	4c 89 e7             	mov    %r12,%rdi
   1d000:	e8 4b 31 ff ff       	call   10150 <rclcpp_lifecycle::LifecycleNode::declare_parameter(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, rclcpp::ParameterType, rcl_interfaces::msg::ParameterDescriptor_<std::allocator<void> > const&, bool)@plt>
   1d005:	e9 2e ec ff ff       	jmp    1bc38 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xa68>
   1d00a:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   1d00f:	45 31 c0             	xor    %r8d,%r8d
   1d012:	48 89 ea             	mov    %rbp,%rdx
   1d015:	4c 89 f6             	mov    %r14,%rsi
   1d018:	4c 89 e7             	mov    %r12,%rdi
   1d01b:	e8 50 2f ff ff       	call   ff70 <rclcpp_lifecycle::LifecycleNode::declare_parameter(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, rclcpp::ParameterValue const&, rcl_interfaces::msg::ParameterDescriptor_<std::allocator<void> > const&, bool)@plt>
   1d020:	e9 54 ee ff ff       	jmp    1be79 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xca9>
   1d025:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   1d02a:	45 31 c0             	xor    %r8d,%r8d
   1d02d:	48 89 ea             	mov    %rbp,%rdx
   1d030:	4c 89 f6             	mov    %r14,%rsi
   1d033:	4c 89 e7             	mov    %r12,%rdi
   1d036:	e8 35 2f ff ff       	call   ff70 <rclcpp_lifecycle::LifecycleNode::declare_parameter(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, rclcpp::ParameterValue const&, rcl_interfaces::msg::ParameterDescriptor_<std::allocator<void> > const&, bool)@plt>
   1d03b:	e9 cb ec ff ff       	jmp    1bd0b <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xb3b>
   1d040:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   1d045:	45 31 c0             	xor    %r8d,%r8d
   1d048:	48 89 ea             	mov    %rbp,%rdx
   1d04b:	4c 89 f6             	mov    %r14,%rsi
   1d04e:	4c 89 e7             	mov    %r12,%rdi
   1d051:	e8 1a 2f ff ff       	call   ff70 <rclcpp_lifecycle::LifecycleNode::declare_parameter(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, rclcpp::ParameterValue const&, rcl_interfaces::msg::ParameterDescriptor_<std::allocator<void> > const&, bool)@plt>
   1d056:	e9 ad e7 ff ff       	jmp    1b808 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x638>
   1d05b:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   1d060:	45 31 c0             	xor    %r8d,%r8d
   1d063:	48 89 ea             	mov    %rbp,%rdx
   1d066:	4c 89 f6             	mov    %r14,%rsi
   1d069:	4c 89 e7             	mov    %r12,%rdi
   1d06c:	e8 ff 2e ff ff       	call   ff70 <rclcpp_lifecycle::LifecycleNode::declare_parameter(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, rclcpp::ParameterValue const&, rcl_interfaces::msg::ParameterDescriptor_<std::allocator<void> > const&, bool)@plt>
   1d071:	e9 eb ea ff ff       	jmp    1bb61 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x991>
   1d076:	4c 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%r8
   1d07d:	00 
   1d07e:	48 8b 3d 23 9b 02 00 	mov    0x29b23(%rip),%rdi        # 46ba8 <pluginlib::ClassLoader<nav2_core::Controller>::createUniqueInstance(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&)::__rcutils_logging_location@@Base-0xb48>
   1d085:	31 c0                	xor    %eax,%eax
   1d087:	48 8d 0d e2 cb 01 00 	lea    0x1cbe2(%rip),%rcx        # 39c70 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3ad0>
   1d08e:	48 8d 15 6f c0 01 00 	lea    0x1c06f(%rip),%rdx        # 39104 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2f64>
   1d095:	be 0a 00 00 00       	mov    $0xa,%esi
   1d09a:	e8 41 2f ff ff       	call   ffe0 <rcutils_log@plt>
   1d09f:	e9 fb f3 ff ff       	jmp    1c49f <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x12cf>
   1d0a4:	45 31 ed             	xor    %r13d,%r13d
   1d0a7:	e9 95 fb ff ff       	jmp    1cc41 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1a71>
   1d0ac:	48 8b 84 24 30 05 00 	mov    0x530(%rsp),%rax
   1d0b3:	00 
   1d0b4:	48 89 84 24 30 0d 00 	mov    %rax,0xd30(%rsp)
   1d0bb:	00 
   1d0bc:	e9 41 fa ff ff       	jmp    1cb02 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1932>
   1d0c1:	48 8d 84 24 10 01 00 	lea    0x110(%rsp),%rax
   1d0c8:	00 
   1d0c9:	48 8d 35 6f bf 01 00 	lea    0x1bf6f(%rip),%rsi        # 3903f <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e9f>
   1d0d0:	48 89 c7             	mov    %rax,%rdi
   1d0d3:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   1d0d8:	e8 43 9a 01 00       	call   36b20 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x980>
   1d0dd:	e9 23 f4 ff ff       	jmp    1c505 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1335>
   1d0e2:	48 8b 04 24          	mov    (%rsp),%rax
   1d0e6:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
   1d0eb:	e9 76 ed ff ff       	jmp    1be66 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xc96>
   1d0f0:	48 8b 04 24          	mov    (%rsp),%rax
   1d0f4:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
   1d0f9:	e9 fa eb ff ff       	jmp    1bcf8 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xb28>
   1d0fe:	48 8b 04 24          	mov    (%rsp),%rax
   1d102:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
   1d107:	e9 17 eb ff ff       	jmp    1bc23 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xa53>
   1d10c:	48 8b 04 24          	mov    (%rsp),%rax
   1d110:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
   1d115:	e9 34 ea ff ff       	jmp    1bb4e <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x97e>
   1d11a:	48 8b 04 24          	mov    (%rsp),%rax
   1d11e:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
   1d123:	e9 5c e8 ff ff       	jmp    1b984 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x7b4>
   1d128:	48 8b 04 24          	mov    (%rsp),%rax
   1d12c:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
   1d131:	e9 31 e9 ff ff       	jmp    1ba67 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x897>
   1d136:	48 8b 04 24          	mov    (%rsp),%rax
   1d13a:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
   1d13f:	e9 cd e5 ff ff       	jmp    1b711 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x541>
   1d144:	48 8b 04 24          	mov    (%rsp),%rax
   1d148:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
   1d14d:	e9 a3 e6 ff ff       	jmp    1b7f5 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x625>
   1d152:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
   1d157:	e9 31 e1 ff ff       	jmp    1b28d <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0xbd>
   1d15c:	48 8b 04 24          	mov    (%rsp),%rax
   1d160:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
   1d165:	e9 bf e4 ff ff       	jmp    1b629 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x459>
   1d16a:	48 8d 15 37 90 02 00 	lea    0x29037(%rip),%rdx        # 461a8 <std::_Sp_make_shared_tag::_S_ti()::__tag@@Base+0x8558>
   1d171:	48 89 84 24 28 09 00 	mov    %rax,0x928(%rsp)
   1d178:	00 
   1d179:	49 89 55 00          	mov    %rdx,0x0(%r13)
   1d17d:	48 ba 01 00 00 00 01 	movabs $0x100000001,%rdx
   1d184:	00 00 00 
   1d187:	48 c7 84 24 20 09 00 	movq   $0x0,0x920(%rsp)
   1d18e:	00 00 00 00 00 
   1d193:	49 89 55 08          	mov    %rdx,0x8(%r13)
   1d197:	49 c7 45 20 00 00 00 	movq   $0x0,0x20(%r13)
   1d19e:	00 
   1d19f:	49 89 45 28          	mov    %rax,0x28(%r13)
   1d1a3:	0f 29 84 24 10 09 00 	movaps %xmm0,0x910(%rsp)
   1d1aa:	00 
   1d1ab:	41 0f 11 45 10       	movups %xmm0,0x10(%r13)
   1d1b0:	e9 59 fa ff ff       	jmp    1cc0e <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1a3e>
   1d1b5:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
   1d1ba:	e9 d1 fb ff ff       	jmp    1cd90 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1bc0>
   1d1bf:	f0 83 40 08 01       	lock addl $0x1,0x8(%rax)
   1d1c4:	e9 92 fb ff ff       	jmp    1cd5b <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1b8b>
   1d1c9:	4c 89 e7             	mov    %r12,%rdi
   1d1cc:	ff d0                	call   *%rax
   1d1ce:	49 89 c5             	mov    %rax,%r13
   1d1d1:	e9 b4 f7 ff ff       	jmp    1c98a <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x17ba>
   1d1d6:	f0 41 83 45 08 01    	lock addl $0x1,0x8(%r13)
   1d1dc:	48 8b 7b 50          	mov    0x50(%rbx),%rdi
   1d1e0:	48 85 ff             	test   %rdi,%rdi
   1d1e3:	0f 85 e9 e2 ff ff    	jne    1b4d2 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x302>
   1d1e9:	e9 e9 e2 ff ff       	jmp    1b4d7 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x307>
   1d1ee:	f0 41 83 45 08 01    	lock addl $0x1,0x8(%r13)
   1d1f4:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
   1d1f8:	48 85 ff             	test   %rdi,%rdi
   1d1fb:	0f 85 3b e2 ff ff    	jne    1b43c <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x26c>
   1d201:	e9 3b e2 ff ff       	jmp    1b441 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x271>
   1d206:	f0 41 83 45 08 01    	lock addl $0x1,0x8(%r13)
   1d20c:	48 8b 7b 70          	mov    0x70(%rbx),%rdi
   1d210:	48 85 ff             	test   %rdi,%rdi
   1d213:	0f 85 64 e2 ff ff    	jne    1b47d <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2ad>
   1d219:	e9 64 e2 ff ff       	jmp    1b482 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x2b2>
   1d21e:	f0 41 83 45 08 01    	lock addl $0x1,0x8(%r13)
   1d224:	e9 10 fa ff ff       	jmp    1cc39 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1a69>
   1d229:	e8 a2 29 ff ff       	call   fbd0 <rcutils_logging_initialize@plt>
   1d22e:	85 c0                	test   %eax,%eax
   1d230:	0f 84 95 fa ff ff    	je     1cccb <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1afb>
   1d236:	4c 8b 3d 63 9c 02 00 	mov    0x29c63(%rip),%r15        # 46ea0 <stderr@GLIBC_2.2.5>
   1d23d:	ba 51 00 00 00       	mov    $0x51,%edx
   1d242:	be 01 00 00 00       	mov    $0x1,%esi
   1d247:	48 8d 3d 92 d2 01 00 	lea    0x1d292(%rip),%rdi        # 3a4e0 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x4340>
   1d24e:	49 8b 0f             	mov    (%r15),%rcx
   1d251:	e8 3a 32 ff ff       	call   10490 <fwrite@plt>
   1d256:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
   1d25b:	4d 8b 2f             	mov    (%r15),%r13
   1d25e:	4c 89 e7             	mov    %r12,%rdi
   1d261:	e8 da 2b ff ff       	call   fe40 <rcutils_get_error_string@plt>
   1d266:	4c 89 e7             	mov    %r12,%rdi
   1d269:	e8 42 2a ff ff       	call   fcb0 <strlen@plt>
   1d26e:	48 89 ef             	mov    %rbp,%rdi
   1d271:	49 89 c4             	mov    %rax,%r12
   1d274:	e8 c7 2b ff ff       	call   fe40 <rcutils_get_error_string@plt>
   1d279:	4c 89 e9             	mov    %r13,%rcx
   1d27c:	4c 89 e2             	mov    %r12,%rdx
   1d27f:	be 01 00 00 00       	mov    $0x1,%esi
   1d284:	48 89 ef             	mov    %rbp,%rdi
   1d287:	e8 04 32 ff ff       	call   10490 <fwrite@plt>
   1d28c:	49 8b 0f             	mov    (%r15),%rcx
   1d28f:	ba 01 00 00 00       	mov    $0x1,%edx
   1d294:	be 01 00 00 00       	mov    $0x1,%esi
   1d299:	48 8d 3d 9e bd 01 00 	lea    0x1bd9e(%rip),%rdi        # 3903e <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e9e>
   1d2a0:	e8 eb 31 ff ff       	call   10490 <fwrite@plt>
   1d2a5:	e8 06 2d ff ff       	call   ffb0 <rcutils_reset_error@plt>
   1d2aa:	e9 1c fa ff ff       	jmp    1cccb <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1afb>
   1d2af:	e8 1c 29 ff ff       	call   fbd0 <rcutils_logging_initialize@plt>
   1d2b4:	85 c0                	test   %eax,%eax
   1d2b6:	0f 84 a6 f7 ff ff    	je     1ca62 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1892>
   1d2bc:	4c 8b 3d dd 9b 02 00 	mov    0x29bdd(%rip),%r15        # 46ea0 <stderr@GLIBC_2.2.5>
   1d2c3:	ba 6b 00 00 00       	mov    $0x6b,%edx
   1d2c8:	be 01 00 00 00       	mov    $0x1,%esi
   1d2cd:	48 8d 3d 84 d0 01 00 	lea    0x1d084(%rip),%rdi        # 3a358 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x41b8>
   1d2d4:	49 8b 0f             	mov    (%r15),%rcx
   1d2d7:	e8 b4 31 ff ff       	call   10490 <fwrite@plt>
   1d2dc:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
   1d2e1:	4d 8b 2f             	mov    (%r15),%r13
   1d2e4:	4c 89 e7             	mov    %r12,%rdi
   1d2e7:	e8 54 2b ff ff       	call   fe40 <rcutils_get_error_string@plt>
   1d2ec:	4c 89 e7             	mov    %r12,%rdi
   1d2ef:	e8 bc 29 ff ff       	call   fcb0 <strlen@plt>
   1d2f4:	48 89 ef             	mov    %rbp,%rdi
   1d2f7:	49 89 c4             	mov    %rax,%r12
   1d2fa:	e8 41 2b ff ff       	call   fe40 <rcutils_get_error_string@plt>
   1d2ff:	4c 89 e9             	mov    %r13,%rcx
   1d302:	4c 89 e2             	mov    %r12,%rdx
   1d305:	be 01 00 00 00       	mov    $0x1,%esi
   1d30a:	48 89 ef             	mov    %rbp,%rdi
   1d30d:	e8 7e 31 ff ff       	call   10490 <fwrite@plt>
   1d312:	49 8b 0f             	mov    (%r15),%rcx
   1d315:	ba 01 00 00 00       	mov    $0x1,%edx
   1d31a:	be 01 00 00 00       	mov    $0x1,%esi
   1d31f:	48 8d 3d 18 bd 01 00 	lea    0x1bd18(%rip),%rdi        # 3903e <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e9e>
   1d326:	e8 65 31 ff ff       	call   10490 <fwrite@plt>
   1d32b:	e8 80 2c ff ff       	call   ffb0 <rcutils_reset_error@plt>
   1d330:	e9 2d f7 ff ff       	jmp    1ca62 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1892>
   1d335:	e8 96 28 ff ff       	call   fbd0 <rcutils_logging_initialize@plt>
   1d33a:	85 c0                	test   %eax,%eax
   1d33c:	0f 84 44 f1 ff ff    	je     1c486 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x12b6>
   1d342:	4c 8b 3d 57 9b 02 00 	mov    0x29b57(%rip),%r15        # 46ea0 <stderr@GLIBC_2.2.5>
   1d349:	ba 6b 00 00 00       	mov    $0x6b,%edx
   1d34e:	be 01 00 00 00       	mov    $0x1,%esi
   1d353:	48 8d 3d a6 c8 01 00 	lea    0x1c8a6(%rip),%rdi        # 39c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3a60>
   1d35a:	49 8b 0f             	mov    (%r15),%rcx
   1d35d:	e8 2e 31 ff ff       	call   10490 <fwrite@plt>
   1d362:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
   1d367:	49 8b 07             	mov    (%r15),%rax
   1d36a:	4c 89 ef             	mov    %r13,%rdi
   1d36d:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   1d372:	e8 c9 2a ff ff       	call   fe40 <rcutils_get_error_string@plt>
   1d377:	4c 89 ef             	mov    %r13,%rdi
   1d37a:	e8 31 29 ff ff       	call   fcb0 <strlen@plt>
   1d37f:	48 89 ef             	mov    %rbp,%rdi
   1d382:	49 89 c5             	mov    %rax,%r13
   1d385:	e8 b6 2a ff ff       	call   fe40 <rcutils_get_error_string@plt>
   1d38a:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
   1d38f:	4c 89 ea             	mov    %r13,%rdx
   1d392:	be 01 00 00 00       	mov    $0x1,%esi
   1d397:	48 89 ef             	mov    %rbp,%rdi
   1d39a:	e8 f1 30 ff ff       	call   10490 <fwrite@plt>
   1d39f:	49 8b 0f             	mov    (%r15),%rcx
   1d3a2:	ba 01 00 00 00       	mov    $0x1,%edx
   1d3a7:	be 01 00 00 00       	mov    $0x1,%esi
   1d3ac:	48 8d 3d 8b bc 01 00 	lea    0x1bc8b(%rip),%rdi        # 3903e <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e9e>
   1d3b3:	e8 d8 30 ff ff       	call   10490 <fwrite@plt>
   1d3b8:	e8 f3 2b ff ff       	call   ffb0 <rcutils_reset_error@plt>
   1d3bd:	e9 c4 f0 ff ff       	jmp    1c486 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x12b6>
   1d3c2:	e8 09 28 ff ff       	call   fbd0 <rcutils_logging_initialize@plt>
   1d3c7:	85 c0                	test   %eax,%eax
   1d3c9:	0f 84 46 f1 ff ff    	je     1c515 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1345>
   1d3cf:	4c 8b 3d ca 9a 02 00 	mov    0x29aca(%rip),%r15        # 46ea0 <stderr@GLIBC_2.2.5>
   1d3d6:	ba 6b 00 00 00       	mov    $0x6b,%edx
   1d3db:	be 01 00 00 00       	mov    $0x1,%esi
   1d3e0:	48 8d 3d c9 c8 01 00 	lea    0x1c8c9(%rip),%rdi        # 39cb0 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3b10>
   1d3e7:	49 8b 0f             	mov    (%r15),%rcx
   1d3ea:	e8 a1 30 ff ff       	call   10490 <fwrite@plt>
   1d3ef:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
   1d3f4:	4d 8b 2f             	mov    (%r15),%r13
   1d3f7:	4c 89 e7             	mov    %r12,%rdi
   1d3fa:	e8 41 2a ff ff       	call   fe40 <rcutils_get_error_string@plt>
   1d3ff:	4c 89 e7             	mov    %r12,%rdi
   1d402:	e8 a9 28 ff ff       	call   fcb0 <strlen@plt>
   1d407:	48 89 ef             	mov    %rbp,%rdi
   1d40a:	49 89 c4             	mov    %rax,%r12
   1d40d:	e8 2e 2a ff ff       	call   fe40 <rcutils_get_error_string@plt>
   1d412:	4c 89 e9             	mov    %r13,%rcx
   1d415:	4c 89 e2             	mov    %r12,%rdx
   1d418:	be 01 00 00 00       	mov    $0x1,%esi
   1d41d:	48 89 ef             	mov    %rbp,%rdi
   1d420:	e8 6b 30 ff ff       	call   10490 <fwrite@plt>
   1d425:	49 8b 0f             	mov    (%r15),%rcx
   1d428:	ba 01 00 00 00       	mov    $0x1,%edx
   1d42d:	be 01 00 00 00       	mov    $0x1,%esi
   1d432:	48 8d 3d 05 bc 01 00 	lea    0x1bc05(%rip),%rdi        # 3903e <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e9e>
   1d439:	e8 52 30 ff ff       	call   10490 <fwrite@plt>
   1d43e:	e8 6d 2b ff ff       	call   ffb0 <rcutils_reset_error@plt>
   1d443:	e9 cd f0 ff ff       	jmp    1c515 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1345>
   1d448:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   1d44d:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   1d452:	e9 e6 f3 ff ff       	jmp    1c83d <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x166d>
   1d457:	4c 89 e7             	mov    %r12,%rdi
   1d45a:	ff d0                	call   *%rax
   1d45c:	49 89 c5             	mov    %rax,%r13
   1d45f:	e9 7e f4 ff ff       	jmp    1c8e2 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1712>
   1d464:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   1d46b:	00 
   1d46c:	48 29 fe             	sub    %rdi,%rsi
   1d46f:	e8 4c 2b ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1d474:	e9 5d f2 ff ff       	jmp    1c6d6 <nav2_rotation_shim_controller::RotationShimController::configure(std::weak_ptr<rclcpp_lifecycle::LifecycleNode> const&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::shared_ptr<tf2_ros::Buffer>, std::shared_ptr<nav2_costmap_2d::Costmap2DROS>)@@Base+0x1506>
   1d479:	89 c7                	mov    %eax,%edi
   1d47b:	e8 80 29 ff ff       	call   fe00 <std::__throw_system_error(int)@plt>
   1d480:	48 8d 3d 79 bb 01 00 	lea    0x1bb79(%rip),%rdi        # 39000 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e60>
   1d487:	e8 c4 28 ff ff       	call   fd50 <std::__throw_length_error(char const*)@plt>
   1d48c:	e8 cf 2b ff ff       	call   10060 <__stack_chk_fail@plt>
   1d491:	48 8d 3d 68 bb 01 00 	lea    0x1bb68(%rip),%rdi        # 39000 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e60>
   1d498:	e8 b3 28 ff ff       	call   fd50 <std::__throw_length_error(char const*)@plt>
   1d49d:	e8 be 27 ff ff       	call   fc60 <std::__throw_bad_function_call()@plt>
   1d4a2:	89 c7                	mov    %eax,%edi
   1d4a4:	e8 57 29 ff ff       	call   fe00 <std::__throw_system_error(int)@plt>
   1d4a9:	48 8d 3d 50 bb 01 00 	lea    0x1bb50(%rip),%rdi        # 39000 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e60>
   1d4b0:	e8 9b 28 ff ff       	call   fd50 <std::__throw_length_error(char const*)@plt>
   1d4b5:	48 8d 3d 44 bb 01 00 	lea    0x1bb44(%rip),%rdi        # 39000 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e60>
   1d4bc:	e8 8f 28 ff ff       	call   fd50 <std::__throw_length_error(char const*)@plt>
   1d4c1:	48 8d 3d 38 bb 01 00 	lea    0x1bb38(%rip),%rdi        # 39000 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e60>
   1d4c8:	e8 83 28 ff ff       	call   fd50 <std::__throw_length_error(char const*)@plt>
   1d4cd:	48 8d 3d 2c bb 01 00 	lea    0x1bb2c(%rip),%rdi        # 39000 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e60>
   1d4d4:	e8 77 28 ff ff       	call   fd50 <std::__throw_length_error(char const*)@plt>
   1d4d9:	48 8d 3d 20 bb 01 00 	lea    0x1bb20(%rip),%rdi        # 39000 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e60>
   1d4e0:	e8 6b 28 ff ff       	call   fd50 <std::__throw_length_error(char const*)@plt>
   1d4e5:	48 8d 3d 14 bb 01 00 	lea    0x1bb14(%rip),%rdi        # 39000 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e60>
   1d4ec:	e8 5f 28 ff ff       	call   fd50 <std::__throw_length_error(char const*)@plt>
   1d4f1:	48 8d 3d 08 bb 01 00 	lea    0x1bb08(%rip),%rdi        # 39000 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e60>
   1d4f8:	e8 53 28 ff ff       	call   fd50 <std::__throw_length_error(char const*)@plt>
   1d4fd:	48 8d 3d fc ba 01 00 	lea    0x1bafc(%rip),%rdi        # 39000 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e60>
   1d504:	e8 47 28 ff ff       	call   fd50 <std::__throw_length_error(char const*)@plt>
   1d509:	48 8d 3d f0 ba 01 00 	lea    0x1baf0(%rip),%rdi        # 39000 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e60>
   1d510:	e8 3b 28 ff ff       	call   fd50 <std::__throw_length_error(char const*)@plt>
   1d515:	48 8d 3d e4 ba 01 00 	lea    0x1bae4(%rip),%rdi        # 39000 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e60>
   1d51c:	e8 2f 28 ff ff       	call   fd50 <std::__throw_length_error(char const*)@plt>
   1d521:	48 8d 3d d8 ba 01 00 	lea    0x1bad8(%rip),%rdi        # 39000 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e60>
   1d528:	e8 23 28 ff ff       	call   fd50 <std::__throw_length_error(char const*)@plt>
   1d52d:	48 8d 3d cc ba 01 00 	lea    0x1bacc(%rip),%rdi        # 39000 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e60>
   1d534:	e8 17 28 ff ff       	call   fd50 <std::__throw_length_error(char const*)@plt>
   1d539:	48 8d 3d c0 ba 01 00 	lea    0x1bac0(%rip),%rdi        # 39000 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e60>
   1d540:	e8 0b 28 ff ff       	call   fd50 <std::__throw_length_error(char const*)@plt>
   1d545:	48 8d 3d b4 ba 01 00 	lea    0x1bab4(%rip),%rdi        # 39000 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e60>
   1d54c:	e8 ff 27 ff ff       	call   fd50 <std::__throw_length_error(char const*)@plt>
   1d551:	48 8d 3d a8 ba 01 00 	lea    0x1baa8(%rip),%rdi        # 39000 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e60>
   1d558:	e8 f3 27 ff ff       	call   fd50 <std::__throw_length_error(char const*)@plt>
   1d55d:	48 8d 3d 9c ba 01 00 	lea    0x1ba9c(%rip),%rdi        # 39000 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e60>
   1d564:	e8 e7 27 ff ff       	call   fd50 <std::__throw_length_error(char const*)@plt>
   1d569:	48 8d 3d 90 ba 01 00 	lea    0x1ba90(%rip),%rdi        # 39000 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e60>
   1d570:	e8 db 27 ff ff       	call   fd50 <std::__throw_length_error(char const*)@plt>
   1d575:	f3 0f 1e fa          	endbr64 
   1d579:	48 89 c3             	mov    %rax,%rbx
   1d57c:	e9 33 45 ff ff       	jmp    11ab4 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x15e4>
   1d581:	f3 0f 1e fa          	endbr64 
   1d585:	48 89 c3             	mov    %rax,%rbx
   1d588:	e9 78 45 ff ff       	jmp    11b05 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1635>
   1d58d:	f3 0f 1e fa          	endbr64 
   1d591:	48 89 c3             	mov    %rax,%rbx
   1d594:	e9 64 45 ff ff       	jmp    11afd <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x162d>
   1d599:	f3 0f 1e fa          	endbr64 
   1d59d:	48 89 c3             	mov    %rax,%rbx
   1d5a0:	e9 aa 45 ff ff       	jmp    11b4f <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x167f>
   1d5a5:	f3 0f 1e fa          	endbr64 
   1d5a9:	48 89 c3             	mov    %rax,%rbx
   1d5ac:	e9 7d 45 ff ff       	jmp    11b2e <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x165e>
   1d5b1:	f3 0f 1e fa          	endbr64 
   1d5b5:	48 89 c3             	mov    %rax,%rbx
   1d5b8:	e9 ce 45 ff ff       	jmp    11b8b <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x16bb>
   1d5bd:	f3 0f 1e fa          	endbr64 
   1d5c1:	49 89 c4             	mov    %rax,%r12
   1d5c4:	49 89 d5             	mov    %rdx,%r13
   1d5c7:	e9 db 45 ff ff       	jmp    11ba7 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x16d7>
   1d5cc:	f3 0f 1e fa          	endbr64 
   1d5d0:	48 89 c3             	mov    %rax,%rbx
   1d5d3:	e9 60 47 ff ff       	jmp    11d38 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1868>
   1d5d8:	f3 0f 1e fa          	endbr64 
   1d5dc:	49 89 c4             	mov    %rax,%r12
   1d5df:	49 89 d5             	mov    %rdx,%r13
   1d5e2:	e9 7e 47 ff ff       	jmp    11d65 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1895>
   1d5e7:	f3 0f 1e fa          	endbr64 
   1d5eb:	49 89 c4             	mov    %rax,%r12
   1d5ee:	49 89 d5             	mov    %rdx,%r13
   1d5f1:	e9 2d 47 ff ff       	jmp    11d23 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1853>
   1d5f6:	f3 0f 1e fa          	endbr64 
   1d5fa:	49 89 c4             	mov    %rax,%r12
   1d5fd:	49 89 d5             	mov    %rdx,%r13
   1d600:	e9 1e 49 ff ff       	jmp    11f23 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1a53>
   1d605:	f3 0f 1e fa          	endbr64 
   1d609:	48 89 c3             	mov    %rax,%rbx
   1d60c:	e9 6a 45 ff ff       	jmp    11b7b <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x16ab>
   1d611:	f3 0f 1e fa          	endbr64 
   1d615:	48 89 c3             	mov    %rax,%rbx
   1d618:	e9 19 45 ff ff       	jmp    11b36 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1666>
   1d61d:	f3 0f 1e fa          	endbr64 
   1d621:	48 89 c3             	mov    %rax,%rbx
   1d624:	e9 07 49 ff ff       	jmp    11f30 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1a60>
   1d629:	f3 0f 1e fa          	endbr64 
   1d62d:	48 89 c3             	mov    %rax,%rbx
   1d630:	e9 1f 49 ff ff       	jmp    11f54 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1a84>
   1d635:	f3 0f 1e fa          	endbr64 
   1d639:	48 89 c3             	mov    %rax,%rbx
   1d63c:	e9 2d 49 ff ff       	jmp    11f6e <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1a9e>
   1d641:	f3 0f 1e fa          	endbr64 
   1d645:	48 89 c3             	mov    %rax,%rbx
   1d648:	e9 3b 49 ff ff       	jmp    11f88 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1ab8>
   1d64d:	f3 0f 1e fa          	endbr64 
   1d651:	48 89 c3             	mov    %rax,%rbx
   1d654:	e9 3c 49 ff ff       	jmp    11f95 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1ac5>
   1d659:	f3 0f 1e fa          	endbr64 
   1d65d:	48 89 c3             	mov    %rax,%rbx
   1d660:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
   1d667:	00 
   1d668:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   1d66d:	e9 d3 48 ff ff       	jmp    11f45 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1a75>
   1d672:	f3 0f 1e fa          	endbr64 
   1d676:	48 89 c3             	mov    %rax,%rbx
   1d679:	e9 31 49 ff ff       	jmp    11faf <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1adf>
   1d67e:	f3 0f 1e fa          	endbr64 
   1d682:	48 89 c3             	mov    %rax,%rbx
   1d685:	e9 41 49 ff ff       	jmp    11fcb <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1afb>
   1d68a:	f3 0f 1e fa          	endbr64 
   1d68e:	48 89 c3             	mov    %rax,%rbx
   1d691:	e9 6c 49 ff ff       	jmp    12002 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1b32>
   1d696:	f3 0f 1e fa          	endbr64 
   1d69a:	e9 67 46 ff ff       	jmp    11d06 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1836>
   1d69f:	f3 0f 1e fa          	endbr64 
   1d6a3:	48 89 c3             	mov    %rax,%rbx
   1d6a6:	e9 3a 44 ff ff       	jmp    11ae5 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1615>
   1d6ab:	f3 0f 1e fa          	endbr64 
   1d6af:	49 89 c4             	mov    %rax,%r12
   1d6b2:	49 89 d5             	mov    %rdx,%r13
   1d6b5:	e9 b3 46 ff ff       	jmp    11d6d <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x189d>
   1d6ba:	f3 0f 1e fa          	endbr64 
   1d6be:	48 89 c3             	mov    %rax,%rbx
   1d6c1:	e9 15 44 ff ff       	jmp    11adb <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x160b>
   1d6c6:	f3 0f 1e fa          	endbr64 
   1d6ca:	49 89 c4             	mov    %rax,%r12
   1d6cd:	49 89 d5             	mov    %rdx,%r13
   1d6d0:	e9 4e 46 ff ff       	jmp    11d23 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1853>
   1d6d5:	f3 0f 1e fa          	endbr64 
   1d6d9:	48 89 c3             	mov    %rax,%rbx
   1d6dc:	e9 76 44 ff ff       	jmp    11b57 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1687>
   1d6e1:	f3 0f 1e fa          	endbr64 
   1d6e5:	48 89 c3             	mov    %rax,%rbx
   1d6e8:	e9 e2 49 ff ff       	jmp    120cf <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1bff>
   1d6ed:	f3 0f 1e fa          	endbr64 
   1d6f1:	48 89 c3             	mov    %rax,%rbx
   1d6f4:	e9 18 49 ff ff       	jmp    12011 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1b41>
   1d6f9:	f3 0f 1e fa          	endbr64 
   1d6fd:	48 89 c3             	mov    %rax,%rbx
   1d700:	e9 14 49 ff ff       	jmp    12019 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1b49>
   1d705:	f3 0f 1e fa          	endbr64 
   1d709:	48 89 c3             	mov    %rax,%rbx
   1d70c:	e9 cb 49 ff ff       	jmp    120dc <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1c0c>
   1d711:	f3 0f 1e fa          	endbr64 
   1d715:	48 89 c3             	mov    %rax,%rbx
   1d718:	e9 dc 49 ff ff       	jmp    120f9 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1c29>
   1d71d:	f3 0f 1e fa          	endbr64 
   1d721:	48 89 c3             	mov    %rax,%rbx
   1d724:	e9 0b 4a ff ff       	jmp    12134 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1c64>
   1d729:	f3 0f 1e fa          	endbr64 
   1d72d:	48 89 c3             	mov    %rax,%rbx
   1d730:	e9 e9 49 ff ff       	jmp    1211e <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1c4e>
   1d735:	f3 0f 1e fa          	endbr64 
   1d739:	48 89 c3             	mov    %rax,%rbx
   1d73c:	e9 ef 45 ff ff       	jmp    11d30 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1860>
   1d741:	f3 0f 1e fa          	endbr64 
   1d745:	48 89 c3             	mov    %rax,%rbx
   1d748:	e9 0b 4a ff ff       	jmp    12158 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1c88>
   1d74d:	f3 0f 1e fa          	endbr64 
   1d751:	49 89 c4             	mov    %rax,%r12
   1d754:	49 89 d7             	mov    %rdx,%r15
   1d757:	e9 0e 4a ff ff       	jmp    1216a <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1c9a>
   1d75c:	f3 0f 1e fa          	endbr64 
   1d760:	49 89 c4             	mov    %rax,%r12
   1d763:	49 89 d7             	mov    %rdx,%r15
   1d766:	e9 ff 49 ff ff       	jmp    1216a <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1c9a>
   1d76b:	f3 0f 1e fa          	endbr64 
   1d76f:	48 89 c3             	mov    %rax,%rbx
   1d772:	e9 c7 49 ff ff       	jmp    1213e <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1c6e>
   1d777:	f3 0f 1e fa          	endbr64 
   1d77b:	48 89 c3             	mov    %rax,%rbx
   1d77e:	e9 fc 49 ff ff       	jmp    1217f <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1caf>
   1d783:	f3 0f 1e fa          	endbr64 
   1d787:	48 89 c3             	mov    %rax,%rbx
   1d78a:	e9 4f 48 ff ff       	jmp    11fde <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1b0e>
   1d78f:	f3 0f 1e fa          	endbr64 
   1d793:	48 89 c3             	mov    %rax,%rbx
   1d796:	e9 4b 48 ff ff       	jmp    11fe6 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1b16>
   1d79b:	f3 0f 1e fa          	endbr64 
   1d79f:	48 89 c3             	mov    %rax,%rbx
   1d7a2:	e9 dc 43 ff ff       	jmp    11b83 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x16b3>
   1d7a7:	f3 0f 1e fa          	endbr64 
   1d7ab:	48 89 c3             	mov    %rax,%rbx
   1d7ae:	e9 d9 49 ff ff       	jmp    1218c <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1cbc>
   1d7b3:	f3 0f 1e fa          	endbr64 
   1d7b7:	49 89 c4             	mov    %rax,%r12
   1d7ba:	49 89 d5             	mov    %rdx,%r13
   1d7bd:	e9 f7 43 ff ff       	jmp    11bb9 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x16e9>
   1d7c2:	f3 0f 1e fa          	endbr64 
   1d7c6:	48 89 c3             	mov    %rax,%rbx
   1d7c9:	e9 d8 49 ff ff       	jmp    121a6 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1cd6>
   1d7ce:	f3 0f 1e fa          	endbr64 
   1d7d2:	49 89 c4             	mov    %rax,%r12
   1d7d5:	49 89 d5             	mov    %rdx,%r13
   1d7d8:	e9 e6 49 ff ff       	jmp    121c3 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1cf3>
   1d7dd:	f3 0f 1e fa          	endbr64 
   1d7e1:	48 89 c3             	mov    %rax,%rbx
   1d7e4:	e9 00 4a ff ff       	jmp    121e9 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1d19>
   1d7e9:	f3 0f 1e fa          	endbr64 
   1d7ed:	48 89 c3             	mov    %rax,%rbx
   1d7f0:	e9 27 4a ff ff       	jmp    1221c <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1d4c>
   1d7f5:	f3 0f 1e fa          	endbr64 
   1d7f9:	48 89 c5             	mov    %rax,%rbp
   1d7fc:	e9 33 4a ff ff       	jmp    12234 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1d64>
   1d801:	f3 0f 1e fa          	endbr64 
   1d805:	48 89 c3             	mov    %rax,%rbx
   1d808:	e9 3c 4a ff ff       	jmp    12249 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1d79>
   1d80d:	f3 0f 1e fa          	endbr64 
   1d811:	48 89 c3             	mov    %rax,%rbx
   1d814:	e9 4a 4a ff ff       	jmp    12263 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1d93>
   1d819:	f3 0f 1e fa          	endbr64 
   1d81d:	48 89 c3             	mov    %rax,%rbx
   1d820:	e9 58 4a ff ff       	jmp    1227d <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1dad>
   1d825:	f3 0f 1e fa          	endbr64 
   1d829:	48 89 c3             	mov    %rax,%rbx
   1d82c:	e9 66 4a ff ff       	jmp    12297 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1dc7>
   1d831:	f3 0f 1e fa          	endbr64 
   1d835:	48 89 c3             	mov    %rax,%rbx
   1d838:	e9 74 4a ff ff       	jmp    122b1 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1de1>
   1d83d:	f3 0f 1e fa          	endbr64 
   1d841:	48 89 c3             	mov    %rax,%rbx
   1d844:	e9 82 4a ff ff       	jmp    122cb <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1dfb>
   1d849:	f3 0f 1e fa          	endbr64 
   1d84d:	48 89 c3             	mov    %rax,%rbx
   1d850:	e9 83 4a ff ff       	jmp    122d8 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1e08>
   1d855:	f3 0f 1e fa          	endbr64 
   1d859:	48 89 c3             	mov    %rax,%rbx
   1d85c:	e9 84 4a ff ff       	jmp    122e5 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1e15>
   1d861:	f3 0f 1e fa          	endbr64 
   1d865:	48 89 c3             	mov    %rax,%rbx
   1d868:	e9 85 4a ff ff       	jmp    122f2 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1e22>
   1d86d:	f3 0f 1e fa          	endbr64 
   1d871:	48 89 c3             	mov    %rax,%rbx
   1d874:	e9 87 49 ff ff       	jmp    12200 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1d30>
   1d879:	f3 0f 1e fa          	endbr64 
   1d87d:	48 89 c3             	mov    %rax,%rbx
   1d880:	e9 7a 4a ff ff       	jmp    122ff <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1e2f>
   1d885:	f3 0f 1e fa          	endbr64 
   1d889:	48 89 c3             	mov    %rax,%rbx
   1d88c:	e9 88 4a ff ff       	jmp    12319 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1e49>
   1d891:	f3 0f 1e fa          	endbr64 
   1d895:	48 89 c3             	mov    %rax,%rbx
   1d898:	e9 96 4a ff ff       	jmp    12333 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1e63>
   1d89d:	f3 0f 1e fa          	endbr64 
   1d8a1:	48 89 c3             	mov    %rax,%rbx
   1d8a4:	e9 6d 48 ff ff       	jmp    12116 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1c46>
   1d8a9:	f3 0f 1e fa          	endbr64 
   1d8ad:	48 89 c3             	mov    %rax,%rbx
   1d8b0:	e9 8b 4a ff ff       	jmp    12340 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1e70>
   1d8b5:	f3 0f 1e fa          	endbr64 
   1d8b9:	48 89 c3             	mov    %rax,%rbx
   1d8bc:	e9 4c 42 ff ff       	jmp    11b0d <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x163d>
   1d8c1:	f3 0f 1e fa          	endbr64 
   1d8c5:	48 89 c3             	mov    %rax,%rbx
   1d8c8:	e9 90 4a ff ff       	jmp    1235d <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1e8d>
   1d8cd:	f3 0f 1e fa          	endbr64 
   1d8d1:	48 89 c3             	mov    %rax,%rbx
   1d8d4:	e9 86 42 ff ff       	jmp    11b5f <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x168f>
   1d8d9:	f3 0f 1e fa          	endbr64 
   1d8dd:	48 89 c3             	mov    %rax,%rbx
   1d8e0:	e9 92 4a ff ff       	jmp    12377 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1ea7>
   1d8e5:	f3 0f 1e fa          	endbr64 
   1d8e9:	48 89 c3             	mov    %rax,%rbx
   1d8ec:	e9 a5 4a ff ff       	jmp    12396 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1ec6>
   1d8f1:	f3 0f 1e fa          	endbr64 
   1d8f5:	48 89 c3             	mov    %rax,%rbx
   1d8f8:	e9 fb 48 ff ff       	jmp    121f8 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1d28>
   1d8fd:	f3 0f 1e fa          	endbr64 
   1d901:	48 89 c3             	mov    %rax,%rbx
   1d904:	e9 bb 41 ff ff       	jmp    11ac4 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x15f4>
   1d909:	f3 0f 1e fa          	endbr64 
   1d90d:	48 89 c3             	mov    %rax,%rbx
   1d910:	e9 11 42 ff ff       	jmp    11b26 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1656>
   1d915:	f3 0f 1e fa          	endbr64 
   1d919:	48 89 c3             	mov    %rax,%rbx
   1d91c:	e9 9b 41 ff ff       	jmp    11abc <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x15ec>
   1d921:	90                   	nop
   1d922:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   1d929:	00 00 00 00 
   1d92d:	0f 1f 00             	nopl   (%rax)
   1d930:	f3 0f 1e fa          	endbr64 
   1d934:	55                   	push   %rbp
   1d935:	48 89 fd             	mov    %rdi,%rbp
   1d938:	e8 53 d2 ff ff       	call   1ab90 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xdd0>
   1d93d:	48 89 ef             	mov    %rbp,%rdi
   1d940:	be c0 00 00 00       	mov    $0xc0,%esi
   1d945:	5d                   	pop    %rbp
   1d946:	e9 75 26 ff ff       	jmp    ffc0 <operator delete(void*, unsigned long)@plt>
   1d94b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
