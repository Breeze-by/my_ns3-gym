"""Read-only observed stop tail: no gate replacement or runtime control."""
from pathlib import Path
import json,hashlib,math,bisect,time
E=Path('/home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261017_v12_reset/worker0/episode004_corridors_101')
end=106480000000;start=102400000000;bindings={};odoms=[];decisions=[];drive=[]
for name in ('motion_safety.jsonl','drive_tb1.jsonl'):
 h=hashlib.sha256();path=E/name
 with path.open('rb') as stream:
  for line_no,line in enumerate(stream,1):
   h.update(line)
   if name=='motion_safety.jsonl':
    if b'"own_odom"' not in line and b'"decision"' not in line:continue
    row=json.loads(line);v=row['payload']
    if v.get('robot')!='tb1':continue
    if row['kind']=='own_odom':
     msg=v['message'];stamp=msg['header']['stamp'];clock=stamp['sec']*10**9+stamp['nanosec']
     if not start<=clock<=end:continue
     pose=msg['pose']['pose']['position'];lin=msg['twist']['twist']['linear'];ang=msg['twist']['twist']['angular']
     odoms.append({'source_ns':clock,'position_xy':[pose['x'],pose['y']],'planar_speed':math.hypot(lin['x'],lin['y']),'linear':lin,'angular':ang,'input_sequence':v['input_sequence'],'record_sequence':row['record_sequence'],'line':line_no,'original':row})
    elif row['kind']=='decision':
     clock=v['clock_ns']
     if start<=clock<=end:decisions.append({'line':line_no,'value':v})
   else:
    row=json.loads(line)
    if start<=row['sim_time_ns']<=end:drive.append({'line':line_no,'value':row})
 bindings[name]={'path':str(path),'sha256':h.hexdigest()}
unique={v['source_ns']:v for v in odoms};ordered=sorted(unique.values(),key=lambda v:v['source_ns']);clocks=[v['source_ns'] for v in ordered];events=[]
for name,event in [('A_final_linear_zero',102480000000),('B_native_cancel_end_to_end',102460000000)]:
 k=bisect.bisect_right(clocks,event)-1;anchor=ordered[k];following=ordered[k+1];f=(event-anchor['source_ns'])/(following['source_ns']-anchor['source_ns']);point=[anchor['position_xy'][i]+f*(following['position_xy'][i]-anchor['position_xy'][i]) for i in range(2)];path=0.;tail=[]
 for v in ordered[k+1:]:
  if v['source_ns']<event:continue
  path+=math.dist(point,v['position_xy']);point=v['position_xy'];tail.append({k:v[k] for k in ('source_ns','position_xy','planar_speed','linear','angular','line','input_sequence')})
 triple=next(([v['source_ns'] for v in tail[j:j+3]] for j in range(len(tail)-2) if all(v['planar_speed']<=.01 for v in tail[j:j+3])),None)
 events.append({'category':name,'event_ns':event,'anchor':{k:anchor[k] for k in ('source_ns','planar_speed','position_xy')},'last_observed_source_ns':tail[-1]['source_ns'],'observed_window_sec':(tail[-1]['source_ns']-event)/1e9,'observed_path_through_final_sample_m':path,'first_rest_triple':triple,'measured_stop_latency_sec':None if triple is None else (triple[0]-event)/1e9,'min_planar_after_horizon':min(v['planar_speed'] for v in tail if v['source_ns']>event+780000000),'max_planar_after_horizon':max(v['planar_speed'] for v in tail if v['source_ns']>event+780000000),'post_horizon_samples':sum(v['source_ns']>event+780000000 for v in tail),'tail':tail})
acts=[r for r in drive if r['value']['kind']=='actuation'];post=[r for r in acts if r['value']['sim_time_ns']>=102480000000];first_desired_zero=next((r for r in drive if r['value']['kind']=='command_received' and r['value']['sim_time_ns']>=102480000000 and r['value']['desired_v']==r['value']['desired_w']==0),None);first_applied_zero=next((r for r in post if r['value']['applied_rim_mps']==[0.,0.]),None)
result={'scope':'Additional raw stop-tail forensic diagnosis only; original formal A/B FAILs unchanged, no continuous trajectory/plant proof','freeze':'6b1b4a0108351f5bfb70ec0c96ba895248d4f7a8','epoch':'mr3_p2a0_20261017_v12_reset_w0_e4_6fe77165','raw_bindings':bindings,'events':events,'first_zero_received':first_desired_zero,'first_zero_applied':first_applied_zero,'all_later_desired_zero':all(r['value']['desired_rim_mps']==[0.,0.] for r in post),'later_applied_nonzero_after_first_zero':sum(any(x!=0 for x in r['value']['applied_rim_mps']) for r in post if first_applied_zero and r['value']['sim_time_ns']>first_applied_zero['value']['sim_time_ns']),'max_post_zero_joint_rim':max(abs(x) for r in post if first_applied_zero and r['value']['sim_time_ns']>=first_applied_zero['value']['sim_time_ns'] for x in r['value']['current_rim_mps']),'decisions':decisions,'drive_rows':drive,'own_raw_rows':odoms,'input_bytes_unchanged':all(hashlib.sha256(Path(v['path']).read_bytes()).hexdigest()==v['sha256'] for v in bindings.values())}
p=Path('/tmp/mr3_p2a0_v12_stop_tail_forensics_v1.json');p.write_text(json.dumps(result,indent=2)+chr(10));print(json.dumps({'output':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'events':[{k:v for k,v in e.items() if k!='tail'} for e in events],'first_zero_received_ns':first_desired_zero['value']['sim_time_ns'] if first_desired_zero else None,'first_zero_applied_ns':first_applied_zero['value']['sim_time_ns'] if first_applied_zero else None,'all_later_desired_zero':result['all_later_desired_zero'],'later_applied_nonzero_after_first_zero':result['later_applied_nonzero_after_first_zero'],'max_post_zero_joint_rim':result['max_post_zero_joint_rim']}))
