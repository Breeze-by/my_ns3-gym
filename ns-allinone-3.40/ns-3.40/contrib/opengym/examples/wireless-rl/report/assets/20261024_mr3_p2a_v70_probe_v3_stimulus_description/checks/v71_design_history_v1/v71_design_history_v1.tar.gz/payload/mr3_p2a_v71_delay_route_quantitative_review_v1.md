# 延迟一拍路线：量化结论

建议暂停以“首拍 KEEP”启动新的 World。现有派生证据没有证明 KEEP 后能获得更长、可活过原 5 秒 commitment 的合法目标；这不等于证明未来 V4 必然失败。

V68 的 task1（snapshot sequence 2，clock 42.22）三机均 idle/unowned。仅使用派生数据中保存的原 per-robot GOAL mask 与坐标，计算原 nonapproach 方向谓词，结果为：

| 机器人 | 方向条件通过的候选 | 最远端点 / 对应路径（米） |
|---|---|---|
| tb1 | 3 | 0.378376 / 0.408968 |
| tb2 | 1、4 | 0.505788 / 0.523877 |
| tb3 | 2 | **0.291027 / 0.310858** |

TB3 的较长原 masked 候选 0（1.074667m）、1（1.033215m）、6（0.648729m）均至少对一名 peer 有负 outward cosine，故不能以原 nonapproach 规则使用。Task0 的上述方向可用集合相同，距离仅有约微米以下差异。额外一拍确实令活动路径观测就绪，但没有观察到目标几何变长。V70/V69 task0 的唯一三 GOAL 联合动作 621 给 tb3 的端点反而较长（0.462651m），仍自然结束在合法 moving WAIT 之前。

原 1000 位 joint mask 未保存在 V68 派生结果中。只可列出方向组合的形式编码 312、342；两者不在已记录的 conflict reason 列表内，但不能据此认证完整原 joint mask membership 或合法三 GOAL 数量。没有重新制造 geometry/joint mask，也没有把旧 V2 经 1.45 过滤后的 count=1 当成全局合法集合。

完整小量化原件：`/tmp/mr3_p2a_v71_delay_route_quantitative_review_v1.json`（33507B，SHA256 `4961dda7475e47ce083d922f4e7f8292618e8042c23e660b23ed0c651c61350a`）。含两拍每个原 masked 候选、peer direction 数值、派生 SHA 与精确 pointer。

本次仅消费已授权 V68/V70 派生 JSON，不读原 transitions/summary，不运行 CPU 测试、reader、native 或 World，不改 canonical。旧 FAIL、物理门及 policy/capacity 阻断保持。
