V60 outward-cancel stimulus: prospective source review

The current selector can miss meaningful cancellation evidence even after a
robot has moved. This is a fixture reliability gap, not a demonstrated cause of
the two actual corridors cases. No V60 scientific stream was read or replayed.
The active E source freeze remains unchanged. The separate observed tb2 B-bound
violation remains a real failed criterion; this proposal does not fix it.

What the current probe actually does

- Reach v1 dispatches benchmark.probe_action_v6, which uses the v4 lifecycle with
  nonapproaching goal screening and the late15–26s goal window. It is not solely
  a fixed-time cancellation script. It tries WAIT on received active/owned motion
  at speed>=.08m/s and path gain>=.05m, plus bounded deadline cleanup at10/28s.
- GoalDispatcher keeps the original5s commitment from acceptance. The actual
  observation mask disables WAIT and replacement GOAL during that interval.
- The outward ordering first maximizes goal components and outward direction;
  when those values tie, its positive path-sum key selects the shorter route.
  There is no minimum goal distance or active-lifetime condition.
- Nav2's configured native xy tolerance is.25m. A short goal can return actual
  SUCCEEDED and release ownership before WAIT becomes legal. A later idle WAIT
  is legal, but GoalDispatcher._cancel immediately returns when goal_id is None.
- record_probe_v4_submission correctly describes an actually submitted step,
  but it latches the round's wait without checking an accepted/owned goal or
  native cancellation. Subsequent round logic holds that wait. This is input
  submission evidence only; the independent physical reader correctly refuses
  to invent native cancellation or eligible stopping evidence from it.
- A late goal at25s cannot be canceled by an actor WAIT until about30s after its
  commitment, leaving only two seconds before the fixed32-step end. That bounded
  opportunity does not itself guarantee an eligible moving anchor or completion.

The closed small result reports tb3 maximum speeds .2008393393 and .1996296529m/s
in the two corridors episodes, zero native-cancel events, and no eligible A/B
stop. Their final-linear-zero anchors have speeds around .022/.026m/s, below the
unchanged .05m/s eligibility threshold. Maximum speed somewhere in a task does
not establish movement at a later stop anchor. This observation is consistent
with the static competition above, but it does not identify which goal completed
when; a future bounded causal trace is required for that claim.

Why the earlier CPU fixtures did not expose it

The v4/v6 tests provide active/owned/accepted and waiting booleans directly. They
exercise mask respect, receipt binding and timing, including the known5s masked
case, but do not drive the real GoalDispatcher from acceptance through natural
SUCCEEDED into the real mask builder. Thus they do not prove that a selected
goal is still owned when the planned WAIT is delivered.

The new /tmp test_goal_lifecycle_v1.py directly uses the real GoalDispatcher and
mr3_observation._action_masks. The unchanged selector function source is compiled
privately to avoid mixing system SciPy with learner Gymnasium. One integrated
counterexample selects original legal .8m goals, observes movement with a real
commitment mask, delivers real SUCCEEDED callbacks before5s, then submits legal
deadline WAITs: all round waits latch and zero cancel_goal events are emitted.
A second conditional model selects legal3m goals, remains active at the first
legal moving WAIT at6s, and produces three matching cancel_goal events. Cancel
acceptance alone does not release ownership; only actual synthetic CANCELED
result callbacks do. This is a protocol fixture, never native/physical evidence.

Recommended explicit v2 stimulus

Keep every original mask, commitment, actor action, safety predicate and physical
eligibility threshold. Preserve v1 selector functions and their existing tests.
Register a distinct mr3-p2a-reach-outward-cancel-v2 and a distinct reset-workload
dispatch. New profile readers must retain the same immutable V17 mathematics and
whole-source inverse; an explicit version declaration is required at every entry.

Use a bounded subset of original legal received-map candidates. For the initial
screen require strict Euclidean distance greater than
.25 + .30*(5+1+2) =2.65m: native goal tolerance, declared planar speed bound, five
seconds of commitment, one decision period, and the maximum two-second command
TTL. This is a conditional stimulus viability screen, not a physical guarantee.
Path length alone is insufficient because a curved path does not imply a far
endpoint. Use current received coordinates, never WorldPose/truth. At the first
fresh active observation recheck residual goal distance against .25 plus .30
times the remaining commitment+1+2; acceptance callback latency is not bounded
by actor command TTL. A late or already completed goal fails viability; it never
gains cancellation credit or a silent replacement attempt.

Each robot receives at most one newly admitted goal per declared round, only
from idle and after the preceding handoff. Choose the first legal moving WAIT
after real acceptance and commitment, binding the exact current goal_id. Separate
planned, step-submitted, accepted/owned, cancel-request-observed and matching
CANCELED-terminal-observed states. A successful WAIT RPC or canceled-result for
another goal cannot latch a completed round. Actual adapter native_cancel and
the raw physical response remain independently audited from their real records.

Keep32 complete policy steps and at most two rounds/six admitted goals overall.
Round1 may admit within[0,1.5) and must be accepted by2s for the planned cancellation
budget; round2 may admit within[13,20) and must be accepted by20s. The planned final
native-cancel deadline is28s, leaving a finite four-second observation tail.
Retain the original10s first-round cleanup WAIT opportunity. These are stimulus
deadlines, not shorter RPC timeouts and not permission to bypass a commitment.
If an acceptance, legal long goal, moving-WAIT opportunity or actual cancellation
is missing, record bounded coverage-unavailable/FAIL and perform existing owned
cleanup. Do not choose a shorter goal, add unbounded attempts, extend the32 steps,
or promote cleanup WAIT into a successful stopping sample.

Before the next round require the received matching CANCELED terminal for that
goal, three fresh increasing-source rest observations, and at least3simseconds
after the first matching terminal observation. Continue KEEP/WAIT during that
handoff and retain the independent actual-cancel/physical-rest gates. Safe handoff
protects the subsequent window; it cannot explain or repair tb2's observed
3.031s/.259m B response, whose rest already preceded its next native goal.

Next work after formal closure

The proposal JSON is uninstalled and the local long-goal chooser is a fixture
precondition, not a production v2 implementation. Before a new native scope,
implement the explicit version and actual state transitions, then add integrated
cases for acceptance delay, success racing WAIT, rejection, missing cancel
terminal, stale/wrong-goal receipts, original masks, strict-distance boundaries,
rest-source freshness, terminal-to-handoff timing and all bounded failure exits.
Fresh source-sealed CPU and a new exact freeze must precede actual qualification.
Keep all12 episodes/30 roles, minimum/pilot/final roles,95% gates and old FAILs.
Do not rerun or relabel the old V60 activity or its scientific readers.

Final artificial CPU receipt: four tests PASS, actual tool16559 reaped rc0,
.770379798s child wait, nine bound sources before/after/current equal, eight
repository sources exact E, and both saved CPU PID/start identities freshgone.
Only /tmp artifacts were written. Engineering fee and qualification credit are0.
