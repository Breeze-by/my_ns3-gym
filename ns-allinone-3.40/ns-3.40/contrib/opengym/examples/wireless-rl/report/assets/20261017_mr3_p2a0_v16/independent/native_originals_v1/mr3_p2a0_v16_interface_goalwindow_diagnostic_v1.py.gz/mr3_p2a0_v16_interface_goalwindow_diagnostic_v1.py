"""Only 33 returned inputs: exact V5+real typed-submission CPU replay, no runtime imports."""
import ast
import copy
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
BENCHMARK = W / 'mr3_learning/benchmark.py'
EPISODE = ROOT / ('ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/'
                  'mr3_p2a0_20261017_v16_interface/worker0/episode001_open_101')
OUTPUT = Path('/tmp/mr3_p2a0_v16_interface_goalwindow_diagnostic_v1.json')
FREEZE = 'ebe7d51bdb7bf9d77a28b77cfb4296876afb0100'
INPUTS = {}


def sha(payload):
    return hashlib.sha256(payload).hexdigest()


def read(path):
    payload = path.read_bytes()
    INPUTS[str(path)] = sha(payload)
    return payload


def choices(action):
    return action // 100, action // 10 % 10, action % 10


def per_robot(actions):
    return {name: {'goal_components': sorted({choices(action)[index]
                                            for action in actions if choices(action)[index] < 8}),
                   'goal_action_count': sum(choices(action)[index] < 8 for action in actions)}
            for index, name in enumerate(('tb1', 'tb2', 'tb3'))}


def state_for_robot(snap, prior, index):
    robot = snap['robots'][index]
    elapsed = snap['task_elapsed_sec']
    first = prior.get('v4_stimulus', {}).get('rounds', {}).get('initial', {}).get('waits', {}).get(robot['name'])
    nav = robot['navigation']
    speed = robot.get('v')
    blockers = []
    if first is None:
        blockers.append('no_actual_initial_WAIT_command_record')
    elif elapsed - first['task_elapsed_sec'] < 3.:
        blockers.append('initial_WAIT_hold_less_than_3_seconds')
    if nav.get('phase') != 'idle':
        blockers.append('received_navigation_not_idle')
    if robot.get('fresh') is not True:
        blockers.append('received_state_not_fresh')
    if type(speed) not in (int, float) or not math.isfinite(speed):
        blockers.append('received_v_not_finite_number')
    elif abs(speed) > .01:
        blockers.append('received_abs_v_above_0.01')
    return {'name': robot['name'], 'first_actual_initial_WAIT': first,
            'elapsed_since_initial_WAIT': None if first is None else elapsed - first['task_elapsed_sec'],
            'received_v': speed, 'received_w': robot.get('w'), 'fresh': robot.get('fresh'),
            'valid': robot.get('valid'), 'source_stamp': robot.get('source_stamp'),
            'odom_source_stamp': robot.get('odom_source_stamp'), 'navigation': nav,
            'activity': robot['activity'], 'recovering_blockers_if_second_round': blockers,
            'per_robot_action_mask': snap['per_robot_action_mask'][index]}


started = time.monotonic()
result = {'schema': 'mr3-v16-interface-goalwindow-readonly-diagnostic-v1', 'passed': False,
          'scope': 'Diagnostic exact original V5 replay on completed returned snapshots and '
                   'actual returned command info. No new formal/native audit, no large raw scans, '
                   'no task/physical PASS assertion.', 'freeze': FREEZE}
try:
    benchmark = read(BENCHMARK)
    frozen = subprocess.check_output(['git', 'show', FREEZE + ':' + BENCHMARK.relative_to(ROOT).as_posix()], cwd=ROOT)
    if benchmark != frozen:
        raise ValueError('benchmark is not exact freeze bytes')
    metadata = json.loads(read(EPISODE / 'metadata.json'))
    if metadata['freeze'] != FREEZE:
        raise ValueError('episode metadata freeze differs')
    data = read(EPISODE / 'transitions.jsonl')
    if not data.endswith(b'\n'):
        raise ValueError('incomplete closed returned ledger')
    rows = [json.loads(line) for line in data.splitlines()]
    if len(rows) != 33 or rows[-1]['truncated'] is not True:
        raise ValueError('not complete32-step interface')
    selected = {'_probe_goal_order', 'probe_action', 'probe_action_v3', 'probe_action_v4',
                'probe_action_v5', '_probe_nonapproaching_goal_action', 'record_probe_v4_submission'}
    tree = ast.parse(benchmark)
    namespace = {'math': math}
    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in selected]
    exec(compile(ast.Module(body=functions, type_ignores=[]), str(BENCHMARK), 'exec'), namespace)
    captured = []

    def trace(frame, event, arg):
        if (event == 'return' and frame.f_code.co_name == 'probe_action_v4'
                and frame.f_globals is namespace):
            captured.append({name: copy.deepcopy(frame.f_locals[name])
                             for name in ('desired', 'reasons', 'legal', 'goal_window', 'round_id')})
        return trace

    diagnostics = {}
    returns, windows = [], []
    for index, row in enumerate(rows[:-1]):
        snap = row['snapshot']
        prior = copy.deepcopy(diagnostics)
        sys.settrace(trace)
        try:
            action = namespace['probe_action_v5'](snap, diagnostics)
        finally:
            sys.settrace(None)
        live = captured.pop()
        info = rows[index + 1]['info']
        if action != info['command']['action']:
            raise ValueError('pure replay differs from actual command')
        namespace['record_probe_v4_submission'](diagnostics, info)
        returns.append({'snapshot_sequence': snap['sequence'], 'elapsed': snap['task_elapsed_sec'],
                        'action': action, 'command_id': info['command']['command_id'],
                        'per_robot': {robot['name']: {'v': robot.get('v'), 'w': robot.get('w'),
                                     'fresh': robot.get('fresh'), 'navigation_phase': robot['navigation']['phase'],
                                     'accepted_goal_count': robot['navigation'].get('accepted_goal_count'),
                                     'estimated_path_m': robot['activity'].get('estimated_path_m')}
                                      for robot in snap['robots']}})
        if live['goal_window']:
            original = [action for action, valid in enumerate(snap['joint_action_mask']) if valid]
            lifecycle = [action for action in original
                         if all(choice in live['desired'][robot] for robot, choice in enumerate(choices(action)))]
            geometry_only = [action for action in original
                             if namespace['_probe_nonapproaching_goal_action'](snap, action)]
            filtered = [action for action, valid in enumerate(live['legal']) if valid]
            robot = snap['robots'][0]
            candidates = []
            for candidate_index, candidate in enumerate(snap['candidates']):
                if candidate_index >= 8:
                    continue
                gx, gy = candidate['x'] - robot['x'], candidate['y'] - robot['y']
                goal_distance = math.hypot(gx, gy)
                margins = {}
                for peer in snap['robots'][1:]:
                    px, py = peer['x'] - robot['x'], peer['y'] - robot['y']
                    denominator = goal_distance * math.hypot(px, py)
                    margins[peer['name']] = -(gx * px + gy * py) / denominator if denominator else None
                candidates.append({'candidate': candidate_index, 'x': candidate['x'], 'y': candidate['y'],
                                   'path_distance_m': candidate['path_distances_m'][0],
                                   'per_robot_original_GOAL_allowed': snap['per_robot_action_mask'][0][candidate_index],
                                   'original_joint_action_exists': any(choices(value)[0] == candidate_index for value in original),
                                   'lifecycle_joint_action_exists': any(choices(value)[0] == candidate_index for value in lifecycle),
                                   'nonapproach_geometry_for_tb1_goal_only': namespace['_probe_nonapproaching_goal_action'](snap, candidate_index * 100 + 88),
                                   'straight_outward_margins': margins,
                                   'final_filtered_joint_action_exists': any(choices(value)[0] == candidate_index for value in filtered)})
            windows.append({'snapshot_sequence': snap['sequence'], 'elapsed': snap['task_elapsed_sec'],
                            'chosen_action': action, 'actual_command_id': info['command']['command_id'],
                            'desired_component_sets': live['desired'], 'reasons': live['reasons'],
                            'stages': {name: {'allowed_joint_actions': len(values), 'per_robot': per_robot(values)}
                                       for name, values in (('original_mask', original), ('V4_lifecycle', lifecycle),
                                                            ('nonapproach_on_original_mask_only', geometry_only),
                                                            ('final_V5_subset', filtered))},
                            'tb1_recovery_inputs': state_for_robot(snap, prior, 0),
                            'tb1_candidate_geometry': candidates,
                            'actual_goal_diagnostic': diagnostics['goal_decisions'][-1]})
    result.update(passed=True, all32_replayed_actions_equal_actual_command=True,
                  replayed_returns=returns, goal_windows=windows,
                  final_snapshot_robots=rows[-1]['snapshot']['robots'],
                  actual_submitted_WAIT_latches=diagnostics['v4_stimulus']['rounds'],
                  source_before_after_stable=all(sha(Path(path).read_bytes()) == digest
                                                 for path, digest in INPUTS.items()))
    if not result['source_before_after_stable']:
        raise ValueError('read-only inputs changed')
except Exception as error:
    result['passed'] = False
    result['error'] = type(error).__name__ + ': ' + str(error)
result['input_sha256'] = INPUTS
result['wall_seconds'] = time.monotonic() - started
result['tool_sha256'] = sha(Path(__file__).read_bytes())
with OUTPUT.open('x') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
print(json.dumps({'output': str(OUTPUT), 'sha256': sha(OUTPUT.read_bytes()),
                  'passed': result['passed'], 'error': result.get('error'),
                  'windows': [{'elapsed': row['elapsed'], 'chosen_action': row['chosen_action'],
                               'TB1_blockers': row['tb1_recovery_inputs']['recovering_blockers_if_second_round'],
                               'TB1_v': row['tb1_recovery_inputs']['received_v'],
                               'TB1_phase': row['tb1_recovery_inputs']['navigation']['phase'],
                               'counts': {key: value['allowed_joint_actions'] for key, value in row['stages'].items()}}
                              for row in result.get('goal_windows', [])]}, indent=2))
raise SystemExit(0 if result['passed'] else 1)
