# V18 observer v3 独立只读复核

对象为patch8276a4ec/sourcefbc9c228，未改作者目录或canonical，未启动native/formal。分离插件、默认不插入SDF及有限noninterference措辞合理；尚不能据此宣称实际solver参数来源完整。

**必须窄修 R1**：configuration只经GetParam读取。官方11.10.2的iters/sor/CFM/ERP等来自SDF缓存，v3没有GetWorldId/dWorldGet原生getter；设计把它们统称actual过强。建议新版本分开cached与native参数，直接读ODE world并绑定实际engine/library。此为证据不足，不是已证当前native参数错误。

**建议窄补 R2/R3**：post除clock外再核同iteration；显式处理double非有限值。独立微型CPU已证nlohmann把available:true/NaN写成value:null，不能把它读成0或健康；未声称原生solver有NaN。

正向核验：patch独立重建完全同；原driver四源/原CMake快照和canonical相等；正常model/launch均无该plugin。origin/CoG API字段正确，vel/fmax是电机参数、GetForce不是反力/ACK的限定正确。weak callback在返回前持有State；但未作native生命周期证明。wx独占及fwrite/每pair fflush检查会把错误变成诊断infra failure；未捕获异常可能终止engine，不能称无害。设计已准确保留JSON/IO造成wall与回调负载的限制。

正式准入仍需actual observer ELF/compiled macro/库SHA/路径/PIDstart/maps绑定、generated SDF只增observer的逆差分、a014原driver重建后字节验证，以及真正任务窗口内完整finite的1ms pre/post reader。示例0..10秒可能仅覆盖warmup。源只提供world residual/contact count，不能定位单个地面接触；desired/target/actuation仍需从原driver账本真实因果绑定，不可伪造private seq。

32step/1800wall baseline及可选iters150/1800wall均只是事前设计，尚无GO实验。迭代对比必须保持同observer及其他物理/control值，实际原生getter证实150；原.01/三样本/.78/.144/95%等门和V17真FAIL保持。新baseline只诊断，不授完整四stage/P2A.0信用。

详见同名JSON的逐字段/行号证据、source before/after SHA和独立非有限值CPU回执。此结论只适用于v3，不自动替代作者后续新版本复核。
