import hashlib
import json
from pathlib import Path
import time
from types import SimpleNamespace
from test_record_equivalence_v2 import original,candidate

A=Path(__file__).parent
payload={'robots':[{'name':f'tb{i}','odometry':{'pose':{'position':{'x':float(i),'y':0.,'z':0.},'covariance':[0.]*36},'twist':{'linear':[0.,0.,0.],'angular':[0.,0.,0.],'covariance':[0.]*36}},'checks':{'valid':True,'causal':True,'admitted_signs':[-1,1],'output':[0.,-0.]}} for i in range(1,4)]}

class Audit:
    def __init__(self):
        self.digest=hashlib.sha256();self.bytes=0
    def write(self,text):
        raw=text.encode();self.bytes+=len(raw);self.digest.update(raw)

results=[]
for repeat in range(3):
    outputs=[]
    for label,function in [('original',original),('candidate',candidate)]:
        owner=SimpleNamespace(audit=Audit(),epoch='finite-kernel',record_sequence=0,now=lambda:12.5)
        start=time.perf_counter_ns()
        for _ in range(2000):function(owner,'artificial_record',payload)
        elapsed=time.perf_counter_ns()-start
        outputs.append(dict(implementation=label,calls=2000,elapsed_ns=elapsed,bytes=owner.audit.bytes,sha256=owner.audit.digest.hexdigest(),sequence=owner.record_sequence))
    assert all(outputs[0][k]==outputs[1][k] for k in ['bytes','sha256','sequence'])
    results.append(outputs)
result=dict(passed=True,scope='AST-extracted actual record methods on fixed artificial finite payload; elapsed kernel cost with digest sink, no filesystem/ROS/native/throughput credit',results=results,native_runs=0,capacity_qualified=False)
(A/'benchmark_record_result_v1.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
