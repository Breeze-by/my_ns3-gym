import json,sys
sys.path.insert(0,sys.argv[1])
import test_proposal as test
value=test.state();value["v"]=.2
print(json.dumps({"state":value,"helper_error":test.NEW.measured_velocity_error(value),"valid_state":test.NEW.valid_state(value,10.,test.EPOCH)},sort_keys=True,allow_nan=False))
