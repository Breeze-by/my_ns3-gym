import hashlib,json,os,pathlib,subprocess,time,datetime
root=pathlib.Path("/home/zhuyulab/ns3-workspace")
helper=pathlib.Path("/tmp/mr3_p2a0_v15_archive_offline_originals_v1.py")
plan=root/"ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v15/predeclared_plan_v15.json"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(helper)=="b828135cfb2123fe816bb00c1c2e26da67445675cb9d4062c1279ceca1b32b70"
assert sha(plan)=="fc52f0e5a632ba8114a68da73f2ee048408a3f795609351469f446a88ab68804"
argv=["/usr/bin/python3",str(helper),"--writers-stopped"]
env=os.environ.copy();env.pop("PYTHONPATH",None);env.update(PYTHONNOUSERSITE="1",PYTHONDONTWRITEBYTECODE="1")
console=pathlib.Path("/tmp/mr3_p2a0_v15_offline_publish_v1.log")
receipt=pathlib.Path("/tmp/mr3_p2a0_v15_offline_publish_receipt_v1.json")
assert not console.exists() and not receipt.exists()
start=datetime.datetime.now(datetime.timezone.utc).isoformat(); begin=time.monotonic()
with console.open("xb") as stream:
 result=subprocess.run(argv,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT,check=False)
wall=time.monotonic()-begin
record={"argv":argv,"cwd":str(root),"env":{"PYTHONPATH":"unset","PYTHONNOUSERSITE":"1","PYTHONDONTWRITEBYTECODE":"1"},"started_utc":start,"ended_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"returncode":result.returncode,"wall_seconds":wall,"console":str(console),"console_sha256":sha(console),"helper_sha256":sha(helper),"plan_sha256":sha(plan),"plan_unchanged":sha(plan)=="fc52f0e5a632ba8114a68da73f2ee048408a3f795609351469f446a88ab68804"}
with receipt.open("x") as stream:json.dump(record,stream,indent=2);stream.write("\n")
print(json.dumps(record,indent=2));print(console.read_text())
raise SystemExit(result.returncode)
