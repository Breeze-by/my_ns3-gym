"""Independent few-case fake-proc review; never inspect/control native DDS."""

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from unittest import mock


SOURCES = Path('/tmp/mr3_p2a0_v13_shim_observer_review_sources_v1')
SPEC = importlib.util.spec_from_file_location(
    'preserved_shim_tests', SOURCES / 'mr3_readonly_v13_drive_shim_process_monitor_tests.py')
T = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(T)
M = T.M
SHA = lambda raw: hashlib.sha256(raw).hexdigest()
before = {str(path): SHA(path.read_bytes()) for path in SOURCES.iterdir() if path.is_file()}
checks = []


with tempfile.TemporaryDirectory() as temporary:
    fixture = T.Fixture(Path(temporary))
    actual_worker = ['/usr/bin/python3',
                     str(M.REPO / 'ros2_ws/ros2-multi-robot-automap/scripts/mr3_env_worker.py'),
                     '--run-dir', str(fixture.ep)]
    fixture.base['owned_current_processes'][1]['argv'] = actual_worker
    fixture.command(fixture.worker['pid'], actual_worker)
    first = fixture.inspect()
    assert first['complete']
    other = fixture.root / 'worker4/episode009_open_101'
    other.mkdir(parents=True)
    (other / 'metadata.json').write_text(json.dumps(
        {'freeze': fixture.base['freeze'], 'epoch': 'different-epoch'}))
    (other / 'supervisor_metadata.json').write_text(json.dumps(
        {'epoch': 'different-epoch', 'worker_identity': fixture.worker}))
    fixture.base['episodes'].append({'directory': str(other)})
    rows = M.inspect_episodes(fixture.base, fixture.binding, fixture.proc)
    assert rows[0]['complete'] and rows[1]['complete']
    checks.append({'case': 'actual_worker_run_dir_cannot_prove_a_different_episode',
                   'expected': 'second episode incomplete/rejected',
                   'observed': 'both different-epoch directories complete from same worker',
                   'counterexample_confirmed': True,
                   'actual_worker_argv': actual_worker,
                   'episode_results': rows})

with tempfile.TemporaryDirectory() as temporary:
    fixture = T.Fixture(Path(temporary))
    for row in fixture.base['owned_current_processes']:
        fixture.stat(dict(row['identity'], state='S'))
    result = fixture.inspect()
    assert result['complete']
    checks.append({'case': 'ordinary_R_to_S_does_not_change_identity', 'passed': True})

with tempfile.TemporaryDirectory() as temporary:
    fixture = T.Fixture(Path(temporary))
    replacement = fixture.root / 'replacement.bin'
    replacement.write_bytes(b'different mapped bytes, not the declared library')
    replacement_stat = replacement.stat()
    fixture.maps(fixture.controllers['tb1']['pid'], inode=replacement_stat.st_ino)
    original_read = M.stable_bytes

    def replace_after_the_stable_read(path):
        raw = original_read(path)
        if Path(path) == fixture.library:
            replacement.replace(fixture.library)
        return raw

    captured = next(row for row in fixture.base['owned_current_processes']
                    if row['identity']['pid'] == fixture.controllers['tb1']['pid'])
    inventory = {row['identity']['pid']: row['identity']
                 for row in fixture.base['owned_current_processes']}
    with mock.patch.object(M, 'stable_bytes', side_effect=replace_after_the_stable_read):
        result = M.mapped_controller(captured, inventory, fixture.worker,
                                     fixture.library_proof, fixture.proc)
    assert result['valid']
    actual_sha = SHA(fixture.library.read_bytes())
    assert actual_sha != fixture.library_proof['sha256']
    checks.append({'case': 'hash_read_and_separate_stat_can_bind_different_inodes',
                   'expected': 'reject changed library byte/inode custody',
                   'counterexample_confirmed': True,
                   'scope': 'Constructed fake-proc/file-replacement race, not observed native '
                            'or evidence that installed files changed.',
                   'observed_valid': result['valid'],
                   'claimed_sha256': result['mappings'][0]['sha256'],
                   'actual_disk_sha256_after': actual_sha,
                   'claimed_mapping_inode': result['mappings'][0]['inode']})

binding = M.check_binding(SOURCES / 'mr3_v13_shim_binding_v1.json')
checks.append({'case': 'actual_installed_header_ELF_XML_package_and_tag_binding',
               'passed': set(binding['files']) == set(M.EXPECTED), 'binding': binding})

with tempfile.TemporaryDirectory() as temporary:
    directory = Path(temporary)
    output = directory / 'snapshot.json'
    base = {'owned_current_processes': [], 'episodes': [], 'freeze': 'a' * 40,
            'typed_original_fields': [False, 0, 0., '0', None, {'x': -0.0}]}
    requests = []

    def original_base_call(argv, **kwargs):
        requests.append(argv)
        Path(argv[argv.index('--output') + 1]).write_text(json.dumps(base))
        return subprocess.CompletedProcess(argv, 0, b'base-output', b'')

    argv = [str(SOURCES / 'mr3_readonly_v13_drive_shim_process_monitor.py'), str(directory),
            '--launch', str(directory / 'launch.json'),
            '--binary-proof', str(directory / 'binary.json'),
            '--shim-binding', str(SOURCES / 'mr3_v13_shim_binding_v1.json'),
            '--output', str(output)]
    with mock.patch.object(sys, 'argv', argv), \
            mock.patch.object(M.subprocess, 'run', side_effect=original_base_call):
        M.main()
    actual = json.loads(output.read_bytes())
    supplement = actual.pop('shim_mapping')
    canonical = lambda x: json.dumps(x, sort_keys=True, separators=(',', ':'), allow_nan=False)
    assert canonical(actual) == canonical(base)
    assert requests[0][1] == str(M.BASE) and SHA(M.BASE.read_bytes()) == M.BASE_SHA
    checks.append({'case': 'main_preserves_every_original_A10_JSON_field_and_type',
                   'passed': True, 'base_source_sha256': M.BASE_SHA,
                   'actual_delegated_argv': requests[0],
                   'scope': 'Mocked original-base output, actual wrapper main; '
                            'no host proc scan or native snapshot credit',
                   'base_sha256': SHA(canonical(base).encode()),
                   'supplement_keys': sorted(supplement)})

after = {str(path): SHA(path.read_bytes()) for path in SOURCES.iterdir() if path.is_file()}
assert before == after
result = {'schema': 'mr3-v13-shim-observer-independent-review-v1',
          'scope': 'Independent few fake-proc/interface cases and actual disk binding reads. '
                   'No ROS/DDS, signal, native process or production/observer source edits. '
                   'Old observer and author tests were copied before review, then byte-stable.',
          'original_source_bindings': before, 'sources_unchanged': before == after,
          'checks': checks,
          'blocking_findings': ['Bind actual worker command --run-dir to each episode; '
                                'current observer accepts a different-epoch directory borrowing '
                                'one actual worker snapshot.',
                                'Use the same file identity associated with hashed bytes for '
                                'map device/inode comparison; the separate post-read stat can '
                                'be for a replaced file. This race is synthetic, not native evidence.'],
          'credit_boundary': 'Independent tag identity is separate from installed ELF identity; '
                             'neither proves source-to-ELF compilation or controller/body execution.'}
output = Path('/tmp/mr3_p2a0_v13_shim_observer_independent_review_v1.json')
output.write_text(json.dumps(result, sort_keys=True, indent=2, allow_nan=False) + '\n')
print(json.dumps({'output': str(output), 'counterexample_count': 2,
                  'source_sha256': before[str(SOURCES / 'mr3_readonly_v13_drive_shim_process_monitor.py')],
                  'output_sha256': SHA(output.read_bytes())}))
