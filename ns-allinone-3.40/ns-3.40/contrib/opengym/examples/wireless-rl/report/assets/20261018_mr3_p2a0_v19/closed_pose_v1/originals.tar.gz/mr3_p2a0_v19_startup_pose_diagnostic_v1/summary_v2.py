import hashlib
import json
import math
from pathlib import Path

ROOT=Path(__file__).parent


def ref(path):
    raw=path.read_bytes()
    return {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def main():
    global_path=ROOT/'review_v1.json'
    relative_path=ROOT/'relative_age_v2/review_v1.json'
    endpoint_path=Path('/tmp/mr3_p2a0_v19_endpoint_pose_diagnostic_v1/review_v1.json')
    g=json.loads(global_path.read_bytes());r=json.loads(relative_path.read_bytes());e=json.loads(endpoint_path.read_bytes())
    rows=[]
    for stage in ('baseline','iters150'):
        samples=[v for row in r['results'] if row['stage']==stage for selected in row['samples'] if selected['available'] for v in selected['samples']]
        zs=[v['base']['world_pose']['position_xyz'][2] for v in samples]
        rps=[v['base']['rpy_degrees'] for v in samples]
        predictions=[v['declared_ray_frame_prediction']['ground_intersection_range_m'] for v in samples]
        finite_predictions=[v for v in predictions if v is not None]
        assert all(math.isfinite(v) and v>0 for v in finite_predictions)
        rows.append({'stage':stage,'sampled_first_pair_relative_ages_ns':[200000000,400000000,600000000,1000000000,2000000000,3000000000],
                     'sampled_phase_rows':len(samples),'min_max_base_z_m':[min(zs),max(zs)],
                     'max_abs_roll_deg':max(abs(v[0]) for v in rps),'max_abs_pitch_deg':max(abs(v[1]) for v in rps),
                     'minimum_predicted_horizontal_ray_ground_intersection_m':min(finite_predictions),
                     'exactly_horizontal_predictions_without_ground_intersection':sum(v is None for v in predictions),
                     'max_fixed_base_relative_canonical_position_norm_m':max(math.sqrt(sum(x*x for x in v['base_relative_canonical']['position_xyz'])) for v in samples),
                     'all_sampled_motor_targets_zero':all(j['motor_velocity_target_radps']==0 for v in samples for j in v['joints_right_left']),
                     'max_abs_sampled_actual_wheel_radps':max(abs(j['velocity_radps']) for v in samples for j in v['joints_right_left'])})
    summary={'schema':'mr3-v19-bounded-pose-description-summary-v2','freeze':e['freeze'],
             'passed':True,'pass_scope':'Extraction/source identity only; original physicalFalse retained and no unique causal/matrix acceptance credit.',
             'references':[ref(p) for p in [endpoint_path,global_path,relative_path,ROOT/'slam_startup_source_review_v1.json',ROOT/'summary_initial_error_v1.json']],
             'bounded_large_raw_read_bytes':{'endpoint':sum(x['io']['bytes_read_including_binary_probes'] for x in e['results']),
                                             'fixed_global_startup':g['total_large_raw_bytes_read'],
                                             'first_pair_relative_age':r['total_large_raw_bytes_read'],
                                             'total':sum(x['io']['bytes_read_including_binary_probes'] for x in e['results'])+g['total_large_raw_bytes_read']+r['total_large_raw_bytes_read']},
             'full_source_raw_sha_scope':'Six raw SHA inherited from two completed e61c formal and closed-custody manifests; selected original line bytes independently hashed with absolute offsets and fd/path stat before/after.',
             'per_stage_sampled_relative_age_summary':rows,
             'conclusion':'Selected endpoint and startup states show small upright pitch/roll and millimetric initial settling, without evidence of a toppled or grossly lowered robot. Contrast early .4s-age pitch is higher than baseline (.7948deg vs .6426deg), and a declared-frame ray can reach ground at about9.34m within10m sensor range; these predictions do not directly explain .05/.1m seed-adjacent occupancy. Actual scans and intervening extrema remain unmeasured here.',
             'slam_startup':'Frozen launch starts each SLAM node with its own spawn action and has no height/attitude settle gate; active derived laserCallback submits available odom+laser scans directly to addScan/Karto. Exact per-scan ingestion is not archived by selected logs.',
             'new_native_calls':0,'new_formal_audits':0,'canonical_writes':0,'writers_stop_after_manifest':True}
    output=ROOT/'summary_v2.json'
    with output.open('x') as stream:
        json.dump(summary,stream,indent=2);stream.write('\n')
    print(json.dumps({'summary':ref(output),'rows':rows,'total_large_read_bytes':summary['bounded_large_raw_read_bytes']['total']},indent=2))


if __name__=='__main__':main()
