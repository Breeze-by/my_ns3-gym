import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path('/home/zhuyulab/ns3-workspace')
TARGET = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v20_sensor/closed_source_reviews_v1'
assert not TARGET.exists()
manifest = Path('/tmp/mr3_p2a0_v20_sensor_ray_geometry_source_review_v1/manifest_v2.json')
ray = json.loads(manifest.read_text())
assert ray['writers'] == 'STOP'
files = [Path(row['path']) for row in ray['files']]
for row in ray['files']:
    assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest() == row['sha256']
files += [manifest, Path('/tmp/mr3_p2a0_v20_interval_semantic_review_v1.json'),
          Path('/tmp/mr3_p2a0_v20_interval_semantic_review_v1/manifest_v1.json'),
          Path('/tmp/mr3_p2a0_v20_interval_semantic_review_v1.tar.gz'), Path(__file__)]
assert hashlib.sha256(files[-2].read_bytes()).hexdigest() == '38db36d6f810f18082a20f728430fb585baca1c0a4cbf4168aaf401f7702dbfd'
buffer = io.BytesIO()
entries = []
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for path in sorted(set(files)):
        before = path.stat()
        raw = path.read_bytes()
        info = tarfile.TarInfo(str(path.relative_to('/tmp')))
        info.size, info.mtime, info.mode = len(raw), 0, 0o644
        archive.addfile(info, io.BytesIO(raw))
        entries.append({'source': str(path), 'member': info.name, 'bytes': len(raw),
                        'sha256': hashlib.sha256(raw).hexdigest(),
                        'stat': [before.st_dev, before.st_ino, before.st_size,
                                 before.st_mtime_ns, before.st_ctime_ns]})
encoded = gzip.compress(buffer.getvalue(), compresslevel=6, mtime=0)
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(encoded))) as archive:
    assert archive.getnames() == [row['member'] for row in entries]
    for row in entries:
        assert hashlib.sha256(archive.extractfile(row['member']).read()).hexdigest() == row['sha256']
        path = Path(row['source'])
        value = path.stat()
        assert [value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns] == row['stat']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
TARGET.mkdir()
(TARGET / 'originals.tar.gz').write_bytes(encoded)
result = {'schema': 'mr3-v20-source-review-custody-v1',
          'scope': 'Read-only ray geometry review and interval semantic correction. Failed isolated SDK regression, all compile failures and one gdb rerun retained in nested original tar; no production change or SDK PASS.',
          'files': entries, 'original_count': len(entries),
          'original_bytes': sum(row['bytes'] for row in entries),
          'archive': 'originals.tar.gz', 'archive_bytes': len(encoded),
          'archive_sha256': hashlib.sha256(encoded).hexdigest(),
          'full_roundtrip_and_source_final_sha_stat_verified': True}
(TARGET / 'manifest_v1.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('original_count', 'original_bytes', 'archive_bytes', 'archive_sha256')}))
