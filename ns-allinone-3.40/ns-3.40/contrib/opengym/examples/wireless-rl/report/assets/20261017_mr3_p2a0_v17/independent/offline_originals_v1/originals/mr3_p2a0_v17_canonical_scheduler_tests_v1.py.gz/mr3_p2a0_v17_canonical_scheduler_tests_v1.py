import pathlib,importlib.util,unittest
p=pathlib.Path("/home/zhuyulab/ns3-workspace/ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v17/independent/mr3_p2a0_v17_audit_stage_tests_v1.py")
spec=importlib.util.spec_from_file_location("canonical_v17_scheduler",p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.OLD_PLAN=pathlib.Path("/tmp/mr3_p2a0_v17_matrix_draft_v1/predeclared_plan_v17.json")
s=unittest.defaultTestLoader.loadTestsFromModule(m);assert s.countTestCases()==9
r=unittest.TextTestRunner(verbosity=2).run(s);raise SystemExit(0 if r.wasSuccessful() else 1)
