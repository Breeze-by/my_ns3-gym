"""Static-only shadow generator. It never writes to the checkout."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path('/home/zhuyulab/ns3-workspace')
HERE = Path(__file__).resolve().parent
PACKAGE = Path('ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/multi_robot_exploration')
LAUNCH = Path('ros2_ws/ros2-multi-robot-automap/src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py')
paths = [PACKAGE/'mr3_adapter.py', PACKAGE/'motion_safety.py', LAUNCH]
originals = {str(p): (ROOT/p).read_text() for p in paths}
shadow = dict(originals)


def change(path, old, new):
    path = str(path)
    assert shadow[path].count(old) == 1, (path, old[:80], shadow[path].count(old))
    shadow[path] = shadow[path].replace(old, new)


A = PACKAGE/'mr3_adapter.py'
change(A, 'import copy\n', 'import copy\nimport hashlib\n')
change(A, 'from multi_robot_exploration.mr3_information import map_digest, map_payload',
       'from multi_robot_exploration.mr3_information import map_digest, map_payload, publisher_graph_identity\n'
       'from multi_robot_exploration.mr3_motion_authority import (\n'
       '    PROFILE as AUTHORITY_PROFILE, ACK as AUTHORITY_ACK, canonical,\n'
       '    from_accepted_owner, from_canceling_owner, from_terminal_owner, renewal_from_owner,\n'
       ')\nfrom multi_robot_exploration.mr3_safety_intent import parse_json')
change(A, '        self.stepped_mode = self.declare_parameter("stepped_mode", False).value\n', '''        self.stepped_mode = self.declare_parameter("stepped_mode", False).value
        safety_contract = self.declare_parameter("safety_contract", "legacy").value
        self.motion_authority_profile = self.declare_parameter("motion_authority_profile", "").value
        expected_authority = AUTHORITY_PROFILE if safety_contract == "mr3-reach-v1" else ""
        if (safety_contract not in ("legacy", "mr3-reach-v1")
                or self.motion_authority_profile != expected_authority
                or expected_authority and not self.stepped_mode):
            raise ValueError("fixed receiving-authority profile differs from safety contract")
''')
change(A, '        self.handles = {}\n', '''        self.handles = {}
        self.authority_sequence = dict.fromkeys(ROBOTS, 0)
        self.authority_packet = dict.fromkeys(ROBOTS)
        self.authority_grant = dict.fromkeys(ROBOTS)
        self.authority_ready = dict.fromkeys(ROBOTS)
        self.authority_ack_sequence = dict.fromkeys(ROBOTS, 0)
        self.authority_last_ack = dict.fromkeys(ROBOTS)
        self.authority_ack_gids = {}
        self.authority_pending_accept = {}
        self.authority_buffered_terminal = {}
''')
change(A, '        timer_clock = Clock(clock_type=ClockType.STEADY_TIME) if self.stepped_mode else None\n', '''        self.authority_publishers = {}
        if self.motion_authority_profile:
            authority_qos = QoSProfile(depth=64, durability=DurabilityPolicy.TRANSIENT_LOCAL)
            self.authority_publishers = {name: self.create_publisher(
                String, f"/{name}/mr3/motion_authority", authority_qos) for name in ROBOTS}
            self.subscriptions_.extend(self.create_subscription(
                String, f"/{name}/mr3/motion_authority_ack",
                lambda message, name=name: self.receive_authority_ack(message, name), authority_qos)
                for name in ROBOTS)
            self.record("authority_configuration", {
                "motion_authority_profile": self.motion_authority_profile,
                "six_navigation_phases_unchanged": True, "worker_quantum_ack_barrier": False,
                "raw_goal_generation": None, "raw_goal_association": "UNKNOWN_UNSTAMPED_TWIST"})
        timer_clock = Clock(clock_type=ClockType.STEADY_TIME) if self.stepped_mode else None
''')
methods = '''    def publish_authority(self, packet):
        name = packet["robot"]
        encoded = canonical(packet)
        # This event names a successful publication call, never a delivery.
        self.authority_publishers[name].publish(String(data=encoded))
        self.authority_sequence[name] = packet["authority_sequence"]
        self.authority_packet[name] = copy.deepcopy(packet)
        self.authority_ready[name] = None
        self.record("authority_publication", {"robot": name, "packet": packet,
            "raw_json": encoded, "packet_sha256": hashlib.sha256(encoded.encode()).hexdigest(),
            "clock_ns": self.get_clock().now().nanoseconds, "scope": "publication_call_returned"})

    def receive_authority_ack(self, message, name):
        try:
            packet = parse_json(message.data)
            identity = publisher_graph_identity(self, f"/{name}/mr3/motion_authority_ack",
                "motion_safety", "/", self.authority_ack_gids.get(name))
            now_ns = self.get_clock().now().nanoseconds
            self.record("authority_ack_callback", {"robot": name, "message": packet,
                "raw_json": message.data, "publisher_identity": identity, "clock_ns": now_ns})
            keys = {"schema", "profile", "epoch", "robot", "ack_sequence", "clock_ns",
                    "authority_packet_sha256", "ack"}
            if (type(packet) is not dict or set(packet) != keys
                    or packet["schema"] != "mr3-motion-authority-ack-wire-v1"
                    or packet["profile"] != AUTHORITY_PROFILE or packet["epoch"] != self.epoch
                    or packet["robot"] != name or not identity["valid"]
                    or type(packet["ack_sequence"]) is not int or packet["ack_sequence"] <= 0
                    or type(packet["clock_ns"]) is not int or not 0 <= packet["clock_ns"] <= now_ns):
                raise ValueError("invalid receiving-authority ACK")
            self.authority_ack_gids[name] = identity["endpoints"][0]["endpoint_gid"]
            if packet["ack_sequence"] == self.authority_ack_sequence[name]:
                if packet != self.authority_last_ack[name]:
                    raise ValueError("conflicting duplicate receiving-authority ACK")
                return
            if packet["ack_sequence"] < self.authority_ack_sequence[name]:
                return
            self.authority_ack_sequence[name] = packet["ack_sequence"]
            self.authority_last_ack[name] = copy.deepcopy(packet)
            ack = packet["ack"]
            if (type(ack) is not dict or ack.get("schema") != AUTHORITY_ACK
                    or ack.get("epoch") != self.epoch or ack.get("robot") != name
                    or type(ack.get("authority_sequence")) is not int or ack["authority_sequence"] < 0):
                raise ValueError("authority ACK context differs")
            current = self.authority_packet[name]
            expected_hash = None if current is None else hashlib.sha256(canonical(current).encode()).hexdigest()
            if (ack.get("authority_sequence") != self.authority_sequence[name]
                    or packet["authority_packet_sha256"] != expected_hash):
                self.record("authority_ack_stale", {"robot": name, "ack_sequence": packet["ack_sequence"]})
                return
            if ack.get("stage") == "stop_obligation_ready":
                witness = ack.get("witness")
                if (set(ack) != {"schema", "epoch", "robot", "stage", "authority_sequence",
                                 "owner", "received_clock_ns", "witness"}
                        or type(witness) is not dict
                        or witness.get("schema") != "mr3-normal-zero-authority-witness-v1"
                        or witness.get("epoch") != self.epoch
                        or witness.get("robot") != name or witness.get("clock_ns") != packet["clock_ns"]
                        or current is not None and current["operation"] != "revoke"
                        or (ack["received_clock_ns"] is not None and
                            (type(ack["received_clock_ns"]) is not int or
                             not 0 <= ack["received_clock_ns"] <= packet["clock_ns"]))
                        or ack.get("owner") != current):
                    raise ValueError("stop readiness does not match current receiving owner")
                self.authority_ready[name] = copy.deepcopy(packet)
            else:
                if (set(ack) != {"schema", "epoch", "robot", "stage", "authority_sequence",
                        "accepted", "state", "received_clock_ns", "source_clock_ns", "callback_floor", "scope"}
                        or ack.get("stage") != "authority_received" or ack.get("accepted") is not True
                        or current is None or ack.get("source_clock_ns") != current["source_clock_ns"]
                        or type(ack.get("received_clock_ns")) is not int
                        or not current["source_clock_ns"] <= ack["received_clock_ns"] <= packet["clock_ns"]
                        or type(ack.get("callback_floor")) is not int or ack["callback_floor"] < 0
                        or ack.get("state") != ("REVOKED" if current["operation"] == "revoke" else "ACTIVE")):
                    raise ValueError("authority callback rejected")
        except (ValueError, KeyError, TypeError, AttributeError) as error:
            self.record("invalid_authority_ack", {"robot": name, "raw_json": message.data, "reason": str(error)})
            self.stop_requested = True
            self.dispatcher.safety_stop(self.now(), "invalid_motion_authority_ack")

    def authority_after_receipt(self, envelope, now):
        event, name = envelope.payload, envelope.source
        goal_id, kind = event["goal_id"], event["type"]
        if kind == "accept":
            outcome = self.dispatcher.on_accept(name, goal_id, event["value"], now)
            if outcome == "active":
                self.authority_pending_accept[name] = goal_id
            return
        grant = self.authority_grant[name]
        if (kind == "result" and grant is not None and goal_id == grant["goal_id"]
                and self.dispatcher.states[name].goal_id == goal_id and event["value"] in (4, 5, 6)):
            current = self.authority_packet[name]
            if current["operation"] != "revoke":
                packet = from_terminal_owner(self.dispatcher, grant, self.authority_sequence[name]+1,
                    timestamp_ns(now), terminal_goal_id=goal_id, status=event["value"])
                self.publish_authority(packet)
            if self.dispatcher.states[name].phase == "canceling":
                saved = envelope.to_dict()
                old = self.authority_buffered_terminal.get(name)
                if old is not None and old != saved:
                    raise ValueError("conflicting buffered native terminal")
                self.authority_buffered_terminal[name] = copy.deepcopy(saved)
                self.record("authority_terminal_buffered", {"robot": name, "goal_id": goal_id,
                    "delivery": saved, "authority_sequence": self.authority_sequence[name],
                    "buffered_clock_ns": timestamp_ns(now), "receipt_times_rewritten": False})
                return
        {"result": self.dispatcher.on_result, "cancel": self.dispatcher.on_cancel_response}[kind](
            name, goal_id, event["value"], now)

    def poll_authority_handoff(self, now):
        # No wait blocks ROS or physical stepping. The unchanged cancel timeout applies.
        for name, saved in list(self.authority_buffered_terminal.items()):
            ready = self.authority_ready[name]
            if ready is None:
                continue
            event = saved["payload"]
            if self.dispatcher.states[name].goal_id != event["goal_id"]:
                raise ValueError("buffered terminal no longer owns dispatcher")
            self.record("authority_terminal_dispatched", {"robot": name, "goal_id": event["goal_id"],
                "original_delivery": saved, "matching_ready_ack": ready,
                "dispatch_clock_ns": timestamp_ns(now), "receipt_times_rewritten": False})
            self.dispatcher.on_result(name, event["goal_id"], event["value"], now)
            del self.authority_buffered_terminal[name]
        for name, goal_id in list(self.authority_pending_accept.items()):
            state = self.dispatcher.states[name]
            if state.goal_id != goal_id or state.cancel_requested or state.phase != "active":
                del self.authority_pending_accept[name]
                continue
            if self.authority_ready[name] is not None and not self.stop_requested:
                packet = from_accepted_owner(self.dispatcher, name, self.handles,
                    self.authority_sequence[name]+1, timestamp_ns(now), accepted_goal_id=goal_id)
                self.publish_authority(packet)
                self.authority_grant[name] = copy.deepcopy(packet)
                del self.authority_pending_accept[name]

'''
change(A, '    def receipt(self, kind, robot, goal_id, value):\n', methods+'    def receipt(self, kind, robot, goal_id, value):\n')
change(A, '                self.dispatcher.renew(name, goal_id, self.epoch, now, event["expires_at"])\n', '''                self.dispatcher.renew(name, goal_id, self.epoch, now, event["expires_at"])
                grant = self.authority_grant[name] if self.motion_authority_profile else None
                current = self.authority_packet[name] if grant is not None else None
                state = self.dispatcher.states[name]
                if (current is not None and current["operation"] != "revoke"
                        and state.goal_id == grant["goal_id"] and state.phase == "active"
                        and not state.cancel_requested and timestamp_ns(state.lease_until) > current["lease_until_ns"]):
                    self.publish_authority(renewal_from_owner(self.dispatcher, grant,
                        self.authority_sequence[name]+1, timestamp_ns(now)))
''')
change(A, '''                callback = {
                    "accept": self.dispatcher.on_accept, "result": self.dispatcher.on_result,
                    "cancel": self.dispatcher.on_cancel_response,
                }[event["type"]]
                callback(name, goal_id, event["value"], now)
''', '''                if self.motion_authority_profile:
                    self.authority_after_receipt(envelope, now)
                else:
                    callback = {
                        "accept": self.dispatcher.on_accept, "result": self.dispatcher.on_result,
                        "cancel": self.dispatcher.on_cancel_response,
                    }[event["type"]]
                    callback(name, goal_id, event["value"], now)
''')
change(A, '''                self.handles[goal_id].cancel_goal_async().add_done_callback(
                    lambda future, name=name, goal_id=goal_id: self.canceled(
                        future, name, goal_id))
        self.flush_protocol_events(now)
''', '''                # Preserve the original B-start/native attempt. Never wait for stop ACK here.
                try:
                    grant = self.authority_grant[name] if self.motion_authority_profile else None
                    current = self.authority_packet[name] if grant is not None else None
                    if grant is not None and grant["goal_id"] == goal_id and current["operation"] != "revoke":
                        self.publish_authority(from_canceling_owner(self.dispatcher, grant,
                            self.authority_sequence[name]+1, timestamp_ns(now)))
                finally:
                    self.handles[goal_id].cancel_goal_async().add_done_callback(
                        lambda future, name=name, goal_id=goal_id: self.canceled(
                            future, name, goal_id))
        if self.motion_authority_profile:
            self.poll_authority_handoff(now)
        self.flush_protocol_events(now)
''')

M = PACKAGE/'motion_safety.py'
change(M, 'from multi_robot_exploration.mr3_episode import elapsed_ns, timestamp_ns\n',
       'from multi_robot_exploration.mr3_episode import elapsed_ns, timestamp_ns\n'
       'from multi_robot_exploration.mr3_motion_authority import (\n'
       '    PROFILE as AUTHORITY_PROFILE, MotionAuthority, canonical as authority_canonical,\n'
       ')\n')
change(M, '        self.reach_enabled = self.safety_contract == CONTRACT\n', '''        self.reach_enabled = self.safety_contract == CONTRACT
        self.motion_authority_profile = self.declare_parameter("motion_authority_profile", "").value
        if self.motion_authority_profile != (AUTHORITY_PROFILE if self.reach_enabled else ""):
            raise ValueError("fixed receiving-authority profile differs from safety contract")
''')
change(M, '        self.reach_publisher_gids = {}\n', '''        self.reach_publisher_gids = {}
        self.motion_authorities = dict.fromkeys(ROBOTS)
        self.authority_ack_sequences = dict.fromkeys(ROBOTS, 0)
        self.authority_ready_sent = dict.fromkeys(ROBOTS)
''')
change(M, '        self.inputs.extend([\n            self.create_subscription(String, "/mr3/received/states", self.receive_states, 10),\n', '''        self.authority_ack_publishers = {}
        if self.motion_authority_profile:
            authority_qos = QoSProfile(depth=64, durability=DurabilityPolicy.TRANSIENT_LOCAL)
            self.authority_ack_publishers = {name: self.create_publisher(
                String, f"/{name}/mr3/motion_authority_ack", authority_qos) for name in ROBOTS}
            self.inputs.extend(self.create_subscription(
                String, f"/{name}/mr3/motion_authority",
                lambda message, name=name: self.receive_motion_authority(message, name), authority_qos)
                for name in ROBOTS)
        self.inputs.extend([
            self.create_subscription(String, "/mr3/received/states", self.receive_states, 10),
''')
change(M, '            "safety_contract": self.safety_contract,\n', '''            "safety_contract": self.safety_contract,
            **({"motion_authority_profile": self.motion_authority_profile,
                "worker_quantum_ack_barrier": False, "raw_goal_generation": None,
                "raw_goal_association": "UNKNOWN_UNSTAMPED_TWIST"}
               if self.motion_authority_profile else {}),
''')
methods = '''    def authority_identity(self, name):
        gate = self.motion_authorities[name]
        return publisher_graph_identity(self, f"/{name}/mr3/motion_authority", "mr3_adapter", "/",
            None if gate is None else gate.publisher_gid)

    def bind_motion_authority(self, name, identity):
        gate = self.motion_authorities[name]
        if gate is None and identity["valid"]:
            gate = MotionAuthority(self.epoch, name, identity["endpoints"][0]["endpoint_gid"])
            self.motion_authorities[name] = gate
            self.record("authority_configuration", {"robot": name,
                "motion_authority_profile": AUTHORITY_PROFILE, "publisher_identity": identity,
                "scope": "unique graph endpoint binding only; not packet authentication"})
        return gate

    def publish_authority_ack(self, name, ack, clock_ns):
        gate = self.motion_authorities[name]
        self.authority_ack_sequences[name] += 1
        packet = {"schema": "mr3-motion-authority-ack-wire-v1", "profile": AUTHORITY_PROFILE,
            "epoch": self.epoch, "robot": name, "ack_sequence": self.authority_ack_sequences[name],
            "clock_ns": clock_ns, "authority_packet_sha256": None if gate.packet is None else
                hashlib.sha256(authority_canonical(gate.packet).encode()).hexdigest(), "ack": ack}
        encoded = authority_canonical(packet)
        self.authority_ack_publishers[name].publish(String(data=encoded))
        self.record("authority_ack_publication", {"robot": name, "message": packet,
            "raw_json": encoded, "scope": "publication_call_returned; not delivery"})

    def receive_motion_authority(self, message, name):
        identity = self.authority_identity(name)
        clock_ns = self.get_clock().now().nanoseconds
        try:
            value = parse_json(message.data)
            gate = self.bind_motion_authority(name, identity)
            if not identity["valid"] or gate is None:
                raise ValueError("motion authority publisher graph unavailable")
            ack = gate.receive(value, publisher_gid=identity["endpoints"][0]["endpoint_gid"],
                clock_ns=clock_ns, latest_raw_sequence=self.input_sequences[name]["request"])
            self.record("authority_callback", {"robot": name, "message": value,
                "raw_json": message.data, "packet_sha256": hashlib.sha256(message.data.encode()).hexdigest(),
                "publisher_identity": identity, "clock_ns": clock_ns, "result": ack})
            if gate.fault is not None:
                raise ValueError(gate.fault)
            if ack.get("schema") == "mr3-motion-authority-ack-v1":
                self.publish_authority_ack(name, ack, clock_ns)
        except (ValueError, KeyError, TypeError, OverflowError) as error:
            self.record("invalid_motion_authority", {"robot": name, "raw_json": message.data,
                "publisher_identity": identity, "clock_ns": clock_ns, "reason": str(error)})
            self.reach_failure(name, error)

    def receiving_permission(self, name, tracker, request, clock_ns):
        gate = self.motion_authorities[name]
        if gate is None:
            gate = self.bind_motion_authority(name, self.authority_identity(name))
        if gate is None:
            return {"effective_request": [0., 0.], "permission": "zero_only",
                "state": "UNBOUND", "authority_sequence": 0, "owner": None,
                "raw_goal_generation": None, "raw_goal_association": "UNKNOWN_UNSTAMPED_TWIST"}
        gate.note_real_application(tracker)
        # Refresh local proof every original normal phase, but emit the large
        # witness only once per authority sequence. GRANT checks fresh local proof.
        ack = gate.observe_stop(tracker, clock_ns)
        if ack is not None and self.authority_ready_sent[name] != gate.sequence:
            self.publish_authority_ack(name, ack, clock_ns)
            self.authority_ready_sent[name] = gate.sequence
        return gate.input(request, clock_ns=clock_ns)

'''
change(M, '    def receive_reach_feed(self, message, name, kind):\n', methods+'    def receive_reach_feed(self, message, name, kind):\n')
change(M, '            getattr(self.reach[name], "receive_"+kind)(value)\n', '''            getattr(self.reach[name], "receive_"+kind)(value)
            if self.motion_authority_profile and kind == "applied":
                gate = self.motion_authorities[name]
                if gate is not None:
                    gate.note_real_application(self.reach[name])
''')
change(M, '        decisions = {}\n', '        decisions = {}\n        receiving_permissions = {}\n')
change(M, '            decision={"allow":False,"reason":"reach_zero","output":[0.,0.],"minimum_margin_m":None}\n', '''            permission = None
            if self.motion_authority_profile:
                try:
                    permission = self.receiving_permission(name, tracker, request if allowed_request else None, clock_ns)
                except (ValueError, KeyError, TypeError, OverflowError) as error:
                    self.reach_failure(name, error)
                    permission = {"effective_request": [0., 0.], "permission": "zero_only",
                        "state": "FAULT", "fault": str(error), "raw_goal_generation": None,
                        "raw_goal_association": "UNKNOWN_UNSTAMPED_TWIST"}
                receiving_permissions[name] = permission
            effective_request = (permission["effective_request"] if permission is not None else
                                 [request["v"], request["w"]] if allowed_request else [0., 0.])
            decision={"allow":False,"reason":"reach_zero","output":[0.,0.],"minimum_margin_m":None}
''')
change(M, '                    decision=tracker.decide([request["v"],request["w"]] if allowed_request else [0.,0.],own[name],\n',
       '                    decision=tracker.decide(effective_request,own[name],\n')
change(M, '                "decision_sequence":self.decision_sequences[name],"request":request,\n', '''                "decision_sequence":self.decision_sequences[name],"request":request,
                **({"motion_authority_profile": AUTHORITY_PROFILE,
                    "effective_request": receiving_permissions[name]["effective_request"],
                    "motion_authority": receiving_permissions[name]}
                   if self.motion_authority_profile else {}),
''')

change(LAUNCH, 'from multi_robot_exploration.mr3_safety_intent import actuation_profile_for_safety_contract\n',
       'from multi_robot_exploration.mr3_safety_intent import actuation_profile_for_safety_contract\n'
       'from multi_robot_exploration.mr3_motion_authority import PROFILE as AUTHORITY_PROFILE\n')
change(LAUNCH, '                         "safety_contract": safety_contract,\n                         **({"reach_geometry_rule": reach_geometry_rule}\n',
       '                         "safety_contract": safety_contract,\n'
       '                         "motion_authority_profile": AUTHORITY_PROFILE if safety_contract == "mr3-reach-v1" else "",\n'
       '                         **({"reach_geometry_rule": reach_geometry_rule}\n')
change(LAUNCH, '                **({"episode_epoch": episode_epoch, "stepped_mode": stepped_mode,\n',
       '                **({"episode_epoch": episode_epoch, "stepped_mode": stepped_mode,\n'
       '                    "safety_contract": safety_contract,\n'
       '                    "motion_authority_profile": AUTHORITY_PROFILE if safety_contract == "mr3-reach-v1" else "",\n')

core = Path('/tmp/mr3_p2a_motion_authority_candidate_v2/files/mr3_motion_authority.py')
shadow[str(PACKAGE/'mr3_motion_authority.py')] = core.read_text()
manifest = []
patch = []
for relative, text in shadow.items():
    ast.parse(text, filename=relative)
    path = HERE/'shadow'/relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    before = originals.get(relative, '')
    manifest.append({'path': relative, 'base_sha256': hashlib.sha256(before.encode()).hexdigest() if before else None,
                     'sha256': hashlib.sha256(text.encode()).hexdigest(), 'bytes': len(text.encode())})
    patch.extend(difflib.unified_diff(before.splitlines(True), text.splitlines(True),
                 fromfile='a/'+relative if before else '/dev/null', tofile='b/'+relative))
(HERE/'ros_wiring_candidate.patch').write_text(''.join(patch))
(HERE/'source_manifest_v1.json').write_text(json.dumps({'status':'STATIC_SHADOW_NOT_CPU_OR_ROS_QUALIFIED',
    'files':manifest,'protocol_source_modified':False,'repository_writes':False},indent=2)+'\n')
print(json.dumps({'shadow_count':len(shadow),'AST_PASS':True,'patch_bytes':len(''.join(patch).encode())}))
