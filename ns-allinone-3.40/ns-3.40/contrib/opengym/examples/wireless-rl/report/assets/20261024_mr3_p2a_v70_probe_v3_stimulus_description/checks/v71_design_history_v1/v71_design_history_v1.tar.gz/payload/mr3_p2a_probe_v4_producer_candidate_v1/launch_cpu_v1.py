import json,os
from pathlib import Path
v=json.loads((Path(__file__).parent/'cpu_v1/spec_v1.json').read_bytes())
os.chdir(v['cwd']);os.environ['PYTHONDONTWRITEBYTECODE']='1'
os.execv(v['actual_argv'][0],v['actual_argv'])
