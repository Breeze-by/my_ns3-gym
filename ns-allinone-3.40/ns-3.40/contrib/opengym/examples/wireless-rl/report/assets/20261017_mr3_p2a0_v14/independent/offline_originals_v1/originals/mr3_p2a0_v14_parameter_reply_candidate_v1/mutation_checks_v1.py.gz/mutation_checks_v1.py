"""Pure XML guard mutations, no ROS initialization or DDS participant."""
import importlib.util
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).parent
TEST = ROOT / 'ros_view/src/multi_robot_exploration/test/test_fastdds_environment.py'
PROFILE = ROOT / 'ros_view/src/multi_robot/config/mr3_fastdds_loopback_udp.xml'
spec = importlib.util.spec_from_file_location('candidate_test', TEST)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
functions = [module.test_profile_uses_only_one_default_loopback_udp_transport,
             module.test_only_exact_nav2_lifecycle_replies_get_distinct_bounded_matching_waits,
             module.test_nine_exact_parameter_replies_add_only_bounded_response_matching_waits]
for function in functions:
    function()
ns = module.NS


def parameter(tree):
    return next(node for node in tree.findall('dds:publisher', ns)
                if node.get('profile_name').endswith('get_parametersReply'))


def changed_legacy(tree):
    node = next(x for x in tree.findall('dds:publisher', ns)
                if x.get('profile_name').endswith('change_stateReply'))
    node.find('dds:qos/dds:reliability/dds:max_blocking_time/dds:sec', ns).text = '2'


def changed_transport(tree):
    tree.find('dds:transport_descriptors/dds:transport_descriptor/dds:interfaceWhiteList/dds:address', ns).text = '0.0.0.0'


def changed_parameter_wait(tree):
    parameter(tree).find('dds:qos/dds:reliability/dds:max_blocking_time/dds:sec', ns).text = '0'


changes = {
    'wrong_parameter_node': lambda t: parameter(t).set('profile_name', 'rr/tb1/planner_server/get_parametersReply'),
    'parameter_wildcard': lambda t: parameter(t).set('profile_name', 'rr/tb*/controller_server/get_parametersReply'),
    'default_writer_attribute': lambda t: parameter(t).set('is_default_profile', 'true'),
    'fallback_service': lambda t: parameter(t).set('profile_name', 'service'),
    'parameter_wait_wrong': changed_parameter_wait,
    'extra_reader': lambda t: ET.SubElement(t, '{' + ns['dds'] + '}subscriber'),
    'changed_legacy5s': changed_legacy,
    'changed_loopback': changed_transport,
}
results = []
for name, change in changes.items():
    tree = ET.parse(PROFILE).getroot()
    change(tree)
    selected = ROOT / ('mutation_' + name + '.xml')
    ET.ElementTree(tree).write(selected, encoding='utf-8', xml_declaration=True)
    module.PROFILE = selected
    rejected = []
    for function in functions:
        try:
            function()
        except AssertionError:
            rejected.append(function.__name__)
    if not rejected:
        raise AssertionError(name + ' was not rejected')
    results.append({'mutation': name, 'path': str(selected), 'rejected_by': rejected})
(ROOT / 'mutation_results_v1.json').write_text(json.dumps({
    'passed': True, 'mutations': results, 'scope': 'Offline XML assertion counterexamples only'}, indent=2) + '\n')
print(json.dumps({'passed': True, 'mutations_rejected': len(results)}))
