"""Analyze captured subsets only; never re-read the original large raw files."""
from bisect import bisect_left
from datetime import datetime, timezone
import gzip
import hashlib
import json
import math
from pathlib import Path
import statistics

BASE = Path('/tmp/mr3_p2a0_v17_stop_response_raw_diagnostic_v1')
OUT = Path('/tmp/mr3_p2a0_v17_stop_response_chain_review_v1.json')
BOUND = .01
INPUTS = {}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    data = path.read_bytes()
    INPUTS[str(path)] = sha(data)
    return json.loads(data)


def summary(values):
    return {'minimum': min(values), 'maximum': max(values),
            'mean': statistics.mean(values), 'median': statistics.median(values)} if values else None


def position_interval(samples, begin, end):
    selected = [r for r in samples if begin <= r['source_ns'] <= end]
    pairs = list(zip(selected, selected[1:]))
    return {'first': selected[0] if selected else None, 'last': selected[-1] if selected else None,
            'unique_source_samples': len(selected),
            'maximum_source_gap_ns': max((b['source_ns']-a['source_ns'] for a,b in pairs), default=None),
            'sampled_polyline_m': sum(math.dist(a['xy'], b['xy']) for a,b in pairs),
            'endpoint_chord_m': math.dist(selected[0]['xy'], selected[-1]['xy']) if selected else None,
            'chord_speed_mps': summary([math.dist(a['xy'], b['xy'])/((b['source_ns']-a['source_ns'])/1e9) for a,b in pairs]),
            'raw_planar_speed_mps': summary([r['planar_speed'] for r in selected]),
            'raw_linear_x_mps': summary([r['linear_xyz'][0] for r in selected]),
            'raw_linear_y_mps': summary([r['linear_xyz'][1] for r in selected]),
            'raw_angular_z_radps': summary([r['angular_xyz'][2] for r in selected]),
            'above_rest_threshold_count': sum(r['planar_speed'] > BOUND for r in selected)}


def episode(name, a_ns, b_ns):
    directory = BASE / name
    report = read(directory/'report.json')
    odom = read(directory/'unique_own_odom.json')
    drive = read(directory/'drive_derived.json')
    commands = read(directory/'actual_commands.json')
    source_manifest = report['input_manifest']
    for item in source_manifest:
        if item.get('selected_encoding') != 'gzip':
            continue
        encoded = Path(item['selected_path']).read_bytes()
        decoded = gzip.decompress(encoded)
        assert sha(encoded) == item['selected_encoded_sha256']
        assert sha(decoded) == item['selected_decoded_sha256']
        assert len(encoded) == item['selected_encoded_bytes']
        assert len(decoded) == item['selected_decoded_bytes']
        rows = [r for r in decoded.splitlines(keepends=True) if r.strip()]
        assert len(rows) == len(item['row_index'])
        assert all(sha(raw) == index['raw_line_sha256'] for raw,index in zip(rows,item['row_index']))
        INPUTS[item['selected_path']] = sha(encoded)
    act = [r for r in drive if r['kind']=='actuation']
    received = [r for r in drive if r['kind']=='command_received']
    after = [r for r in act if r['sim_time_ns']>=a_ns]
    last_nonzero = next((r for r in reversed(after) if any(r['applied_rim_mps'])), None)
    zeros = [r for r in after if not any(r['applied_rim_mps']) and
             (last_nonzero is None or r['sim_time_ns']>last_nonzero['sim_time_ns'])]
    first_zero = zeros[0]
    first_desired_zero = next(r for r in after if r['desired_rim_mps']==[0.,0.])
    first_received_zero = next(r for r in received if r['sim_time_ns']>=a_ns and
                               r['desired_v']==r['desired_w']==0.)
    assert all(r['desired_v']==r['desired_w']==0 for r in received if r['sim_time_ns']>=a_ns)
    assert all(r['v']==r['w']==0 for r in commands if r['clock_ns']>=a_ns)
    assert all(r['desired_v']==r['desired_w']==0 and r['alpha']==1. and
               r['applied_rim_mps']==[0.,0.] for r in zeros)
    own_sources = [r['source_ns'] for r in odom]
    boundaries = []
    for target in [b_ns, a_ns, first_desired_zero['sim_time_ns'], first_zero['sim_time_ns'],
                   a_ns+780_000_000, 109_684_000_000, report['physics_end_ns']]:
        if not odom[0]['source_ns']<=target<=report['physics_end_ns']:
            continue
        i=bisect_left(own_sources,target)
        nearest = odom[max(0,i-1):min(len(odom),i+2)]
        d = min(act,key=lambda r:abs(r['sim_time_ns']-target))
        boundaries.append({'target_clock_ns':target,'surrounding_own_odom':nearest,
                           'nearest_actuation':d})
    horizon = a_ns+780_000_000
    rest = report['events'][1]['first_three_rest_samples']
    stop = rest[0]['source_ns'] if rest else report['physics_end_ns']
    post = [r for r in act if r['sim_time_ns']>=horizon]
    return {'episode':name, 'epoch':report['epoch'], 'release_ns':report['release_ns'],
        'physics_end_ns':report['physics_end_ns'],
        'actual_linear_and_angular_stay_zero_from_ns':a_ns,
        'first_native_received_zero':first_received_zero,
        'first_zero_desired_actuation':first_desired_zero,
        'last_nonzero_applied_after_final_zero':last_nonzero,
        'first_permanent_zero_applied_actuation':first_zero,
        'permanent_zero_applied_to_last_actuation':zeros[-1],
        'permanent_zero_applied_actuation_count':len(zeros),
        'zero_applied_latency_from_actual_final_zero_sec':(first_zero['sim_time_ns']-a_ns)/1e9,
        'post_horizon_current_right_mps':summary([r['current_rim_mps'][0] for r in post]),
        'post_horizon_current_left_mps':summary([r['current_rim_mps'][1] for r in post]),
        'post_horizon_measured_wheel_body_v_mps':summary([sum(r['current_rim_mps'])/2 for r in post]),
        'post_horizon_measured_wheel_body_w_radps':summary([(r['current_rim_mps'][0]-r['current_rim_mps'][1])/.287 for r in post]),
        'post_horizon_dt_ns_values':sorted({r['dt_ns'] for r in post}),
        'post_horizon_alpha_values':sorted({r['alpha'] for r in post}),
        'post_horizon_through_first_rest_or_end':position_interval(odom,horizon,stop),
        'last_second_before_physics_end':position_interval(odom,report['physics_end_ns']-1_000_000_000,report['physics_end_ns']),
        'first_three_rest':rest,'stop_responses':report['events'],
        'source_callback_duplicates_in_window':report['repeated_source_callbacks'],
        'source_conflicting_duplicates_in_window':report['conflicting_duplicate_sources'],
        'boundary_rows':boundaries,
        'original_inputs':[{'source':r['source'],'sha256':r['source_sha256'],
                           'bytes':r['source_bytes'],'original_sequential_reads':r['original_sequential_reads']}
                          for r in source_manifest]}


result={'schema':'mr3-v17-stop-response-chain-diagnostic-v1',
        'freeze':'eee6b2f90f697b28a1c20a2af5d1a6d2f044465e',
        'diagnostic_completed':True,'formal_gate_credit':False,
        'episodes':[episode('episode002_open_101',96_220_000_000,96_180_000_000),
                    episode('episode003_rooms_101',90_360_000_000,90_260_000_000)],
        'conclusions':[
          'Both final linear and angular commands remain exactly zero after the identified final zero. Native desired rims also become zero and stay zero.',
          'Both applied rim targets become exactly zero within 0.204/0.179 seconds and stay exactly zero with alpha=1. This excludes a long nonzero target or paired slew residual as the direct cause of the 13-second/missing-rest failures.',
          'Raw sampled lateral linear.y remains above .01 m/s for long intervals while linear.x is small. The immutable rest predicate hypot(linear.x,linear.y)<=.01 is genuinely unmet; no duplicated source message accounts for it.',
          'Sampled pose chords are much smaller than instantaneous raw velocity magnitudes during the tail. They measure different finite-sample quantities. These diagnostics do not prove a velocity producer bug, contact cause, frame-point mismatch, or continuous physical rest; the original strict failures remain.',
          'The sampled path remains below .144 m in these windows, which does not waive the independent .78-second/three-rest-sample requirement.'
        ],
        'input_bindings':INPUTS,'utc':datetime.now(timezone.utc).isoformat(),
        'script_sha256':sha(Path(__file__).read_bytes())}
for path,expected in INPUTS.items():
    assert sha(Path(path).read_bytes())==expected, f'captured input changed: {path}'
with OUT.open('x') as out:
    json.dump(result,out,indent=2)
    out.write('\n')
print(json.dumps({'output':str(OUT),'sha256':sha(OUT.read_bytes()),
                  'episodes':[{k:v for k,v in e.items() if k in (
                      'episode','actual_linear_and_angular_stay_zero_from_ns',
                      'zero_applied_latency_from_actual_final_zero_sec',
                      'permanent_zero_applied_actuation_count','post_horizon_current_right_mps',
                      'post_horizon_current_left_mps','post_horizon_measured_wheel_body_w_radps',
                      'post_horizon_through_first_rest_or_end')} for e in result['episodes']]},indent=2))
