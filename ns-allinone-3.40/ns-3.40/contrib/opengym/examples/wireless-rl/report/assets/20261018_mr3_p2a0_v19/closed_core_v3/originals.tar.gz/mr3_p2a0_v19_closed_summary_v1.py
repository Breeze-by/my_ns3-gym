"""Read closed V19 originals and check saved PID/start identity disappearance."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
FREEZE = '72d0465ddd1bbee09af117cfd9d89b7e729f8578'
started = time.monotonic()
inputs = {}


def read(path):
    path = Path(path)
    before = path.stat()
    raw = path.read_bytes()
    assert path.stat() == before
    inputs[str(path)] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    return json.loads(raw)


def identity(pid):
    try:
        fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
        return {'pid': pid, 'start_ticks': int(fields[19]), 'state': fields[0]}
    except FileNotFoundError:
        return None


pair = read('/tmp/mr3_p2a0_v19_pair_execution.json')
assert pair['freeze'] == FREEZE and pair['passed'] and not pair['matrix_credit']
identities = {}
stages = []
for stage in ('baseline', 'iters150'):
    execution = read(f'/tmp/mr3_p2a0_v19_{stage}_execution.json')
    assert execution['freeze'] == FREEZE and execution['passed'] and execution['returncode'] == 0
    run = ROOT / f'ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261018_v19_{stage}'
    summary = read(run / 'benchmark_summary.json')
    episode = run / 'worker0/episode001_open_101'
    shutdown = read(episode / 'supervisor_shutdown.json')
    physical = read(f'/tmp/mr3_p2a0_v19_{stage}_physical_review.json')
    observer = read(f'/tmp/mr3_p2a0_v19_{stage}_observer_review.json')
    rows = [json.loads(line) for line in (episode / 'transitions.jsonl').read_text().splitlines()]
    assert summary['passed'] and len(rows) == 33 and rows[0]['kind'] == 'reset'
    assert all(row['kind'] == 'step' for row in rows[1:])
    assert rows[-1]['truncated'] and rows[-1]['info']['reason'] == 'external_sampler_limit'
    assert observer['passed'] and not observer['errors']
    assert physical['episodes'][0]['closure']['strict']
    assert not shutdown['remaining_owned_processes'] and not shutdown['remaining_owned_zombies']
    for row in shutdown['owned_processes_seen'] + [execution['parent_identity'], execution['benchmark_identity']]:
        identities[(row['pid'], row['start_ticks'])] = row
    log = (episode / 'launch.log').read_text()
    clean = re.findall(r'process has finished cleanly \[pid (\d+)\]', log)
    assert not re.findall(r'process has died', log)
    stages.append({'stage': stage, 'saved_reset_records': 1, 'returned_step_calls': 32,
                   'saved_api_records': 33, 'native_benchmark_passed': True,
                   'native_wall_seconds': execution['native_wall_seconds'],
                   'observer_1ms_passed': observer['passed'], 'original_physical_passed': physical['passed'],
                   'strict_closure': physical['episodes'][0]['closure'],
                   'clean_native_process_exit_lines': len(clean),
                   'task_release_ns': rows[0]['info']['release_time_ns'],
                   'task_seconds': sum(row['info'].get('dt', 0.0) for row in rows[1:])})
checks = [{'saved': {'pid': pid, 'start_ticks': start}, 'current': identity(pid)}
          for pid, start in sorted(identities)]
live = [row for row in checks if row['current'] and row['current']['start_ticks'] == row['saved']['start_ticks']]
assert not live
result = {'schema': 'mr3-v19-closed-summary-v1', 'freeze': FREEZE,
          'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'stages': stages,
          'capture_admission_native_closure_passed': True, 'physical_response_pair_passed': False,
          'matrix_credit': False, 'iters150_selected': False, 'optimizer_updates': 0,
          'fresh_saved_identity_count': len(checks), 'identity_checks': checks,
          'fresh_live_saved_identities': live, 'native_wall_seconds': pair['native_wall_seconds'],
          'v18_plus_v19_diagnostic_native_wall_seconds': 850.965301560238 + pair['native_wall_seconds'],
          'unused_of_3600_diagnostic_ceiling': 3600 - 850.965301560238 - pair['native_wall_seconds'],
          'pilot_balance': {'decisions': 1870, 'wall_seconds': 2905.954739546403, 'changed': False},
          'inputs': inputs, 'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'wall_seconds': time.monotonic() - started,
          'limits': 'Contrast produced no GOAL or eligible stopping stimulation. No V17 repair, matrix, policy or 95% claim.'}
Path('/tmp/mr3_p2a0_v19_closed_summary_v1.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ('fresh_saved_identity_count', 'native_wall_seconds',
    'v18_plus_v19_diagnostic_native_wall_seconds', 'unused_of_3600_diagnostic_ceiling')}))
