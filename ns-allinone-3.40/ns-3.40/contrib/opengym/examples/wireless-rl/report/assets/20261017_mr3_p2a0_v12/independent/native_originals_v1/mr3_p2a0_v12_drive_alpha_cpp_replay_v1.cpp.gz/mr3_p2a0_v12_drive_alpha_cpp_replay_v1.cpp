#include <multi_robot/paired_wheel_slew.hpp>
#include <iostream>
#include <iomanip>
#include <limits>
int main(){
 std::array<double,2> current{},desired{};double a,dt;
 std::cout<<"long_double_digits "<<std::numeric_limits<long double>::digits<<"\n";
 while(std::cin>>current[0]>>current[1]>>desired[0]>>desired[1]>>a>>dt){
  const auto result=multi_robot::limit_paired_wheel_speeds(current,desired,a,dt);
  const long double d0=static_cast<long double>(desired[0])-current[0],d1=static_cast<long double>(desired[1])-current[1];
  const long double budget=static_cast<long double>(a)*dt;
  const long double largest=std::max(std::abs(d0),std::abs(d1));
  const long double nominal=budget/largest;
  const double cast=static_cast<double>(nominal);
  std::cout<<std::setprecision(25)<<"alpha "<<result.alpha<<" applied "<<result.applied[0]<<" "<<result.applied[1]<<" nominal_ld "<<nominal<<" cast_greater_ld "<<(static_cast<long double>(cast)>nominal)<<" alpha_greater_ld "<<(static_cast<long double>(result.alpha)>nominal)<<"\n";
  std::cout<<std::hexfloat<<"hex "<<result.alpha<<" "<<result.applied[0]<<" "<<result.applied[1]<<" nominal_ld "<<nominal<<" delta "<<d0<<" "<<d1<<" budget "<<budget<<std::defaultfloat<<"\n";
 }
}
