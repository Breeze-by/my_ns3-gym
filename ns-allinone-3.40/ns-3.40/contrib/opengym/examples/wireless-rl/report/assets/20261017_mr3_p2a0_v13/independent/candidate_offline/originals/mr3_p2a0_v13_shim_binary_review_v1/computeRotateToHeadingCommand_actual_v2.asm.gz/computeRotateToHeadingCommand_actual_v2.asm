0000000000018460 <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base>:
   18460:	f3 0f 1e fa          	endbr64 
   18464:	41 57                	push   %r15
   18466:	41 56                	push   %r14
   18468:	49 89 d6             	mov    %rdx,%r14
   1846b:	41 55                	push   %r13
   1846d:	49 89 cd             	mov    %rcx,%r13
   18470:	41 54                	push   %r12
   18472:	49 89 fc             	mov    %rdi,%r12
   18475:	55                   	push   %rbp
   18476:	48 89 f5             	mov    %rsi,%rbp
   18479:	53                   	push   %rbx
   1847a:	48 83 ec 08          	sub    $0x8,%rsp
   1847e:	80 be d2 01 00 00 00 	cmpb   $0x0,0x1d2(%rsi)
   18485:	0f 84 25 01 00 00    	je     185b0 <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base+0x150>
   1848b:	49 8b 58 28          	mov    0x28(%r8),%rbx
   1848f:	66 48 0f 6e db       	movq   %rbx,%xmm3
   18494:	66 0f 2e 1d fc 26 02 	ucomisd 0x226fc(%rip),%xmm3        # 3ab98 <typeinfo name for nav2_core::Controller*@@Base+0x38>
   1849b:	00 
   1849c:	7a 08                	jp     184a6 <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base+0x46>
   1849e:	48 0f 44 1d 62 27 02 	cmove  0x22762(%rip),%rbx        # 3ac08 <typeinfo name for nav2_core::Controller*@@Base+0xa8>
   184a5:	00 
   184a6:	49 8d 44 24 18       	lea    0x18(%r12),%rax
   184ab:	41 c6 44 24 18 00    	movb   $0x0,0x18(%r12)
   184b1:	45 31 c0             	xor    %r8d,%r8d
   184b4:	31 d2                	xor    %edx,%edx
   184b6:	49 c7 04 24 00 00 00 	movq   $0x0,(%r12)
   184bd:	00 
   184be:	4d 8d 7c 24 08       	lea    0x8(%r12),%r15
   184c3:	48 8d 0d 75 0b 02 00 	lea    0x20b75(%rip),%rcx        # 3903f <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e9f>
   184ca:	31 f6                	xor    %esi,%esi
   184cc:	49 89 44 24 08       	mov    %rax,0x8(%r12)
   184d1:	4c 89 ff             	mov    %r15,%rdi
   184d4:	49 c7 44 24 10 00 00 	movq   $0x0,0x10(%r12)
   184db:	00 00 
   184dd:	e8 ee 7d ff ff       	call   102d0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_replace(unsigned long, unsigned long, char const*, unsigned long)@plt>
   184e2:	49 8b 45 00          	mov    0x0(%r13),%rax
   184e6:	49 8d 75 08          	lea    0x8(%r13),%rsi
   184ea:	4c 89 ff             	mov    %r15,%rdi
   184ed:	49 c7 44 24 28 00 00 	movq   $0x0,0x28(%r12)
   184f4:	00 00 
   184f6:	49 c7 44 24 30 00 00 	movq   $0x0,0x30(%r12)
   184fd:	00 00 
   184ff:	49 c7 44 24 38 00 00 	movq   $0x0,0x38(%r12)
   18506:	00 00 
   18508:	49 c7 44 24 40 00 00 	movq   $0x0,0x40(%r12)
   1850f:	00 00 
   18511:	49 c7 44 24 48 00 00 	movq   $0x0,0x48(%r12)
   18518:	00 00 
   1851a:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
   18521:	00 00 
   18523:	49 89 04 24          	mov    %rax,(%r12)
   18527:	e8 34 78 ff ff       	call   fd60 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_assign(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&)@plt>
   1852c:	f2 41 0f 10 0e       	movsd  (%r14),%xmm1
   18531:	66 0f 2f 0d cf 26 02 	comisd 0x226cf(%rip),%xmm1        # 3ac08 <typeinfo name for nav2_core::Controller*@@Base+0xa8>
   18538:	00 
   18539:	f2 0f 10 05 5f 26 02 	movsd  0x2265f(%rip),%xmm0        # 3aba0 <typeinfo name for nav2_core::Controller*@@Base+0x40>
   18540:	00 
   18541:	77 08                	ja     1854b <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base+0xeb>
   18543:	f2 0f 10 05 85 26 02 	movsd  0x22685(%rip),%xmm0        # 3abd0 <typeinfo name for nav2_core::Controller*@@Base+0x70>
   1854a:	00 
   1854b:	f2 0f 10 95 b8 01 00 	movsd  0x1b8(%rbp),%xmm2
   18552:	00 
   18553:	f2 0f 59 95 c0 01 00 	mulsd  0x1c0(%rbp),%xmm2
   1855a:	00 
   1855b:	66 48 0f 6e cb       	movq   %rbx,%xmm1
   18560:	f2 0f 59 85 b0 01 00 	mulsd  0x1b0(%rbp),%xmm0
   18567:	00 
   18568:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
   1856c:	66 0f 2f c8          	comisd %xmm0,%xmm1
   18570:	77 0d                	ja     1857f <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base+0x11f>
   18572:	66 48 0f 6e cb       	movq   %rbx,%xmm1
   18577:	f2 0f 58 ca          	addsd  %xmm2,%xmm1
   1857b:	f2 0f 5d c8          	minsd  %xmm0,%xmm1
   1857f:	f2 41 0f 11 4c 24 50 	movsd  %xmm1,0x50(%r12)
   18586:	4c 89 e9             	mov    %r13,%rcx
   18589:	4c 89 f2             	mov    %r14,%rdx
   1858c:	4c 89 e6             	mov    %r12,%rsi
   1858f:	48 89 ef             	mov    %rbp,%rdi
   18592:	e8 09 7a ff ff       	call   ffa0 <nav2_rotation_shim_controller::RotationShimController::isCollisionFree(geometry_msgs::msg::TwistStamped_<std::allocator<void> > const&, double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&)@plt>
   18597:	48 83 c4 08          	add    $0x8,%rsp
   1859b:	4c 89 e0             	mov    %r12,%rax
   1859e:	5b                   	pop    %rbx
   1859f:	5d                   	pop    %rbp
   185a0:	41 5c                	pop    %r12
   185a2:	41 5d                	pop    %r13
   185a4:	41 5e                	pop    %r14
   185a6:	41 5f                	pop    %r15
   185a8:	c3                   	ret    
   185a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   185b0:	48 8b 9e d8 01 00 00 	mov    0x1d8(%rsi),%rbx
   185b7:	e9 d3 fe ff ff       	jmp    1848f <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base+0x2f>
   185bc:	f3 0f 1e fa          	endbr64 
   185c0:	48 89 c5             	mov    %rax,%rbp
   185c3:	e9 46 86 ff ff       	jmp    10c0e <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x73e>
   185c8:	f3 0f 1e fa          	endbr64 
   185cc:	48 89 c5             	mov    %rax,%rbp
   185cf:	e9 4a 86 ff ff       	jmp    10c1e <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x74e>
   185d4:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   185db:	00 00 00 00 
   185df:	90                   	nop
   185e0:	f3 0f 1e fa          	endbr64 
   185e4:	41 57                	push   %r15
   185e6:	41 56                	push   %r14
   185e8:	49 89 fe             	mov    %rdi,%r14
   185eb:	41 55                	push   %r13
   185ed:	41 54                	push   %r12
   185ef:	55                   	push   %rbp
   185f0:	48 89 f5             	mov    %rsi,%rbp
   185f3:	53                   	push   %rbx
   185f4:	48 83 ec 28          	sub    $0x28,%rsp
   185f8:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
   185fc:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
   18603:	00 00 
   18605:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   1860a:	31 c0                	xor    %eax,%eax
   1860c:	48 2b 1e             	sub    (%rsi),%rbx
   1860f:	48 c7 07 00 00 00 00 	movq   $0x0,(%rdi)
   18616:	48 c7 47 08 00 00 00 	movq   $0x0,0x8(%rdi)
   1861d:	00 
   1861e:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
   18625:	00 
   18626:	0f 84 1c 01 00 00    	je     18748 <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base+0x2e8>
   1862c:	48 b8 e0 ff ff ff ff 	movabs $0x7fffffffffffffe0,%rax
   18633:	ff ff 7f 
   18636:	48 39 c3             	cmp    %rax,%rbx
   18639:	0f 87 17 01 00 00    	ja     18756 <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base+0x2f6>
   1863f:	48 89 df             	mov    %rbx,%rdi
   18642:	e8 49 79 ff ff       	call   ff90 <operator new(unsigned long)@plt>
   18647:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   1864c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   18651:	48 01 c3             	add    %rax,%rbx
   18654:	49 89 06             	mov    %rax,(%r14)
   18657:	49 89 46 08          	mov    %rax,0x8(%r14)
   1865b:	49 89 5e 10          	mov    %rbx,0x10(%r14)
   1865f:	4c 8b 7d 08          	mov    0x8(%rbp),%r15
   18663:	48 8b 6d 00          	mov    0x0(%rbp),%rbp
   18667:	4c 39 fd             	cmp    %r15,%rbp
   1866a:	0f 84 a8 00 00 00    	je     18718 <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base+0x2b8>
   18670:	48 89 c3             	mov    %rax,%rbx
   18673:	48 8d 44 24 10       	lea    0x10(%rsp),%rax
   18678:	48 89 04 24          	mov    %rax,(%rsp)
   1867c:	eb 24                	jmp    186a2 <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base+0x242>
   1867e:	66 90                	xchg   %ax,%ax
   18680:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
   18685:	88 43 10             	mov    %al,0x10(%rbx)
   18688:	48 83 c5 20          	add    $0x20,%rbp
   1868c:	4c 89 63 08          	mov    %r12,0x8(%rbx)
   18690:	48 83 c3 20          	add    $0x20,%rbx
   18694:	42 c6 04 27 00       	movb   $0x0,(%rdi,%r12,1)
   18699:	49 39 ef             	cmp    %rbp,%r15
   1869c:	0f 84 7e 00 00 00    	je     18720 <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base+0x2c0>
   186a2:	48 8d 7b 10          	lea    0x10(%rbx),%rdi
   186a6:	4c 8b 65 08          	mov    0x8(%rbp),%r12
   186aa:	48 89 3b             	mov    %rdi,(%rbx)
   186ad:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
   186b1:	4c 89 e8             	mov    %r13,%rax
   186b4:	4c 01 e0             	add    %r12,%rax
   186b7:	74 09                	je     186c2 <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base+0x262>
   186b9:	4d 85 ed             	test   %r13,%r13
   186bc:	0f 84 a3 00 00 00    	je     18765 <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base+0x305>
   186c2:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   186c7:	49 83 fc 0f          	cmp    $0xf,%r12
   186cb:	77 13                	ja     186e0 <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base+0x280>
   186cd:	49 83 fc 01          	cmp    $0x1,%r12
   186d1:	74 ad                	je     18680 <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base+0x220>
   186d3:	4d 85 e4             	test   %r12,%r12
   186d6:	74 b0                	je     18688 <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base+0x228>
   186d8:	eb 23                	jmp    186fd <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base+0x29d>
   186da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   186e0:	48 8b 34 24          	mov    (%rsp),%rsi
   186e4:	31 d2                	xor    %edx,%edx
   186e6:	48 89 df             	mov    %rbx,%rdi
   186e9:	e8 d2 7c ff ff       	call   103c0 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_create(unsigned long&, unsigned long)@plt>
   186ee:	48 89 03             	mov    %rax,(%rbx)
   186f1:	48 89 c7             	mov    %rax,%rdi
   186f4:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   186f9:	48 89 43 10          	mov    %rax,0x10(%rbx)
   186fd:	4c 89 e2             	mov    %r12,%rdx
   18700:	4c 89 ee             	mov    %r13,%rsi
   18703:	e8 c8 77 ff ff       	call   fed0 <memcpy@plt>
   18708:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   1870d:	48 8b 3b             	mov    (%rbx),%rdi
   18710:	e9 73 ff ff ff       	jmp    18688 <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base+0x228>
   18715:	0f 1f 00             	nopl   (%rax)
   18718:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
   1871d:	0f 1f 00             	nopl   (%rax)
   18720:	49 89 5e 08          	mov    %rbx,0x8(%r14)
   18724:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   18729:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
   18730:	00 00 
   18732:	75 3d                	jne    18771 <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base+0x311>
   18734:	48 83 c4 28          	add    $0x28,%rsp
   18738:	5b                   	pop    %rbx
   18739:	5d                   	pop    %rbp
   1873a:	41 5c                	pop    %r12
   1873c:	41 5d                	pop    %r13
   1873e:	41 5e                	pop    %r14
   18740:	41 5f                	pop    %r15
   18742:	c3                   	ret    
   18743:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   18748:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
   1874f:	00 00 
   18751:	e9 f6 fe ff ff       	jmp    1864c <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base+0x1ec>
   18756:	48 85 db             	test   %rbx,%rbx
   18759:	79 05                	jns    18760 <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base+0x300>
   1875b:	e8 60 77 ff ff       	call   fec0 <std::__throw_bad_array_new_length()@plt>
   18760:	e8 db 74 ff ff       	call   fc40 <std::__throw_bad_alloc()@plt>
   18765:	48 8d 3d 4c 0e 02 00 	lea    0x20e4c(%rip),%rdi        # 395b8 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3418>
   1876c:	e8 df 76 ff ff       	call   fe50 <std::__throw_logic_error(char const*)@plt>
   18771:	e8 ea 78 ff ff       	call   10060 <__stack_chk_fail@plt>
   18776:	f3 0f 1e fa          	endbr64 
   1877a:	48 89 c7             	mov    %rax,%rdi
   1877d:	e9 ee 87 ff ff       	jmp    10f70 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0xaa0>
   18782:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   18789:	00 00 00 00 
   1878d:	0f 1f 00             	nopl   (%rax)
