"""Append-only conditional execution-contract draft; no canonical mutation."""
import difflib
import hashlib
import json
from pathlib import Path
import time

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
ENV = ROOT / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
              'MR3_ENV_CONTRACT.md')
PIN_SOURCE = Path('/tmp/mr3_p2a0_v19_conditional_world_iters150_proposal_v1/attempt02/checks_v1.json')
EXPECTED = '96d9bd3e3d597899b3d44a69ef9138e77b62b3641bd7261eb38846d5b003f155'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    started = time.monotonic()
    original = ENV.read_bytes()
    assert sha(original) == EXPECTED
    pins_raw = PIN_SOURCE.read_bytes()
    pins = json.loads(pins_raw)
    assert pins['passed'] and pins['conditional_only']
    rows = []
    for label in ('prospective_world_pins', 'prospective_task_metadata_pins'):
        for path, digest in pins[label].items():
            relative = path.removeprefix('ros2_ws/ros2-multi-robot-automap/')
            rows.append(f'| `{relative}` | `{digest}` |')
    addition = '''
## P2A.0 研究 world 的显式 QuickStep 执行配置

本执行修订仅在`p1c_open.world`、`p1c_rooms.world`、`p1c_corridors.world`中，
增加唯一审核过的`ode/solver`块，显式指定`type=quick`及`iters=150`。
SOR、CFM、ERP、接触参数、重力及其他物理配置保持原值；模型、碰撞体、场景几何不变。
对应`mr3_p1a/open.json`、`rooms.json`、`corridors.json`仅更新单个`world_sha256`，
使任务加载、真值栅格、scene审计、reward reset和evaluation继续绑定所选实际world的完整文件SHA。
任务loader仍只使用这一实际world身份；不以旧geometry摘要代替实际world来源，
不通过运行时物理setter绕过world配置或审计。

六个修订文件的完整新SHA如下，路径相对ROS工程根：

| 文件 | 完整新SHA256 |
| --- | --- |
''' + '\n'.join(rows) + '''

这六份执行/元数据原件与W7原字节不同。受限审计仅对白名单中这六个固定路径，
同时核验声明冻结Git对象、当前文件及上述固定新SHA，再作逐字投影：
三个world移除唯一固定新增的`ode/solver/type=quick/iters=150`块后必须完全恢复
`TASK_BASE_FREEZE`的原world；三个JSON仅将对应实际新world SHA替回该场景原W7 world SHA，
必须完全恢复原JSON。任务JSON的新world SHA须来自独立验证的对应实际world，不能由调用者自证。
其他machine/config文件仍要求与原W7逐字相同。审计回执分别保留实际新SHA、
物理配置或world-SHA元数据修订类别、原W7来源与投影SHA，不将新文件记为原始W7字节。
旧SDF、任务JSON、sourcepack、失败、诊断及各冻结结果均保留，不改写或追认其范围。

SDFormat9.7的每场景43项schema字段归一化对照只允许迭代数`50→150`不同；
43项是schema字段数，包含可选及非活动引擎分支，不是43次测试，也不是实际native参数读回。
静态几何、ROI和真值mask一致性只证明任务定义保持，不能证明求解收敛、机体响应或运行稳定性。
完整新冻结须保留实际world路径/SHA、任务JSON SHA、Gazebo命令及二进制来源，
并按事前声明的实际参数核验范围解释生效证据；不把缓存solver标签冒充私有执行函数指针证明。

物理步`1ms`、受控量子`20ms`、实测全平面速度界`.30m/s`、完整角速度范数界`1.2rad/s`、
原角加速度界`7rad/s²`、停车响应`.78s`与路程`.144m`、全平面速度≤`.01m/s`的
连续`3`条唯一raw源样本均不变；积分、位姿差分或更高求解迭代数不能替代这些原门。
任务仍为三机`95%`覆盖、`300s`期限、每机至少`1m`参与及原目标要求，
保留`18`路持续机体接触监测、零真实非支撑接触、`.50m`队友安全包络、原地图质量与导航闭合门。
原`a014`驱动及目标存储协议、actor、候选/掩码、observation/tensor schema、reward和评价器数学不变。

本执行修订本身不授予原生矩阵、95%任务或策略信用。应用后须另立干净推送的新source freeze，
在同一冻结下完成原interface、terminal、reset、deadline四阶段及全部独立门禁；
不得将旧矩阵或隔离对照结果拼接为新矩阵，也不因此启动PPO或重置累计训练余额。
'''
    proposed = original + addition.encode()
    draft = HERE / 'MR3_ENV_CONTRACT.proposed.md'
    with (HERE / 'MR3_ENV_CONTRACT.original.md').open('xb') as stream:
        stream.write(original)
    with draft.open('xb') as stream:
        stream.write(proposed)
    patch = ''.join(difflib.unified_diff(
        original.decode().splitlines(True), proposed.decode().splitlines(True),
        fromfile='a/MR3_ENV_CONTRACT.md', tofile='b/MR3_ENV_CONTRACT.md'))
    with (HERE / 'review_only.patch').open('x') as stream:
        stream.write(patch)
    handoff = f'''# 条件性文档交接：未实施

本目录仅保存未来执行合同草案，尚未选择或应用iters150。
未读取V19数据或正式结果，不据尚未完成的对照授予任何信用。
当前canonical ENV及其pin仍为`{EXPECTED}`，原文件未改。
草案完整新SHA为`{sha(proposed)}`，只有在root完成结果判断并实际应用相同正文后，
才可将它作为新的ENV digest进入审核、冻结和完整矩阵；当前不能刷新运行中的pin。

正文采用未来可用的执行约束措辞，不表示该配置已经实现、验收或获得native信用。
还须应用并核验配套六文件固定补丁及受限auditor projection；
保留所有旧字节和失败，更新新scene/source元数据，并完成新freeze四阶段。
本草案没有加入one-shot读回插件或新的mandatory接口。
'''
    with (HERE / 'handoff_v1.md').open('x') as stream:
        stream.write(handoff)
    assert proposed.startswith(original) and proposed[:len(original)] == original
    assert len(rows) == 6 and all(proposed.count(row.encode()) == 1 for row in rows)
    assert all(not line.endswith((' ', '\t')) for line in addition.splitlines())
    assert 'PASS' not in addition and '已接受' not in addition
    for token in ('1ms', '20ms', '.30m/s', '1.2rad/s', '7rad/s²', '.78s', '.144m',
                  '.01m/s', '`3`条唯一raw', '95%', '300s', '1m', '`18`路', '.50m'):
        assert token in addition, token
    assert ENV.read_bytes() == original and PIN_SOURCE.read_bytes() == pins_raw
    checks = {'schema': 'mr3-conditional-env-contract-draft-checks-v1',
              'passed': True, 'conditional_only': True, 'implemented': False,
              'selected_iters150': False, 'ready': False, 'canonical_source_unchanged': True,
              'original_env_sha256': EXPECTED, 'proposed_env_sha256': sha(proposed),
              'append_only_original_prefix_exact': True, 'six_fixed_sha_rows': len(rows),
              'all_requested_numeric_and_raw_gates_retained': True,
              'native_credit_or_acceptance_claim_added': False,
              'source_pins': {'path': str(PIN_SOURCE), 'sha256': sha(pins_raw)},
              'argv': ['/usr/bin/python3', '-B', str(Path(__file__))],
              'cwd': str(ROOT), 'wall_seconds': time.monotonic() - started,
              'v19_data_or_results_read': False, 'new_native_ros_git_calls': 0}
    with (HERE / 'checks_v1.json').open('x') as stream:
        json.dump(checks, stream, indent=2)
        stream.write('\n')
    print(json.dumps(checks))


if __name__ == '__main__':
    main()
