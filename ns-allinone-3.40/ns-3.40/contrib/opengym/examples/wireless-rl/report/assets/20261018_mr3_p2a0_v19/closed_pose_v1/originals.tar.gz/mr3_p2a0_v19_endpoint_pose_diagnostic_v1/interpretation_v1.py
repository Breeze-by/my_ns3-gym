import hashlib
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def ref(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def rotate(q, p):
    n = math.sqrt(sum(v*v for v in q))
    w, x, y, z = [v/n for v in q]
    return [(1-2*(y*y+z*z))*p[0]+2*(x*y-w*z)*p[1]+2*(x*z+w*y)*p[2],
            2*(x*y+w*z)*p[0]+(1-2*(x*x+z*z))*p[1]+2*(y*z-w*x)*p[2],
            2*(x*z-w*y)*p[0]+2*(y*z+w*x)*p[1]+(1-2*(x*x+y*y))*p[2]]


def main():
    review_path = ROOT/'review_v1.json'
    review = json.loads(review_path.read_bytes())
    geometry = review['source_geometry']
    model_path = Path(geometry['source']['path'])
    assert sha(model_path.read_bytes()) == geometry['source']['sha256']
    model = ET.fromstring(model_path.read_bytes()).find('model')
    scan = model.find("link[@name='base_scan']")
    ray = scan.find("sensor[@type='ray']")
    declared_sensor_pose = [float(v) for v in ray.findtext('pose').split()]
    assert declared_sensor_pose == [-0.064, 0., 0.121, 0., 0., 0.]
    assert scan.find('pose') is None
    assert 'turtlebot3_wall1' not in geometry['active_link_names']
    assert 'turtlebot3_tray' not in geometry['active_link_names']
    range_max = float(ray.findtext('ray/range/max'))
    range_min = float(ray.findtext('ray/range/min'))
    rows = []
    source_rows_selected = 0
    for robot in review['results']:
        source_rows_selected += len(robot['selected_rows'])
        phases = [sample for endpoint in robot['endpoints']
                  for sample in endpoint['exact_same_clock_pre_post']]
        zs = [sample['base']['world_pose']['position_xyz'][2] for sample in phases]
        rolls = [sample['base']['rpy_degrees'][0] for sample in phases]
        pitches = [sample['base']['rpy_degrees'][1] for sample in phases]
        predictions = []
        for endpoint in robot['endpoints']:
            for sample in endpoint['exact_same_clock_pre_post']:
                pose = sample['base']['world_pose']
                world_sensor_offset = rotate(pose['quaternion_wxyz'], declared_sensor_pose[:3])
                origin = [a+b for a, b in zip(pose['position_xyz'], world_sensor_offset)]
                # Source sensor has zero roll/pitch relative to the declared frame.
                rotation_x = rotate(pose['quaternion_wxyz'], [1., 0., 0.])
                rotation_y = rotate(pose['quaternion_wxyz'], [0., 1., 0.])
                max_downward_unit = math.hypot(rotation_x[2], rotation_y[2])
                predictions.append({'endpoint': endpoint['name'], 'phase': sample['phase'],
                                    'predicted_sensor_origin_xyz': origin,
                                    'max_ray_downward_vertical_unit': max_downward_unit,
                                    'predicted_min_z_at_declared_max_range': origin[2]-range_max*max_downward_unit,
                                    'scope': 'Kinematic prediction from measured base pose and source-declared rigid offset/zero relative rotation; base_scan/sensor pose itself was not observed.'})
        pre_start, post_start = robot['endpoints'][0]['exact_same_clock_pre_post']
        pre_end, post_end = robot['endpoints'][1]['exact_same_clock_pre_post']
        rows.append({'stage': robot['stage'], 'robot': robot['robot'],
                     'same_clock_endpoint_base_z_range_m': [min(zs), max(zs)],
                     'same_clock_endpoint_base_roll_range_deg': [min(rolls), max(rolls)],
                     'same_clock_endpoint_base_pitch_range_deg': [min(pitches), max(pitches)],
                     'post_start_to_post_end_xyz_delta_m': [b-a for a,b in zip(post_start['base']['world_pose']['position_xyz'], post_end['base']['world_pose']['position_xyz'])],
                     'post_start_to_post_end_xy_chord_m': math.dist(post_start['base']['world_pose']['position_xyz'][:2], post_end['base']['world_pose']['position_xyz'][:2]),
                     'max_fixed_base_relative_canonical_position_norm_m': max(math.sqrt(sum(v*v for v in sample['base_relative_canonical']['position_xyz'])) for sample in phases),
                     'max_fixed_base_relative_canonical_rpy_abs_deg': max(abs(v) for sample in phases for v in sample['base_relative_canonical']['rpy_degrees']),
                     'endpoint_motor_targets_all_zero': all(j['motor_velocity_target_radps'] == 0 for sample in phases for j in sample['joints_right_left']),
                     'max_endpoint_wheel_actual_abs_radps': max(abs(j['velocity_radps']) for sample in phases for j in sample['joints_right_left']),
                     'sensor_kinematic_predictions': predictions})
    interpretation = {'schema': 'mr3-v19-endpoint-pose-description-v1',
                      'scope': 'Description of selected actual endpoint states and explicit source-geometry prediction, not a full trajectory or unique causal attribution.',
                      'input_review': ref(review_path),
                      'formal_reviews': review['formal_reviews'],
                      'total_large_source_bytes_read': sum(row['io']['bytes_read_including_binary_probes'] for row in review['results']),
                      'total_original_rows_selected': source_rows_selected,
                      'stages_actual_task_intervals_ns': {stage: [next(r for r in review['results'] if r['stage']==stage)['endpoints'][0]['clock_ns'], next(r for r in review['results'] if r['stage']==stage)['endpoints'][1]['clock_ns']] for stage in ('baseline','iters150')},
                      'per_robot': rows,
                      'laser_source': {'sdf': geometry['source'], 'urdf': geometry['urdf_source'],
                                       'active_sdf_link_pose_base_scan': 'absent; SDF default model-relative zero at initialization',
                                       'active_sdf_lidar_fixed_joint_name': 'lidar_joint',
                                       'active_sdf_sensor_pose': declared_sensor_pose,
                                       'urdf_scan_joint_origin_xyz': [-0.064, 0., 0.121],
                                       'declared_range_min_max_m': [range_min,range_max],
                                       'active_tray_or_wall_link_present': False,
                                       'scope': 'XML parse excludes commented tray/wall text. Does not establish actual ray return source or sampled scan range.'},
                      'observations': ['At these exact task start/end samples, contrast base height and small pitch/roll are of the same order as baseline; no endpoint evidence of a toppled robot or large height change.',
                                       'Contrast selected endpoint motor targets are zero and measured wheel velocities are small; this is not a claim about every task sample.',
                                       'Contrast rigid base/canonical relative pose errors are smaller than baseline in these selected samples.',
                                       'Under the declared rigid sensor transform only, all predicted endpoint rays remain above z=0 even at declared10m max range; no actual laser samples or actual base_scan pose were extracted.',
                                       'Endpoints do not exclude transient startup/task tilt, sensor noise, own-body reflections or SLAM/scan state effects.'],
                      'no_physical_gate_or_verdict_changed': True,
                      'new_native_calls': 0, 'new_formal_audits': 0, 'canonical_writes': 0}
    output = ROOT/'description_v1.json'
    with output.open('x') as stream:
        json.dump(interpretation,stream,indent=2);stream.write('\n')
    print(json.dumps({'description':ref(output), 'rows':source_rows_selected,
                      'total_large_source_bytes_read':interpretation['total_large_source_bytes_read'],
                      'contrast_predictions_min_z_m': min(item['predicted_min_z_at_declared_max_range'] for row in rows if row['stage']=='iters150' for item in row['sensor_kinematic_predictions'])}))


if __name__ == '__main__':
    main()
