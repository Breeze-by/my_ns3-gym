"""Archive closed V19 original receipts and descriptive helpers, never regrade."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
TARGET = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v19/closed_core_v3'
assert not TARGET.exists()
started = time.monotonic()
excluded = ('conditional_', 'progress_', 'os_progress_', 'remaining_exit_', 'report_draft_',
            'root_static_precommit_', 'precommit_add_', 'six_file_consumer_', 'diagnostics.lock')
files = [p for p in sorted(Path('/tmp').glob('mr3_p2a0_v19_*'))
         if p.is_file() and not any(part in p.name for part in excluded)]
for name in ('baseline_live_witness', 'iters150_live_witness',
             'paired_zero_motor_analysis_checks_v1', 'paired_zero_motor_run_checks_v1'):
    files.extend(p for p in sorted((Path('/tmp') / ('mr3_p2a0_v19_' + name)).rglob('*')) if p.is_file())
files.extend(Path('/tmp') / ('source_bindings_72d0465ddd1b.' + suffix) for suffix in ('json', 'tar.gz'))
files = sorted(set(files + [Path(__file__)]))
assert len(files) == len(set(files))
TARGET.mkdir()
buffer = io.BytesIO()
entries = []
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for path in sorted(files):
        before = path.stat()
        raw = path.read_bytes()
        assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns) == (path.stat().st_dev,path.stat().st_ino,path.stat().st_size,path.stat().st_mtime_ns,path.stat().st_ctime_ns) and len(raw) < 100000000
        name = str(path.relative_to('/tmp'))
        info = tarfile.TarInfo(name)
        info.size, info.mtime, info.mode = len(raw), 0, 0o644
        archive.addfile(info, io.BytesIO(raw))
        entries.append({'source': str(path), 'member': name, 'bytes': len(raw),
                        'sha256': hashlib.sha256(raw).hexdigest(),
                        'stat_before_after': [before.st_dev, before.st_ino, before.st_size,
                                              before.st_mtime_ns, before.st_ctime_ns]})
encoded = gzip.compress(buffer.getvalue(), compresslevel=6, mtime=0)
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(encoded))) as archive:
    assert archive.getnames() == [row['member'] for row in entries]
    for row in entries:
        raw = archive.extractfile(row['member']).read()
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
        path = Path(row['source'])
        value = path.stat()
        assert [value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns] == row['stat_before_after']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
(TARGET / 'originals.tar.gz').write_bytes(encoded)
result = {'schema': 'mr3-v19-closed-core-original-custody-v3',
          'freeze': '72d0465ddd1bbee09af117cfd9d89b7e729f8578',
          'scope': 'Closed execution/formal/loaded witnesses/source-pack/CPU and descriptive originals. No acceptance or retroactive result change.',
          'archive': 'originals.tar.gz', 'archive_bytes': len(encoded),
          'archive_sha256': hashlib.sha256(encoded).hexdigest(), 'original_count': len(entries),
          'original_bytes': sum(row['bytes'] for row in entries), 'files': entries,
          'roundtrip_and_source_final_sha_stat_verified': True,
          'wall_seconds': time.monotonic() - started}
(TARGET / 'manifest_v1.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ('original_count', 'original_bytes', 'archive_bytes', 'archive_sha256', 'wall_seconds')}))
