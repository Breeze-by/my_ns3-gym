"""Archive only closed V10 originals; frozen source is read exclusively from Git631."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
import time

ROOT=Path('/home/zhuyulab/ns3-workspace')
FREEZE='631d8c35c43fdb7ed45e984376543e55395066ef'
A10=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v10'
TEMP=Path('/tmp');PREFIX='mr3_p2a0_v10_interface'
sha=lambda b:hashlib.sha256(b).hexdigest()
js=lambda p:json.loads(p.read_bytes())
execution=js(TEMP/(PREFIX+'_audit_execution_v1.json'))
launch=js(TEMP/(PREFIX+'_launch.json'))
assert execution['freeze']==launch['freeze']==FREEZE and launch['status']=='completed'
assert execution['passed'] is False and launch['passed'] is False
run=ROOT/'ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261017_v10_interface'
summary=js(run/'benchmark_summary.json')
episode=run/'worker0/episode001_open_101'
shutdown=js(episode/'supervisor_shutdown.json')
assert (episode/'transitions.jsonl').read_bytes()==b''
# Bind every tracked original A10 byte to its frozen object; do not read current sources.
git_tar=subprocess.check_output(['git','archive','--format=tar',FREEZE,'--',str(A10.relative_to(ROOT))],cwd=ROOT)
frozen=[]
with tarfile.open(fileobj=io.BytesIO(git_tar),mode='r:')as stream:
 for member in stream:
  if not member.isfile():continue
  raw=stream.extractfile(member).read();p=ROOT/member.name
  assert p.read_bytes()==raw,member.name+' changed frozen A10 byte'
  frozen.append({'path':member.name,'sha256':sha(raw),'bytes':len(raw)})
assert len(frozen)==723
prefreeze=js(A10/'inventory_prefreeze_v1.json');frozen_paths={e['path']for e in frozen};untracked=[]
for entry in prefreeze['files']:
 p=A10/entry['path'];raw=p.read_bytes();assert len(raw)==entry['bytes']and sha(raw)==entry['sha256']
 if str(p.relative_to(ROOT))not in frozen_paths:untracked.append(entry)
assert len(prefreeze['files'])==724 and len(untracked)==2
# Existing exact source pack made before edits; verify tar members against Git objects.
preflight=js(TEMP/'mr3_p2a0_v10_source_preflight.json')
source_manifest=TEMP/('source_bindings_'+FREEZE[:12]+'.json')
source_archive=source_manifest.with_suffix('.tar.gz')
source_proof=js(source_manifest);encoded=source_archive.read_bytes();decoded=gzip.decompress(encoded)
assert preflight['freeze']==source_proof['freeze']==FREEZE and preflight['passed']is True
assert sha(encoded)==source_proof['encoded_sha256']and sha(decoded)==source_proof['tar_sha256']
paths=sorted(preflight['source_bindings']);assert len(paths)==100
with tarfile.open(fileobj=io.BytesIO(decoded),mode='r:')as stream:
 members={m.name:m for m in stream if m.isfile()};assert set(members)==set(paths)
 for path in paths:
  raw=stream.extractfile(members[path]).read()
  git_raw=subprocess.check_output(['git','show',FREEZE+':'+path],cwd=ROOT)
  assert raw==git_raw and sha(raw)==preflight['source_bindings'][path]['sha256']
assert len(preflight['independent_source_bindings'])==59
# Transfer the selected native originals and recheck raw/decoded and encoded identities.
selected=TEMP/'mr3_p2a0_v10_selected_native/interface'
native_manifest=js(selected/'manifest.json');target=A10/'native/interface'
assert not target.exists();shutil.copytree(selected,target)
for row in native_manifest['files']:
 p=target/row['selected'];data=p.read_bytes();raw=gzip.decompress(data)if row['encoding']=='gzip'else data
 assert len(data)==row['selected_bytes']and sha(data)==row['selected_sha256']
 assert len(raw)==row['raw_bytes']and sha(raw)==row['raw_sha256']
 assert (selected/row['selected']).read_bytes()==data
assert (target/'manifest.json').read_bytes()==(selected/'manifest.json').read_bytes()
for p in (source_manifest,source_archive):
 dest=A10/'independent'/p.name;assert not dest.exists();dest.write_bytes(p.read_bytes())
# No old canonical file is changed. New diagnostics are stored losslessly with explicit mapping.
originals=set(TEMP.glob(PREFIX+'*'))
for pattern in ('mr3_p2a0_v10_final_plan_command_review_v2.*','mr3_p2a0_v10_protocol_readonly_review_v1.*','mr3_p2a0_v10_reader_sticky_negative_review_v1.*'):
 originals.update(TEMP.glob(pattern))
for name in ('mr3_p2a0_v10_source_preflight.json','mr3_p2a0_v10_binaryproof.json','mr3_p2a0_v10_pack_native_v1.py','mr3_p2a0_v10_pack_source_bindings_v1.py','mr3_p2a0_v10_native_cli_review_v1.json','mr3_p2a0_v10_phase_live_monitor_v1.py','mr3_p2a0_v10_capture_check.py'):
 p=TEMP/name;assert p.exists(),name;originals.add(p)
originals.add(Path(__file__))
archive=A10/'independent/native_originals_v1';archive.mkdir(exist_ok=False)
entries=[]
for p in sorted(originals):
 if not p.is_file():continue
 raw=p.read_bytes();encoded=gzip.compress(raw,mtime=0);dest=archive/(p.name+'.gz')
 with dest.open('xb')as out:out.write(encoded)
 assert gzip.decompress(dest.read_bytes())==raw and p.read_bytes()==raw
 entries.append({'source':str(p),'selected_path':str(dest.relative_to(ROOT)),'raw_bytes':len(raw),'raw_sha256':sha(raw),'selected_bytes':len(encoded),'selected_encoded_sha256':sha(encoded),'selected_decoded_sha256':sha(gzip.decompress(encoded)),'decoded_equals_raw':True})
originals_manifest={'schema':'mr3-v10-closed-native-support-originals-v1','freeze':FREEZE,'count':len(entries),'passed':True,'entries':entries,'scope':'All final interface formal outputs, failed console traces, diagnostics, seven actual /proc map snapshots, source/binary preflight and review tools. No absent formal result is fabricated; all originals remain unmodified.'}
(archive/'manifest.json').write_text(json.dumps(originals_manifest,indent=2)+'\n')
# Preserve factual cost and distinct closure/absence facts; strict fail stays failed.
allgone=js(TEMP/(PREFIX+'_allgone_fresh_v1.json'))
account={'schema':'mr3-v10-closed-engineering-cost-v1','freeze':FREEZE,'stage':'interface','stage_passed':False,'attempted_environments':1,'attempted_resets':1,'returned_resets':0,'returned_steps':0,'saved_transition_records':0,'gpu_calls':0,'optimizer_updates':0,'launcher_wall_seconds':launch['wall_duration_sec'],'benchmark_wall_seconds_including_attempts':summary['wall_sec_including_all_attempts'],'declared_matrix_wall_seconds':18000,'later_stages':{s:'SKIPPED_after_interface_failure'for s in ('terminal','reset','deadline')},'pilot_budget_unchanged':{'remaining_decisions':1870,'remaining_wall_seconds':2905.954739546403},'first_failure':summary['preparation_abort']['first_failure'],'formal_audit_execution_passed':execution['passed'],'formal_commands':[{k:r.get(k)for k in ('label','returncode','passed','output_exists')}for r in execution['commands']],'strict_closure':{k:shutdown[k]for k in ('epoch','worker_returncode','forced_shutdown','failed_sample','remaining_owned_processes','remaining_owned_zombies')},'fresh_saved_identity_count':allgone['saved_identity_count'],'fresh_same_identity_present':allgone['same_identity_present'],'fresh_absence_is_not_strict_closure_pass':True,'native_selected_files':native_manifest['source_files'],'native_raw_bytes':native_manifest['raw_bytes'],'native_selected_bytes':native_manifest['selected_bytes'],'sourcepack_files':len(paths),'prefreeze_git_files_including_inventory':len(frozen),'prefreeze_inventory_entries':len(prefreeze['files']),'inventory_originals_not_in_freeze':untracked,'scope':'Engineering failure and collection costs only; no task release, training, candidate execution, safety/body,95% or P2A/P2A.0 acceptance credit.'}
accountdir=A10/'accounting';accountdir.mkdir(exist_ok=False);cost=accountdir/'native_cost_v1.json';cost.write_text(json.dumps(account,indent=2)+'\n')
verification={'schema':'mr3-v10-native-archive-verification-v1','passed':True,'freeze':FREEZE,'native_selected_files':len(native_manifest['files']),'support_originals':len(entries),'sourcepack_files':len(paths),'sourcepack_encoded_sha256':sha(source_archive.read_bytes()),'sourcepack_tar_sha256':sha(decoded),'prefreeze_git_files_unchanged':len(frozen),'prefreeze_inventory_entries_unchanged':len(prefreeze['files']),'prefreeze_inventory_originals_not_tracked_at_freeze':untracked,'prefreeze_git_bindings':frozen,'native_manifest_sha256':sha((target/'manifest.json').read_bytes()),'originals_manifest_sha256':sha((archive/'manifest.json').read_bytes()),'accounting_sha256':sha(cost.read_bytes()),'scope':'Lossless byte/Git/source/encoded-and-decoded archive verification. Failure results and absent formal observer outputs are preserved, never converted to PASS.'}
v=A10/'independent/native_archive_verification_v1.json';v.write_text(json.dumps(verification,indent=2)+'\n')
# Final self-excluded complete A10 inventory. Root may later append evidence only by new version.
inventory=A10/'inventory_native_v1.json';assert not inventory.exists()
files=[p for p in sorted(A10.rglob('*'))if p.is_file()and p!=inventory]
inv={'schema':'mr3-inventory-native-v1','freeze':FREEZE,'self_excluded':True,'files':[{'path':str(p.relative_to(A10)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in files]}
inventory.write_text(json.dumps(inv,indent=2)+'\n')
# Recheck every byte in all manifest inventories after writes.
for row in inv['files']:
 p=A10/row['path'];assert p.stat().st_size==row['bytes']and sha(p.read_bytes())==row['sha256']
for row in frozen:assert sha((ROOT/row['path']).read_bytes())==row['sha256']
result={'passed':True,'freeze':FREEZE,'archive_verification':str(v),'archive_verification_sha256':sha(v.read_bytes()),'inventory':str(inventory),'inventory_files_selfexcluded':len(inv['files']),'inventory_sha256':sha(inventory.read_bytes()),'native_selected_files':len(native_manifest['files']),'support_originals':len(entries),'native_raw_bytes':native_manifest['raw_bytes'],'native_selected_bytes':native_manifest['selected_bytes'],'sourcepack_files':len(paths),'sourcepack_independent_bindings':len(preflight['independent_source_bindings']),'cost_receipt':str(cost),'strict_closure_passed':False,'fresh_saved_identities_absent':not allgone['same_identity_present']}
output=TEMP/'mr3_p2a0_v10_closed_archive_receipt_v1.json'
with output.open('x')as out:out.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
