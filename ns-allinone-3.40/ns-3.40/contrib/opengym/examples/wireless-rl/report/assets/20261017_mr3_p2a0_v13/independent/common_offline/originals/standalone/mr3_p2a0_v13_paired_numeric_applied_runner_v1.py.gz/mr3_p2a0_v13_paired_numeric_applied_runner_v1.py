"""Shortest canonical C++ regression verification, without colcon or native ROS."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT=Path('/home/zhuyulab/ns3-workspace')
HEADER=ROOT/'ros2_ws/ros2-multi-robot-automap/src/multi_robot/include/multi_robot/paired_wheel_slew.hpp'
TEST=ROOT/'ros2_ws/ros2-multi-robot-automap/src/multi_robot/test/test_paired_wheel_slew.cpp'
PREFIX=Path('/tmp/mr3_p2a0_v13_paired_numeric')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={str(p):sha(p) for p in (HEADER,TEST)}
include=str(HEADER.parents[1]);binary=str(PREFIX)+'_gtest_v1'
compile_argv=['g++','-std=c++17','-O2','-Wall','-Wextra','-Werror','-pedantic','-I'+include,str(TEST),'-lgtest','-lgtest_main','-pthread','-o',binary]
commands=[]
def run(label,argv):
 began=time.monotonic();p=subprocess.run(argv,cwd=ROOT,text=True,capture_output=True);elapsed=time.monotonic()-began
 path=Path(str(PREFIX)+'_'+label+'_v1.log');path.write_text(p.stdout+p.stderr)
 row={'label':label,'argv':argv,'cwd':str(ROOT),'returncode':p.returncode,'wall_sec':elapsed,'output':str(path),'output_sha256':sha(path)};commands.append(row);return p
began=time.monotonic();built=run('gtest_build',compile_argv)
if built.returncode==0:run('gtest_run',[binary])
run('diff_check',['git','diff','--check','--',str(HEADER.relative_to(ROOT)),str(TEST.relative_to(ROOT))])
parent=subprocess.run(['git','rev-parse','d48b939'],cwd=ROOT,text=True,capture_output=True,check=True).stdout.strip()
original={str(p):hashlib.sha256(subprocess.run(['git','show',parent+':'+str(p.relative_to(ROOT))],cwd=ROOT,capture_output=True,check=True).stdout).hexdigest() for p in (HEADER,TEST)}
proposal=Path('/tmp/mr3_paired_wheel_numeric_proposal_v1')
prior={str(p):sha(p) for p in (proposal/'checks_v2.json',proposal/'permanent_regression_checks_v1.json',proposal/'explicit_comparisons_v1.json',proposal/'original_gtest_run.log',proposal/'proposed_gtest_run.log')}
result={'schema':'mr3-paired-wheel-numeric-applied-checks-v1','scope':'Only production header and its existing gtest source changed. Canonical standalone CPU compile/gtest plus scoped diff check; no colcon/native/GPU/optimizer or commit.','based_on_archive_commit':parent,'passed':len(commands)==3 and all(row['returncode']==0 for row in commands),'commands':commands,'source_before_checks':before,'source_after_checks':{str(p):sha(p) for p in (HEADER,TEST)},'source_checks_unchanged':all(sha(Path(p))==v for p,v in before.items()),'archive_original_source_hashes':original,'total_wall_sec':time.monotonic()-began,'prior_cpu_evidence':prior,'prior_red_green_scope':'Preserved original helper: original8 pass plus new4 FAIL; proposed exact same final header/test bytes:12 PASS. Prior 30085 exact-Fraction cases passed new proposal; not counted as a second fresh run here.','proposal_bytes_identical':HEADER.read_bytes()==(proposal/'proposed.hpp').read_bytes() and TEST.read_bytes()==(proposal/'test_paired_wheel_slew_proposed.cpp').read_bytes()}
output=Path('/tmp/mr3_p2a0_v13_paired_numeric_applied_checks_v1.json');output.write_text(json.dumps(result,indent=2)+chr(10));print(json.dumps({'output':str(output),'sha256':sha(output),'passed':result['passed'],'commands':commands,'source_after_checks':result['source_after_checks'],'total_wall_sec':result['total_wall_sec']},indent=2));raise SystemExit(0 if result['passed'] and result['source_checks_unchanged'] and result['proposal_bytes_identical'] else 1)
