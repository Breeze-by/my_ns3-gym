"""Read small immutable preflight/plan/sourcepack metadata, never active traces."""
import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, '/tmp')
import mr3_p2a0_v14_archive_closed_v1 as H  # noqa: E402

plan = H.load_context()
preflight = H.read(H.TEMP / (H.PREFIX + '_source_preflight.json'))
proof_path = H.TEMP / ('source_bindings_' + H.FREEZE[:12] + '.json')
proof = H.read(proof_path)
paths = H.verify_sourcepack_paths(preflight, proof, H.expected_runtime_paths())
result = dict(
    passed=True, freeze=H.FREEZE, plan_sha256=H.PLAN_SHA,
    runtime_paths=len(paths), independent_bindings=len(plan['independent_source_bindings']),
    sourcepack_metadata_sha256=hashlib.sha256(proof_path.read_bytes()).hexdigest(),
    binary_sha256=H.read(Path(preflight['binary_proof']))['library_sha256'],
    active_raw_traces_read=False, archive_helpers_executed=False,
    scope='Small actual immutable metadata binding only; no pack/publish/formal audit/native credit.')
with (Path(__file__).parent / 'context01.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result, indent=2))
