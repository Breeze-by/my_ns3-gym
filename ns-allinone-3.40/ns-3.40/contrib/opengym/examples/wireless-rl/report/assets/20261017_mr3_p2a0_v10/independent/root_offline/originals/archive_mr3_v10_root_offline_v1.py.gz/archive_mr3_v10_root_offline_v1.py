from pathlib import Path
import gzip
import hashlib
import json

root=Path('/home/zhuyulab/ns3-workspace')
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
a=w/'report/assets/20261017_mr3_p2a0_v10'
out=a/'independent/root_offline';out.mkdir(exist_ok=True)
names=['mr3_p2a0_v10_capture_check.py','update_mr3_v10_docs.py','prepare_mr3_v10_tools.py','prepare_mr3_v10_contract_tool.py','update_mr3_v10_observers.py','pin_mr3_v10_runtime.py','refresh_mr3_v10_runtime_pins.py','finalize_mr3_v10_plan.py','archive_mr3_v9_completion_v2.py','archive_mr3_v10_root_offline_v1.py','mr3_p2a0_v10_runtime_import_bindings.json','mr3_p2a0_v10_runtime_import_bindings_v2.json','mr3_p2a0_v10_contract_static_draft_01.json','mr3_p2a0_v10_contract_static_final.json']
records=[]
def add(src,relative,role):
    raw=src.read_bytes();encoded=gzip.compress(raw,mtime=0);dst=out/(relative+'.gz')
    dst.parent.mkdir(parents=True,exist_ok=True)
    with dst.open('xb') as f:f.write(encoded)
    assert gzip.decompress(dst.read_bytes())==raw
    records.append({'original':str(src),'archived':str(dst.relative_to(a)), 'role':role,'raw_bytes':len(raw),'raw_sha256':hashlib.sha256(raw).hexdigest(),'encoded_bytes':len(encoded),'encoded_sha256':hashlib.sha256(encoded).hexdigest()})
for name in names:
    add(Path('/tmp')/name,'originals/'+name,'exact retained root tool or real result; not an earlier source snapshot')
bindings={}
for label in ('ros_semantic_v10_final_v3','conda_cpu_v10_final_v4','style_v10_final_v3','build_v10_final','runtime_imports_v10_final_v2','plan_launcher_v10_final_v3','contract_static_v10_final'):
    p=a/(label+'.json');value=json.loads(p.read_text())
    assert value['exit_code']==0
    bindings[label]={'path':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'all_source_before_after_equal':value['source_before']==value['source_after']}
    for logkey in ('stdout_stderr_gzip',):
        raw=gzip.decompress((a/value[logkey]).read_bytes())
        assert hashlib.sha256(raw).hexdigest()==value['decoded_sha256']
for relative in sorted(set().union(*(set(json.loads((a/(name+'.json')).read_text())['source_after']) for name in bindings))):
    p=root/relative
    if p.is_file() and p.suffix=='.py' and '/report/assets/' not in relative:
        add(p,'final_source/'+relative,'final precommit source only; never substituted for earlier check inputs')
manifest={'schema':'mr3-root-offline-originals-v1','originals':records,'final_check_bindings':bindings,'limitations':['Root check receipts retain real argv/cwd/Python/source-before-after hashes and lossless stdout, including all failed preliminary checks. Not every earlier draft source was independently snapshotted. Final_source entries explicitly represent only the final current source.','Synthetic and mocked CLI checks are not native execution, driver latency, continuous body safety, policy reliability or training evidence.']}
p=out/'manifest.json';assert not p.exists();p.write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'passed':True,'originals':len(records),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'checks':bindings}))
