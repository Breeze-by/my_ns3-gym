"""Final fixed runtime adapter CPU receipts; no actual preflight/native invocation."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

D=Path(__file__).parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
paths=[D/'mr3_p2a0_v21_ray_preflight_v1.py',D/'test_runtime_projection.py']
before={str(p):sha(p.read_bytes()) for p in paths}
command=['/usr/bin/python3','-B',str(paths[1]),'-v'];start=time.monotonic();result=subprocess.run(command,capture_output=True)
(D/'runtime_projection_checks_v1.stdout.log').write_bytes(result.stdout)
(D/'runtime_projection_checks_v1.stderr.log').write_bytes(result.stderr)
wall=time.monotonic()-start
for p in paths:compile(p.read_bytes(),str(p),'exec')
stable=all(sha(Path(p).read_bytes())==v for p,v in before.items());assert stable
record={'passed':result.returncode==0,'argv':command,'exit_code':result.returncode,'wall_seconds':wall,
        'methods':4,'source_sha256':before,'source_stable':stable,'python_compile':True,
        'scope':'Fixed2source byteprojection and full dict restoration. Actual newsource bytes+normative Git read; freezeactual Git I/O and oldloader replaced by finite CPU fixtures. No actual full loader/preflight/SDK/DDS/ROS/Gazebo/native.',
        'stdout':str(D/'runtime_projection_checks_v1.stdout.log'),'stderr':str(D/'runtime_projection_checks_v1.stderr.log')}
(D/'checks_runtime_projection_v1.json').write_text(json.dumps(record,indent=2)+'\n')
print(result.stderr.decode());print(json.dumps(record,indent=2))
if result.returncode:raise SystemExit(result.returncode)
