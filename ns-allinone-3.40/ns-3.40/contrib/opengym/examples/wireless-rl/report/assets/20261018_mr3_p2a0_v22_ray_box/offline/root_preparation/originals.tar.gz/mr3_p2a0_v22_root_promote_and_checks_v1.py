import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT=Path('/home/zhuyulab/ns3-workspace')
W=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A=W/'report/assets/20261018_mr3_p2a0_v22_ray_box'
OUT=Path('/tmp/mr3_p2a0_v22_root_conda16_v1')
assert not OUT.exists()
OUT.mkdir()
h=json.loads(Path('/tmp/mr3_p2a0_v22_production_auditor_proposal_v6/handoff_v6.json').read_text())
assert h['source_writers_stopped']
for item in h['files']:
    source=Path(item['source']); dest=ROOT/item['canonical']
    raw=source.read_bytes()
    assert hashlib.sha256(raw).hexdigest()==item['sha256']
    assert hashlib.sha256(dest.read_bytes()).hexdigest()==item['before_sha256']
    dest.write_bytes(raw)
copy_records=[]
def copy(source, dest, sha=None):
    source=Path(source); dest=A/dest
    raw=source.read_bytes(); digest=hashlib.sha256(raw).hexdigest()
    if sha: assert digest==sha,source
    assert not dest.exists(),dest
    dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(raw)
    assert dest.read_bytes()==raw
    copy_records.append({'source':str(source),'destination':str(dest.relative_to(ROOT)), 'bytes':len(raw),'sha256':digest})
review=Path('/tmp/mr3_p2a0_v22_canonical_build_independent_review_v1')
copy('/tmp/mr3_p2a0_v22_canonical_build02_originals_v1.tar.gz','offline/canonical_build02/originals.tar.gz','2d9897a993d56a4de211d1d3adce2d483d57137250f7692dbd6ca72d1d62af33')
copy(review/'custody_manifest_v1.json','offline/canonical_build02/manifest_v1.json','30a91f37338eeade317456f8245d6fa8253a959d01024340806273ca3d8241b1')
copy(review/'handoff_v1.json','offline/canonical_build02/handoff_v1.json')
copy('/tmp/mr3_p2a0_v22_corrector_custody_sealed_v1.tar.gz','offline/corrector_custody/originals.tar.gz','8bfd3b62c96b791927b564d7f257c3db022a19b862aef2054ef99c71fce4ebe7')
custody=Path('/tmp/mr3_p2a0_v22_corrector_custody_proposal_v1')
copy(custody/'sealed_manifest_v1.json','offline/corrector_custody/manifest_v1.json','cdc06c895101a33a938144358f1cdc0823a1d8d6610bbb4635ed6b92c183f8b0')
copy(custody/'handoff_v1.json','offline/corrector_custody/handoff_v1.json')
(OUT/'promotion_and_copy.json').write_text(json.dumps({'schema':'mr3-v22-root-source-promotion-and-copy-v1','promoted_test':h,'copies':copy_records},indent=2)+'\n')
argv=['/home/zhuyulab/miniconda3/envs/ns3gym/bin/python','-B','-m','unittest','mr3_learning.tests.test_audit_ppo']
env=os.environ.copy(); env.pop('PYTHONPATH',None); env.update(PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1')
start=time.monotonic()
with (OUT/'stdout.txt').open('xb') as out,(OUT/'stderr.txt').open('xb') as err:
    child=subprocess.run(argv,cwd=W,env=env,stdout=out,stderr=err)
result={'schema':'mr3-v22-root-canonical-conda16-v1','argv':argv,'cwd':str(W),'environment':{'PYTHONPATH':None,'PYTHONNOUSERSITE':'1','PYTHONDONTWRITEBYTECODE':'1'},'returncode':child.returncode,'wall_seconds':time.monotonic()-start,'scope':'Actual canonical audit unit module, CPU only; no full source admission or native run.'}
(OUT/'execution.json').write_text(json.dumps(result,indent=2)+'\n')
print((OUT/'stderr.txt').read_text()[-2500:]); print(json.dumps(result))
raise SystemExit(child.returncode)
