#!/usr/bin/env python3
"""Read-only review and lossless custody of completed V24 canonical build."""
import datetime
import gzip
import hashlib
import io
import json
import os
import pathlib
import re
import stat
import subprocess
import sys
import tarfile
import time

REPO = pathlib.Path('/home/zhuyulab/ns3-workspace')
ROS = REPO / 'ros2_ws/ros2-multi-robot-automap'
BUILD = pathlib.Path('/tmp/mr3_p2a0_v24_canonical_build_v1')
OUT = pathlib.Path(__file__).parent
ASSETS = REPO / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v24_install'
AUTHOR = pathlib.Path('/tmp/mr3_p2a0_v22_ray_box_corrector_proposal_v1')
GETTER = pathlib.Path('/tmp/mr3_p2a0_v24_install_lifecycle_proposal_v1')
EXPECTED = {
    'src/mr3_ray_box_corrector.cpp': 'f82646c8434b77c42f585ac1828eda84640bac873f70cc7de6848cfbd6493473',
    'src/mr3_ray_box_collision.cpp': 'd556dda57250da3680a7d5a9862416f6196cab9763e495ee75269307b87715cb',
    'include/multi_robot/mr3_ray_box_collision.hpp': 'c619442d038e4bc6ea0695ada34d7074ee83d775b2137222ab9fb6bf8193879b'}
SO_SHA = '782d388fea8df3646524e54f41d71de5f53480b9d04cc0ea1c453c70e2c1f7d8'
inputs = {}
cache = {}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def st(value):
    return {key: getattr(value, key) for key in
            ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_mode')}


def capture(path, expected=None, expected_bytes=None):
    path = pathlib.Path(path).absolute()
    key = str(path)
    if key in inputs:
        row = inputs[key]
        if expected is not None: assert row['sha256'] == expected, key
        if expected_bytes is not None: assert row['bytes'] == expected_bytes, key
        return cache[key]
    lbefore = st(path.lstat())
    resolved = str(path.resolve(strict=True))
    fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC)
    try:
        before = st(os.fstat(fd))
        parts = []
        while True:
            part = os.read(fd, 1024 * 1024)
            if not part: break
            parts.append(part)
        data = b''.join(parts)
        after = st(os.fstat(fd))
    finally:
        os.close(fd)
    assert before == after == st(path.stat()), key
    assert lbefore == st(path.lstat()), key
    digest = sha(data)
    if expected is not None: assert digest == expected, key
    if expected_bytes is not None: assert len(data) == expected_bytes, key
    inputs[key] = {'path': key, 'resolved_path': resolved, 'bytes': len(data),
                   'sha256': digest, 'is_elf': data.startswith(b'\x7fELF'),
                   'stat_before': before, 'stat_after': after,
                   'lstat_before': lbefore, 'lstat_after': st(path.lstat())}
    cache[key] = data
    return data


def capture_row(row):
    return capture(row['path'], row['sha256'], row['bytes'])


def add_member(tar, name, data, mode=0o644):
    item = tarfile.TarInfo(name)
    item.size = len(data)
    item.mode = stat.S_IMODE(mode)
    item.mtime = item.uid = item.gid = 0
    item.uname = item.gname = ''
    tar.addfile(item, io.BytesIO(data))


began = time.monotonic()
utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
execution_path = BUILD / 'execution.json'
execution_bytes = capture(execution_path)
execution = json.loads(execution_bytes)
assert execution['passed'] is True
assert execution['sources_before'] == execution['sources_after']
assert execution['old_libraries_before'] == execution['old_libraries_after']
for key, row in execution['sources_before'].items():
    capture_row(row)
    if key in EXPECTED: assert row['sha256'] == EXPECTED[key], key
for row in execution['old_libraries_after'].values(): capture_row(row)
library = capture_row(execution['installed_new_library'])
assert len(library) == 398080 and sha(library) == SO_SHA
assert library.startswith(b'\x7fELF')
build_library = ROS / 'build/multi_robot/libmr3_ray_box_corrector.so'
assert capture(build_library, SO_SHA, 398080) == library
assert os.path.samefile(build_library, execution['installed_new_library']['path'])
for digest in EXPECTED.values(): assert digest.encode() in library
flags = capture_row(execution['new_target_flags']).decode()
link = capture_row(execution['new_target_link']).decode()
for digest in EXPECTED.values(): assert digest in flags
for token in ('-O3', '-DNDEBUG', '-fPIC', '-std=gnu++17'):
    assert token in flags
assert '-DMR3_RAY_BOX_CORRECTOR_CPU' not in flags
assert 'src/mr3_ray_box_corrector.cpp.o' in link
assert 'src/mr3_ray_box_collision.cpp.o' in link
assert 'libmr3_ray_box_corrector.so' in link and '-lgazebo_ode' in link
capture_row(execution['probe_source_before'])
capture_row(execution['factory_before'])
capture_row(execution['actual_installed_probe_executable'])
commands = {row['label']: row for row in execution['commands']}
assert set(commands) == {'colcon', 'factory', 'ldd', 'compile_actual_probe', 'actual_installed_probe'}
for row in execution['commands']:
    assert row['exit_code'] == 0
    capture_row(row['stdout']); capture_row(row['stderr'])
assert commands['colcon']['argv'][:3] == ['/usr/bin/python3', '/usr/bin/colcon', 'build']
assert commands['colcon']['cwd'] == str(ROS)
assert execution['environment_selected']['PYTHONNOUSERSITE'] == '1'
assert 'conda' not in execution['environment_selected']['PATH']
assert commands['factory']['argv'][1] == execution['installed_new_library']['path']
factory = json.loads(cache[commands['factory']['stdout']['path']])
assert factory == {'system_plugin_factory': True, 'load_called': False, 'init_called': False}
ldd = cache[commands['ldd']['stdout']['path']] + cache[commands['ldd']['stderr']['path']]
assert b'undefined symbol' not in ldd and b'not found' not in ldd
probe = json.loads(cache[commands['actual_installed_probe']['stdout']['path']])
assert probe['passed'] is True
assert probe['named_cases'] == 36 and probe['deterministic_cases'] == 512
assert probe['invalid_primitive_rejections'] == 3
assert not probe['deterministic_failures']
assert all(row['agrees_with_reference_including_depth_normal_ids']
           for row in probe['corrected_results'])
assert probe['broadphase_original']['contacts'] == 1
assert probe['broadphase_corrected']['contacts'] == 0
probe_argv = commands['compile_actual_probe']['argv']
assert '-lmr3_ray_box_corrector' in probe_argv
assert '-L' + str(ROS / 'build/multi_robot') in probe_argv
assert '-Wl,-rpath,' + str(ROS / 'build/multi_robot') in probe_argv
assert [value for value in probe_argv if value.endswith('.cpp')] == [str(AUTHOR / 'probe.cpp')]
assert execution['actual_installed_probe_passed'] is True

# Inspect existing ELF metadata only; do not rerun the probe, factory or ldd.
metadata_commands = []
for label, arguments in (
        ('actual_probe_dynamic', ['-W', '-d']),
        ('actual_probe_symbols', ['-W', '--dyn-syms', '--demangle'])):
    argv = ['/usr/bin/readelf'] + arguments + [execution['actual_installed_probe_executable']['path']]
    start = time.monotonic()
    run = subprocess.run(argv, capture_output=True)
    assert run.returncode == 0
    for suffix, data in (('stdout', run.stdout), ('stderr', run.stderr)):
        path = OUT / (label + '.' + suffix)
        with path.open('xb') as stream: stream.write(data)
        capture(path)
    metadata_commands.append({'argv': argv, 'exit_code': run.returncode,
                              'wall_seconds': time.monotonic() - start})
dynamic = cache[str(OUT / 'actual_probe_dynamic.stdout')].decode()
symbols = cache[str(OUT / 'actual_probe_symbols.stdout')].decode()
assert 'libmr3_ray_box_corrector.so' in dynamic
assert str(ROS / 'build/multi_robot') in dynamic
for symbol in ('multi_robot::ray_box::CorrectRayBox(', 'multi_robot::ray_box::ReadInput('):
    assert any('UND' in row and symbol in row for row in symbols.splitlines())

receipt_path = ASSETS / 'binary/receipt_v1.json'
receipt = json.loads(capture(receipt_path, '84bbd6bd4b5a8802222dfff9ef8f5a741b89a5d670b71170f46e9a8ae67b4ac8'))
assert receipt['passed'] is True
assert receipt['installed_library'] == execution['installed_new_library']
assert receipt['sources'] == execution['sources_after']
assert receipt['old_libraries_before'] == execution['old_libraries_before']
assert receipt['old_libraries_after'] == execution['old_libraries_after']
assert receipt['old_four_libraries_byte_unchanged'] is True
canonical_receipt = capture(receipt['canonical_build_receipt']['resolved'],
    receipt['canonical_build_receipt']['sha256'], receipt['canonical_build_receipt']['bytes'])
assert canonical_receipt == execution_bytes
encoded = capture(receipt['encoded_library']['resolved'],
                  receipt['encoded_library']['sha256'], receipt['encoded_library']['bytes'])
assert gzip.decompress(encoded) == library
assert receipt['encoded_library']['decoded_sha256'] == SO_SHA
capture_row(receipt['actual_ode_library'])
getter_selected = [GETTER / name for name in ("mr3_ray_box_corrector.proposed.cpp", "source_review_v1.json", "handoff_v1.json", "review_only.patch", "created_callback_v1.txt")]
for path in getter_selected: capture(path)
assert (capture(GETTER / 'mr3_ray_box_corrector.proposed.cpp') ==
        cache[execution['sources_before']['src/mr3_ray_box_corrector.cpp']['path']])
for path in (pathlib.Path('/tmp/mr3_p2a0_v24_canonical_build_v1.py'),
             AUTHOR / 'factory.cpp', pathlib.Path(__file__)):
    capture(path)
for path in BUILD.iterdir():
    if path.is_file(): capture(path)
failure_originals = list(OUT.glob('initial_custody_script_syntax_failure_v1.*'))
for path in failure_originals: capture(path)

# All SHA/stat checks are repeated after every source/receipt read, not merely
# inferred from existing producer booleans.
for row in inputs.values():
    path = pathlib.Path(row['path'])
    assert st(path.stat()) == row['stat_after']
    assert st(path.lstat()) == row['lstat_after']
    assert str(path.resolve(strict=True)) == row['resolved_path']
    assert sha(path.read_bytes()) == row['sha256']
review = {
    'schema': 'mr3-v24-canonical-build-independent-readonly-review-v1',
    'passed': True, 'scope': 'Read-only checks of actual final V24 build bytes, flags, commands, recorded factory/math results, ELF dependency metadata, source binding and gzip roundtrip. No compiler, factory, math, simulator, ROS/DDS or native execution repeated.',
    'actual_library_sha256': SO_SHA, 'actual_library_bytes': 398080,
    'source3': EXPECTED, 'old_four_current_before_after_byte_equal': True,
    'build_install_samefile_and_bytes': True, 'source3_macro_and_elf_strings_match': True,
    'canonical_receipt_exact_copy_of_execution': True,
    'actual_probe_linked_target': {
        'recorded_compile_links_only_probe_source_and_actual_so': True,
        'elf_needed_corrector_and_canonical_runpath': True,
        'imported_corrector_functions_undefined_in_probe_elf': True,
        'recorded_passed': True, 'named_both_orders': 36,
        'deterministic_oriented': 512, 'invalid_rejections': 3,
        'live_process_maps_not_available': 'This completed CPU process was not instrumented by this review; actual linking is established by existing compiler argv plus ELF imports/NEEDED/RUNPATH and the captured sanitized environment.'},
    'factory_recorded_system_noLoad_noInit': True,
    'ldd_recorded_no_unresolved': True,
    'native_getter_readback_source_present': ['native_ode_quickstep_iterations', 'physics_max_step_size_sec'],
    'getters_not_executed_by_factory_or_pure_collision_probe': True,
    'custody_helper_initial_parse_failure_preserved': 'The reused V22 custody helper early parse failure remains in its original sealed evidence; this V24 custody invocation does not rewrite or duplicate that old failure.',
    'current_build_cost': {'top_wall_seconds': execution['wall_seconds'],
                     'colcon_wall_seconds': commands['colcon']['wall_seconds'],
                     'kind': 'CPU/SDK only, not native budget'},
    'prior_builds_kept_separate': 'Original V22 b992/f9a and b165/7be79 builds remain historical evidence with separate costs. This review binds only final V24 f826/782d build59.77381576690823 wall seconds.',
    'read_only_metadata_commands': metadata_commands,
    'inputs': list(inputs.values()), 'input_count': len(inputs),
    'all_inputs_final_sha_stat_stable': True,
    'no_native_or_matrix_credit': True,
    'execution': {'argv': sys.argv, 'executable': sys.executable, 'cwd': os.getcwd(),
                  'began_utc': utc, 'wall_seconds': time.monotonic() - began}}
review_path = OUT / 'review_v1.json'
review_data = (json.dumps(review, indent=2) + '\n').encode()
with review_path.open('xb') as stream: stream.write(review_data)

# Closed V24 build custody: raw source/argv/logs/flags/link/getter delta and
# actual-linked probe inputs/results. Actual .so and .so.gz are already held
# authoritatively under A24/binary, so they remain references, not duplicates.
archive_paths = {path for path in BUILD.iterdir() if path.is_file()}
archive_paths.update(pathlib.Path(row['path']) for row in execution['sources_before'].values())
archive_paths.update(pathlib.Path(execution[key]['path']) for key in ('new_target_flags', 'new_target_link'))
archive_paths.update(getter_selected)
archive_paths.update([pathlib.Path('/tmp/mr3_p2a0_v24_canonical_build_v1.py'),
                      AUTHOR / 'probe.cpp', AUTHOR / 'factory.cpp',
                      pathlib.Path(execution['factory_before']['path']),
                      pathlib.Path(__file__), review_path, receipt_path,
                      pathlib.Path(receipt['canonical_build_receipt']['resolved'])])
archive_paths.update(OUT / (label + '.' + suffix) for label in
                     ('actual_probe_dynamic', 'actual_probe_symbols') for suffix in ('stdout', 'stderr'))
archive_paths.update(failure_originals)
selected, excluded = [], []
payload = {}
for path in sorted(archive_paths):
    data = review_data if path == review_path else cache[str(path)]
    if path.is_relative_to('/tmp'):
        member = str(path.relative_to('/tmp'))
    else:
        member = 'repository/' + str(path.relative_to(REPO))
    row = {'path': str(path), 'member': member, 'bytes': len(data), 'sha256': sha(data)}
    if data.startswith(b'\x7fELF'):
        row['reason'] = 'CPU executable intentionally excluded; source, argv, exact SHA and original results remain.'
        excluded.append(row)
    else:
        selected.append(row)
        payload[member] = data
manifest = {'schema': 'mr3-v24-canonical-build02-originals-manifest-v1',
            'files': selected, 'excluded_cpu_executables': excluded,
            'selected_files': len(selected), 'raw_bytes': sum(row['bytes'] for row in selected),
            'binary_already_canonical': {'receipt': str(receipt_path), 'library_sha256': SO_SHA,
                                         'encoded_path': receipt['encoded_library']['resolved'],
                                         'encoded_sha256': receipt['encoded_library']['sha256']},
            'prior_V22_builds_not_duplicated': True,
            'all_referenced_inputs': review['inputs']}
manifest_path = OUT / 'custody_manifest_v1.json'
manifest_data = (json.dumps(manifest, indent=2) + '\n').encode()
with manifest_path.open('xb') as stream: stream.write(manifest_data)
archive = OUT.parent / 'mr3_p2a0_v24_canonical_build_originals_v1.tar.gz'
with archive.open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=6) as encoded_stream:
        with tarfile.open(fileobj=encoded_stream, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for row in selected: add_member(tar, row['member'], payload[row['member']])
            add_member(tar, str(manifest_path.relative_to('/tmp')), manifest_data)
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(selected) + 1
    for row in selected:
        assert sha(tar.extractfile(row['member']).read()) == row['sha256']
    assert tar.extractfile(str(manifest_path.relative_to('/tmp'))).read() == manifest_data
for row in inputs.values():
    path = pathlib.Path(row['path'])
    assert st(path.stat()) == row['stat_after'] and st(path.lstat()) == row['lstat_after']
    assert sha(path.read_bytes()) == row['sha256']
handoff = {'schema': 'mr3-v24-canonical-build02-independent-review-custody-handoff-v1',
           'passed': True, 'review_path': str(review_path), 'review_sha256': sha(review_data),
           'review_input_count': len(inputs), 'manifest_path': str(manifest_path),
           'manifest_sha256': sha(manifest_data), 'archive_path': str(archive),
           'archive_bytes': archive.stat().st_size, 'archive_sha256': sha(archive.read_bytes()),
           'selected_files': len(selected), 'selected_raw_bytes': manifest['raw_bytes'],
           'excluded_cpu_executables': len(excluded), 'members_roundtrip_verified': len(selected) + 1,
           'all_source_input_final_sha_stat_stable': True,
           'actual_library_sha256': SO_SHA, 'scope': review['scope'],
           'wall_seconds': time.monotonic() - began}
handoff_path = OUT / 'handoff_v1.json'
with handoff_path.open('x') as stream:
    json.dump(handoff, stream, indent=2); stream.write('\n')
print(json.dumps(handoff))
