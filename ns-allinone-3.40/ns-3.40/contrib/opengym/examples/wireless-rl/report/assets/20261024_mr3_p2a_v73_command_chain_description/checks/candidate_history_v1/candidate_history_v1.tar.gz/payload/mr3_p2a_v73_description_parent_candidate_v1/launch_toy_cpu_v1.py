"""Exclusive source-snapshotted CPU wrapper for the fixed artificial test entry."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

BASE=Path(__file__).resolve().parent
ROOT=Path('/home/zhuyulab/ns3-workspace')
W=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
OUT=BASE/'cpu_attempt_v1'


def main():
    OUT.mkdir(exist_ok=False)
    files=sorted(BASE.glob('*.py'))+sorted(BASE.glob('*.json'))+[BASE/'README.md']
    files += [W/'report/assets/20261024_mr3_p2a_v72_masked_stimulus_description/run_description_v1.py']
    files += [W/'mr3_learning'/name for name in ('__init__.py','reach_execution.py','preparation.py',
        'native_custody.py','supervisor.py','ipc.py','motion_authority_profile.py')]
    snapshots=OUT/'source_snapshots';snapshots.mkdir()
    rows=[]
    for index,path in enumerate(files):
        raw=path.read_bytes();digest=hashlib.sha256(raw).hexdigest()
        archive=snapshots/(str(index).zfill(3)+'_'+digest+'.rawbytes.gz')
        with archive.open('xb') as stream:
            with gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0) as zipped:zipped.write(raw)
        rows.append(dict(path=str(path),bytes=len(raw),sha256=digest,snapshot=str(archive)))
    argv=['/usr/bin/python3','-B','-m','mr3_learning.reach_execution','--output',str(OUT/'actual_wait'),'--scope','cpu']
    for row in rows:argv += ['--source',row['path']]
    argv += ['--','/usr/bin/python3','-B',str(BASE/'run_toy_cpu_v1.py')]
    with (OUT/'spec_v1.json').open('x') as stream:
        json.dump(dict(schema='mr3-v73-description-parent-artificial-cpu-spec-v1',source_bindings=rows,
            actual_argv=argv,scope='cpu',engineering_seconds='0',artificial_only=True),stream,indent=2);stream.write('\n')
    env=dict(os.environ,PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONPATH',None);env.pop('PYTHONHOME',None)
    os.chdir(W);os.execve(argv[0],argv,env)


if __name__=='__main__':raise SystemExit(main())
