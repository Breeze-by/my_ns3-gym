from pathlib import Path
import gzip
import hashlib
import json
ROOT=Path('/home/zhuyulab/ns3-workspace')
BASE=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v11/independent'
DEST=BASE/'control_consumer_offline'
files=set()
for p in Path('/tmp').glob('mr3_p2a0_v11_control*'):
 files.update([f for f in p.rglob('*')if f.is_file()]if p.is_dir()else[p])
files.update(Path('/tmp')/n for n in ('mr3_independent_control_phase_v2.py','mr3_independent_control_phase_v2_tests.py'))
def sha(data):return hashlib.sha256(data).hexdigest()
entries=[]
for source in sorted(files):
 if source.suffix in ('.pyc','.pyo')or'__pycache__'in source.parts:continue
 raw=source.read_bytes();encoded=gzip.compress(raw,compresslevel=9,mtime=0)
 target=Path(str(DEST/'originals'/source.relative_to('/tmp'))+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 if target.exists():assert target.read_bytes()==encoded,str(target)
 else:target.write_bytes(encoded)
 assert gzip.decompress(target.read_bytes())==raw
 entries.append({'source':str(source),'selected_path':str(target.relative_to(ROOT)),
                 'raw_sha256':sha(raw),'encoded_sha256':sha(encoded),
                 'decoded_sha256':sha(gzip.decompress(encoded)),'raw_bytes':len(raw),
                 'selected_bytes':len(encoded),'decoded_equals_raw':True})
manifest={'schema':'mr3-v11-control-consumer-offline-originals-v1','passed':True,'count':len(entries),'entries':entries,
 'raw_bytes':sum(e['raw_bytes']for e in entries),'selected_bytes':sum(e['selected_bytes']for e in entries),
 'inherited_immutable_sources':{'A10/independent/mr3_independent_control_phase_v1.py':'04cd7d079c16004b20320868943bcdac899da7646304d30cbad0804d1a6ee8d3','A10/independent/mr3_independent_control_phase_v1_tests.py':'9d89029457a7975d22dd78e8963a3b92ce1a16352d9db9355c995740a5e6eed3'},
 'scope':'Offline original58 plus9 extension tests, retained styleFAIL/green, actual-wrapper AST red/green and unchanged synthetic rawinput CLI replay; zero native starts',
 'limits':['Synthetic raw receipts are explicitly synthetic and award no native/physical/task credit.','The expected old-reader PASS demonstrates a retained gap; new-reader FAIL is expected positive regression detection.','No old source or original failure was rewritten; wrapper imports SHA-pinned original mathematics/protocol.','Peer-only keeps original component scope and cannot substitute for the new full-control sticky prefix gate.']}
for item in entries:
 assert sha(Path(item['source']).read_bytes())==item['raw_sha256']
 target=ROOT/item['selected_path'];assert sha(target.read_bytes())==item['encoded_sha256'];assert sha(gzip.decompress(target.read_bytes()))==item['decoded_sha256']
DEST.mkdir(exist_ok=True);output=DEST/'manifest.json';output.write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
print(json.dumps({'manifest':str(output),'sha256':sha(output.read_bytes()),'count':manifest['count'],'raw_bytes':manifest['raw_bytes'],'selected_bytes':manifest['selected_bytes'],'passed':True}))
