"""Verify the exact reviewed V14 preparation before commit; no native work."""
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote

R = Path('/home/zhuyulab/ns3-workspace')
WP = 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
RP = 'ros2_ws/ros2-multi-robot-automap'
W = R / WP
A = W / 'report/assets/20261017_mr3_p2a0_v14'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
plan = json.loads((A / 'predeclared_plan_v14.json').read_text())
assert plan['readiness']['status'] == 'ready' and not plan['readiness']['pending_bindings']
assert not plan['new_source_bindings_pending']
bindings = {b['path']: b['sha256'] for b in plan['independent_source_bindings']}
assert len(bindings) == len(plan['independent_source_bindings']) == 105
for path, digest in bindings.items():
    assert sha((R / path).read_bytes()) == digest, path
spec = importlib.util.spec_from_file_location(
    'static', '/tmp/mr3_p2a0_v13_prefreeze_inventory_verify_v1.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
values = m.static_assignments(W / 'mr3_learning/audit_ppo.py')
pins = {}
for key in ('EVALUATOR_PHASE_PINS', 'PREPARATION_RUNTIME_PINS', 'EXECUTION_CONFIG_PINS'):
    pins.update(values[key])
assert len(pins) == 36
for path, digest in pins.items():
    assert sha((R / path).read_bytes()) == digest, path
assert sha((W / 'MR3_ENV_CONTRACT.md').read_bytes()) == values['ENV_DOCUMENT_SHA256']
old = json.loads(Path('/tmp/mr3_p2a0_v13_source_preflight.json').read_text())
sources = {p: b['sha256'] for p, b in old['source_bindings'].items()}
sources[WP + '/MR3_ENV_CONTRACT.md'] = values['ENV_DOCUMENT_SHA256']
audit_path = WP + '/mr3_learning/audit_ppo.py'
sources[audit_path] = bindings[audit_path]
xml = RP + '/src/multi_robot/config/mr3_fastdds_loopback_udp.xml'
sources[xml] = pins[xml]
assert len(sources) == 101
for path, digest in sources.items():
    assert sha((R / path).read_bytes()) == digest, path
receipt = plan['drive_contract']['binary_build_receipt']
raw = (R / receipt['path']).read_bytes()
assert sha(raw) == receipt['sha256']
build = json.loads(raw)
library = Path(build['library_path']).read_bytes()
assert sha(library) == build['library_sha256']
assert gzip.decompress((R / build['archived_library_gzip']).read_bytes()) == library
for key in ('compiled_source_sha256', 'compiled_header_sha256',
            'compiled_helper_sha256', 'compiled_target_contract_sha256'):
    assert build[key].encode() in library
manifest = json.loads((A / 'independent/offline_originals_v1/manifest.json').read_text())
for row in manifest['entries']:
    encoded = (R / row['selected']).read_bytes()
    assert len(encoded) == row['encoded_bytes'] and sha(encoded) == row['encoded_sha256']
    raw = gzip.decompress(encoded)
    assert len(raw) == row['raw_bytes'] and sha(raw) == row['raw_sha256'] == row['decoded_sha256']
for row in manifest['deduplicated_A13']:
    ref = row['already_A13']
    assert sha(Path(ref['manifest']).read_bytes()) == ref['manifest_sha256']
    assert sha(Path(ref['selected']).read_bytes()) == ref['selected_encoded_sha256']
    assert row['raw_sha256'] == ref['raw_sha256']
allowed = {'AGENTS.md', *[WP + '/' + p for p in (
    'AGENTS.md', 'IMPLEMENTATION_PLAN.md', 'MR3_ENV_CONTRACT.md', 'RESEARCH_PLAN.md',
    'log.md', 'mr3_learning/audit_ppo.py', 'mr3_learning/tests/test_audit_ppo.py',
    'report/ARCHIVE_INDEX.json', 'report/README.md', 'report/20261017_mr3_p2a0_v14.md')],
    *[RP + '/' + p for p in ('AGENTS.md', 'user_guide.md', 'launch_commands.md',
    'src/multi_robot/config/mr3_fastdds_loopback_udp.xml',
    'src/multi_robot_exploration/test/test_fastdds_environment.py')]}
links = []
for path in sorted(allowed):
    if not path.endswith('.md'):
        continue
    for target in re.findall(r'\]\(([^)]+)\)', (R / path).read_text()):
        if target.startswith(('http:', 'https:', '#', 'app:', 'plugin:', 'mailto:')):
            continue
        local = unquote(target.split('#', 1)[0])
        assert ((R / path).parent / local).exists(), (path, target)
        links.append([path, target])
files = []
for path in sorted(A.rglob('*')):
    assert not path.is_symlink(), path
    if not path.is_file() or '__pycache__' in path.parts or path.suffix == '.pyc':
        continue
    raw = path.read_bytes()
    assert not raw.startswith(b'\x7fELF'), path
    row = {'path': str(path.relative_to(A)), 'bytes': len(raw), 'sha256': sha(raw)}
    if raw.startswith(b'\x1f\x8b'):
        decoded = gzip.decompress(raw)
        assert not decoded.startswith(b'\x7fELF'), path
        row.update(decoded_bytes=len(decoded), decoded_sha256=sha(decoded))
    files.append(row)
inventory = A / 'inventory_prefreeze_v1.json'
assert not inventory.exists()
inventory.write_text(json.dumps({'self_excluded': True, 'exclude_python_cache': True,
                                'files': files}, indent=2) + '\n')
raw = subprocess.check_output(['git', 'add', '-n', '.'], cwd=R)
Path('/tmp/mr3_p2a0_v14_git_add_dryrun_prefreeze_v1.log').write_bytes(raw)
paths = [re.fullmatch("add '(.*)'", line).group(1) for line in raw.decode().splitlines()]
asset_paths = {str((A / b['path']).relative_to(R)) for b in files} | {
    str(inventory.relative_to(R))}
assert not set(paths) - (allowed | asset_paths)
check = subprocess.run(['git', 'diff', '--check'], cwd=R, capture_output=True)
assert check.returncode == 0
result = {'passed': True, 'plan_ready': True, 'runtime_source_paths': 101,
          'independent_bindings': 105, 'pins': 36, 'library_sha256': sha(library),
          'four_embedded_source_macros': True, 'offline_selected_checked': len(manifest['entries']),
          'dedup_A13_custody_refs_checked': len(manifest['deduplicated_A13']),
          'prefreeze_assets': len(files), 'inventory_sha256': sha(inventory.read_bytes()),
          'links': len(links), 'dryrun_paths': len(paths), 'unexpected': [],
          'allowed_non_asset_paths': sorted(allowed), 'dryrun_sha256': sha(raw),
          'script_sha256': sha(Path(__file__).read_bytes()),
          'scope': 'Source/CPU/binary/custody/static only; no native experiment'}
Path('/tmp/mr3_p2a0_v14_prefreeze_final_review_v2.json').write_text(
    json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
