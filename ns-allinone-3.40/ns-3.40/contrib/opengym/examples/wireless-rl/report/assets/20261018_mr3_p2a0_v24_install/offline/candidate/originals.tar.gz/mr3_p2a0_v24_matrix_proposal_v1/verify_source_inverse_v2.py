"""Static mechanical coordinator inverse; no entrypoints or production gates run."""
from pathlib import Path
import ast
import hashlib
import json

B = Path(__file__).resolve().parent
W = Path('/home/zhuyulab/ns3-workspace/ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl')
OLD = W / 'report/assets/20261018_mr3_p2a0_v23_entry'
current_name = '20261018_mr3_p2a0_v24_install'
previous_name = '20261018_mr3_p2a0_v23_entry'
rows = []
for path in sorted((B / 'independent').glob('*.py')):
    ast.parse(path.read_bytes())
    if 'custody' in path.name or path.name.startswith('test_'):
        continue
    text = path.read_text()
    back = text
    if 'launch_stage' in path.name:
        back = back.replace('PRIOR_ENGINEERING_WALL_SECONDS', 'PRIOR_ENTRY_WALL_SECONDS')
        back = back.replace('71.97839368507266', '0.24578428314998746')
        back = back.replace('"prior_engineering_cost"', '"prior_entry_cost"')
        back = back.replace('prior_engineering_wall_seconds=', 'prior_entry_wall_seconds=')
    if 'load_checked_corrector' in back:
        back = back.replace('    custody_asset = asset',
            "    legacy = asset.replace('20261018_mr3_p2a0_v24_install', '20261018_mr3_p2a0_v22_ray_box')")
        back = back.replace("relative = custody_asset + 'independent/mr3_v24_corrector_custody_v3.py'",
                            "relative = legacy + 'independent/mr3_v22_corrector_custody_v2.py'")
        back = back.replace("binding = root / (custody_asset + 'independent/mr3_v24_corrector_binding_v1.json')",
                            "binding = root / (legacy + 'independent/mr3_v22_corrector_binding_v1.json')")
    if 'buildproof_preflight' in path.name:
        back = back.replace('report/assets/20261018_mr3_p2a0_v24_install/independent/mr3_v24_corrector_custody_v3.py',
                            'report/assets/20261018_mr3_p2a0_v22_ray_box/independent/mr3_v22_corrector_custody_v2.py')
    if 'cross_stage_mapping' in path.name:
        prefix = "    asset = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/"
        back = back.replace(prefix + current_name + "/independent'",
                            prefix + "20261018_mr3_p2a0_v22_ray_box/independent'")
        back = back.replace("asset/'mr3_v24_corrector_custody_v3.py'", "asset/'mr3_v22_corrector_custody_v2.py'")
        back = back.replace("asset/'mr3_v24_corrector_binding_v1.json'", "asset/'mr3_v22_corrector_binding_v1.json'")
    back = back.replace(current_name, previous_name).replace('v24', 'v23')
    original = OLD / 'independent' / path.name.replace('v24', 'v23')
    assert back.encode() == original.read_bytes(), str(path)
    rows.append({'source': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                 'normative': str(original), 'normative_sha256': hashlib.sha256(original.read_bytes()).hexdigest(),
                 'whole_byte_inverse': True})
assert len(rows) == 6
old = json.loads((OLD / 'predeclared_plan_v23.json').read_bytes())
new = json.loads((B / 'predeclared_plan_v24.json').read_bytes())
for key in ('max_api_records', 'max_submitted_script_decisions', 'max_total_wall_seconds',
            'unchanged_gates', 'physical_response_criteria', 'angular_interface_criteria',
            'angular_reset_criteria', 'external_probe_v6', 'world_solver_candidate',
            'production_environment', 'pilot_budget_unchanged'):
    assert old[key] == new[key], key
assert [len(s['required_audit_receipts']) for s in new['stages']] == [10,7,10,7]
assert new['readiness']['status'] == 'ready' and not new['readiness']['pending_bindings']
assert new['native_admission_granted'] is False

ROOT = Path('/home/zhuyulab/ns3-workspace')
SOURCE = Path('/tmp/mr3_p2a0_v24_source_admission_proposal_v1')
A24 = W / 'report/assets/20261018_mr3_p2a0_v24_install'
assert len(new['independent_source_bindings']) == 210
assert len({row['path'] for row in new['independent_source_bindings']}) == 210
oldpins = {row['path']:row['sha256'] for row in old['independent_source_bindings']}
pins = {row['path']:row['sha256'] for row in new['independent_source_bindings']}
changed = {key for key in oldpins if oldpins[key] != pins[key]}
assert changed == {'ros2_ws/ros2-multi-robot-automap/src/multi_robot/src/mr3_ray_box_corrector.cpp',
                   str((W/'mr3_learning/audit_ppo.py').relative_to(ROOT))}
for relative, digest in pins.items():
    path = ROOT / relative
    if path.parent == A24/'independent':
        path = B/'independent'/path.name
    elif relative == str((W/'mr3_learning/audit_ppo.py').relative_to(ROOT)):
        path = SOURCE/'audit_ppo.proposed_v24_v2.py'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, relative
assert new['prior_engineering_cost']['wall_seconds'] == 71.97839368507266
assert new['max_total_wall_seconds'] - new['prior_engineering_cost']['wall_seconds'] == 17928.021606314927
import importlib.util
wrapper = B/'independent/mr3_v24_multiepoch_closure_binary_review_v1.py'
method = next(n for n in ast.parse(wrapper.read_bytes()).body if isinstance(n,ast.FunctionDef) and n.name=='load_checked_corrector')
namespace = {'Path':Path,'json':json,'hashlib':hashlib,'importlib':importlib}
exec(compile(ast.Module(body=[method],type_ignores=[]),str(wrapper),'exec'),namespace)
def selected_read(path):
    if path == A24/'predeclared_plan_v24.json': return (B/'predeclared_plan_v24.json').read_bytes()
    if path.parent == A24/'independent': return (B/'independent'/path.name).read_bytes()
    return path.read_bytes()
module, selected_binding = namespace['load_checked_corrector'](selected_read)
binding = module.load_binding(selected_binding, selected_read)
assert binding['library']['sha256'] == '782d388fea8df3646524e54f41d71de5f53480b9d04cc0ea1c453c70e2c1f7d8'
assert binding['binary_receipt']['sha256'] == '84bbd6bd4b5a8802222dfff9ef8f5a741b89a5d670b71170f46e9a8ae67b4ac8'
assert hashlib.sha256(selected_read(A24/'independent/mr3_v24_corrector_custody_v3.py')).hexdigest() == 'f65c9c68e6203c499b53d4b75f0ee4e41b256250aae014c783f69cd41af14ab3'

result = {'schema':'mr3-v24-final-mechanical-source-inverse-v2', 'passed':True, 'sources':rows,
          'ready_source_only_actual_native_admission_false':True, 'old34_and_core_gates_preserved':True,'binding_count':210,'old198_unchanged':196,'authorized_old_changed':sorted(changed),'new12_exact':True,'actual_new_selected_loader_binding_PASS':True,'scope_current_bytes':'NewA24independent and currentauditor selected from exactTMP candidates; actualbinary/source/196unchanged files read canonical. No fullpreflight claim.',
          'plan_sha256':hashlib.sha256((B/'predeclared_plan_v24.json').read_bytes()).hexdigest(),
          'scope':'Static bytes/AST/JSON only. ActualSO782d/fixednewloader/ENV prepared; actualcleanpushedpreflight stillrequired. No old tests, entrypoint, ROS/DDS/SDK/native.'}
with (B/'source_inverse_checks_v2.json').open('x') as stream:
    stream.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':True,'sources':len(rows),'plan_sha256':result['plan_sha256']}))
