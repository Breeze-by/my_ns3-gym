"""One explicitly authorized synthetic DDS probe; no Gazebo or real robots."""
import array
import hashlib
import json
import os
from pathlib import Path
import resource
import struct
import subprocess
import sys
import time
import traceback

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
OUTPUT = HERE / 'ros_loopback_probe_v1'
BINARY = HERE / 'build/mr3_startup_sensor_recorder'
PROFILE = ROOT / 'ros2_ws/ros2-multi-robot-automap/src/multi_robot/config/mr3_fastdds_loopback_udp.xml'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def main():
    started = time.monotonic()
    OUTPUT.mkdir(exist_ok=False)
    active = []
    inaccessible = 0
    for proc in Path('/proc').glob('[0-9]*'):
        if int(proc.name) == os.getpid():
            continue
        try:
            if b'ROS_DOMAIN_ID=171' in (proc / 'environ').read_bytes().split(b'\0'):
                active.append({'pid': int(proc.name), 'cmdline': (proc / 'cmdline').read_bytes().decode(
                    errors='replace').replace('\0', ' ')})
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            inaccessible += 1
    write(OUTPUT / 'domain_precheck.json', {'domain': 171, 'same_domain_processes': active,
                                          'unreadable_or_exited_processes': inaccessible})
    assert not active, 'reserved synthetic probe domain171 already has a process'
    for key in ('FASTDDS_DEFAULT_PROFILES_FILE', 'RMW_FASTRTPS_USE_QOS_FROM_XML',
                'RMW_FASTRTPS_PUBLICATION_MODE'):
        os.environ.pop(key, None)
    os.environ.update({'ROS_DOMAIN_ID': '171', 'RMW_IMPLEMENTATION': 'rmw_fastrtps_cpp',
                       'ROS_LOCALHOST_ONLY': '0', 'FASTRTPS_DEFAULT_PROFILES_FILE': str(PROFILE),
                       'SKIP_DEFAULT_XML': '1', 'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1'})
    environment = {key: os.environ.get(key) for key in (
        'ROS_DOMAIN_ID', 'RMW_IMPLEMENTATION', 'ROS_LOCALHOST_ONLY', 'FASTRTPS_DEFAULT_PROFILES_FILE',
        'SKIP_DEFAULT_XML', 'FASTDDS_DEFAULT_PROFILES_FILE', 'RMW_FASTRTPS_USE_QOS_FROM_XML',
        'RMW_FASTRTPS_PUBLICATION_MODE', 'PYTHONNOUSERSITE', 'PYTHONDONTWRITEBYTECODE')}
    run = OUTPUT / 'synthetic_run'
    episode = run / 'worker0/episode001_open_101'
    episode.mkdir(parents=True)
    freeze = 'a' * 40
    write(episode / 'metadata.json', {'schema': 'mr3-p1c-worker-v1', 'scene': 'open', 'seed': 101,
                                    'freeze': freeze, 'epoch': 'synthetic_run_w0_e1_fixture',
                                    'synthetic_metadata_not_native_credit': True})
    capture = OUTPUT / 'capture'
    ready = OUTPUT / 'ready.json'
    stop = OUTPUT / 'stop.json'
    config = {'schema': 'mr3-startup-sensor-capture-config-v1', 'run_directory': str(run),
              'episode_relative_directory': 'worker0/episode001_open_101',
              'output_directory': str(capture), 'ready_path': str(ready), 'stop_marker': str(stop),
              'expected_freeze': freeze, 'expected_domain_id': 171, 'wall_guard_sec': 25,
              'max_cdr_bytes': 1048576, 'max_records': 10000, 'parameter_wall_guard_sec': 5}
    config_path = OUTPUT / 'config.json'
    write(config_path, config)
    source_before = sha((HERE / 'mr3_startup_sensor_recorder.cpp').read_bytes())
    binary_before = sha(BINARY.read_bytes())
    usage_before = resource.getrusage(resource.RUSAGE_CHILDREN)
    child = None
    node = None
    initialized = False
    expected = []
    error = None
    exit_code = None
    child_argv = [str(BINARY), '--config', str(config_path)]
    with (OUTPUT / 'recorder.stdout').open('xb') as out, (OUTPUT / 'recorder.stderr').open('xb') as err:
        try:
            child = subprocess.Popen(child_argv, cwd=ROOT, env=os.environ.copy(), stdout=out, stderr=err)
            write(OUTPUT / 'recorder_process.json', {'pid': child.pid,
                  'stat_raw': Path('/proc', str(child.pid), 'stat').read_text(), 'argv': child_argv})
            deadline = time.monotonic() + 15
            ready_value = None
            while ready_value is None:
                assert child.poll() is None, 'recorder exited before ready'
                assert time.monotonic() < deadline, 'recorder readiness wall guard'
                if ready.exists():
                    raw = ready.read_bytes()
                    if raw.endswith(b'\n'):
                        try:
                            ready_value = json.loads(raw)
                        except json.JSONDecodeError:
                            pass
                if ready_value is not None:
                    break
                time.sleep(.02)
            assert ready_value['ready'] is True
            assert ready_value['compiled_source_sha256'] == source_before
            import rclpy
            from rclpy.node import Node
            from rclpy.qos import QoSProfile, ReliabilityPolicy
            from rclpy.serialization import serialize_message
            from sensor_msgs.msg import LaserScan
            rclpy.init(args=[])
            initialized = True
            node = Node('mr3_sensor_fixture_pub', enable_rosout=False, start_parameter_services=False)
            pub = node.create_publisher(LaserScan, '/tb1/scan',
                                        QoSProfile(depth=10, reliability=ReliabilityPolicy.BEST_EFFORT))
            deadline = time.monotonic() + 5
            while pub.get_subscription_count() < 1:
                assert time.monotonic() < deadline, 'synthetic subscriber discovery wall guard'
                rclpy.spin_once(node, timeout_sec=.05)
            for index in range(3):
                message = LaserScan()
                message.header.frame_id = 'tb1/base_scan'
                message.header.stamp.sec = index + 1
                message.angle_min = -1.0
                message.angle_max = 1.0
                message.angle_increment = .1
                message.range_min = .12
                message.range_max = 10.0
                message.ranges = array.array('f')
                message.ranges.frombytes(struct.pack('<6I', 0x7f800000, 0xff800000,
                                                     0x7fc00001, 0x7fc12345, 0x3df5c28f, 0))
                message.intensities = array.array('f', [1, 2, 3])
                raw = serialize_message(message)
                expected.append({'index': index, 'source_ns': (index + 1) * 1000000000,
                                 'sha256': sha(raw), 'bytes': len(raw)})
                (OUTPUT / ('expected_scan' + str(index) + '.cdr')).write_bytes(raw)
                # Public Humble Publisher.publish(bytes) uses publish_raw;
                # compare the exact sent CDR rather than a second serialization.
                pub.publish(raw)
                rclpy.spin_once(node, timeout_sec=.15)
            deadline = time.monotonic() + 1
            while time.monotonic() < deadline:
                rclpy.spin_once(node, timeout_sec=.05)
        except Exception as caught:
            error = {'type': type(caught).__name__, 'message': str(caught),
                     'traceback': traceback.format_exc()}
        finally:
            if node is not None:
                node.destroy_node()
            if initialized:
                rclpy.shutdown()
            if not stop.exists():
                write(stop, {'schema': 'mr3-startup-sensor-recorder-stop-v1',
                             'run_directory': str(run), 'freeze': freeze,
                             'reason': 'benchmark_closed', 'synthetic_probe_only': True})
            if child is not None:
                # Recorder exits by the normal marker or its own finite wall guard.
                exit_code = child.wait()
    checks = {}
    if error is None:
        try:
            assert exit_code == 0, 'recorder did not exit normally'
            final = json.loads((capture / 'final.json').read_bytes())
            assert final['capture_completed'] is True and final['normal_stop'] is True
            assert final['failed'] is False and final['unbound_epoch_samples'] == 0
            rows = [json.loads(raw) for raw in (capture / 'records.jsonl').read_bytes().splitlines()]
            scans = [row for row in rows if row['kind'] == 'sample'
                     and row['payload']['topic'] == '/tb1/scan']
            assert len(scans) == 3, 'not all three explicitly published synthetic scans captured'
            cdr = (capture / 'messages.cdr').read_bytes()
            for expected_scan, row in zip(expected, scans):
                item = row['payload']
                blob = item['CDR']
                raw = cdr[blob['offset']:blob['offset'] + blob['length']]
                assert sha(raw) == blob['sha256'] == expected_scan['sha256']
                assert len(raw) == expected_scan['bytes']
                assert item['decoded_metadata']['source_ns'] == expected_scan['source_ns']
                assert any(item['message_info']['publisher_gid']), 'all-zero sample writer GID'
                assert row['epoch'] == 'synthetic_run_w0_e1_fixture'
            graph_endpoints = [endpoint for row in rows if row['kind'] == 'publisher_graph'
                               for endpoint in row['payload']['topics']['/tb1/scan']]
            actual_gid = scans[0]['payload']['message_info']['publisher_gid']
            assert any(item['node_name'] == 'mr3_sensor_fixture_pub'
                       and item['endpoint_gid'] == actual_gid for item in graph_endpoints)
            checks = {'actual_serialized_callback_delivery': True, 'exact_CDR_bytes': 3,
                      'actual_writer_GID_matches_same_context_graph': True,
                      'normal_stop_marker_exit': True, 'epoch_binding_matches_fixture': True}
        except Exception as caught:
            error = {'type': type(caught).__name__, 'message': str(caught),
                     'traceback': traceback.format_exc()}
    usage_after = resource.getrusage(resource.RUSAGE_CHILDREN)
    result = {'schema': 'mr3-v20-sensor-synthetic-ROS-loopback-probe-v1',
              'passed_synthetic_SDK_probe': error is None, 'error': error,
              'argv': sys.argv, 'child_argv': child_argv, 'cwd': str(ROOT),
              'environment': environment, 'profile_sha256': sha(PROFILE.read_bytes()),
              'wall_seconds': time.monotonic() - started, 'recorder_exit_code': exit_code,
              'source_before_sha256': source_before,
              'source_after_sha256': sha((HERE / 'mr3_startup_sensor_recorder.cpp').read_bytes()),
              'binary_before_sha256': binary_before, 'binary_after_sha256': sha(BINARY.read_bytes()),
              'child_cpu_user_seconds': usage_after.ru_utime - usage_before.ru_utime,
              'child_cpu_system_seconds': usage_after.ru_stime - usage_before.ru_stime,
              'checks': checks, 'expected_messages': expected,
              'fixture_publish_api': 'public Humble rclpy Publisher.publish(bytes)',
              'scope': 'One isolated domain171 real ROS/RMW synthetic scan delivery. No Gazebo, '
                       'native benchmark, real robot, SLAM service response or research credit.'}
    write(OUTPUT / 'result_v1.json', result)
    print(json.dumps(result), flush=True)
    return 0 if error is None else 1


if __name__ == '__main__':
    raise SystemExit(main())
