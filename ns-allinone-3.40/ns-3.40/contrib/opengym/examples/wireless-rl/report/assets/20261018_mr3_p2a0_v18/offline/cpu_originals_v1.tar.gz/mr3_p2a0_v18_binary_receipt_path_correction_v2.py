"""Correct prospective archive paths only; preserve all original evidence."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import time

DIRECTORY=Path('/tmp/mr3_p2a0_v18_binary_custody_v1')
ORIGINAL=DIRECTORY/'build_receipt_v1.json'
TARGET=DIRECTORY/'build_receipt_v2.json'
BASE='ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/'
OLD=BASE+'20261017_mr3_p2a0_v18/'
NEW=BASE+'20261018_mr3_p2a0_v18/'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    value=path.stat()
    return {key:getattr(value,key) for key in ('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns')}


start=time.monotonic()
before=identity(ORIGINAL)
raw=ORIGINAL.read_bytes()
original_sha=sha(raw)
assert original_sha=='a002fe286cc8d376f0a6332695295e0e4370dfa32425d6d05acebeb8b975fd34'
source=json.loads(raw)
changes=[]


def replace(value,path='$'):
    if isinstance(value,dict):
        return {key:replace(item,path+'.'+key) for key,item in value.items()}
    if isinstance(value,list):
        return [replace(item,path+'['+str(index)+']') for index,item in enumerate(value)]
    if type(value) is str and value.startswith(OLD):
        assert path.endswith('.canonical_path') or path.endswith('.archived_library_gzip'),path
        replacement=NEW+value[len(OLD):]
        changes.append({'json_path':path,'original':value,'corrected':replacement})
        return replacement
    return value


corrected=replace(source)
assert changes


def reverse(value):
    if isinstance(value,dict):
        return {key:reverse(item) for key,item in value.items()}
    if isinstance(value,list):
        return [reverse(item) for item in value]
    if type(value) is str and value.startswith(NEW):
        return OLD+value[len(NEW):]
    return value


assert json.dumps(reverse(corrected),sort_keys=True)==json.dumps(source,sort_keys=True)
archives=[]
for role,item in source['libraries'].items():
    path=Path(item['prepared_archive_path'])
    stat=identity(path)
    encoded=path.read_bytes()
    decoded=gzip.decompress(encoded)
    assert sha(encoded)==item['archived_library_encoded_sha256']
    assert len(encoded)==item['archived_library_encoded_bytes']
    assert sha(decoded)==item['library_sha256']==item['decoded_library_sha256']
    assert len(decoded)==item['library_bytes']
    assert stat==identity(path)
    archives.append({'kind':'library','role':role,'path':str(path),
        'encoded_sha256':sha(encoded),'encoded_bytes':len(encoded),
        'decoded_sha256':sha(decoded),'decoded_bytes':len(decoded),'verified':True})
for item in source['original_build_artifacts']:
    path=Path(item['prepared_path'])
    stat=identity(path)
    encoded=path.read_bytes()
    decoded=gzip.decompress(encoded)
    assert sha(encoded)==item['encoded_sha256']
    assert len(encoded)==item['encoded_bytes']
    assert sha(decoded)==item['raw_sha256']==item['decoded_sha256']
    assert len(decoded)==item['raw_bytes']
    assert stat==identity(path)
    archives.append({'kind':'original_build_artifact','path':str(path),
        'encoded_sha256':sha(encoded),'encoded_bytes':len(encoded),
        'decoded_sha256':sha(decoded),'decoded_bytes':len(decoded),'verified':True})
assert identity(ORIGINAL)==before and ORIGINAL.read_bytes()==raw
corrected['original_v1']={'path':str(ORIGINAL),'sha256':original_sha,'bytes':len(raw)}
corrected['archive_path_correction']={
    'scope':'Only prospective canonical archive paths changed from20261017 to20261018. Actual source/build/install/tmp paths, source macros, SO bytes/hashes, command/environment/exit/wall receipts and original pass/fail are untouched.',
    'old_prefix':OLD,'corrected_prefix':NEW,'changes':changes,
    'reverse_only_corrected_paths_recovers_original_json':True,
    'static_gzip_rechecks':archives,'no_rebuild_ldd_native_or_canonical_write':True,
    'utc':datetime.now(timezone.utc).isoformat(),'wall_sec':time.monotonic()-start,
    'correction_helper_path':str(Path(__file__).resolve()),
    'correction_helper_sha256':sha(Path(__file__).read_bytes())}
with TARGET.open('x') as output:
    json.dump(corrected,output,indent=2)
    output.write('\n')
print(json.dumps({'passed':corrected['passed'],'output':str(TARGET),
                  'sha256':sha(TARGET.read_bytes()),'original_v1_sha256':original_sha,
                  'changed_prospective_paths':len(changes),'gzip_archives_rechecked':len(archives),
                  'wall_sec':corrected['archive_path_correction']['wall_sec']},indent=2))
