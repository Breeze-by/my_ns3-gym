"""Only closed native master costmap forensic geometry; not exact planner-consumption proof."""
from pathlib import Path
import json,gzip,hashlib,collections,math,bisect
E=Path('/home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261017_v12_reset/worker0/episode002_open_101')
BASE=json.loads(Path('/tmp/mr3_p2a0_v12_reset_w0_e2_tb2_stall_diagnostic_v1.json').read_text())
OUT=Path('/tmp/mr3_p2a0_v12_reset_w0_e2_tb2_costmap_diagnostic_v1.json')
inputs={};odom={};decisions=[]
p=E/'motion_safety.jsonl';before=p.stat();h=hashlib.sha256()
with p.open('rb')as stream:
 for line,raw in enumerate(stream,1):
  h.update(raw);r=json.loads(raw);v=r['payload']
  if v.get('robot')!='tb2':continue
  if r['kind']=='own_odom':odom[v['input_sequence']]=v['message']
  elif r['kind']=='decision'and 73<=r['sim_time_sec']<=106.3:
   decisions.append((r['sim_time_sec'],line,v))
assert p.stat().st_mtime_ns==before.st_mtime_ns
inputs[str(p)]={'sha256':h.hexdigest(),'bytes':before.st_size}
times=[d[0]for d in decisions]

def yaw(q):return math.atan2(2*(q['w']*q['z']+q['x']*q['y']),1-2*(q['y']**2+q['z']**2))
def cell(grid,x,y):
 i=grid['info'];o=i['origin']['position'];return (math.floor((x-o['x'])/i['resolution']),math.floor((y-o['y'])/i['resolution']))
def value(grid,c):
 x,y=c;i=grid['info'];return grid['data'][y*i['width']+x]if 0<=x<i['width']and 0<=y<i['height']else None
def point(grid,c):
 i=grid['info'];o=i['origin']['position'];return[o['x']+(c[0]+.5)*i['resolution'],o['y']+(c[1]+.5)*i['resolution']]
def viable(grid,c):
 v=value(grid,c);return v is not None and 0<=v<99
def pathfind(grid,start,end):
 if not viable(grid,start)or not viable(grid,end):return None
 queue=collections.deque([start]);prev={start:None}
 while queue:
  c=queue.popleft()
  if c==end:break
  for dx,dy in((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)):
   n=(c[0]+dx,c[1]+dy)
   if n in prev or not viable(grid,n):continue
   if dx and dy and(not viable(grid,(c[0]+dx,c[1]))or not viable(grid,(c[0],c[1]+dy))):continue
   prev[n]=c;queue.append(n)
 if end not in prev:return None
 path=[];cur=end
 while cur is not None:path.append(cur);cur=prev[cur]
 return path[::-1]
def samples(grid,start,end):
 d=math.hypot(end[0]-start[0],end[1]-start[1]);n=max(1,math.ceil(d/.02))
 return[dict(x=start[0]+(end[0]-start[0])*a/n,y=start[1]+(end[1]-start[1])*a/n,
  value=value(grid,cell(grid,start[0]+(end[0]-start[0])*a/n,start[1]+(end[1]-start[1])*a/n)))for a in range(n+1)]
def summarize(s):
 vals=[r['value']for r in s];return dict(max_value=max(v for v in vals if v is not None),
  unknown_or_outside_count=sum(v is None or v<0 for v in vals),inscribed_or_lethal_count=sum(v is not None and v>=99 for v in vals),
  first_nontraversable=next((r for r in s if r['value']is None or r['value']<0 or r['value']>=99),None))

receipts=[];results=[]
p=E/'costmaps.jsonl';raw=p.read_bytes();inputs[str(p)]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
for line,raw in enumerate(raw.splitlines(),1):
 r=json.loads(raw)
 if r['robot']!='tb2'or not 74e9<=r['received_clock_ns']<=106.3e9:continue
 stamp=r['source_header']['stamp'];clock=stamp['sec']+stamp['nanosec']/1e9
 index=bisect.bisect_right(times,clock)-1
 if index<0:continue
 dt,dline,decision=decisions[index];state=decision['own_state'];m=odom[state['input_sequences']['odom']];pose=m['pose']['pose'];op=pose['position'];oyaw=yaw(pose['orientation'])
 path=E/r['artifact'];encoded=path.read_bytes();raw=gzip.decompress(encoded);grid=json.loads(raw)
 assert hashlib.sha256(raw).hexdigest()==r['payload_sha256']
 inputs[str(path)]={'encoded_sha256':hashlib.sha256(encoded).hexdigest(),'decoded_sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(encoded)}
 goal=BASE['goals'][0 if clock<87.3 else 1]['row']['payload']['pose'];mapgoal=[goal['x'],goal['y']]
 rotation=state['yaw']-oyaw;c=math.cos(rotation);s=math.sin(rotation)
 if r['layer']=='local':
  start=[op['x'],op['y']];dx=mapgoal[0]-state['x'];dy=mapgoal[1]-state['y'];target=[op['x']+c*dx+s*dy,op['y']-s*dx+c*dy];heading=oyaw
 else:start=[state['x'],state['y']];target=mapgoal;heading=state['yaw']
 seed=cell(grid,*start);end=cell(grid,*target);bfs=pathfind(grid,seed,end)
 ring=[]
 for y in range(seed[1]-7,seed[1]+8):
  for x in range(seed[0]-7,seed[0]+8):
   pos=point(grid,(x,y))
   if math.hypot(pos[0]-start[0],pos[1]-start[1])<=.3:ring.append(value(grid,(x,y)))
 ray=samples(grid,start,target);forward=samples(grid,start,[start[0]+.12*math.cos(heading),start[1]+.12*math.sin(heading)])
 results.append(dict(receipt_line=line,receipt=r,costmap_header_clock=clock,decision_clock_used=dt,decision_line_used=dline,
  state=state,raw_odom_input_sequence=state['input_sequences']['odom'],map_to_odom_rotation=rotation,
  start_xy=start,target_xy=target,seed_cell=seed,seed_cost=value(grid,seed),goal_cell=end,goal_cost=value(grid,end),
  radius_30cm_ring=dict(cells=len(ring),max_cost=max(v for v in ring if v is not None),lethal_or_inscribed=sum(v is not None and v>=99 for v in ring)),
  bfs_center_noninscribed_reachable=bfs is not None,
  bfs_length_m=sum(math.dist(point(grid,a),point(grid,b))for a,b in zip(bfs,bfs[1:]))if bfs else None,
  first_bfs_10_points=[point(grid,c)for c in bfs[:10]]if bfs else None,
  direct_line=summarize(ray),first_12cm_forward=summarize(forward)))
result=dict(schema='mr3-v12-closed-tb2-costmap-forensics-v1',freeze=BASE['freeze'],episode=str(E),inputs=inputs,results=results,
 scope='Actual published master costmap SHA verified. Costmap→DWB exact consumption, controller input path/critic scores, per-layer marking origin and controller pre-smoother Twist were not archived. Cell BFS (<99, known only, no diagonal corner cut) and rays are diagnostic; not actual Nav2 planning/trajectory proof. Local goal projection uses map/odom transform encoded by preceding guard own state and its exact selected raw odometry, which may differ from Nav2 internal TF timing.')
with OUT.open('x')as f:f.write(json.dumps(result,indent=2,allow_nan=False)+'\n')
print('clock layer seed goal reachable linebad forwardbad ringbad')
for x in results:print(x['costmap_header_clock'],x['receipt']['layer'],x['seed_cost'],x['goal_cost'],x['bfs_center_noninscribed_reachable'],x['direct_line']['inscribed_or_lethal_count'],x['first_12cm_forward']['inscribed_or_lethal_count'],x['radius_30cm_ring']['lethal_or_inscribed'])
