# MR3-P2A.0 V20_sensor：单次 startup 原始来源采集提案

当前仅 TMP 草案，未晋升、未 ready、未运行。准备基线为已关闭并推送的 `9f7ab6e7fe7e85ff1f6bf3ee6e3fcba7d960549e`；实际执行 freeze 必须来自新准备提交的 clean pushed exact40，不能拿此历史 base 代替。

只声明 exact3、open/seed101、1worker、一次既有普通 benchmark，requested4step、实际最多1reset+4step/5API。原V6 preparation flag强制32step，参数hook依赖该flag，因此本次三个flag都不传。真实调用既有 `probe_action(snapshot,outward_goals=False)`，源码/函数/调用处精确SHA和原文本在 `ordinary_action_selector_binding_v1.json`。没有新增生产特例、手工探索fallback或学得策略信用。

以隔离 profile 复用原150实验接线，生产world/驱动a014/1ms observer及其源码、库、原body/静止门都不改。唯一新一次原生墙时上限900秒，domain170、Gazebo13451须实际无占用；V18+V19已记2489.3860735194758秒，沿原3600上限，本次即便用足仍有约210.6139264805242秒。不得自动重试、改参数、主动信号终止或换seed。900是结果硬上限，父编排仍等有限原benchmark自然关闭，不能通过强杀隐藏超时成本。recorder独立1000秒wallguard仅结束其自身，不控制benchmark。

C++ recorder须先真实ready并确认配置、源码和ownedPID，父进程才启动benchmark。两者使用同一已冻结FastDDS loopback UDP七项配置和domain170，系统ROS子进程清理conda路径。recorder先建22个只读订阅和三机SLAM一次List/Get clients，无控制publisher、无SetParameters。只记录实际回调CDR/receipt/frame/GID、metadata epoch和实际参数可用性；读数超时如实 unavailable，不补配置默认值。worker metadata未完整前可保留epoch-null原样本，不能伪造归属。正常benchmark自然结束后，由唯一父进程独占写stopmarker，recorder刷新原件并正常退出；父进程在benchmark前失败时不得伪造closed marker，recorder靠自身wallguard结束。

普通benchmark真实提前terminated/truncated若已在原RPC及summary中一致记录，保留实际≤4step并原样保留原summaryFalse/CLI1；新capture过程不把它改成任务成功。无终态而少于requested4、worker基础设施错误、写入/identity错误或原严格关闭失败，过程不完整。原2516只运行一次保存4step真实结果，物理False/刺激不足不得改PASS；strict native closure必须通过。

完整e61c CLI因硬32step明确SKIP，不复制/放宽它。仅复用其原 `profile_record` / `validate_profile` 小谓词读取实际首1ms/it1 ledger，核native与cached50→150、setter1以及其余字段不变；保存原字节SHA。这不是1ms全区间、32step、V6、四阶段或物理修复信用。

`capture_process_completed`只指ready→订阅/记录生命周期→正常stop、无写入/identity错误及严格nativeclose。`measurement_availability`与过程结果分开：每robot scan/map/odom/processedpose、TF实际frame/GID、22topic counts、参数状态全按实际保存；namespaced/global TF alias为0不自动判过程失败。缺关键来源只能说明本次仍不能归因，无额外run和补源。

V19 baseline原停车PASS/contrast无刺激physicalFalse及V17停车FAIL均保持；iters150仍未选择为生产配置。本提案不授PPO/GPU/native训练、95%任务、矩阵或150物理修复信用，pilot1870决策/2905.954739546403墙秒不变。
