"""Summarize the failed declared diagnostic attempt without replacing its verdict."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
RUN = ROOT / 'ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261018_v18_baseline'
FREEZE = '85abe3916ab1582b68d7b3c3c0b96ea7fd68f6f1'
bindings = {}


def read(path):
    path = Path(path)
    raw = path.read_bytes()
    proof = {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    bindings[str(path)] = proof
    return json.loads(raw)


def identity(pid):
    try:
        raw = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
        return {'pid': pid, 'start_ticks': int(raw[19]), 'state': raw[0]}
    except (OSError, ValueError, IndexError):
        return None


started = time.monotonic()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == FREEZE
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
execution = read('/tmp/mr3_p2a0_v18_baseline_execution.json')
pair = read('/tmp/mr3_p2a0_v18_pair_execution.json')
summary = read(RUN / 'benchmark_summary.json')
physical = read('/tmp/mr3_p2a0_v18_baseline_physical_review.json')
assert execution['status'] == 'completed' and execution['passed'] is False and execution['returncode'] == 0
assert execution['within_wall_budget'] is True and summary['passed'] is True
assert execution['live_witness']['errors'] == ["ValueError('observer PID is not gzserver')"]
assert execution['live_witness']['proof'] is None and pair['passed'] is False and len(pair['stages']) == 1
assert physical['passed'] is True and len(physical['episodes']) == 1
episode = RUN / 'worker0/episode001_open_101'
shutdown = read(episode / 'supervisor_shutdown.json')
with (episode / 'transitions.jsonl').open() as stream:
    transitions = [json.loads(line) for line in stream]
assert len(transitions) == 33 and transitions[0]['kind'] == 'reset'
assert all(row['kind'] == 'step' for row in transitions[1:])
assert all(row['terminated'] is False for row in transitions)
assert transitions[-1]['truncated'] is True and transitions[-1]['info']['reason'] == 'external_sampler_limit'
identities = {(row['pid'], row['start_ticks']): row for row in shutdown['owned_processes_seen']}
for key in ('parent_identity', 'benchmark_identity'):
    row = execution[key]
    identities[(row['pid'], row['start_ticks'])] = row
live = []
for key in identities:
    current = identity(key[0])
    if current and current['start_ticks'] == key[1]:
        live.append(current)
assert not live
row = physical['episodes'][0]
result = {'schema': 'mr3-closed-diagnostic-attempt-summary-v1', 'freeze': FREEZE,
    'declared_attempt_passed': False, 'failure': 'Root witness compares a versioned actual ELF basename to gzserver. '
        'It rejected /usr/bin/gzserver-11.10.2 although it is the same file as /usr/bin/gzserver.',
    'stage': 'baseline', 'later_iters150': 'SKIPPED; no retry or retroactive proof',
    'saved_reset_records': 1, 'returned_steps': 32, 'saved_api_records': 33,
    'actual_commands': sum(item['kind'] == 'step' and item.get('info', {}).get('command') is not None for item in transitions),
    'task_release_ns': transitions[0]['info']['release_time_ns'],
    'task_seconds': sum(item['info'].get('dt', 0.0) for item in transitions[1:]),
    'native_wall_seconds': execution['native_wall_seconds'],
    'readonly_original_physical_consumer_wall_seconds': execution['diagnostic_consumers'][1]['wall_seconds'],
    'native_benchmark_passed': True, 'original_sampled_physics_passed': True,
    'original_strict_closure': row['closure'], 'fresh_saved_identity_count': len(identities),
    'fresh_live_saved_identities': live,
    'robot_physics': {name: {key: value.get(key) for key in ('physical_evidence_complete', 'errors',
        'maximum_planar_speed_task', 'maximum_angular_norm_task', 'bound_violation_counts',
        'credited_sampled_stop_events', 'credited_cancel_stop_events')} for name, value in row['robots'].items()},
    'inputs': bindings, 'source_tree_still_exact_and_clean_at_summary': True,
    'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'wall_seconds': time.monotonic() - started,
    'limits': 'No predeclared 1ms-admission proof, 1ms formal consumer or contrast run. '
        'Original physical PASS does not reproduce or resolve V17 failure; no matrix/task/PPO credit.'}
result['correction_to_v1'] = 'V1 summary counted absent top-level command instead of actual info.command. Only this descriptive tally is corrected to32; all native/audit originals and FAIL unchanged.'
assert result['actual_commands'] == 32
output = Path('/tmp/mr3_p2a0_v18_closed_summary_v2.json')
with output.open('x') as stream:
    stream.write(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ('declared_attempt_passed', 'saved_api_records', 'actual_commands',
    'task_seconds', 'native_wall_seconds', 'fresh_saved_identity_count', 'fresh_live_saved_identities')}))
