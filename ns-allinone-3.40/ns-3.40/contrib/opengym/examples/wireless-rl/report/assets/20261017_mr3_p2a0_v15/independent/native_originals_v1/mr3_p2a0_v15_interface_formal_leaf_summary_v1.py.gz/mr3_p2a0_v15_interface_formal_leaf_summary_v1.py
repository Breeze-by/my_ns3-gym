"""Summarize already-produced formal receipts; never invoke their consumers."""
from collections import Counter
import hashlib
import json
from pathlib import Path


def main():
    prefix = Path('/tmp/mr3_p2a0_v15_interface')
    receipts, payloads = {}, {}
    for name in ('peer_review_v1', 'control_review_v1', 'fixed_angular_v1',
                 'fixed_physics_v1', 'settled_review_v1'):
        path = Path(str(prefix) + '_' + name + '.json')
        raw = path.read_bytes()
        payload = json.loads(raw)
        receipts[name] = {'path': str(path), 'bytes': len(raw),
                          'sha256': hashlib.sha256(raw).hexdigest(),
                          'passed': payload['passed']}
        payloads[name] = payload
    angular = payloads['fixed_angular_v1']
    physical = payloads['fixed_physics_v1']
    settled = payloads['settled_review_v1']
    robots = {}
    for episode in physical['episodes']:
        for name, robot in episode['robots'].items():
            robots[name] = {key: robot[key] for key in (
                'maximum_planar_speed_task', 'maximum_angular_norm_task',
                'maximum_raw_odom_chord_speed_task', 'bound_violation_counts',
                'eligible_stop_events', 'credited_sampled_stop_events',
                'eligible_cancel_stop_events', 'credited_cancel_stop_events',
                'physical_evidence_complete')}
            robots[name]['eligible_A_statuses'] = dict(Counter(
                item['status'] for item in robot['stop_responses'] if item['eligible']))
            robots[name]['B_statuses'] = dict(Counter(
                item['status'] for item in robot['cancel_stop_responses']))
    intervals = []
    for episode in settled['episodes']:
        for row in episode['qualification_intervals']:
            intervals.append({key: row[key] for key in (
                'robot', 'clock_ns', 'actual_zero_interval_end_ns', 'future_raw_unique_samples',
                'maximum_planar_speed_mps', 'whole_interval_sampled_odom_polyline_m')})
    for receipt in receipts.values():
        assert hashlib.sha256(Path(receipt['path']).read_bytes()).hexdigest() == receipt['sha256']
    result = {'schema': 'mr3-v15-interface-formal-leaf-readonly-summary-v1',
              'scope': 'Existing original formal receipts only; no repeated auditors or native '
                       'experiment. This summary grants no overall acceptance/task/continuous '
                       'dynamics credit; original FAIL remains authoritative.',
              'source_receipts': receipts,
              'angular': {'sampled_bounds_passed': angular['sampled_bounds_passed'],
                          'stimulus_coverage_passed': angular['stimulus_coverage_passed']},
              'physical': {'passed': physical['passed'], 'robots': robots,
                           'interpretation': 'Sampled body/chord bound counters are zero, but '
                           'tb1 has no active prior linear output for either cancellation, '
                           'and tb3 eligible A events resume before proven rest. Meaningful '
                           'stopping evidence is missing for tb1 and tb3; do not replace FAIL '
                           'with the passing body-bound component.'},
              'settled': {'passed': settled['passed'], 'intervals': intervals},
              'stall_diagnostic': {
                  'path': '/tmp/mr3_p2a0_v15_interface_tb1_closed_diagnostic_v1/review.json',
                  'scope': 'Separate one-pass original request/guard/actual-receipt causal '
                           'diagnostic; tb1 all task final linear outputs zero despite many '
                           'nonzero requests. Near tb3 nonclosing criterion rejects translation; '
                           'permitted angular component remains in actual outputs.'}}
    output = Path('/tmp/mr3_p2a0_v15_interface_formal_leaf_summary_v1.json')
    with output.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'output': str(output),
                      'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
                      'original_physical_passed': physical['passed']}))


if __name__ == '__main__':
    main()
