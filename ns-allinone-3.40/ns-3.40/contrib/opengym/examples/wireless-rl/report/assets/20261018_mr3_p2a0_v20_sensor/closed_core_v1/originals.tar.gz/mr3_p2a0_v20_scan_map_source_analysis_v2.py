#!/usr/bin/env python3
"""Offline original CDR only; imports ROS types without initializing ROS/DDS."""
import hashlib
import json
import math
from pathlib import Path
import sys
import time
from collections import Counter, defaultdict
from rclpy.serialization import deserialize_message
from rosidl_runtime_py.utilities import get_message

BASE = Path('/tmp/mr3_p2a0_v20_sensor_capture_v1')
OUT = Path('/tmp/mr3_p2a0_v20_scan_map_source_analysis_v2.json')
FREEZE = 'b33ff70084be6419edc3d0d91a26d6db3936ff45'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def stat(path):
    x = path.stat()
    return [x.st_dev, x.st_ino, x.st_size, x.st_mtime_ns, x.st_ctime_ns]

def ns(stamp):
    return stamp.sec * 1000000000 + stamp.nanosec

def yaw(q):
    return math.atan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z))

def pose(value):
    p, q = value.position, value.orientation
    return {'xyz': [p.x, p.y, p.z], 'quaternion_xyzw': [q.x, q.y, q.z, q.w], 'yaw': yaw(q)}

def clean(value):
    if isinstance(value, float) and not math.isfinite(value):
        return repr(value)
    if isinstance(value, dict):
        return {k: clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(v) for v in value]
    return value

def transform_value(value):
    t, q = value.transform.translation, value.transform.rotation
    return {'parent': value.header.frame_id, 'child': value.child_frame_id,
            'source_ns': ns(value.header.stamp), 'xyz': [t.x, t.y, t.z],
            'quaternion_xyzw': [q.x, q.y, q.z, q.w], 'yaw': yaw(q)}

def reference(row):
    p = row['payload']
    return {'ledger_line': row['_line'], 'record_sequence': row['record_sequence'],
            'wall_monotonic_ns': row['wall_monotonic_ns'],
            'clock_at_receipt_ns': row['clock_at_receipt_ns'], 'topic': p['topic'],
            'CDR': p['CDR'], 'message_info': p['message_info']}

def chain(static, parent, child):
    # First select the actual frame path; unrelated fixed caster/camera rotations are irrelevant.
    queue = [(parent, [])]
    visited = set()
    while queue:
        current, path = queue.pop(0)
        if current == child:
            x = y = z = angle = 0.
            refs = []
            for tf, ref in path:
                q = tf["quaternion_xyzw"]
                assert q[0] == 0 and q[1] == 0, ("non-planar selected static chain", tf)
                a, b, c = tf["xyz"]
                x, y = x + math.cos(angle) * a - math.sin(angle) * b, y + math.sin(angle) * a + math.cos(angle) * b
                z += c
                angle += tf["yaw"]
                refs.append({"transform": tf, "CDR_reference": ref})
            return {"x": x, "y": y, "z": z, "yaw": angle, "transform_refs": refs}
        if current in visited:
            continue
        visited.add(current)
        for tf, ref in static:
            if tf["parent"] == current:
                queue.append((tf["child"], path + [(tf, ref)]))
    raise ValueError(("actual static chain unavailable", parent, child))


def native_index(grid, x, y, mode):
    p, q = grid.info.origin.position, grid.info.origin.orientation
    a = yaw(q)
    xx, yy = x - p.x, y - p.y
    gx = (math.cos(a) * xx + math.sin(a) * yy) / grid.info.resolution
    gy = (-math.sin(a) * xx + math.cos(a) * yy) / grid.info.resolution
    # Karto converter uses round; native published origin is its offset. ROS uses floor.
    column, row = ((math.floor(gx + .5), math.floor(gy + .5)) if mode == 'karto_round'
                   else (math.floor(gx), math.floor(gy)))
    inside = 0 <= column < grid.info.width and 0 <= row < grid.info.height
    return {'row': row, 'column': column, 'inside': inside,
            'value': int(grid.data[row * grid.info.width + column]) if inside else None}

def grid_cells_near(grid, base, radius=.35):
    result = []
    p = grid.info.origin.position
    a = yaw(grid.info.origin.orientation)
    r = grid.info.resolution
    bx, by = base['xyz'][:2]
    for row in range(grid.info.height):
        for col in range(grid.info.width):
            value = int(grid.data[row * grid.info.width + col])
            if value != 100:
                continue
            # Native Karto centre and ROS interpreted centre are both explicit.
            x = p.x + math.cos(a) * col * r - math.sin(a) * row * r
            y = p.y + math.sin(a) * col * r + math.cos(a) * row * r
            distance = math.hypot(x - bx, y - by)
            if distance <= radius:
                result.append({'row': row, 'column': col, 'value': value,
                  'karto_grid_point_xy': [x, y], 'karto_distance_to_base_m': distance,
                  'ROS_cell_center_xy': [x + .5 * r * (math.cos(a) - math.sin(a)),
                                         y + .5 * r * (math.sin(a) + math.cos(a))]})
    return result

def main():
    started = time.monotonic()
    ledger_path, cdr_path = BASE / 'records.jsonl', BASE / 'messages.cdr'
    initial = {str(p): stat(p) for p in (ledger_path, cdr_path)}
    cdr = cdr_path.read_bytes()
    inputs = {str(cdr_path): {'sha256': sha(cdr), 'bytes': len(cdr)}}
    digest = hashlib.sha256()
    selected = defaultdict(list)
    count = Counter()
    types = {}
    parameters = {}
    expected_offset = 0
    epoch = None
    with ledger_path.open('rb') as stream:
        for number, line in enumerate(stream, 1):
            digest.update(line)
            row = json.loads(line)
            assert row['record_sequence'] == number
            row['_line'] = number
            if row['kind'] == 'parameter_values_response':
                parameters[row['payload']['robot']] = {'record_sequence': number, 'row': row}
            if row['kind'] != 'sample':
                continue
            p = row['payload']
            count[p['topic']] += 1
            part = p['CDR']
            assert part['offset'] == expected_offset
            raw = cdr[part['offset']:part['offset'] + part['length']]
            assert len(raw) == part['length'] and sha(raw) == part['sha256']
            expected_offset += part['length']
            assert row['epoch'] is not None
            if epoch is None:
                epoch = row['epoch']
            assert row['epoch'] == epoch
            if p['topic'].endswith(('/scan', '/pose', '/map', '/tf_static')):
                cls = types.setdefault(p['type'], get_message(p['type']))
                message = deserialize_message(raw, cls)
                selected[p['topic']].append((row, message))
    assert expected_offset == len(cdr)
    inputs[str(ledger_path)] = {'sha256': digest.hexdigest(), 'bytes': ledger_path.stat().st_size}
    robots = {}
    for name in ('tb1', 'tb2', 'tb3'):
        scans = selected['/' + name + '/scan']
        poses = selected['/' + name + '/pose']
        maps = selected['/' + name + '/map']
        static = []
        for row, message in selected['/' + name + '/tf_static']:
            static.extend((transform_value(item), reference(row)) for item in message.transforms)
        by_stamp = defaultdict(list)
        for row, message in scans:
            by_stamp[ns(message.header.stamp)].append((row, message))
        pose_results = []
        all_candidates = []
        for row, message in poses:
            matches = by_stamp[ns(message.header.stamp)]
            entry = {'pose_source_ns': ns(message.header.stamp), 'pose_frame': message.header.frame_id,
                     'pose': pose(message.pose.pose), 'pose_CDR_reference': reference(row),
                     'matching_received_raw_scans': len(matches)}
            if len(matches) != 1:
                entry['beam_source_scope'] = 'unknown: unique raw scan unavailable'
                pose_results.append(entry)
                continue
            sr, scan = matches[0]
            offset = chain(static, 'base_footprint', scan.header.frame_id)
            base = entry['pose']
            a = base['yaw']
            sx = base['xyz'][0] + math.cos(a) * offset['x'] - math.sin(a) * offset['y']
            sy = base['xyz'][1] + math.sin(a) * offset['x'] + math.cos(a) * offset['y']
            eligible, rejected = [], Counter()
            for index, value in enumerate(scan.ranges):
                if math.isnan(value):
                    rejected['nan'] += 1
                elif value <= scan.range_min:
                    rejected['at_or_below_min'] += 1
                elif value >= scan.range_max:
                    rejected['at_or_above_max'] += 1
                else:
                    angle = a + offset['yaw'] + scan.angle_min + index * scan.angle_increment
                    x, y = sx + value * math.cos(angle), sy + value * math.sin(angle)
                    beam = {'beam_index': index, 'range': value, 'map_xy': [x, y],
                            'range_min': scan.range_min, 'range_max': scan.range_max,
                            'distance_to_corrected_base_m': math.hypot(x - base['xyz'][0], y - base['xyz'][1])}
                    eligible.append(beam)
            near = [beam for beam in eligible if beam['distance_to_corrected_base_m'] <= .35]
            entry.update({'raw_scan_CDR_reference': reference(sr),
              'raw_scan_source_ns': ns(scan.header.stamp), 'raw_scan_frame': scan.header.frame_id,
              'static_offset_actual': offset, 'sensor_pose_map_xy_yaw': [sx, sy, a + offset['yaw']],
              'eligible_beam_count': len(eligible), 'rejected_beams': dict(rejected),
              'minimum_eligible_range': min((beam['range'] for beam in eligible), default=None),
              'near_body_eligible_endpoints': near})
            all_candidates.extend((entry, beam) for beam in near)
            pose_results.append(entry)
        first_pose = pose_results[0]['pose'] if pose_results else None
        map_results = []
        for row, grid in maps:
            assert len(grid.data) == grid.info.width * grid.info.height
            latest = [entry for entry in pose_results if entry['pose_source_ns'] <= ns(grid.header.stamp)]
            base = latest[-1]['pose'] if latest else first_pose
            near_cells = grid_cells_near(grid, base) if base else []
            mapped = []
            # Compare every received processed candidate before map publication, not map header equality.
            for entry, beam in all_candidates:
                if entry['pose_CDR_reference']['wall_monotonic_ns'] > row['wall_monotonic_ns']:
                    continue
                ki = native_index(grid, *beam['map_xy'], 'karto_round')
                ri = native_index(grid, *beam['map_xy'], 'ros_floor')
                mapped.append({'pose_source_ns': entry['pose_source_ns'], 'beam_index': beam['beam_index'],
                               'range': beam['range'], 'map_xy': beam['map_xy'],
                               'distance_to_base_m': beam['distance_to_corrected_base_m'],
                               'karto_index': ki, 'ROS_index': ri})
            map_results.append({'map_CDR_reference': reference(row), 'header_source_ns': ns(grid.header.stamp),
              'frame': grid.header.frame_id, 'shape': [grid.info.height, grid.info.width],
              'resolution': grid.info.resolution, 'origin': pose(grid.info.origin),
              'data_sha256': sha(grid.data.tobytes()), 'near_body_occupied_cells': near_cells,
              'processed_near_endpoints_before_callback': mapped,
              'map_header_has_matching_public_pose': ns(grid.header.stamp) in {e['pose_source_ns'] for e in pose_results}})
        robots[name] = {'counts': {'scans': len(scans), 'processed_pose': len(poses), 'maps': len(maps)},
          'raw_scans_summary': [{'source_ns': ns(m.header.stamp), 'frame': m.header.frame_id,
            'CDR_reference': reference(r), 'range_min': m.range_min, 'range_max': m.range_max,
            'minimum_finite_range': min((v for v in m.ranges if math.isfinite(v)), default=None),
            'finite_below_point20m_count': sum(math.isfinite(v) and v < .2 for v in m.ranges)} for r, m in scans],
          'actual_parameter_response': parameters[name], 'actual_static_transforms': static,
          'processed_poses': pose_results, 'maps': map_results}
    result = {'schema': 'mr3-v20-offline-scan-map-source-analysis-v1', 'freeze': FREEZE, 'epoch': epoch,
      'analysis_complete': True, 'all_CDR_slices_SHA_and_contiguous_offsets_verified': True,
      'sample_counts': dict(count), 'robots': robots, 'inputs': inputs,
      'scope': 'Offline system ROS deserialization only; no rclpy.init/node/DDS/native/control/truth/production mutation.',
      'limitations': ['Public corrected pose is a processed acceptance proxy, not an internal hit ledger.',
        'Map header can reference rejected scans; map is aggregate of all processed history.',
        'Endpoint projections do not include later private graph corrections to historical poses.',
        'Karto round index and ROS floor index are explicitly different interpretations of published origin; no fake geometric match is assumed.'],
      'execution': {'argv': sys.argv, 'wall_seconds': time.monotonic() - started}, 'writers': 'STOP after seal'}
    for path, before in initial.items():
        assert stat(Path(path)) == before
        assert sha(Path(path).read_bytes()) == inputs[path]['sha256']
    result['whole_files_SHA_stat_before_after_unchanged'] = True
    with OUT.open('x') as stream:
        stream.write(json.dumps(clean(result), indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    summary = {'output': str(OUT), 'sha256': sha(OUT.read_bytes()), 'wall_seconds': result['execution']['wall_seconds'],
      'robots': {name: {'counts': data['counts'],
        'first_scan_min': data['raw_scans_summary'][0]['minimum_finite_range'],
        'first_pose_stamp': data['processed_poses'][0]['pose_source_ns'] if data['processed_poses'] else None,
        'first_pose_near_endpoints': len(data['processed_poses'][0].get('near_body_eligible_endpoints', [])) if data['processed_poses'] else None,
        'first_map_near100': len(data['maps'][0]['near_body_occupied_cells']),
        'first_map_near_endpoint_mapped100': sum(e['karto_index']['value'] == 100 for e in data['maps'][0]['processed_near_endpoints_before_callback'])}
        for name, data in robots.items()}}
    print(json.dumps(summary))

if __name__ == '__main__':
    main()
