"""Finite source/plan wiring read only. No imports of producer or gate modules."""
import hashlib
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A26 = W / 'report/assets/20261018_mr3_p2a0_v26_capture'
A25 = W / 'report/assets/20261018_mr3_p2a0_v25_smoother'
TMP = Path('/tmp/mr3_p2a0_v26_matrix_proposal_v1')
OUT = Path('/tmp/mr3_p2a0_v26_final_plan_wiring_independent_v1')
inputs = {}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def signature(p):
    s = p.stat()
    return [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns]


def read(p):
    before = signature(p)
    raw = p.read_bytes()
    assert signature(p) == before, str(p)
    proof = {'sha256': sha(raw), 'bytes': len(raw), 'stat': before}
    assert str(p) not in inputs or inputs[str(p)] == proof, str(p)
    inputs[str(p)] = proof
    return raw


def obj(p):
    return json.loads(read(p))


def normalize(value):
    if isinstance(value, str):
        return value.replace('v26_', 'v25_')
    if isinstance(value, list):
        return [normalize(v) for v in value]
    if isinstance(value, dict):
        return {k: normalize(v) for k, v in value.items()}
    return value


started = time.monotonic()
plan_path = A26 / 'predeclared_plan_v26.json'
plan = obj(plan_path)
assert inputs[str(plan_path)]['sha256'] == 'fe5a2a7bfb5b6708c396687ece361ba603de76cc35ef443ba4ae50cc739efa0a'
old = obj(A25 / 'predeclared_plan_v25.json')
draft_path = TMP / 'predeclared_plan_v26.draft.json'
draft = obj(draft_path)
root_receipt = obj(A26 / 'root_preparation/final_plan_receipt_v1.json')
changed_top = sorted(k for k in set(plan) | set(draft) if plan.get(k) != draft.get(k))
allowed = sorted(['source_binding', 'readiness', 'new_source_bindings_pending',
                  'authorized_current_binding_refresh_pending',
                  'v25_smoother_clock_revision', 'v26_capture_revision'])
assert changed_top == allowed == sorted(root_receipt['root_changed_top_keys'])
assert root_receipt['draft_sha256'] == inputs[str(draft_path)]['sha256']
assert root_receipt['final_plan_sha256'] == inputs[str(plan_path)]['sha256']
assert plan['native_admission_granted'] is False
pins = {r['path']: r['sha256'] for r in plan['independent_source_bindings']}
old_pins = {r['path']: r['sha256'] for r in old['independent_source_bindings']}
assert len(pins) == len(plan['independent_source_bindings']) == 230
assert len(old_pins) == len(old['independent_source_bindings']) == 222
changed_bindings = sorted(k for k in old_pins if pins.get(k) != old_pins[k])
assert changed_bindings == [str((W / 'mr3_learning/audit_ppo.py').relative_to(ROOT))]
assert pins[changed_bindings[0]] == 'f45c214856d73f57ebc0622c2da20c6c96b663a975f14a2d00215cbe088377c2'
added_bindings = sorted(set(pins) - set(old_pins))
assert len(added_bindings) == 8 and set(old_pins) <= set(pins)
for relative, digest in pins.items():
    assert sha(read(ROOT / relative)) == digest, relative
handoff_path = TMP / 'handoff_final_v1.json'
handoff = obj(handoff_path)
assert inputs[str(handoff_path)]['sha256'] == '2300ec0bba5dd196b71c3c7caeebce908b5e50f0cc77f5881de88bd253ddb705'
for row in handoff['files']:
    if row['path'].endswith('predeclared_plan_v26.json'):
        continue
    assert sha(read(ROOT / row['path'])) == row['sha256']
    assert sha(read(Path(row['source']))) == row['sha256']
static_path = Path(handoff['checks']['path'])
static = obj(static_path)
assert inputs[str(static_path)]['sha256'] == handoff['checks']['sha256']
assert static['passed'] is True
assert handoff['checks']['wall_seconds'] == 1.3881991049274802
assert all(r['whole_byte_and_AST_inverse'] is True for r in static['sources'])
for r in static['sources']:
    assert sha(read(A26 / 'independent' / Path(r['path']).name)) == r['sha256']
same_fields = static['old_mathematics_and_gate_fields_same']
for name in same_fields:
    assert plan[name] == old[name], name
assert [len(s['required_audit_receipts']) for s in plan['stages']] == [10, 7, 10, 7]
assert sum(len(s['required_audit_receipts']) for s in plan['stages']) == 34
assert plan['max_api_records'] == 608 and plan['max_submitted_script_decisions'] == 596
assert plan['max_total_wall_seconds'] == 18000
stage_summaries = []
for s, previous in zip(plan['stages'], old['stages']):
    assert s['stage'] == previous['stage']
    assert s['required_audits'] == previous['required_audits']
    assert s['on_error'] == previous['on_error']
    assert s['wall_ceiling_seconds'] == previous['wall_ceiling_seconds']
    command = normalize(s['command'])
    for flag in ('--base-domain', '--base-port'):
        command[command.index(flag) + 1] = previous['command'][previous['command'].index(flag) + 1]
    assert command == previous['command']
    assert normalize(s['required_audit_receipts']) == previous['required_audit_receipts']
    for key in s:
        if key.endswith('_command_template'):
            assert normalize(s[key]) == previous[key], (s['stage'], key)
    workers = int(s['command'][s['command'].index('--workers') + 1])
    base_domain = int(s['command'][s['command'].index('--base-domain') + 1])
    base_port = int(s['command'][s['command'].index('--base-port') + 1])
    expected_workers = [{'worker_id': i, 'robots': ['tb1', 'tb2', 'tb3'],
                         'domain': base_domain + i, 'port': base_port + i}
                        for i in range(workers)]
    assert s['worker_bindings'] == expected_workers
    stage_summaries.append({'stage': s['stage'], 'command': s['command'],
                            'wall_ceiling_seconds': s['wall_ceiling_seconds'],
                            'required_receipts': len(s['required_audit_receipts']),
                            'actual_command_worker_bindings': expected_workers})
cost = plan['prior_engineering_cost']
assert cost['wall_seconds'] == 1369.6459453934804
assert cost['opening_remaining_wall_seconds'] == 16630.35405460652
assert cost['previous_carried_wall_seconds'] == 572.9355761036277
assert cost['V25_interface_actual_native_wall_seconds'] == 796.7103692898527
assert cost['previous_carried_wall_seconds'] + cost['V25_interface_actual_native_wall_seconds'] == cost['wall_seconds']
assert cost['original_ceiling_wall_seconds'] == 18000
helper = plan['stage_worker_bindings']['helper']
assert helper['sha256'] == '3b685448644d5e1ad50adf3f551107120e13c692865a4e7f6bc0facd2c844e70'
assert helper['path'] == str((A25 / 'independent/mr3_v25_stage_worker_bindings_v1.py').relative_to(ROOT))
entry_sources = {}
for name in ('mr3_p2a0_v26_buildproof_preflight.py', 'mr3_p2a0_v26_launch_stage.py',
             'mr3_p2a0_v26_run_matrix_v1.py'):
    source = read(A26 / 'independent' / name).decode()
    assert helper['path'] in source and helper['sha256'] in source
    assert "exec(compile(worker_raw, str(worker_helper), 'exec'), worker_namespace)" in source
    assert "worker_namespace['validate_worker_bindings']" in source
    assert 'from mr3_v26_stage_worker_bindings' not in source
    entry_sources[name] = {'sha256': sha(source.encode()),
                           'fixed_helper_sha_checked_before_compile': True,
                           'all_stage_validation_called': True}
smoother = plan['smoother_runtime_custody']
assert smoother['module']['sha256'] == 'ac90b7f896592a5a08430ee859ad73332a4e0cd3292e53e20ada310179841c30'
binding = obj(ROOT / smoother['binding']['path'])
assert inputs[str(ROOT / smoother['binding']['path'])]['sha256'] == smoother['binding']['sha256']
assert smoother['binding']['path'] == str((A25 / 'independent/mr3_v25_smoother_binding_v1.json').relative_to(ROOT))
for label in ('source_manifest', 'binary_receipt'):
    declared = binding[label]
    assert sha(read(Path(declared['path']))) == declared['sha256']
elf = {}
for label, declared in binding['installed'].items():
    path = Path(declared['path'])
    assert str(path.resolve(strict=True)) == declared['resolved']
    raw = read(path)
    assert raw[:4] == b'\x7fELF' and len(raw) == declared['bytes']
    assert sha(raw) == declared['sha256']
    elf[label] = declared
for name in ('mr3_p2a0_v26_cross_stage_mapping_monitor_v1.py',
             'mr3_v26_multiepoch_closure_binary_review_v1.py'):
    source = read(A26 / 'independent' / name).decode()
    assert "relative = asset + 'independent/mr3_v26_smoother_custody_v2.py'" in source
    assert '20261018_mr3_p2a0_v25_smoother/' in source
    assert 'mr3_v25_smoother_binding_v1.json' in source
    assert 'declared[\'sha256\'] != binding_sha' in source
    assert ('module.observe(monitor, binding, FREEZE, read)' in source
            or 'smoother_module.review(a.run, prefix, a.freeze, smoother_binding, read)' in source)
report = {
    'schema': 'mr3-v26-final-plan-source-wiring-independent-v1',
    'verdict': 'no_identified_blocker_for_exact_fresh_pushed_preflight',
    'plan_sha256': inputs[str(plan_path)]['sha256'],
    'root_top_level_delta': changed_top,
    'bindings': {'actual_all_match': 230, 'old_unchanged': 221,
                 'only_old_changed': changed_bindings, 'new_paths': added_bindings},
    'reused_proof': {'path': str(static_path), 'sha256': inputs[str(static_path)]['sha256'],
                     'original_wall_seconds': 1.3881991049274802,
                     'original_six_inverse_reexecuted': False,
                     'all_actual_canonical_six_sha_match_proved_sources': True},
    'old_mathematical_and_gate_fields_exact': same_fields,
    'mandatory_receipts': 34, 'maximum_API': 608, 'maximum_decisions': 596,
    'ceiling_seconds': 18000, 'native_admission_granted': False,
    'stages': stage_summaries, 'cost': cost, 'three_entry_wiring': entry_sources,
    'binding': smoother['binding'], 'actual_A25_ELFs': elf,
    'initial_promotion_failure_scope': 'Root reported pre-execution mandatory_receipts KeyError; corrected to real required_audit_receipts and same-SHA resume. This review uses final JSON, retains historical failure, and does not claim a native/test retry.',
    'limits': 'Read-only finite source/JSON/ELF identity checks. No producer/consumer module imports, suites, original math inverse rerun, ROS/DDS/SDK/native, or preflight. Native035 cause remains unknown and original V25 FAIL is retained.',
    'inputs': inputs, 'argv': sys.argv, 'cwd': str(Path.cwd()),
    'environment': {k: os.environ.get(k) for k in ('PYTHONNOUSERSITE',
                    'PYTHONDONTWRITEBYTECODE', 'ROS_DOMAIN_ID', 'RMW_IMPLEMENTATION',
                    'FASTRTPS_DEFAULT_PROFILES_FILE', 'RMW_FASTRTPS_USE_QOS_FROM_XML')},
    'script_sha256': sha(Path(__file__).read_bytes()),
}
for name, proof in inputs.items():
    path = Path(name)
    assert signature(path) == proof['stat'] and sha(path.read_bytes()) == proof['sha256'], name
report['inputs_end_sha_stat_stable'] = True
report['wall_seconds'] = time.monotonic() - started
with (OUT / 'review_v1.json').open('x') as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps({'verdict': report['verdict'], 'actual_bindings': 230,
                  'root_changed_keys': changed_top, 'inputs': len(inputs),
                  'report_sha256': sha((OUT / 'review_v1.json').read_bytes()),
                  'wall_seconds': report['wall_seconds']}))
