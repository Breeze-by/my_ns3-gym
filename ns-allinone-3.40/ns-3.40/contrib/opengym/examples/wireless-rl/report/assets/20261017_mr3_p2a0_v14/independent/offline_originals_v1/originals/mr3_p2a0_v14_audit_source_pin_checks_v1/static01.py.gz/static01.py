"""Exact two-assignment audit source delta; no native or policy execution."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/home/zhuyulab/ns3-workspace')
WIRELESS = 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
ROS = 'ros2_ws/ros2-multi-robot-automap/'
OUT = Path(__file__).parent
RELATIVE = WIRELESS + 'mr3_learning/audit_ppo.py'
XML = ROS + 'src/multi_robot/config/mr3_fastdds_loopback_udp.xml'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def assignments(tree):
    return {node.targets[0].id: node for node in tree.body if isinstance(node, ast.Assign)
            and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)}


def text(node):
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if isinstance(node, ast.Name):
        return {'ROS': ROS, 'WIRELESS': WIRELESS, 'SLAM': ROS + 'src/slam_toolbox/'}[node.id]
    assert isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add)
    return text(node.left) + text(node.right)


def methods(tree):
    return {parent.name + '.' + node.name: ast.dump(node, include_attributes=False)
            for parent in tree.body if isinstance(parent, ast.ClassDef)
            for node in parent.body if isinstance(node, ast.FunctionDef)}


def main():
    before_raw = (OUT / 'before_audit_ppo.py').read_bytes()
    current_raw = (ROOT / RELATIVE).read_bytes()
    before, current = ast.parse(before_raw), ast.parse(current_raw)
    original, changed = assignments(before), assignments(current)
    added = changed['PREPARATION_RUNTIME_PINS'].value
    old = original['PREPARATION_RUNTIME_PINS'].value
    old_pairs = dict(zip((text(key) for key in old.keys), map(text, old.values)))
    new_pairs = dict(zip((text(key) for key in added.keys), map(text, added.values)))
    expected_xml_sha = sha((ROOT / XML).read_bytes())
    assert XML not in old_pairs
    assert new_pairs == {**old_pairs, XML: expected_xml_sha}
    env_digest = sha((ROOT / WIRELESS / 'MR3_ENV_CONTRACT.md').read_bytes())
    assert text(changed['ENV_DOCUMENT_SHA256'].value) == env_digest
    restored = copy.deepcopy(current)
    slots = assignments(restored)
    slots['PREPARATION_RUNTIME_PINS'].value = copy.deepcopy(old)
    slots['ENV_DOCUMENT_SHA256'].value = copy.deepcopy(original['ENV_DOCUMENT_SHA256'].value)
    assert ast.dump(restored, include_attributes=False) == ast.dump(before, include_attributes=False)
    old_tests = ast.parse((OUT / 'before_test_audit_ppo.py').read_bytes())
    tests_path = ROOT / WIRELESS / 'mr3_learning/tests/test_audit_ppo.py'
    new_tests = ast.parse(tests_path.read_bytes())
    old_methods, new_methods = methods(old_tests), methods(new_tests)
    assert all(new_methods[name] == value for name, value in old_methods.items())
    assert set(new_methods) - set(old_methods) == {
        'VersionedNativeGateTests.test_current_transport_profile_has_explicit_current_runtime_proof',
        'VersionedNativeGateTests.test_full_component_loader_rejects_changed_transport_git_or_worktree'}
    selected_groups = ('EVALUATOR_PHASE_PINS', 'PREPARATION_RUNTIME_PINS', 'EXECUTION_CONFIG_PINS')
    pins = {}
    for group in selected_groups:
        value = changed[group].value
        for key, digest in zip(value.keys, value.values):
            relative, expected = text(key), text(digest)
            assert sha((ROOT / relative).read_bytes()) == expected, relative
            assert relative not in pins
            pins[relative] = expected
    phase = ROOT / WIRELESS / 'report/assets/20261015_mr3_p1c/audit_mr3_env_contact_phase_v3.py'
    phase_raw = phase.read_bytes()
    assert sha(phase_raw) == text(changed['PHASE_SHA256'].value)
    phase_pins = assignments(ast.parse(phase_raw))['PINNED_RUNTIME'].value
    assert XML not in {text(key) for key in phase_pins.keys}
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    assert subprocess.check_output(['git', 'show', head + ':' + RELATIVE], cwd=ROOT) == before_raw
    result = dict(
        passed=True, base_commit=head, source_before_sha256=sha(before_raw),
        source_after_sha256=sha(current_raw), tests_sha256=sha(tests_path.read_bytes()),
        only_production_ast_changes=['one explicit PREPARATION_RUNTIME_PINS XML entry',
                                     'ENV_DOCUMENT_SHA256 literal'],
        unchanged_old_test_methods=len(old_methods), new_test_methods=2,
        reviewed_runtime_and_execution_pin_count=len(pins), env_document_sha256=env_digest,
        xml_sha256=expected_xml_sha, pins=pins,
        immutable_phase_sha256=sha(phase_raw), immutable_phase_xml_pin_present=False,
        scope='Current XML is newly explicitly source-bound. Immutable W7 runtime dictionary, '
              'auditor functions/math, collecting policy and pipeline order are unchanged. '
              'CPU uses synthetic claimed commit to exercise current loader; no pushed new '
              'freeze, native or transport-delivery credit.')
    path = OUT / 'static01.json'
    with path.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'pins'}, indent=2))


if __name__ == '__main__':
    main()
