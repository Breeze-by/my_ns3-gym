import pathlib,subprocess,os,time,json,hashlib,datetime
R=pathlib.Path("/home/zhuyulab/ns3-workspace");T=pathlib.Path("/tmp");helper=T/"mr3_p2a0_v16_archive_offline_originals_v1.py";sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=R/"ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v16/predeclared_plan_v16.json"
assert sha(helper)=="b2f1795d4c3d0fa4b574c016ae19a2a03ee5e73689e53e15422a5f3eaa429305"
assert sha(plan)=="5eca58447b8075782bb56ef2506c2bcb8a84e01b5a8233242fe08d963b46bd07"
argv=["/usr/bin/python3",str(helper),"--writers-stopped"];console=T/"mr3_p2a0_v16_offline_publish_v1.log";receipt=T/"mr3_p2a0_v16_offline_publish_receipt_v1.json";assert not console.exists() and not receipt.exists()
env=os.environ.copy();env.pop("PYTHONPATH",None);env.update(PYTHONNOUSERSITE="1",PYTHONDONTWRITEBYTECODE="1");started=datetime.datetime.now(datetime.timezone.utc).isoformat();begin=time.monotonic()
with console.open("xb") as f:r=subprocess.run(argv,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,check=False)
record=dict(argv=argv,cwd=str(R),env={"PYTHONPATH":"unset","PYTHONNOUSERSITE":"1","PYTHONDONTWRITEBYTECODE":"1"},started_utc=started,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),returncode=r.returncode,wall_seconds=time.monotonic()-begin,console=str(console),console_sha256=sha(console),source_sha256=sha(helper),plan_sha256=sha(plan),plan_unchanged=sha(plan)=="5eca58447b8075782bb56ef2506c2bcb8a84e01b5a8233242fe08d963b46bd07")
with receipt.open("x") as f:json.dump(record,f,indent=2);f.write("\n")
print(json.dumps(record,indent=2));print(console.read_text());raise SystemExit(r.returncode)
