# Forward fixture compatibility delta

The original canonical compatibility diagnostic is retained at A65/checks/learner_compat_diagnostic_v1: actual tool 20172 reap 1, 469 tests, 450 pass / 19 fail / zero errors or skips, 146.082204 seconds. Its 320 bound sources and snapshots remained stable and three saved CPU identities were freshly absent. Two known producer/Lifecycle collection blockers were explicitly outside that diagnostic selection.

This candidate changes eight canonical files: seven test/fixture files and one production source-closure line. The seven failing modules are represented; support integration's two failures resolve through its existing shared audit fixture and its own test source is unchanged.

The test updates add the explicit fixed authority profile, complete artificial 12-episode qualification proof shape, actual raw/odometry/calibration/storage/encoder inputs for the public no-owner zero path, and current source dependencies to the real isolated system-Python/Git fixture. Existing qualifier bookkeeping continues to declare its original source/Git/liveness stubs and synthetic child outputs. Those data are not scientific qualification. No production authority helper is substituted as an independent oracle, and no new authority validator is mocked away.

The sole production change adds `motion_authority_profile.py` to `audit_seed_inputs`' existing exact current/Git source-proof list. Merely copying that imported helper into the artificial tree would hide a real dependency omission. The real system fixture now freezes/checks eleven sources and retains the supervisor mismatch negative while adding a helper mismatch negative.

Private targeted tool 63924 truly reaped zero: 87 tests pass / zero fail, errors or skips, 49.555092612 seconds; 222 sources were stable and exactly recoverable, and both saved outer/pytest identities were freshly absent. That run imported canonical production modules and used the candidate test lookup path only. It explicitly deselected the one real isolated system-child case because the one-line production closure change was not installed in the canonical tree. That case must run in the complete forward canonical fresh groups after installation. No partial/private result can replace those groups or provide native, capacity, learning or P2A credit.

All old negative guards remain. The final manifest lists only the eight byte-changing files for installation; the unchanged support-integration source remains a regression input. No canonical source was changed by this candidate preparation.
