import json,os,sys,unittest
from pathlib import Path
ROOT=Path('/home/zhuyulab/ns3-workspace');W=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';B=Path(__file__).parent
os.environ['GIT_DIR']=str(ROOT/'.git');os.environ['PYTHONDONTWRITEBYTECODE']='1'
os.environ['MR3_MASKED_ARTIFICIAL_TRACE_OUTPUT']=str(B/'toy_trace_masked_v1.json')
sys.path.insert(0,str(B/'shadow'/W.relative_to(ROOT)))
import mr3_learning
mr3_learning.__path__.append(str(W/'mr3_learning'))
import mr3_learning.tests
mr3_learning.tests.__path__.append(str(W/'mr3_learning/tests'))
from mr3_learning.preparation import identity
(B/'toy_identity_v1.json').write_text(json.dumps(identity(os.getpid()),indent=2)+'\n')
names=['mr3_learning.tests.test_reach_masked_cancel_producer','mr3_learning.tests.test_reach_outward_cancel_v3_producer','mr3_learning.tests.test_reach_outward_cancel_v2_producer']
r=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n) for n in names))
from mr3_learning.tests.test_reach_masked_cancel_producer import EVENTS
(B/'V3_differential_events_v1.json').write_text(json.dumps(EVENTS,indent=2)+'\n')
v=dict(schema='mr3-masked-cancel-targeted-artificial-cpu-v1',passed=r.wasSuccessful(),tests=r.testsRun,failures=len(r.failures),errors=len(r.errors),skipped=len(r.skipped),differential_event_count=len(EVENTS),actual_main_or_original_inputs_or_World=False,qualification_credit=False)
(B/'toy_result_v1.json').write_text(json.dumps(v,indent=2)+'\n')
raise SystemExit(0 if v['passed'] else 1)
