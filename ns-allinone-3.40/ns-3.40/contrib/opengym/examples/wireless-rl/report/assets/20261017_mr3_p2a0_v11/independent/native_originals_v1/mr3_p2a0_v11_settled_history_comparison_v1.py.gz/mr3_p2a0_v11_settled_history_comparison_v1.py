from pathlib import Path
import collections
import hashlib
import json
import time
BASE=Path('/home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0')
result={'schema':'mr3-v11-v8-actual-settled-history-comparison-v1','wall_monotonic_ns':time.monotonic_ns(),'scope':'Original native records from distinct freezes; descriptive timing/qualification only, not matched ablation or counterfactual native evidence','runs':{}}
for version in ('v8','v11'):
 run=BASE/('mr3_p2a0_20261017_'+version+'_interface');ep=next(run.glob('worker*/episode*'));p=ep/'motion_safety.jsonl';raw=p.read_bytes();release=None;robots={r:{'decisions':0,'nonzero_line':[],'settled_grants':[],'null_cert_count':0,'counts_by_reason':collections.Counter(),'blocked_9s':[]}for r in ('tb1','tb2','tb3')};lastnonzero={r:None for r in robots};zero_since={r:None for r in robots}
 for i,s in enumerate(raw.splitlines(),1):
  try:row=json.loads(s)
  except json.JSONDecodeError:continue
  kind,payload=row['kind'],row['payload']
  if kind=='release':
   release=round(payload['stamp']*1e9)
   for r in robots:zero_since[r]=release
  if kind!='decision'or release is None:continue
  n=payload['robot'];r=robots[n];t=(payload['clock_ns']-release)/1e9
  if t<0 or t>9.02:continue
  d=payload['decision'];request=payload.get('request')or{};own=payload.get('own_state')or{};certificate=own.get('settled_turn');rotation=(d.get('component_filter')or{}).get('rotation_check')or{}
  r['decisions']+=1;r['counts_by_reason'][d['reason']]+=1;r['null_cert_count']+=certificate is None
  if d['reason']=='settled_turn_drift_reserve'or rotation.get('reason')=='settled_turn_drift_reserve':r['settled_grants'].append({'task_sec':t,'original_line':i,'sequence':payload['decision_sequence'],'active_since_ns':certificate.get('active_since_ns')if certificate else None})
  if 8.8<=t<=9.02 and d['reason']=='peer_braking_nonclosing':
   r['blocked_9s'].append({'original_line':i,'task_sec':t,'clock_ns':payload['clock_ns'],'request':{k:request.get(k)for k in ('v','w')},'certificate':certificate,'latest_prior_nonzero':lastnonzero[n],'prior_zero_since_ns':zero_since[n],'continuous_zero_publication_sec':None if zero_since[n]is None else(payload['clock_ns']-zero_since[n])/1e9,'body_margin_m':d.get('body_margin_m'),'component_filter':d.get('component_filter')})
  if d['output'][0]!=0:
   record={'task_sec':t,'clock_ns':payload['clock_ns'],'original_line':i,'sequence':payload['decision_sequence'],'output':d['output']};r['nonzero_line'].append(record);lastnonzero[n]=record;zero_since[n]=None
  elif zero_since[n]is None:zero_since[n]=payload['clock_ns']
 for r in robots.values():r['counts_by_reason']=dict(r['counts_by_reason'])
 result['runs'][version]={'episode':str(ep),'source':{'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)},'task_release_ns':release,'robots':robots}
out=Path('/tmp/mr3_p2a0_v11_interface_settled_history_comparison_v1.json');out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'output':str(out),'runs':{version:{n:{'decisions':r['decisions'],'nonzero_linear_count':len(r['nonzero_line']),'settled_grants':len(r['settled_grants']),'first_blocked_9s':r['blocked_9s'][:1]}for n,r in v['robots'].items()}for version,v in result['runs'].items()}},sort_keys=True))
