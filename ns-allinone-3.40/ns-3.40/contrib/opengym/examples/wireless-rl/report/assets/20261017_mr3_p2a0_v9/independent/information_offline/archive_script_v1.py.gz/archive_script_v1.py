"""Losslessly archive this producer task's CPU-only originals; no native runs."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/home/zhuyulab/ns3-workspace')
OUT = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v9/independent/information_offline'
OUT.mkdir(parents=True, exist_ok=False)


def digest(data):
    return hashlib.sha256(data).hexdigest()


items = []


def archive(original, raw, relative):
    target = OUT / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    encoded = gzip.compress(raw, mtime=0)
    with target.open('xb') as stream:
        stream.write(encoded)
    selected = target.read_bytes()
    decoded = gzip.decompress(selected)
    assert decoded == raw and selected == encoded
    items.append({'source': original, 'selected_path': str(target.relative_to(ROOT)),
                  'raw_sha256': digest(raw), 'selected_encoded_sha256': digest(selected),
                  'selected_decoded_sha256': digest(decoded), 'raw_bytes': len(raw),
                  'selected_bytes': len(selected), 'compression': 'gzip-mtime0',
                  'decoded_equals_raw': True})


files = set()
for pattern in ('mr3_p2a0_v9_information*', 'mr3_information_future_latest*',
                'mr3_information_producer_ledger_fixture*'):
    for path in Path('/tmp').glob(pattern):
        if path.is_file():
            files.add(path)
        elif path.is_dir():
            files.update(item for item in path.rglob('*') if item.is_file())
for path in sorted(files):
    archive(str(path), path.read_bytes(), 'originals/' + str(path.relative_to('/tmp')) + '.gz')
source = 'ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/multi_robot_exploration/mr3_information.py'
old = subprocess.check_output(['git', 'show', 'd41485dfd93797026316806916e127eb5101f3b8:' + source], cwd=ROOT)
archive('git:d41485dfd93797026316806916e127eb5101f3b8:' + source, old,
        'source_snapshots/producer_before_d414.py.gz')
archive(str(ROOT / source), (ROOT / source).read_bytes(),
        'source_snapshots/producer_checked_b983.py.gz')
test = 'ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/test/test_mr3_information.py'
archive(str(ROOT / test), (ROOT / test).read_bytes(),
        'source_snapshots/test_information_checked_ad769.py.gz')
archive(str(Path(__file__)), Path(__file__).read_bytes(), 'archive_script_v1.py.gz')
manifest = {'schema': 'mr3-p2a0-v9-information-offline-originals-v1',
            'passed': all(item['decoded_equals_raw'] for item in items),
            'source_before': 'd41485dfd93797026316806916e127eb5101f3b8',
            'source_after_freeze': 'pending', 'entries': items, 'count': len(items),
            'native_starts': 0, 'scope': 'offline producer checks and original failures; no native/task/learning credit',
            'receipt': 'originals/mr3_p2a0_v9_information_checks_v2.json.gz',
            'notes': ['Original v1/v2 receipts, fixtures, stdout and failed checks retained.',
                      'The counterexample demonstrates an implementation defect; native V8 ingress ordering was not recorded.',
                      'One mistyped setup path failure had no saved stdout file; its description remains in the original checks receipt.',
                      'Gzip is lossless; selected_encoded SHA differs from raw while selected_decoded must equal raw.']}
path = OUT / 'manifest.json'
with path.open('x') as stream:
    stream.write(json.dumps(manifest, indent=2) + '\n')
for item in items:
    selected = (ROOT / item['selected_path']).read_bytes()
    assert digest(selected) == item['selected_encoded_sha256']
    assert digest(gzip.decompress(selected)) == item['raw_sha256'] == item['selected_decoded_sha256']
print(json.dumps({'passed': True, 'manifest': str(path), 'manifest_sha256': digest(path.read_bytes()),
                  'files': len(items), 'raw_bytes': sum(i['raw_bytes'] for i in items),
                  'encoded_bytes': sum(i['selected_bytes'] for i in items)}, indent=2))
