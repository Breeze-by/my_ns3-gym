#!/usr/bin/env python3
"""Posthoc original ray cache/CDR analysis only. Never initializes ROS or recasts a ray."""
import argparse
from collections import Counter, defaultdict
import gzip
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import struct
import time


def sha(raw):return hashlib.sha256(raw).hexdigest()
def require(value,message):
    if not value:raise ValueError(message)
def stable(path):
    value=Path(path).stat()
    return [value.st_dev,value.st_ino,value.st_size,value.st_mtime_ns,value.st_ctime_ns]
def scalar_class(value):
    return ('nan' if math.isnan(value) else ('negative_infinity' if value<0 else 'positive_infinity')
            if math.isinf(value) else 'finite')
def floating(value):
    require(type(value) is dict and set(value)=={'value','fpclass','binary64_hex'},'Floating schema differs')
    raw=bytes.fromhex(value['binary64_hex']);require(len(raw)==8,'binary64 width differs')
    result=struct.unpack('>d',raw)[0]
    require(scalar_class(result)==value['fpclass'],'Floating class differs from exact bits')
    require((value['value']==result and type(value['value']) in (int,float)) if math.isfinite(result)
            else value['value'] is None,'Floating JSON value differs from bits')
    return result


def scan_cdr(raw):
    """CDR1 LaserScan ranges as original32 bits; validates layout, no float roundtrip."""
    require(raw[:2] in (b'\x00\x01',b'\x00\x00'),'unsupported CDR representation')
    endian='<' if raw[:2]==b'\x00\x01' else '>';offset=4
    def aligned(size):
        nonlocal offset
        offset+=(-(offset-4))%size
    def take(fmt):
        nonlocal offset
        size=struct.calcsize(endian+fmt);aligned(4)
        require(offset+size<=len(raw),'truncated CDR primitive')
        value=struct.unpack_from(endian+fmt,raw,offset);offset+=size
        return value[0] if len(value)==1 else value
    sec,nsec=take('iI');length=take('I');require(length>0 and offset+length<=len(raw),'CDR frame string')
    text=raw[offset:offset+length];offset+=length;require(text[-1:]==b'\x00','CDR string terminator')
    frame=text[:-1].decode();metadata=take('7f');count=take('I');begin=offset
    require(count<=1000000 and offset+4*count<=len(raw),'CDR ranges length')
    bits=list(struct.unpack_from(endian+str(count)+'I',raw,offset));offset+=4*count
    intensities=take('I');require(offset+4*intensities==len(raw),'CDR intensities/trailing layout differs')
    return {'source_ns':sec*1000000000+nsec,'frame':frame,'metadata':metadata,'bits':bits,
            'ranges':[struct.unpack('>f',struct.pack('>I',v))[0] for v in bits],
            'ranges_byte_offset':begin,'cdr_endian':endian,'intensities':intensities}


def ray_reference(row,line,raw):
    return {'line':line,'record_sequence':row['record_sequence'],'row_sha256':sha(raw),
            'measurement_time_ns':row.get('measurement_time_ns')}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--capture',type=Path,required=True)
    parser.add_argument('--episode',type=Path,required=True);parser.add_argument('--freeze',required=True)
    parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    started=time.monotonic();require(not args.output.exists(),'exclusive output directory required')
    helper_path=Path(__file__).with_name('v20_geometry_helpers.py')
    source_paths=(Path(__file__),helper_path)
    source_before={str(p):{'stat':stable(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in source_paths}
    # Source imports only; no rclpy.init/node/client/subscriber/control.
    from rclpy.serialization import deserialize_message
    from rosidl_runtime_py.utilities import get_message
    spec=importlib.util.spec_from_file_location('v20_geometry',helper_path);geo=importlib.util.module_from_spec(spec);spec.loader.exec_module(geo)
    metadata_path=args.episode/'metadata.json'
    initial={p:v['stat'] for p,v in source_before.items()}
    inputs={p:{'bytes':v['bytes'],'sha256':v['sha256']} for p,v in source_before.items()}
    def read_file(path):
        initial[str(path)]=stable(path);raw=path.read_bytes();require(stable(path)==initial[str(path)],'input changed during read')
        inputs[str(path)]={'bytes':len(raw),'sha256':sha(raw)};return raw
    metadata=json.loads(read_file(metadata_path));require(metadata['freeze']==args.freeze,'episode freeze differs')
    epoch=metadata['epoch'];cdr_path=args.capture/'messages.cdr';ledger_path=args.capture/'records.jsonl'
    cdr=read_file(cdr_path);initial[str(ledger_path)]=stable(ledger_path);digest=hashlib.sha256();total=0;expected=0
    scans=defaultdict(lambda:defaultdict(list));messages=defaultdict(list);types={};topic_counts=Counter();parameters={}
    with ledger_path.open('rb') as stream:
        for number,line in enumerate(stream,1):
            digest.update(line);total+=len(line);row=json.loads(line);require(row['record_sequence']==number,'recorder sequence differs');row['_line']=number
            if row['kind']=='parameter_values_response':parameters[row['payload']['robot']]=row
            if row['kind']!='sample':continue
            require(row['epoch']==epoch,'recorder sample epoch differs');p=row['payload'];topic=p['topic'];topic_counts[topic]+=1
            part=p['CDR'];require(part['offset']==expected,'CDR offset discontinuity')
            raw=cdr[part['offset']:part['offset']+part['length']];require(len(raw)==part['length'] and sha(raw)==part['sha256'],'CDR slice SHA differs');expected+=len(raw)
            if topic.endswith('/scan'):
                parsed=scan_cdr(raw);cls=types.setdefault(p['type'],get_message(p['type']));message=deserialize_message(raw,cls)
                require(parsed['source_ns']==geo.ns(message.header.stamp) and parsed['frame']==message.header.frame_id
                        and len(parsed['bits'])==len(message.ranges),'manual CDR decoder differs from ROS decoder')
                require(all((math.isnan(a) and math.isnan(b)) or a==b for a,b in zip(parsed['ranges'],message.ranges)),'manual CDR ranges differ')
                scans[topic][parsed['source_ns']].append((row,message,parsed))
            elif topic.endswith(('/pose','/map','/tf_static')):
                cls=types.setdefault(p['type'],get_message(p['type']));messages[topic].append((row,deserialize_message(raw,cls)))
    require(expected==len(cdr),'unreferenced CDR bytes');inputs[str(ledger_path)]={'bytes':total,'sha256':digest.hexdigest()}
    args.output.mkdir(exist_ok=False)
    summary={'schema':'mr3-v21-posthoc-ray-source-analysis-v1','freeze':args.freeze,'epoch':epoch,
             'posthoc_only':True,'predeclared_gate':False,'topic_counts':dict(topic_counts),'robots':{},'parameters':parameters,
             'scope':'Cached original cast data and received CDR/publicposes/maps only. No ray recast or truth for actor. Current geometry getters are non-atomic with cast. Publicpose is acceptance proxy; mapheader is aggregate, not scanID.'}
    beam_path=args.output/'all_beam_comparisons.jsonl.gz'
    with beam_path.open('xb') as encoded,gzip.GzipFile(filename='',mode='wb',fileobj=encoded,mtime=0) as beamout:
        for robot in ('tb1','tb2','tb3'):
            ray_path=args.episode/f'ray_{robot}.jsonl';initial[str(ray_path)]=stable(ray_path);digest=hashlib.sha256();total=0
            rows_by_stamp={};names=Counter();near_names=Counter();scan_summaries=[];errors=[];comparisons=Counter();configuration=None
            processed_stamps={geo.ns(message.header.stamp) for _,message in messages['/'+robot+'/pose']}
            with ray_path.open('rb') as stream:
                for number,line in enumerate(stream,1):
                    digest.update(line);total+=len(line);row=json.loads(line)
                    require(row['record_sequence']==number and row['epoch']==epoch and row['robot']==robot,'ray row identity differs')
                    if row['kind']=='configuration':
                        require(configuration is None and row['plugin_type']=='SensorPlugin','ray configuration differs');configuration=row;continue
                    if row['kind']=='diagnostic_error':errors.append({'reference':ray_reference(row,number,line),'row':row});continue
                    if row['kind']!='scan':continue
                    stamp=row['measurement_time_ns'];require(stamp not in rows_by_stamp,'duplicate cached measurement stamp')
                    require(row['ray_count']==360 and len(row['rays'])==360,'incomplete ray record')
                    require(configuration and row['sensor_parent']==configuration['model_scoped_name']+'::'+configuration['sensor_link']
                            and row['sensor_scoped_name']==configuration['world_name']+'::'+row['sensor_parent']+'::'+configuration['sensor_name'],'actual sensor identity differs')
                    reference=ray_reference(row,number,line);matches=scans['/'+robot+'/scan'][stamp]
                    report={'ray':reference,'raw_cdr_matches':len(matches),'sensor_scoped_name':row['sensor_scoped_name'],
                            'cached_measurement_stable_during_read':row['measurement_time_after_ns']==stamp,
                            'world_clock_before_ns':row['world_clock_before_ns'],'world_clock_after_ns':row['world_clock_after_ns'],
                            'current_valid_hit_names':Counter(),'near_raw_beams':[],'comparisons':Counter()}
                    processed_cache={}
                    for index,ray in enumerate(row['rays']):
                        require(type(ray['index']) is int and ray['index']==index,'ray index differs')
                        length=floating(ray['cached_length']);full=row['full_ray_length']
                        valid=math.isfinite(length) and 0<=length<full and bool(ray['cached_collision_name'])
                        require(valid is ray['collision_name_current_hit_valid'],'cached name validity differs')
                        name=ray['cached_collision_name']
                        if valid:names[name]+=1;report['current_valid_hit_names'][name]+=1
                        if len(matches)!=1:continue
                        sr,scan,parsed=matches[0];require(len(parsed['bits'])==360,'CDR scan count differs')
                        final=floating(ray['final_sensor_range']);rawbits=parsed['bits'][index]
                        try:castbits=struct.unpack('>I',struct.pack('>f',final))[0]
                        except OverflowError:castbits=0xff800000 if final<0 else 0x7f800000
                        rawvalue=parsed['ranges'][index];equal=castbits==rawbits
                        if stamp in processed_stamps:
                            processed_cache[index]={'index':index,'raw_range':rawvalue,
                                'current_hit_name_valid':valid,'cached_collision_name':name if valid else None,
                                'hit_point_from_cached_cast':ray.get('hit_point_from_cached_cast'),
                                'collision_current_geometry':row['hit_collisions'].get(name) if valid else None,
                                'ray_reference':reference}
                        category='bits_equal' if equal else 'same_class_bits_differ' if scalar_class(rawvalue)==scalar_class(final) else 'class_differ'
                        comparisons[category]+=1;report['comparisons'][category]+=1
                        beam={'robot':robot,'source_ns':stamp,'beam_index':index,'ray_record_sequence':number,
                              'cdr_record_sequence':sr['record_sequence'],'CDR_payload_sha256':sr['payload']['CDR']['sha256'],
                              'binary64_hex':ray['final_sensor_range']['binary64_hex'],'narrowed32_hex':f'{castbits:08x}',
                              'raw_cdr32_hex':f'{rawbits:08x}','final_class':scalar_class(final),'raw_class':scalar_class(rawvalue),
                              'comparison':category,'current_hit_name_valid':valid,'cached_collision_name':name if valid else None,
                              'cached_measurement_stable':row['measurement_time_after_ns']==stamp}
                        beamout.write((json.dumps(beam,sort_keys=True,allow_nan=False)+'\n').encode())
                        if math.isfinite(rawvalue) and scan.range_min<rawvalue<min(scan.range_max,.2):
                            if valid:near_names[name]+=1
                            report['near_raw_beams'].append({'index':index,'range':rawvalue,'raw_bits':f'{rawbits:08x}',
                                'current_hit_name_valid':valid,'cached_collision_name':name if valid else None,
                                'hit_point_from_cached_cast':ray.get('hit_point_from_cached_cast'),
                                'collision_current_geometry':row['hit_collisions'].get(name) if valid else None})
                    report['current_valid_hit_names']=dict(report['current_valid_hit_names']);report['comparisons']=dict(report['comparisons'])
                    if len(matches)==1:report['raw_cdr_reference']=geo.reference(matches[0][0])
                    rows_by_stamp[stamp]={'reference':reference,'near':report['near_raw_beams'],'processed_cache':processed_cache};scan_summaries.append(report)
            inputs[str(ray_path)]={'bytes':total,'sha256':digest.hexdigest()}
            static=[]
            for row,message in messages['/'+robot+'/tf_static']:
                static.extend((geo.transform_value(tf),geo.reference(row)) for tf in message.transforms)
            pose_results=[];near_processed=[]
            for pr,message in messages['/'+robot+'/pose']:
                stamp=geo.ns(message.header.stamp);matches=scans['/'+robot+'/scan'][stamp];base=geo.pose(message.pose.pose)
                entry={'source_ns':stamp,'frame':message.header.frame_id,'pose':base,'pose_CDR_reference':geo.reference(pr),
                       'raw_scan_matches':len(matches),'ray_match':{k:v for k,v in rows_by_stamp.get(stamp,{}).items() if k!='processed_cache'},'near_endpoints':[]}
                if len(matches)==1:
                    sr,scan,parsed=matches[0];offset=geo.chain(static,'base_footprint',scan.header.frame_id)
                    angle=base['yaw'];sx=base['xyz'][0]+math.cos(angle)*offset['x']-math.sin(angle)*offset['y'];sy=base['xyz'][1]+math.sin(angle)*offset['x']+math.cos(angle)*offset['y']
                    entry['actual_static_chain']=offset;entry['raw_CDR_reference']=geo.reference(sr)
                    cache=rows_by_stamp.get(stamp,{}).get('processed_cache',{})
                    for index,value in enumerate(parsed['ranges']):
                        if not(scan.range_min<value<scan.range_max):continue
                        a=angle+offset['yaw']+scan.angle_min+index*scan.angle_increment;x=sx+value*math.cos(a);y=sy+value*math.sin(a)
                        distance=math.hypot(x-base['xyz'][0],y-base['xyz'][1])
                        if distance<=.35:
                            beam={'index':index,'range':value,'map_xy':[x,y],'distance_to_corrected_base_m':distance,
                                  'actual_cache_near_raw':cache.get(index)}
                            entry['near_endpoints'].append(beam);near_processed.append((entry,beam))
                pose_results.append(entry)
            map_results=[]
            for mr,grid in messages['/'+robot+'/map']:
                preceding=[p for p in pose_results if p['pose_CDR_reference']['wall_monotonic_ns']<=mr['wall_monotonic_ns']]
                base=preceding[-1]['pose'] if preceding else None;points=[]
                for entry,beam in near_processed:
                    if entry['pose_CDR_reference']['wall_monotonic_ns']>mr['wall_monotonic_ns']:continue
                    points.append({'pose_source_ns':entry['source_ns'],'beam_index':beam['index'],'range':beam['range'],
                                   'map_xy':beam['map_xy'],'cached_source':beam['actual_cache_near_raw'],
                                   'karto_round':geo.native_index(grid,*beam['map_xy'],'karto_round'),
                                   'ROS_floor':geo.native_index(grid,*beam['map_xy'],'ros_floor')})
                map_results.append({'CDR_reference':geo.reference(mr),'header_ns':geo.ns(grid.header.stamp),'frame':grid.header.frame_id,
                                    'data_sha256':sha(grid.data.tobytes()),'shape':[grid.info.height,grid.info.width],
                                    'resolution':grid.info.resolution,'origin':geo.pose(grid.info.origin),
                                    'near_occupied':geo.grid_cells_near(grid,base) if base else None,'processed_endpoints_before_callback':points})
            summary['robots'][robot]={'configuration':configuration,'ray_scans':len(rows_by_stamp),'raw_scans':sum(len(x) for x in scans['/'+robot+'/scan'].values()),
                'raw_duplicate_stamps':[s for s,x in scans['/'+robot+'/scan'].items() if len(x)>1],
                'raw_without_cache_stamps':[s for s in scans['/'+robot+'/scan'] if s not in rows_by_stamp],
                'cache_without_raw_stamps':[s for s in rows_by_stamp if not scans['/'+robot+'/scan'][s]],
                'comparisons':dict(comparisons),'all_current_valid_hit_names':dict(names),'near_raw_current_valid_hit_names':dict(near_names),
                'scan_summaries':scan_summaries,'public_processed_poses':pose_results,'maps':map_results,'diagnostic_errors':errors}
    require(all(stable(Path(p))==v for p,v in initial.items()),'one or more full inputs changed during analysis')
    require(all(sha(Path(p).read_bytes())==v['sha256'] for p,v in source_before.items()),'analysis source changed')
    summary.update(inputs=inputs,input_stat_before=initial,input_stat_after={p:stable(Path(p)) for p in initial},
                   beam_evidence={'path':str(beam_path),'encoded_sha256':sha(beam_path.read_bytes()),'encoded_bytes':beam_path.stat().st_size},
                   analysis_source_sha256=sha(Path(__file__).read_bytes()),geometry_source_sha256=sha(helper_path.read_bytes()),
                   wall_seconds=time.monotonic()-started)
    output=args.output/'summary.json';output.write_text(json.dumps(geo.clean(summary),indent=2,allow_nan=False)+'\n')
    print(json.dumps({'output':str(output),'robots':{r:{k:v[k] for k in ('ray_scans','raw_scans','comparisons','all_current_valid_hit_names','near_raw_current_valid_hit_names')} for r,v in summary['robots'].items()},'wall_seconds':summary['wall_seconds']}))


if __name__=='__main__':main()
