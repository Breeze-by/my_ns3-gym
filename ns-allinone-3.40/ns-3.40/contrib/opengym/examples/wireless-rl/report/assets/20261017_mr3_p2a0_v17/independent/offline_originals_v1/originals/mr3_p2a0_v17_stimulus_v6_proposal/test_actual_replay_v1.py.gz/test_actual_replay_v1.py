"""Isolated pure function replay on completed V15/V16 received inputs; not native credit."""
import ast
import itertools
import json
import math
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
NAMES = ('tb1', 'tb2', 'tb3')
FUNCTIONS = {'_probe_goal_order', 'probe_action', 'probe_action_v3', 'probe_action_v4',
             'probe_action_v5', 'probe_action_v6', '_probe_nonapproaching_goal_action',
             'record_probe_v4_submission'}


def load_pure(path):
    namespace = {'math': math}
    definitions = [node for node in ast.parse(path.read_bytes()).body
                   if isinstance(node, ast.FunctionDef) and node.name in FUNCTIONS]
    exec(compile(ast.Module(body=definitions, type_ignores=[]), str(path), 'exec'), namespace)
    return namespace


OLD = load_pure(HERE / 'old_benchmark.py')
NEW = load_pure(HERE / 'benchmark.py')
fixture = W / 'mr3_learning/tests/test_benchmark_stimulus_v4.py'
fixtures = {'itertools': itertools, 'NAMES': NAMES}
definitions = [node for node in ast.parse(fixture.read_bytes()).body
               if isinstance(node, ast.FunctionDef) and node.name in ('snapshot', 'result')]
exec(compile(ast.Module(body=definitions, type_ignores=[]), str(fixture), 'exec'), fixtures)


def rows(version):
    path = ROOT / ('ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/'
                   'mr3_p2a0_20261017_' + version + '_interface/worker0/episode001_open_101/'
                   'transitions.jsonl')
    return [json.loads(line) for line in path.read_bytes().splitlines()]


class ActualReplayTests(unittest.TestCase):
    def test_v4_v5_whole_actions_and_diagnostics_equal_on_actual_v15_v16(self):
        for selector in ('probe_action_v4', 'probe_action_v5'):
            for version in ('v15', 'v16'):
                old_state, new_state = {}, {}
                original = rows(version)
                matching_original = ((selector == 'probe_action_v4' and version == 'v15')
                                     or (selector == 'probe_action_v5' and version == 'v16'))
                for index, row in enumerate(original[:-1]):
                    snap = row['snapshot']
                    before = json.dumps(snap, sort_keys=True)
                    old = OLD[selector](snap, old_state)
                    new = NEW[selector](snap, new_state)
                    self.assertEqual(old, new)
                    self.assertEqual(old_state, new_state)
                    info = original[index + 1]['info'] if matching_original else fixtures['result'](snap, old)
                    if matching_original:
                        self.assertEqual(old, info['command']['action'])
                    OLD['record_probe_v4_submission'](old_state, info)
                    NEW['record_probe_v4_submission'](new_state, info)
                    self.assertEqual(old_state, new_state)
                    self.assertEqual(json.dumps(snap, sort_keys=True), before)
                print(json.dumps({'selector': selector, 'actual_input_run': version,
                                  'boundaries': 32, 'matching_original_commands': matching_original,
                                  'scope': 'Other selector/run pair uses explicit hypothetical matching typed receipts.'}))

    def test_legacy_functions_and_default_v5_ast_remain_unchanged(self):
        old = ast.parse((HERE / 'old_benchmark.py').read_bytes())
        new = ast.parse((HERE / 'benchmark.py').read_bytes())
        for name in ('_probe_goal_order', 'probe_action', 'probe_action_v3',
                     'probe_action_v5', 'record_probe_v4_submission',
                     '_probe_nonapproaching_goal_action'):
            first = next(node for node in old.body if isinstance(node, ast.FunctionDef) and node.name == name)
            second = next(node for node in new.body if isinstance(node, ast.FunctionDef) and node.name == name)
            self.assertEqual(ast.dump(first), ast.dump(second))

    def test_actual_v16_prefix_first_changed_action_is_late22_legal_single_goal(self):
        diagnostics = {}
        divergence = None
        original = rows('v16')
        for index, row in enumerate(original[:-1]):
            snap = row['snapshot']
            if snap['task_elapsed_sec'] > 22.:
                break
            before = json.dumps(snap, sort_keys=True)
            chosen = NEW['probe_action_v6'](snap, diagnostics)
            actual = original[index + 1]['info']
            if chosen != actual['command']['action']:
                divergence = snap['task_elapsed_sec']
                self.assertEqual(divergence, 22.)
                self.assertIn(chosen, (99, 499))
                self.assertTrue(snap['joint_action_mask'][chosen])
                self.assertTrue(NEW['_probe_nonapproaching_goal_action'](snap, chosen))
                self.assertEqual(json.dumps(snap, sort_keys=True), before)
                print(json.dumps({'first_counterfactual_divergence_elapsed': divergence,
                                  'V6_action': chosen, 'original_V5_action': actual['command']['action'],
                                  'scope': 'Input opportunity on real received snapshot only; no actual new GOAL/execution.'}))
                break
            NEW['record_probe_v4_submission'](diagnostics, actual)
        self.assertEqual(divergence, 22.)

    def test_integer_boundary_corrects_only_new_late_predicate(self):
        first = load_pure(HERE / 'initial_float_boundary_benchmark.py')
        elapsed = 46.12 - 20.12

        def choose(module):
            state = {}
            initial = fixtures['snapshot'](10., active=False)
            action = module['probe_action_v6'](initial, state)
            module['record_probe_v4_submission'](state, fixtures['result'](initial, action))
            return module['probe_action_v6'](fixtures['snapshot'](elapsed, active=False), state)
        old, new = choose(first), choose(NEW)
        self.assertTrue(any(value < 8 for value in (old // 100, old // 10 % 10, old % 10)))
        self.assertEqual(new, 888)
        print(json.dumps({'actual_elapsed26_binary64': elapsed,
                          'initial_float_predicate_action': old, 'integer_late_predicate_action': new,
                          'scope': 'Pure boundary counterexample; initial prototype retained, not native.'}))


if __name__ == '__main__':
    unittest.main(verbosity=2)
