import hashlib,json,os,subprocess,time
from pathlib import Path
R=Path('/home/zhuyulab/ns3-workspace')
A=R/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v16'
O=Path('/tmp/mr3_p2a0_v16_final_coord_checks_v1');O.mkdir()
plan=json.loads((A/'predeclared_plan_v16.json').read_text())
paths=[R/b['path'] for b in plan['independent_source_bindings']]+[A/'predeclared_plan_v16.json']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={str(p):sha(p) for p in paths}
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1');env.pop('PYTHONPATH',None)
rows=[]
for label,file in [('launcher14','mr3_p2a0_v16_plan_launcher_tests_v1.py'),('scheduler9','mr3_p2a0_v16_audit_stage_tests_v1.py')]:
 argv=['/usr/bin/python3',str(A/'independent'/file)]
 log=O/(label+'.log');start=time.monotonic()
 with log.open('x') as f:p=subprocess.run(argv,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
 rows.append(dict(label=label,argv=argv,cwd=str(R),returncode=p.returncode,wall_seconds=time.monotonic()-start,stdout=str(log),stdout_sha256=sha(log)))
after={str(p):sha(p) for p in paths}
result=dict(passed=all(x['returncode']==0 for x in rows) and before==after,commands=rows,source_before=before,source_after=after,sources_stable=before==after,env={k:env.get(k) for k in ['PYTHONPATH','PYTHONNOUSERSITE','PYTHONDONTWRITEBYTECODE']},scope='Final canonical23 stdlib fake CLI checks; no native/formal run')
(O/'checks_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['passed','commands','sources_stable']}))
raise SystemExit(0 if result['passed'] else 1)
