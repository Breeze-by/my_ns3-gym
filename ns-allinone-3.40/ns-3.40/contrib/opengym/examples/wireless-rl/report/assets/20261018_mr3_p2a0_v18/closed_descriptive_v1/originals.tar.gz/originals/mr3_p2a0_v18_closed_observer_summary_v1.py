"""Summarize already reduced small JSON only. Never reread the large raw files."""
import hashlib
import json
from pathlib import Path

SOURCE = Path("/tmp/mr3_p2a0_v18_closed_observer_diagnostic_v1/diagnostic.json")
EXPECTED = "a6b112450b6fb806c74bf0dfc54f3a9d5fa76fdf56d0f2bb121cdee14c2d085a"
raw = SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == EXPECTED
data = json.loads(raw)
physical_path = Path("/tmp/mr3_p2a0_v18_baseline_physical_review.json")
physical_raw = physical_path.read_bytes()
physical = json.loads(physical_raw)
summary = {"schema": "mr3-v18-closed-observer-descriptive-summary-v1",
    "observation_only": True, "v18_overall_result_unchanged": "FAIL",
    "missing_required_live_admission_not_repaired": True,
    "capture_errors": data["capture_validation_errors"],
    "actual_interval": data["actual_interval"],
    "original2516": {"path": str(physical_path), "sha256": hashlib.sha256(physical_raw).hexdigest(),
        "script_sha256": physical["script_sha256"], "passed_as_originally_recorded": physical["passed"],
        "closure_passed_as_originally_recorded": physical["episodes"][0]["closure"]["passed"]},
    "robots": [], "source": {"path": str(SOURCE), "sha256": EXPECTED},
    "raw_input_bindings": data["inputs"],
    "interpretation": [
        "All3 task captures contain32001 same-clock PRE/POST pairs and32000 integration intervals, with no typed/finite/sequence/iteration/coverage error.",
        "All task ownodom messages match exact same-T PRE pose and original float-yaw cosf/sinf projected XY plus WZ, not POST. This establishes sampled interface consistency only.",
        "Origin/CoG lever-arm identities are algebraically coherent; fixed-link velocity differences are small in this run. These identities do not prove a continuous physical model.",
        "Post-velocity integrated Z disagrees substantially with public CoG-pose changes while XY discrepancy is millimetric. This is retained as a getter/pose consistency limitation, not assigned to solver, contact or a specific physical cause.",
        "Motor target0 does not imply feedback wheel speed0. Above-.01 counts include initial braking and cannot be relabeled as late-stop failure.",
        "Complete zero-reference windows are summarized; the reducer did not separately isolate start+.78s tail maxima. No late-tail1ms guarantee is invented from a whole-window peak.",
        "Original2516 stopping and closure are PASS in this single baseline run; V17's nonrest failure is not reproduced by that original gate here. This dataset does not establish V17's cause or prove it repaired.",
        "Retained contact/wrench data availability does not identify causal force attribution. RMS/constraint residual are unavailable typed pointer return values, not0.",
        "V18 remains FAIL due the required admission-witness failure. This descriptive postmortem is not a new formal or matrix PASS."
    ]}
rows = []
for robot in data["robots"]:
    residual = robot["extra_residuals"]
    point = robot["point_velocity_residual"]
    complete_zero = [window for window in robot["zero_motor_windows"]["longest_ten"]
                     if window["intervals"] >= 780]
    original = physical["episodes"][0]["robots"][robot["robot"]]
    entry = {"robot": robot["robot"], "records": robot["record_count"],
        "task_pairs": robot["task_pairs_including_start_anchor"],
        "integration_intervals": robot["task_integration_intervals"],
        "odom_pre_join": robot["own_odom_same_T_pre_join"],
        "odom_pre_position_residual": residual["own_odom.position_minus_same_T_pre_model"],
        "odom_pre_projected_xy_wz_residual": residual["own_odom.xy_wz_minus_same_T_pre_float_yaw_projection"],
        "origin_cog_residual": point,
        "post_fixed_link_residual": residual["post.fixed_base_origin_velocity_minus_canonical_rigid_prediction"],
        "post_model_minus_canonical_origin": residual["post.model_velocity_minus_canonical_origin"],
        "post_model_minus_canonical_cog": residual["post.model_velocity_minus_canonical_cog"],
        "post_cog_pose_speed_minus_velocity": {
            key: residual[key] for key in (
                "canonical_cog.pre_post_pose_speed_minus_post_velocity",
                "base_cog.pre_post_pose_speed_minus_post_velocity")},
        "post_cog_integral_residual_xyz": {
            key: robot["post_velocity_pose_integral_residual_xyz"][key]
            for key in ("canonical_cog", "base_cog")},
        "zero_motor_counts": robot["wheel_zero_diagnostics"],
        "complete_zero_windows_at_least_point78_sec": complete_zero,
        "all_at_least_point78_windows_included": len(complete_zero)
            == robot["zero_motor_windows"]["at_least_point78_sec"],
        "contacts": robot["contacts"],
        "world_solver_availability": robot["world_solver_diagnostic_availability"],
        "original2516_credited_A": original["credited_sampled_stop_events"],
        "original2516_credited_B": original["credited_cancel_stop_events"],
        "original2516_bound_violation_counts": original["bound_violation_counts"],
        "selected_original_raw_rows": robot["selected_original_raw_rows"]}
    summary["robots"].append(entry)
    zero = robot["wheel_zero_diagnostics"]
    rows.append("| " + robot["robot"] + " | " + str(entry["task_pairs"]) + " | "
        + str(entry["odom_pre_join"]["joined_rows"]) + " | "
        + str(zero["motor_both_exact_zero_task_samples"]) + " | "
        + str(zero["motor_both_zero_body_planar_above_original_rest_threshold_samples"]) + " | "
        + str(entry["original2516_credited_A"]) + "/" + str(entry["original2516_credited_B"]) + " |")
target = Path("/tmp/mr3_p2a0_v18_closed_observer_summary_v1.json")
target.write_text(json.dumps(summary, indent=2, sort_keys=True, allow_nan=False) + "\n")
report = """V18 已关闭记录的描述性复核；原整体 FAIL 保持。

没有所需 live admission proof，本分析不补发 PASS。只对三份已关闭 1 ms 文件各做一次完整顺序读取，源时段为29.72–61.72 s。三台均完整覆盖32001对 PRE/POST，32000个积分区间，无缺帧、重复、阶段/迭代或有限数值错误。

| 机器人 | 成对边界 | 同T PRE里程计 | 双motor零样本 | 其中planar>.01 | 原2516 A/B信用 |
| --- | ---: | ---: | ---: | ---: | ---: |
""" + "\n".join(rows) + """

零目标不等于轮速零；上述>.01计数含初始刹车，不能当作晚停违规。所有完整长零目标窗口及积分统计保存在JSON。没有单独统计+.78 s尾段的1 ms极值，不能从整段最大值反推其时间归属。

原点—CoG杠杆关系最大残差约8.33e-17 m/s；固定link逐轴残差最大约9.45e-5 m/s。全部942/942/941条原始里程计的同T PRE位置、按原float yaw/cosf/sinf投影XY和WZ逐值一致。它们支持本次接口/代数一致性，不是连续动力学定理。

本次公共getter的post速度积分与CoG姿态变化在XY上为毫米级残差；Z累计残差约2.69–2.89 m/32 s。该不一致保留为getter/位姿限制，当前证据不足以将其归因于solver或接触，也不能据此更改旧门。

每机64002个任务内阶段样本均保留自身与静态地面接触证据；wrench点计数分别158356/159047/156927。世界num_contacts可读，RMS和constraint_residual为不支持的指针返回，全程不可用，不能解释为0。接触可用性不能证明具体致因。

原2516与strictclose在本次baseline为PASS，因此原门没有复现V17的nonrest失败。这不解释V17根因，也不证明它已修好。原V18 witness错误、observer正式SKIP和iters150 SKIP均未改变。

精确原始SHA、执行命令/环境/壁钟及逐字选行在同名JSON、execution回执与封存manifest中。选行中的zero-motor峰值是相应PRE/POST对的指标；默认保存POST原行，并通过before_record_sequence绑定同对PRE，不声称峰值一定来自POST。
"""
Path("/tmp/mr3_p2a0_v18_closed_observer_summary_v1.md").write_text(report)
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == EXPECTED
print(json.dumps({"summary": str(target), "sha256": hashlib.sha256(target.read_bytes()).hexdigest()}))
