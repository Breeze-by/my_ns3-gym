#!/usr/bin/env python3
"""Seal offline candidate evidence; this script does not publish into Git."""
import gzip
import hashlib
import json
from pathlib import Path

P = Path(__file__).resolve().parent
D = Path('/tmp/mr3_p2a0_v18_physics_design_v2')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(name, value):
    with (P / name).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def main():
    proposed = {name: {'path': str(P / 'proposed' / name),
                      'sha256': sha((P / 'proposed' / name).read_bytes())}
                for name in ['gazebo_multirobot_mapping_with_nav2.launch.py',
                             'CMakeLists.txt', 'mr3_physics_diagnostic_profile.cpp']}
    expected = ['bcb177d669890ecd6f552379afad771656b6b748c314ea158e5599d37a0c3d2b',
                '43e74b4c2fd82ea5ab2eb950e51b71a1a30009fa2776956749de4e381baa566f',
                '26952e1cb8b17239a61b75ee98466daad65bafe116864557bbe92cc0b7fed7c0']
    assert [row['sha256'] for row in proposed.values()] == expected
    base = json.loads((P / 'base_sources.json').read_bytes())
    current = [{'path': row['source'], 'sha256': sha(Path(row['source']).read_bytes())}
               for row in base]
    write('handoff_final_v1.json', {
        'schema': 'mr3-v18-diagnostic-wiring-handoff-v1',
        'status': 'candidate_sources_STOP_offline_evidence_only',
        'native_admission_granted': False, 'source_freeze': None,
        'canonical_changes_by_this_agent': False, 'build_or_native_by_this_agent': False,
        'base_sources': base, 'proposed_sources': proposed,
        'unapplied_patch': {'path': str(P / 'review_only.patch'),
                            'sha256': sha((P / 'review_only.patch').read_bytes())},
        'current_root_promotion_observed': current,
        'base_current_scope': 'Root confirms it promoted bcb177/269 and merged CMake7ebe after verifying finalchecks. A sealing assertion expecting old base-current identity therefore failed; not a candidate test/native failure. Old9a28/84c4 base snapshots are retained. This agent made no canonical changes.',
        'final_checks': {'launch_graph_and_typed': str(P / 'checks_final_v1.json'),
                         'tests_passed': 9, 'wall_seconds': 4.038197519723326,
                         'style': str(P / 'style_final_v2.json'),
                         'scope': 'Pure launch graph/XML/schema/source tests. Fake SO files are plain text. No ROS context, child native process, C++ build/load, physics setter or formal audit.'},
        'old_failures_preserved': ['checks_v1.json', 'checks_v2.json',
                                   'initial_style_v1/execution.json', 'style_final_v1.json'],
        'old_checks_v4_bytes': {
            'old_launch_1df6': str(P / 'initial_style_v1/gazebo_multirobot_mapping_with_nav2.launch.py'),
            'old_helpers_d86': str(P / 'historical_helpers_d86.py'),
            'old_cpp_c552': str(P / 'historical_profile_c552_reconstructed.cpp'),
            'reconstruction_note': str(P / 'historical_source_note_v1.json'),
            'scope': 'Oldchecks_v4 remains bound to1df6, never relabeled final. Final graph aggregate is from last call only; earlier positive graph scratch aggregates were not separately retained.'},
        'accounting': {'each_run': {'reset_API': 1, 'step_API': 32, 'total_API': 33,
                                     'wall_ceiling_proposed_seconds': 1800},
                       'two_predeclared_maximum': {'reset_API': 2, 'step_API': 64,
                           'total_API': 66, 'wall_ceiling_proposed_seconds': 3600,
                           'learning_updates': 0, 'pilot_budget_change': 0}},
        'admission': 'User already authorized P2A.0 completion. Root concretely predeclares/reviews diagnostics and branch/budget, then uses clean pushed sourcefreeze+GO. No new user question is required; elapsed/noanswer never implies permission.',
        'pending_before_any_native': [
            'Root merge/build/provenance checks for observer final source and this profile target. Original a014/four actuator sources must remain exact.',
            'Replace invalid zero digest sentinels in config_template_pending_v1.json with actual reviewed library/source SHA and fix declared run/window.',
            'Predeclare required independent1ms capture/profile/loaded-library/closure evidence. Original30Hz physical FAIL remains scientific outcome, never matrixPASS.',
            'Root scoped-env command only. Fail exact run/firstepisode/scene/seed/adapter+stepped/epoch/audit mismatch; never persist env export into later training.'
        ],
        'limits': [
            'GetParam solver_type/GetStepType is cached metadata. Native quick-step parameter storage readback does not prove private active solver function pointer or continuous accuracy.',
            'First successful profile callback stays subscribed but immediately returns applied==true; no further getter/write/setter. PID is recorded for owned maps binding.',
            'C++ consumes only launch-generated exclusive binding. Strict template duplicate/nonfinite/unknown keys validation is in launch; actual consumed raw binding is retained for independent SHA equality.',
            'Instrumentation has real IO/callback cost. No runtime/performance claim follows from CPU fixtures.',
            'No actor/candidate/map/guard/reward change, explorationfallback, taskgate relaxation, policy or matrix credit.'
        ],
        'all_candidate_source_writers_stopped': True})

    snapshots = P / 'reviewed_root_tools_v1'
    snapshots.mkdir()
    sources = {}
    for name in ['mr3_p2a0_v18_run_diagnostics_v1.py', 'mr3_p2a0_v18_live_admission_v1.py']:
        path = Path('/tmp') / name
        raw = path.read_bytes()
        (snapshots / name).write_bytes(raw)
        sources[str(path)] = {'sha256': sha(raw), 'snapshot': str(snapshots / name)}
    write('root_runner_readonly_review_v1.json', {
        'schema': 'mr3-v18-root-runner-readonly-review-v1', 'sources': sources,
        'scope': 'Source review only; no runner/witness CLI, native/formal, ROS participant or /proc scan. Root may subsequently revise its files.',
        'positive': [
            'Clean exact pushed HEAD/sourceplan/preflight, atomic lock and existing run/receipt refusal prevent native retry.',
            'Native child is reaped and observer thread joined before consumer jobs on normal/exception paths.',
            'Own ancestry/PIDstart/exe,3 actual headers,actual maps/library bytes,profile samePID/rawbinding and3effective-model original byte restoration are checked.',
            'Original physical FAIL is retained as separate optional outcome, while required capture/closure false prevents diagnosticPASS.'
        ],
        'findings': [
            {'kind': 'startup_readiness_race', 'file': 'mr3_p2a0_v18_live_admission_v1.py',
             'fact': 'The exclusive binding filename exists before launch write/close. Witness json.loads of empty/incomplete raw can raise JSONDecodeError, whereas parent observe retries only FileNotFoundError.',
             'fix': 'Require trailing newline before parsing the known single-line generated binding; incomplete input maps to FileNotFoundError. Complete malformed bytes still fail. This is read-only readiness polling, not native retry.'},
            {'kind': 'failure_receipt_gap', 'file': 'mr3_p2a0_v18_run_diagnostics_v1.py',
             'fact': 'Per-consumer subprocess launch/result-JSON exceptions escape the loop before final completed/pair receipts and later-skip evidence. Native has already been reaped; no orphan/falsePASS is demonstrated.',
             'fix': 'Preserve actual argv/error per attempted job, aggregate required failure and finish parent receipt/skip without rerunning the consumer.'},
            {'kind': 'file_identity_hardening', 'file': 'mr3_p2a0_v18_live_admission_v1.py',
             'fact': 'mapped() checks inode/device before later hashing library bytes; the two reads are not associated to a shared fd-stat snapshot under replacement. No actual mutation was observed.',
             'fix': 'Return associated fd-stat from read() and compare to maps, or recheck mapped(maps_raw,path) immediately after stable byte read/final identity.'},
            {'kind': 'predeclared_branch_consistency', 'file': 'mr3_p2a0_v18_run_diagnostics_v1.py',
             'fact': 'Runner unconditionally attempts iters150 after baseline required capture/closure. This is valid for two explicitly fixed runs; it does not implement the reproduced-nonrest conditional branch in my optional design.',
             'fix': 'Choose fixed-two versus conditional semantics in the plan before freeze; if conditional, test the declared branch and skip when absent. Never choose after seeing a favorable result.'}
        ], 'not_claimed': 'These are concrete source paths/possible startup failure modes, not newly observed native failures.'})

    for directory, name in [(D, 'manifest_final_v2.json'), (P, 'manifest_final_v1.json')]:
        rows = []
        for path in sorted(directory.rglob('*')):
            if not path.is_file() or '__pycache__' in path.parts or path.suffix in ('.pyc', '.pyo'):
                continue
            if path.name == name:
                continue
            raw = path.read_bytes()
            row = {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}
            if path.suffix == '.gz':
                row['decoded_sha256'] = sha(gzip.decompress(raw))
            rows.append(row)
        value = {'schema': 'mr3-v18-candidate-offline-manifest-v1',
                 'scope': 'Only design/proposal/CPU/source review. No canonical/build/native/formal by this agent. Historical failures retained; self/cache excluded.',
                 'files': rows, 'files_count': len(rows), 'all_writers_stopped': True}
        target = directory / name
        with target.open('x') as stream:
            json.dump(value, stream, indent=2)
            stream.write('\n')
        print(json.dumps({'manifest': str(target), 'files': len(rows),
                          'sha256': sha(target.read_bytes())}))
    print(json.dumps({'handoff_sha256': sha((P / 'handoff_final_v1.json').read_bytes()),
                      'root_review_sha256': sha((P / 'root_runner_readonly_review_v1.json').read_bytes())}))


if __name__ == '__main__':
    main()
