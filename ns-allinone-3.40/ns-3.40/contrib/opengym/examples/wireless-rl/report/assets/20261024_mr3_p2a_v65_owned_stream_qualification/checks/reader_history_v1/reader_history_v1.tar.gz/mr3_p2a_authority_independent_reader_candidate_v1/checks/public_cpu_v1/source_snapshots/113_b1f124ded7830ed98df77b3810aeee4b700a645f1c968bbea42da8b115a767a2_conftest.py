"""Private overlay only; canonical-ready test sources themselves use real imports."""
import importlib.util
from pathlib import Path
import sys

ROOT=Path('/home/zhuyulab/ns3-workspace')
W=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
S=Path(__file__).resolve().parent/'shadow'/W.relative_to(ROOT)/'mr3_learning'
sys.path.insert(0,str(W))
import mr3_learning

for name in ('motion_authority_profile','audit_reach_runtime','motion_authority_audit',
             'native_custody_reach','audit_reach_reset_workload','reach_gates','reach_preparation',
             'audit_reach_peer_control','audit_reach_controlled_physics','audit_reach_preparation',
             'audit_reach_cadence','audit_seed_inputs','audit_reach_ppo','reach_policy_chain'):
    file=S/(name+'.py')
    spec=importlib.util.spec_from_file_location('mr3_learning.'+name,file)
    module=importlib.util.module_from_spec(spec)
    # Immutable dependencies and ROOT continue to use actual canonical paths;
    # the CPU receipt binds the separate source bytes actually executed here.
    module.__file__=str(W/'mr3_learning'/file.name)
    sys.modules[spec.name]=module;setattr(mr3_learning,name,module)
    exec(compile(file.read_bytes(),str(file),'exec'),module.__dict__)
