"""Seal the read-only diagnostic candidate, including earlier real failures."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import urllib.request

OUT=Path(__file__).parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


check=json.loads((OUT/'checks_v1.json').read_bytes())
assert check['passed'] is True
source=OUT/'mr3_stop_response_observer.cpp'
assert sha(source.read_bytes())=='4e721e15ee7c67938c1f2c1dbd3005e0832adb0182c66d6dce6ddcafaf7c0396'
sources=[]
for name in ('ContactManager','ode/ODEPhysics'):
    url='https://raw.githubusercontent.com/gazebosim/gazebo-classic/gazebo11_11.10.2/gazebo/physics/'+name+'.cc'
    data=urllib.request.urlopen(url,timeout=20).read()
    selected=OUT/(name.split('/')[-1]+'_11.10.2.cc')
    selected.write_bytes(data)
    sources.append({'url':url,'selected':str(selected),'sha256':sha(data)})
schema={
 'schema':'mr3-stop-response-observer-v1',
 'soname':'libmr3_stop_response_observer.so',
 'sdf_keys':{'output_path':'exclusive dedicated JSONL path','epoch':'nonempty exact episode identity',
   'robot':'nonempty exact robot name','start_ns':'nonnegative decimal int64 string',
   'end_ns':'decimal int64 string >start_ns','base_link':'required explicit current MR3 base_link',
   'right_joint':'wheel_right_joint','left_joint':'wheel_left_joint'},
 'all_rows':{'epoch':'string','robot':'string','kind':'configuration|sample|capture_complete',
   'record_sequence':'positive integer increasing by1','sim_time_ns':'actual callback world-clock int',
   'world_iterations':'actual world integer','wall_monotonic_ns':'actual steady clock integer',
   'measurements_finite':'typed bool before JSON serialization; false when any raw numeric JSON member is nonfinite. Nonfinite raw body/joint values serialize null and must be rejected, never reinterpreted0.'},
 'configuration':{'process_id':'getpid() int','world_name':'actual world name',
   'loaded_library_path':'canonical dladdr path','compiled_source_sha256':'configured source SHA macro',
   'physics_type':'engine GetType','max_step_size_sec':'public physics getter',
   'physics_parameters':'typed public GetParam entries; iters/sor/cfm/erp/solver_type explicitly sdf_cached_public_GetParam',
   'native_ode':'object described below','canonical_name':'actual scoped canonical link',
   'base_name':'actual scoped explicit base_link','start_ns':'integer','end_ns':'integer',
   'flush_per_completed_pair':True,'observer_effect':'explicit synchronous observer wall-time load'},
 'native_ode':{'available':'typed bool, false if not actual ODE/WorldId or nonfinite native values',
   'nonfinite':'typed bool when ODE is available','readback_scope':'native_dWorld_getters_on_public_ODEPhysics_GetWorldId',
   'values':['iters','precon_iters','sor','cfm','erp','contact_max_correcting_vel',
       'contact_surface_layer','sor_lcp_tolerance','use_dynamic_moi_rescaling','gravity_xyz'],
   'solver_dispatch':{'available':False,'reason':'actual private step function lacks public getter; GetStepType also reads SDF'}},
 'sample':{'phase':'before_physics_after_collision|world_update_end_after_physics_and_pose_propagation',
   'pair_sequence':'positive integer increasing once per completed physics step',
   'pair_iterations':'actual pre-world iteration, post must exactly match',
   'before_record_sequence':'self/pre row sequence','before_clock_ns':'exact pre callback sim clock',
   'physics_enabled':'actual World::PhysicsEnabled typed bool',
   'model':'actual world pose/linear and angular velocity',
   'canonical':'link name/world pose/CoG pose/origin velocity/CoG velocity/angular velocity',
   'base':'same fields at explicitly named base_link',
   'joints_right_left':'position/feedback velocity/GetParam vel and fmax/GetForce readbacks in right,left order',
   'solver_diagnostics_world_scope':'GetParam rms_error/constraint_residual/num_contacts, not per-robot attribution',
   'native_ode':'same native ODE actual getter object',
   'contacts':'only valid prefix [0,GetContactCount), current own model vs static-environment support candidates'},
 'contacts':{'manager_available':'typed bool','valid_prefix_count':'integer including all retained world contacts',
   'never_drop_contacts':'read-only existing flag; observer never calls setter or creates publisher/filter',
   'available':'true only if fresh selected own/static contact points retained; false/empty does not prove no physical contacts',
   'records':'scoped collision/link names, own_collision_index, contact_time_ns, count, world positions/normals/depths',
   'forces':'available only postsolve with fresh record, ODE and World::PhysicsEnabled. Body force/torque vectors are labeled in respective link frames as implemented by ODEPhysics.cc; pre never reads stale force arrays.'},
 'load_time_note':'Configuration occurs at ModelPlugin::Load. A diagnostic profile applied at first WorldUpdateBegin may causally follow that header. Do not demand a contrast-mode150 header before the recorded profile application. All task sample native values must match declared actual profile.',
 'tail_note':'Capture_complete is emitted only if a real callback exceeds the finite window. An exclusive0..300e9 window with earlier natural close need not emit it; require complete pre/post pairs and actual task-interval coverage, not a fabricated completion row.',
 'no_identity_invention':'Private original driver desired/applied/cmdseq/targetseq remain in unchanged original driver trace. Join by real epoch/clock/order and compare actual motor GetParam(vel); observer does not claim packet or actuator ACK.'}
with (OUT/'schema_v1.json').open('x') as output:
    json.dump(schema,output,indent=2)
    output.write('\n')
review={
 'schema':'mr3-v18-observer-proposal-final-review-v1','status':'candidate_only_no_canonical_native_or_formal',
 'source_sha256':sha(source.read_bytes()),'patch_sha256':sha((OUT/'review_only.patch').read_bytes()),
 'syntax_check':str(OUT/'checks_v1.json'),'syntax_exit':check['commands'][0]['exit_code'],
 'syntax_wall_sec':check['commands'][0]['wall_sec'],'schema_path':str(OUT/'schema_v1.json'),
 'corrections_preserved':[
   'v1 actual SDFormat9 Get<int64_t> syntax failure kept with exact initial source/argv/stdout.',
   'v3 public GetParam iters/sor/cfm/erp/type are SDF-cached, not independent actual ODE world values. v4/v5 explicitly label this and add native dWorldGet... getters.',
   'GetStepType also reads SDF. No active private solver-dispatch getter is invented.',
   'v5 additionally records PhysicsEnabled and suppresses current-force availability if the physics step was disabled.'
 ],
 'unchanged':check['canonical_unchanged_bindings'],
 'limits':[
   'Independent opt-in ModelPlugin only; original a014 driver/4sources/control/protocol unchanged. CMake proposal removes to exact prior bytes when only new target block is removed.',
   'No actor/map/mask/safety input, transport publisher/subscriber/filter or physics/motor setter. Explicit diagnosis SDF injection must be separately authorized/frozen.',
   'Synchronous getters/JSON/stdio add real wall load. Read-only does not mean no observer effects. Pair write/clock/iteration failures throw and can interrupt the diagnostic engine; preserve them as infrastructure failures.',
   'Contact records are only whatever the existing manager retained. No SetNeverDropContacts or extra subscription is used. Missing records never imply no physical contact.',
   'No .so built/loaded, plugin factory/lifetime exercised, Gazebo task/native run, formal audit or new PASS credit. Syntax-only is limited CPU evidence.',
   'Original V17 strict .01/3sample/.78/.144 failures remain unchanged and cannot be spliced with future diagnostics.'
 ],
 'primary_sources':sources,'utc':datetime.now(timezone.utc).isoformat()}
with (OUT/'final_review_v1.json').open('x') as output:
    json.dump(review,output,indent=2)
    output.write('\n')
files=[]
for directory in sorted(OUT.parent.glob('mr3_p2a0_v18_driver_diagnostic_proposal_v*')):
    for path in sorted(directory.rglob('*')):
        if path.is_file() and path.name!='manifest_final_v2.json':
            data=path.read_bytes()
            files.append({'path':str(path),'bytes':len(data),'sha256':sha(data)})
extra=OUT.parent/'mr3_p2a0_v18_make_observer_v4.py'
data=extra.read_bytes()
files.append({'path':str(extra),'bytes':len(data),'sha256':sha(data)})
manifest={'schema':'mr3-v18-observer-candidate-custody-final-v2','files':files,'count':len(files),
          'bytes':sum(r['bytes'] for r in files),'scope':'All actual candidate/history/CPU failures preserved. No canonical/native/formal writes. Stop writers after this manifest.'}
with (OUT/'manifest_final_v2.json').open('x') as output:
    json.dump(manifest,output,indent=2)
    output.write('\n')
print(json.dumps({'manifest':str(OUT/'manifest_final_v2.json'),
                  'manifest_sha256':sha((OUT/'manifest_final_v2.json').read_bytes()),
                  'count':manifest['count'],'bytes':manifest['bytes'],
                  'final_review_sha256':sha((OUT/'final_review_v1.json').read_bytes()),
                  'schema_sha256':sha((OUT/'schema_v1.json').read_bytes())},indent=2))
