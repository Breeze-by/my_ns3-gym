"""One isolated fakeproc counterexample; no old suite or real process reads."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import time
from unittest.mock import patch

D = Path('/tmp/mr3_p2a0_v26_capture_consistency_independent_review_v1')
SOURCE = Path('/tmp/mr3_p2a0_v26_capture_consistency_proposal_v1/'
              'mr3_v26_smoother_custody_v2.py')
FIXTURE = Path('/tmp/mr3_p2a0_v25_smoother_custody_proposal_v3/'
               'test_smoother_custody_v1.py')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def stat(path):
    s = path.stat()
    return [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns]


started = time.monotonic()
before = {str(p): {'sha256': sha(p), 'stat': stat(p)} for p in (SOURCE, FIXTURE)}
assert before[str(SOURCE)]['sha256'] == '7ff18f1a1628a24367cfeff69b65c6c5ea0177c9a6c178a6839172c1688e649e'
m = load('isolated_v26_capture_module', SOURCE)
fixture = load('reused_fixture_definitions_only', FIXTURE)
facts = {}
with tempfile.TemporaryDirectory(prefix='mr3-v26-one-reuse-z-') as directory:
    with patch.object(fixture, 'm', m):
        f = fixture.Fixture(Path(directory))
        count = 0
        original = m.file_proof

        def hook(value, read):
            global count
            count += 1
            result = original(value, read)
            if count == 4:
                path = f.proc / '110/stat'
                facts['before_stat'] = path.read_text()
                path.write_text(path.read_text().replace('1010', '7777').replace(') S ', ') Z '))
                facts['after_stat'] = path.read_text()
                (f.proc / '110/exe').unlink()
                facts['after_exe_exists'] = (f.proc / '110/exe').exists()
            return result

        with patch.object(m, 'file_proof', side_effect=hook):
            proof = f.observe()
        facts['proof'] = proof
assert proof['passed'] is False
assert proof['errors'] == []
assert proof['episodes'][0]['complete'] is False
assert 'disappeared' in proof['episodes'][0]['pending_reason']
assert proof['episodes'][0]['attempts'][0]['identity_after']['start_ticks'] == 7777
for p in (SOURCE, FIXTURE):
    assert before[str(p)] == {'sha256': sha(p), 'stat': stat(p)}
result = {
    'schema': 'mr3-v26-reuse-z-missing-exe-single-counterexample-v1',
    'counterexample_reproduced': True,
    'finding': 'Already-observed different PID/start is swallowed as no-error disappearance pending before hard pair check.',
    'scope': 'One direct prospective observe with fakeproc; no old9/21, no formal CLI or real /proc/ROS/native. This is not actual native035 attribution.',
    'facts': facts, 'input_bindings': before, 'argv': sys.argv,
    'script_sha256': sha(Path(__file__)),
    'wall_seconds': time.monotonic() - started,
    'source_end_sha_stat_stable': True,
}
with (D / 'reuse_z_missing_exe_v1.json').open('x') as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps({'counterexample_reproduced': True,
                  'source_sha256': before[str(SOURCE)]['sha256'],
                  'proof_errors': proof['errors'],
                  'pending_reason': proof['episodes'][0]['pending_reason'],
                  'output_sha256': sha(D / 'reuse_z_missing_exe_v1.json')}))
