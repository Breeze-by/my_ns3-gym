"""Generate a conditional auditor integration; canonical sources remain untouched."""
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
AUDIT = ROOT / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
                'mr3_learning/audit_ppo.py')
SEALED = Path('/tmp/mr3_p2a0_v19_conditional_world_iters150_proposal_v1/attempt02')

FUNCTION = '''def verify_machine_task_file(root, freeze, relative):
    """Bind current bytes and narrowly project only the reviewed six-file revision."""
    normative = subprocess.check_output(
        ["git", "show", TASK_BASE_FREEZE + ":" + relative], cwd=root)
    actual = subprocess.check_output(["git", "show", freeze + ":" + relative], cwd=root)
    normative_digest = hashlib.sha256(normative).hexdigest()
    actual_digest = hashlib.sha256(actual).hexdigest()
    if relative not in SOLVER150_WORLD_PINS and relative not in SOLVER150_TASK_PINS:
        require(actual == normative and sha(root / relative) == normative_digest,
                "machine task/geometry changed from accepted W7 contract: " + relative)
        return {"sha256": normative_digest, "git_source": freeze + ":" + relative,
                "normative_source": TASK_BASE_FREEZE + ":" + relative}
    expected_digest = (SOLVER150_WORLD_PINS if relative in SOLVER150_WORLD_PINS
                       else SOLVER150_TASK_PINS)[relative]
    require(actual_digest == expected_digest and sha(root / relative) == expected_digest,
            "explicit solver150 machine source freeze/worktree SHA mismatch: " + relative)
    if relative in SOLVER150_WORLD_PINS:
        anchor = b"      <real_time_update_rate>1000</real_time_update_rate>\\n"
        block = (b"      <ode>\\n"
                 b"        <solver>\\n"
                 b"          <type>quick</type>\\n"
                 b"          <iters>150</iters>\\n"
                 b"        </solver>\\n"
                 b"      </ode>\\n")
        require(normative.count(anchor) == 1 and b"<ode>" not in normative
                and actual.count(block) == 1
                and actual == normative.replace(anchor, anchor + block, 1)
                and actual.replace(block, b"", 1) == normative,
                "solver150 world does not project exactly to W7: " + relative)
        revision = "explicit_quickstep150_physics_only_v1"
        world_reference = None
    else:
        scene = Path(relative).stem
        world_relative = ROS + "src/multi_robot/worlds/p1c_" + scene + ".world"
        require(world_relative in SOLVER150_WORLD_PINS,
                "solver150 task metadata has no reviewed matching scene")
        world_proof = verify_machine_task_file(root, freeze, world_relative)
        old_field = ('  "world_sha256": "' + world_proof["normative_sha256"] + '",\\n').encode()
        new_field = ('  "world_sha256": "' + world_proof["sha256"] + '",\\n').encode()
        require(normative.count(old_field) == 1 and actual.count(new_field) == 1
                and actual == normative.replace(old_field, new_field, 1)
                and actual.replace(new_field, old_field, 1) == normative,
                "solver150 task metadata does not project exactly to W7: " + relative)
        revision = "actual_world_sha256_metadata_only_v1"
        world_reference = {"path": world_relative, "sha256": world_proof["sha256"]}
    proof = {"sha256": actual_digest, "git_source": freeze + ":" + relative,
             "normative_source": TASK_BASE_FREEZE + ":" + relative,
             "normative_sha256": normative_digest, "machine_revision": revision,
             "projected_normative_sha256": normative_digest,
             "scope": "actual revised execution/config bytes; exact W7 geometry/task projection"}
    if world_reference is not None:
        proof["actual_world"] = world_reference
    return proof


'''


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    original = AUDIT.read_bytes()
    checks = json.loads((SEALED / 'checks_v1.json').read_bytes())
    assert checks['passed'] and checks['conditional_only']
    constants = ''
    for name, key in [('SOLVER150_WORLD_PINS', 'prospective_world_pins'),
                      ('SOLVER150_TASK_PINS', 'prospective_task_metadata_pins')]:
        constants += name + ' = {\n'
        for path, digest in checks[key].items():
            constants += '    ' + repr(path) + ':\n        ' + repr(digest) + ',\n'
        constants += '}\n'
    constants += '\n'
    text = original.decode()
    marker = '\n\ndef parameter_changes(before, after):\n'
    assert text.count(marker) == 1
    text = text.replace(marker, '\n\n' + FUNCTION + 'def parameter_changes(before, after):\n', 1)
    marker = 'PHASE_SHA256 = '
    assert text.count(marker) == 1
    text = text.replace(marker, constants + marker, 1)
    old_loop = '''    for relative in machine_paths:
        normative = subprocess.check_output(
            ["git", "show", TASK_BASE_FREEZE + ":" + relative], cwd=root)
        actual = subprocess.check_output(["git", "show", freeze + ":" + relative], cwd=root)
        digest = hashlib.sha256(normative).hexdigest()
        require(actual == normative and sha(root / relative) == digest,
                "machine task/geometry changed from accepted W7 contract: " + relative)
        proof[relative] = {"sha256": digest, "git_source": freeze + ":" + relative,
                           "normative_source": TASK_BASE_FREEZE + ":" + relative}
'''
    assert text.count(old_loop) == 1
    text = text.replace(old_loop, '''    for relative in machine_paths:
        proof[relative] = verify_machine_task_file(root, freeze, relative)
''', 1)
    files = {'original_audit_ppo.py': original, 'proposed_audit_ppo.py': text.encode(),
             'original_machine_loop.txt': old_loop.encode(),
             'review_only.patch': ''.join(difflib.unified_diff(
                 original.decode().splitlines(True), text.splitlines(True),
                 fromfile='a/mr3_learning/audit_ppo.py',
                 tofile='b/mr3_learning/audit_ppo.py')).encode()}
    for name, raw in files.items():
        with (HERE / name).open('xb') as stream:
            stream.write(raw)
    assert AUDIT.read_bytes() == original
    receipt = {'passed': True, 'conditional_only': True,
               'original_canonical_source': str(AUDIT),
               'original_source_sha256': sha(original),
               'canonical_unchanged': True,
               'proposed_source_sha256': sha(text.encode()),
               'env_pin': 'unchanged; actual future execution document revision pending, not ready',
               'source_of_six_pins': {'path': str(SEALED / 'checks_v1.json'),
                                     'sha256': sha((SEALED / 'checks_v1.json').read_bytes())},
               'files': [{'path': str(HERE / name), 'sha256': sha(raw), 'bytes': len(raw)}
                         for name, raw in files.items()]}
    with (HERE / 'generation_receipt_v1.json').open('x') as stream:
        json.dump(receipt, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'passed': True, 'proposed_source_sha256': sha(text.encode()),
                      'canonical_unchanged': True}))


if __name__ == '__main__':
    main()
