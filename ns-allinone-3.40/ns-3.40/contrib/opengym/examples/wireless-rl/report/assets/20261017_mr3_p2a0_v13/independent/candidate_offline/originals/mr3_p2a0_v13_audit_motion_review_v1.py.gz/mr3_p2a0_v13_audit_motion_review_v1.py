"""Replay the retained root03 auditor in isolation; no Git edits or native input."""
from pathlib import Path
import copy
import gzip
import hashlib
import importlib.util
import json
import sys
import tempfile
from types import ModuleType

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
SAVED = Path('/tmp/mr3_p2a0_v13_root_motion_cpu_sources_03')
OUT = Path('/tmp/mr3_p2a0_v13_audit_motion_review_v1')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    OUT.mkdir()
    originals = {}
    for name in ('audit_motion.py', 'test_audit_motion.py'):
        source = SAVED / (name + '.gz')
        encoded = source.read_bytes()
        decoded = gzip.decompress(encoded)
        (OUT / (name + '.gz')).write_bytes(encoded)
        originals[name] = {'path': str(source), 'encoded_sha256': sha(encoded),
                           'decoded_sha256': sha(decoded)}
    audit = ModuleType('detached_root03_audit_motion')
    audit.__file__ = str(W / 'mr3_learning/audit_motion.py')
    exec(compile(gzip.decompress((SAVED / 'audit_motion.py.gz').read_bytes()),
                 audit.__file__, 'exec'), audit.__dict__)
    tests = ModuleType('detached_root03_test_audit_motion')
    tests.__file__ = str(W / 'mr3_learning/tests/test_audit_motion.py')
    previous = sys.modules.get('mr3_learning.audit_motion')
    sys.modules['mr3_learning.audit_motion'] = audit
    try:
        exec(compile(gzip.decompress((SAVED / 'test_audit_motion.py.gz').read_bytes()),
                     tests.__file__, 'exec'), tests.__dict__)
    finally:
        if previous is None:
            sys.modules.pop('mr3_learning.audit_motion', None)
        else:
            sys.modules['mr3_learning.audit_motion'] = previous
    helper = tests.helper_module()
    helper_path = Path(helper.__file__)
    helper_raw = helper_path.read_bytes()
    gap = {}
    with tempfile.TemporaryDirectory(prefix='v13_audit_motion_review_') as temp:
        directory = Path(temp)
        files = tests.write_controlled_fixture(directory, helper)
        baseline = audit._audit_records(directory, helper, {})
        gap['baseline_passed'] = baseline['passed']
        mutant = copy.deepcopy(files)
        modified = []
        for index, row in enumerate(mutant['motion_safety.jsonl'], 1):
            if row['kind'] == 'own_odom' and row['payload']['robot'] == 'tb1':
                row['payload']['message']['twist']['twist']['angular']['x'] = 1.3
                modified.append(index)
        tests.write_files(directory, mutant)
        result = audit._audit_records(directory, helper, {})
        gap.update(mutated_audit_passed=result['passed'], changed_local_raw_rows=modified,
                   actual_mutation={'angular_x': 1.3}, other_decision_fields_unchanged=True)
        for name, data in [('baseline_fixture.json', files), ('mutated_fixture.json', mutant)]:
            (OUT / name).write_text(json.dumps(data, indent=2, allow_nan=False) + '\n')
    assert helper_raw == helper_path.read_bytes()
    command_cases = []
    for output, limits in [([.2, .8], (.2, .8)), ([.2], (.2, .8)),
                           ([.2, .8, 999.], (.2, .8)), ([.2, 999.], (.2,)),
                           ([.26, .4], (.26, .8))]:
        try:
            audit.command_boundary({'allow': True, 'output': output},
                                   {'v': output[0], 'w': output[1] if len(output)>1 else 0.},
                                   command_limits=limits)
            passed = True
        except (ValueError, TypeError):
            passed = False
        command_cases.append({'output': output, 'limits': list(limits), 'accepted': passed})
    review = {'schema': 'mr3-v13-audit-motion-independent-source-review-v1',
        'scope': 'Read-only exact root03 two-file snapshot review and synthetic detached methods. No native/formal audit or gate change; does not claim a complete matrix falsePASS.',
        'source_snapshots': originals,
        'current_helper': {'path': str(helper_path), 'sha256': sha(helper_raw),
                           'changed_during_replay': False},
        'findings': [{'id': 'full-angular-local-normal-commit',
            'severity': 'new failfast contract audit coverage gap; old mandatory angular gate still rejects actualbound violation',
            'proof': gap,
            'cause': 'own_state reconstructs only v/w/planar scalar, not raw angularXYZ; ready loop valid_state sees abs(wz) only. New producer separately checks raw full vectors/history before normal commit.',
            'minimal_suggestion': 'For new-helper branch, on non-stop ready normal decision validate actual selected local raw with measured_velocity_error(require_raw=True), and release-to-clock causal own history for the declared failfast history contract. Keep recorded own_state schema/legacy paths unchanged.'}],
        'positive_checks': ['command_limits and final output both require length2, finite nonbool positive caps and finite nonbool values; no zip truncation loophole',
            'normalization input is bound to the two original request values, then exact one-ULP endpoint; explicit old(.26,.8) remains available and frozen helpercaps drive actual replay',
            'peer require_raw is enabled only for helper exposing measured_velocity_error; actualreceived peer bytes/scalars stay exact bound and original own_state comparison remains',
            'no change to original geometry, braking equations, stop/phase/nativeFIFO or final strict equality in this diff'],
        'command_shape_cases': command_cases,
        'root_source_files_modified_by_reviewer': False,
        'script_sha256': sha(Path(__file__).read_bytes())}
    (OUT / 'review_v1.json').write_text(json.dumps(review, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'output': str(OUT / 'review_v1.json'),
        'sha256': sha((OUT / 'review_v1.json').read_bytes()), 'gap': gap,
        'command_shape_cases': command_cases}))


if __name__ == '__main__':
    main()
