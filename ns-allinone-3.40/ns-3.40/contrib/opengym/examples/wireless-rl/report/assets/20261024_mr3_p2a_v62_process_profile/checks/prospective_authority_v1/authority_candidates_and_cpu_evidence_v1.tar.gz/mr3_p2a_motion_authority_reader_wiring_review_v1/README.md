# Typed receiving-authority：未来公开读者接线清单

这是源码审查与未执行的测试规格；没有应用代码、跑reader/CPU/native、读取V60五原件或赋予新资格。A62性能baseline仍旧production。core候选仅/tmp，SHA `ba2e5d8880021872f9cbc941b1457013be0e8721e8a1b137af77a8fca0672f70`，尚未ROS接线/CPU。

最重要的必要接线是 **raw→独立authority重建→effective→原Reach oracle→实际motor**。`reach_decision.request`必须继续等于原raw，不可重写零。独立读者验证实际GRANT/RENEW/REVOKE发布/接收、真实owner/UUID/epoch/seq/floor/lease与stop义务后，才以验证出的effective_request喂原数学函数；ACTIVE也不能任意给额外zero信用。原supported/GID/freshness判据仍独立核，原oracle仍可拒绝或component-filter。no-owner仅有效输入零，不能强置ready=False制造bootstrap死锁，也不能调用永久STOP替代普通取消。

新profile建议独立metadata键`motion_authority_profile=mr3-owned-stream-authority-v1`；`actuation_profile=initial-zero-encoder-hold-v1`保持。固定自动Reach派生，legacy旧路保留；不加benchmark/PPO自由开关。新配置/计划选择缺字段必须拒绝，不能把缺失当旧版本降级。

当前可定位的实质缺口：

1. `audit_reach_peer_control.py:306–309`硬拒未知motion事件；`check_decision:318`正确绑定原raw。新增事件须窄profile验证后仍把完整原行交给原父类计seq，不能删行/归零normalization。
2. `audit_reach_runtime.py:567–705`反而会忽略未知事件；`admitted_command:368`全零直接返回。只补whitelist会让新authority完全没被证明。必须新增独立重放及公开EP/RUN的严格结果合取，再用effective作为原数学输入。
3. `reach_gates.load_exact_protocol:147–155`只更新adapter SHA；`audit_protocol.PINS`仍固定protocol.py。若closing改变protocol，单改adapter pin必FAIL；需要显式新source与实际生命周期验证，不能改literal糊过去。
4. `mr3_observation.py:54`及learner `observation.py:28`只支持原六个nav.phase，后者固定六维编码。新`closing`phase会触及mask、完整snapshot/archive重构、tensor与normalization契约。优先保持原形状、另记owner barrier；若改变则须完整显式版本与新proof，不能漏接input。
5. full/preparation与PPO已有plan→peer/controlled双dispatch接线，应复用；公开cadence也需合取新runtime proof。input leaf仍证明地图/快照，只做正确profile/source身份与原始archive一致，不伪称它证明了authority。
6. PPO在模型副作用前必须核新plan/QUAL/profile；在targets/update前必须核本epoch必要authority eligibility/proof，不能从旧summary无已知fault推新PASS。proof生成路径/成本须明确纳入后继capacity，不拿预算理由删必要门。
7. 原计划ROS source_inventory用git-ls-files，新untracked helper会漏；fresh CPU分类必须继续显式纳P/*.py、ROS test/*.py、W tests/*.py全部当前文件。plan/stage/三policy registry/QUAL/native/supervisor/PPO/config同profile，不能借旧CPU或旧资格。

仍需最终ROS wrapper决定的小接口：上述六个journal事件的精确schema、negative/duplicate ACK形状，以及实际authority_received ACK如何与下一正常20ms phase/advance绑定。publication不是delivery；不可等rest时冻结physics。这里没有为此创建新通道或通用框架。新C++事件不需要：本候选未改实际motor law，保留APPLIED-v1、20/34ms、原complete nativeprefix与compound replay。仅在所有编译源相同且原真实bridge仍通过时按原规则复用build，不伪造新build。

停止见证必须关联实际storage/APPLIED与原calibrated rest/PUB/H/anchor义务；body0不等于motor0，startupservo纠偏非零和首次实际非零后的严格零rim分开。取消物理B起点仍是原native_cancel sourceclock，不能重置为authority接收/ACK/stopready。GRANT后seq>floor仅接收屏障；raw_goal_generation=null、UNKNOWN_UNSTAMPED_TWIST。取消前生成、恢复后才回调仍可UNKNOWN，不能声称完整goal-generation隔离。

`reader_wiring_checklist_v1.json`给出具体文件/函数/行号；`prospective_evidence_contract_v1.json`列拟议join字段；`prospective_public_route_tests_v1.json`列12个实际公开路径正负案例（未执行，非CPU证据）。`source_baseline_v1.json`固定27份当前解释源字节与core/contract SHA。新source/helper/reader全部稳定后，才做人工public-route CPU、新freeze与真实有意义取消→原12EP/30角色→容量/学习/strict95；原R/STOP债务/5commit/两秒lease/首次非零servo latch及旧FAIL保持。
