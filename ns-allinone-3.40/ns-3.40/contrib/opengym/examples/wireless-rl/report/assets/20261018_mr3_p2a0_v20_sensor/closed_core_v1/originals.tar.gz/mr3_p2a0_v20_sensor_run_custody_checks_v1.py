"""Record shortest schema-fit CPU checks, exact argv/env/source stability."""
import hashlib
import json
from pathlib import Path
import subprocess
import time


ROOT = Path('/home/zhuyulab/ns3-workspace')
TMP = Path('/tmp')
ENV = {'PATH': '/usr/bin:/bin', 'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1',
       'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'TZ': 'UTC'}
SOURCES = [TMP / name for name in ('mr3_p2a0_v20_sensor_prepare_custody_v1.py',
                                  'mr3_p2a0_v20_sensor_pack_closed_v1.py',
                                  'mr3_p2a0_v20_sensor_custody_tests_v1.py',
                                  'mr3_p2a0_v20_sensor_run_custody_checks_v1.py')]


def hashes():
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in SOURCES}


def main():
    before = hashes()
    start = time.monotonic()
    commands = [('fixture01', ['/usr/bin/python3', '-B', str(SOURCES[2])]),
                ('fatal_style01', ['/usr/bin/python3', '-m', 'flake8',
                                   *[str(path) for path in SOURCES], '--select=E9,F63,F7,F82'])]
    rows = []
    for label, argv in commands:
        began = time.monotonic()
        result = subprocess.run(argv, cwd=ROOT, env=ENV, capture_output=True)
        output = TMP / ('mr3_p2a0_v20_sensor_custody_' + label + '.log')
        raw = result.stdout + result.stderr
        with output.open('xb') as stream:
            stream.write(raw)
        rows.append({'argv': argv, 'exit_code': result.returncode,
                     'wall_seconds': time.monotonic() - began,
                     'output': str(output), 'output_sha256': hashlib.sha256(raw).hexdigest()})
    after = hashes()
    value = {'schema': 'mr3-v20-sensor-custody-checks-v1', 'argv_environment': ENV,
             'cwd': str(ROOT), 'source_before': before, 'source_after': after,
             'commands': rows, 'wall_seconds': time.monotonic() - start,
             'passed': before == after and all(row['exit_code'] == 0 for row in rows),
             'scope': 'Four tiny schema fixtures plus exact six-core byte/whole inverse proof; old32MiB codec tests not repeated.'}
    path = TMP / 'mr3_p2a0_v20_sensor_custody_checks_v1.json'
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'passed': value['passed'], 'checks': str(path),
                      'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}))
    return 0 if value['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
