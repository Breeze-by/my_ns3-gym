"""Pure finite V6 window/commit review; no native or formal consumers."""
import ast
import copy
import hashlib
import itertools
import json
import math
from pathlib import Path
import subprocess

ROOT = Path('/home/zhuyulab/ns3-workspace')
WIRELESS = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
SOURCES = Path('/tmp/mr3_p2a0_v17_fixture_independent_sources_v1')
NAMES = ('tb1', 'tb2', 'tb3')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load(raw):
    tree = ast.parse(raw)
    names = {'_probe_goal_order', 'probe_action', 'probe_action_v3', 'probe_action_v4',
             'record_probe_v4_submission', '_probe_nonapproaching_goal_action',
             'probe_action_v5', 'probe_action_v6'}
    namespace = {'math': math}
    exec(compile(ast.Module(body=[node for node in tree.body if isinstance(node, ast.FunctionDef)
                                 and node.name in names], type_ignores=[]), '<reviewed-selector>', 'exec'), namespace)
    return tree, namespace


def snapshot(elapsed, allowed=None):
    robots = [{'name': name, 'x': 0., 'y': 2. * i, 'yaw': 0., 'w': 0., 'v': 0.,
               'fresh': True, 'valid': True,
               'activity': {'estimated_path_m': 0., 'path_observation_complete': True},
               'navigation': {'phase': 'idle', 'owned': False, 'goal_id': None,
                              'accepted_goal_count': 1}}
              for i, name in enumerate(NAMES)]
    allowed = allowed or [range(10)] * 3
    per_robot = [[choice in allowed[i] for choice in range(10)] for i in range(3)]
    joint = [all(per_robot[i][choice] for i, choice in enumerate(choices))
             for choices in itertools.product(range(10), repeat=3)]
    return {'epoch': 'synthetic-v17', 'sequence': int(round(elapsed * 1000)) + 1,
            'digest': 'synthetic-' + repr(elapsed), 'task_elapsed_sec': elapsed,
            'robots': robots, 'per_robot_action_mask': per_robot, 'joint_action_mask': joint,
            'candidates': [{'x': 2. + i, 'y': float(i), 'path_distances_m': [2. + i] * 3}
                           for i in range(8)]}


def receipt(snap, action, **extra):
    return {'command': {'epoch': snap['epoch'], 'observation_sequence': snap['sequence'],
                        'observation_digest': snap['digest'], 'action': action,
                        'command_id': snap['sequence']}, **extra}


def main():
    proof = json.loads((SOURCES / 'sources.json').read_bytes())
    source = SOURCES / 'benchmark.py'
    raw = source.read_bytes()
    assert sha(raw) == proof['benchmark.py']['sha256']
    tree, new = load(raw)
    old_path = WIRELESS / 'mr3_learning/benchmark.py'
    old_raw = subprocess.check_output(['git', 'show',
        'ebe7d51bdb7bf9d77a28b77cfb4296876afb0100:' + old_path.relative_to(ROOT).as_posix()], cwd=ROOT)
    old_tree, old = load(old_raw)
    choose, submit = new['probe_action_v6'], new['record_probe_v4_submission']
    results = []

    def step(snap, state):
        action = choose(snap, state)
        assert snap['joint_action_mask'][action] is True
        submit(state, receipt(snap, action))
        return action

    def initial_wait(at=10.):
        state = {}
        assert step(snapshot(at), state) == 999
        return state

    def delayed_team():
        state = initial_wait()
        first = snapshot(13., [[8], [2, 8], [4, 8]])
        assert step(first, state) == 824
        moving = snapshot(18., [[8], [8, 9], [8, 9]])
        for robot in moving['robots'][1:]:
            robot['v'] = .1
            robot['activity']['estimated_path_m'] = .1
            robot['navigation'].update(phase='active', owned=True, goal_id='owned-goal')
        assert step(moving, state) == 899
        return state

    # Old default modes: real original received snapshots, synthetic exact post-step receipts.
    transition = ROOT / ('ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/'
                        'mr3_p2a0_20261017_v16_interface/worker0/episode001_open_101/transitions.jsonl')
    transition_raw = transition.read_bytes()
    records = [json.loads(line) for line in transition_raw.splitlines()]
    for selector in ('probe_action_v4', 'probe_action_v5'):
        a_state, b_state = {}, {}
        for row in records[:-1]:
            snap = row['snapshot']
            before = json.dumps(snap, sort_keys=True, separators=(',', ':'))
            a = old[selector](snap, a_state)
            b = new[selector](snap, b_state)
            assert a == b and a_state == b_state
            old['record_probe_v4_submission'](a_state, receipt(snap, a))
            submit(b_state, receipt(snap, b))
            assert a_state == b_state
            assert before == json.dumps(snap, sort_keys=True, separators=(',', ':'))
    results.append({'check': 'V4/V5 defaults real32 received snapshots actions+diagnostics exact',
                    'passed': True, 'modes': 2, 'records_each': len(records) - 1,
                    'scope': 'Synthetic matching command receipts; no new native accept credit.'})

    # New V6-only ns predicate must have priority at15 and fail at26, without changing elapsed.
    seen_v3 = []
    actual_v3 = new['probe_action_v3']

    def spy_v3(snap, diagnostics):
        seen_v3.append(snap['task_elapsed_sec'])
        return actual_v3(snap, diagnostics)

    new['probe_action_v3'] = spy_v3
    endpoint_cases = []
    for elapsed, late_expected in ((35.12 - 20.12, True), (46.12 - 20.12, False),
                                   (15., True), (25., True), (26., False),
                                   (math.nextafter(26., 0.), False)):
        state = initial_wait()
        seen_v3.clear()
        snap = snapshot(elapsed)
        original = copy.deepcopy(snap)
        action = choose(snap, state)
        assert snap == original
        late = state.get('late_goal_decisions', [])
        assert bool(late) is late_expected
        if late_expected:
            assert not seen_v3
            assert late[-1]['task_elapsed_sec'] == elapsed
            legal = [a for a, valid in enumerate(snap['joint_action_mask'])
                     if valid and new['_probe_nonapproaching_goal_action'](snap, a)
                     and all(c < 9 for c in (a // 100, a // 10 % 10, a % 10))]
            expected = min(legal, key=lambda a: new['_probe_goal_order'](snap, a, True))
            assert action == expected
        else:
            assert seen_v3 == [elapsed]
            assert action == 888
        endpoint_cases.append({'raw_elapsed': elapsed, 'elapsed_ns': round(elapsed * 1e9),
                               'late': late_expected, 'action': action})
    new['probe_action_v3'] = actual_v3
    assert 46.12 - 20.12 < 26  # Old naked-float RED, without new execution.
    results.append({'check': 'integer-ns15/26 boundary and original-time outward ranking',
                    'passed': True, 'cases': endpoint_cases,
                    'naked_double_predicate_at_actual26_would_admit': True,
                    'original_V3_elapsed_not_forged': True})

    state = delayed_team()
    snap = snapshot(22., [[0, 8], [9], [9]])
    pending = choose(snap, state)
    assert pending == 99
    assert 'tb1' not in state['v4_stimulus']['rounds']['second']['waits']
    submit(state, receipt(snap, pending))
    assert 'tb1' not in state['v4_stimulus']['rounds']['second']['waits']
    results.append({'check': 'late legal GOAL099 only; actual submit does not fabricate WAIT',
                    'passed': True})

    for kind in ('no_first_WAIT', 'less_three_seconds', 'stale', 'not_idle', 'not_rest', 'GOAL_masked'):
        state = {} if kind == 'no_first_WAIT' else initial_wait(12.5 if kind == 'less_three_seconds' else 10.)
        elapsed = 15. if kind == 'less_three_seconds' else 22.
        snap = snapshot(elapsed, [[8], [8], [8]] if kind == 'GOAL_masked' else None)
        if kind == 'stale':
            for robot in snap['robots']:
                robot['fresh'] = False
        elif kind == 'not_idle':
            for robot in snap['robots']:
                robot['navigation']['phase'] = 'active'
        elif kind == 'not_rest':
            for robot in snap['robots']:
                robot['v'] = .011
        assert choose(snap, state) == 888, kind
    results.append({'check': 'original first-WAIT/recovery/fresh/rest and GOALmask restrictions',
                    'passed': True, 'subcases': 6})

    # Latest normal integer input25; the unchanged mask must block premature cancel.
    state = delayed_team()
    assert step(snapshot(25., [[0, 8], [9], [9]]), state) == 99
    for elapsed in (26., 28., 29.):
        snap = snapshot(elapsed, [[8], [9], [9]])
        snap['robots'][0]['navigation'].update(phase='active', owned=True, goal_id='last-goal')
        assert step(snap, state) == 899
        assert 'tb1' not in state['v4_stimulus']['rounds']['second']['waits']
    final_cancel = snapshot(30., [[8, 9], [9], [9]])
    action = choose(final_cancel, state)
    assert action == 999 and 'tb1' not in state['v4_stimulus']['rounds']['second']['waits']
    submit(state, receipt(final_cancel, action))
    assert state['v4_stimulus']['rounds']['second']['waits']['tb1']['task_elapsed_sec'] == 30.
    assert step(snapshot(31., [[9], [9], [9]]), state) == 999
    results.append({'check': '25GOAL -> blocked26/28/29 WAIT -> legal30WAIT ->31hold',
                    'passed': True, 'normal_integer_last_goal': 25, 'first_legal_cancel': 30,
                    'planned_tail_until32_sec': 2., 'scope': 'Test supplies authoritative legal '
                    'masks; no proof actual Nav2 command, cancel receipt or physical rest occurs.'})

    state = delayed_team()
    moving = snapshot(23., [[8, 9], [9], [9]])
    moving['robots'][0].update(v=.08)
    moving['robots'][0]['activity']['estimated_path_m'] = .05
    moving['robots'][0]['navigation'].update(phase='active', owned=True, goal_id='owned')
    action = choose(moving, state)
    assert action == 999
    submit(state, receipt(moving, action, action_submitted=False))
    assert 'tb1' not in state['v4_stimulus']['rounds']['second']['waits']
    action = choose(moving, state)
    try:
        submit(state, receipt(moving, action, action_submitted=0))
    except ValueError:
        pass
    else:
        raise AssertionError('untyped actual flag latched')
    assert 'tb1' not in state['v4_stimulus']['rounds']['second']['waits']
    results.append({'check': 'unchanged.08/.05 WAIT trigger; false or typed-alias never latches', 'passed': True})

    old_functions = {node.name: node for node in old_tree.body if isinstance(node, ast.FunctionDef)}
    functions = {node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)}
    unchanged = ('_probe_goal_order', 'probe_action', 'probe_action_v3',
                 'record_probe_v4_submission', '_probe_nonapproaching_goal_action', 'probe_action_v5')
    for name in unchanged:
        assert ast.dump(old_functions[name]) == ast.dump(functions[name])
    assert not any(word in ast.unparse(functions['probe_action_v6']) for word in
                   ('ModelStates', 'truth', 'raw_guard', 'own_odom', 'open(', 'read_text'))
    results.append({'check': 'old ranker/V3/V5/filter/submission AST exact, V6 received keyword wrapper',
                    'passed': True, 'unchanged_functions': list(unchanged)})
    assert source.read_bytes() == raw
    assert Path(proof['benchmark.py']['source']).read_bytes() == raw
    assert transition.read_bytes() == transition_raw
    report = {'schema': 'mr3-v17-fixture-independent-review-v1', 'passed': True,
              'source': {'path': str(source), 'sha256': sha(raw), 'before_after_stable': True},
              'old_V5_freeze': 'ebe7d51bdb7bf9d77a28b77cfb4296876afb0100',
              'old_benchmark_sha256': sha(old_raw),
              'received_fixture': {'path': str(transition), 'sha256': sha(transition_raw)},
              'checks': results,
              'limits': ['New late GOAL availability is an engineering fixture opportunity, '
                         'not a new actor, candidate, real mask, control or safety layer.',
                         'Only new V6 late eligibility uses integer ns. Old V4/V5 default '
                         'float windows/diagnostics remain identical.',
                         'Normal1s input schedule makes latest new GOAL25 and30 cancel '
                         'opportunity. Fractional hypothetical inputs and delayed actual '
                         'mask/cancel delivery must not be called a guaranteed2s rest proof.',
                         'No evidence tb1 will move continuously>=.1s or satisfy a meaningful '
                         'stop. Ineligible body-clearance seeds such as.1449<.29 remain masked.',
                         'All raw body/angular/settled/source/latency/contacts/activity/closure '
                         'gates unchanged; original angular needs perrobot1sign span and at '
                         'least1robot opposite spans; original stopping requires A OR B.',
                         'No new native/formal test/large-log scan/Git/source mutation or '
                         'old V16 prefix output; all lifecycle responses here are synthetic.']}
    output = Path('/tmp/mr3_p2a0_v17_fixture_independent_review_v1.json')
    with output.open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'passed': True, 'checks': len(results), 'output': str(output),
                      'sha256': sha(output.read_bytes())}))


if __name__ == '__main__':
    main()
