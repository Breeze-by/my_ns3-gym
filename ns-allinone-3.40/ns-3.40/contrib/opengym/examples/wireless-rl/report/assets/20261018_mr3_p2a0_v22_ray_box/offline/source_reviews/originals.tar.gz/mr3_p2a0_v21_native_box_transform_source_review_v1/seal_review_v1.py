#!/usr/bin/env python3
"""Seal a static-source review. Does not open live/native trace files."""
import hashlib
import json
import pathlib
import sys
import time

ROOT = pathlib.Path('/tmp/mr3_p2a0_v21_native_box_transform_source_review_v1')
OLD = pathlib.Path('/tmp/mr3_p2a0_v20_sensor_ray_geometry_source_review_v1')
LINK = pathlib.Path('/tmp/mr3_p2a0_v13_stop_point_review_v1')
FILES = [
    ROOT / 'ODEBoxShape_11.10.2.hh', ROOT / 'BoxShape_11.10.2.cc',
    ROOT / 'ode_box_11.10.2.cpp', ROOT / 'ode_ray_11.10.2.cpp',
    ROOT / 'ode_collision_kernel_11.10.2.cpp',
    ROOT / 'ode_collision_kernel_11.10.2.h', ROOT / 'Base_11.10.2.cc',
    OLD / 'official/ODECollision_11.10.2.cc',
    OLD / 'official/Collision_11.10.2.cc',
    OLD / 'official/ODERayShape_11.10.2.cc',
    OLD / 'official/RayShape_11.10.2.cc',
    OLD / 'official/PhysicsEngine_11.10.2.cc',
    OLD / 'inputs/ODEMultiRayShape_11.10.2.cc',
    OLD / 'inputs/MultiRayShape_11.10.2.cc',
    OLD / 'inputs/RaySensor_11.10.2.cc',
    LINK / 'ODELink.cc', LINK / 'Link.cc', LINK / 'Entity.cc',
    pathlib.Path('/tmp/mr3_p2a0_v18_driver_diagnostic_proposal_v5/World_11.10.2.cc'),
    pathlib.Path('/tmp/mr3_p2a0_v18_driver_diagnostic_proposal_v5/ODEPhysics_11.10.2.cc'),
    pathlib.Path('/usr/include/gazebo-11/gazebo/physics/ode/ODEBoxShape.hh'),
    pathlib.Path('/usr/include/gazebo-11/gazebo/physics/ode/ODECollision.hh'),
    pathlib.Path('/usr/include/gazebo-11/gazebo/physics/ode/ODELink.hh'),
    pathlib.Path('/usr/include/gazebo-11/gazebo/physics/ode/ODERayShape.hh'),
    pathlib.Path('/usr/include/gazebo-11/gazebo/ode/collision.h'),
    pathlib.Path('/usr/include/gazebo-11/gazebo/ode/objects.h'),
    pathlib.Path('/home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/src/multi_robot/models/turtlebot3_waffle/model.sdf'),
    pathlib.Path('/tmp/mr3_p2a0_v21_ray_first8_bounded_observation_v1/compact_data_v1.json'),
    pathlib.Path('/tmp/mr3_p2a0_v21_ray_first8_bounded_observation_v1/interim_review_v1.json'),
]


def stat(p):
    s = p.stat()
    return {k: getattr(s, k) for k in ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns')}


def main():
    started = time.monotonic()
    bindings = []
    texts = {}
    for p in FILES:
        before = stat(p)
        data = p.read_bytes()
        after = stat(p)
        if before != after:
            raise RuntimeError('source changed while reading: ' + str(p))
        texts[str(p)] = data.decode('utf-8')
        bindings.append({'path': str(p), 'bytes': len(data),
                         'sha256': hashlib.sha256(data).hexdigest(),
                         'stat_before': before, 'stat_after': after})
    def evidence(p, needle):
        lines = texts[str(p)].splitlines()
        found = [i + 1 for i, line in enumerate(lines) if needle in line]
        if not found:
            raise RuntimeError('missing reviewed source clause: ' + needle)
        return {'path': str(p), 'needle': needle, 'lines': found}
    clauses = [
        evidence(ROOT / 'Base_11.10.2.cc', 'this->parent->AddChild(shared_from_this());'),
        evidence(OLD / 'official/Collision_11.10.2.cc', 'this->placeable = false;'),
        evidence(OLD / 'inputs/ODEMultiRayShape_11.10.2.cc', 'odeCollision.reset(new ODECollision'),
        evidence(OLD / 'official/ODERayShape_11.10.2.cc', 'collision->SetCollision(this->geomId, false);'),
        evidence(LINK / 'ODELink.cc', 'if (g->IsPlaceable() && g->GetCollisionId())'),
        evidence(LINK / 'ODELink.cc', 'dGeomSetBody('),
        evidence(LINK / 'ODELink.cc', 'localPose.Pos() -= cogVec;'),
        evidence(LINK / 'ODELink.cc', 'myPose.Rot().RotateVector(this->inertial->CoG())'),
        evidence(LINK / 'ODELink.cc', 'self->dirtyPose.Pos() -= cog;'),
        evidence(ROOT / 'ODEBoxShape_11.10.2.hh', 'dCreateBox(0, _size.X(), _size.Y(), _size.Z())'),
        evidence(ROOT / 'ode_collision_kernel_11.10.2.cpp', 'void dxGeom::computePosr()'),
        evidence(ROOT / 'ode_collision_kernel_11.10.2.cpp', 'int dCollide ('),
        evidence(ROOT / 'ode_ray_11.10.2.cpp', 'void dGeomRaySet ('),
        evidence(ROOT / 'ode_ray_11.10.2.cpp', 'int dCollideRayBox ('),
    ]
    report = {
        'schema': 'mr3-v21-native-box-transform-static-review-v1',
        'review_completed': True,
        'scope': 'Source-only causal audit; no additional ray stream reads, no native getter invocation, build, ROS/DDS, simulator or Git/canonical mutation.',
        'frozen_native_source': '099a8eeaa00676f7e6e00d7f5ef51294aac5edcb',
        'source_bindings': bindings,
        'source_evidence': clauses,
        'findings': {
            'ray_dummy_not_link_child_by_normal_construction': 'Base constructor stores parent but AddChild occurs only in Base::Load. ODEMultiRayShape::AddRay constructs dummy ODECollision, ODERayShape, SetShape and SetPoints; it does not call dummy Load. MultiRayShape::AddRay is empty. Neither constructor calls Load.',
            'ray_body_attachment_double_transform_not_supported_by_source': 'Collision initializes placeable=false; ODERayShape explicitly SetCollision(geomId,false). Both ODELink Init and UpdateCollisionOffsets gate on IsPlaceable. Therefore even hypothetical child membership does not attach these rays through the reviewed link path.',
            'ray_cached_and_native_set_arguments': 'ODERayShape::Update obtains cached globalStart/globalEnd from parent Link::WorldPose, normalizes their difference, and passes cached start/direction to dGeomRaySet. ODE dGeomRaySet directly assigns final_posr position and direction; it does not apply an additional body/world transform. Actual runtime dGeomGetBody and dGeomRayGet have not been captured.',
            'base_geometry_transform': 'Dynamic box geom is attached to link ODE body. ODELink body position is link world position + R*CoG; geom local offset is collision RelativePose position - CoG; ODE computePosr composes body + R*offset. At a common consistent state these cancel CoG. ODELink MoveCallback subtracts R*CoG before publishing dirty link pose.',
            'actual_declared_waffle_offsets': {'link_inertial_pose': [-0.064, 0, 0.048, 0, 0, 0], 'base_collision_pose': [-0.064, 0, 0.048, 0, 0, 0], 'expected_native_geom_body_local_offset': [0, 0, 0], 'box_lengths': [0.265, 0.265, 0.089], 'inertial_rotation': 'identity; UpdateMass rotates inertia via MOI, does not add an inertial quaternion to body orientation'},
            'box_expansion_not_found': 'ODEBoxShape forwards exact requested XYZ to dCreateBox/dGeomBoxSetLengths. BoxShape scaling explicitly updates size by scale ratio. ODE stores those side lengths; ray-box uses half side lengths without contact surface layer/ERP/CFM inflation. This is a source-path statement, not actual native length readback.',
            'public_collision_pose_is_not_native_geom_readback': 'Collision::WorldPose lazily recomposes InitialRelativePose + link WorldPose. World UpdatePhysics and later dirty-pose propagation take separate physics-mutex critical sections. MultiRay Update updates cached rays before UpdateRays acquires that mutex. Current callback getters are not an atomic record of original collision checks.',
            'observed_discrepancy_not_explained': 'Previously selected tb1 scan6 beam286 cached hit z .12887599538110692 versus callback public-box upper extent about .10075 is real scope mismatch in observed fields. No reviewed fixed offset, inertial rotation or box inflation explains it; its cause is not established.'
        },
        'minimal_existing_public_readback_apis': {
            'collision': ['boost::dynamic_pointer_cast<physics::ODECollision>', 'GetCollisionId()', 'dGeomGetClass', 'dGeomGetBody', 'dGeomCopyPosition/dGeomGetPosition', 'dGeomGetQuaternion', 'dGeomGetAABB', 'dGeomIsOffset', 'dGeomCopyOffsetPosition/dGeomGetOffsetPosition', 'dGeomGetOffsetQuaternion', 'dGeomBoxGetLengths only when dBoxClass'],
            'body': ['ODELink::GetODEId()', 'dBodyGetPosition', 'dBodyGetQuaternion', 'dBodyIsEnabled'],
            'ray': ['boost::dynamic_pointer_cast<physics::ODERayShape>', 'ODEGeomId()', 'dGeomGetClass', 'dGeomGetBody', 'dGeomRayGet', 'dGeomRayGetLength'],
            'scope_limit': 'GetPosition/GetQuaternion/AABB may recompute ODE derived pose/AABB caches, but do not invoke collision casting or physics stepping. Capture primitive copies under the existing physics mutex and format JSON after releasing it. A callback-time readback still cannot recover original cast-time pose.'
        },
        'conditional_fix_candidates_only': [
            'If actual native ray differs from cached input, investigate true body attachment/other native ray writes; do not assume this based on current source.',
            'If native box pose/size differs from public geometry, isolate initialization/body-offset/pose propagation or effective-shape discrepancies with actual native readback.',
            'If only cast-versus-pose phase mismatch is demonstrated, a prospective engine fix would require one consistent transform/collision critical section; merely adding a callback lock cannot repair the earlier cast. No such patch is implemented or claimed necessary here.'
        ],
        'not_proved': ['unique root cause', 'original cast-time native geom pose', 'physical correctness or PASS', 'sensor placement repair', 'legitimate hits should be filtered'],
        'lookup_failures_preserved_as_notes': ['Official ODEBoxShape.cc URL returned 404; class is implemented in ODEBoxShape.hh, which was retrieved and equals installed header. /usr/include/ode absent; installed bundled ODE headers are under /usr/include/gazebo-11/gazebo/ode. An initial unrelated burger-model lookup is excluded from actual-model conclusions.'],
        'execution': {'argv': sys.argv, 'executable': sys.executable, 'cwd': str(pathlib.Path.cwd()), 'wall_seconds': time.monotonic() - started},
    }
    for row in bindings:
        if stat(pathlib.Path(row['path'])) != row['stat_after']:
            raise RuntimeError('source changed before sealing: ' + row['path'])
    out = ROOT / 'review_v1.json'
    with out.open('x') as f:
        json.dump(report, f, indent=2)
        f.write('\n')
    print(json.dumps({'output': str(out), 'sha256': hashlib.sha256(out.read_bytes()).hexdigest(), 'source_bindings': len(bindings), 'review_completed': True}))


if __name__ == '__main__':
    main()
