"""Read-only AST/source binding check; never execute an episode auditor."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/home/zhuyulab/ns3-workspace')
WIRELESS = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
ASSETS = WIRELESS / 'report/assets'
NEW = ASSETS / '20261017_mr3_p2a0_v15/independent'
OLD = ASSETS / '20261017_mr3_p2a0_v8/independent'
PROPOSAL = Path('/tmp/mr3_p2a0_v15_stop_fixture_v4_proposal/assets/20261017_mr3_p2a0_v15/independent')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def literal_assignments(tree):
    values = {}
    for node in tree.body:
        if (isinstance(node, ast.Assign) and len(node.targets) == 1
                and isinstance(node.targets[0], ast.Name)):
            try:
                value = eval(compile(ast.Expression(node.value), '<static-assignment>', 'eval'),
                             {'__builtins__': {}}, values)
            except (NameError, TypeError, AttributeError):
                continue
            values[node.targets[0].id] = value
    return values


class NormalizeWrapper(ast.NodeTransformer):
    def __init__(self, physical):
        self.physical = physical
        self.changed = []

    def visit_Constant(self, node):
        replacements = {'mr3-p2a0-outward-cancel-v4': 'mr3-p2a0-outward-cancel-v3'}
        if self.physical:
            replacements.update({
                'missing/ambiguous v4 reset transitions': 'missing/ambiguous v3 reset transitions',
                'incomplete v4 reset transitions': 'incomplete v3 reset transitions',
                'v4 reset requires one actual reset and32 nonterminal steps ending external truncation':
                'v3 reset requires one actual reset and32 nonterminal steps ending external truncation',
                'predeclared v4 probe reset-only eight-episode/32-step aggregate: all raw speed/chord/angular '
                'and strict closures, no eligible observed stop violation, one meaningful A/B '
                'sampled stop per robot across this matrix; original per-episode missing is retained; '
                'terminal/deadline excluded, activity gate separate, no continuous dynamics proof':
                'predeclared v3 probe reset-only eight-episode/32-step aggregate: all raw speed/chord/angular '
                'and strict closures, no eligible observed stop violation, one meaningful A/B '
                'sampled stop per robot across this matrix; original per-episode missing is retained; '
                'terminal/deadline excluded, activity gate separate, no continuous dynamics proof'})
        if node.value in replacements if isinstance(node.value, str) else False:
            self.changed.append(node.value)
            node.value = replacements[node.value]
        return node


def main():
    paths = [NEW / 'mr3_independent_angular_reset_matrix_v15.py',
             NEW / 'mr3_independent_physics_matrix_v15.py',
             NEW / 'mr3_p2a0_v15_audit_stage.py', WIRELESS / 'mr3_learning/audit_ppo.py',
             WIRELESS / 'MR3_ENV_CONTRACT.md']
    raw = {str(path): path.read_bytes() for path in paths}
    before = {path: sha(payload) for path, payload in raw.items()}
    rows = []
    for stem, expected_old, fixed_source, fixed_sha in (
            ('angular_reset_matrix', '83f1cabcebda11d431f30e4a752bf87534864f344f7c48755015fbd401f6fee4',
             ASSETS / '20261017_mr3_p2a0_v4/independent/mr3_independent_angular_interface_v1.py',
             '7a472ba7efdd55addc710b98c66c89feff7f5092f214f76fd76cd4ca526343d0'),
            ('physics_matrix', 'b89403fdec92e81fab52ea4eae3ffd6dd35f4674132128b7c3f4cacbd5b70d5d',
             ASSETS / '20261017_mr3_p2a0_v3/independent/mr3_independent_physics_review.py',
             '2516e394f60eac5dd24fd66b51c4c48fc37245090eb1626ebe1c7a3a23f8bafb')):
        physical = stem == 'physics_matrix'
        old_path = OLD / ('mr3_independent_' + stem + '_v8.py')
        new_path = NEW / ('mr3_independent_' + stem + '_v15.py')
        old_raw, new_raw = old_path.read_bytes(), raw[str(new_path)]
        assert sha(old_raw) == expected_old
        assert new_raw == (PROPOSAL / new_path.name).read_bytes()
        assert sha(fixed_source.read_bytes()) == fixed_sha
        old_tree, new_tree = ast.parse(old_raw), ast.parse(new_raw)
        old_doc, new_doc = ast.get_docstring(old_tree), ast.get_docstring(new_tree)
        assert old_doc.replace('v8 workload adapter: v3/32', 'v15 workload adapter: v4/32') == new_doc
        assert isinstance(old_tree.body[0], ast.Expr) and isinstance(new_tree.body[0], ast.Expr)
        old_tree.body.pop(0)
        new_tree.body.pop(0)
        normalizer = NormalizeWrapper(physical)
        normalized = normalizer.visit(copy.deepcopy(new_tree))
        assert len(normalizer.changed) == (5 if physical else 1)
        assert ast.dump(normalized) == ast.dump(old_tree)
        assert next(n.value.value for n in new_tree.body
                    if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name)
                    and n.targets[0].id == 'CONSUMER_SHA256') == fixed_sha
        rows.append({'canonical_path': str(new_path), 'sha256': sha(new_raw),
                     'old_path': str(old_path), 'old_sha256': sha(old_raw),
                     'whole_AST_equals_old_after_exact_version_doc_message_normalization': True,
                     'allowed_normalized_literals': normalizer.changed,
                     'actual_promoted_bytes_equal_handoff_proposal': True,
                     'fixed_consumer': {'path': str(fixed_source), 'sha256': fixed_sha},
                     'source_hash_uses_actual___file___unchanged': True,
                     'eligibility': 'exact v4/32 only; v3 now ineligible; eight EP and 33 records retained',
                     'unchanged_scope': 'Every old raw/fullbody/chord/source gap/strict closure/meaningful '
                                        'A-or-B response-pool/angular numerical gate retained. '
                                        'Activity remains an independent required gate; not substituted.'})

    stage_tree = ast.parse(raw[str(NEW / 'mr3_p2a0_v15_audit_stage.py')])
    stage_paths = {}
    for node in ast.walk(stage_tree):
        if (isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
                and node.func.id == 'standard' and len(node.args) >= 2
                and isinstance(node.args[0], ast.Constant)
                and node.args[0].value in ('angular_matrix_v1', 'physics_matrix_v1')):
            stage_paths[node.args[0].value] = str(eval(
                compile(ast.Expression(node.args[1]), '<static-stage-path>', 'eval'),
                {'__builtins__': {}}, {'ASSETS': ASSETS}))
    assert stage_paths == {
        'angular_matrix_v1': str(NEW / 'mr3_independent_angular_reset_matrix_v15.py'),
        'physics_matrix_v1': str(NEW / 'mr3_independent_physics_matrix_v15.py')}

    audit_path = WIRELESS / 'mr3_learning/audit_ppo.py'
    relative = audit_path.relative_to(ROOT).as_posix()
    old_raw = subprocess.check_output(['git', 'show', 'f7376d0:' + relative], cwd=ROOT)
    old_tree, new_tree = ast.parse(old_raw), ast.parse(raw[str(audit_path)])
    replacement = {
        '3b6fb71f2c90a055ef3bb922bd3f08332eb366d8becde577106d1ed5bd56cedd':
        'f595fd1e999a5cbe9d0f33db549d7aba0af615703b589ef14ff2538a871e380c',
        '2e95bf8a76b9216088d10e1ad1125b3d341e55144e2452cde852a869c4b7cf36':
        '4285b8d3ec5b28c4944b04e03258e1955b491d7d635e7edd4e57751c979028f9'}
    normalized = copy.deepcopy(new_tree)
    modified = []
    for node in ast.walk(normalized):
        if isinstance(node, ast.Constant) and isinstance(node.value, str) and node.value in replacement:
            modified.append(node.value)
            node.value = replacement[node.value]
    assert sorted(modified) == sorted(replacement)
    assert ast.dump(normalized) == ast.dump(old_tree)
    constants = literal_assignments(new_tree)
    groups = ('EVALUATOR_PHASE_PINS', 'PREPARATION_RUNTIME_PINS', 'EXECUTION_CONFIG_PINS')
    pins = {path: expected for group in groups for path, expected in constants[group].items()}
    assert len(pins) == sum(len(constants[group]) for group in groups) == 36
    proofs = []
    for path, expected in pins.items():
        actual = sha((ROOT / path).read_bytes())
        assert actual == expected, path
        proofs.append({'path': path, 'expected': expected, 'actual': actual})
    assert constants['ENV_DOCUMENT_SHA256'] == before[str(WIRELESS / 'MR3_ENV_CONTRACT.md')]
    after = {str(path): sha(path.read_bytes()) for path in paths}
    assert before == after
    report = {'schema': 'mr3-v15-wrappers-pins-independent-review-v1', 'passed': True,
              'wrappers': rows, 'audit_stage_reset_paths': stage_paths,
              'audit_ppo': {'path': str(audit_path), 'sha256': before[str(audit_path)],
                            'old_freeze': 'f7376d0', 'old_sha256': sha(old_raw),
                            'exactly_two_digest_literal_changes': modified,
                            'whole_AST_equal_after_only_these_two_replacements': True,
                            'pin_groups': {group: len(constants[group]) for group in groups},
                            'current_36_source_pin_bindings': proofs,
                            'ENV_sha256': constants['ENV_DOCUMENT_SHA256']},
              'source_before': before, 'source_after': after,
              'scope': 'Read-only AST, exact-byte and current SHA checks only. No wrapper audit '
                       'or formal consumer invoked, no author 17 tests repeated, no ROS/native/control '
                       'and no Git writes. These checks give no new native safety/task credit.'}
    output = Path('/tmp/mr3_p2a0_v15_wrappers_pins_independent_review_v1.json')
    with output.open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'passed': True, 'wrappers': len(rows), 'current_pins': len(pins),
                      'output': str(output), 'sha256': sha(output.read_bytes())}))


if __name__ == '__main__':
    main()
