"""Bounded read-only live facts; never a formal native PASS or control client."""
import datetime
import hashlib
import json
from pathlib import Path
import time

RUN = Path('/home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261017_v11_interface')
LAUNCH = Path('/tmp/mr3_p2a0_v11_interface_launch.json')
OUT = Path('/tmp/mr3_p2a0_v11_interface_phase_monitor_v1.jsonl')
FREEZE = 'ba018fe3122c478836eb4e5da9c14306cd832c1b'


def read_json(path):
    try:
        return json.loads(path.read_bytes())
    except (OSError, ValueError) as error:
        return {'observer_unavailable': str(error)}


def rows(path, head=False, maximum=512 * 1024):
    try:
        size = path.stat().st_size
        with path.open('rb') as stream:
            start = 0 if head else max(0, size - maximum)
            stream.seek(start)
            raw = stream.read(maximum)
        lines = raw.splitlines()
        if start and lines:
            lines = lines[1:]
        result = []
        for line in lines:
            try:
                result.append(json.loads(line))
            except ValueError:
                continue
        return result
    except OSError:
        return []


def identity(saved):
    if not saved:
        return None
    try:
        raw = Path('/proc/' + str(saved['pid']) + '/stat').read_text()
        values = raw[raw.rfind(')') + 2:].split()
        actual = {'pid': saved['pid'], 'start_ticks': int(values[19]), 'state': values[0]}
        return {**actual, 'same_identity': actual['start_ticks'] == saved['start_ticks']}
    except (OSError, ValueError, KeyError):
        return {'pid': saved.get('pid'), 'same_identity': False, 'absent_or_unreadable': True}


def compact_control(row):
    result = {key: row[key] for key in ['kind', 'component', 'worker_clock_ns',
              'worker_physical_ns', 'wall_monotonic_ns'] if key in row}
    value = row.get('ack', row.get('request', row.get('status', {})))
    result['payload'] = {key: value[key] for key in ['operation', 'request_id', 'ok', 'error',
                         'clock_ns', 'target_time_ns', 'phase_kind', 'ready'] if key in value}
    if isinstance(value.get('status'), dict):
        result['status'] = {key: value['status'].get(key) for key in
                            ['clock_ns', 'phase_kind', 'ready', 'decision_sequences']}
    return result


def observe():
    launch = read_json(LAUNCH)
    snapshot = {'schema': 'mr3-v11-readonly-live-facts-v1', 'freeze': FREEZE,
                'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'wall_monotonic_ns': time.monotonic_ns(), 'launch_status': launch.get('status'),
                'launch_returncode': launch.get('returncode'),
                'parent': identity(launch.get('benchmark_parent')),
                'scope': 'Live observations only; no PASS, completed audits or physical credit',
                'episodes': []}
    for episode in sorted(RUN.glob('worker*/episode*')):
        if not episode.is_dir():
            continue
        metadata = read_json(episode / 'metadata.json')
        item = {'directory': str(episode), 'epoch': metadata.get('epoch'),
                'files': {name: (episode / name).stat().st_size for name in
                    ['control_phase_worker.jsonl', 'transitions.jsonl', 'physics.jsonl',
                     'peer_phase.jsonl', 'information_states.jsonl', 'motion_safety.jsonl']
                    if (episode / name).is_file()}}
        transition = rows(episode / 'transitions.jsonl')
        first = rows(episode / 'transitions.jsonl', head=True, maximum=1024 * 1024)
        item['reset_recorded'] = bool(first and first[0].get('kind') == 'reset')
        if transition:
            final = transition[-1]
            item['last_transition'] = {key: final.get(key) for key in
                                      ['kind', 'sequence', 'action', 'terminated', 'truncated']}
            item['last_snapshot_sequence'] = final.get('snapshot', {}).get('sequence')
        controls = rows(episode / 'control_phase_worker.jsonl')
        item['last_control_records'] = [compact_control(row) for row in controls[-4:]]
        prefix = rows(episode / 'control_phase_worker.jsonl', head=True, maximum=1024 * 1024)
        commits = [row for row in prefix if row.get('kind') == 'ack_consumed'
                   and row.get('component') == 'motion' and row.get('ack', {}).get('ok') is True
                   and row.get('ack', {}).get('operation') == 'commit']
        if commits:
            item['first_motion_commit_actual_receipt'] = compact_control(commits[0])
        physical = rows(episode / 'physics.jsonl')
        if physical:
            item['last_physics'] = physical[-1]
        for name in ['infrastructure_failure.json', 'infrastructure_cleanup.json',
                     'failed_sample.json', 'native_stop.json', 'nav2_shutdown.json', 'summary.json']:
            if (episode / name).exists():
                item[name] = read_json(episode / name)
        log = episode / 'worker.log'
        if log.exists():
            text = log.read_text(errors='replace')
            item['worker_log_bytes'] = len(text.encode())
            item['worker_log_tail'] = text.splitlines()[-4:]
        snapshot['episodes'].append(item)
    return snapshot


with OUT.open('x', buffering=1) as output:
    for index in range(45):
        value = observe()
        output.write(json.dumps(value, sort_keys=True) + '\n')
        print(json.dumps(value, sort_keys=True), flush=True)
        if value['launch_status'] in ('completed', 'failed'):
            break
        time.sleep(35.)
