原始动作掩码下的取消刺激 family：仅设计审阅

建议将该路线作为独立的 mr3-p2a-reach-masked-cancel-v1 / mr3-reach-reset-masked-cancel-v1；本目录没有实现、CPU、World 或资格运行。其含义是“在原始掩码与预声明生命周期机会中，按声明路径排序的外部取消刺激”，不是安全路径承诺，也不是旧 outward family 的等价别名。

源码边界已核：benchmark.py:336 的 _probe_nonapproaching_goal_action 自注是 external straight-direction filter，计算初始目标方向与各 peer 的点积，只筛刺激输入，不证明完整轨迹。它用于 benchmark 的旧刺激分支，也在 reach_probe_v3_replay.py:69/173 被独立重放。故不能说它从未进入验收：它确是 V3 版本的 workload 一致性门；它不是原 Reach 数学分离、角界、物理 A/B、contact 或 strict95 判据。新 family 要明确改变刺激输入域并重新取得资格，不能删过滤后继续借 V3 reader/profile 的标签。

新选择集合应来自实际收到的原 per_robot_action_mask 与完整 joint_action_mask True，并保留两轮固定生命周期机会（首次未发送、idle/unowned/fresh/valid、第二轮真实 handoff 等）。保持 actor 的所有 mask 位不变；外部 fixture 的生命周期子集不代表覆盖了 actor 的全部动作。只删除额外 nonapproach 方向筛选，不增加新的角度、距离或银行范围。原 _action_masks 在 mr3_observation.py:745 起仅用 candidate.valid/reachable 决定 GOAL，再做目标冲突 joint 检查，并未要求路径严格大于零。真实有限非负0路径可正常参与排序；mask=True 却 path 缺失/非有限/负值，应报告输入契约失败，不能用 or0、修改 mask 或悄悄退回 KEEP 来取得有效信用。

建议固定排序：(-GOAL数,-所选GOAL最小声明path,-第二轮reverse数,-sum所选path,action)。无GOAL时最小值/总和使用明确的排序中性值0，绝不表示缺失路径为零。最小路径放在总路径前，避免总和很长却仍牺牲某一机器的短目标。第二轮 reverse 只是沿用原输入软鼓励，不影响资格集合，也不证明实际反向转动。它有助于原 interface angular gate 所需正/负及至少一机双向 span 的刺激，但该原门仍须实际满足。更简备选可去掉 reverse 项；代价是更少的转向覆盖意图。Root 原例中的 outward margin 也可作更后的软 tie，但我倾向删掉它以保持新 family 中性、减少不必要几何项。须先固定一个 rank，再写实现与独立 reader，不做阈值搜索。

现有派生证据不能认证更长的三 GOAL joint 已存在。V70 保存了全27个原合法且 nonapproach 的 joint，三 GOAL 只有621；它没有保存所有被方向筛选拒绝的原 joint 位集。V68 的 per-robot mask/path 与方向过滤量化来自不同 freeze，同样不能代替缺失 joint membership。不能用候选坐标或重新计算的假想 mask 补造原 bitset 认证。新 family 是否能选择更长且同时合法的目标、是否被 Nav2 接受、能否在原5秒承诺后仍移动，以及 peer/Reach 是否拒动，均待实际新资格；长声明 path 本身也不保证目标存活。

当前公开 benchmark CLI 没有 --outward-goals，输出 metadata 也没有 outward_goals 字段。现有 outward_goals 是 legacy Python 参数；--preparation-motion-probe 的帮助文本仍写 prefer outward legal goals。应将这个通用 help 中性化，并用新固定 token、新 state key 及明确的 goal_filter=original_per_robot_and_joint_masks_only_v1 / goal_rank=固定所选rank 标记真实刺激。不可新增一个假的 outward=True。旧 outward/v3 入口、诊断字段和历史 FAIL 保持原义。

两个原 V17 angular/physics reset matrix 只按 PROBE_VERSION、preparation_motion_probe、schedule、freeze 等检查 workload 声明，未调用 nonapproach，也未要求 outward_goals 字段。最小登记可沿现有 loader：只对新 family 唯一 PROBE_VERSION 字面做明确投影，完整逆投影逐字恢复原源码，leaf SHA 与全部数学/物理谓词不变。原嵌套报告的历史 v6 scope 字符串应标明是原 reader 的历史标签；外层明确新 family，不得冒称它是 outward 方向证明。单独改 token 仍不够：必须有新的独立 masked selector/rank/完整生命周期重放，与原科学读者合取；旧 V3 reader 仍须拒绝新 family。

最小实施/准入顺序：

1. Root 固定 family/rank/字段契约后，producer 仅增加显式固定 family，继续 task0..1.5 初始窗口、真实 accepted<=2、moving WAIT<=10、第二 GOAL13..20、accepted<=20、WAIT<=28，32步/两轮六GOAL、baseline 一次、三 fresh rest 与3秒 handoff、.08/.05/5秒承诺不变。V4 延一拍原型不混入本 family。可复用 private shared-core 结构，但新分支不能更改旧 V3 的 JSON/异常；旧 V2 字面保持。

2. 独立 reader 不导入 producer 作 oracle，逐 previousSnapshot→实际 command→postSnapshot 重建新集合、rank、baseline、WAIT/cancel/rest 与完整 persisted state。新增明确 profile/source binding；公开 full、reset angular/physics、preparation qualification 强制 interface1+reset8 共9EP真实重放，再与原12EP/30role合取。terminal/deadline、authority/encoder/runtime/input/peer/contact/closure/质量/strict95 门全部保留。

3. 人工 CPU 应包括：max-min 与 sum 排序冲突、原 joint/per-mask=False 永不选、朝 peer 但原 mask=True 可被列入、真实0与缺失路径区别、第二 reverse 仅 tie、真实 GoalDispatcher 的32步两轮正例及自然终态/晚接受/提前WAIT/缺handoff负例、公开 reader 缺/假 proof 拒绝。用实际原 mask helper 生成合成观测。新源码对旧 G720 实际 V3 函数重新逐调用比较全部返回、canonical JSON 和异常；29P/527旧私有证明只作历史/夹具依据。

4. Supervisor/worker、benchmark metadata、plan/profile/immutable reader readiness、完整 filesystem source/test union、每个声明测试都有实际 case 的 CPU 准备一并完成。Supervisor 新字节若进入 current21 build gate，执行新的有界真实 build/source before-after，不能借旧行政 pin 或假称 Python 编入 ELF。随后才声明新 scope/freeze/预算并做完整新资格。可能出现真实 Reach 拒动、覆盖不足、物理或接触失败，必须原样 FAIL。capacity 继续False，未实测前不自动进入 pilot/final。

本次仅12份源码与既有派生 JSON 的静态审阅；未读原两输入、旧 raw/pstats/342库，未运行测试/reader/native，也未改 canonical。
