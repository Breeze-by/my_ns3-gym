
### 2026-10-17 MR3-P2A.0 V12 native（结果草稿，reset审计未完成）

freeze `6b1b4a0108351f5bfb70ec0c96ba895248d4f7a8`；source preflight100 runtime/76independent，原actual binary/four macro proof按其原receipt。按预声明依次执行三次benchmark（精确实际argv如下；启动环境及launcher/source/planSHA见各`/tmp/mr3_p2a0_v12_{stage}_launch.json`，正式审计完整命令与退出/输出SHA见`*_audit_execution_v1.json`）：

```bash
/home/zhuyulab/miniconda3/envs/ns3gym/bin/python -u -m mr3_learning.benchmark --workers 1 --schedule open:101 --steps 32 --preparation-motion-probe --preparation-probe-version mr3-p2a0-outward-cancel-v3 --base-domain 130 --base-port 13201 --output-root /home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0 --run-id mr3_p2a0_20261017_v12_interface --preparation-parameter-review
```

```bash
/home/zhuyulab/miniconda3/envs/ns3gym/bin/python -u -m mr3_learning.benchmark --workers 1 --schedule open:101,open:101 --steps 4 --terminal-probe --base-domain 132 --base-port 13211 --output-root /home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0 --run-id mr3_p2a0_20261017_v12_terminal
```

```bash
/home/zhuyulab/miniconda3/envs/ns3gym/bin/python -u -m mr3_learning.benchmark --workers 2 --schedule open:101,open:101,rooms:101,corridors:101 --steps 32 --preparation-motion-probe --preparation-probe-version mr3-p2a0-outward-cancel-v3 --base-domain 134 --base-port 13221 --output-root /home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0 --run-id mr3_p2a0_20261017_v12_reset
```

interface32steps与terminal2×4step API全部mandatory PASS。reset2workers×4schedule×32step完成并CLI0，整体版本FAIL：w0/e2 tb2仅0.0032782531368285074m活动；w0/e3 tb2真实fullplanar0.3058281617710947>.30；w1/e2与e3 tb1驱动alpha真Fraction向内门正式拒绝。三项归因独立，旧FAIL/原物理界/原driver数学均保留。reset其它正式reader尚在运行，结果待补；deadline SKIP，无同freeze盲重试。

实际一次性计费307reset+step API（11reset+296step）、295真正下发joint command、294.02有效/返回物理任务秒；helper推进294.538秒（含release前.338及cleanup.180），原启动free-run不混该helper量。launcher原生墙秒4414.7895641284995；benchmark elapsed4413.4765489515848只是同一成本另一视图，不能相加或再加wrapper样本。八轮reset native_stop0/真实Nav2finalized，各saved identity动态并集349fresh全gone为关闭子事实。完整accounting源码原件SHA在`/tmp/mr3_p2a0_v12_report_accounting_draft_v1.json`。

失败后被动corridor CDR诊断为额外非预声明负载，仅/tmp保存完整原件/初失败/修正与范围：5850+5556实收、6161去重gzip；没有控制publisher/SetParameters，无法补旧w0/e2内部原件或证明每包GID/接收延迟。参见`passive_nav2_custody_manifest_v1.json`、`observer_corrections_v1.json`、`timestamp_scope_v1.json`。原计划、所有运行/审计FAIL、观察器错误及修正分别保留；不得用新的working-consumer/source修复重标旧freeze。

PPO/GPU/optimizer均0，pilot2226/11494.045260453597已用、1870/2905.954739546403余额原样；不降95%/参与/物理门，不授冻结策略或本版完整矩阵PASS。正式reset/skip/canonical证据待收齐再定稿。
