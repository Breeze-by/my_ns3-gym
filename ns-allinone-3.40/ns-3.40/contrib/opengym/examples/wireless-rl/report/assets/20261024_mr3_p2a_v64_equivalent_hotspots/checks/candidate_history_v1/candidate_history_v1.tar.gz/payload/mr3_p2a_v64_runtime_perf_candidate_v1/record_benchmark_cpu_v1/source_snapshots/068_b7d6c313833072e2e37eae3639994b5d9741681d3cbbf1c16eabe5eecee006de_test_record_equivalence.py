import ast
import copy
import io
import json
import math
from pathlib import Path
from types import SimpleNamespace
import pytest

A=Path(__file__).parent

def method(filename):
    tree=ast.parse((A/filename).read_text())
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='MotionSafety')
    record=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='record')
    namespace=dict(json=json,math=math,time=SimpleNamespace(monotonic_ns=lambda:1234567))
    exec(compile(ast.Module(body=[record],type_ignores=[]),str(A/filename),'exec'),namespace)
    return namespace['record']

original=method('original_motion_safety.py')
candidate=method('motion_safety.py')

def run(function,payload,enabled=True,now=12.5):
    audit=io.StringIO() if enabled else None
    owner=SimpleNamespace(audit=audit,epoch='finite-encoding-eq',record_sequence=3,now=lambda:now)
    try:
        function(owner,'test',payload)
        result=('ok',)
    except Exception as error:
        result=(type(error).__name__, None if isinstance(error,RecursionError) else str(error))
    return result,owner.record_sequence,None if audit is None else audit.getvalue()

@pytest.mark.parametrize('payload',[
    None,True,False,0,-1,0.,-0.,1.25,'中文\n\\nan',[],{},
    [1,True,None,'x',{'nested':(1.,2.,-0.)}],
    {'nan':math.nan,'positive':math.inf,'negative':-math.inf,'nested':[math.nan,{'x':math.inf}]},
    {1:'int',False:'bool',None:'null'},
    {math.nan:'nonfinite key'},
    object(),{'first':object(),'later':math.nan},{'first':math.nan,'later':object()},
    10**4400,
])
def test_record_wire_bytes_and_errors_match(payload):
    assert run(original,payload)==run(candidate,payload)

def test_none_audit_and_nonfinite_metadata_still_match():
    for payload in [object(),[math.nan],{'x':-0.}]:
        assert run(original,payload,False)==run(candidate,payload,False)
        assert run(original,payload,True,math.nan)==run(candidate,payload,True,math.nan)

def test_shared_alias_circular_and_input_immutability():
    shared=[1.,2.]; payload={'a':shared,'b':shared,'nested':(math.nan,)}
    assert run(original,payload)==run(candidate,payload)
    assert payload['a'] is payload['b'] and math.isnan(payload['nested'][0])
    circular=[];circular.append(circular)
    assert run(original,circular)==run(candidate,circular)
