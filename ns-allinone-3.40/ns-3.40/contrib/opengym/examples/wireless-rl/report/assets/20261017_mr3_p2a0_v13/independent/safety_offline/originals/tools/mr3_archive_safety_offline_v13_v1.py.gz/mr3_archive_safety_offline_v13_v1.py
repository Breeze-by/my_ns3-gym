"""Losslessly archive stopped Safety CPU originals; never copy native payloads."""

import gzip
import hashlib
import json
from pathlib import Path
import sys


REPOSITORY = Path('/home/zhuyulab/ns3-workspace')
DESTINATION = REPOSITORY / (
    'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/'
    '20261017_mr3_p2a0_v13/independent/safety_offline')
DIRECTORIES = [Path('/tmp') / f'mr3_velocity_bound_proposal_v{version}'
               for version in range(1, 6)] + [
    Path('/tmp/mr3_velocity_bound_ros_fixtures_v1'),
    Path('/tmp/mr3_p2a0_v13_safety_apply_v1')]
STANDALONE = [Path('/tmp') / name for name in (
    'mr3_p2a0_v13_ros_semantic_full_v1.json',
    'mr3_p2a0_v13_ros_semantic_full_v1.log',
    'mr3_p2a0_v13_ros_semantic_full_v1.log.gz',
    'mr3_p2a0_v13_paired_numeric_independent_review_v1.py',
    'mr3_p2a0_v13_paired_numeric_independent_review_v1.json',
    'mr3_p2a0_v13_navigation_profile_independent_review_v1.json')]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def stat(path):
    value = path.stat()
    return {'size': value.st_size, 'mtime_ns': value.st_mtime_ns,
            'inode': value.st_ino, 'device': value.st_dev}


def main():
    DESTINATION.mkdir(parents=True, exist_ok=False)
    originals = DESTINATION / 'originals'
    originals.mkdir()
    sources = []
    excluded = []
    for directory in DIRECTORIES:
        assert directory.is_dir() and not directory.is_symlink(), directory
        for path in sorted(directory.rglob('*')):
            if path.is_symlink():
                excluded.append({'source': str(path), 'reason': 'symbolic link'})
            elif path.is_file():
                sources.append((path, Path(directory.name) / path.relative_to(directory)))
    sources.extend((path, Path('standalone') / path.name) for path in STANDALONE)
    sources.append((Path(__file__).resolve(), Path('tools') / Path(__file__).name))
    entries = []
    for path, relative in sources:
        assert path.is_absolute() and path.is_file() and not path.is_symlink(), path
        if ('__pycache__' in path.parts or path.suffix in ('.pyc', '.so', '.o', '.a')):
            excluded.append({'source': str(path), 'reason': 'compiled binary/cache'})
            continue
        initial_stat = stat(path)
        raw = path.read_bytes()
        if raw.startswith(b'\x7fELF'):
            excluded.append({'source': str(path), 'reason': 'ELF compiled binary'})
            continue
        target = originals / (str(relative) + '.gz')
        target.parent.mkdir(parents=True, exist_ok=True)
        encoded = gzip.compress(raw, mtime=0)
        with target.open('xb') as stream:
            stream.write(encoded)
        actual = target.read_bytes()
        decoded = gzip.decompress(actual)
        later_raw = path.read_bytes()
        final_stat = stat(path)
        assert actual == encoded and decoded == raw and later_raw == raw, path
        assert initial_stat == final_stat, path
        item = {
            'source': str(path),
            'selected': str(target.relative_to(DESTINATION)),
            'compression': 'gzip',
            'raw_bytes': len(raw), 'encoded_bytes': len(actual),
            'raw_sha256': sha(raw), 'encoded_sha256': sha(actual),
            'decoded_sha256': sha(decoded),
            'source_before_sha256': sha(raw), 'source_after_sha256': sha(later_raw),
            'source_stat_before': initial_stat, 'source_stat_after': final_stat,
            'source_stable': True,
        }
        if path.suffix == '.gz':
            # The outer archive encoding preserves this already-compressed
            # original byte-for-byte; retain its inner decoded-content digest too.
            item['source_was_already_gzip'] = True
            item['source_gzip_decoded_sha256'] = sha(gzip.decompress(raw))
        entries.append(item)
    # Recheck every selected source after all copying, not just each local read.
    for entry in entries:
        source = Path(entry['source'])
        target = DESTINATION / entry['selected']
        assert sha(source.read_bytes()) == entry['source_after_sha256']
        assert stat(source) == entry['source_stat_after']
        assert sha(target.read_bytes()) == entry['encoded_sha256']
        assert sha(gzip.decompress(target.read_bytes())) == entry['decoded_sha256']
    manifest = {
        'schema': 'mr3-offline-originals-manifest-v1', 'passed': True,
        'scope': 'Stopped Safety prospective V13 CPU proposals, corrections, '
                 'actual-source unit checks and independent reviews only. '
                 'V12 canonical native/formal archives are untouched.',
        'archive_argv': list(sys.argv),
        'archive_command': 'rtk proxy env PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 '
                           '/tmp/mr3_archive_safety_offline_v13_v1.py',
        'archive_cwd': str(REPOSITORY),
        'counts': {'originals': len(entries),
                   'raw_bytes': sum(entry['raw_bytes'] for entry in entries),
                   'encoded_bytes': sum(entry['encoded_bytes'] for entry in entries),
                   'explicit_discovered_exclusions': len(excluded)},
        'verification': 'Every archive encoded file and decoded original matched SHA256 '
                        'and byte comparison, and every /tmp original SHA/stat stayed '
                        'stable across initial read, local copy and whole-copy end.',
        'encoding_note': 'All originals use one deterministic outer gzip layer. An '
                         'already-gzip original therefore has .gz.gz and an additional '
                         'source_gzip_decoded_sha256; its original encoded bytes remain exact.',
        'deduplication_key_for_other_archivers': 'entries[].source absolute original path',
        'exclusions': excluded,
        'deliberate_external_exclusions': [
            {'source': '/tmp/mr3_paired_wheel_numeric_proposal_v1',
             'reason': 'Coordinator-owned numeric proposal/source/checks archive is separate; '
                       'only this agent independent review is copied. CPU probe.so is excluded.'},
            {'source': '/tmp/mr3_p2a0_v13_navigation_profile_draft_v1',
             'reason': 'Candidate-owned profile draft/checks archive is separate; '
                       'only this agent independent review is copied.'},
            {'source': '/tmp/mr3_p2a0_v13_local_control_sources_v1',
             'reason': 'Candidate-owned primary-source evidence is separate.'},
            {'source': '/tmp/mr3_p2a0_v12_*',
             'reason': 'Already archived V12 diagnostics/native/formal originals are untouched; '
                       'only preserved offline proposal fixtures already inside listed '
                       'versioned directories are copied.'},
            {'source': 'CPU ELF/shared/static/object binaries, __pycache__, symlink views',
             'reason': 'Not canonical Safety offline originals; retain exact commands/results '
                       'and source hashes instead.'}],
        'entries': entries,
    }
    output = DESTINATION / 'manifest.json'
    output.write_text(json.dumps(manifest, sort_keys=True, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'destination': str(DESTINATION), 'counts': manifest['counts'],
                      'manifest_sha256': sha(output.read_bytes())}, sort_keys=True))


if __name__ == '__main__':
    main()
