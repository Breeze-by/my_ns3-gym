"""Preserve closed V20 receipts/analysis, including original auxiliary failures."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
TARGET = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v20_sensor/closed_core_v1'
assert not TARGET.exists()
started = time.monotonic()
names = [
    'source_preflight_v1.json', 'parent_v2.log', 'lifecycle_v1.jsonl',
    'execution_v1.json', 'recorder_config_v1.json', 'recorder_ready_v1.json',
    'recorder_stop_v1.json', 'recorder_console_v1.log', 'benchmark_console_v1.log',
    'original_physical_review_v1.json', 'original_physical4_console_v1.log',
    'launch_error_lines_v1.log', 'readonly_closed_identities_v1.json',
    'readonly_lifecycle_observations_v1.jsonl', 'pack_closed_v1.py',
    'prepare_custody_v1.py', 'run_closed_custody_v1.py',
    'run_custody_checks_v1.py', 'custody_tests_v1.py',
    'custody_checks_v1.json', 'custody_mechanical_proof_v1.json',
    'custody_mechanical_v1.patch', 'custody_fixture01.log',
    'custody_fatal_style01.log', 'closed_custody_handoff_v1.json',
    'closed_custody_execution_v1.json', 'custody_native_execution_v1.stdout.log',
    'custody_sensor_capture_execution_v1.stdout.log',
    'closed_small_review_v1.py', 'closed_small_review_v1.json',
    'closed_small_review_execution_v1.json', 'closed_small_review_execution_v1.stdout',
    'closed_small_review_execution_v1.stderr', 'promote_closed_bytes_v1.py',
    'promote_closed_bytes_v2.py', 'promote_initial_failure_v1.json',
]
files = [Path('/tmp') / ('mr3_p2a0_v20_sensor_' + name) for name in names]
files.extend(p for p in sorted(Path('/tmp/mr3_p2a0_v20_sensor_live_witness').rglob('*')) if p.is_file())
handoff = Path('/tmp/mr3_p2a0_v20_scan_analysis_handoff_v1.json')
analysis = json.loads(handoff.read_text())
assert analysis.get('writers') == 'STOP', analysis.get('writers')
rows = analysis['archive_files']
assert isinstance(rows, list)
files.append(handoff)
for row in rows:
    assert isinstance(row, dict), row
    path = Path(row['source'])
    assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
    files.append(path)
files.append(Path(__file__))
files = sorted(set(files))
entries = []
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for path in files:
        before = path.stat()
        raw = path.read_bytes()
        assert len(raw) < 100000000
        name = str(path.relative_to('/tmp'))
        info = tarfile.TarInfo(name)
        info.size, info.mtime, info.mode = len(raw), 0, 0o644
        archive.addfile(info, io.BytesIO(raw))
        entries.append({'source': str(path), 'member': name, 'bytes': len(raw),
                        'sha256': hashlib.sha256(raw).hexdigest(),
                        'stat': [before.st_dev, before.st_ino, before.st_size,
                                 before.st_mtime_ns, before.st_ctime_ns]})
encoded = gzip.compress(buffer.getvalue(), compresslevel=6, mtime=0)
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(encoded))) as archive:
    assert archive.getnames() == [row['member'] for row in entries]
    for row in entries:
        raw = archive.extractfile(row['member']).read()
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
        path = Path(row['source'])
        value = path.stat()
        assert [value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns] == row['stat']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
TARGET.mkdir()
(TARGET / 'originals.tar.gz').write_bytes(encoded)
result = {'schema': 'mr3-v20-closed-core-custody-v1',
          'freeze': 'b33ff70084be6419edc3d0d91a26d6db3936ff45',
          'scope': 'Original closure, CPU/custody and descriptive analysis; no gate regrading. Time-parameter semantic interpretation is corrected separately.',
          'archive': 'originals.tar.gz', 'archive_bytes': len(encoded),
          'archive_sha256': hashlib.sha256(encoded).hexdigest(),
          'original_count': len(entries), 'original_bytes': sum(row['bytes'] for row in entries),
          'files': entries, 'full_roundtrip_and_source_final_sha_stat_verified': True,
          'wall_seconds': time.monotonic() - started}
(TARGET / 'manifest_v1.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('original_count', 'original_bytes', 'archive_bytes', 'archive_sha256', 'wall_seconds')}))
