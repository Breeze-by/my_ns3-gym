# 固定三角色 CPU 分解候选（仅 /tmp，未准入 native）

目的：先定位真实 31–32 wall秒/task秒主要消耗在哪里，再选等价优化。唯一后继诊断拟为 **open101 / 1 worker / 1 EP / 8 steps / 0 learning**；不是新qualification、capacity PASS、pilot或final。当前没有生产接线、ROS/World/profile执行或费用承诺。原E源码未动，最终scope/完整parent预算/新source freeze由root在V60真实关闭后另封。

`fixed_process_profile_v1.py` 只认识 motion_safety、adapter、worker 三角色及固定程序/source路径和SHA；`fixed_process_profile_entry_v1.py` 以真实模块名导入它，使线程hook和main共享同一进程内capture。CLI只从固定program路径推断角色，不能指定任意目标、prefix或spec。worker只接受该owned episode的原run-dir；节点只接受固定node remap与原实际params文件。输出仅为固定owned episode/profiles/role的新独占目录。open101/worker1/steps8由source-bound固定诊断launcher及真实benchmark argv/metadata约束，不再增加动态argv授权sidecar。

## 为什么不直接用 `python -m cProfile`

本机 `/usr/lib/python3.10/cProfile.py` CLI经 `profile.py::_Utils.runctx` 捕获并忽略SystemExit。因此目标脚本 `sys.exit(7)` 可能被CLI变成0，不能直接用作真实rc可信prefix。候选改用 `cProfile.Profile.runcall(runpy.run_path, ..., run_name='__main__')`，保留原sys.argv与SystemExit/BaseException传播，finally才dump。普通dump异常记为缺失/失败profile，不能覆盖目标的异常/退出码。没有新signal handler；默认SIGTERM/强制退出可能不执行finally、没有pstats，这必须作为partial保留，不能声称完整profile。

## 固定五份 pstats 与实际覆盖

| 真实进程 | lane | 现有源码中的线程位置 |
|---|---|---|
| motion_safety | main | `main` 的SingleThreadedExecutor.spin，主要Python callbacks在同线程 |
| adapter | main | rclpy.spin主线程 |
| adapter | encoder | ThreadPoolExecutor(max_workers=1)中原encode_snapshot调用 |
| worker | main | worker IPC/reset/step/normal-close主线程 |
| worker | ros_spin | 已有mr3_worker_ros线程中executor.spin |

每lane有独立Profile和pstats，固定lane只能由对应同一线程使用。adapter encoder不能靠main prefix自动覆盖，worker ROS callbacks也不属于main。两个线程入口需要最小显式hook：原executor提交的**同一函数/同一args/kwargs**外包 `profiled_call('encoder', ...)`；原worker spin线程的**同一executor.spin**外包 `profiled_call('ros_spin', ...)`。hook不改返回/异常、参数、线程数、调度目标或数学，但profiling会增加耗时。main正常关闭须等原线程结束；未观察或仍active的lane不能报告profile完整。

各进程记录真实/proc pid/parent/group/session/start_ticks、原cmdline与原program argv、console/source SHA及literal-lstat/resolved-target稳定字段、monotonic区间、process CPU与各lane thread CPU。params随机路径不预知：只接受完整canonical、无symlink的regular输入，完整SHA/bytes与只读快照保存（每份≤1MiB、最多4份）；配置由已有实际参数readback核验，不能把路径猜测当配置证明。pstats默认时钟含callee阻塞等待；各线程/进程cumulative重叠，不能相加当parent wall。C扩展内部、DDS内部线程、Nav2和Gazebo/ODE不由这五份Python pstats细分，必须明确UNKNOWN。

## 接线边界：prefix可复用，但不能假装没有hook

现有ROS `Node`最终委托ExecuteProcess；本机launch/descriptions/executable.py在prepare时把 `shlex.split(prefix)` 加到原cmd之前。因此优先在source-bound诊断worker的既有ros2 launch argv里加入固定 `--launch-prefix='/usr/bin/python3 <frozen_entry_path>'` 和 `--launch-prefix-filter='^(motion_safety|mr3_adapter)$'`；prefix只包两个Python console，不能包Nav2/Gazebo。entry从原完整program路径推断固定角色。worker则在Supervisor原bash source环境后，把原 `/usr/bin/python3 worker.py --run-dir ...` 换成同解释器+固定entry+原完整program argv；保留exec、环境、cwd和session ownership。最终ROS argv构造须先做真实launch API的CPU检查，不能盲猜CLI参数位置。

ROS参数dict会生成随机 `/tmp/launch_params_*`。这不需要额外动态argv授权框架，也不需要把参数改写为fixed-YAML；wrapper如实保存actualargv和实际regular参数文件完整快照，后继已有参数readback与固定source/launcher约束合取即可。早期要求这些动态路径预先Git逐字固定是本草稿自行增加的不必要限制，已删除；`pre_simplification_v1/`保留该未执行旧稿，不给CPU或native信用。

最小待实现接线面：Supervisor固定worker prefix；worker的固定ros2 launch prefix/filter并包ros_spin；adapter只包encoder函数。仅此诊断source投影必须保存old E原源、明确有限diff、逐AST/源码逆投影与实际加载路径；thread hooks改变相应source SHA时，wrapper内固定pin也要在新freeze前明确更新并CPU验证。没有hook就不能声称已覆盖两个线程，当前也不能称为ROS-ready。无需增加任意prefix接口或改主launch参数生成逻辑。

## 一次有界诊断草案

复用现有 `benchmark`、Supervisor真实owned process/normal close、`reach_execution --scope engineering` 与source recovery；保留当前20/34ms、所有原RPC/启动时限和first-fault，不为了profile增加其timeout或改行为。只一个新独占run/open101/8step，无PPO/model/optimizer；选择现有合法固定外部动作路线，明示是诊断激励、不是policy容量样本。

前瞻资源草案可为完整parent1800秒，其中native合作式allocation1500（含原close120）及其后metadata/pstats/实际关闭尾300。它是待root核实际工程余额后另封的建议，不是已批准/已花费用或硬杀保证。当前未profiled32步open的startup约135–139秒、8秒推进若恰好保持原短前缀率约250秒只是规划参考；profiling扰动/超限仍可能partial，不能据此保证8step完成。固定最多5份pstats，每份64MiB上限；完整SHA和解析成本连同真实parent wait收费，不按top40命中行计输入。

只在所有真实进程reap、保存身份fresh-gone、源码前后稳定后，才有限读这5份owned pstats与summary/RPC metadata，输出各自top40 self/cumulative/callcount与coverage。非main lane还要求真实Thread.is_alive()==False才可报告完整；source stat只比dev/ino/mode/size/mtime_ns/ctime_ns，不断言atime。任何缺失/解析/超限都保留partial与真实rc，不补造profile。

8step profile之后，先依据实际主耗时选择恒等优化与全字段/独立oracle CPU；随后仍须证明native推进和**完整audit/finalizer**两侧真实容量。当前capacity未过，原9000余额/95%/科学门保持，后继driver不能自动解锁pilot/final。容量复核见 `/tmp/mr3_p2a_v60_policy_capacity_source_review_v1/README.md`。

## 当前验证边界

core唯一人工CPU已完成：tool14748真实reap rc0，3/3 group PASS、14个真实toy child wait、3.086367216秒；67源before/after/current/recovery一致，JUnit/actualargv已核，2coordinator/pytest+14toy共16个保存start身份fresh-gone。覆盖真实SystemExit/异常/auxdump失败/SIGTERM不吞、3main+2thread pstats分离、固定role/source/program及worker argv/node remap/params缺失与symlink拒绝。没有ROS/World/raw或容量信用。原wait/source snapshots/JUnit/toy receipts与严格验证见artificial_cpu_v1、artificial_cpu_source_recovery_v1.json、artificial_cpu_verified_v1.json。

后继固定接线候选另存 `integration_v1/`，core的bef68fb6...073e7/11286B保持不动。其独立小AST/人工函数hook三项于tool57708真实reap rc0，1.139958058秒；72源稳定可恢复、2保存CPU身份fresh-gone。它验证两固定source投影的whole-byte inverse/方法范围、adapter args/kwargs/return/异常与恢复、worker thread/prefix/main形状；不重复core14toy、不导入执行生产ROS模块，不算实际ROS launch或native成功。详见该目录README与static_cpu_verified_v1.json。
