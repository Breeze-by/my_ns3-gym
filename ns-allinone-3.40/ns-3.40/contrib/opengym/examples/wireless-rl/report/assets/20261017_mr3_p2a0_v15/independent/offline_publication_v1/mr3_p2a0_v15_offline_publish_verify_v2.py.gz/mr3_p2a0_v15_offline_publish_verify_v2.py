import pathlib,json,hashlib,gzip,collections,importlib.util,time
root=pathlib.Path("/home/zhuyulab/ns3-workspace");base=root/"ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v15"
path=base/"independent/offline_originals_v1/manifest.json"
helper=pathlib.Path("/tmp/mr3_p2a0_v15_archive_offline_originals_v1.py")
sha=lambda b:hashlib.sha256(b).hexdigest()
start=time.monotonic(); captured=path.read_bytes();m=json.loads(captured)
spec=importlib.util.spec_from_file_location("v15_custody_verifier_helper",helper);h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
for r in m["entries"]:
 encoded=(root/r["selected"]).read_bytes();decoded=gzip.decompress(encoded)
 assert r["encoding"]=="gzip"
 assert len(encoded)==r["encoded_bytes"] and sha(encoded)==r["encoded_sha256"]
 assert len(decoded)==r["decoded_bytes"]==r["raw_bytes"] and sha(decoded)==r["decoded_sha256"]==r["raw_sha256"]
 raw,stat=h.capture(pathlib.Path(r["source"]))
 assert raw==decoded and stat==r["source_stat_before"]==r["source_stat_after"]
 assert not raw.startswith(b"\x7fELF")
for r in m["deduplicated_prior"]:
 raw,stat=h.capture(pathlib.Path(r["source"]));assert len(raw)==r["raw_bytes"] and sha(raw)==r["raw_sha256"] and stat==r["source_stat"]
 old=r["already_canonical"];encoded=pathlib.Path(old["selected"]).read_bytes();assert sha(encoded)==old["selected_encoded_sha256"]
 assert h.decoded_original(old,encoded)[1]==raw
assert path.read_bytes()==captured
plan=base/"predeclared_plan_v15.json";assert sha(plan.read_bytes())=="fc52f0e5a632ba8114a68da73f2ee048408a3f795609351469f446a88ab68804"
result={"passed":True,"scope":"Postpublish byte/codec/source-stat custody verification only; no native/formal/optimizer/admission credit.","manifest":str(path),"manifest_sha256":sha(captured),"counts":m["counts"],"all_new_and_prior_reference_bytes_verified":True,"plan_sha256":sha(plan.read_bytes()),"plan_unchanged":True,"exclusion_reason_counts":dict(collections.Counter(r["reason"] for r in m["exclusions"])),"old_manifest_count":len(m["old_manifests"]),"selected_file_count_including_manifest":len(m["entries"])+1,"wall_seconds":time.monotonic()-start,"source":str(pathlib.Path(__file__)),"source_sha256":sha(pathlib.Path(__file__).read_bytes())}
out=pathlib.Path("/tmp/mr3_p2a0_v15_offline_publish_verification_v2.json")
with out.open("x") as stream:json.dump(result,stream,indent=2);stream.write("\n")
print(json.dumps(result,indent=2));print("VERIFICATION_SHA256",sha(out.read_bytes()))
