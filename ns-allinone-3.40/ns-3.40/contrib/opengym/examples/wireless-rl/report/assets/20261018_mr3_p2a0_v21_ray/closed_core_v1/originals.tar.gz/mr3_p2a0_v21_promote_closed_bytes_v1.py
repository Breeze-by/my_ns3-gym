"""Copy sealed closed V21 evidence; no regrading or source mutation."""
import hashlib
import json
from pathlib import Path
import shutil
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
SOURCE = Path('/tmp/mr3_p2a0_v21_ray_selected_v1')
TARGET = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v21_ray'
started = time.monotonic()
handoff = SOURCE / 'custody_handoff_v1.json'
assert hashlib.sha256(handoff.read_bytes()).hexdigest() == '299200db81c14f0f85210251acdd01becf76be5a4d03f50443899f81517ec5cc'
d = json.loads(handoff.read_text())
assert d['passed'] and d['source_writers_stopped'] and d['no_native_or_formal_rerun']
assert d['freeze'] == '099a8eeaa00676f7e6e00d7f5ef51294aac5edcb'
files = sorted(p for p in SOURCE.rglob('*') if p.is_file())
assert len(files) == 205 and sum(p.stat().st_size for p in files) == 57836611
rows = []
for source in files:
    assert not source.is_symlink()
    destination = TARGET / source.relative_to(SOURCE)
    assert not destination.exists(), destination
    before = source.stat()
    raw = source.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    assert hashlib.sha256(destination.read_bytes()).hexdigest() == digest
    after = source.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    rows.append({'source': str(source), 'canonical': str(destination.relative_to(ROOT)), 'bytes': len(raw), 'sha256': digest})
result = {'schema': 'mr3-v21-closed-canonical-copy-v1', 'passed': True,
          'freeze': d['freeze'], 'scope': 'Exact sealed byte copy only; original physical FAIL and e61c SKIP retained.',
          'files': rows, 'file_count': len(rows), 'total_bytes': sum(x['bytes'] for x in rows),
          'wall_seconds': time.monotonic() - started}
(TARGET / 'closed_canonical_copy_v1.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('passed', 'file_count', 'total_bytes', 'wall_seconds')}))
