#include "mr3_ray_box_collision.hpp"
#include <nlohmann/json.hpp>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <limits>
#include <random>
#include <string>
#include <vector>

using Json = nlohmann::json;
namespace rb = multi_robot::ray_box;

struct Oracle
{
  bool hit = false;
  long double depth = 0;
  int axis = 0;
};

// Independent, unmirrored finite segment / slab reference.
Oracle Reference(const rb::Input &in)
{
  long double lo = -std::numeric_limits<long double>::infinity();
  long double hi = std::numeric_limits<long double>::infinity();
  int enter = 0, leave = 0;
  for (int i = 0; i < 3; ++i)
  {
    const long double p = in.start[i], v = in.direction[i];
    const long double h = static_cast<long double>(in.lengths[i]) / 2;
    if (v == 0)
    {
      if (p < -h || p > h)
        return {};
      continue;
    }
    long double a = (-h - p) / v, b = (h - p) / v;
    if (a > b) std::swap(a, b);
    if (a > lo) { lo = a; enter = i; }
    if (b < hi) { hi = b; leave = i; }
    if (lo > hi) return {};
  }
  const bool entering = lo >= 0;
  const long double depth = entering ? lo : hi;
  if (depth < 0 || depth > in.max_length) return {};
  return {true, depth, entering ? enter : leave};
}

struct Case
{
  std::string name;
  std::array<double, 3> origin;
  std::array<double, 3> direction;
  double length = 9.88;
  std::array<double, 3> rpy{0, 0, 0};
  std::array<double, 3> center{0, 0, 0};
  bool reversed = false;
};

struct Pair
{
  dGeomID ray, box;
  explicit Pair(const Case &c, dSpaceID space = nullptr)
  {
    box = dCreateBox(space, .265, .265, .089);
    dMatrix3 rot;
    dRFromEulerAngles(rot, c.rpy[0], c.rpy[1], c.rpy[2]);
    dGeomSetRotation(box, rot);
    dGeomSetPosition(box, c.center[0], c.center[1], c.center[2]);
    ray = dCreateRay(space, c.length);
    dVector3 o, v, p{c.origin[0], c.origin[1], c.origin[2], 0};
    dVector3 direction{c.direction[0], c.direction[1], c.direction[2], 0};
    dMultiply0_331(o, rot, p);
    dMultiply0_331(v, rot, direction);
    dGeomRaySet(ray, o[0] + c.center[0], o[1] + c.center[1],
      o[2] + c.center[2], v[0], v[1], v[2]);
  }
  ~Pair() { dGeomDestroy(ray); dGeomDestroy(box); }
};

Json Evaluate(const Case &c)
{
  Pair pair(c);
  const auto input = rb::ReadInput(pair.ray, pair.box);
  const auto oracle = Reference(input);
  dContactGeom contact{};
  const int n = c.reversed ? dCollide(pair.box, pair.ray, 1, &contact,
    sizeof(contact)) : dCollide(pair.ray, pair.box, 1, &contact, sizeof(contact));
  const bool hit = n > 0;
  bool correct = hit == oracle.hit;
  Json row{{"name", c.name}, {"reversed", c.reversed},
    {"hit", hit}, {"oracle_hit", oracle.hit},
    {"local_start", input.start}, {"local_direction", input.direction},
    {"finite_length", input.max_length}};
  if (hit)
  {
    const double expected = static_cast<double>(oracle.depth);
    const double tolerance = 2e-12 * std::max(1., std::abs(expected));
    correct = correct && std::abs(contact.depth - expected) <= tolerance;
    correct = correct && contact.depth >= 0 && contact.depth <= input.max_length;
    correct = correct && contact.g1 == (c.reversed ? pair.box : pair.ray);
    correct = correct && contact.g2 == (c.reversed ? pair.ray : pair.box);
    row["depth"] = contact.depth;
    row["oracle_depth"] = oracle.hit ? Json(expected) : Json(nullptr);
    row["contact_position"] = {contact.pos[0], contact.pos[1], contact.pos[2]};
    row["normal"] = {contact.normal[0], contact.normal[1], contact.normal[2]};
    if (oracle.hit)
    {
      const double sign = (input.direction[oracle.axis] < 0 ? 1. : -1.) *
        (c.reversed ? -1. : 1.);
      for (int i = 0; i < 3; ++i)
      {
        correct = correct && std::abs(contact.normal[i] -
          input.box_rotation[i * 4 + oracle.axis] * sign) <= 1e-12;
        const long double point = input.start[i] + oracle.depth *
          input.direction[i];
        correct = correct && std::abs(point) <=
          static_cast<long double>(input.lengths[i]) / 2 + 1e-12L;
      }
    }
  }
  row["agrees_with_reference_including_depth_normal_ids"] = correct;
  return row;
}

struct BroadResult { int callbacks = 0; int contacts = 0; };
void BroadCallback(void *data, dGeomID a, dGeomID b)
{
  auto &result = *static_cast<BroadResult *>(data);
  ++result.callbacks;
  dContactGeom contact{};
  result.contacts += dCollide(a, b, 1, &contact, sizeof(contact));
}

Json BroadphaseProbe()
{
  const Case c{"rotated_AABB_overlap_outside_Z", {.034385, -.114968, .073},
    {.286565, -.958061, -1e-9}, 9.88, {0, .009, 0}};
  const auto space = dSimpleSpaceCreate(nullptr);
  BroadResult result;
  Json out;
  {
    Pair pair(c, space);
    const auto expected = Reference(rb::ReadInput(pair.ray, pair.box));
    dSpaceCollide(space, &result, &BroadCallback);
    out = {{"callbacks", result.callbacks}, {"contacts", result.contacts},
      {"oracle_hit", expected.hit}};
  }
  dSpaceDestroy(space);
  return out;
}

int main()
{
  if (!dInitODE2(0) || !dAllocateODEDataForThread(dAllocateMaskAll)) return 2;
  std::vector<Case> cases = {
    {"outside_Z_exact_parallel", {0, -.12, .073}, {0, -1, 0}},
    {"outside_Z_tiny_toward", {0, -.12, .073}, {0, -1, -1e-9}},
    {"outside_Z_tiny_away", {0, -.12, .073}, {0, -1, 1e-9}},
    {"outside_Z_larger_toward", {0, -.12, .073}, {0, -1, -1.01e-6}},
    {"below_Z_tiny_toward", {0, -.12, -.073}, {0, -1, 1e-9}},
    {"real_tiny_entry_correct_depth", {-.2, 0, .0445 + 1e-10}, {1, 0, -1e-9}, 1},
    {"real_tiny_entry_short_segment_miss", {-.2, 0, .0445 + 1e-10}, {1, 0, -1e-9}, .09},
    {"real_tiny_entry_from_inside_XY", {0, 0, .0445 + 1e-10}, {0, -1, -1e-9}},
    {"inside_exit", {0, 0, 0}, {1, 0, 0}},
    {"boundary_enter_zero", {-.1325, 0, 0}, {1, 0, 0}, 0},
    {"boundary_exit_zero", {.1325, 0, 0}, {1, 0, 0}, 0},
    {"length_endpoint", {-.2, 0, 0}, {1, 0, 0}, .0675},
    {"short_before_endpoint", {-.2, 0, 0}, {1, 0, 0}, .0674},
    {"grazing_exact_edge", {-.2, .1325, .0445}, {1, 0, 0}, 1},
    {"near_subnormal_outside", {0, -.12, .073}, {0, -1, -1e-310}},
    {"opposite_below", {0, 0, -.0445 - 1e-10}, {0, -1, 1e-9}, 1}
  };
  auto rotated = cases[5];
  rotated.name = "rotated_translated_true_grazing";
  rotated.rpy = {.21, -.37, .73}; rotated.center = {1.5, -2.1, .8};
  cases.push_back(rotated);
  rotated = cases[1]; rotated.name = "rotated_translated_false_old_hit";
  rotated.rpy = {.21, -.37, .73}; rotated.center = {1.5, -2.1, .8};
  cases.push_back(rotated);
  const auto initialSize = cases.size();
  for (std::size_t i = 0; i < initialSize; ++i)
  { auto c = cases[i]; c.name += "_reverse"; c.reversed = true; cases.push_back(c); }
  Json original = Json::array(), corrected = Json::array();
  for (const auto &c : cases) original.push_back(Evaluate(c));
  const auto broadOld = BroadphaseProbe();
  dSetColliderOverride(dRayClass, dBoxClass, &rb::CorrectRayBox);
  bool passed = true;
  for (const auto &c : cases)
  {
    auto row = Evaluate(c);
    passed = passed && row["agrees_with_reference_including_depth_normal_ids"].get<bool>();
    corrected.push_back(row);
  }
  const auto broadNew = BroadphaseProbe();
  passed = passed && broadOld["callbacks"].get<int>() > 0 &&
    broadOld["contacts"].get<int>() == 1 && broadNew["contacts"].get<int>() == 0;
  std::mt19937_64 random(0x726179626f78ULL);
  std::uniform_real_distribution<double> pose(-.6, .6), angle(-3, 3), unit(-1, 1);
  Json failures = Json::array();
  for (int i = 0; i < 512; ++i)
  {
    Case c{"deterministic_oriented_" + std::to_string(i),
      {pose(random), pose(random), pose(random)},
      {unit(random), unit(random), unit(random)}, 1.5,
      {angle(random), angle(random), angle(random)}, {2.3, -1.7, .4}, i % 2 == 0};
    if (i % 3 == 0) c.direction[2] *= 1e-9;
    auto row = Evaluate(c);
    if (!row["agrees_with_reference_including_depth_normal_ids"].get<bool>())
      failures.push_back(row);
  }
  passed = passed && failures.empty();
  std::cout << Json{{"schema", "mr3-ray-box-correction-cpu-probe-v1"},
    {"passed", passed}, {"scope", "CPU only. No Gazebo server, world or stepping; no ROS/DDS. Original library result retained separately; replacement registered once using public API."},
    {"named_cases", cases.size()}, {"deterministic_cases", 512},
    {"old_results", original}, {"corrected_results", corrected},
    {"broadphase_original", broadOld}, {"broadphase_corrected", broadNew},
    {"deterministic_failures", failures}}.dump(2) << '\n';
  dCloseODE();
  return passed ? 0 : 1;
}
