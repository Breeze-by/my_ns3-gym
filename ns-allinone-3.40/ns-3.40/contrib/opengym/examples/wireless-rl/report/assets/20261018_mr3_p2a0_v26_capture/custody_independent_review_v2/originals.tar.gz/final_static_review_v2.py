"""Narrow static diff and sealed-result reading only; does not run consumers."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import sys
import time

D = Path('/tmp/mr3_p2a0_v26_capture_consistency_independent_review_v2')
P = Path('/tmp/mr3_p2a0_v26_capture_consistency_proposal_v2')
inputs = {}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def sig(p):
    s = p.stat()
    return [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns]


def read(p):
    before = sig(p)
    raw = p.read_bytes()
    assert sig(p) == before
    inputs[str(p)] = {'sha256': sha(raw), 'bytes': len(raw), 'stat': before}
    return raw


started = time.monotonic()
handoff = json.loads(read(P / 'handoff_v2.json'))
for entry in handoff['files']:
    assert sha(read(Path(entry['path']))) == entry['sha256']
old = read(P / 'prospective_v1_7ff18.py').decode()
new = read(P / 'mr3_v26_smoother_custody_v2.py').decode()
old_sha, new_sha = sha(old.encode()), sha(new.encode())
assert old_sha == '7ff18f1a1628a24367cfeff69b65c6c5ea0177c9a6c178a6839172c1688e649e'
assert new_sha == 'ac90b7f896592a5a08430ee859ad73332a4e0cd3292e53e20ada310179841c30'
new_block = """                if after is None:
                    result['pending_reason'] = 'same process naturally closed during capture; no credit'
                    continue
                checks = attempt['checks']
                checks['pid_start_same'] = pair(after) == pair(identity)
                require(checks['pid_start_same'], 'smoother PID reused during capture')
                if after['state'] == 'Z':
"""
old_block = """                if after is None or (pair(after) == pair(identity) and after['state'] == 'Z'):
"""
assert new.count(new_block) == 1
inverse = new.replace(new_block, old_block)
late = """                checks = attempt['checks']
                checks['pid_start_same'] = pair(after) == pair(identity)
                require(checks['pid_start_same'], 'smoother PID reused during capture')
"""
needle = '                after_lines = map_lines(maps_after, core)\n'
assert inverse.count(needle) == 1
inverse = inverse.replace(needle, late + needle)
assert inverse == old
old_audit = read(Path('/tmp/mr3_p2a0_v25_smoother_custody_proposal_v3/'
                      'audit_ppo.proposed_v25.py')).decode()
new_audit = read(P / 'audit_ppo.proposed_v26.py').decode()
new_path = ('report/assets/20261018_mr3_p2a0_v26_capture/independent/'
            'mr3_v26_smoother_custody_v2.py')
old_path = ('report/assets/20261018_mr3_p2a0_v25_smoother/independent/'
            'mr3_v25_smoother_custody_v1.py')
audit_inverse = new_audit.replace(new_path, old_path).replace(
    new_sha, '6edeb3a7e814fb024594be724ef98dce39e1d23a84af5d34d6d6faac0b5cb88b')
assert audit_inverse == old_audit
assert sha(old_audit.encode()) == '7d1a1a70761115b2582d7c08315e42cce97ddacdae067e066fa1e5487853294d'
old_tree, new_tree = ast.parse(old), ast.parse(new)
functions = lambda s: {n.name: ast.get_source_segment(s, n) for n in ast.parse(s).body
                       if isinstance(n, ast.FunctionDef)}
a, b = functions(old), functions(new)
assert set(a) == set(b)
assert [k for k in a if a[k] != b[k]] == ['observe']
nonfunctions = lambda t: [ast.dump(n, include_attributes=False) for n in t.body
                           if not isinstance(n, ast.FunctionDef)]
assert nonfunctions(old_tree) == nonfunctions(new_tree)
green = json.loads(read(D / 'reuse_z_missing_exe_v2.json'))
author = json.loads(read(P / 'counterexamples_result_v2.json'))
assert green['facts']['proof']['errors'] == ['smoother PID reused during capture']
assert green['facts']['proof']['episodes'][0]['attempts'][0]['checks']['pid_start_same'] is False
assert author['passed'] is True and author['case_count'] == 1
result = {
    'schema': 'mr3-v26-capture-consistency-independent-final-review-v2',
    'verdict': 'no_identified_blocker_for_exact_promotion_and_fresh_preflight',
    'reviewed_module_sha256': new_sha,
    'v2_to_v1_whole_byte_inverse': True,
    'v2_only_changed_function': 'observe',
    'v2_other_function_bytes_and_module_AST_identical': True,
    'auditor_sha256': sha(new_audit.encode()),
    'auditor_fixed_module_path_and_sha_only_inverse_to_7d1': True,
    'independent_single_case': {
        'scope': 'Exact same reuse-Z/missing-exe case on v2; no original9/21 rerun.',
        'path': str(D / 'reuse_z_missing_exe_v2.json'),
        'sha256': inputs[str(D / 'reuse_z_missing_exe_v2.json')]['sha256'],
        'result': 'hard rejection with named pid_start_same=False before after proc reads'},
    'preserved_v1_red': '/tmp/mr3_p2a0_v26_capture_consistency_independent_review_v1/handoff_v1.json',
    'author_new_case_read_not_rerun': {
        'case_count': author['case_count'], 'direct_observe_calls': author['direct_observe_calls'],
        'passed': author['passed'], 'scope': handoff['single_case_result']['compared']},
    'conclusions': [
        'Relevant fixed core rows are validated before and after; unrelated VMA changes are descriptive, with both raw snapshots retained.',
        'Already observed reuse is hard before any later file disappearance can classify pending. Same-identity closure gives no proof credit.',
        'Known ancestor closure remains pending/no credit; reuse, unexplained lineage, core/argv/exe/hash errors remain hard.',
        'Named conjuncts and collected facts remain saved on error; unavailable facts are not invented.',
        'ASSET intentionally stays A25: actual overlay build/source/ELF/binding are unchanged. Auditor only updates fixed module path and hash.',
        'Original source/runtime resolution/build verification and old numerical task gates remain unchanged.',
        'Native035 cause remains unknown; V25 original FAIL is retained. No retrospective or assembled matrix PASS.'],
    'limits': 'Static review plus one isolated new fakeproc case. No formal consumer CLI, old9/21 suite, ROS/DDS/SDK/native, canonical/source/bin or Git write.',
    'source_diff': ''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True))),
    'input_bindings': inputs, 'argv': sys.argv,
    'script_sha256': sha(Path(__file__).read_bytes()),
    'wall_seconds': time.monotonic() - started,
}
for name, proof in inputs.items():
    path = Path(name)
    assert sig(path) == proof['stat'] and sha(path.read_bytes()) == proof['sha256']
result['input_end_sha_stat_stable'] = True
with (D / 'source_review_v2.json').open('x') as stream:
    json.dump(result, stream, indent=2, ensure_ascii=False, allow_nan=False)
    stream.write('\n')
print(json.dumps({'verdict': result['verdict'], 'source_sha256': new_sha,
                  'report_sha256': sha((D / 'source_review_v2.json').read_bytes()),
                  'input_count': len(inputs)}))
