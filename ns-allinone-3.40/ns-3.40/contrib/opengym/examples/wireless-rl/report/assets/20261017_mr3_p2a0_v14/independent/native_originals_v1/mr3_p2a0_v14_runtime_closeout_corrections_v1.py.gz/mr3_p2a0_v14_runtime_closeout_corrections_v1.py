"""Correct evidence interpretation; original native/formal/static bytes stay intact."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path('/home/zhuyulab/ns3-workspace')
TEMP = Path('/tmp')
PREFIX = 'mr3_p2a0_v14'
FROZEN = 'aa16d6541ef54a9c676e78367ba8a8b13c2589b9'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    inputs = {}

    def read(path):
        raw = path.read_bytes()
        inputs[str(path)] = sha(raw)
        return json.loads(raw)

    spec = importlib.util.spec_from_file_location('closed_v14', TEMP / (
        PREFIX + '_archive_closed_v1.py'))
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    plan = helper.load_context()
    outcomes = helper.validate_final_states(plan, 'stopped', 'interface')
    absence = helper.closed_identities(outcomes)
    run = Path(outcomes[0]['run_directory'])
    summary = read(run / 'benchmark_summary.json')
    shutdown = read(next(run.glob('worker*/episode*/supervisor_shutdown.json')))
    execution = read(TEMP / (PREFIX + '_interface_audit_execution_v1.json'))
    closed = (execution['all_submitted_jobs_finished'] is True
              and execution['runner_errors'] == []
              and all(type(row.get('returncode')) is int for row in execution['commands']))
    assert closed and execution['passed'] is False
    failed = [row['label'] for row in execution['commands']
              if row['required_success'] and not row['passed']]
    assert set(failed) == {'peer_review_v1', 'control_review_v1', 'fixed_physics_v1'}
    ledger_path = TEMP / (PREFIX + '_remaining_matrix_v1.jsonl')
    raw = ledger_path.read_bytes()
    inputs[str(ledger_path)] = sha(raw)
    final = json.loads(raw.splitlines()[-1])
    assert final['event'] == 'version_failed_later_stages_skip'
    assert final['error'] == "ValueError('actual audit runner did not close every required job')"
    runner = TEMP / (PREFIX + '_run_matrix_v1.py')
    runner_raw = runner.read_bytes()
    inputs[str(runner)] = sha(runner_raw)
    assert b"audit.get('passed') is True and audit.get('all_submitted_jobs_finished') is True" in (
        runner_raw)
    peer = read(TEMP / (PREFIX + '_peer_geometry_diagnostic_v1/review.json'))
    assert peer['freeze'] == FROZEN and peer['passed'] is True
    assert all(row['production20_exact_actual_recorded_hash']
               and row['production26_exact_frozen_reader_hash']
               for row in peer['three_cloud_exact_replays'])
    static = read(TEMP / (PREFIX + '_research_static_v1/review_v1.json'))
    argv = ['git', 'grep', '-n', 'COMMAND_SPEED_LIMIT', FROZEN, '--',
            'ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/',
            'ros2_ws/ros2-multi-robot-automap/scripts/',
            'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/mr3_learning/']
    rg = subprocess.run(argv, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    assert rg.returncode == 0
    grep_path = TEMP / (PREFIX + '_frozen_command_speed_consumers_v1.log')
    with grep_path.open('xb') as stream:
        stream.write(rg.stdout)
    inputs[str(grep_path)] = sha(rg.stdout)
    result = dict(
        schema='mr3-v14-closeout-interpretation-corrections-v1', freeze=FROZEN,
        original_stage_status='FAIL', later_stages='SKIPPED',
        saved_identity_absence=absence,
        actual_launcher_passed=outcomes[0]['launch']['passed'],
        formal_stage_passed=execution['passed'],
        actual_formal_jobs_finished=closed, actual_formal_command_count=len(execution['commands']),
        failed_required_commands=failed, formal_schema_mismatch_found=False,
        parent_diagnostic_correction={
            'original_error': final['error'], 'original_error_retained': True,
            'explanation': 'One combined require includes aggregate passed and every required '
                           'command success as well as job completion. Three real failed '
                           'required gates trigger its misleading close-every-job wording; '
                           'all eleven jobs actually returned. No schema/missing-job cause found.',
            'stage_fail_remains': True},
        static_semantic_correction={
            'original_static_sha256': inputs[str(TEMP / (
                PREFIX + '_research_static_v1/review_v1.json'))],
            'original_static_passed_retained': static['passed'],
            'withdrawn_inference': 'Source/function AST equality was not sufficient to claim '
                                   'unchanged peer obstacle geometry or complete runtime semantics.',
            'established_alias_cause': peer['established_cause'],
            'all_three_actual_20_and_reader_26_clouds_reproduced': True,
            'source_equality_scope': 'Literal source/AST equality remains only a byte/syntax '
                                     'fact; imported mutable command-limit alias changed its '
                                     'dependent navigation envelope. No task/actor/movement '
                                     'counterfactual or full behavior invariance is inferred.',
            'hard_body_gate_50_unchanged': True},
        frozen_consumer_search=dict(argv=argv, cwd=str(ROOT), returncode=rg.returncode,
                                    stdout=str(grep_path), stdout_sha256=sha(rg.stdout)),
        shutdown_scope=dict(worker_returncode=shutdown.get('worker_returncode'),
                            forced_shutdown=shutdown.get('forced_shutdown'),
                            failed_sample=shutdown.get('failed_sample'),
                            owned_processes=len(shutdown.get('owned_processes_seen', []))),
        benchmark_scope=dict(valid_transitions=summary['valid_transitions'],
                             sampler_wall=summary['wall_sec_including_all_attempts']),
        input_sha256=inputs,
        scope='Read-only interpretation/fresh PID absence, not rerun native/formal audits. '
              'Original positive/negative receipts and earlier static conclusions remain '
              'unchanged. Post-native V15 producer edits are not V14 source bytes.')
    assert all(sha(Path(path).read_bytes()) == digest for path, digest in inputs.items())
    path = TEMP / (PREFIX + '_runtime_closeout_corrections_v1.json')
    with path.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps(dict(saved_union=absence['saved_identities'], all_gone=True,
                          actual_jobs_finished=closed, failed_required=failed,
                          correction_sha256=sha(path.read_bytes()))))


if __name__ == '__main__':
    main()
