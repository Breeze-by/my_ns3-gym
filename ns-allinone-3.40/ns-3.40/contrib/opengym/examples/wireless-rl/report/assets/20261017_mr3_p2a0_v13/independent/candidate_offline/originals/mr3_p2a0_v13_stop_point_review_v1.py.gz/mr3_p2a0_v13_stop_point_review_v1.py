"""Read-only V12 stop measurement-point diagnosis; no actor/control or gate changes."""
from pathlib import Path
import ctypes
import hashlib
import json
import math
import statistics
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path('/home/zhuyulab/ns3-workspace')
EP = ROOT / 'ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261017_v12_reset/worker0/episode004_corridors_101'
OUT = Path('/tmp/mr3_p2a0_v13_stop_point_review_v1')
DRIVER = ROOT / 'ros2_ws/ros2-multi-robot-automap/src/multi_robot/src/mr3_gazebo_diff_drive.cpp'
EVALUATOR = ROOT / 'ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/multi_robot_exploration/task_evaluator.py'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def span(values):
    return {'min': min(values), 'max': max(values), 'mean': statistics.fmean(values)}


def euler(q):
    # Installed ignition math6/gz Quaternion::Euler normalizes its copy first.
    w, x, y, z = (q[k] for k in ('w', 'x', 'y', 'z'))
    norm = math.sqrt(w*w+x*x+y*y+z*z)
    w, x, y, z = w/norm, x/norm, y/norm, z/norm
    sarg = -2*(x*z-w*y)
    return (math.atan2(2*(y*z+w*x), w*w-x*x-y*y+z*z),
            math.asin(max(-1., min(1., sarg))),
            math.atan2(2*(x*y+w*z), w*w+x*x-y*y-z*z))


def main():
    output = OUT / 'review_v1.json'
    assert not output.exists()
    raw_path = EP / 'motion_safety.jsonl'
    raw_sha = sha(raw_path)
    libm = ctypes.CDLL('libm.so.6')
    for name in ('cosf', 'sinf'):
        function = getattr(libm, name)
        function.argtypes = [ctypes.c_float]
        function.restype = ctypes.c_float
    sources = {}
    with raw_path.open() as stream:
        for line, text in enumerate(stream, 1):
            row = json.loads(text)
            if row['kind'] != 'own_odom' or row['payload']['robot'] != 'tb1':
                continue
            msg = row['payload']['message']
            source = msg['header']['stamp']['sec']*10**9+msg['header']['stamp']['nanosec']
            if not 102_470_000_000 <= source <= 106_480_000_000:
                continue
            if source in sources:
                assert sources[source]['raw_message'] == msg
                continue
            pose = msg['pose']['pose']; twist = msg['twist']['twist']
            roll, pitch, yaw = euler(pose['orientation'])
            yf = ctypes.c_float(yaw).value
            c, s = libm.cosf(yf), libm.sinf(yf)
            factor = math.hypot(c, s)
            vx, vy = twist['linear']['x'], twist['linear']['y']
            # Inverse of the actual driver float c/s transform, not a guessed point shift.
            world = ((c*vx-s*vy)/(c*c+s*s), (s*vx+c*vy)/(c*c+s*s))
            sources[source] = {'source_ns': source, 'line': line,
                'input_sequence': row['payload']['input_sequence'], 'position': pose['position'],
                'roll_rad': roll, 'pitch_rad': pitch, 'yaw_rad': yaw,
                'yaw_float_rad': yf, 'float_rotation_norm_scale': factor,
                'body_planar_norm_mps': math.hypot(vx, vy), 'body_linear_xy': [vx, vy],
                'world_xy_velocity_reconstructed': list(world), 'angular_z': twist['angular']['z'],
                'raw_message': msg}
    assert sha(raw_path) == raw_sha
    rows = sorted(sources.values(), key=lambda r:r['source_ns'])
    assert len(rows) > 100
    edges = []
    for a, b in zip(rows, rows[1:]):
        dt = (b['source_ns']-a['source_ns'])/1e9
        dx, dy = (b['position'][k]-a['position'][k] for k in ('x', 'y'))
        edges.append({'start_ns': a['source_ns'], 'end_ns': b['source_ns'],
            'dt_sec': dt, 'chord_speed_mps': math.hypot(dx, dy)/dt,
            'chord_m': math.hypot(dx, dy),
            'mean_endpoint_reported_speed_mps': (a['body_planar_norm_mps']+b['body_planar_norm_mps'])/2,
            'observed_yaw_rate_rps': math.atan2(math.sin(b['yaw_rad']-a['yaw_rad']),
                                             math.cos(b['yaw_rad']-a['yaw_rad']))/dt})
    settled_rows = [r for r in rows if r['source_ns'] >= 103_260_000_000]
    settled_edges = [r for r in edges if r['start_ns'] >= 103_260_000_000]
    sdf = ET.fromstring((EP / 'drive_model_tb1.sdf').read_bytes()).find('model')
    links = [{'name': l.attrib['name'], 'pose': l.findtext('pose', default='0 0 0 0 0 0'),
        'inertial_pose_explicit': l.findtext('inertial/pose'),
        'mass_explicit': l.findtext('inertial/mass')}
        for l in sdf.findall('link')]
    joints = [{'name': j.attrib['name'], 'type': j.attrib['type'],
        'parent': j.findtext('parent'), 'child': j.findtext('child'),
        'pose': j.findtext('pose', default='0 0 0 0 0 0')} for j in sdf.findall('joint')]
    assert links[0]['name'] == 'base_footprint' and links[0]['pose'] == '0 0 0 0 0 0'
    model_result_path = EP / (json.loads((EP/'metadata.json').read_bytes())['epoch'] + '.json')
    model_result = json.loads(model_result_path.read_bytes())
    native_rows = [json.loads(line) for line in (EP/'drive_tb1.jsonl').read_text().splitlines()]
    actuation = [r for r in native_rows if r['kind'] == 'actuation'
                 and 102_480_000_000 <= r['sim_time_ns'] <= 106_480_000_000]
    assert actuation
    input_paths = [raw_path, EP/'drive_tb1.jsonl', EP/'drive_model_tb1.sdf', model_result_path,
        EP/'evaluator_phase_evaluator.jsonl', DRIVER, EVALUATOR,
        Path('/usr/include/gazebo-11/gazebo/physics/Model.hh'),
        Path('/usr/include/gazebo-11/gazebo/physics/Link.hh'),
        Path('/usr/include/gazebo-11/gazebo/physics/Entity.hh'),
        Path('/usr/include/ignition/math6/gz/math/Quaternion.hh')]
    result = {
        'schema': 'mr3-stop-measurement-point-forensics-v1',
        'scope': 'Read-only raw/source diagnosis. No actor/control/ROS/native run or task-gate change. OriginalV12 physicalFAIL remains. New.20 profile has not been shown to fix this.',
        'freeze': '6b1b4a0108351f5bfb70ec0c96ba895248d4f7a8',
        'epoch': model_result['episode_id'],
        'packages': subprocess.check_output(['dpkg-query', '-W', '-f=${Package} ${Version}\n',
            'gazebo', 'libgazebo-dev', 'libgazebo11']).decode().splitlines(),
        'source_contract': {
            'model_velocity': 'Gazebo11.10.2 Model::WorldLinearVel delegates to GetLink(canonical)->WorldLinearVel. Link no-arg delegates to offset zero. ODE offset implementation subtracts that link inertial CoG then calls dBodyGetRelPointVel: velocity at link-frame origin, not bareCoG.',
            'model_pose': 'Entity WorldPose is model frame pose; canonical link updates parent model pose by inverse initialRelativePose. Here first direct link base_footprint has zero initial relative pose, so declared model and canonical link origins coincide.',
            'sdf': 'Actual archived spawned SDF is directSDF, not a hypothetical URDF collapse. First link base_footprint has no explicit inertial/CoG; base_link explicit inertial offset is-.064,0,.048, connected by zero-pose fixed base_joint. That base_link CoG does not by itself prove the canonical origin velocity is aCoG velocity.',
            'driver': 'Original UpdateOdometryWorld gets model WorldPose and WorldLinearVel; stores model pose; projects worldXY with floatyaw cosf/sinf into base_footprint, angular.z only. yaw-only conversion changes XY orientation, not a point translation.',
            'modelstates': 'Officialgazebo_ros3.9.0 state plugin uses exactly same model WorldPose/WorldLinearVel APIs. A rawModelStates twist would be another observation of the same backend API, not an independent physical velocity oracle.'},
        'quantitative_tail': {
            'samples': len(rows), 'source_first_ns': rows[0]['source_ns'], 'source_last_ns': rows[-1]['source_ns'],
            'post_horizon_samples': len(settled_rows),
            'reported_planar_mps': span([r['body_planar_norm_mps'] for r in settled_rows]),
            'same_point_source_chord_mps': span([r['chord_speed_mps'] for r in settled_edges]),
            'chord_path_post_horizon_m': sum(r['chord_m'] for r in settled_edges),
            'float_rotation_relative_norm_error_max': max(abs(r['float_rotation_norm_scale']-1) for r in rows),
            'absolute_roll_rad_max': max(abs(r['roll_rad']) for r in rows),
            'absolute_pitch_rad_max': max(abs(r['pitch_rad']) for r in rows),
            'native_actuations': len(actuation),
            'all_native_desired_zero': all(r['desired_v']==r['desired_w']==0. for r in actuation),
            'all_native_applied_rim_zero': all(r['applied_rim_mps']==[0.,0.] for r in actuation),
            'source_rows': [{k:v for k,v in r.items()if k!='raw_message'} for r in rows], 'consecutive_source_edges': edges},
        'available_modelstates_evidence': {
            'message_count': model_result['model_state_message_count'],
            'control_failure_truth_diagnostic': model_result['control_failure_truth_diagnostic'],
            'tb1_aggregate_from_actual_modelstates_receipts': model_result['robots']['tb1'],
            'full_raw_modelstates_pose_twist_timeseries_found': False,
            'limit': 'Frozen task_evaluator keeps aggregate position/path and only emits latest diagnostic pose on control failure. This episode has no control failure; rawModelStates twist/source (header absent) was not archived. Cannot infer time-aligned model velocity from count/start/end/path.'},
        'conclusions': [
            'No demonstrated measurement-point/frame bug: declared canonical point and model pose origin coincide for this SDF; CoG correction in ODE velocity getter is explicit.',
            'Floatyaw/cosf/sinf norm error is orders of magnitude too small to explain the reported-speed/chord difference. Applying full roll/pitch rotation would change the meaning of the planar metric and is not evidence-based repair.',
            'Finite-difference pose speed is smaller than instant reported velocity; these distinct sampled quantities alone do not prove either source is erroneous, noise, or a false-positive stop gate.',
            'Zero desired/applied rim targets do not prove zero world-body velocity, zero constraint/contact motion, or successful rest. Missing rest remains a genuine unfulfilled empirical gate.',
            'If further diagnosis is authorized, passive co-timed canonical link WorldPose/WorldLinearVel/WorldCoGLinearVel/full angular and model/link states, plus joint/contact state, would separate backend point/physics/update-phase effects. Do not route evaluation truth to actor/guard or loosen originalrest.'],
        'sdf_links': links, 'sdf_joints': joints,
        'input_bindings': [{'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in input_paths],
        'official_source_bindings': json.loads((OUT/'official_sources_v1.json').read_bytes()),
        'script_sha256': sha(Path(__file__)),
        'source_data_unchanged_after_analysis': sha(raw_path) == raw_sha,
    }
    with output.open('x') as stream:
        stream.write(json.dumps(result, indent=2, allow_nan=False)+'\n')
    print(json.dumps({'output': str(output), 'sha256': sha(output),
        'tail_summary': {k:v for k,v in result['quantitative_tail'].items()
                         if k not in ('source_rows', 'consecutive_source_edges')}}))


if __name__ == '__main__':
    main()
