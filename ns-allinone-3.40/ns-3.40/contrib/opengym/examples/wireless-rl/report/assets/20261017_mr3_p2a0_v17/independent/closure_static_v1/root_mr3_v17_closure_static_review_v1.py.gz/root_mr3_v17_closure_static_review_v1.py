import hashlib,json,re,subprocess,time
from pathlib import Path
from urllib.parse import unquote
R=Path('/home/zhuyulab/ns3-workspace');WP='ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';RP='ros2_ws/ros2-multi-robot-automap';W=R/WP;A=W/'report/assets/20261017_mr3_p2a0_v17';T=Path('/tmp');freeze='eee6b2f90f697b28a1c20a2af5d1a6d2f044465e'
sha=lambda raw:hashlib.sha256(raw).hexdigest();start=time.monotonic()
inv=A/'inventory_native_v1.json';assert sha(inv.read_bytes())=='a711b076280676eff18c53708e108f7afd0c24edd27b46f704490693f7b916df';rows=json.loads(inv.read_bytes())['files'];assert len(rows)==6928
for row in rows:
 p=A/row['path'];raw=p.read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],str(p)
pre=json.loads((T/'mr3_p2a0_v17_source_preflight.json').read_text());assert pre['passed'] and pre['freeze']==freeze and len(pre['source_bindings'])==101 and len(pre['independent_source_bindings'])==147
for path,row in pre['source_bindings'].items():assert sha((R/path).read_bytes())==row['sha256'],path
for row in pre['independent_source_bindings']:assert sha((R/row['path']).read_bytes())==row['sha256'],row['path']
v=json.loads((A/'independent/native_archive_verification_v1.json').read_text());assert v['passed'] is True and v['matrix_all_formal_stages_passed'] is False and v['saved_identity_absence']['all_saved_identities_absent'] is True and v['saved_identity_absence']['saved_identities']==487
assert [(x['stage'],x['status']) for x in v['original_gate_statuses']]==[('interface','PASS'),('terminal','PASS'),('reset','FAIL'),('deadline','SKIPPED_after_reset_failure')]
for stage,jobs,failed in [('interface',11,[]),('terminal',9,[]),('reset',26,['physical_per_episode_v1','physics_matrix_v1'])]:
 a=json.loads((T/('mr3_p2a0_v17_'+stage+'_audit_execution_v1.json')).read_text());assert a['all_submitted_jobs_finished'] is True and a['runner_errors']==[] and len(a['commands'])==jobs;assert sorted(x['label'] for x in a['commands'] if not x['passed'])==sorted(failed)
old=subprocess.check_output(['git','show',freeze+':'+WP+'/log.md'],cwd=R);assert (W/'log.md').read_bytes().startswith(old)
allowed={'AGENTS.md',*[WP+'/'+x for x in ('AGENTS.md','RESEARCH_PLAN.md','IMPLEMENTATION_PLAN.md','log.md','report/20261017_mr3_p2a0_v17.md','report/ARCHIVE_INDEX.json','report/README.md')],*[RP+'/'+x for x in ('AGENTS.md','user_guide.md','launch_commands.md')]}
assert len(allowed)==11
links=[]
for path in sorted(allowed):
 if not path.endswith('.md'):continue
 for target in re.findall(r'\]\(([^)]+)\)',(R/path).read_text()):
  if target.startswith(('http:','https:','#','app:','plugin:','mailto:')):continue
  assert ((R/path).parent/unquote(target.split('#',1)[0])).exists(),(path,target)
  links.append([path,target])
assets={str((A/x['path']).relative_to(R)) for x in rows}|{str(inv.relative_to(R))}
subprocess.run(['git','diff','--check'],cwd=R,check=True);dry=subprocess.check_output(['git','add','-n','.'],cwd=R);drypath=T/'mr3_p2a0_v17_closure_git_add_dryrun_v1.log';drypath.write_bytes(dry)
paths=[re.fullmatch("add '(.*)'",x).group(1) for x in dry.decode().splitlines()];assert not set(paths)-(allowed|assets),sorted(set(paths)-(allowed|assets))
changed=set(subprocess.check_output(['git','diff','--name-only'],cwd=R).decode().splitlines());assert changed==allowed,(changed-allowed,allowed-changed)
result=dict(passed=True,freeze=freeze,inventory_entries=6928,inventory_sha256=sha(inv.read_bytes()),runtime_sources_unchanged=101,independent_sources_unchanged=147,all_487_saved_identities_gone=True,original_outcomes_preserved=True,links=len(links),dryrun_paths=len(paths),dryrun_sha256=sha(dry),allowed_non_asset_paths=sorted(allowed),script_sha256=sha(Path(__file__).read_bytes()),wall_seconds=time.monotonic()-start,scope='Static custody/links/staging only, no native or formal rerun.')
out=T/'root_mr3_v17_closure_static_review_v1.json'
with out.open('x') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['passed','inventory_entries','links','dryrun_paths','wall_seconds']}))
