"""Prepared only; publish requires explicit root GO via --publish after all formals end."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT=Path('/home/zhuyulab/ns3-workspace')
FREEZE='ba018fe3122c478836eb4e5da9c14306cd832c1b'
A=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v11'
TEMP=Path('/tmp');PREFIX='mr3_p2a0_v11_interface'
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_bytes())


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--publish',action='store_true',required=True)
    parser.parse_args()
    execution=read(TEMP/(PREFIX+'_audit_execution_v1.json'))
    launch=read(TEMP/(PREFIX+'_launch.json'))
    assert execution['freeze']==launch['freeze']==FREEZE and launch['status']=='completed'
    run=ROOT/'ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261017_v11_interface'
    ep=run/'worker0/episode001_open_101';summary=read(run/'benchmark_summary.json')
    shutdown=read(ep/'supervisor_shutdown.json')
    # Check frozen canonical originals, independently of later production source edits.
    raw_tar=subprocess.check_output(['git','archive','--format=tar',FREEZE,'--',str(A.relative_to(ROOT))],cwd=ROOT)
    frozen=[]
    with tarfile.open(fileobj=io.BytesIO(raw_tar),mode='r:')as stream:
        for member in stream:
            if member.isfile():
                data=stream.extractfile(member).read();assert(ROOT/member.name).read_bytes()==data
                frozen.append({'path':member.name,'bytes':len(data),'sha256':sha(data)})
    original_inventory=A/'inventory_prefreeze_v1.json'
    prefreeze=[]
    if original_inventory.exists():
        prefreeze=read(original_inventory)['files']
        for row in prefreeze:
            p=A/row['path'];raw=p.read_bytes();assert len(raw)==row['bytes']and sha(raw)==row['sha256']
    # Exact frozen runtime and independent source identities; never use current source bytes.
    preflight=read(TEMP/'mr3_p2a0_v11_source_preflight.json')
    manifest=TEMP/('source_bindings_'+FREEZE[:12]+'.json');archive=manifest.with_suffix('.tar.gz')
    proof=read(manifest);encoded=archive.read_bytes();decoded=gzip.decompress(encoded)
    assert proof['freeze']==preflight['freeze']==FREEZE and preflight['passed']is True
    assert sha(encoded)==proof['encoded_sha256']and sha(decoded)==proof['tar_sha256']
    paths=set(preflight['source_bindings']);assert len(paths)==100
    with tarfile.open(fileobj=io.BytesIO(decoded),mode='r:')as stream:
        members={m.name:m for m in stream if m.isfile()};assert set(members)==paths
        for path in paths:
            raw=stream.extractfile(members[path]).read()
            assert raw==subprocess.check_output(['git','show',FREEZE+':'+path],cwd=ROOT)
            assert sha(raw)==preflight['source_bindings'][path]['sha256']
    for binding in preflight['independent_source_bindings']:
        raw=subprocess.check_output(['git','show',FREEZE+':'+binding['path']],cwd=ROOT)
        assert sha(raw)==binding['sha256']
    selected=TEMP/'mr3_p2a0_v11_selected_native/interface';native=read(selected/'manifest.json')
    target=A/'native/interface';assert not target.exists();shutil.copytree(selected,target)
    for row in native['files']:
        data=(target/row['selected']).read_bytes();raw=gzip.decompress(data)if row['encoding']=='gzip'else data
        assert len(data)==row['selected_bytes']and sha(data)==row['selected_sha256']
        assert len(raw)==row['raw_bytes']and sha(raw)==row['raw_sha256']
    for p in(manifest,archive):
        dest=A/'independent'/p.name;assert not dest.exists();dest.write_bytes(p.read_bytes())
    originals={p for p in TEMP.glob(PREFIX+'*')if p.is_file()}
    for pattern in('mr3_p2a0_v11*review*.py','mr3_p2a0_v11*review*.json','mr3_p2a0_v11*profile*.py','mr3_p2a0_v11*live*monitor*.py'):
        originals.update(p for p in TEMP.glob(pattern)if p.is_file())
    for name in('mr3_p2a0_v11_source_preflight.json','mr3_p2a0_v11_binaryproof.json','mr3_p2a0_v11_pack_native_v1.py','mr3_p2a0_v11_sourcepack_old_git_verification_v1.json','mr3_p2a0_v11_phase_live_monitor_v1.py','mr3_p2a0_v11_phase_live_monitor_v2.py','mr3_p2a0_v11_settled_history_comparison_v1.py'):
        p=TEMP/name
        if p.exists():originals.add(p)
    originals.add(Path(__file__))
    destination=A/'independent/native_originals_v1';destination.mkdir(exist_ok=False);entries=[]
    for src in sorted(originals):
        raw=src.read_bytes();data=gzip.compress(raw,mtime=0);dest=destination/(src.name+'.gz')
        with dest.open('xb')as stream:stream.write(data)
        assert gzip.decompress(dest.read_bytes())==raw and src.read_bytes()==raw
        entries.append({'source':str(src),'selected_path':str(dest.relative_to(ROOT)),'raw_bytes':len(raw),'raw_sha256':sha(raw),'selected_bytes':len(data),'selected_encoded_sha256':sha(data),'selected_decoded_sha256':sha(gzip.decompress(data)),'decoded_equals_raw':True})
    support={'schema':'mr3-v11-closed-native-support-originals-v1','freeze':FREEZE,'passed':True,'count':len(entries),'entries':entries,'scope':'All completed formal results, diagnostic partial PASS and FAIL remain under original scopes; missing output stays missing with original console. No cross-freeze matrix assembly.'}
    (destination/'manifest.json').write_text(json.dumps(support,indent=2)+'\n')
    transition_rows=[json.loads(x)for x in(ep/'transitions.jsonl').read_bytes().splitlines()if x]
    account={'schema':'mr3-v11-closed-engineering-cost-v1','freeze':FREEZE,'stage':'interface','formal_stage_passed':execution['passed'],'launcher_benchmark_only_passed':launch['passed'],'launcher_wall_seconds':launch['wall_duration_sec'],'benchmark_wall_seconds_including_attempts':summary['wall_sec_including_all_attempts'],'returned_resets':sum(x['kind']=='reset'for x in transition_rows),'returned_steps':sum(x['kind']=='step'for x in transition_rows),'saved_transition_records':len(transition_rows),'gpu_calls':0,'optimizer_updates':0,'pilot_budget_unchanged':{'remaining_decisions':1870,'remaining_wall_seconds':2905.954739546403},'formal_commands':[{k:r.get(k)for k in('label','returncode','passed','output_exists')}for r in execution['commands']],'later_stages':{s:'SKIPPED_after_interface_formal_failure'for s in('terminal','reset','deadline')},'strict_supervisor_facts':{k:shutdown[k]for k in('epoch','worker_returncode','forced_shutdown','failed_sample','remaining_owned_processes','remaining_owned_zombies')},'sourcepack_files':len(paths),'independent_source_bindings':len(preflight['independent_source_bindings']),'native_selected_files':native['source_files'],'native_raw_bytes':native['raw_bytes'],'native_selected_bytes':native['selected_bytes'],'scope':'Costs and original gate outcomes only. No partial-PASS combination gives a complete version, task95%, learned-policy or P2A.0 acceptance credit.'}
    accounting=A/'accounting';accounting.mkdir(exist_ok=False);cost=accounting/'native_cost_v1.json';cost.write_text(json.dumps(account,indent=2)+'\n')
    verification={'schema':'mr3-v11-native-archive-verification-v1','passed':True,'freeze':FREEZE,'sourcepack_files':len(paths),'independent_source_bindings':len(preflight['independent_source_bindings']),'frozen_canonical_originals_unchanged':frozen,'prefreeze_inventory_entries_unchanged':len(prefreeze),'native_selected_files':len(native['files']),'support_originals':len(entries),'native_manifest_sha256':sha((target/'manifest.json').read_bytes()),'support_manifest_sha256':sha((destination/'manifest.json').read_bytes()),'source_archive_encoded_sha256':sha(encoded),'source_archive_tar_sha256':sha(decoded),'scope':'Lossless original-byte/Git/source/encoded-and-decoded verification, not formal stage PASS.'}
    output=A/'independent/native_archive_verification_v1.json';output.write_text(json.dumps(verification,indent=2)+'\n')
    inventory=A/'inventory_native_v1.json';assert not inventory.exists();rows=[];excluded=[]
    for p in sorted(A.rglob('*')):
        if not p.is_file()or p==inventory:continue
        if p.suffix=='.pyc'or'__pycache__'in p.parts:excluded.append(str(p.relative_to(A)));continue
        rows.append({'path':str(p.relative_to(A)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
    inventory.write_text(json.dumps({'schema':'mr3-inventory-native-v1','freeze':FREEZE,'self_excluded':True,'exclude_python_cache':True,'excluded_python_cache':excluded,'files':rows},indent=2)+'\n')
    for row in rows:
        p=A/row['path'];assert p.stat().st_size==row['bytes']and sha(p.read_bytes())==row['sha256']
    result={'passed':True,'freeze':FREEZE,'native_selected_files':len(native['files']),'support_originals':len(entries),'inventory_count':len(rows),'inventory_sha256':sha(inventory.read_bytes()),'archive_verification_sha256':sha(output.read_bytes()),'excluded_cache_count':len(excluded),'cost_receipt':str(cost)}
    path=TEMP/'mr3_p2a0_v11_closed_archive_receipt_v1.json'
    with path.open('x')as stream:stream.write(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
