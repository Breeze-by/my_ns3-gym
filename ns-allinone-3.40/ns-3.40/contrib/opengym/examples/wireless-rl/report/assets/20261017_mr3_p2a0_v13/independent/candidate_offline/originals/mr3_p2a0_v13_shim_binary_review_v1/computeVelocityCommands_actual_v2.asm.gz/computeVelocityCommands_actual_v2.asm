0000000000019dc0 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base>:
   19dc0:	f3 0f 1e fa          	endbr64 
   19dc4:	41 57                	push   %r15
   19dc6:	41 56                	push   %r14
   19dc8:	49 89 ce             	mov    %rcx,%r14
   19dcb:	41 55                	push   %r13
   19dcd:	49 89 d5             	mov    %rdx,%r13
   19dd0:	41 54                	push   %r12
   19dd2:	49 89 fc             	mov    %rdi,%r12
   19dd5:	55                   	push   %rbp
   19dd6:	4c 89 c5             	mov    %r8,%rbp
   19dd9:	53                   	push   %rbx
   19dda:	48 89 f3             	mov    %rsi,%rbx
   19ddd:	48 81 ec c8 08 00 00 	sub    $0x8c8,%rsp
   19de4:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
   19deb:	00 00 
   19ded:	48 89 84 24 b8 08 00 	mov    %rax,0x8b8(%rsp)
   19df4:	00 
   19df5:	31 c0                	xor    %eax,%eax
   19df7:	80 be d0 01 00 00 00 	cmpb   $0x0,0x1d0(%rsi)
   19dfe:	0f 85 0c 01 00 00    	jne    19f10 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x150>
   19e04:	48 8d 84 24 c8 04 00 	lea    0x4c8(%rsp),%rax
   19e0b:	00 
   19e0c:	80 bb 50 01 00 00 00 	cmpb   $0x0,0x150(%rbx)
   19e13:	4c 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%r15
   19e1a:	00 
   19e1b:	48 89 04 24          	mov    %rax,(%rsp)
   19e1f:	0f 85 ab 03 00 00    	jne    1a1d0 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x410>
   19e25:	48 8b b3 40 01 00 00 	mov    0x140(%rbx),%rsi
   19e2c:	49 89 e8             	mov    %rbp,%r8
   19e2f:	4c 89 f1             	mov    %r14,%rcx
   19e32:	4c 89 ea             	mov    %r13,%rdx
   19e35:	c6 83 d1 01 00 00 00 	movb   $0x0,0x1d1(%rbx)
   19e3c:	4c 89 ff             	mov    %r15,%rdi
   19e3f:	48 8b 06             	mov    (%rsi),%rax
   19e42:	ff 50 38             	call   *0x38(%rax)
   19e45:	48 8b 84 24 b0 04 00 	mov    0x4b0(%rsp),%rax
   19e4c:	00 
   19e4d:	f2 0f 10 84 24 00 05 	movsd  0x500(%rsp),%xmm0
   19e54:	00 00 
   19e56:	f2 0f 11 83 d8 01 00 	movsd  %xmm0,0x1d8(%rbx)
   19e5d:	00 
   19e5e:	49 89 04 24          	mov    %rax,(%r12)
   19e62:	49 8d 44 24 18       	lea    0x18(%r12),%rax
   19e67:	49 89 44 24 08       	mov    %rax,0x8(%r12)
   19e6c:	48 8b 84 24 b8 04 00 	mov    0x4b8(%rsp),%rax
   19e73:	00 
   19e74:	48 3b 04 24          	cmp    (%rsp),%rax
   19e78:	74 7e                	je     19ef8 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x138>
   19e7a:	49 89 44 24 08       	mov    %rax,0x8(%r12)
   19e7f:	48 8b 84 24 c8 04 00 	mov    0x4c8(%rsp),%rax
   19e86:	00 
   19e87:	49 89 44 24 18       	mov    %rax,0x18(%r12)
   19e8c:	48 8b 84 24 c0 04 00 	mov    0x4c0(%rsp),%rax
   19e93:	00 
   19e94:	f3 0f 6f 9c 24 d8 04 	movdqu 0x4d8(%rsp),%xmm3
   19e9b:	00 00 
   19e9d:	f3 0f 6f a4 24 e8 04 	movdqu 0x4e8(%rsp),%xmm4
   19ea4:	00 00 
   19ea6:	f3 0f 6f ac 24 f8 04 	movdqu 0x4f8(%rsp),%xmm5
   19ead:	00 00 
   19eaf:	49 89 44 24 10       	mov    %rax,0x10(%r12)
   19eb4:	41 0f 11 5c 24 28    	movups %xmm3,0x28(%r12)
   19eba:	41 0f 11 64 24 38    	movups %xmm4,0x38(%r12)
   19ec0:	41 0f 11 6c 24 48    	movups %xmm5,0x48(%r12)
   19ec6:	48 8b 84 24 b8 08 00 	mov    0x8b8(%rsp),%rax
   19ecd:	00 
   19ece:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
   19ed5:	00 00 
   19ed7:	0f 85 3d 07 00 00    	jne    1a61a <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x85a>
   19edd:	48 81 c4 c8 08 00 00 	add    $0x8c8,%rsp
   19ee4:	4c 89 e0             	mov    %r12,%rax
   19ee7:	5b                   	pop    %rbx
   19ee8:	5d                   	pop    %rbp
   19ee9:	41 5c                	pop    %r12
   19eeb:	41 5d                	pop    %r13
   19eed:	41 5e                	pop    %r14
   19eef:	41 5f                	pop    %r15
   19ef1:	c3                   	ret    
   19ef2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   19ef8:	f3 0f 6f b4 24 c8 04 	movdqu 0x4c8(%rsp),%xmm6
   19eff:	00 00 
   19f01:	41 0f 11 74 24 18    	movups %xmm6,0x18(%r12)
   19f07:	eb 83                	jmp    19e8c <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xcc>
   19f09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   19f10:	48 8d 86 e0 01 00 00 	lea    0x1e0(%rsi),%rax
   19f17:	48 89 c7             	mov    %rax,%rdi
   19f1a:	48 89 04 24          	mov    %rax,(%rsp)
   19f1e:	e8 3d 63 ff ff       	call   10260 <pthread_mutex_lock@plt>
   19f23:	85 c0                	test   %eax,%eax
   19f25:	0f 85 f4 06 00 00    	jne    1a61f <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x85f>
   19f2b:	4c 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%r15
   19f32:	00 
   19f33:	48 89 de             	mov    %rbx,%rsi
   19f36:	4c 89 ff             	mov    %r15,%rdi
   19f39:	e8 f2 62 ff ff       	call   10230 <nav2_rotation_shim_controller::RotationShimController::getSampledPathGoal()@plt>
   19f3e:	49 8b 75 08          	mov    0x8(%r13),%rsi
   19f42:	49 8b 55 10          	mov    0x10(%r13),%rdx
   19f46:	48 8d 84 24 b0 00 00 	lea    0xb0(%rsp),%rax
   19f4d:	00 
   19f4e:	48 8d 8c 24 c0 00 00 	lea    0xc0(%rsp),%rcx
   19f55:	00 
   19f56:	48 89 c7             	mov    %rax,%rdi
   19f59:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
   19f5e:	48 01 f2             	add    %rsi,%rdx
   19f61:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
   19f68:	00 
   19f69:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   19f6e:	e8 8d cc 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   19f73:	48 8b 53 18          	mov    0x18(%rbx),%rdx
   19f77:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   19f7c:	4c 89 fe             	mov    %r15,%rsi
   19f7f:	4c 89 ff             	mov    %r15,%rdi
   19f82:	f2 0f 10 05 1e 0c 02 	movsd  0x20c1e(%rip),%xmm0        # 3aba8 <typeinfo name for nav2_core::Controller*@@Base+0x48>
   19f89:	00 
   19f8a:	e8 91 5d ff ff       	call   fd20 <nav2_util::transformPoseInTargetFrame(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> >&, tf2_ros::Buffer&, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, double)@plt>
   19f8f:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
   19f96:	00 
   19f97:	48 3b 7c 24 10       	cmp    0x10(%rsp),%rdi
   19f9c:	74 1a                	je     19fb8 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x1f8>
   19f9e:	88 44 24 10          	mov    %al,0x10(%rsp)
   19fa2:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
   19fa9:	00 
   19faa:	48 8d 70 01          	lea    0x1(%rax),%rsi
   19fae:	e8 0d 60 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   19fb3:	0f b6 44 24 10       	movzbl 0x10(%rsp),%eax
   19fb8:	84 c0                	test   %al,%al
   19fba:	0f 84 a8 75 ff ff    	je     11568 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1098>
   19fc0:	48 8b 05 d9 0b 02 00 	mov    0x20bd9(%rip),%rax        # 3aba0 <typeinfo name for nav2_core::Controller*@@Base+0x40>
   19fc7:	48 89 ef             	mov    %rbp,%rdi
   19fca:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
   19fd1:	00 00 
   19fd3:	48 8d 54 24 40       	lea    0x40(%rsp),%rdx
   19fd8:	48 c7 44 24 78 00 00 	movq   $0x0,0x78(%rsp)
   19fdf:	00 00 
   19fe1:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
   19fe6:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   19fed:	00 
   19fee:	48 8b 45 00          	mov    0x0(%rbp),%rax
   19ff2:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
   19ff9:	00 00 00 00 00 
   19ffe:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   1a005:	00 00 00 00 00 
   1a00a:	48 c7 84 24 90 00 00 	movq   $0x0,0x90(%rsp)
   1a011:	00 00 00 00 00 
   1a016:	48 c7 84 24 98 00 00 	movq   $0x0,0x98(%rsp)
   1a01d:	00 00 00 00 00 
   1a022:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
   1a029:	00 00 
   1a02b:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
   1a032:	00 00 
   1a034:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
   1a03b:	00 00 
   1a03d:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
   1a044:	00 00 
   1a046:	48 c7 44 24 60 00 00 	movq   $0x0,0x60(%rsp)
   1a04d:	00 00 
   1a04f:	48 c7 44 24 68 00 00 	movq   $0x0,0x68(%rsp)
   1a056:	00 00 
   1a058:	ff 50 28             	call   *0x28(%rax)
   1a05b:	48 8b bb 18 02 00 00 	mov    0x218(%rbx),%rdi
   1a062:	f2 0f 10 44 24 70    	movsd  0x70(%rsp),%xmm0
   1a068:	e8 b3 61 ff ff       	call   10220 <nav2_controller::PositionGoalChecker::setXYGoalTolerance(double)@plt>
   1a06d:	48 8b bb 18 02 00 00 	mov    0x218(%rbx),%rdi
   1a074:	48 8d 94 24 d8 04 00 	lea    0x4d8(%rsp),%rdx
   1a07b:	00 
   1a07c:	49 8d 75 28          	lea    0x28(%r13),%rsi
   1a080:	4c 89 f1             	mov    %r14,%rcx
   1a083:	48 8b 07             	mov    (%rdi),%rax
   1a086:	ff 50 20             	call   *0x20(%rax)
   1a089:	84 c0                	test   %al,%al
   1a08b:	0f 84 4f 03 00 00    	je     1a3e0 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x620>
   1a091:	49 8d 7d 40          	lea    0x40(%r13),%rdi
   1a095:	e8 16 bf ff ff       	call   15fb0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x240>
   1a09a:	48 8d bc 24 f0 04 00 	lea    0x4f0(%rsp),%rdi
   1a0a1:	00 
   1a0a2:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
   1a0a8:	e8 03 bf ff ff       	call   15fb0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x240>
   1a0ad:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
   1a0b3:	f2 0f 58 05 fd 0a 02 	addsd  0x20afd(%rip),%xmm0        # 3abb8 <typeinfo name for nav2_core::Controller*@@Base+0x58>
   1a0ba:	00 
   1a0bb:	f2 0f 10 0d ed 0a 02 	movsd  0x20aed(%rip),%xmm1        # 3abb0 <typeinfo name for nav2_core::Controller*@@Base+0x50>
   1a0c2:	00 
   1a0c3:	e8 d8 60 ff ff       	call   101a0 <fmod@plt>
   1a0c8:	66 0f ef c9          	pxor   %xmm1,%xmm1
   1a0cc:	66 0f 2f c8          	comisd %xmm0,%xmm1
   1a0d0:	0f 83 c2 03 00 00    	jae    1a498 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x6d8>
   1a0d6:	f2 0f 5c 05 da 0a 02 	subsd  0x20ada(%rip),%xmm0        # 3abb8 <typeinfo name for nav2_core::Controller*@@Base+0x58>
   1a0dd:	00 
   1a0de:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   1a0e3:	48 8d 54 24 38       	lea    0x38(%rsp),%rdx
   1a0e8:	4d 89 f0             	mov    %r14,%r8
   1a0eb:	4c 89 e9             	mov    %r13,%rcx
   1a0ee:	48 89 de             	mov    %rbx,%rsi
   1a0f1:	f2 0f 11 44 24 38    	movsd  %xmm0,0x38(%rsp)
   1a0f7:	e8 b4 59 ff ff       	call   fab0 <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@plt>
   1a0fc:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   1a103:	00 
   1a104:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
   1a10b:	00 
   1a10c:	f2 0f 10 84 24 00 01 	movsd  0x100(%rsp),%xmm0
   1a113:	00 00 
   1a115:	f2 0f 11 83 d8 01 00 	movsd  %xmm0,0x1d8(%rbx)
   1a11c:	00 
   1a11d:	49 89 04 24          	mov    %rax,(%r12)
   1a121:	49 8d 44 24 18       	lea    0x18(%r12),%rax
   1a126:	49 89 44 24 08       	mov    %rax,0x8(%r12)
   1a12b:	48 8d 84 24 c8 00 00 	lea    0xc8(%rsp),%rax
   1a132:	00 
   1a133:	48 39 c2             	cmp    %rax,%rdx
   1a136:	0f 84 44 03 00 00    	je     1a480 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x6c0>
   1a13c:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
   1a141:	48 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%rdx
   1a148:	00 
   1a149:	49 89 54 24 18       	mov    %rdx,0x18(%r12)
   1a14e:	48 8b 94 24 c0 00 00 	mov    0xc0(%rsp),%rdx
   1a155:	00 
   1a156:	f3 0f 6f bc 24 d8 00 	movdqu 0xd8(%rsp),%xmm7
   1a15d:	00 00 
   1a15f:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   1a166:	00 
   1a167:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
   1a16e:	00 
   1a16f:	f3 0f 6f 94 24 e8 00 	movdqu 0xe8(%rsp),%xmm2
   1a176:	00 00 
   1a178:	c6 84 24 c8 00 00 00 	movb   $0x0,0xc8(%rsp)
   1a17f:	00 
   1a180:	f3 0f 6f b4 24 f8 00 	movdqu 0xf8(%rsp),%xmm6
   1a187:	00 00 
   1a189:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
   1a18e:	41 0f 11 7c 24 28    	movups %xmm7,0x28(%r12)
   1a194:	41 0f 11 54 24 38    	movups %xmm2,0x38(%r12)
   1a19a:	41 0f 11 74 24 48    	movups %xmm6,0x48(%r12)
   1a1a0:	48 c7 84 24 c0 00 00 	movq   $0x0,0xc0(%rsp)
   1a1a7:	00 00 00 00 00 
   1a1ac:	e8 5f 5f ff ff       	call   10110 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_dispose()@plt>
   1a1b1:	48 8d bc 24 b8 04 00 	lea    0x4b8(%rsp),%rdi
   1a1b8:	00 
   1a1b9:	e8 52 5f ff ff       	call   10110 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_dispose()@plt>
   1a1be:	48 8b 3c 24          	mov    (%rsp),%rdi
   1a1c2:	e8 c9 5c ff ff       	call   fe90 <pthread_mutex_unlock@plt>
   1a1c7:	e9 fa fc ff ff       	jmp    19ec6 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x106>
   1a1cc:	0f 1f 40 00          	nopl   0x0(%rax)
   1a1d0:	48 8b 43 68          	mov    0x68(%rbx),%rax
   1a1d4:	48 8b 80 d8 03 00 00 	mov    0x3d8(%rax),%rax
   1a1db:	48 8b 40 48          	mov    0x48(%rax),%rax
   1a1df:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   1a1e4:	48 85 c0             	test   %rax,%rax
   1a1e7:	0f 84 39 04 00 00    	je     1a626 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x866>
   1a1ed:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
   1a1f2:	e8 69 60 ff ff       	call   10260 <pthread_mutex_lock@plt>
   1a1f7:	85 c0                	test   %eax,%eax
   1a1f9:	0f 85 20 04 00 00    	jne    1a61f <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x85f>
   1a1ff:	48 8d 83 e0 01 00 00 	lea    0x1e0(%rbx),%rax
   1a206:	48 89 c7             	mov    %rax,%rdi
   1a209:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   1a20e:	e8 4d 60 ff ff       	call   10260 <pthread_mutex_lock@plt>
   1a213:	85 c0                	test   %eax,%eax
   1a215:	0f 85 15 04 00 00    	jne    1a630 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x870>
   1a21b:	48 89 de             	mov    %rbx,%rsi
   1a21e:	4c 89 ff             	mov    %r15,%rdi
   1a221:	e8 ea 5a ff ff       	call   fd10 <nav2_rotation_shim_controller::RotationShimController::getSampledPathPt()@plt>
   1a226:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   1a22b:	4c 89 fa             	mov    %r15,%rdx
   1a22e:	48 89 de             	mov    %rbx,%rsi
   1a231:	e8 3a 5c ff ff       	call   fe70 <nav2_rotation_shim_controller::RotationShimController::transformPoseToBaseFrame(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&)@plt>
   1a236:	48 8b bc 24 b8 04 00 	mov    0x4b8(%rsp),%rdi
   1a23d:	00 
   1a23e:	48 8d 84 24 c8 04 00 	lea    0x4c8(%rsp),%rax
   1a245:	00 
   1a246:	48 89 04 24          	mov    %rax,(%rsp)
   1a24a:	48 39 c7             	cmp    %rax,%rdi
   1a24d:	74 11                	je     1a260 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x4a0>
   1a24f:	48 8b 84 24 c8 04 00 	mov    0x4c8(%rsp),%rax
   1a256:	00 
   1a257:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1a25b:	e8 60 5d ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1a260:	f2 0f 10 4c 24 70    	movsd  0x70(%rsp),%xmm1
   1a266:	f2 0f 10 44 24 78    	movsd  0x78(%rsp),%xmm0
   1a26c:	e8 6f 58 ff ff       	call   fae0 <atan2@plt>
   1a271:	80 bb d1 01 00 00 00 	cmpb   $0x0,0x1d1(%rbx)
   1a278:	f2 0f 10 93 a0 01 00 	movsd  0x1a0(%rbx),%xmm2
   1a27f:	00 
   1a280:	f2 0f 10 8b a8 01 00 	movsd  0x1a8(%rbx),%xmm1
   1a287:	00 
   1a288:	f2 0f 11 44 24 40    	movsd  %xmm0,0x40(%rsp)
   1a28e:	0f 84 dc 01 00 00    	je     1a470 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x6b0>
   1a294:	66 0f 54 05 64 09 02 	andpd  0x20964(%rip),%xmm0        # 3ac00 <typeinfo name for nav2_core::Controller*@@Base+0xa0>
   1a29b:	00 
   1a29c:	48 8b 05 3d c9 02 00 	mov    0x2c93d(%rip),%rax        # 46be0 <g_rcutils_logging_initialized@Base>
   1a2a3:	66 0f 2f c1          	comisd %xmm1,%xmm0
   1a2a7:	0f b6 00             	movzbl (%rax),%eax
   1a2aa:	0f 86 50 01 00 00    	jbe    1a400 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x640>
   1a2b0:	84 c0                	test   %al,%al
   1a2b2:	0f 84 08 02 00 00    	je     1a4c0 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x700>
   1a2b8:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
   1a2bc:	48 85 ff             	test   %rdi,%rdi
   1a2bf:	74 03                	je     1a2c4 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x504>
   1a2c1:	48 8b 3f             	mov    (%rdi),%rdi
   1a2c4:	be 0a 00 00 00       	mov    $0xa,%esi
   1a2c9:	e8 22 5c ff ff       	call   fef0 <rcutils_logging_logger_is_enabled_for@plt>
   1a2ce:	84 c0                	test   %al,%al
   1a2d0:	74 26                	je     1a2f8 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x538>
   1a2d2:	48 8b 53 48          	mov    0x48(%rbx),%rdx
   1a2d6:	48 85 d2             	test   %rdx,%rdx
   1a2d9:	74 03                	je     1a2de <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x51e>
   1a2db:	48 8b 12             	mov    (%rdx),%rdx
   1a2de:	48 8d 0d 5b f4 01 00 	lea    0x1f45b(%rip),%rcx        # 39740 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x35a0>
   1a2e5:	be 0a 00 00 00       	mov    $0xa,%esi
   1a2ea:	48 8d 3d 1f d3 02 00 	lea    0x2d31f(%rip),%rdi        # 47610 <pluginlib::ClassLoader<nav2_core::Controller>::ClassLoader(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::vector<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::allocator<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > > >)::__rcutils_logging_location@@Base+0x80>
   1a2f1:	31 c0                	xor    %eax,%eax
   1a2f3:	e8 e8 5c ff ff       	call   ffe0 <rcutils_log@plt>
   1a2f8:	c6 83 d1 01 00 00 01 	movb   $0x1,0x1d1(%rbx)
   1a2ff:	4d 89 f0             	mov    %r14,%r8
   1a302:	4c 89 e9             	mov    %r13,%rcx
   1a305:	48 89 de             	mov    %rbx,%rsi
   1a308:	48 8d 54 24 40       	lea    0x40(%rsp),%rdx
   1a30d:	4c 89 ff             	mov    %r15,%rdi
   1a310:	e8 9b 57 ff ff       	call   fab0 <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@plt>
   1a315:	48 8b 84 24 b0 04 00 	mov    0x4b0(%rsp),%rax
   1a31c:	00 
   1a31d:	f2 0f 10 84 24 00 05 	movsd  0x500(%rsp),%xmm0
   1a324:	00 00 
   1a326:	f2 0f 11 83 d8 01 00 	movsd  %xmm0,0x1d8(%rbx)
   1a32d:	00 
   1a32e:	49 89 04 24          	mov    %rax,(%r12)
   1a332:	49 8d 44 24 18       	lea    0x18(%r12),%rax
   1a337:	49 89 44 24 08       	mov    %rax,0x8(%r12)
   1a33c:	48 8b 84 24 b8 04 00 	mov    0x4b8(%rsp),%rax
   1a343:	00 
   1a344:	48 3b 04 24          	cmp    (%rsp),%rax
   1a348:	0f 84 5a 01 00 00    	je     1a4a8 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x6e8>
   1a34e:	49 89 44 24 08       	mov    %rax,0x8(%r12)
   1a353:	48 8b 84 24 c8 04 00 	mov    0x4c8(%rsp),%rax
   1a35a:	00 
   1a35b:	49 89 44 24 18       	mov    %rax,0x18(%r12)
   1a360:	48 8b 84 24 c0 04 00 	mov    0x4c0(%rsp),%rax
   1a367:	00 
   1a368:	f3 0f 6f bc 24 d8 04 	movdqu 0x4d8(%rsp),%xmm7
   1a36f:	00 00 
   1a371:	48 8d bc 24 b8 04 00 	lea    0x4b8(%rsp),%rdi
   1a378:	00 
   1a379:	48 c7 84 24 c0 04 00 	movq   $0x0,0x4c0(%rsp)
   1a380:	00 00 00 00 00 
   1a385:	f3 0f 6f 94 24 e8 04 	movdqu 0x4e8(%rsp),%xmm2
   1a38c:	00 00 
   1a38e:	c6 84 24 c8 04 00 00 	movb   $0x0,0x4c8(%rsp)
   1a395:	00 
   1a396:	f3 0f 6f b4 24 f8 04 	movdqu 0x4f8(%rsp),%xmm6
   1a39d:	00 00 
   1a39f:	49 89 44 24 10       	mov    %rax,0x10(%r12)
   1a3a4:	48 8b 04 24          	mov    (%rsp),%rax
   1a3a8:	41 0f 11 7c 24 28    	movups %xmm7,0x28(%r12)
   1a3ae:	41 0f 11 54 24 38    	movups %xmm2,0x38(%r12)
   1a3b4:	41 0f 11 74 24 48    	movups %xmm6,0x48(%r12)
   1a3ba:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
   1a3c1:	00 
   1a3c2:	e8 49 5d ff ff       	call   10110 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_dispose()@plt>
   1a3c7:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   1a3cc:	e8 bf 5a ff ff       	call   fe90 <pthread_mutex_unlock@plt>
   1a3d1:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
   1a3d6:	e8 b5 5a ff ff       	call   fe90 <pthread_mutex_unlock@plt>
   1a3db:	e9 e6 fa ff ff       	jmp    19ec6 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x106>
   1a3e0:	48 8d bc 24 b8 04 00 	lea    0x4b8(%rsp),%rdi
   1a3e7:	00 
   1a3e8:	e8 23 5d ff ff       	call   10110 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::_M_dispose()@plt>
   1a3ed:	48 8b 3c 24          	mov    (%rsp),%rdi
   1a3f1:	e8 9a 5a ff ff       	call   fe90 <pthread_mutex_unlock@plt>
   1a3f6:	e9 09 fa ff ff       	jmp    19e04 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x44>
   1a3fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1a400:	84 c0                	test   %al,%al
   1a402:	0f 84 68 01 00 00    	je     1a570 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x7b0>
   1a408:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
   1a40c:	48 85 ff             	test   %rdi,%rdi
   1a40f:	74 03                	je     1a414 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x654>
   1a411:	48 8b 3f             	mov    (%rdi),%rdi
   1a414:	be 0a 00 00 00       	mov    $0xa,%esi
   1a419:	e8 d2 5a ff ff       	call   fef0 <rcutils_logging_logger_is_enabled_for@plt>
   1a41e:	84 c0                	test   %al,%al
   1a420:	74 26                	je     1a448 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x688>
   1a422:	48 8b 53 48          	mov    0x48(%rbx),%rdx
   1a426:	48 85 d2             	test   %rdx,%rdx
   1a429:	74 03                	je     1a42e <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x66e>
   1a42b:	48 8b 12             	mov    (%rdx),%rdx
   1a42e:	48 8d 0d b3 f3 01 00 	lea    0x1f3b3(%rip),%rcx        # 397e8 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3648>
   1a435:	be 0a 00 00 00       	mov    $0xa,%esi
   1a43a:	48 8d 3d af d1 02 00 	lea    0x2d1af(%rip),%rdi        # 475f0 <pluginlib::ClassLoader<nav2_core::Controller>::ClassLoader(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::vector<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::allocator<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > > >)::__rcutils_logging_location@@Base+0x60>
   1a441:	31 c0                	xor    %eax,%eax
   1a443:	e8 98 5b ff ff       	call   ffe0 <rcutils_log@plt>
   1a448:	c6 83 50 01 00 00 00 	movb   $0x0,0x150(%rbx)
   1a44f:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   1a454:	e8 37 5a ff ff       	call   fe90 <pthread_mutex_unlock@plt>
   1a459:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
   1a45e:	e8 2d 5a ff ff       	call   fe90 <pthread_mutex_unlock@plt>
   1a463:	e9 bd f9 ff ff       	jmp    19e25 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x65>
   1a468:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   1a46f:	00 
   1a470:	66 0f 28 ca          	movapd %xmm2,%xmm1
   1a474:	e9 1b fe ff ff       	jmp    1a294 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x4d4>
   1a479:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   1a480:	f3 0f 6f bc 24 c8 00 	movdqu 0xc8(%rsp),%xmm7
   1a487:	00 00 
   1a489:	41 0f 11 7c 24 18    	movups %xmm7,0x18(%r12)
   1a48f:	e9 ba fc ff ff       	jmp    1a14e <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x38e>
   1a494:	0f 1f 40 00          	nopl   0x0(%rax)
   1a498:	f2 0f 58 05 18 07 02 	addsd  0x20718(%rip),%xmm0        # 3abb8 <typeinfo name for nav2_core::Controller*@@Base+0x58>
   1a49f:	00 
   1a4a0:	e9 39 fc ff ff       	jmp    1a0de <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x31e>
   1a4a5:	0f 1f 00             	nopl   (%rax)
   1a4a8:	f3 0f 6f 94 24 c8 04 	movdqu 0x4c8(%rsp),%xmm2
   1a4af:	00 00 
   1a4b1:	41 0f 11 54 24 18    	movups %xmm2,0x18(%r12)
   1a4b7:	e9 a4 fe ff ff       	jmp    1a360 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x5a0>
   1a4bc:	0f 1f 40 00          	nopl   0x0(%rax)
   1a4c0:	e8 0b 57 ff ff       	call   fbd0 <rcutils_logging_initialize@plt>
   1a4c5:	85 c0                	test   %eax,%eax
   1a4c7:	0f 84 eb fd ff ff    	je     1a2b8 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x4f8>
   1a4cd:	48 8b 05 cc c9 02 00 	mov    0x2c9cc(%rip),%rax        # 46ea0 <stderr@GLIBC_2.2.5>
   1a4d4:	ba 52 00 00 00       	mov    $0x52,%edx
   1a4d9:	be 01 00 00 00       	mov    $0x1,%esi
   1a4de:	48 8d 3d 03 f2 01 00 	lea    0x1f203(%rip),%rdi        # 396e8 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3548>
   1a4e5:	48 8b 08             	mov    (%rax),%rcx
   1a4e8:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   1a4ed:	e8 9e 5f ff ff       	call   10490 <fwrite@plt>
   1a4f2:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   1a4f7:	48 8d 94 24 b0 00 00 	lea    0xb0(%rsp),%rdx
   1a4fe:	00 
   1a4ff:	48 89 d7             	mov    %rdx,%rdi
   1a502:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   1a507:	48 8b 08             	mov    (%rax),%rcx
   1a50a:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
   1a50f:	e8 2c 59 ff ff       	call   fe40 <rcutils_get_error_string@plt>
   1a514:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   1a519:	e8 92 57 ff ff       	call   fcb0 <strlen@plt>
   1a51e:	4c 89 ff             	mov    %r15,%rdi
   1a521:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   1a526:	e8 15 59 ff ff       	call   fe40 <rcutils_get_error_string@plt>
   1a52b:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
   1a530:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   1a535:	be 01 00 00 00       	mov    $0x1,%esi
   1a53a:	4c 89 ff             	mov    %r15,%rdi
   1a53d:	e8 4e 5f ff ff       	call   10490 <fwrite@plt>
   1a542:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   1a547:	ba 01 00 00 00       	mov    $0x1,%edx
   1a54c:	be 01 00 00 00       	mov    $0x1,%esi
   1a551:	48 8d 3d e6 ea 01 00 	lea    0x1eae6(%rip),%rdi        # 3903e <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e9e>
   1a558:	48 8b 08             	mov    (%rax),%rcx
   1a55b:	e8 30 5f ff ff       	call   10490 <fwrite@plt>
   1a560:	e8 4b 5a ff ff       	call   ffb0 <rcutils_reset_error@plt>
   1a565:	e9 4e fd ff ff       	jmp    1a2b8 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x4f8>
   1a56a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   1a570:	e8 5b 56 ff ff       	call   fbd0 <rcutils_logging_initialize@plt>
   1a575:	85 c0                	test   %eax,%eax
   1a577:	0f 84 8b fe ff ff    	je     1a408 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x648>
   1a57d:	48 8b 05 1c c9 02 00 	mov    0x2c91c(%rip),%rax        # 46ea0 <stderr@GLIBC_2.2.5>
   1a584:	ba 52 00 00 00       	mov    $0x52,%edx
   1a589:	be 01 00 00 00       	mov    $0x1,%esi
   1a58e:	48 8d 3d fb f1 01 00 	lea    0x1f1fb(%rip),%rdi        # 39790 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x35f0>
   1a595:	48 8b 08             	mov    (%rax),%rcx
   1a598:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   1a59d:	e8 ee 5e ff ff       	call   10490 <fwrite@plt>
   1a5a2:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   1a5a7:	48 8d 94 24 b0 00 00 	lea    0xb0(%rsp),%rdx
   1a5ae:	00 
   1a5af:	48 89 d7             	mov    %rdx,%rdi
   1a5b2:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   1a5b7:	48 8b 08             	mov    (%rax),%rcx
   1a5ba:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
   1a5bf:	e8 7c 58 ff ff       	call   fe40 <rcutils_get_error_string@plt>
   1a5c4:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   1a5c9:	e8 e2 56 ff ff       	call   fcb0 <strlen@plt>
   1a5ce:	4c 89 ff             	mov    %r15,%rdi
   1a5d1:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   1a5d6:	e8 65 58 ff ff       	call   fe40 <rcutils_get_error_string@plt>
   1a5db:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
   1a5e0:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   1a5e5:	be 01 00 00 00       	mov    $0x1,%esi
   1a5ea:	4c 89 ff             	mov    %r15,%rdi
   1a5ed:	e8 9e 5e ff ff       	call   10490 <fwrite@plt>
   1a5f2:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   1a5f7:	ba 01 00 00 00       	mov    $0x1,%edx
   1a5fc:	be 01 00 00 00       	mov    $0x1,%esi
   1a601:	48 8d 3d 36 ea 01 00 	lea    0x1ea36(%rip),%rdi        # 3903e <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e9e>
   1a608:	48 8b 08             	mov    (%rax),%rcx
   1a60b:	e8 80 5e ff ff       	call   10490 <fwrite@plt>
   1a610:	e8 9b 59 ff ff       	call   ffb0 <rcutils_reset_error@plt>
   1a615:	e9 ee fd ff ff       	jmp    1a408 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x648>
   1a61a:	e8 41 5a ff ff       	call   10060 <__stack_chk_fail@plt>
   1a61f:	89 c7                	mov    %eax,%edi
   1a621:	e8 da 57 ff ff       	call   fe00 <std::__throw_system_error(int)@plt>
   1a626:	bf 01 00 00 00       	mov    $0x1,%edi
   1a62b:	e8 d0 57 ff ff       	call   fe00 <std::__throw_system_error(int)@plt>
   1a630:	89 c7                	mov    %eax,%edi
   1a632:	e8 c9 57 ff ff       	call   fe00 <std::__throw_system_error(int)@plt>
   1a637:	f3 0f 1e fa          	endbr64 
   1a63b:	e9 62 6f ff ff       	jmp    115a2 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x10d2>
   1a640:	f3 0f 1e fa          	endbr64 
   1a644:	48 89 c5             	mov    %rax,%rbp
   1a647:	e9 b0 70 ff ff       	jmp    116fc <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x122c>
   1a64c:	f3 0f 1e fa          	endbr64 
   1a650:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   1a655:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
   1a65a:	e9 00 71 ff ff       	jmp    1175f <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x128f>
   1a65f:	f3 0f 1e fa          	endbr64 
   1a663:	48 89 c7             	mov    %rax,%rdi
   1a666:	e9 58 6f ff ff       	jmp    115c3 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x10f3>
   1a66b:	f3 0f 1e fa          	endbr64 
   1a66f:	48 89 04 24          	mov    %rax,(%rsp)
   1a673:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   1a678:	e9 fb 70 ff ff       	jmp    11778 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x12a8>
   1a67d:	f3 0f 1e fa          	endbr64 
   1a681:	48 89 c7             	mov    %rax,%rdi
   1a684:	48 89 d0             	mov    %rdx,%rax
   1a687:	e9 02 71 ff ff       	jmp    1178e <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x12be>
   1a68c:	0f 1f 40 00          	nopl   0x0(%rax)
   1a690:	41 57                	push   %r15
   1a692:	41 56                	push   %r14
   1a694:	49 89 d6             	mov    %rdx,%r14
   1a697:	41 55                	push   %r13
   1a699:	49 89 f5             	mov    %rsi,%r13
   1a69c:	4c 89 c6             	mov    %r8,%rsi
   1a69f:	41 54                	push   %r12
   1a6a1:	49 89 cc             	mov    %rcx,%r12
   1a6a4:	55                   	push   %rbp
   1a6a5:	53                   	push   %rbx
   1a6a6:	48 89 fb             	mov    %rdi,%rbx
   1a6a9:	48 8d 6b 28          	lea    0x28(%rbx),%rbp
   1a6ad:	4c 8d 7b 50          	lea    0x50(%rbx),%r15
   1a6b1:	48 81 ec a8 08 00 00 	sub    $0x8a8,%rsp
   1a6b8:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
   1a6bd:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
   1a6c4:	00 00 
   1a6c6:	48 89 84 24 98 08 00 	mov    %rax,0x898(%rsp)
   1a6cd:	00 
   1a6ce:	48 8d 05 3b ba 02 00 	lea    0x2ba3b(%rip),%rax        # 46110 <std::_Sp_make_shared_tag::_S_ti()::__tag@@Base+0x84c0>
   1a6d5:	48 89 07             	mov    %rax,(%rdi)
   1a6d8:	48 8d 47 08          	lea    0x8(%rdi),%rax
   1a6dc:	48 89 c7             	mov    %rax,%rdi
   1a6df:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   1a6e4:	e8 f7 de ff ff       	call   185e0 <nav2_rotation_shim_controller::RotationShimController::computeRotateToHeadingCommand(double const&, geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&)@@Base+0x180>
   1a6e9:	48 8d 43 60          	lea    0x60(%rbx),%rax
   1a6ed:	48 89 6b 38          	mov    %rbp,0x38(%rbx)
   1a6f1:	4c 89 ff             	mov    %r15,%rdi
   1a6f4:	48 c7 43 48 00 00 00 	movq   $0x0,0x48(%rbx)
   1a6fb:	00 
   1a6fc:	49 8b 55 08          	mov    0x8(%r13),%rdx
   1a700:	48 89 43 50          	mov    %rax,0x50(%rbx)
   1a704:	49 8b 75 00          	mov    0x0(%r13),%rsi
   1a708:	c7 43 28 00 00 00 00 	movl   $0x0,0x28(%rbx)
   1a70f:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
   1a716:	00 
   1a717:	48 01 f2             	add    %rsi,%rdx
   1a71a:	48 89 6b 40          	mov    %rbp,0x40(%rbx)
   1a71e:	e8 dd c4 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1a723:	48 8d 83 80 00 00 00 	lea    0x80(%rbx),%rax
   1a72a:	49 8b 56 08          	mov    0x8(%r14),%rdx
   1a72e:	48 8d 7b 70          	lea    0x70(%rbx),%rdi
   1a732:	48 89 43 70          	mov    %rax,0x70(%rbx)
   1a736:	49 8b 36             	mov    (%r14),%rsi
   1a739:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
   1a73e:	48 01 f2             	add    %rsi,%rdx
   1a741:	e8 ba c4 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1a746:	48 8d 83 a0 00 00 00 	lea    0xa0(%rbx),%rax
   1a74d:	49 8b 54 24 08       	mov    0x8(%r12),%rdx
   1a752:	48 8d bb 90 00 00 00 	lea    0x90(%rbx),%rdi
   1a759:	48 89 83 90 00 00 00 	mov    %rax,0x90(%rbx)
   1a760:	49 8b 34 24          	mov    (%r12),%rsi
   1a764:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
   1a769:	48 01 f2             	add    %rsi,%rdx
   1a76c:	e8 8f c4 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1a771:	48 8d 83 b0 00 00 00 	lea    0xb0(%rbx),%rax
   1a778:	31 f6                	xor    %esi,%esi
   1a77a:	48 89 c7             	mov    %rax,%rdi
   1a77d:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   1a782:	e8 a9 53 ff ff       	call   fb30 <class_loader::MultiLibraryClassLoader::MultiLibraryClassLoader(bool)@plt>
   1a787:	48 8b 05 52 c4 02 00 	mov    0x2c452(%rip),%rax        # 46be0 <g_rcutils_logging_initialized@Base>
   1a78e:	80 38 00             	cmpb   $0x0,(%rax)
   1a791:	0f 84 e9 02 00 00    	je     1aa80 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xcc0>
   1a797:	4c 8d 2d 66 e9 01 00 	lea    0x1e966(%rip),%r13        # 39104 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2f64>
   1a79e:	be 0a 00 00 00       	mov    $0xa,%esi
   1a7a3:	4c 8d 63 20          	lea    0x20(%rbx),%r12
   1a7a7:	4c 89 ef             	mov    %r13,%rdi
   1a7aa:	e8 41 57 ff ff       	call   fef0 <rcutils_logging_logger_is_enabled_for@plt>
   1a7af:	84 c0                	test   %al,%al
   1a7b1:	74 28                	je     1a7db <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xa1b>
   1a7b3:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   1a7b8:	49 89 d9             	mov    %rbx,%r9
   1a7bb:	4c 89 ea             	mov    %r13,%rdx
   1a7be:	be 0a 00 00 00       	mov    $0xa,%esi
   1a7c3:	48 8b 3d de c7 02 00 	mov    0x2c7de(%rip),%rdi        # 46fa8 <pluginlib::ClassLoader<nav2_core::Controller>::ClassLoader(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::vector<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::allocator<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > > >)::__rcutils_logging_location@@Base-0x5e8>
   1a7ca:	48 8d 0d af f2 01 00 	lea    0x1f2af(%rip),%rcx        # 39a80 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x38e0>
   1a7d1:	4c 8b 00             	mov    (%rax),%r8
   1a7d4:	31 c0                	xor    %eax,%eax
   1a7d6:	e8 05 58 ff ff       	call   ffe0 <rcutils_log@plt>
   1a7db:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
   1a7e2:	00 
   1a7e3:	4c 89 fe             	mov    %r15,%rsi
   1a7e6:	48 89 c7             	mov    %rax,%rdi
   1a7e9:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   1a7ee:	e8 1d 56 ff ff       	call   fe10 <ament_index_cpp::get_package_prefix(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&)@plt>
   1a7f3:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
   1a7fa:	00 
   1a7fb:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
   1a802:	00 
   1a803:	48 39 c7             	cmp    %rax,%rdi
   1a806:	74 11                	je     1a819 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xa59>
   1a808:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
   1a80f:	00 
   1a810:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1a814:	e8 a7 57 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1a819:	48 8b 43 10          	mov    0x10(%rbx),%rax
   1a81d:	4c 8d 74 24 60       	lea    0x60(%rsp),%r14
   1a822:	48 39 43 08          	cmp    %rax,0x8(%rbx)
   1a826:	0f 84 24 01 00 00    	je     1a950 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xb90>
   1a82c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   1a831:	48 89 de             	mov    %rbx,%rsi
   1a834:	4c 89 f7             	mov    %r14,%rdi
   1a837:	4c 8d 63 20          	lea    0x20(%rbx),%r12
   1a83b:	e8 b0 7e 00 00       	call   226f0 <std::_Function_handler<rcl_interfaces::msg::SetParametersResult_<std::allocator<void> > (std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> > const&), std::_Bind<rcl_interfaces::msg::SetParametersResult_<std::allocator<void> > (nav2_rotation_shim_controller::RotationShimController::*(nav2_rotation_shim_controller::RotationShimController*, std::_Placeholder<1>))(std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> >)> >::_M_invoke(std::_Any_data const&, std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> > const&)@@Base+0x3f00>
   1a840:	48 8b 73 30          	mov    0x30(%rbx),%rsi
   1a844:	4c 89 e7             	mov    %r12,%rdi
   1a847:	e8 84 42 00 00       	call   1ead0 <std::_Function_handler<rcl_interfaces::msg::SetParametersResult_<std::allocator<void> > (std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> > const&), std::_Bind<rcl_interfaces::msg::SetParametersResult_<std::allocator<void> > (nav2_rotation_shim_controller::RotationShimController::*(nav2_rotation_shim_controller::RotationShimController*, std::_Placeholder<1>))(std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> >)> >::_M_invoke(std::_Any_data const&, std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> > const&)@@Base+0x2e0>
   1a84c:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   1a851:	48 89 6b 38          	mov    %rbp,0x38(%rbx)
   1a855:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
   1a85c:	00 
   1a85d:	48 89 6b 40          	mov    %rbp,0x40(%rbx)
   1a861:	48 c7 43 48 00 00 00 	movq   $0x0,0x48(%rbx)
   1a868:	00 
   1a869:	48 85 c0             	test   %rax,%rax
   1a86c:	74 57                	je     1a8c5 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xb05>
   1a86e:	8b 54 24 68          	mov    0x68(%rsp),%edx
   1a872:	48 89 43 30          	mov    %rax,0x30(%rbx)
   1a876:	89 53 28             	mov    %edx,0x28(%rbx)
   1a879:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
   1a87e:	48 89 53 38          	mov    %rdx,0x38(%rbx)
   1a882:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   1a889:	00 
   1a88a:	48 89 53 40          	mov    %rdx,0x40(%rbx)
   1a88e:	48 89 68 08          	mov    %rbp,0x8(%rax)
   1a892:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
   1a899:	00 
   1a89a:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
   1a8a1:	00 00 
   1a8a3:	48 89 43 48          	mov    %rax,0x48(%rbx)
   1a8a7:	48 8d 44 24 68       	lea    0x68(%rsp),%rax
   1a8ac:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   1a8b1:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   1a8b8:	00 
   1a8b9:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
   1a8c0:	00 00 00 00 00 
   1a8c5:	31 f6                	xor    %esi,%esi
   1a8c7:	4c 89 f7             	mov    %r14,%rdi
   1a8ca:	e8 01 42 00 00       	call   1ead0 <std::_Function_handler<rcl_interfaces::msg::SetParametersResult_<std::allocator<void> > (std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> > const&), std::_Bind<rcl_interfaces::msg::SetParametersResult_<std::allocator<void> > (nav2_rotation_shim_controller::RotationShimController::*(nav2_rotation_shim_controller::RotationShimController*, std::_Placeholder<1>))(std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> >)> >::_M_invoke(std::_Any_data const&, std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> > const&)@@Base+0x2e0>
   1a8cf:	48 8b 05 0a c3 02 00 	mov    0x2c30a(%rip),%rax        # 46be0 <g_rcutils_logging_initialized@Base>
   1a8d6:	80 38 00             	cmpb   $0x0,(%rax)
   1a8d9:	0f 84 01 01 00 00    	je     1a9e0 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xc20>
   1a8df:	be 0a 00 00 00       	mov    $0xa,%esi
   1a8e4:	4c 89 ef             	mov    %r13,%rdi
   1a8e7:	e8 04 56 ff ff       	call   fef0 <rcutils_logging_logger_is_enabled_for@plt>
   1a8ec:	84 c0                	test   %al,%al
   1a8ee:	75 30                	jne    1a920 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xb60>
   1a8f0:	48 8b 84 24 98 08 00 	mov    0x898(%rsp),%rax
   1a8f7:	00 
   1a8f8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
   1a8ff:	00 00 
   1a901:	0f 85 1f 02 00 00    	jne    1ab26 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xd66>
   1a907:	48 81 c4 a8 08 00 00 	add    $0x8a8,%rsp
   1a90e:	5b                   	pop    %rbx
   1a90f:	5d                   	pop    %rbp
   1a910:	41 5c                	pop    %r12
   1a912:	41 5d                	pop    %r13
   1a914:	41 5e                	pop    %r14
   1a916:	41 5f                	pop    %r15
   1a918:	c3                   	ret    
   1a919:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   1a920:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   1a925:	49 89 d9             	mov    %rbx,%r9
   1a928:	4c 89 ea             	mov    %r13,%rdx
   1a92b:	be 0a 00 00 00       	mov    $0xa,%esi
   1a930:	48 8b 3d f1 c4 02 00 	mov    0x2c4f1(%rip),%rdi        # 46e28 <pluginlib::ClassLoader<nav2_core::Controller>::ClassLoader(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::vector<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >, std::allocator<std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > > >)::__rcutils_logging_location@@Base-0x748>
   1a937:	48 8d 0d e2 f1 01 00 	lea    0x1f1e2(%rip),%rcx        # 39b20 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3980>
   1a93e:	4c 8b 00             	mov    (%rax),%r8
   1a941:	31 c0                	xor    %eax,%eax
   1a943:	e8 98 56 ff ff       	call   ffe0 <rcutils_log@plt>
   1a948:	eb a6                	jmp    1a8f0 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xb30>
   1a94a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   1a950:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
   1a955:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
   1a95a:	4c 89 fe             	mov    %r15,%rsi
   1a95d:	4c 8d 63 20          	lea    0x20(%rbx),%r12
   1a961:	48 89 c7             	mov    %rax,%rdi
   1a964:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   1a969:	e8 12 7f 01 00       	call   32880 <std::_Function_handler<bool (char), std::__detail::_CharMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_invoke(std::_Any_data const&, char&&)@@Base+0x7670>
   1a96e:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
   1a973:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
   1a977:	4c 89 f7             	mov    %r14,%rdi
   1a97a:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
   1a981:	00 00 
   1a983:	48 8b 53 10          	mov    0x10(%rbx),%rdx
   1a987:	48 8b 43 18          	mov    0x18(%rbx),%rax
   1a98b:	48 89 73 08          	mov    %rsi,0x8(%rbx)
   1a98f:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
   1a994:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   1a999:	48 89 73 10          	mov    %rsi,0x10(%rbx)
   1a99d:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
   1a9a2:	48 89 54 24 68       	mov    %rdx,0x68(%rsp)
   1a9a7:	48 89 73 18          	mov    %rsi,0x18(%rbx)
   1a9ab:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   1a9b0:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
   1a9b7:	00 00 
   1a9b9:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
   1a9c0:	00 00 
   1a9c2:	e8 f9 b7 ff ff       	call   161c0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x450>
   1a9c7:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   1a9cc:	e8 ef b7 ff ff       	call   161c0 <nav2_rotation_shim_controller::RotationShimController::cleanup()@@Base+0x450>
   1a9d1:	e9 56 fe ff ff       	jmp    1a82c <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xa6c>
   1a9d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   1a9dd:	00 00 00 
   1a9e0:	e8 eb 51 ff ff       	call   fbd0 <rcutils_logging_initialize@plt>
   1a9e5:	85 c0                	test   %eax,%eax
   1a9e7:	0f 84 f2 fe ff ff    	je     1a8df <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xb1f>
   1a9ed:	4c 8b 35 ac c4 02 00 	mov    0x2c4ac(%rip),%r14        # 46ea0 <stderr@GLIBC_2.2.5>
   1a9f4:	ba 6b 00 00 00       	mov    $0x6b,%edx
   1a9f9:	be 01 00 00 00       	mov    $0x1,%esi
   1a9fe:	48 8d 3d ab f0 01 00 	lea    0x1f0ab(%rip),%rdi        # 39ab0 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3910>
   1aa05:	49 8b 0e             	mov    (%r14),%rcx
   1aa08:	e8 83 5a ff ff       	call   10490 <fwrite@plt>
   1aa0d:	4c 89 74 24 38       	mov    %r14,0x38(%rsp)
   1aa12:	49 8b 2e             	mov    (%r14),%rbp
   1aa15:	4c 8b 74 24 20       	mov    0x20(%rsp),%r14
   1aa1a:	4c 89 f7             	mov    %r14,%rdi
   1aa1d:	e8 1e 54 ff ff       	call   fe40 <rcutils_get_error_string@plt>
   1aa22:	4c 89 f7             	mov    %r14,%rdi
   1aa25:	4c 8d b4 24 90 04 00 	lea    0x490(%rsp),%r14
   1aa2c:	00 
   1aa2d:	e8 7e 52 ff ff       	call   fcb0 <strlen@plt>
   1aa32:	4c 89 f7             	mov    %r14,%rdi
   1aa35:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   1aa3a:	e8 01 54 ff ff       	call   fe40 <rcutils_get_error_string@plt>
   1aa3f:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   1aa44:	48 89 e9             	mov    %rbp,%rcx
   1aa47:	be 01 00 00 00       	mov    $0x1,%esi
   1aa4c:	4c 89 f7             	mov    %r14,%rdi
   1aa4f:	e8 3c 5a ff ff       	call   10490 <fwrite@plt>
   1aa54:	4c 8b 74 24 38       	mov    0x38(%rsp),%r14
   1aa59:	ba 01 00 00 00       	mov    $0x1,%edx
   1aa5e:	be 01 00 00 00       	mov    $0x1,%esi
   1aa63:	48 8d 3d d4 e5 01 00 	lea    0x1e5d4(%rip),%rdi        # 3903e <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e9e>
   1aa6a:	49 8b 0e             	mov    (%r14),%rcx
   1aa6d:	e8 1e 5a ff ff       	call   10490 <fwrite@plt>
   1aa72:	e8 39 55 ff ff       	call   ffb0 <rcutils_reset_error@plt>
   1aa77:	e9 63 fe ff ff       	jmp    1a8df <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xb1f>
   1aa7c:	0f 1f 40 00          	nopl   0x0(%rax)
   1aa80:	4c 8d 63 20          	lea    0x20(%rbx),%r12
   1aa84:	e8 47 51 ff ff       	call   fbd0 <rcutils_logging_initialize@plt>
   1aa89:	85 c0                	test   %eax,%eax
   1aa8b:	0f 84 06 fd ff ff    	je     1a797 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x9d7>
   1aa91:	4c 8b 35 08 c4 02 00 	mov    0x2c408(%rip),%r14        # 46ea0 <stderr@GLIBC_2.2.5>
   1aa98:	ba 6a 00 00 00       	mov    $0x6a,%edx
   1aa9d:	be 01 00 00 00       	mov    $0x1,%esi
   1aaa2:	48 8d 3d 67 ef 01 00 	lea    0x1ef67(%rip),%rdi        # 39a10 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3870>
   1aaa9:	49 8b 0e             	mov    (%r14),%rcx
   1aaac:	e8 df 59 ff ff       	call   10490 <fwrite@plt>
   1aab1:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
   1aab8:	00 
   1aab9:	4c 89 74 24 38       	mov    %r14,0x38(%rsp)
   1aabe:	4d 8b 2e             	mov    (%r14),%r13
   1aac1:	48 89 c7             	mov    %rax,%rdi
   1aac4:	49 89 c6             	mov    %rax,%r14
   1aac7:	e8 74 53 ff ff       	call   fe40 <rcutils_get_error_string@plt>
   1aacc:	4c 89 f7             	mov    %r14,%rdi
   1aacf:	4c 8d b4 24 90 04 00 	lea    0x490(%rsp),%r14
   1aad6:	00 
   1aad7:	e8 d4 51 ff ff       	call   fcb0 <strlen@plt>
   1aadc:	4c 89 f7             	mov    %r14,%rdi
   1aadf:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   1aae4:	e8 57 53 ff ff       	call   fe40 <rcutils_get_error_string@plt>
   1aae9:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   1aaee:	4c 89 e9             	mov    %r13,%rcx
   1aaf1:	be 01 00 00 00       	mov    $0x1,%esi
   1aaf6:	4c 89 f7             	mov    %r14,%rdi
   1aaf9:	e8 92 59 ff ff       	call   10490 <fwrite@plt>
   1aafe:	4c 8b 74 24 38       	mov    0x38(%rsp),%r14
   1ab03:	ba 01 00 00 00       	mov    $0x1,%edx
   1ab08:	be 01 00 00 00       	mov    $0x1,%esi
   1ab0d:	48 8d 3d 2a e5 01 00 	lea    0x1e52a(%rip),%rdi        # 3903e <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e9e>
   1ab14:	49 8b 0e             	mov    (%r14),%rcx
   1ab17:	e8 74 59 ff ff       	call   10490 <fwrite@plt>
   1ab1c:	e8 8f 54 ff ff       	call   ffb0 <rcutils_reset_error@plt>
   1ab21:	e9 71 fc ff ff       	jmp    1a797 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x9d7>
   1ab26:	e8 35 55 ff ff       	call   10060 <__stack_chk_fail@plt>
   1ab2b:	f3 0f 1e fa          	endbr64 
   1ab2f:	48 89 c5             	mov    %rax,%rbp
   1ab32:	4c 8d 63 20          	lea    0x20(%rbx),%r12
   1ab36:	e9 e3 6d ff ff       	jmp    1191e <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x144e>
   1ab3b:	f3 0f 1e fa          	endbr64 
   1ab3f:	48 89 c5             	mov    %rax,%rbp
   1ab42:	4c 8d 63 20          	lea    0x20(%rbx),%r12
   1ab46:	e9 c1 6d ff ff       	jmp    1190c <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x143c>
   1ab4b:	f3 0f 1e fa          	endbr64 
   1ab4f:	48 89 c5             	mov    %rax,%rbp
   1ab52:	4c 8d 63 20          	lea    0x20(%rbx),%r12
   1ab56:	e9 a7 6d ff ff       	jmp    11902 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1432>
   1ab5b:	f3 0f 1e fa          	endbr64 
   1ab5f:	48 89 c5             	mov    %rax,%rbp
   1ab62:	e9 91 6d ff ff       	jmp    118f8 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1428>
   1ab67:	f3 0f 1e fa          	endbr64 
   1ab6b:	48 89 c5             	mov    %rax,%rbp
   1ab6e:	4c 8d 63 20          	lea    0x20(%rbx),%r12
   1ab72:	e9 9f 6d ff ff       	jmp    11916 <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x1446>
   1ab77:	f3 0f 1e fa          	endbr64 
   1ab7b:	48 89 c7             	mov    %rax,%rdi
   1ab7e:	48 89 d0             	mov    %rdx,%rax
   1ab81:	e9 b6 6d ff ff       	jmp    1193c <std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> >::find_last_of(char const*, unsigned long, unsigned long) const@plt+0x146c>
   1ab86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   1ab8d:	00 00 00 
   1ab90:	f3 0f 1e fa          	endbr64 
   1ab94:	41 56                	push   %r14
   1ab96:	41 55                	push   %r13
   1ab98:	41 54                	push   %r12
   1ab9a:	55                   	push   %rbp
   1ab9b:	53                   	push   %rbx
   1ab9c:	48 89 fb             	mov    %rdi,%rbx
   1ab9f:	48 81 ec 10 08 00 00 	sub    $0x810,%rsp
   1aba6:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
   1abad:	00 00 
   1abaf:	48 89 84 24 08 08 00 	mov    %rax,0x808(%rsp)
   1abb6:	00 
   1abb7:	48 8d 05 52 b5 02 00 	lea    0x2b552(%rip),%rax        # 46110 <std::_Sp_make_shared_tag::_S_ti()::__tag@@Base+0x84c0>
   1abbe:	48 89 07             	mov    %rax,(%rdi)
   1abc1:	48 8b 05 18 c0 02 00 	mov    0x2c018(%rip),%rax        # 46be0 <g_rcutils_logging_initialized@Base>
   1abc8:	80 38 00             	cmpb   $0x0,(%rax)
   1abcb:	0f 84 af 01 00 00    	je     1ad80 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xfc0>
   1abd1:	4c 8d 25 2c e5 01 00 	lea    0x1e52c(%rip),%r12        # 39104 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2f64>
   1abd8:	be 0a 00 00 00       	mov    $0xa,%esi
   1abdd:	4c 89 e7             	mov    %r12,%rdi
   1abe0:	e8 0b 53 ff ff       	call   fef0 <rcutils_logging_logger_is_enabled_for@plt>
   1abe5:	84 c0                	test   %al,%al
   1abe7:	0f 85 13 01 00 00    	jne    1ad00 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xf40>
   1abed:	48 8d bb b0 00 00 00 	lea    0xb0(%rbx),%rdi
   1abf4:	e8 d7 57 ff ff       	call   103d0 <class_loader::MultiLibraryClassLoader::~MultiLibraryClassLoader()@plt>
   1abf9:	48 8b bb 90 00 00 00 	mov    0x90(%rbx),%rdi
   1ac00:	48 8d 83 a0 00 00 00 	lea    0xa0(%rbx),%rax
   1ac07:	48 39 c7             	cmp    %rax,%rdi
   1ac0a:	74 10                	je     1ac1c <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xe5c>
   1ac0c:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
   1ac13:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1ac17:	e8 a4 53 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1ac1c:	48 8b 7b 70          	mov    0x70(%rbx),%rdi
   1ac20:	48 8d 83 80 00 00 00 	lea    0x80(%rbx),%rax
   1ac27:	48 39 c7             	cmp    %rax,%rdi
   1ac2a:	74 10                	je     1ac3c <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xe7c>
   1ac2c:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
   1ac33:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1ac37:	e8 84 53 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1ac3c:	48 8b 7b 50          	mov    0x50(%rbx),%rdi
   1ac40:	48 8d 43 60          	lea    0x60(%rbx),%rax
   1ac44:	48 39 c7             	cmp    %rax,%rdi
   1ac47:	74 0d                	je     1ac56 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xe96>
   1ac49:	48 8b 43 60          	mov    0x60(%rbx),%rax
   1ac4d:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1ac51:	e8 6a 53 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1ac56:	48 8b 73 30          	mov    0x30(%rbx),%rsi
   1ac5a:	48 8d 7b 20          	lea    0x20(%rbx),%rdi
   1ac5e:	e8 6d 3e 00 00       	call   1ead0 <std::_Function_handler<rcl_interfaces::msg::SetParametersResult_<std::allocator<void> > (std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> > const&), std::_Bind<rcl_interfaces::msg::SetParametersResult_<std::allocator<void> > (nav2_rotation_shim_controller::RotationShimController::*(nav2_rotation_shim_controller::RotationShimController*, std::_Placeholder<1>))(std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> >)> >::_M_invoke(std::_Any_data const&, std::vector<rclcpp::Parameter, std::allocator<rclcpp::Parameter> > const&)@@Base+0x2e0>
   1ac63:	4c 8b 63 10          	mov    0x10(%rbx),%r12
   1ac67:	48 8b 6b 08          	mov    0x8(%rbx),%rbp
   1ac6b:	49 39 ec             	cmp    %rbp,%r12
   1ac6e:	74 27                	je     1ac97 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xed7>
   1ac70:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
   1ac74:	48 8d 45 10          	lea    0x10(%rbp),%rax
   1ac78:	48 39 c7             	cmp    %rax,%rdi
   1ac7b:	74 0d                	je     1ac8a <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xeca>
   1ac7d:	48 8b 45 10          	mov    0x10(%rbp),%rax
   1ac81:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1ac85:	e8 36 53 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1ac8a:	48 83 c5 20          	add    $0x20,%rbp
   1ac8e:	49 39 ec             	cmp    %rbp,%r12
   1ac91:	75 dd                	jne    1ac70 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xeb0>
   1ac93:	48 8b 6b 08          	mov    0x8(%rbx),%rbp
   1ac97:	48 85 ed             	test   %rbp,%rbp
   1ac9a:	74 3c                	je     1acd8 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xf18>
   1ac9c:	48 8b 84 24 08 08 00 	mov    0x808(%rsp),%rax
   1aca3:	00 
   1aca4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
   1acab:	00 00 
   1acad:	0f 85 5c 01 00 00    	jne    1ae0f <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x104f>
   1acb3:	48 8b 73 18          	mov    0x18(%rbx),%rsi
   1acb7:	48 81 c4 10 08 00 00 	add    $0x810,%rsp
   1acbe:	48 89 ef             	mov    %rbp,%rdi
   1acc1:	5b                   	pop    %rbx
   1acc2:	48 29 ee             	sub    %rbp,%rsi
   1acc5:	5d                   	pop    %rbp
   1acc6:	41 5c                	pop    %r12
   1acc8:	41 5d                	pop    %r13
   1acca:	41 5e                	pop    %r14
   1accc:	e9 ef 52 ff ff       	jmp    ffc0 <operator delete(void*, unsigned long)@plt>
   1acd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   1acd8:	48 8b 84 24 08 08 00 	mov    0x808(%rsp),%rax
   1acdf:	00 
   1ace0:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
   1ace7:	00 00 
   1ace9:	0f 85 20 01 00 00    	jne    1ae0f <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0x104f>
   1acef:	48 81 c4 10 08 00 00 	add    $0x810,%rsp
   1acf6:	5b                   	pop    %rbx
   1acf7:	5d                   	pop    %rbp
   1acf8:	41 5c                	pop    %r12
   1acfa:	41 5d                	pop    %r13
   1acfc:	41 5e                	pop    %r14
   1acfe:	c3                   	ret    
   1acff:	90                   	nop
   1ad00:	48 8b 73 70          	mov    0x70(%rbx),%rsi
   1ad04:	48 8b 53 78          	mov    0x78(%rbx),%rdx
   1ad08:	48 8d bc 24 00 04 00 	lea    0x400(%rsp),%rdi
   1ad0f:	00 
   1ad10:	48 8d ac 24 10 04 00 	lea    0x410(%rsp),%rbp
   1ad17:	00 
   1ad18:	48 89 ac 24 00 04 00 	mov    %rbp,0x400(%rsp)
   1ad1f:	00 
   1ad20:	48 01 f2             	add    %rsi,%rdx
   1ad23:	e8 d8 be 01 00       	call   36c00 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0xa60>
   1ad28:	49 89 d9             	mov    %rbx,%r9
   1ad2b:	4c 89 e2             	mov    %r12,%rdx
   1ad2e:	be 0a 00 00 00       	mov    $0xa,%esi
   1ad33:	48 8b 3d 26 c2 02 00 	mov    0x2c226(%rip),%rdi        # 46f60 <pluginlib::ClassLoader<nav2_core::Controller>::~ClassLoader()::__rcutils_logging_location@@Base-0x5f0>
   1ad3a:	4c 8b 84 24 00 04 00 	mov    0x400(%rsp),%r8
   1ad41:	00 
   1ad42:	48 8d 0d 87 ee 01 00 	lea    0x1ee87(%rip),%rcx        # 39bd0 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x3a30>
   1ad49:	31 c0                	xor    %eax,%eax
   1ad4b:	e8 90 52 ff ff       	call   ffe0 <rcutils_log@plt>
   1ad50:	48 8b bc 24 00 04 00 	mov    0x400(%rsp),%rdi
   1ad57:	00 
   1ad58:	48 39 ef             	cmp    %rbp,%rdi
   1ad5b:	0f 84 8c fe ff ff    	je     1abed <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xe2d>
   1ad61:	48 8b 84 24 10 04 00 	mov    0x410(%rsp),%rax
   1ad68:	00 
   1ad69:	48 8d 70 01          	lea    0x1(%rax),%rsi
   1ad6d:	e8 4e 52 ff ff       	call   ffc0 <operator delete(void*, unsigned long)@plt>
   1ad72:	e9 76 fe ff ff       	jmp    1abed <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xe2d>
   1ad77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   1ad7e:	00 00 
   1ad80:	e8 4b 4e ff ff       	call   fbd0 <rcutils_logging_initialize@plt>
   1ad85:	85 c0                	test   %eax,%eax
   1ad87:	0f 84 44 fe ff ff    	je     1abd1 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xe11>
   1ad8d:	48 8b 2d 0c c1 02 00 	mov    0x2c10c(%rip),%rbp        # 46ea0 <stderr@GLIBC_2.2.5>
   1ad94:	ba 6b 00 00 00       	mov    $0x6b,%edx
   1ad99:	be 01 00 00 00       	mov    $0x1,%esi
   1ad9e:	49 89 e4             	mov    %rsp,%r12
   1ada1:	48 8d 3d b8 ed 01 00 	lea    0x1edb8(%rip),%rdi        # 39b60 <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x39c0>
   1ada8:	4c 8d ac 24 00 04 00 	lea    0x400(%rsp),%r13
   1adaf:	00 
   1adb0:	48 8b 4d 00          	mov    0x0(%rbp),%rcx
   1adb4:	e8 d7 56 ff ff       	call   10490 <fwrite@plt>
   1adb9:	4c 89 e7             	mov    %r12,%rdi
   1adbc:	4c 8b 75 00          	mov    0x0(%rbp),%r14
   1adc0:	e8 7b 50 ff ff       	call   fe40 <rcutils_get_error_string@plt>
   1adc5:	4c 89 e7             	mov    %r12,%rdi
   1adc8:	e8 e3 4e ff ff       	call   fcb0 <strlen@plt>
   1adcd:	4c 89 ef             	mov    %r13,%rdi
   1add0:	49 89 c4             	mov    %rax,%r12
   1add3:	e8 68 50 ff ff       	call   fe40 <rcutils_get_error_string@plt>
   1add8:	4c 89 f1             	mov    %r14,%rcx
   1addb:	4c 89 e2             	mov    %r12,%rdx
   1adde:	4c 89 ef             	mov    %r13,%rdi
   1ade1:	be 01 00 00 00       	mov    $0x1,%esi
   1ade6:	e8 a5 56 ff ff       	call   10490 <fwrite@plt>
   1adeb:	48 8b 4d 00          	mov    0x0(%rbp),%rcx
   1adef:	ba 01 00 00 00       	mov    $0x1,%edx
   1adf4:	be 01 00 00 00       	mov    $0x1,%esi
   1adf9:	48 8d 3d 3e e2 01 00 	lea    0x1e23e(%rip),%rdi        # 3903e <std::_Function_handler<bool (char), std::__detail::_BracketMatcher<std::__cxx11::regex_traits<char>, true, true> >::_M_manager(std::_Any_data&, std::_Any_data const&, std::_Manager_operation)@@Base+0x2e9e>
   1ae00:	e8 8b 56 ff ff       	call   10490 <fwrite@plt>
   1ae05:	e8 a6 51 ff ff       	call   ffb0 <rcutils_reset_error@plt>
   1ae0a:	e9 c2 fd ff ff       	jmp    1abd1 <nav2_rotation_shim_controller::RotationShimController::computeVelocityCommands(geometry_msgs::msg::PoseStamped_<std::allocator<void> > const&, geometry_msgs::msg::Twist_<std::allocator<void> > const&, nav2_core::GoalChecker*)@@Base+0xe11>
   1ae0f:	e8 4c 52 ff ff       	call   10060 <__stack_chk_fail@plt>
   1ae14:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   1ae1b:	00 00 00 00 
   1ae1f:	90                   	nop
