# V68 最小刺激缺口描述草案（仅源码，未执行）

V67 的原始 FAIL 保持：Root57699/rc1，32/32 transition 返回后，固定 v2 刺激覆盖不足；阶段科学审计没有派发。当前稿没有打开 transitions、summary、adapter 或 motion 原件，没有实现或运行 consumer，不提供科学、物理、资格或容量信用。

首轮固定两份原件：interface 的 `worker0/episode001_open_101/transitions.jsonl` 与同 run 的 `benchmark_summary.json`。不加 adapter/motion。前者有完整初始 reset 和每次 step 的 snapshot/command；后者已持久化 producer 的 rounds、32条 planned decisions、coverage_failures。closure 的实际 inventory 与 ledger 物化后，再按 original 精确路径填 encoded bytes/SHA、epoch、实际前账 pin。当前 admitted=False，不能先为填 pin 读取原件，也不能消费 archive 重压包装替代 original。

拟 cap：transitions 4MiB、summary 256KiB，总4.25MiB；JSONL最多64个非空对象，预期1reset+32step。输出1MiB，最多33快照、792个(快照,机器人,8候选)谓词行、6个(robot,round)汇总。consumer work60秒/完整parent120秒只是后继资源候选；每份原件完整字节必须计入成本并完整SHA，不按命中行计费。两原件从固定 inventory 选取、regular/canonical/nosymlink，读前后稳定；不得目录发现或gzip后缀fallback。任何缺字段/额外行/类型不符/超限均保留INCOMPLETE及实际费用，不伪造完整解释。

## 先确认已有缺项，再解释最早可区分条件

1. 从 `workers_results[0].episodes[0].preparation_probe_diagnostics.reach_v2_stimulus` 提取 `rounds.initial/second.tb1/tb2/tb3`、`decisions`、`coverage_failures`、`coverage_passed`。逐字段保留 missing、None、False、0、[] 的区别，不把缺robot key补成空候选。六组依原 finish 判据分别报告 goal_command_id、accepted_at_ns、wait_command_id、cancel_terminal_observed_ns、三次fresh rest；initial另需handoff_observed_ns。producer 的报告只作为原声明，必须和下面原 transition 字段交叉核。
2. 用 reset 的 snapshot 作为 decision0；step[i].info.command 的 epoch/observation_sequence/observation_digest/action/created_at 必须匹配前一个 snapshot。step[i].snapshot 是后一个观测。不能把本步command错配本步post-snapshot。32个命令应对应前32观测；最后第33个snapshot只用于finish，不生成第33次动作。summary的planned decision还需精确seq/digest/clock/action join，不仅按列表索引。action_submitted=False、command=None或命令字段缺失原样记录，不自行视为提交。
3. 每个合法GOAL窗口逐机器人拆开原谓词，不只读 eligible=[]：goal_window(task<1.5s或13<=task<20s)、当前round无已有goal_command_id、nav.phase==idle、owned=False、fresh/valid、path数字且path_observation_complete=True、第二轮已观察initial handoff；再逐候选记录原 per_robot_action_mask、候选valid/reachable/path_distances_m、finite x/y与机器人坐标、path_distance>0、hypot(endpoint-own)>1.45。**1.45是名义端点直线screen，不是安全半径、真实路径/寿命保证，也不是path_distance门。**随后分别计算含此候选的joint mask、其他机器人desired组件、原nonapproaching条件是否留下合法joint动作，再按原rank描述是否被选。原8候选均须可复核，不能只输出选中候选。
4. 对已有真实提交GOAL再描述接受/移动/WAIT：同goal_id+owned=True+active/canceling+finite accepted_at<=now+accepted_goal_count>0，接受不得早于created，initial接受task<=2秒/second<=20秒。moving要求fresh+valid、phase active、owned、同saved goal_id、已accepted、**v>=.08**、path_observation_complete、累计received path减GOAL提交前baseline>=.05，并且原per_robot_action_mask[i][9]为True、还没科学WAIT。记录navigation.commitment_until/remaining与diagnostics.mask_reasons，包括原minimum_commitment；不改原5秒承诺期，不把负向速度abs(v)>=.08代替v>=.08。
5. 分类first legal moving WAIT与纯cleanup WAIT。cleanup为10<=task<13或task>=28，合法数字9可被提交，但理由`bounded_cleanup_wait_no_credit`不能填科学wait_command_id；initial科学WAIT任务时刻>10/second>28会原样计失败。`info.command`只能证明action已发给adapter，不能证明adapter实际接受/执行。
6. 接收态取消确认：同saved goal的cancel_requested/stop_reason=wait，再观察last_goal_id同值、last_terminal=CANCELED、phase idle、owned=False；三次distinct increasing odom_source_stamp、fresh/valid、abs(v)<=.01、同last_goal、idle/unowned才是producer接收态rest，且距cancel_terminal观察>=3秒才initial handoff。它不是高频actual motor零、角速度静止或独立physical B证明。若根本未满足GOAL提交条件，后续accept/WAIT/cancel/rest缺项标为下游未触发，不假造取消延迟归因。

输出每个条件第一次满足/每个窗口阻断计数、最大endpoint距离/可达候选计数、原动作与原mask、必要少量原line/seq/digest指针；不要输出完整snapshot数组或新造跨进程wall总序。只凭这些已接收快照不能重建两快照之间的真实运动或动作callback。任何原因不能从字段区分时明确UNKNOWN；尤其“没有GOAL”不能推出Nav2/authority/plant坏，也不能用cleanup WAIT替代cancel证据。

## 为什么现在不加第三条流

transitions记录的是原1秒采样决策输入和返回命令，足够先区分：候选/路径缺失、endpoint<=1.45、原mask/commitment、joint/nonapproaching过滤、已有owner、首轮handoff不足、接受/速度/path条件不达标。若原summary显示未发任何GOAL，优先解释GOAL最早门，不必读motion来猜后果。

只有后续问题明确涉及实际callback/submit结果/native cancellation/authority时，才另封新固定adapter scope：`action.payload.results/choices`、`native_send`、`native_cancel`、实际UUIDaccept callback、原delivery、authority publication/terminal buffer/later dispatch。涉及raw→guard→storage/APPLIED或物理rest，则还需独立新固定motion/drive/odom源，不在本次scope追加；原physical B/R、STOP debt和initial servo latch保持。

## 源码依据（7源完整SHA另存interpretation_sources_v1.json）

- benchmark.py:397–545 原GOAL/WAIT筛选与planned decision；558–590真实returned command关联；593–620原六组finish覆盖门。
- benchmark.py:995–1018 异常后finally仍写worker_summary；1256–1275把workers_results完整写benchmark_summary。
- Supervisor.step:446–461 原RPC结果作为last_result，未重写snapshot。
- worker:1459–1480 reset记录；1512–1518 command绑定前snapshot；1559–1567 step记录post-snapshot。
- mr3_observation.py:148–220 received robot/navigation/activity字段；745–807原per/joint mask和minimum_commitment；985–1020最终快照保存字段。
- mr3_protocol.py:403–423 navigation ownership/accepted/commitment/cancel/terminal字段。mr3_activity.py记录delivered odom chord估计，不是真实连续物理路程。

CLI只有后继固定canonical consumer的 `--freeze HEX --spec A68/description_spec_v1.json --output /tmp/mr3_p2a_v68_probe_stimulus_description_v1.json`，完整候选argv在scope JSON。没有任意input、目录、window、robot、阈值或运行器开关。consumer、两原件pins、完整parent、真实CPU/source/absence、新freeze均尚待Root后继封定；不能凭本草案执行。保持32步/六GOAL/两轮、原5秒commit、physical B/R/HOLD与所有旧FAIL。未来新qualification child argv应修正为原gate接受的child `python -m ...`，outer -B与env保持；这是独立后继接线修复，不重判当前无资格活动。
