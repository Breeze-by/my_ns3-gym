"""Exact execution receipt wrapper; no simulator or middleware calls."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


SOURCE = Path("/tmp/mr3_p2a0_v18_closed_observer_diagnostic_v1.py")
ROOT = Path("/home/zhuyulab/ns3-workspace")
TARGET = Path("/tmp/mr3_p2a0_v18_closed_observer_diagnostic_v1")
EPISODE = ROOT / ("ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/"
                  "mr3_p2a0_20261018_v18_baseline/worker0/episode001_open_101")
before = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
env = os.environ.copy()
env.update(PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1")
argv = ["/usr/bin/python3", str(SOURCE), str(EPISODE), "--output-directory", str(TARGET)]
started = time.monotonic()
stdout = Path("/tmp/mr3_p2a0_v18_closed_observer_diagnostic_v1.stdout")
stderr = Path("/tmp/mr3_p2a0_v18_closed_observer_diagnostic_v1.stderr")
with stdout.open("xb") as out, stderr.open("xb") as err:
    run = subprocess.run(argv, cwd=ROOT, env=env, stdout=out, stderr=err)
result = {"argv": argv, "cwd": str(ROOT),
          "environment": {key: env[key] for key in ("PYTHONDONTWRITEBYTECODE", "PYTHONNOUSERSITE")},
          "exit_code": run.returncode, "wall_seconds": time.monotonic() - started,
          "source_before_sha256": before,
          "source_after_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
          "wrapper_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          "stdout": str(stdout), "stdout_sha256": hashlib.sha256(stdout.read_bytes()).hexdigest(),
          "stderr": str(stderr), "stderr_sha256": hashlib.sha256(stderr.read_bytes()).hexdigest(),
          "scope": "Postmortem only; original V18 FAIL and missing live admission remain unchanged."}
Path("/tmp/mr3_p2a0_v18_closed_observer_diagnostic_execution_v1.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result), flush=True)
