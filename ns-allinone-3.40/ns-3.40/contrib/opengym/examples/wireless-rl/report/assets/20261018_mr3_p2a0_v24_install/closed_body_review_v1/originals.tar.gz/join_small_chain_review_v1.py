#!/usr/bin/python3
"""Independent arithmetic/context review of stable small V24 forensic products."""
from pathlib import Path
import hashlib
import json
import math

D = Path('/tmp/mr3_p2a0_v24_body_trigger_independent_v1')
CHAIN = Path('/tmp/mr3_p2a0_v24_model_fault_review_v1/chain_review_v1.json')
CHAIN_SHA = '44efd14c15533dc8e35b29350d387e98e36edae033eae26ec45a23b383da90df'


def bound(path):
    s = path.stat()
    raw = path.read_bytes()
    t = path.stat()
    assert (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns) == (t.st_dev, t.st_ino, t.st_size, t.st_mtime_ns, t.st_ctime_ns)
    return raw, {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw),
                 'stat': [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns]}


def main():
    inputs = [Path(__file__), D / 'body_formal_review_v1.json', CHAIN]
    captured = [bound(p) for p in inputs]
    assert captured[2][1]['sha256'] == CHAIN_SHA
    body, chain = (json.loads(x[0]) for x in captured[1:])
    assert body['fault']['raw_line_sha256'] == chain['fault_original']['sha256']
    motion_key = next(k for k in chain['input_bindings'] if k.endswith('/motion_safety.jsonl'))
    assert body['whole_motion_identity_from_original_consumer_and_roundtrip_custody']['sha256'] == chain['input_bindings'][motion_key]['sha256']
    cfg = chain['driver_configuration']
    assert cfg['wheel_order'] == ['right', 'left'] and cfg['wheel_separation_m'] == [0.287]
    assert cfg['max_acceleration_mps2'] == 1.0
    rows = chain['actuation']
    assert len(rows) == 64
    for r in rows:
        for field in ('current_rim_mps', 'applied_rim_mps', 'desired_rim_mps'):
            assert len(r[field]) == 2 and all(math.isfinite(x) for x in r[field])
        for field, stored in [('current_rim_mps', 'wheel_current_yaw_proxy_radps'),
                              ('applied_rim_mps', 'wheel_applied_yaw_proxy_radps'),
                              ('desired_rim_mps', 'wheel_desired_yaw_radps')]:
            assert (r[field][0] - r[field][1]) / 0.287 == r[stored]
    peak = chain['same_clock_peak_actuation'][0]
    assert peak['sim_time_ns'] == body['trigger_sample']['source_ns']
    assert chain['latest_received_tuple_matches_every_window_actuation'] is True
    assert chain['actual_incoming_commands']['caps_pass'] is True
    transition = [r for r in rows if 56662000000 <= r['sim_time_ns'] <= 56764000000]
    mixed = [r for r in transition if r['desired_v'] != 0]
    slopes = [{'prior_ns': a['sim_time_ns'], 'current_ns': b['sim_time_ns'],
               'desired_v_delta_per_sim_second': (b['desired_v'] - a['desired_v']) / ((b['sim_time_ns'] - a['sim_time_ns']) / 1e9)}
              for a,b in zip(transition, transition[1:])]
    result = {
        'schema': 'mr3-v24-body-drive-context-independent-review-v1',
        'scope': 'Small closed products only; exact wheel-proxy arithmetic checked independently, no original large trace rescan, no tests/native/formal or causal proof.',
        'input_bindings': [x[1] for x in captured], 'body_fault_raw_line_sha256': body['fault']['raw_line_sha256'],
        'original_formal_angular_passed': False, 'original_formal_physics_passed': False,
        'transition_actuation_samples': transition, 'sampled_desired_input_slopes': slopes,
        'peak_same_source_actuation': peak, 'peak_body_sample': body['trigger_sample'],
        'first_zero_storage_after_fault': chain['first_zero_storage_after_fault'],
        'all_64_actuations_match_actual_latest_target': True,
        'maximum_abs_current_joint_yaw_proxy_in_window': max(abs(x['wheel_current_yaw_proxy_radps']) for x in rows),
        'maximum_abs_applied_command_yaw_proxy_in_window': max(abs(x['wheel_applied_yaw_proxy_radps']) for x in rows),
        'findings_zh': [
            '56.662s纯转desired(0,-.8)时，joint-current yaw proxy已-.8841089，尚未触机体1.2界。56.696–56.764s目标线速度从.1升至.2，angular目标同时减小；body和wheel current仍继续向负角速增长。',
            '同56.968s，desired(.2,-.378947)、current wheel proxy-1.224470、applied proxy-1.101559，与raw body-1.206191相邻对应；三者不是应逐值相等的同一个物理量。',
            'desired命令均遵守.2/.8，真实latest目标逐tuple匹配，不支持旧命令滞后/符号反转/最终gate放大作为本window原因。',
            '当前反馈起点已在名义命令角速盒外，凸组合可继续给出|applied yaw proxy|>.8；这不违反原每rim相对current的增量性质，也不形成body1.2定理。',
            '峰值时目标右rim为正而current/applied右rim仍负。该servo/接触/惯性响应与转入平移过渡值得优先核验；当前记录不能唯一确定接触或solver原因。',
            '故障后的zero真实存入56.98s；57.002s wheel current proxy仍增至-1.26187，而body raw已回落到-1.19666。不能以joint proxy替代原body门或只因zero已存即假定rest。'
        ],
        'prospective_repair_options': [
            {'option': '实际simtime转向到平移过渡约束',
             'basis': '同一窗口desired_v离散增量约1.47–2.94m/s²，body在目标减小turn时继续增速；当前walltimer/profile参数并不自行证明simtime输入斜率。',
             'requirements': '保持硬零立即发布/原actuator制动规则；需直接使用实际source/simtime、actual target identity、无新方向/探索fallback，并以新冻结完整原矩阵验证。',
             'limit': '这是优先设计假设；尚无反事实native或充分body界证明。'},
            {'option': '真实joint servo控制律的有限模型审查',
             'basis': 'actual current→desired paired反馈可保留与目标相反的轮速符号；当前逐rim步长性质没有保证轮速或机体进入名义角速盒。',
             'requirements': '任何新法必须同时保留原rim加速度/命令因果/硬零制动含义，先检查冲突与不可行状态，不得直接投影后声称步长仍成立。',
             'limit': '不能仅凭当前raw区分motor/inertia/slip，也不能擅改robot质量/friction/solver来消除失败。'},
            {'option': '降低command angular profile留真实余量',
             'basis': 'pure turn阶段出现约.884对.8的响应，mixed阶段进一步上升；较低目标可能有余量。',
             'requirements': '若采用必须明确新profile及真实native验证，不改measured1.2/accel7/其余原门。',
             'limit': '不可比例预测最大body响应或把一次降低cap作为已修充分证据。'}],
        'unchanged_gates': {'body_planar_mps': 0.30, 'body_angular_radps': 1.2, 'sampled_angular_accel_radps2': 7,
                            'stop_horizon_sec': 0.78, 'path_reserve_m': 0.144, 'rest_mps': 0.01, 'rest_samples': 3},
        'no_canonical_or_source_change': True}
    assert [x[1] for x in captured] == [bound(p)[1] for p in inputs]
    result['inputs_end_stable'] = True
    out = D / 'body_drive_context_review_v1.json'
    assert not out.exists()
    out.write_text(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    print(json.dumps({'output': str(out), 'sha256': hashlib.sha256(out.read_bytes()).hexdigest(), 'inputs_end_stable': True}))

if __name__ == '__main__':
    main()
