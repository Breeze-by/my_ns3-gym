"""Offline proposal only: exact captured counterexample and native-free phase semantics."""
import ast
from collections import OrderedDict
import copy
import importlib.util
import json
import math
from pathlib import Path
import sys
from types import ModuleType, SimpleNamespace
import unittest

HERE=Path(__file__).resolve().parent
PACKAGE="multi_robot_exploration"
pkg=ModuleType(PACKAGE);pkg.__path__=[];sys.modules[PACKAGE]=pkg
def load(name,filename):
 spec=importlib.util.spec_from_file_location(PACKAGE+"."+name,HERE/filename)
 module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module);return module
load("mr3_episode","original_mr3_episode.py")
load("mr3_drive_phase","original_mr3_drive_phase.py")
CLIENT=load("mr3_control_phase","original_mr3_control_phase.py")
OLD=load("old_motion","original_mr3_motion_safety.py")
NEW=load("new_motion","proposed_mr3_motion_safety.py")
FIXTURE=json.loads((HERE/"actual_peak_fixture.json").read_text())
EPOCH="synthetic_velocity_proposal"
def state(vx=.1,vy=0., *,raw=False,w=0.,scalar=True):
 value={"name":"tb1","epoch":EPOCH,"valid":True,"x":0.,"y":0.,"yaw":0.,"v":vx,"w":w,"source_stamp":10.,"odom_source_stamp":10.,"tf_source_stamp":10.}
 if scalar:value["planar_speed_mps"]=math.hypot(vx,vy)
 if raw:value["odometry"]={"twist":{"twist":{"linear":{"x":vx,"y":vy,"z":0.},"angular":{"x":0.,"y":0.,"z":w}}}}
 return value

def phase(filename, *,halted="normal_control_model_invalid",operation="commit",fail_inside=False,terminal=False,model_check=None,target_ns=20_000_000_000):
 tree=ast.parse((HERE/filename).read_text());cls=next(x for x in tree.body if isinstance(x,ast.ClassDef)and x.name=="MotionControlPhase")
 wanted={"poll_once","ensure_stop","record","finish","publish_ack"}
 methods=[x for x in cls.body if isinstance(x,ast.FunctionDef)and x.name in wanted]
 ns={"OrderedDict":OrderedDict,"copy":copy,"monotonic":lambda:0.,"monotonic_ns":lambda:1,"WALL_GUARD_SEC":10.,"canonical":CLIENT.canonical,"String":lambda **kw:SimpleNamespace(**kw)}
 compiled=ast.ClassDef(name="ActualPhase",bases=[],keywords=[],body=methods,decorator_list=[])
 ast.fix_missing_locations(compiled);exec(compile(ast.Module(body=[compiled],type_ignores=[]),filename,"exec"),ns)
 actual=ns["ActualPhase"]();sent=[];records=[];target=target_ns
 node=SimpleNamespace(epoch=EPOCH,halted=halted,stop_time=20. if terminal else None,decision_sequences={n:1 for n in ("tb1","tb2","tb3")},completed_motion={},issued_motion=set(),get_clock=lambda:SimpleNamespace(now=lambda:SimpleNamespace(nanoseconds=target)),record=lambda kind,payload:records.append((kind,payload)))
 def emit(clock,stop=False):
  node.completed_motion[(clock,"stop"if stop else"normal")]={"schema":"mr3-motion-safety-status-v1","epoch":EPOCH,"clock_ns":clock,"ready":not stop,"completion_scope":"publication_and_local_topic_receipt","decision_sequences":dict(node.decision_sequences),"outputs":{n:{"linear_x":0.,"angular_z":0.}for n in node.decision_sequences},**({"phase_kind":"stop"}if stop else{})}
 node.ensure_motion_output=emit
 def inputs(clock):
  if fail_inside:node.halted="normal_control_model_invalid";return False
  return True
 node.control_inputs_ready=inputs
 node.normal_control_model_fault=None
 node.normal_velocity_fault=model_check or (lambda clock: {"reason":"synthetic_actual_model_error","commit_clock_ns":clock} if fail_inside else None)
 actual.node=node;actual.controlled=True;actual.stopping=False;actual.normal_clocks=set();actual.pending={"request":{"schema":"mr3-motion-control-request-v1","epoch":EPOCH,"request_id":"actual-proposal-phase","target_time_ns":target,"operation":operation},"started":0.,"issued":False};actual.responses=OrderedDict();actual.publisher=SimpleNamespace(publish=lambda m:sent.append(json.loads(m.data)));actual.dependency_ready=lambda req:True
 actual.poll_once();return actual,node,sent,records,target

class VelocityProposalTests(unittest.TestCase):
 def test_real_captured_own_peak_red_green(self):
  value=FIXTURE["own_state"];now=FIXTURE["clock_ns"]/1e9
  self.assertTrue(OLD.valid_state(value,now,FIXTURE["epoch"]))
  self.assertFalse(NEW.valid_state(value,now,FIXTURE["epoch"]))
  self.assertEqual(NEW.measured_velocity_error(value),"measured_planar_speed_exceeded")
 def test_real_captured_received_peer_peak_red_green(self):
  value=FIXTURE["received_peer_state"];now=FIXTURE["clock_ns"]/1e9
  self.assertTrue(OLD.valid_state(value,now,FIXTURE["epoch"]))
  self.assertFalse(NEW.valid_state(value,now,FIXTURE["epoch"],require_raw=True))
 def test_real_actual_guard_will_not_forward_new_nonzero_request(self):
  value=FIXTURE["own_state"];now=FIXTURE["clock_ns"]/1e9;req=FIXTURE["request"]
  old=OLD.guard_motion([req["v"],req["w"]],value,FIXTURE["received_peers"],now,FIXTURE["epoch"])
  new=NEW.guard_motion([req["v"],req["w"]],value,FIXTURE["received_peers"],now,FIXTURE["epoch"])
  self.assertTrue(old["allow"]);self.assertEqual(new["output"],[0.,0.]);self.assertFalse(new["allow"])
 def test_scalar_own_valid_and_raw_peer_required(self):
  self.assertTrue(NEW.valid_state(state(),10.,EPOCH))
  self.assertFalse(NEW.valid_state(state(),10.,EPOCH,require_raw=True))
  self.assertTrue(NEW.valid_state(state(raw=True),10.,EPOCH,require_raw=True))
 def test_no_missing_or_none_raw_scalar_bypass(self):
  self.assertFalse(NEW.valid_state(state(scalar=False),10.,EPOCH))
  value=state();value["odometry"]=None
  self.assertFalse(NEW.valid_state(value,10.,EPOCH))
 def test_raw_has_priority_and_optional_scalar_must_equal_it(self):
  for scalar in (.1,.299,True,float("nan")):
   value=state(.25164306169129336,-.17380055821233364,raw=True);value["planar_speed_mps"]=scalar
   with self.subTest(scalar=scalar):self.assertFalse(NEW.valid_state(value,10.,EPOCH,require_raw=True))
 def test_strict_measured_planar_boundary_no_command_ulp_tolerance(self):
  for vx,vy,expected in [(.3,0.,True),(-.3,0.,True),(.18,.24,True),(math.nextafter(.3,math.inf),0.,False),(.3,math.nextafter(0.,math.inf),True)]:
   with self.subTest(vx=vx,vy=vy):self.assertEqual(NEW.valid_state(state(vx,vy,raw=True),10.,EPOCH,require_raw=True),expected)
  value=state();value["planar_speed_mps"]=math.nextafter(.3,math.inf);self.assertFalse(NEW.valid_state(value,10.,EPOCH))
 def test_finite_typed_planar_inputs(self):
  for axis in ("x","y"):
   for bad in (True,float("nan"),float("inf"),-float("inf"),".1"):
    value=state(raw=True,scalar=False);value["odometry"]["twist"]["twist"]["linear"][axis]=bad
    with self.subTest(axis=axis,bad=repr(bad)):self.assertFalse(NEW.valid_state(value,10.,EPOCH,require_raw=True))
  for bad in (None,True,-.1,float("nan"),float("inf")):
   value=state();value["planar_speed_mps"]=bad;self.assertFalse(NEW.valid_state(value,10.,EPOCH))
 def test_angular_full_norm_boundary_and_not_only_z(self):
  self.assertTrue(NEW.valid_state(state(raw=True,w=1.2),10.,EPOCH,require_raw=True))
  self.assertFalse(NEW.valid_state(state(raw=True,w=math.nextafter(1.2,math.inf)),10.,EPOCH,require_raw=True))
  for axis in ("x","y","z"):
   value=state(raw=True);value["odometry"]["twist"]["twist"]["angular"][axis]=float("nan");self.assertFalse(NEW.valid_state(value,10.,EPOCH,require_raw=True))
  value=state(raw=True);value["odometry"]["twist"]["twist"]["angular"]["x"]=1.3;self.assertFalse(NEW.valid_state(value,10.,EPOCH,require_raw=True))
 def test_epoch_future_and_old_source_rules_remain_strict(self):
  value=state(raw=True);self.assertTrue(NEW.valid_state(value,10.5,EPOCH,require_raw=True))
  for now,epoch in [(10.500000001,EPOCH),(9.999999999,EPOCH),(10.,"wrong")]:
   with self.subTest(now=now,epoch=epoch):self.assertFalse(NEW.valid_state(value,now,epoch,require_raw=True))
 def test_phase_model_failure_is_true_negative_not_ok_zero(self):
  _,_,old,_,_=phase("original_mr3_motion_control.py")
  _,_,new,records,_=phase("proposed_mr3_motion_control.py")
  self.assertTrue(old[0]["ok"]);self.assertEqual(old[0]["status"]["phase_kind"],"stop")
  self.assertIs(new[0]["ok"],False);self.assertEqual(new[0]["error"],"normal_control_model_invalid");self.assertTrue(any(k=="control_failure"for k,_ in records))
 def test_violation_found_during_input_check_does_not_wait_10_seconds(self):
  _,_,old,_,_=phase("original_mr3_motion_control.py",halted=None,fail_inside=True)
  _,_,new,_,_=phase("proposed_mr3_motion_control.py",halted=None,fail_inside=True)
  self.assertEqual(old,[]);self.assertIs(new[0]["ok"],False)
 def test_explicit_stop_still_has_actual_zero_completion(self):
  _,_,new,_,_=phase("proposed_mr3_motion_control.py",operation="stop")
  self.assertIs(new[0]["ok"],True);self.assertEqual(new[0]["status"]["phase_kind"],"stop")
 def test_ordinary_terminal_stop_is_not_new_model_failure(self):
  _,_,new,_,_=phase("proposed_mr3_motion_control.py",halted=None,terminal=True)
  self.assertIs(new[0]["ok"],True);self.assertEqual(new[0]["status"]["phase_kind"],"stop")
 def test_real_client_sticky_error_cannot_be_used_to_resume(self):
  _,_,new,_,target=phase("proposed_mr3_motion_control.py");ack=new[0];client=CLIENT.ControlPhaseClient(EPOCH)
  client.begin("motion","commit",target,request_id=ack["request_id"]);client.receive("motion",ack,target,target)
  with self.assertRaises(RuntimeError):client.consume()
  with self.assertRaises(ValueError):client.begin("motion","commit",target+20_000_000)
  client=CLIENT.ControlPhaseClient(EPOCH);client.begin("motion","commit",target,request_id=ack["request_id"]);client.abandon_for_stop()
  with self.assertRaises(ValueError):client.receive("motion",ack,target,target)

if __name__=="__main__":unittest.main(verbosity=2)
