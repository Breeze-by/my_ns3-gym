"""Explicit current-base three-way hunk merges, solely into this /tmp root."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT=Path('/home/zhuyulab/ns3-workspace')
HERE=Path(__file__).resolve().parent
W=Path('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/mr3_learning')
ROS=Path('ros2_ws/ros2-multi-robot-automap')
PACKAGE=ROS/'src/multi_robot_exploration/multi_robot_exploration'
AUTH=Path('/tmp/mr3_p2a_motion_authority_ros_wiring_draft_v3')
META=Path('/tmp/mr3_p2a_authority_metadata_candidate_v1')
PROBE=Path('/tmp/mr3_p2a_outward_cancel_v2_shadow_v1')
current={}
origins={}
merges=[]


def sha(data):return hashlib.sha256(data).hexdigest()


def merge(relative,version,candidate,step):
    name=str(relative)
    present=(ROOT/relative).read_bytes() if (ROOT/relative).exists() else b''
    origins.setdefault(name,present)
    ours=current.get(name,present)
    theirs=candidate.read_bytes()
    if version is None:
        assert not ours
        result=theirs
        base=b''
    else:
        base=subprocess.check_output(['git','show',version+':'+name],cwd=ROOT)
        saved=HERE/'merge_inputs'/step
        saved.mkdir(parents=True,exist_ok=True)
        inputs=[]
        for label,data in [('ours',ours),('base',base),('theirs',theirs)]:
            path=saved/(relative.name+'.'+label+'.rawbytes');path.write_bytes(data);inputs.append(path)
        proc=subprocess.run(['git','merge-file','--stdout',*[str(p) for p in inputs]],capture_output=True)
        (saved/(relative.name+'.merge_returncode.json')).write_text(json.dumps({'returncode':proc.returncode})+'\n')
        assert proc.returncode==0,(step,name,proc.returncode,proc.stderr.decode())
        result=proc.stdout
    ast.parse(result.decode(),filename=name)
    current[name]=result
    merges.append({'path':name,'step':step,'base_git':version,'base_sha256':sha(base),
        'ours_sha256':sha(ours),'theirs_path':str(candidate),'theirs_sha256':sha(theirs),
        'merged_sha256':sha(result),'clean_three_way':True})


for relative in (PACKAGE/'mr3_adapter.py',PACKAGE/'motion_safety.py',ROS/'src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py'):
    merge(relative,'81e63f50699073286c9773dcb92106de63fdf4ca',AUTH/'shadow'/relative,'authority')
merge(PACKAGE/'mr3_motion_authority.py',None,AUTH/'shadow'/PACKAGE/'mr3_motion_authority.py','authority_new_core')
for relative in (W/'supervisor.py',W/'benchmark.py',W/'ppo.py',ROS/'scripts/mr3_env_worker.py'):
    merge(relative,'3e98f00483469c034f7b5fdef29bd2c6337eaecd',META/'shadow'/relative,'metadata')
for relative in (W/'supervisor.py',W/'benchmark.py',ROS/'scripts/mr3_env_worker.py'):
    merge(relative,'935b466bd076002afdfe161b55a508938de2a8b0',PROBE/'shadow'/relative,'outward_probe_v2')

adapter_name=str(PACKAGE/'mr3_adapter.py')
before=current[adapter_name]
old_stop='''            self.stop_requested = True
            self.dispatcher.safety_stop(self.now(), "task_stop")
'''
new_stop='''            self.stop_requested = True
            try:
                if getattr(self, "motion_authority_profile", ""):
                    self.record("authority_task_stop_callback", {
                        "message": {"stamp": {"sec": message.stamp.sec,
                                              "nanosec": message.stamp.nanosec},
                                    "frame_id": message.frame_id},
                        "clock_ns": self.get_clock().now().nanoseconds,
                        "started_at": self.started_at})
            finally:
                self.dispatcher.safety_stop(self.now(), "task_stop")
'''
assert before.count(old_stop.encode())==1
current[adapter_name]=before.replace(old_stop.encode(),new_stop.encode())
merges.append({'path':adapter_name,'step':'profile_only_accepted_task_stop_callback_journal',
               'before_sha256':sha(before),'after_sha256':sha(current[adapter_name]),
               'semantics_or_phase_or_B_start_changed':False})

patch=[];files=[]
for name,data in current.items():
    path=HERE/'shadow'/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    old=origins[name]
    patch.extend(difflib.unified_diff(old.decode().splitlines(True),data.decode().splitlines(True),
        fromfile='a/'+name if old else '/dev/null',tofile='b/'+name))
    files.append({'path':name,'current_base_sha256':sha(old) if old else None,'bytes':len(data),'sha256':sha(data)})
accessor=META/'shadow'/W/'motion_authority_profile.py'
target=HERE/'shadow'/W/'motion_authority_profile.py';target.write_bytes(accessor.read_bytes())
assert sha(target.read_bytes())=='a5a213e641c208dbc056f39c63d13042b01ae2a8025cfe481ff1dce67ca93b6b'

def method_text(text,cls,method):
    tree=ast.parse(text);node=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==cls)
    node=next(n for n in node.body if isinstance(n,ast.FunctionDef) and n.name==method)
    return ast.get_source_segment(text,node)

motion_name=str(PACKAGE/'motion_safety.py')
record_before=method_text(origins[motion_name].decode(),'MotionSafety','record')
record_after=method_text(current[motion_name].decode(),'MotionSafety','record')
assert record_before==record_after
runtime=ROOT/PACKAGE/'mr3_reach_runtime.py'
assert sha(runtime.read_bytes())=='576c235901a51223f1d2723757f60c490045ba897d445d5c6fb3c739512a466b'
assert sha(origins[motion_name])=='b1aaa465f6fe1c940674b97f347d14840f79d04a3d233be6f143fb06fbbb6b1e'

for source,name in [(AUTH/'test_motion_authority_ros_wrapper_v2.py','test_motion_authority_ros_wrapper_v2.py'),
                    (META/'test_authority_metadata_entry_v1.py','test_authority_metadata_entry_v1.py'),
                    (PROBE/'test_provisional_system_v1.py','test_provisional_system_v1.py'),
                    (PROBE/'test_provisional_learner_v1.py','test_provisional_learner_v1.py')]:
    target=HERE/name
    if not target.exists():shutil.copy2(source,target)
(HERE/'integrated_candidate.patch').write_text(''.join(patch))
(HERE/'source_manifest_v1.json').write_text(json.dumps({'schema':'mr3-authority-integrated-source-manifest-v1',
    'status':'UNSEALED_WAITING_MERGED_READER_DEPENDENCIES_AND_CPU','files':files,'merges':merges,
    'V64_record_method_exactly_preserved':True,'current_base_motion_sha256':sha(origins[motion_name]),
    'V64_runtime_unmodified_sha256':sha(runtime.read_bytes()),'owned_sources':8,
    'external_accessor_snapshot_sha256':sha(target.read_bytes()) if False else sha(accessor.read_bytes()),
    'repository_source_edited':False,'formal_plan_or_World':False},indent=2)+'\n')
print(json.dumps({'owned_sources':8,'AST_PASS':True,'clean_merges':len(merges),'V64_record_exact':True,
                 'patch_bytes':len(''.join(patch).encode())}))
