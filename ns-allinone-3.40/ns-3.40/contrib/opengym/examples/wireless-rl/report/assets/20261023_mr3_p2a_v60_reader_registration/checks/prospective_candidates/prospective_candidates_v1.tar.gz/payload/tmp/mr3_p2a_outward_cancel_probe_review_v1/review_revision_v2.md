Current recommendation: explicit outward-cancel v2 stimulus

This revision supersedes the numeric distance screen in review.md and
proposal_v2.json. The earlier2.65m proposal and its CPU evidence are preserved;
they are not the recommended requirement. All proposals remain uninstalled.

Distance and timing correction

The real5s commitment begins in GoalDispatcher.on_accept when the delivered
accepted callback is consumed. It is not measured from command.created_at.
Worker.step publishes at a paused physical clock, waits for the adapter to
account for the action, then advances the next physical second. Its2s TTL is a
freshness/lease constraint, not an extra mandatory2s movement interval. Adding
that entire TTL to the travel screen was unnecessarily conservative.

The unchanged Reach target cap is.20m/s. The independent physical observation
bound is.30m/s, and actual body speed may differ from the target cap; the two
numbers must not be interchanged in a physical claim. Nav2's native xy tolerance
is.25m. With a nominal.20m/s travel model, five seconds of commitment plus at most
one1Hz decision period gives .25+.20*(5+1)=1.45m. Use strict endpoint distance
above1.45m as the prospective single nominal screen. Reuse the existing declared
per-robot path_distances_m to favor longer original legal outward choices. Do
not invent targets or change candidate/mask/commitment semantics.

This screen is neither necessary nor actually sufficient. A shorter goal may
remain active because of turning, planning or slow motion. A longer goal may
complete or stop unexpectedly because the target cap is not a proven body-speed
bound, source poses can differ from controller poses, the action/native callback
chain has real delays, or the safety guard can withhold motion. Graph path length
also does not lower-bound every controller trajectory; use it for ranking, not
as a substitute proof for endpoint separation. The.30 physical-bound arithmetic
would give2.05m for the same5+1s model, not2.65m. That is a different conditional
screen, not an extra suggested mode or an existing physical guarantee.

The deciding condition is the received fresh active/owned goal and the real
legal WAIT mask while meaningful motion is actually observed. Record acceptance,
remaining commitment, goal distance, goal_id and source clocks. Do not transform
a missed active interval, legal idle WAIT, or accepted action RPC into an actual
cancel event. If no original joint-legal candidate satisfies the selected screen,
record bounded coverage failure. Do not relax it silently, choose a short fallback,
or repeat the old campaign. Availability in actual open/rooms/corridors candidate
sets is UNKNOWN here: no saved observation/map/candidate stream was read. The
producer's1m frontier-staging limit concerns a safe staging offset from a frontier,
not a universal robot-to-goal travel cap, so it proves neither impossibility nor
availability of1.45m goals.

Can32 steps fit two rounds for all three robots?

Conditionally, yes. A nominal joint-legal three-goal round accepted by2s can first
WAIT near7s, physically settle near8s if the original.78s bound actually holds,
and collect three increasing rest observations plus the3s terminal-observation
handoff by roughly11s. The second declared goal window[13,20) can then admit
another joint-legal set. A normal acceptance near13–14s permits a second WAIT near
18–20s, leaving a substantial tail before32s. This uses simultaneous independent
robot ownership, not three serial allocations.

There is no unconditional32-step guarantee. Original action-response/cancel
timeouts are10s, and a legal cancellation result may arrive late. Two commitment
windows plus two full cancellation timeouts and a3s handoff already cost33s,
before acceptance, decision alignment, movement and observation delay. If only
some robots have joint-legal long goals, if a goal remains blocked, or if a robot
does not become active/moving in time, serializing opportunities may also exceed
the remaining window. Angular reversal may use time without meaningful forward
motion. Keep32 complete steps, at most two admitted goals per robot, and all three
robots' evidence requirements; report missing opportunities as coverage failure.
Do not shorten RPCs, reduce commitment, force a mask, borrow cleanup as an extra
planned round, change stop eligibility or assert that this static timeline proves
actual reachability. Preserve every eligible stop violation even if a later stop
is successful.

The fixed proposed phase boundaries remain an explicit bounded experiment:
round1 goal opportunity[0,1.5), acceptance viability by2s, cleanup WAIT from10s;
round2 goal opportunity[13,20), acceptance viability by20s, planned native-cancel
deadline28s and four-second tail. These deadlines can fail to be met. They do not
override the original ownership/timeout rules and must be recorded as failed
stimulus conditions rather than assumed true. Before another round require a
matching received CANCELED terminal, three fresh rest observations with increasing
source stamps, and3simseconds after the first matching terminal observation.

Complete wiring list before a new production version

1. supervisor.py: add an explicit Reach v2 probe identity; preserve legacy/v1
   branches in validate_preparation_profile. Retain the same32-step and exclusive
   diagnostic restrictions. Carry the selected identity through supervisor
   metadata and worker startup requests. A missing or unknown selection fails.
2. benchmark.py: update _collection_safety_contract, CLI choices, explicit32-step
   enforcement, preparation/parameter-review compatibility, run_worker diagnostic
   construction, selector dispatch and post-step submission handling. Implement a
   separate v2 selector/recorder; retain all v1/v4/v6 function semantics and AST
   checks. Persist planned/submitted/accepted/cancel-observed/terminal-observed
   distinctions in metadata and summary; bind exact command and goal identities.
3. mr3_env_worker.py/adapter/protocol/observation: inspect the metadata/request path
   and consume the existing navigation fields and original masks. No new probe
   may lower the5s commitment, create a raw motor command, bypass idle ownership,
   use WorldPose/truth, reinterpret WAIT as completion, or refresh command expiry.
   No source change is required here if the existing fields suffice; still bind
   their exact bytes as dependencies and test the real lifecycle.
4. audit_reach_reset_workload.py: register a fixed pair
   mr3-p2a-reach-outward-cancel-v2 / mr3-reach-reset-outward-cancel-v2. Extend the
   fixed-kind loader, command_argv, CLI profile choices, audit identity, benchmark
   metadata/summary checks and verify_reader_readiness to select the explicit
   pair. Do not simply overwrite the global v1 PROFILE/PROBE_VERSION/CHANGE.
5. For both immutable V17 matrix readers, permit only the one unique PROBE_VERSION
   assignment projection from the unchanged original v6 literal to the selected
   Reach literal. Verify exact source SHA, one replacement, whole-source inverse,
   and actual loaded module.PROBE_VERSION. Preserve both unchanged angular and
   physical leaf SHAs and all mathematical functions. Reject v1 producer/v2 reader
   and v2 producer/v1 reader. Never add a general arbitrary-source or arbitrary
   replacement option.
6. audit_reach_preparation.load_impl(plan): its current unique v6-to-Reach-v1
   projection must select the declared v2 literal for the new plan. Preserve the
   immutable audit_preparation source and full inverse. This controls the explicit
   workload/capacity-comparison declaration and32-step schedule checks in the full
   role; fixing only the reset physical/angular wrapper would leave a second
   producer/reader mismatch. Keep peer, controlled-physics and plan propagation.
7. reach_preparation.validate_plan/build_plan: bind the selected probe/workload
   pair; replace the current hardcoded v1 checks and interface/reset CLI rewrite
   only in an explicit new branch. Propagate it into reset angular/physics
   command_argv calls and validate the complete actual job argv and dependencies.
   Retain the original per-episode physical report, four stages,12EP/30 roles,
   worker/schedule/step counts, role prerequisites and failure-stop behavior.
8. Reach native/full gate loaders: make profile selection plan-bound through every
   private loader and source check; require the actual metadata pair to match.
   Readiness must actually instantiate the selected definitions rather than
   checking a callable name. Do not alter sensor inverse, compound actuation,
   physics, contact, input, runtime, peer or safety predicates to admit the probe.
9. New activity prepare/scope/authorization/plan-check/preflight: include the
   selected workload profile and probe identity in scope, plan and dispatch proof.
   Keep one sealed resource/actual prior closure ledger, current source binding,
   exact qualification wrappers and immutable reader source inventory. Require
   actual verify_reader_readiness(plan,newfreeze) before native startup.
10. CPU system_reader_definitions readiness: its present no-argument v1 loader
    assumptions must become explicit fixed-profile selection. Actually load both
    angular/physics matrix definitions and unchanged leaves for the selected pair,
    check the exact inverse and constants, and retain audit_calls=0. Test old v1
    as a preserved branch and reject mixed/unknown pairs. Learner readiness also
    imports the new selector/full-reader path and preserves environment isolation.
11. Fresh CPU/source classification: include every changed runtime and new test via
    the filesystem union, including untracked tests. Add the integrated real
    GoalDispatcher/mask lifecycle and late acceptance/completion races, receipt
    identity, original masks, source-stamp freshness, actual terminal handoff,
    strict distance and bounded failure cases. Extend activity admission tests to
    cover all four entries and both reader readiness calls. Seal source/spec only
    after all writers stop; run real waits/JUnit/source recovery and freshgone.
    Reuse old CPU only when the tested current bytes are exactly equal.
12. Qualification/PPO chain: require the new plan/freeze and all original necessary
    roles before minimum/pilot/final. Preserve normal PPO metadata without injecting
    scripted probe actions into learning episodes. Bind changed benchmark,
    supervisor, reader, plan hooks and tests in source_inventory/qualification
    wrappers and the policy plan relationship. Do not reuse V60 scientific credit
    or a historical FAIL as a passing new qualification.
13. Build/source custody: retain the explicit initial-zero-encoder actuation
    profile, seventh helper/source macro, actual installed ELF and independent
    compound replay. A pure stimulus/reader Python change does not manufacture a
    new C++ build. The real unchanged A59 build evidence remains applicable only
    if all corresponding source/ELF/flags bytes actually match. Any native source
    change requires its own real new build.
14. Final source-only conformance matrix before freeze: one v2 plan must produce
    v2 interface/reset CLI, v2 producer metadata, v2 full reader, v2 reset angular
    reader, v2 reset physical reader, correct original per-episode report,
    successful definition/readiness proofs, full source inventory and unchanged
    leaf predicates. Cross every edge with wrong/omitted/v1 values in artificial
    negative cases. Only then generate a new freeze and bounded actual scope.

The machine-readable wiring_AST_inventory_v1.json lists21 current source files,
their exact E hashes, parsed function ownership and all inspected wiring sites.
It is an inventory for future implementation, not evidence that v2 is installed.
The revised four-case real-protocol fixture uses the1.45m screen and legal1.6m
targets in its conditional travel model. The first corrected-screen CPU launch
failed before starting a child because a source path omitted ros2_ws; its separate
output remains. The corrected argv ran in a new directory. Neither attempt ran
World or an old scientific reader, and no repository file was modified.
