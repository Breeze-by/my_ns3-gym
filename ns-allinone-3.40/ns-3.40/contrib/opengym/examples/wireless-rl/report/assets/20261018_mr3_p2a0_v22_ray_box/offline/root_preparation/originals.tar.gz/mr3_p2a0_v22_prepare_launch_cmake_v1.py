"""Prepare the explicit stepped physics correction; no canonical writes/native."""
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/zhuyulab/ns3-workspace')
PKG = ROOT/'ros2_ws/ros2-multi-robot-automap/src/multi_robot'
OUT = Path('/tmp/mr3_p2a0_v22_launch_cmake_proposal_v1')
assert not OUT.exists()
OUT.mkdir()
path = PKG/'launch/gazebo_multirobot_mapping_with_nav2.launch.py'
old = path.read_text()
assert hashlib.sha256(old.encode()).hexdigest() == '6c76a4f0afbeb4c26f8c28b8e1139bbd12e5162a54ca3a193b99a156ef47a2d2'
changes = []
def change(text, before, after):
    assert text.count(before) == 1
    changes.append({'before':before,'after':after})
    return text.replace(before,after,1)
text = change(old,
    '    server_state = {\n',
    '    ray_box_plugin = None\n'
    '    ray_box_audit_path = None\n'
    '    if stepped_mode:\n'
    '        ray_box_plugin = os.path.join(get_package_prefix("multi_robot"),\n'
    '                                     "lib", "libmr3_ray_box_corrector.so")\n'
    '        if not os.path.isfile(ray_box_plugin):\n'
    '            raise ValueError(f"installed MR3 ray-box corrector does not exist: {ray_box_plugin}")\n'
    '        ray_box_directory = (Path(adapter_audit_path).parent.resolve(strict=True)\n'
    '                             if adapter_audit_path else\n'
    '                             Path(tempfile.mkdtemp(prefix="mr3_ray_box_corrector_")))\n'
    '        ray_box_audit_path = str(ray_box_directory / "ray_box_corrector.jsonl")\n'
    '    server_state = {\n')
text = change(text,
    '                "stepped_mode": stepped_mode, "selected_step_plugin": step_plugin,\n',
    '                "stepped_mode": stepped_mode, "selected_step_plugin": step_plugin,\n'
    '                "selected_ray_box_plugin": ray_box_plugin,\n'
    '                "ray_box_audit_path": ray_box_audit_path,\n')
text = change(text,
    '        diagnostic_system_args = []\n',
    '        gazebo_environment["MR3_RAY_BOX_CORRECTOR_AUDIT_PATH"] = ray_box_audit_path\n'
    '        gazebo_environment["MR3_RAY_BOX_CORRECTOR_EPOCH"] = episode_epoch.perform(context)\n'
    '        diagnostic_system_args = []\n')
text = change(text,
    '                 "-s", "libgazebo_ros_force_system.so", "-s", step_plugin,\n',
    '                 "-s", "libgazebo_ros_force_system.so",\n'
    '                 "-s", ray_box_plugin, "-s", step_plugin,\n')
check = text
for row in reversed(changes):
    assert check.count(row['after']) == 1
    check = check.replace(row['after'],row['before'],1)
assert check == old
compile(text,str(path),'exec')
(OUT/path.name).write_text(text)
cmake = PKG/'CMakeLists.txt'
base = cmake.read_bytes()
assert hashlib.sha256(base).hexdigest() == '170eb49947c4daa61d30f45ab8fde637aa12766182dddfda15c9ca6453d0cc0d'
block = Path('/tmp/mr3_p2a0_v22_ray_box_corrector_proposal_v1/CMake_target_block.txt').read_bytes()
assert base.endswith(b'\n') and block.endswith(b'\n')
new_cmake = base+b'\n'+block
assert new_cmake[:-len(block)-1] == base
(OUT/'CMakeLists.txt').write_bytes(new_cmake)
result = {'schema':'mr3-v22-launch-cmake-proposal-v1','canonical_writes':False,'native_calls':0,
          'launch_changes':changes,'cmake_append_hex':(b'\n'+block).hex(),
          'files':[{'source':str(OUT/p.name),'canonical':str(p.relative_to(ROOT)),
                    'sha256':hashlib.sha256((OUT/p.name).read_bytes()).hexdigest()}
                   for p in (path,cmake)],
          'scope':'Only explicit stepped adapter server loads the correction. Existing baseline include path is retained. Audit uses episode directory; audit-less manual stepped launch preserves a dedicated temporary ledger.'}
(OUT/'proposal_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['files']))
