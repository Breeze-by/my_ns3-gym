"""Record proposed bytes and pure CPU provenance; never promote or start native."""
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A16 = W / 'report/assets/20261017_mr3_p2a0_v16/independent'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


spec = importlib.util.spec_from_file_location('offline_v5', HERE / 'test_stimulus_v5.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
runs = []
for version in ('v14', 'v15'):
    old_state, new_state = {}, {}
    rows = module.recorded(version)
    observations = []
    for index, row in enumerate(rows[:-1]):
        snap = row['snapshot']
        old = module.OLD['probe_action_v4'](snap, old_state)
        new = module.NEW['probe_action_v4'](snap, new_state)
        assert old == new and old_state == new_state
        actual_info = rows[index + 1]['info']
        actual_action = actual_info['command']['action']
        if version == 'v15':
            assert actual_action == old
            info = actual_info
        else:
            info = module.result(snap, old)
        module.OLD['record_probe_v4_submission'](old_state, info)
        module.NEW['record_probe_v4_submission'](new_state, info)
        assert old_state == new_state
        observations.append({'snapshot_sequence': snap['sequence'],
                             'task_elapsed_sec': snap['task_elapsed_sec'],
                             'old_v4_action': old, 'new_v4_default_action': new,
                             'original_returned_action': actual_action,
                             'old_new_diagnostics_equal': True})
    runs.append({'run': version, 'returned_boundaries': len(observations),
                 'submission_replay_scope': ('Real original returned command info' if version == 'v15'
                                             else 'V14 originally V3: hypothetical typed V4 commands '
                                                  'for old/new pure replay, not actual submission'),
                 'observations': observations})
compat = HERE / 'v4_actual_snapshot_compatibility_v1.json'
with compat.open('x') as handle:
    json.dump({'schema': 'mr3-v16-v4-recorded-snapshot-cpu-equivalence-v1', 'passed': True,
               'scope': 'No native rerun. V14 originally used V3; compatibility compares old/new V4 '
                        'on actual V14 inputs using hypothetical matching command receipts. V15 '
                        'additionally matches every actual action and uses original returned info.',
               'runs': runs}, handle, indent=2, allow_nan=False)

files = [(HERE / 'benchmark.py', W / 'mr3_learning/benchmark.py'),
         (HERE / 'audit_preparation.py', W / 'mr3_learning/audit_preparation.py'),
         (HERE / 'test_preparation_comparison.py',
          W / 'mr3_learning/tests/test_preparation_comparison.py'),
         (HERE / 'test_benchmark_stimulus_v5.py',
          W / 'mr3_learning/tests/test_benchmark_stimulus_v5.py')]
for name in ('mr3_independent_angular_reset_matrix_v16.py',
             'mr3_independent_physics_matrix_v16.py',
             'mr3_independent_reset_wrappers_v16_tests.py'):
    files.append((HERE / 'assets/20261017_mr3_p2a0_v16/independent' / name, A16 / name))
entries, patch = [], []
for source, destination in files:
    relative = destination.relative_to(ROOT).as_posix()
    old = destination.read_text() if destination.exists() else ''
    patch.extend(difflib.unified_diff(old.splitlines(True), source.read_text().splitlines(True),
                                    fromfile='a/' + relative if destination.exists() else '/dev/null',
                                    tofile='b/' + relative))
    entries.append({'source': str(source), 'proposed_canonical_path': relative,
                    'sha256': sha(source), 'bytes': source.stat().st_size,
                    'base_sha256': sha(destination) if destination.exists() else None})
patch_path = HERE / 'review_only.patch'
with patch_path.open('x') as handle:
    handle.writelines(patch)
checks = HERE / 'checks_v5.json'
prior = HERE / 'checks_v2.json'
result = {
    'schema': 'mr3-v16-stimulus-v5-handoff-v1', 'state': 'prototype_only_not_promoted',
    'source_editors_stopped': True, 'native_run_performed': False,
    'formal_audit_performed': False, 'fixture_version': 'mr3-p2a0-outward-cancel-v5',
    'steps_per_episode': 32,
    'cli_suffix': ['--preparation-motion-probe', '--preparation-probe-version',
                   'mr3-p2a0-outward-cancel-v5', '--steps', '32'],
    'files': entries, 'review_patch': {'path': str(patch_path), 'sha256': sha(patch_path)},
    'checks': {
        'fresh': {'path': str(checks), 'sha256': sha(checks),
                  'passed': json.loads(checks.read_text())['passed'],
                  'offline_methods': 13, 'portable_methods': 11},
        'unchanged_qualification_and_wrappers': {
            'path': str(prior), 'sha256': sha(prior), 'capacity_methods': 9,
            'wrapper_methods': 18,
            'explanation': 'These unmodified source SHA values match original PASS receipt; '
                           'not rerun after V5-only finite/diagnostic changes.'},
        'v4_actual_snapshot_compatibility': {'path': str(compat), 'sha256': sha(compat),
                                           'passed': True, 'boundaries_per_run': 32}},
    'selection_contract': [
        'Original joint mask and V4 lifecycle eligibility first. Every new GOAL requires all '
        'received robot positions fresh/valid/finite and every goal-peer straight margin finite '
        'and >=0. Degenerate or overflow/underflow arithmetic rejects that new-GOAL action.',
        'Within this subset retain maxGOAL, then second-phase reverse opportunities, outward '
        'minimum/sum, path and action ID ranking. KEEP/WAIT retain original masks/latches.',
        'V5 goal_decisions max_legal_goal_components describes only the external filtered '
        'stimulus subset, not actor interface availability; original/filtered counts recorded.',
        'Existing source-stamped received motion/activity conditions, 5s protocol mask, min3s '
        'initial WAIT and actual returned typed command submission rules remain intact.'],
    'actual_snapshot_counterfactual': {
        'v15_t0_action': 412, 'v15_t13_action': 321,
        'scope': 'CPU selector replay only; no native safety, turn, stop or movement credit.'},
    'legacy': [
        'Old _probe_goal_order/probe_action/probe_action_v3/record_probe_v4_submission AST unchanged.',
        'V4 defaultFalse yields equal actions and full diagnostics at all32 actual V14 and V15 '
        'input boundaries; V15 also equals all original actual actions with actual command info.',
        'PARAMETER_REVIEW_SCRIPT stays at exact A13 path; any later constant merge is root-owned.',
        'Old V2/V3/V4 assets unchanged. New wrappers exactV5/32 only and retain8EP/33records '
        'and immutable7a472/2516 source/math.'],
    'risks': [
        'Straight nonapproach is not Nav2 reachability, velocity-cone clearance or a safety proof.',
        'Initial412 is unchanged; moving peers can later invalidate its margins. Initial TB1 '
        'stall is not established fixed by this second-goal ranking change.',
        'Actual t13=321 predicts reverse opportunity only for TB3. Same-robot bidirectional '
        'and all-robot sign coverage are not guaranteed; pending independent exhaustive review.',
        'No Shim/profile change included.32s stop/activity/angular coverage still requires '
        'a complete new same-freeze four-stage matrix. No PPO effectiveness or95% task credit.'],
    'preserved_failures': [
        'checks_v1.json initial style FAIL and checks_v3.json nested blank style FAIL retained.',
        'checks_v2_source_benchmark.py preserves initial NaN-swallow V5 false accept.',
        'overflow_redgreen_v1.py/.json oldTrue/newFalse retained; green source4ea differs from '
        'final only later formatting/diagnostics, and final13/11 tests include this shape.'],
    'root_owned_followup': [
        'Review authorizes promotion; no source/Git promotion performed by this handoff.',
        'ENV/audit_ppo/plan/coordinator/source bindings and immutable failure/budget retention.',
        'New A16 reset wrapper paths/exactV5 metadata. Wholeinput ab102 schema3 unchanged.']}
with (HERE / 'handoff_v1.json').open('x') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
print(json.dumps({'handoff_sha256': sha(HERE / 'handoff_v1.json'),
                  'compatibility_sha256': sha(compat), 'files': entries}, indent=2))
