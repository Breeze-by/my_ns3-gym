"""Production-method CPU counterexample, no ROS init/spin or native launches."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

from geometry_msgs.msg import TransformStamped
from nav_msgs.msg import Odometry
from tf2_msgs.msg import TFMessage
import rclpy
from multi_robot_exploration.mr3_information import IdealInformation, stamp_seconds

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--label", required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
assert not args.output.exists()
root = Path("/home/zhuyulab/ns3-workspace")
source = root / "ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/multi_robot_exploration/mr3_information.py"
fixture = root / "ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/test/test_mr3_information.py"
spec = importlib.util.spec_from_file_location("real_bridge_fixtures", fixture)
fixtures = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixtures)


def stamp(message, value):
    ns = round(value*1e9)
    message.header.stamp.sec, message.header.stamp.nanosec = divmod(ns, 1_000_000_000)
    return message


def odom(value):
    result = stamp(Odometry(), value)
    result.header.frame_id = "odom"
    result.child_frame_id = "base_footprint"
    result.pose.pose.orientation.w = 1.0
    return result


def transform(source_time):
    result = stamp(TransformStamped(), source_time+.2)
    result.header.frame_id = "map"
    result.child_frame_id = "odom"
    result.transform.rotation.w = 1.0
    return result


node = fixtures.bridge()
clock = {"now": 67.94}
node.now = lambda: clock["now"]
node.tf_validity_lead_sec = .2
for name in node.names:
    IdealInformation.receive_local_odom(node, name, odom(67.934))
    IdealInformation.receive_local_tf(node, name, TFMessage(transforms=[transform(67.58)]))
IdealInformation.publish_states(node)
first = json.loads(node.state_publisher.messages[-1].data)
clock["now"] = 68.0
for name in node.names:
    IdealInformation.receive_local_tf(node, name, TFMessage(transforms=[transform(67.979)]))
    IdealInformation.receive_local_odom(node, name, odom(67.998))
IdealInformation.receive_local_odom(node, "tb3", odom(68.002))
IdealInformation.publish_states(node)
second = json.loads(node.state_publisher.messages[-1].data)
tb3 = next(row for row in second["robots"] if row["name"] == "tb3")
result = dict(schema="mr3-information-future-latest-production-counterexample-v1", label=args.label,
    current_source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    fixture_sha256=hashlib.sha256(fixture.read_bytes()).hexdigest(),
    source_matches_v8_freeze=(source.read_bytes() == subprocess.check_output([
        "git", "show", "d41485dfd93797026316806916e127eb5101f3b8:"+str(source.relative_to(root))],cwd=root)),
    clock_ns=68_000_000_000,
    received_odom_sources={"initial":67.934,"later_causal":67.998,"latest_future":68.002},
    tf_actual_source=67.979, selected_tb3={key:tb3.get(key) for key in (
        "sequence","source_stamp","odom_source_stamp","tf_source_stamp","received_stamp","valid")},
    tb3_source_age_if_next_clock_68_1=68.1-tb3["source_stamp"],
    tb3_strict_original_age_gate_at_68_1=(0<=68.1-tb3["source_stamp"]<=.5),
    newly_delivered_tb3=tb3["sequence"]>first["robots"][2]["sequence"],
    ledger_messages=getattr(node,"state_diagnostic_rows",None),
    jobs=dict(ROS_init_or_spin=0,native_starts=0,services=0,ROS_messages=0,repository_writes=0),
    scope="synthetic received ordering exercising real production receive/publish methods and real ROS messages; proves implementation limitation, not that unlogged native hub ingress followed this exact ordering")
assert not rclpy.ok()
with args.output.open("x") as stream:
    stream.write(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
