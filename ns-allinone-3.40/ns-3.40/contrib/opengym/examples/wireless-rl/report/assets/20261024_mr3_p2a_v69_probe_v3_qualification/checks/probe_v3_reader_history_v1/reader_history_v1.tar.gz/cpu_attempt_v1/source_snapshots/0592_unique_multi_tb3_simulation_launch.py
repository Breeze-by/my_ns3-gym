# Copyright (c) 2018 Intel Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Example for spawning multiple robots in Gazebo.

This is an example on how to create a launch file for spawning multiple robots into Gazebo
and launch multiple instances of the navigation stack, each controlling one robot.
The robots co-exist on a shared environment and are controlled by independent nav stacks.
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch_ros.actions import Node
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, ExecuteProcess, GroupAction,
                            IncludeLaunchDescription, LogInfo)
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, TextSubstitution


def generate_launch_description():
    # Get the launch directory
    bringup_dir = get_package_share_directory('nav2_bringup')
    launch_dir = os.path.join(bringup_dir, 'launch')

    # Names and poses of the robots
    robots = [
            
            #turtlebot_world
            # {'name': 'tb1', 'x_pose': '0.0', 'y_pose': '-0.5', 'z_pose': 0.01},
            # {'name': 'tb2', 'x_pose': '0.0', 'y_pose': '0.5', 'z_pose': 0.01},
            
            #my_world
            {'name': 'tb1', 'x_pose': '5.0', 'y_pose': '4.0', 'z_pose': 0.01, 'roll': 0.00, 'pitch': 0.00, 'yaw': 0.00 },
            {'name': 'tb2', 'x_pose': '-4.5', 'y_pose': '4.0', 'z_pose': 0.01, 'roll': 0.00, 'pitch': 0.00, 'yaw': 0.00},
            {'name': 'tb3', 'x_pose': '6.0', 'y_pose': '-1.5', 'z_pose': 0.01, 'roll': 0.00, 'pitch': 0.00, 'yaw': 0.00},
            {'name': 'tb4', 'x_pose': '-4.0', 'y_pose': '-4.5', 'z_pose': 0.01, 'roll': 0.00, 'pitch': 0.00, 'yaw': 0.00},
            # {'name': 'tb5', 'x_pose': '0.0', 'y_pose': '-0.5', 'z_pose': 0.01, 'roll': 0.00, 'pitch': 0.00, 'yaw': 0.00},
            # {'name': 'tb6', 'x_pose': '0.0', 'y_pose': '0.5', 'z_pose': 0.01, 'roll': 0.00, 'pitch': 0.00, 'yaw': 0.00},
            
            # Add more robots here
        ]
    
    
    # robots = [
    #     {'name': 'tb1', 'x_pose': 1.0, 'y_pose': 0.5, 'z_pose': 0.01,
    #                        'roll': 0.0, 'pitch': 0.0, 'yaw': 0.0},
    #     {'name': 'tb2', 'x_pose': -1.0, 'y_pose': -0.5, 'z_pose': 0.01,
    #                        'roll': 0.0, 'pitch': 0.0, 'yaw': 0.0}]

    # Simulation settings
    world = LaunchConfiguration('world')
    simulator = LaunchConfiguration('simulator')

    # On this example all robots are launched with the same settings
    map_yaml_file = LaunchConfiguration('map')

    autostart = LaunchConfiguration('autostart')
    rviz_config_file = LaunchConfiguration('rviz_config')
    use_robot_state_pub = LaunchConfiguration('use_robot_state_pub')
    use_rviz = LaunchConfiguration('use_rviz')
    log_settings = LaunchConfiguration('log_settings', default='true')
    
    multi_robot = get_package_share_directory('multi_robot')
    # Declare the launch arguments
    declare_world_cmd = DeclareLaunchArgument(
        'world',
        default_value=os.path.join(multi_robot,'worlds', 'my_world.world'),
        description='Full path to world file to load')
    
    # declare_world_cmd = DeclareLaunchArgument(
    #     'world',
    #     default_value=os.path.join(bringup_dir, 'worlds', 'my_world.world'),
    #     description='Full path to world file to load')

    declare_simulator_cmd = DeclareLaunchArgument(
        'simulator',
        default_value='gazebo',
        description='The simulator to use (gazebo or gzserver)')

    declare_map_yaml_cmd = DeclareLaunchArgument(
        'map',
        default_value=os.path.join(bringup_dir, 'maps', 'turtlebot3_world.yaml'),
        description='Full path to map file to load')

    declare_robot1_params_file_cmd = DeclareLaunchArgument(
        'tb1_params_file',
        default_value=os.path.join(bringup_dir, 'params', 'nav2_multirobot_params_1.yaml'),
        description='Full path to the ROS2 parameters file to use for robot1 launched nodes')

    declare_robot2_params_file_cmd = DeclareLaunchArgument(
        'tb2_params_file',
        default_value=os.path.join(bringup_dir, 'params', 'nav2_multirobot_params_2.yaml'),
        description='Full path to the ROS2 parameters file to use for robot2 launched nodes')
    
    declare_robot3_params_file_cmd = DeclareLaunchArgument(
        'tb3_params_file',
        default_value=os.path.join(bringup_dir, 'params', 'nav2_multirobot_params_3.yaml'),
        description='Full path to the ROS2 parameters file to use for robot3 launched nodes')

    declare_robot4_params_file_cmd = DeclareLaunchArgument(
        'tb4_params_file',
        default_value=os.path.join(bringup_dir, 'params', 'nav2_multirobot_params_4.yaml'),
        description='Full path to the ROS2 parameters file to use for robot4 launched nodes')

    declare_autostart_cmd = DeclareLaunchArgument(
        'autostart', default_value='false',
        description='Automatically startup the stacks')

    declare_rviz_config_file_cmd = DeclareLaunchArgument(
        'rviz_config',
        default_value=os.path.join(bringup_dir, 'rviz', 'nav2_namespaced_view.rviz'),
        description='Full path to the RVIZ config file to use.')

    declare_use_robot_state_pub_cmd = DeclareLaunchArgument(
        'use_robot_state_pub',
        default_value='True',
        description='Whether to start the robot state publisher')

    declare_use_rviz_cmd = DeclareLaunchArgument(
        'use_rviz',
        default_value='True',
        description='Whether to start RVIZ')

    # Start Gazebo with plugin providing the robot spawning service
    start_gazebo_cmd = ExecuteProcess(
        cmd=[simulator, '--verbose', '-s', 'libgazebo_ros_init.so',
                                     '-s', 'libgazebo_ros_factory.so', world],
        output='screen')

    # Define commands for launching the navigation instances
    nav_instances_cmds = []
    for robot in robots:
        
        if robot['name'] == 'tb1':
            rviz_config_file_ = os.path.join(
                get_package_share_directory('multi_robot'),
                '../../src/multi_robot/rviz/multi_robot_maping_tb1.rviz')
           
        elif robot['name'] == 'tb2':
            rviz_config_file_ = os.path.join(
                get_package_share_directory('multi_robot'),
                '../../src/multi_robot/rviz/multi_robot_maping_tb2.rviz')
        
        elif robot['name'] == 'tb3':
            rviz_config_file_ = os.path.join(
                get_package_share_directory('multi_robot'),
                '../../src/multi_robot/rviz/multi_robot_maping_tb3.rviz')
        
        elif robot['name'] == 'tb4':
            rviz_config_file_ = os.path.join(
                get_package_share_directory('multi_robot'),
                '../../src/multi_robot/rviz/multi_robot_maping_tb4.rviz')
            
        else:
            rviz_config_file_ = None  # Handle other cases if more robots are added

        params_file = LaunchConfiguration(f"{robot['name']}_params_file")

        group = GroupAction([
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(
                        os.path.join(launch_dir, 'rviz_launch.py')),
                condition=IfCondition(use_rviz),
                launch_arguments={
                                  'namespace': TextSubstitution(text=robot['name']),
                                  'use_namespace': 'True',
                                  'rviz_config': rviz_config_file}.items()),

            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(os.path.join(bringup_dir,
                                                           'launch',
                                                           'tb3_simulation_launch.py')),
                launch_arguments={'namespace': robot['name'],
                                  'use_namespace': 'True',
                                  'map': map_yaml_file,
                                  'use_sim_time': 'True',
                                  'params_file': params_file,
                                  'autostart': autostart,
                                  'use_rviz': 'False',
                                  'use_simulator': 'False',
                                  'headless': 'False',
                                  'use_robot_state_pub': use_robot_state_pub,
                                  'x_pose': TextSubstitution(text=str(robot['x_pose'])),
                                  'y_pose': TextSubstitution(text=str(robot['y_pose'])),
                                  'z_pose': TextSubstitution(text=str(robot['z_pose'])),
                                  'roll': TextSubstitution(text=str(robot['roll'])),
                                  'pitch': TextSubstitution(text=str(robot['pitch'])),
                                  'yaw': TextSubstitution(text=str(robot['yaw'])),
                                  'robot_name':TextSubstitution(text=robot['name']), }.items()),

            LogInfo(
                condition=IfCondition(log_settings),
                msg=['Launching ', robot['name']]),
            LogInfo(
                condition=IfCondition(log_settings),
                msg=[robot['name'], ' map yaml: ', map_yaml_file]),
            LogInfo(
                condition=IfCondition(log_settings),
                msg=[robot['name'], ' params yaml: ', params_file]),
            LogInfo(
                condition=IfCondition(log_settings),
                msg=[robot['name'], ' rviz config file: ', rviz_config_file_]),
            LogInfo(
                condition=IfCondition(log_settings),
                msg=[robot['name'], ' using robot state pub: ', use_robot_state_pub]),
            LogInfo(
                condition=IfCondition(log_settings),
                msg=[robot['name'], ' autostart: ', autostart])
        ])
        
        node_tf_map_to_odom = Node( 
            package='tf2_ros',
            executable='static_transform_publisher',
            arguments=[
                # str(robot['x_pose']), str(robot['y_pose']), str(robot['z_pose']), '0', '0', '0', 
                '0', '0', '0', '0', '0', '0',
            robot['name'] + '/map', robot['name'] + '/odom'],
            parameters=[{'use_sim_time': True}],
            output='screen')

        nav_instances_cmds.append(group)

    # Create the launch description and populate
    ld = LaunchDescription()

    # Declare the launch options
    ld.add_action(declare_simulator_cmd)
    ld.add_action(declare_world_cmd)
    ld.add_action(declare_map_yaml_cmd)
    ld.add_action(declare_robot1_params_file_cmd)
    ld.add_action(declare_robot2_params_file_cmd)
    ld.add_action(declare_robot3_params_file_cmd)
    ld.add_action(declare_robot4_params_file_cmd)
    ld.add_action(declare_use_rviz_cmd)
    ld.add_action(declare_autostart_cmd)
    ld.add_action(declare_rviz_config_file_cmd)
    ld.add_action(declare_use_robot_state_pub_cmd)

    # Add the actions to start gazebo, robots and simulations
    ld.add_action(start_gazebo_cmd)

    for simulation_instance_cmd in nav_instances_cmds:
        ld.add_action(simulation_instance_cmd)
        
    ld.add_action(node_tf_map_to_odom)
    return ld
