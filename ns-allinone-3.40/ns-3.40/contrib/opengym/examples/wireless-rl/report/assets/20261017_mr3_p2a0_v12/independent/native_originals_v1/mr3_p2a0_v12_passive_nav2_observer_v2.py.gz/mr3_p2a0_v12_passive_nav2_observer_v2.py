"""Post-known-FAIL passive Nav2 diagnostic. No control publishers or parameter writes."""
import argparse
import collections
import gzip
import faulthandler
import hashlib
import json
import os
from pathlib import Path
import time
import traceback

import rclpy
from rclpy.executors import SingleThreadedExecutor
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.qos import QoSProfile, DurabilityPolicy, ReliabilityPolicy
from rclpy.serialization import deserialize_message
from rcl_interfaces.srv import GetParameters
from geometry_msgs.msg import Twist
from nav_msgs.msg import Path as PathMessage
from dwb_msgs.msg import LocalPlanEvaluation
from std_msgs.msg import String


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def identity():
    raw = Path('/proc/self/stat').read_text()
    fields = raw[raw.rfind(')') + 2:].split()
    return {'pid': os.getpid(), 'start_ticks': int(fields[19]), 'parent': os.getppid()}


def parameter_value(value):
    types = {1: 'bool_value', 2: 'integer_value', 3: 'double_value', 4: 'string_value',
             5: 'byte_array_value', 6: 'bool_array_value', 7: 'integer_array_value',
             8: 'double_array_value', 9: 'string_array_value'}
    field = types.get(value.type)
    actual = getattr(value, field) if field else None
    if field and field.endswith('_array_value'):
        actual = list(actual)
    return {'type': value.type, 'field': field, 'value': actual}


def header(message):
    if not hasattr(message, 'header'):
        return None
    h = message.header
    return {'frame_id': h.frame_id,
            'stamp_ns': h.stamp.sec * 10**9 + h.stamp.nanosec}


class Observer(Node):
    def __init__(self, args, output):
        super().__init__('mr3_v12_passive_nav2_diagnostic',
                         parameter_overrides=[Parameter('use_sim_time', value=True)])
        self.args, self.output = args, output
        self.sequence, self.graph_sequence = 0, 0
        self.topic_counts = collections.Counter()
        self.payload_proof = {}
        self.graph, self.types, self.subs, self.clients = {}, {}, [], []
        self.motion_context = None
        self.last_graph_poll, self.closed_at = 0., None
        self.completed = False
        self.failure = None
        self.write('startup', identity=identity(), script_sha256=digest(Path(__file__).read_bytes()),
                   execution_scope='late diagnostic after known V12 activity FAIL; extra debug '
                                   'publication/subscription load; zero new formal credit',
                   source_freeze=args.freeze,
                   publisher_gid_scope='actual graph endpoints only; installed Humble drops '
                                       'MessageInfo before user callback; no per-packet GID',
                   worker_environment_binding=json.loads(Path(args.environment_receipt).read_text()))
        qos = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                         durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self.subs.append(self.create_subscription(String, '/motion_safety/status',
                                                  self.receive_context, qos))

    def write(self, kind, **values):
        self.sequence += 1
        row = {'schema': 'mr3-post-failure-passive-nav2-v1', 'kind': kind,
               'record_sequence': self.sequence, 'domain_id': self.args.domain,
               'wall_monotonic_ns': time.monotonic_ns(),
               'observer_clock_ns': self.get_clock().now().nanoseconds,
               'stage_run': self.args.run, **values}
        self.output.write(json.dumps(row, allow_nan=False, sort_keys=True) + '\n')
        self.output.flush()

    def receive_context(self, message):
        try:
            self.motion_context = json.loads(message.data)
            self.write('motion_context_received', value=self.motion_context,
                       scope='context status has epoch; diagnostic Nav2 CDR messages themselves '
                             'lack epoch, so this is not per-message epoch proof')
        except Exception as error:
            self.write('observer_context_error', error=repr(error))

    def endpoint(self, value):
        q = value.qos_profile
        return {'node': value.node_name, 'namespace': value.node_namespace,
                'topic_type': value.topic_type, 'endpoint_gid': bytes(value.endpoint_gid).hex(),
                'qos': {'depth': q.depth, 'history': int(q.history),
                        'reliability': int(q.reliability), 'durability': int(q.durability)}}

    def poll_graph(self, force=False):
        if not force and time.monotonic() - self.last_graph_poll < 2.:
            return
        self.last_graph_poll = time.monotonic()
        self.graph_sequence += 1
        self.graph = {topic: [self.endpoint(value)
                              for value in self.get_publishers_info_by_topic(topic)]
                      for topic in self.types}
        self.write('actual_graph_snapshot', graph_sequence=self.graph_sequence, endpoints=self.graph)

    def subscribe(self):
        for name in ('tb1', 'tb2', 'tb3'):
            for suffix, msg_type in (
                ('cmd_vel_nav', Twist), ('received_global_plan', PathMessage),
                ('transformed_global_plan', PathMessage), ('local_plan', PathMessage),
                ('evaluation', LocalPlanEvaluation)):
                self.types[f'/{name}/{suffix}'] = msg_type
        self.poll_graph(force=True)
        qos = QoSProfile(depth=10, reliability=ReliabilityPolicy.RELIABLE,
                         durability=DurabilityPolicy.VOLATILE)
        for topic, msg_type in self.types.items():
            callback = lambda raw, t=topic, m=msg_type: self.receive_raw(t, m, raw)
            self.subs.append(self.create_subscription(msg_type, topic, callback, qos, raw=True))
            self.write('subscription_created', topic=topic, raw=True,
                       requested_qos={'depth': 10, 'reliability': 'RELIABLE',
                                      'durability': 'VOLATILE'},
                       actual_graph_sequence=self.graph_sequence,
                       publishers=self.graph[topic])

    def receive_raw(self, topic, msg_type, raw):
        if not isinstance(raw, bytes):
            raise RuntimeError('installed raw subscription did not return CDR bytes')
        raw_sha = digest(raw)
        relative = Path('payloads') / raw_sha[:2] / (raw_sha + '.cdr.gz')
        path = Path(self.args.output_dir) / relative
        if not path.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
            encoded = gzip.compress(raw, compresslevel=1, mtime=0)
            with path.open('xb') as stream:
                stream.write(encoded)
        if raw_sha not in self.payload_proof:
            encoded = path.read_bytes()
            assert gzip.decompress(encoded) == raw
            self.payload_proof[raw_sha] = {'encoded_sha256': digest(encoded),
                                           'encoded_bytes': len(encoded)}
        message = deserialize_message(raw, msg_type)
        summary = {}
        if isinstance(message, Twist):
            summary = {'linear': {key: getattr(message.linear, key) for key in ('x', 'y', 'z')},
                       'angular': {key: getattr(message.angular, key) for key in ('x', 'y', 'z')}}
        elif isinstance(message, PathMessage):
            summary = {'poses': len(message.poses)}
            if message.poses:
                summary.update(first={'x': message.poses[0].pose.position.x,
                                      'y': message.poses[0].pose.position.y},
                               last={'x': message.poses[-1].pose.position.x,
                                     'y': message.poses[-1].pose.position.y})
        else:
            summary = {'trajectories': len(message.twists), 'best_index': message.best_index,
                       'worst_index': message.worst_index}
            if message.twists and message.best_index < len(message.twists):
                best = message.twists[message.best_index]
                summary['best'] = {'x': best.traj.velocity.x, 'y': best.traj.velocity.y,
                                   'theta': best.traj.velocity.theta, 'total': best.total,
                                   'scores': [{'name': score.name, 'scale': score.scale,
                                               'raw_score': score.raw_score} for score in best.scores]}
        self.topic_counts[topic] += 1
        self.write('raw_cdr_received', topic=topic, topic_sequence=self.topic_counts[topic],
                   raw_cdr_sha256=raw_sha, raw_cdr_bytes=len(raw), payload=str(relative),
                   payload_proof=self.payload_proof[raw_sha],
                   header=header(message), summary=summary,
                   graph_sequence=self.graph_sequence, graph_endpoints=self.graph.get(topic, []),
                   packet_publisher_gid=None,
                   publisher_identity_scope='latest actual graph snapshot, not packet MessageInfo',
                   epoch_context=self.motion_context)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', required=True)
    parser.add_argument('--domain', type=int, required=True)
    parser.add_argument('--freeze', required=True)
    parser.add_argument('--output-dir', required=True)
    parser.add_argument('--environment-receipt', required=True)
    parser.add_argument('--wall-limit-sec', type=float, default=7200.)
    args = parser.parse_args()
    faulthandler.enable(all_threads=True)
    directory = Path(args.output_dir)
    directory.mkdir(exist_ok=False)
    context, node, executor = False, None, None
    began = time.monotonic()
    result = {'scope': 'late post-known-FAIL passive diagnostic; not formal PASS evidence',
              'completed': False, 'failure': None, 'counts': {}, 'cleanup': {}}
    with (directory / 'receipts.jsonl').open('x') as output:
        try:
            output.write(json.dumps({"kind":"observer_before_ros_init","wall_monotonic_ns":time.monotonic_ns(),"identity":identity()})+"\n")
            output.flush()
            rclpy.init(args=[])
            output.write(json.dumps({"kind":"observer_after_ros_init","wall_monotonic_ns":time.monotonic_ns()})+"\n")
            output.flush()
            context = True
            node = Observer(args, output)
            executor = SingleThreadedExecutor()
            executor.add_node(node)
            names = ['FollowPath.' + key for key in (
                'publish_evaluation', 'publish_global_plan', 'publish_transformed_plan',
                'publish_local_plan', 'debug_trajectory_details', 'trajectory_generator_name')]
            for robot in ('tb1', 'tb2', 'tb3'):
                client = node.create_client(GetParameters, f'/{robot}/controller_server/get_parameters')
                node.clients.append(client)
                deadline = time.monotonic() + 10.
                while not client.service_is_ready() and time.monotonic() < deadline:
                    executor.spin_once(timeout_sec=.05)
                if not client.service_is_ready():
                    node.write('actual_parameter_service_missing', robot=robot)
                    continue
                request = GetParameters.Request()
                request.names = names
                future = client.call_async(request)
                while not future.done() and time.monotonic() < deadline:
                    executor.spin_once(timeout_sec=.05)
                if not future.done():
                    node.write('actual_parameter_timeout', robot=robot)
                    continue
                response = future.result()
                node.write('actual_parameter_response', robot=robot,
                           values={name: parameter_value(value)
                                   for name, value in zip(names, response.values)},
                           scope='GetParameters only; no set or parameter mutation')
            node.subscribe()
            while time.monotonic() - began < args.wall_limit_sec:
                executor.spin_once(timeout_sec=.05)
                node.poll_graph()
                launch = Path('/tmp/mr3_p2a0_v12_reset_launch.json')
                if launch.exists():
                    value = json.loads(launch.read_text())
                    if value.get('status') in ('completed', 'failed'):
                        if node.closed_at is None:
                            node.closed_at = time.monotonic()
                            node.write('native_stage_closed_observed', launch=value)
                        elif time.monotonic() - node.closed_at >= 2.:
                            result['finish_reason'] = 'native_stage_closed_plus_two_wall_seconds'
                            break
            else:
                result['finish_reason'] = 'observer_own_wall_limit'
            result.update(completed=True, counts=dict(node.topic_counts))
            node.write('observer_finished', result=result)
        except BaseException as error:
            result['failure'] = repr(error)
            result['traceback'] = traceback.format_exc()
            if node:
                node.write('observer_failure', error=repr(error), traceback=result['traceback'])
        finally:
            if executor:
                result['cleanup']['executor_shutdown'] = executor.shutdown(timeout_sec=5.)
            if node:
                result['cleanup']['node_destroyed'] = node.destroy_node()
            if context and rclpy.ok():
                rclpy.shutdown()
            result['cleanup']['context_shutdown'] = not rclpy.ok()
            result['wall_sec'] = time.monotonic() - began
            result['identity'] = identity()
            (directory / 'observer_summary.json').write_text(json.dumps(result, indent=2) + '\n')
    return 0 if result['failure'] is None else 1


if __name__ == '__main__':
    raise SystemExit(main())
