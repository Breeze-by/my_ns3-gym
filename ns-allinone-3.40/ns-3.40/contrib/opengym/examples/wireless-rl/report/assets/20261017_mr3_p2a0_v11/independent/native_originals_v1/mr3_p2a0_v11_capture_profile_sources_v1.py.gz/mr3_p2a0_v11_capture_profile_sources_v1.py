"""Read only whitelisted transport env and source identities of actual native process."""
from pathlib import Path
import hashlib,json,subprocess,time
ROOT=Path('/home/zhuyulab/ns3-workspace');FREEZE='ba018fe3122c478836eb4e5da9c14306cd832c1b';EP=ROOT/'ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261017_v11_interface/worker0/episode001_open_101';MON=Path('/tmp/mr3_p2a0_v11_interface_process_monitor_003.json');d=json.loads(MON.read_text());m=json.loads((EP/'metadata.json').read_text());binary=json.loads(Path('/tmp/mr3_p2a0_v11_binaryproof.json').read_text());selected=next(x for x in d['gazebo_mapped_libraries']if x['new_drive_mapped']);identity=selected['identity'];pid=identity['pid'];sha=lambda b:hashlib.sha256(b).hexdigest()
def current():
 raw=Path(f'/proc/{pid}/stat').read_text();xs=raw[raw.rfind(')')+2:].split();return{'pid':pid,'start_ticks':int(xs[19]),'parent':int(xs[1]),'state':xs[0]}
before=current();assert before['start_ticks']==identity['start_ticks'];keys=('RMW_IMPLEMENTATION','ROS_LOCALHOST_ONLY','FASTRTPS_DEFAULT_PROFILES_FILE','SKIP_DEFAULT_XML','FASTDDS_DEFAULT_PROFILES_FILE','RMW_FASTRTPS_USE_QOS_FROM_XML','RMW_FASTRTPS_PUBLICATION_MODE','ROS_DOMAIN_ID');env={}
for item in Path(f'/proc/{pid}/environ').read_bytes().split(b'\0'):
 key,sep,value=item.partition(b'=')
 if sep and key.decode()in keys:env[key.decode()]=value.decode()
for key in keys:env.setdefault(key,None)
profile=Path(env['FASTRTPS_DEFAULT_PROFILES_FILE']);raw=profile.read_bytes();relative=str(profile.relative_to(ROOT));git_raw=subprocess.check_output(['git','show',FREEZE+':'+relative],cwd=ROOT);expected=m['transport_environment'];compiled=('compiled_source_sha256','compiled_header_sha256','compiled_helper_sha256','compiled_target_contract_sha256');sources={}
for name in('tb1','tb2','tb3'):
 p=EP/('drive_'+name+'.jsonl')
 with p.open('rb')as f:configraw=f.readline()
 c=json.loads(configraw);sources[name]={'configuration':c,'configuration_raw_sha256':sha(configraw),'four_sources_match':all(c[k]==binary[k]for k in compiled),'library_matches':c['loaded_library_path']==binary['library_path'],'tagged':c['command_mode']=='tagged'}
after=current();checks={'epoch_freeze':m['freeze']==binary['freeze']==FREEZE,'identity_stable':before['start_ticks']==after['start_ticks']==identity['start_ticks'],'selected_native_env_matches_metadata':all(env[k]==expected[k]for k in keys if k!='ROS_DOMAIN_ID'),'actual_domain120':env['ROS_DOMAIN_ID']=='120','profile_disk_equals_exact_Git':raw==git_raw,'profile_sha_matches_metadata':sha(raw)==expected['profile_sha256'],'three_driver_sources':all(v['four_sources_match']and v['library_matches']and v['tagged']for v in sources.values())};result={'schema':'mr3-v11-native-profile-source-observation-v1','freeze':FREEZE,'epoch':m['epoch'],'capture_wall_monotonic_ns':time.monotonic_ns(),'monitor':str(MON),'monitor_sha256':sha(MON.read_bytes()),'actual_gz_identity_before':before,'actual_gz_identity_after':after,'actual_gz_selected_environment':env,'profile':{'path':str(profile),'sha256':sha(raw),'git_object':FREEZE+':'+relative,'git_sha256':sha(git_raw)},'drivers':sources,'checks':checks,'observed_checks_passed':all(checks.values()),'scope':'Whitelisted actual /proc environment and same PID/start identity, profile disk bytes vs exact frozen Git plus actual native configuration source tuples only. Not DDS packet identity, storage/physical/task/strict-close acceptance.'};out=Path('/tmp/mr3_p2a0_v11_interface_profile_sources_01.json')
with out.open('x')as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'output':str(out),'observed_checks_passed':result['observed_checks_passed'],'checks':checks}))
