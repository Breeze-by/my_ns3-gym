"""Read-only V22 production auditor review; no dependency-loaded gate/test run."""
import ast
import copy
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
OUT = Path(__file__).resolve().parent
P5 = Path('/tmp/mr3_p2a0_v22_production_auditor_proposal_v5')
P6 = Path('/tmp/mr3_p2a0_v22_production_auditor_proposal_v6')
SIX = Path('/tmp/mr3_p2a0_v19_conditional_world_iters150_proposal_v1/attempt02/proposed')
INPUTS = {}
GIT = {}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def stat(path):
    value = path.stat()
    return dict(device=value.st_dev, inode=value.st_ino, size=value.st_size,
                mtime_ns=value.st_mtime_ns, ctime_ns=value.st_ctime_ns)


def read(path):
    path = Path(path).absolute()
    before = stat(path)
    raw = path.read_bytes()
    assert stat(path) == before, str(path)
    record = dict(path=str(path), sha256=digest(raw), bytes=len(raw), stat=before)
    if str(path) in INPUTS:
        assert INPUTS[str(path)] == record, str(path)
    INPUTS[str(path)] = record
    return raw


def git(revision, relative):
    spec = revision + ':' + relative
    raw = subprocess.check_output(['git', 'show', spec], cwd=ROOT)
    GIT[spec] = dict(sha256=digest(raw), bytes=len(raw))
    return raw


def dump(node):
    return ast.dump(node, include_attributes=False)


def defs(tree):
    return {node.name: node for node in tree.body
            if isinstance(node, (ast.FunctionDef, ast.ClassDef))}


def assignments(tree):
    return {node.targets[0].id: node for node in tree.body
            if isinstance(node, ast.Assign) and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)}


def literals(tree):
    body = [node for node in tree.body if isinstance(node, ast.Assign)]
    assert not any(isinstance(node, ast.Call) for statement in body for node in ast.walk(statement))
    ns = {}
    exec(compile(ast.Module(body=copy.deepcopy(body), type_ignores=[]), '<static literal assignments>', 'exec'), ns)
    return ns


def statement(text):
    return ast.parse(text).body[0]


def replace_once(body, old, new):
    indices = [index for index, node in enumerate(body) if dump(node) == dump(old)]
    assert len(indices) == 1, ast.unparse(old)
    index = indices[0]
    if new is None:
        del body[index]
    else:
        body[index] = copy.deepcopy(new)


def main():
    started = time.monotonic()
    source = read(P5 / 'proposed_audit_ppo.py')
    original = read(P5 / 'original_audit_ppo.py')
    test5 = read(P5 / 'proposed_test_audit_ppo.py')
    test6 = read(P6 / 'proposed_test_audit_ppo.py')
    original_test = read(P5 / 'original_test_audit_ppo.py')
    assert digest(source) == 'de297d83fd5436651e526fe9782ac0ebed02573ed9aa735a58d9fdcf613c0adf'
    assert read(P6 / 'proposed_audit_ppo.py') == source
    assert digest(test6) == '43e13e592e637b147d098bd21b874aea2764ca5af81494233469f340874cee57'
    tree, old = ast.parse(source), ast.parse(original)
    current_defs, old_defs = defs(tree), defs(old)
    added_functions = sorted(set(current_defs) - set(old_defs))
    assert added_functions == sorted(['verify_machine_task_file', 'verify_environment_appendix',
                                     'project_sensor_diagnostic_runtime', 'project_ray_box_runtime',
                                     'verify_execution_configs', 'verify_ray_box_library'])
    changed_functions = sorted(name for name in old_defs if dump(old_defs[name]) != dump(current_defs[name]))
    assert changed_functions == ['load_compatible_components', 'load_native_gates']
    ns, old_ns = literals(tree), literals(old)
    old_assignments, new_assignments = assignments(old), assignments(tree)
    common_changed = [name for name in old_assignments
                      if dump(old_assignments[name]) != dump(new_assignments[name])]
    assert common_changed == ['ENV_DOCUMENT_SHA256']
    # Independent whole-module inverse: only two exact loader substitutions,
    # the ENV digest, six reviewed helpers, and their literal constants.
    inverse = copy.deepcopy(tree)
    inv_defs = defs(inverse)
    replace_once(inv_defs['load_compatible_components'].body,
                 statement('proof.update(verify_execution_configs(root, freeze))'),
                 statement('proof.update(verify_frozen_pins(root, freeze, EXECUTION_CONFIG_PINS, "execution config"))'))
    replace_once(inv_defs['load_compatible_components'].body,
                 statement('proof.update(verify_ray_box_library(root, freeze))'), None)
    replace_once(inv_defs['load_native_gates'].body,
                 statement('proof[WIRELESS + "MR3_ENV_CONTRACT.md"].update(verify_environment_appendix(root, freeze))'), None)
    new_loop = statement('for relative in machine_paths:\n    proof[relative] = verify_machine_task_file(root, freeze, relative)')
    old_loop = next(node for node in old_defs['load_native_gates'].body
                    if isinstance(node, ast.For) and isinstance(node.iter, ast.Name)
                    and node.iter.id == 'machine_paths')
    replace_once(inv_defs['load_native_gates'].body, new_loop, old_loop)
    added_constants = set(new_assignments) - set(old_assignments)
    inverse.body = [node for node in inverse.body if not (
        isinstance(node, ast.FunctionDef) and node.name in added_functions) and not (
        isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)
        and node.targets[0].id in added_constants)]
    assignments(inverse)['ENV_DOCUMENT_SHA256'].value = copy.deepcopy(old_assignments['ENV_DOCUMENT_SHA256'].value)
    assert dump(inverse) == dump(old)

    test_old_tree, t5, t6 = ast.parse(original_test), ast.parse(test5), ast.parse(test6)
    methods = lambda value: {cls.name + '.' + method.name: method
                             for cls in value.body if isinstance(cls, ast.ClassDef)
                             for method in cls.body if isinstance(method, ast.FunctionDef)}
    old_methods, m5, m6 = methods(test_old_tree), methods(t5), methods(t6)
    assert [name for name in old_methods if dump(old_methods[name]) != dump(m5[name])] == ['NativeBindingTests.loader']
    changed_v6 = [name for name in m5 if dump(m5[name]) != dump(m6[name])]
    exact_test = 'VersionedNativeGateTests.test_explicit_runtime_extensions_keep_original_helpers_exact'
    assert changed_v6 == [exact_test]
    # Restore only the two-path v6 branch to its old else statements.
    corrected = copy.deepcopy(t6)
    corrected_methods = methods(corrected)
    loop = next(node for node in corrected_methods[exact_test].body
                if isinstance(node, ast.For) and ast.unparse(node.iter) == 'audit_ppo.EXECUTION_CONFIG_PINS.items()')
    assert len(loop.body) == 1 and isinstance(loop.body[0], ast.If)
    assert ast.unparse(loop.body[0].test) == 'path in audit_ppo.RAY_BOX_EXECUTION_PINS'
    loop.body = copy.deepcopy(loop.body[0].orelse)
    assert dump(corrected) == dump(t5)
    assert len([name for name in old_methods if name.split('.')[-1].startswith('test_')]) == 12

    # Execute only side-effect-free inverse text helpers, never the proposed
    # dependency-loaded module, tests, or native-gate entry point.
    helper_body = [copy.deepcopy(node) for node in tree.body if isinstance(node, ast.FunctionDef)
                   and node.name in ('require', 'project_ray_box_runtime', 'project_sensor_diagnostic_runtime')]
    exec(compile(ast.Module(body=helper_body, type_ignores=[]), '<reviewed static inverse helpers>', 'exec'), ns)
    execution = []
    for path, expected in ns['RAY_BOX_EXECUTION_PINS'].items():
        actual = read(ROOT / path)
        assert digest(actual) == expected
        intermediate = ns['project_ray_box_runtime'](path, actual)
        assert digest(intermediate) == ns['SENSOR_DIAGNOSTIC_CONFIG_PINS'][path]
        normative = git(ns['EXECUTION_NORMATIVE_FREEZE'], path)
        assert digest(normative) == ns['EXECUTION_NORMATIVE_PINS'][path]
        projected = ns['project_sensor_diagnostic_runtime'](path, intermediate)
        assert projected == normative
        execution.append(dict(path=path, actual_sha256=expected,
                              intermediate_sha256=digest(intermediate), normative_sha256=digest(normative)))

    anchor = b'      <real_time_update_rate>1000</real_time_update_rate>\n'
    block = b'      <ode>\n        <solver>\n          <type>quick</type>\n          <iters>150</iters>\n        </solver>\n      </ode>\n'
    machine = []
    for path, expected in {**ns['SOLVER150_WORLD_PINS'], **ns['SOLVER150_TASK_PINS']}.items():
        world = path in ns['SOLVER150_WORLD_PINS']
        sealed_path = SIX / ('worlds' if world else 'config') / Path(path).name
        actual = read(sealed_path)
        assert digest(actual) == expected
        normative = git(ns['TASK_BASE_FREEZE'], path)
        if world:
            assert normative.count(anchor) == 1 and b'<ode>' not in normative
            assert actual.count(block) == 1
            assert actual == normative.replace(anchor, anchor + block, 1)
            assert actual.replace(block, b'', 1) == normative
        else:
            matching = ns['ROS'] + 'src/multi_robot/worlds/p1c_' + Path(path).stem + '.world'
            old_world = git(ns['TASK_BASE_FREEZE'], matching)
            old_field = ('  "world_sha256": "' + digest(old_world) + '",\n').encode()
            new_field = ('  "world_sha256": "' + ns['SOLVER150_WORLD_PINS'][matching] + '",\n').encode()
            assert normative.count(old_field) == actual.count(new_field) == 1
            assert actual == normative.replace(old_field, new_field, 1)
            assert actual.replace(new_field, old_field, 1) == normative
        machine.append(dict(path=path, prospective_actual_sha256=expected,
                            normative_sha256=digest(normative), sealed_source=str(sealed_path)))
    env = read(P5 / 'MR3_ENV_CONTRACT.proposed.md')
    env_old = git(ns['ENV_NORMATIVE_FREEZE'], ns['WIRELESS'] + 'MR3_ENV_CONTRACT.md')
    assert digest(env) == ns['ENV_DOCUMENT_SHA256']
    assert read(P5 / 'MR3_ENV_CONTRACT.original.md') == env_old
    assert len(env_old) == 40186 and len(env) == 47721
    assert env == env_old + read(P5 / 'ENV_appendix_v2.txt')
    assert len(env) - len(env_old) == ns['ENV_EXECUTION_APPENDIX_BYTES']
    assert digest(env[len(env_old):]) == ns['ENV_EXECUTION_APPENDIX_SHA256']

    source3 = {}
    for path, expected in {**ns['RAY_BOX_SOURCE_PINS'], **ns['RAY_BOX_LICENSE_PINS']}.items():
        assert digest(read(ROOT / path)) == expected
        source3[path] = expected
    spec = ns['RAY_BOX_LIBRARY_SPEC']
    binary = {}
    for key in ('receipt', 'build', 'archive', 'library', 'ode_library'):
        entry = spec[key]
        path = ROOT / entry['path']
        raw = read(path)
        assert len(raw) == entry['bytes'] and digest(raw) == entry['sha256']
        if 'resolved' in entry:
            assert path.resolve(strict=True) == (ROOT / entry['resolved']).resolve(strict=True)
        binary[key] = dict(path=str(path), sha256=digest(raw), bytes=len(raw))
    library = read(ROOT / spec['library']['path'])
    assert library[:4] == b'\x7fELF'
    assert gzip.decompress(read(ROOT / spec['archive']['path'])) == library
    receipt = json.loads(read(ROOT / spec['receipt']['path']))
    assert receipt['passed'] is True and receipt['old_four_libraries_byte_unchanged'] is True
    for path, expected in ns['RAY_BOX_SOURCE_PINS'].items():
        assert expected.encode() in library
        short = str(Path(path).relative_to(ns['ROS'] + 'src/multi_robot'))
        assert receipt['sources'][short]['sha256'] == expected
    for name, entry in spec['unchanged_libraries'].items():
        path = ROOT / entry['path']
        raw = read(path)
        assert raw[:4] == b'\x7fELF' and len(raw) == entry['bytes'] and digest(raw) == entry['sha256']
        assert path.resolve(strict=True) == (ROOT / entry['resolved']).resolve(strict=True)
        binary[name] = dict(path=str(path), bytes=len(raw), sha256=digest(raw))
    # Retained explicit pins are not silently refreshed by this proposal.
    assert ns['PREPARATION_RUNTIME_PINS'] == old_ns['PREPARATION_RUNTIME_PINS']
    assert ns['SLAM_RUNTIME_PINS'] == old_ns['SLAM_RUNTIME_PINS']
    assert ns['EXECUTION_CONFIG_PINS'] == old_ns['EXECUTION_CONFIG_PINS']
    assert ns['CURRENT_AUDITOR_PINS'] == old_ns['CURRENT_AUDITOR_PINS']
    assert ns['EVALUATOR_PHASE_PINS'] == old_ns['EVALUATOR_PHASE_PINS']
    prep_path = ROOT / ns['WIRELESS'] / 'mr3_learning/audit_preparation.py'
    prep = ast.parse(read(prep_path))
    assert any(isinstance(node, ast.ImportFrom) and node.module == 'audit_ppo'
               and any(alias.name == 'load_native_gates' for alias in node.names)
               for node in ast.walk(prep))
    assert any(isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
               and node.func.id == 'load_native_gates' for node in ast.walk(prep))
    assert any(isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
               and node.func.id == 'load_native_gates' for node in ast.walk(current_defs['audit_run']))
    assert any(isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
               and node.func.id == 'load_compatible_components' for node in ast.walk(current_defs['load_native_gates']))
    checks5 = json.loads(read(P5 / 'checks_v5.json'))
    checks6 = json.loads(read(P6 / 'checks_v6.json'))
    assert checks5['passed'] is True and checks6['passed'] is True
    for path, record in INPUTS.items():
        assert stat(Path(path)) == record['stat'] and digest(Path(path).read_bytes()) == record['sha256']
    report = dict(schema='mr3-v22-production-auditor-independent-review-v1', passed=True,
                  blockers=[], source_auditor_sha256=digest(source), test_v5_sha256=digest(test5),
                  final_test_v6_sha256=digest(test6), environment_sha256=digest(env),
                  original_mathematical_and_other_functions_ast_unchanged=sorted(set(old_defs) - set(changed_functions)),
                  changed_loader_functions_only=changed_functions,
                  original_module_whole_ast_after_exact_authorized_inverse=True,
                  explicit_old_runtime_pin_dictionaries_unchanged=True,
                  original_12_tests_v5_ast_unchanged=True,
                  resolved_failure=dict(v5='Two old assertions expected normative SHA in actual-SHA proof slots; this fails the complete original class.',
                                        v6='Only exact2 execution paths now bind actual and normative SHA separately plus whole inverse; all other original assertions retained.',
                                        v6_to_v5_only_exact_test_branch_inverse=True,
                                        author_complete_test_result='16 methods PASS recorded in checks_v6, not repeated here'),
                  execution_two_level_whole_byte_inverse=execution, fixed_six_machine_projection=machine,
                  environment_append_only=dict(original_bytes=len(env_old), appendix_bytes=len(env)-len(env_old), actual_bytes=len(env)),
                  binary_bindings=binary, current_source_bindings=source3,
                  shared_actual_call_chain=['audit_preparation.audit -> imported audit_ppo.load_native_gates',
                                            'audit_ppo.audit_run -> load_native_gates -> load_compatible_components -> execution and actual binary verifiers'],
                  no_generalized_bypass='Six fixed literal machine paths and fixed exact2 execution sources only; normative bytes are read independently from fixed Git authorities. Other machine/config paths retain exact W7 or existing explicit pins.',
                  scope='Read-only source/AST/data identity review. No 40 CPU rerun, full dependency-loaded auditor/source-preflight, compiler, factory, ldd, SDK or native execution.',
                  pending=['Root exact promotion and full conda checks', 'New clean pushed freeze actual Git/worktree source preflight', 'Per-episode actual mapping/callback/native150-dt custody and same-freeze full four-stage matrix'],
                  input_final_sha_stat_stable=True, inputs=list(INPUTS.values()), normative_git_objects=GIT,
                  argv=sys.argv, cwd=os.getcwd(), wall_seconds=time.monotonic()-started)
    destination = OUT / 'review_v1.json'
    with destination.open('x') as target:
        json.dump(report, target, indent=2)
        target.write('\n')
    print(json.dumps(dict(passed=True, report=str(destination), sha256=digest(destination.read_bytes()),
                          inputs=len(INPUTS), normative_git_objects=len(GIT), wall_seconds=report['wall_seconds'])))


if __name__ == '__main__':
    main()
