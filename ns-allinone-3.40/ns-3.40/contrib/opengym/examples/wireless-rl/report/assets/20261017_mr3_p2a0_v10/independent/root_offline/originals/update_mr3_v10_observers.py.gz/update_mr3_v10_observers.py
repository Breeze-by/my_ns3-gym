from pathlib import Path

root=Path('/home/zhuyulab/ns3-workspace')
ind=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v10/independent'
p=ind/'mr3_v10_fifo_phase_review.py';s=p.read_text()
s=s.replace("    motion_consumed = []\n    for r in rows('motion_phase_worker.jsonl'):", """    motion_consumed = []
    stop_observed = []
    phase_rows = list(rows('motion_phase_worker.jsonl'))
    for control in rows('control_phase_worker.jsonl'):
        if control['kind'] == 'stop_observed':
            status = control['status']
            check(status.get('phase_kind') == 'stop' and status.get('ready') is False
                  and all(canon(value) == canon({'linear_x': 0., 'angular_z': 0.})
                          for value in status['outputs'].values()), 'stop status is not strict zero')
            phase_rows.append(dict(control, kind='stop_observed', ack=status))
            stop_observed.append(status)
    for r in phase_rows:""")
s=s.replace("check(bool(motion_consumed) and motion_consumed[-1]['clock_ns'] == final, 'final motion ACK missing')", "check(any(x['clock_ns'] == final for x in motion_consumed + stop_observed), 'final normal/strict-zero actual motion receipt missing')")
s=s.replace("check({r['request_id'] for r in positive}==set(advances),'positive20tick requests differ from driver advance ledger')", "check({r['request_id'] for r in positive}=={key for key,value in advances.items() if value['start_time_ns'] >= release and value['steps'] == 20},'post-release positive20tick requests differ from driver advance ledger')")
s=s.replace("'schema':'mr3-v9-final", "'schema':'mr3-v10-final")
s=s.replace("'motion_consumed_acks':len(motion_consumed),", "'motion_consumed_acks':len(motion_consumed),'strict_zero_stop_observations':len(stop_observed),")
s=s.replace('Frozen full drive reader remains complete acceptance gate;', 'Frozen full drive v5 and mandatory control-chain reader remain complete acceptance gates including bootstrap and stop authorization;')
p.write_text(s)
p=ind/'mr3_readonly_v10_body_live.py';s=p.read_text();s=s.replace("'freeze':'26534fae40409e266376baf0995fb15dc0223e4b'", "'freeze':sys.argv[3]")
s=s.replace('mr3-v9-', 'mr3-v10-');p.write_text(s)
p=ind/'mr3_v10_multiepoch_closure_binary_review_v1.py';s=p.read_text().replace('mr3-v9-','mr3-v10-');p.write_text(s)
p=ind/'mr3_p2a0_v10_plan_launcher_tests_v1.py';s=p.read_text();needle="        self.assertEqual(new['unchanged_gates'], old['unchanged_gates'])"
s=s.replace(needle,"""        old_v9 = json.loads((ROOT / (
            'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
            'report/assets/20261017_mr3_p2a0_v9/predeclared_plan_v9.json')).read_text())
        self.assertEqual(new['independent_source_bindings'][:33],
                         old_v9['independent_source_bindings'])
"""+needle)
p.write_text(s)
print('v10 observer protocols versioned; old consumers unchanged')
