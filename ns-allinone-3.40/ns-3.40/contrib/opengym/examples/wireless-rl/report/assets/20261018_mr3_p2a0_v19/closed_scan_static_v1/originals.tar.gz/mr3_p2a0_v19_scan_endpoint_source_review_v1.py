#!/usr/bin/env python3
"""Read-only closed-evidence/source review. No ROS, native, or formal replay."""
import hashlib
import json
import math
from pathlib import Path
import struct
import subprocess
import sys
import time
import urllib.request
import xml.etree.ElementTree as ET

ROOT = Path('/home/zhuyulab/ns3-workspace')
ROS = ROOT / 'ros2_ws/ros2-multi-robot-automap'
FREEZE = '72d0465ddd1bbee09af117cfd9d89b7e729f8578'
OUT = Path('/tmp/mr3_p2a0_v19_scan_endpoint_source_review_v1.json')
SOURCES = Path('/tmp/mr3_p2a0_v19_scan_endpoint_sources_v1')
LOCAL = [
 'src/slam_toolbox/src/laser_utils.cpp',
 'src/slam_toolbox/include/slam_toolbox/laser_utils.hpp',
 'src/slam_toolbox/lib/karto_sdk/src/Karto.cpp',
 'src/slam_toolbox/lib/karto_sdk/include/karto_sdk/Karto.h',
 'src/slam_toolbox/lib/karto_sdk/src/Mapper.cpp',
 'src/slam_toolbox/src/slam_toolbox_common.cpp',
 'src/slam_toolbox/src/slam_toolbox_multirobot.cpp',
 'src/slam_toolbox/src/slam_mapper.cpp',
 'src/slam_toolbox/launch/online_async_multirobot_launch.py',
 'src/slam_toolbox/config/mapper_params_online_multi_async.yaml',
 'src/slam_toolbox/CMakeLists.txt',
 'src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py',
 'src/multi_robot/urdf/turtlebot3_waffle.urdf',
 'src/multi_robot/models/turtlebot3_waffle/model.sdf',
]
OFFICIAL = {
 'RaySensor_11.10.2.cc': 'https://raw.githubusercontent.com/gazebosim/gazebo-classic/gazebo11_11.10.2/gazebo/sensors/RaySensor.cc',
 'MultiRayShape_11.10.2.cc': 'https://raw.githubusercontent.com/gazebosim/gazebo-classic/gazebo11_11.10.2/gazebo/physics/MultiRayShape.cc',
 'ODEMultiRayShape_11.10.2.cc': 'https://raw.githubusercontent.com/gazebosim/gazebo-classic/gazebo11_11.10.2/gazebo/physics/ode/ODEMultiRayShape.cc',
 'Joint_11.10.2.cc': 'https://raw.githubusercontent.com/gazebosim/gazebo-classic/gazebo11_11.10.2/gazebo/physics/Joint.cc',
 'gazebo_ros_ray_sensor_3.9.0.cpp': 'https://raw.githubusercontent.com/ros-simulation/gazebo_ros_pkgs/3.9.0/gazebo_plugins/src/gazebo_ros_ray_sensor.cpp',
 'sensor_msgs_conversions_3.9.0.hpp': 'https://raw.githubusercontent.com/ros-simulation/gazebo_ros_pkgs/3.9.0/gazebo_ros/include/gazebo_ros/conversions/sensor_msgs.hpp',
}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def write(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)

def f32(value):
    return struct.unpack('f', struct.pack('f', value))[0]

def model_geometry(path):
    model = ET.fromstring(path.read_bytes()).find('model')
    sensor = model.find("link[@name='base_scan']/sensor")
    return {
      'base_footprint_link_pose': model.findtext("link[@name='base_footprint']/pose", 'implicit_zero'),
      'base_link_pose': model.findtext("link[@name='base_link']/pose", 'implicit_zero'),
      'base_scan_link_pose': model.findtext("link[@name='base_scan']/pose", 'implicit_zero'),
      'base_joint': ET.tostring(model.find("joint[@name='base_joint']"), encoding='unicode'),
      'lidar_joint': ET.tostring(model.find("joint[@name='lidar_joint']"), encoding='unicode'),
      'sensor': ET.tostring(sensor, encoding='unicode'),
    }

def main():
    started = time.monotonic()
    SOURCES.mkdir(exist_ok=False)
    bindings, source_records = {}, []
    for rel in LOCAL:
        path = ROS / rel
        raw = path.read_bytes()
        gitrel = path.relative_to(ROOT).as_posix()
        frozen = subprocess.check_output(['git', '-C', str(ROOT), 'show', FREEZE + ':' + gitrel])
        assert frozen == raw, gitrel
        target = SOURCES / 'local' / rel
        write(target, raw)
        bindings[str(path)] = sha(raw)
        source_records.append({'source': str(path), 'copy': str(target), 'sha256': sha(raw),
                               'bytes': len(raw), 'freeze_exact': True})
    for name, url in OFFICIAL.items():
        raw = urllib.request.urlopen(url, timeout=30).read()
        target = SOURCES / 'official' / name
        write(target, raw)
        source_records.append({'url': url, 'copy': str(target), 'sha256': sha(raw), 'bytes': len(raw),
                               'scope': 'official tagged source; package-version match, not rebuilt binary equivalence'})
    package_command = ['dpkg-query', '-W', 'ros-humble-gazebo-plugins', 'ros-humble-gazebo-ros', 'gazebo', 'libgazebo11']
    packages = subprocess.check_output(package_command, text=True)
    stages = {}
    for stage in ('baseline', 'iters150'):
        episode = ROS / 'log/mr3_p2a0' / ('mr3_p2a0_20261018_v19_' + stage) / 'worker0/episode001_open_101'
        paths = sorted(p for p in episode.rglob('*') if p.is_file())
        suspicious = [p.relative_to(episode).as_posix() for p in paths
                      if any(term in p.name.lower() for term in ('scan', 'laser', 'tf_static', 'rosbag'))
                      or p.suffix in ('.db3', '.mcap')]
        log = episode / 'launch.log'
        raw = log.read_bytes()
        bindings[str(log)] = sha(raw)
        relevant, processes, temporary_parameters = [], [], []
        for number, line in enumerate(raw.decode(errors='replace').splitlines(), 1):
            if any(term in line for term in ('clipped range threshold', 'maximum laser range',
                 'Registering sensor', 'Unregistering sensor', 'Message Filter dropping message')):
                relevant.append({'source_line': number, 'text': line})
            marker = 'MR3_ORDERED_SHUTDOWN '
            if marker in line:
                row = json.loads(line.split(marker, 1)[1])
                if row.get('event') == 'process_started' and any(
                    term in row.get('process_name', '') for term in ('slam_toolbox', 'robot_state_publisher')):
                    processes.append({'source_line': number, 'record': row})
                    argv = row['argv']
                    for i, token in enumerate(argv[:-1]):
                        if token == '--params-file':
                            path = Path(argv[i + 1])
                            entry = {'path': str(path), 'exists_after_close': path.exists()}
                            if path.exists():
                                data = path.read_bytes()
                                target = SOURCES / stage / path.name
                                if not target.exists():
                                    write(target, data)
                                entry.update({'copy': str(target), 'sha256': sha(data), 'text': data.decode()})
                                bindings[str(path)] = sha(data)
                            temporary_parameters.append(entry)
        stages[stage] = {'episode': str(episode), 'file_count': len(paths),
          'raw_scan_or_bag_filename_matches': suspicious,
          'filename_inventory_scope': 'all regular episode files; no large raw ledger contents scanned',
          'launch_log_sha256': sha(raw), 'launch_log_relevant': relevant,
          'actual_process_arguments': processes, 'parameters_after_close': temporary_parameters,
          'actual_model_geometry': {name: model_geometry(episode / ('drive_model_' + name + '.sdf'))
                                    for name in ('tb1', 'tb2', 'tb3')}}
        for name in ('tb1', 'tb2', 'tb3'):
            path = episode / ('drive_model_' + name + '.sdf')
            bindings[str(path)] = sha(path.read_bytes())
    urdf = ET.fromstring((ROS / LOCAL[-2]).read_bytes())
    joints = {name: ET.tostring(urdf.find("joint[@name='" + name + "']"), encoding='unicode')
              for name in ('base_joint', 'scan_joint')}
    minimum = f32(.12)
    cases = []
    for label, gaz_value in [('below_min_masked', -math.inf), ('clamped_min', .12),
                             ('just_above_min_float32', f32(.12) + 2**-27),
                             ('no_return', math.inf), ('clamped_max', 10.0), ('nan', math.nan)]:
        wire = f32(gaz_value)
        ignored = wire <= minimum or wire >= f32(10.0) or math.isnan(wire)
        cases.append({'case': label, 'wire_float32_hex': struct.pack('f', wire).hex(),
          'wire_value': repr(wire), 'minimum_float32': minimum,
          'occupancy_endpoint_ignored': ignored,
          'scope': 'independent scalar transcription of exact AddScan rejection predicate; not native replay'})
    assert [x['occupancy_endpoint_ignored'] for x in cases] == [True, True, False, True, True, True]
    result = {
      'schema': 'mr3-v19-scan-endpoint-source-review-v1', 'review_complete': True,
      'freeze': FREEZE, 'physical_profile_selected': False,
      'source_records': source_records, 'installed_packages': {'argv': package_command, 'stdout': packages},
      'stages': stages, 'declared_URDF_joints': joints, 'float32_endpoint_cases': cases,
      'findings': [
        'Gazebo11 RaySensor445-460 masks raw range<=min as -inf and >=max as +inf before noise; only interior noisy values clamp to min/max.',
        'ROS3.9.0 LaserScan converter copies ranges and min/max into float32; scanToReadings converts floats to doubles without replacement.',
        'Karto AddScan skips <=min, >=max and NaN; exact clipped-min, below-min and no-return therefore cannot directly add occupied endpoints. A valid just-above-min finite reading remains eligible.',
        'LaserRangeFinder GetPointReadings has a clipping branch, but OccupancyGrid uses LocalizedRangeScan unfiltered points with the original range and its explicit rejection predicate; citing generic clipping alone is misleading.',
        'The native max-range warning concerns declared20m versus sensor10m and is identical in baseline/contrast; it is not a min-range warning.',
        'CMake selects MultiRobotSlamToolbox::laserCallback which calls addScan directly. Karto Process accepts first scan and later accepts time>=.5s OR movement/heading; stationary scans can still enter.',
        'Successfully processed scans are retained in dataset/mapper and map rebuilding uses all processed scans. Startup contamination is possible in principle; no closed raw scan/processed-pose archive proves it happened.',
        'Declared planar sensor origin in SDF and URDF is x=-.064,y=0. SDF joint anchor pose must not be added as another child-link pose. URDF footprint-to-lidar z=.131 versus SDF model-relative sensorz=.121 is a declared vertical difference, not proof of an erroneous actual TF or the near occupied cells.',
        'Projected occupied-cell centres below nominal minimum range are not individual beam endpoints: source-cell extent, reprojection, acquisition-time pose and corrected scan pose must be resolved before inferring below-min returns.',
        'Current raw map evidence proves own mapper asserted100 and downstream navigation preserved it; it cannot classify actual obstacle, self-hit, floor-hit or historical registration error.'
      ],
      'minimal_next_action': {
        'production_repair_selected': False,
        'reason': 'Closed evidence rejects simple exact-min/no-return clipping hypothesis but does not identify the upstream hit/pose that created100.',
        'bounded_passive_capture': ['earliest raw /tbN/scan CDR including nonfinite float patterns',
          'actual /tbN/tf and /tbN/tf_static, stamped odometry',
          'existing /tbN/pose accepted corrected base pose (published only after processed scan; stamp matches original scan)',
          'earliest /tbN/map raw grids and geometry'],
        'conditional_repairs_only': ['if exact TF/model mismatch demonstrated, correct one extrinsic source and prove known targets round-trip',
          'if startup scans demonstrably contain invalid geometry, introduce a sensor-validity startup admission barrier before SLAM integration and retain original scans',
          'if finite genuine valid hits cause obstruction, preserve occupied cells and investigate sensor/scene/self-collision geometry; no unconditional range cut or footprint clearing'],
        'prohibited_inference': 'No .12 filter, occupied erasure, .29 clearance reduction, solver choice, candidate fallback, PPO or95% credit justified by this review.'},
      'inputs_sha256': bindings,
      'all_inputs_unchanged': all(sha(Path(path).read_bytes()) == value for path, value in bindings.items()),
      'execution': {'argv': sys.argv, 'wall_seconds': time.monotonic() - started,
                    'scope': 'source/closed small logs/XML/filename inventory + six scalar cases; no ROS/native/formal/large raw scans'},
      'writers': 'STOP after report and separate self-excluded seal',
    }
    assert result['all_inputs_unchanged']
    write(OUT, (json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode())
    print(json.dumps({'output': str(OUT), 'sha256': sha(OUT.read_bytes()), 'wall_seconds': result['execution']['wall_seconds']}))

if __name__ == '__main__':
    main()
