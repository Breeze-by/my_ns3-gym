import pathlib,importlib.util,unittest
source=pathlib.Path("/home/zhuyulab/ns3-workspace/ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v16/independent/mr3_p2a0_v16_audit_stage_tests_v1.py")
spec=importlib.util.spec_from_file_location("v16_canonical_scheduler",source);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.OLD_PLAN=pathlib.Path("/tmp/mr3_p2a0_v16_matrix_draft_v1/predeclared_plan_v16.json")
suite=unittest.defaultTestLoader.loadTestsFromModule(module);assert suite.countTestCases()==9
result=unittest.TextTestRunner(verbosity=2).run(suite);raise SystemExit(0 if result.wasSuccessful() else 1)
