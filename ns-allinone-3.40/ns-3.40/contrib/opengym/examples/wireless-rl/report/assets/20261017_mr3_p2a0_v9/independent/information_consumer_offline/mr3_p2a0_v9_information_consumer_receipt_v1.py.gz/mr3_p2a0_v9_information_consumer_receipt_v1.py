import hashlib
import json
from pathlib import Path

ROOT = Path('/home/zhuyulab/ns3-workspace')
PREFIX = 'mr3_p2a0_v9_information_'
TMP = Path('/tmp')
OUT = TMP / 'mr3_p2a0_v9_information_consumer_checks_v1.json'
ASSETS = ROOT / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/'
                 '20261017_mr3_p2a0_v9/independent')


def binding(path):
    data = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}


sources = [ASSETS / name for name in ('mr3_independent_information_v1.py',
                                     'mr3_independent_information_v1_tests.py')]
assert all(path.read_bytes() == (TMP / path.name).read_bytes() for path in sources)
for path in sources:
    compile(path.read_bytes(), str(path), 'exec')
logs = sorted(TMP.glob(PREFIX + 'consumer_*'))
logs += sorted(TMP.glob(PREFIX + 'raw_counterexample_v1.*'))
logs = [path for path in logs if path.is_file() and path != OUT]
assert 'Ran 25 tests' in (TMP / (PREFIX + 'consumer_tests_06.log')).read_text()
assert (TMP / (PREFIX + 'consumer_tests_06.log')).read_text().endswith('\nOK\n')
assert not (TMP / (PREFIX + 'consumer_style_07.log')).read_bytes()
compat = json.loads((TMP / (PREFIX + 'consumer_compat_v1.json')).read_text())
assert compat['passed'] is True
counter = json.loads((TMP / (PREFIX + 'raw_counterexample_v1.json')).read_text())
assert counter['passed'] is True
result = {
    'schema': 'mr3-information-independent-checks-v1', 'passed': True,
    'cwd': str(ROOT), 'source_bindings': [binding(path) for path in sources],
    'checks': [
        {'name': 'final_stdlib_mutation_tests', 'exit_code': 0, 'methods_passed': 25,
         'test_elapsed_sec': 1.567,
         'argv': ['env', 'PYTHONDONTWRITEBYTECODE=1', '/usr/bin/python3',
                  '/tmp/mr3_independent_information_v1_tests.py'],
         'stdout_stderr': binding(TMP / (PREFIX + 'consumer_tests_06.log'))},
        {'name': 'final_system_flake8', 'exit_code': 0,
         'argv': ['env', 'PYTHONDONTWRITECODE=1', '/usr/bin/python3', '-m', 'flake8',
                  '/tmp/mr3_independent_information_v1.py',
                  '/tmp/mr3_independent_information_v1_tests.py', '--max-line-length=99'],
         'note': 'The recorded env spelling PYTHONDONTWRITECODE is preserved exactly; '
                 'flake8 still passed and no production module was imported.',
         'stdout_stderr': binding(TMP / (PREFIX + 'consumer_style_07.log'))},
        {'name': 'real_producer_cpu_fixture_compat', 'exit_code': 0,
         'argv': ['env', 'PYTHONDONTWRITEBYTECODE=1', '/usr/bin/python3',
                  '/tmp/mr3_p2a0_v9_information_consumer_compat_v1.py'],
         'result': binding(TMP / (PREFIX + 'consumer_compat_v1.json')),
         'stdout_stderr': binding(TMP / (PREFIX + 'consumer_compat_v1.log'))},
        {'name': 'actual_v8_raw_values_concrete_hazard_replay', 'exit_code': 0,
         'argv': ['env', 'PYTHONDONTWRITEBYTECODE=1', '/usr/bin/python3',
                  '/tmp/mr3_p2a0_v9_information_raw_counterexample_v1.py'],
         'result': binding(TMP / (PREFIX + 'raw_counterexample_v1.json')),
         'stdout_stderr': binding(TMP / (PREFIX + 'raw_counterexample_v1.log'))},
        {'name': 'canonical_byte_and_syntax_check', 'passed': True,
         'method': 'each canonical file equals /tmp tested bytes; built-in compile(...,exec), '
                   'no pycache writes or production imports'}],
    'history': {
        'all_prior_stdout_stderr_preserved': True,
        'initial_style_failures_not_overwritten': [str(TMP / (PREFIX + 'consumer_style_01.log')),
                                                  str(TMP / (PREFIX + 'consumer_style_02.log'))],
        'review': 'Runtime independently identified cached received-stamp rewriting, dict== typed '
                  'placeholder and configuration strictness gaps. Those are fixed and mutation-tested. '
                  'Its earliest inspected draft was not separately frozen with an exact SHA; no '
                  'claim that final source bytes equal that draft. The later before-cache snapshot '
                  'is separately preserved, not substituted for the historical review.',
        'before_cache_snapshot': binding(TMP / 'mr3_independent_information_v1_before_cache_fix.py')},
    'test_scope': [
        'future19ms keeps causal odometry and later promotes future; late causal arrival is admitted',
        'raw source/hash/sequence, duplicate/conflicting/backwards/overflow, old TF pending semantics',
        'received envelopes match send, cached received_stamp cannot be refreshed, all side publications bind',
        'each motion receipt must originate in an earlier publish-call start; publications may be missed by subscriber',
        'each motion decision uses prior actual callback state, never later same-clock state',
        'typed JSON/False numeric substitutions, exact .5sec and +1ns, plain/gzip detached replay and changed-input rejection',
        'first captured selection/send clock may precede later delivery clock by20ms',
        'actual production nonidentity odom/TF+translation/covariance 27rows/2cycles replay independently',
        '6000 raw TF records with5999 ignored pending duplicates preserve old semantics (partial stress scope)'],
    'limitations': [
        'No ROS initialization, native simulation, PPO/GPU or external process control was performed.',
        'V8 raw replay uses motion-subscriber values and is not proof of original information-producer callback order.',
        'Producer provenance replay does not prove middleware completeness or eliminate all same-clock races.',
        'Full native/safety/physical/angular/settled/contact/phase/activity/closure gates remain independently required.'],
    'originals': [binding(path) for path in logs]
}
OUT.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + '\n')
print(json.dumps({'output': str(OUT), 'sha256': binding(OUT)['sha256'], 'passed': True}))
