import hashlib
import json
import subprocess
from pathlib import Path

ROOT=Path(__file__).parent
REPO=Path('/home/zhuyulab/ns3-workspace')
FREEZE='72d0465ddd1bbee09af117cfd9d89b7e729f8578'
FILES={
 'top_launch':('ros2_ws/ros2-multi-robot-automap/src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py',[(900,1004)]),
 'slam_launch':('ros2_ws/ros2-multi-robot-automap/src/slam_toolbox/launch/online_async_multirobot_launch.py',[(11,51)]),
 'slam_callback':('ros2_ws/ros2-multi-robot-automap/src/slam_toolbox/src/slam_toolbox_multirobot.cpp',[(7,50)]),
 'slam_common':('ros2_ws/ros2-multi-robot-automap/src/slam_toolbox/src/slam_toolbox_common.cpp',[(200,214),(255,263),(536,581),(594,649)]),
 'slam_parameters':('ros2_ws/ros2-multi-robot-automap/src/slam_toolbox/config/mapper_params_online_multi_async.yaml',[(13,45)]),
}


def sha(raw):return hashlib.sha256(raw).hexdigest()


def ref(path):
 raw=path.read_bytes();return {'path':str(path),'bytes':len(raw),'sha256':sha(raw)}


def main():
 sources=[]
 for label,(relative,ranges) in FILES.items():
  path=REPO/relative;raw=path.read_bytes()
  argv=['/usr/bin/git','show',FREEZE+':'+relative]
  result=subprocess.run(argv,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
  assert result.returncode==0 and result.stdout==raw
  lines=raw.decode().splitlines()
  snippets=[{'start_line':a,'end_line':b,'text':'\n'.join(f'{i+1}: {lines[i]}' for i in range(a-1,min(b,len(lines))))} for a,b in ranges]
  sources.append({'label':label,'source':ref(path),'freeze_git_show_argv':argv,
                  'freeze_git_show_exit':result.returncode,'freeze_blob_sha256':sha(result.stdout),
                  'current_equals_freeze_blob':True,'snippets':snippets})
 logs=[]
 for stage in ('baseline','iters150'):
  formal=json.loads(Path('/tmp/mr3_p2a0_v19_'+stage+'_observer_review.json').read_bytes())
  path=Path(formal['episode_directory'])/'launch.log';raw=path.read_bytes()
  inventory=json.loads((Path('/tmp/mr3_p2a0_v19_selected_native_v1')/stage/'manifest.json').read_bytes())
  proof=next(row for row in inventory['files'] if row['source']==str(path))
  assert sha(raw)==proof['raw_sha256']
  selected=[]
  for index,line in enumerate(raw.splitlines(keepends=True)):
   text=line.decode()
   if 'slam_toolbox' in text and any(key in text for key in ['process started','Registering sensor','Message Filter dropping','maximum laser range']):
    selected.append({'line_number':index+1,'raw_bytes':len(line),'raw_sha256':sha(line),'text':text})
  logs.append({'stage':stage,'source':ref(path),'original_custody_sha256':proof['raw_sha256'],'lines':selected})
 result={'schema':'mr3-v19-startup-slam-source-review-v1','freeze':FREEZE,
         'passed':True,'pass_scope':'Read-only source/log identity and bounded interpretation; no new formal/physical or actual scan ingestion credit.',
         'sources':sources,'actual_launch_logs':logs,
         'findings':[
          {'claim':'SLAM startup is not gated by robot height/roll/pitch or a physical settle condition.','evidence':'top_launch: robot_actions groups robot_state_publisher, spawn_robot, slam_toolbox_node; first group immediately appended, later groups triggered by prior spawn exit, not own settled state.'},
          {'claim':'The active node can submit scans to Karto once odom pose and laser metadata are available.','evidence':'MultiRobotSlamToolbox::laserCallback lines30-43: getOdomPose, getLaser, addScan; common addScan lines600-612 constructs range scan and calls Mapper::Process. No explicit physics-settled predicate on this route.'},
          {'claim':'Minimum_time_interval=.5 is configured but is not a startup-settle guard on the active derived laser callback.','evidence':'shouldProcessScan exists in common536-581, gives first measurement a pass; active derived callback does not call it and directly calls addScan. Karto may independently decline scan insertion.'},
          {'claim':'Both real logs show all three SLAM processes/sensor registrations during startup; tb3 first frame is explicitly reported earlier than TF cache.','evidence':'Actual selected launch.log lines, preserving wall log timestamp and reported simulation scan timestamp. No assumption every startup scan was accepted.'}],
         'limitations':['No raw LaserScan message or per-scan Karto acceptance archive is available in this selection; source readiness does not prove a particular early ray entered the map.',
                        'This review does not infer occupied-cell root cause, retune scan/SLAM, or weaken candidate/task gates.']}
 output=ROOT/'slam_startup_source_review_v1.json';output.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'review':ref(output),'source_count':len(sources),'log_count':len(logs)}))


if __name__=='__main__':main()
