"""Pure custody counterexamples only; never calls archive main/publish/native."""
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

SOURCE = Path('/tmp/mr3_p2a0_v15_archive_offline_originals_v1.py')
SPEC = importlib.util.spec_from_file_location('offline_helper_v15', SOURCE)
H = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(H)


class CustodyTests(unittest.TestCase):
    def test_explicit_identity_gzip_and_unlabelled_identity_do_not_decode_inner_bytes(self):
        encoded = gzip.compress(b'inner source', mtime=0)
        for row in (dict(raw_sha256=H.sha(encoded), encoding='identity'),
                    dict(raw_sha256=H.sha(encoded))):
            codec, raw = H.decoded_original(row, encoded)
            self.assertEqual(codec, 'identity')
            self.assertEqual(raw, encoded)
        row = dict(raw_sha256=H.sha(b'inner source'), encoding='gzip')
        self.assertEqual(H.decoded_original(row, encoded), ('gzip', b'inner source'))

    def test_unknown_conflicting_codecs_and_false_raw_sha_rejected(self):
        encoded = gzip.compress(b'actual source', mtime=0)
        for changes in (dict(encoding='unknown'), dict(encoding='identity', compression='gzip'),
                        dict(encoding='identity', raw_sha256=H.sha(b'wrong'))):
            row = dict(raw_sha256=H.sha(encoded))
            row.update(changes)
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                H.decoded_original(row, encoded)

    def test_capture_regular_file_stable_and_symlink_rejected(self):
        with tempfile.TemporaryDirectory(prefix='mr3_v15_custody_test_') as temporary:
            path = Path(temporary) / 'source'
            path.write_bytes(b'actual source')
            raw, stat = H.capture(path)
            self.assertEqual(raw, b'actual source')
            self.assertEqual(stat['size'], len(raw))
            link = path.with_name('symlink')
            link.symlink_to(path)
            with self.assertRaises(ValueError):
                H.capture(link)

    def test_real_inplace_write_during_open_descriptor_capture_is_rejected(self):
        with tempfile.TemporaryDirectory(prefix='mr3_v15_custody_mutation_') as temporary:
            path = Path(temporary) / 'source'
            path.write_bytes(b'old')
            original = H.os.fstat
            calls = []

            def mutate(descriptor):
                result = original(descriptor)
                calls.append(descriptor)
                if len(calls) == 1:
                    path.write_bytes(b'real changed input with a different size')
                return result

            with patch.object(H.os, 'fstat', mutate), self.assertRaises(ValueError):
                H.capture(path)

    def test_both_old_roots_identity_manifest_and_corrupted_selected_bytes(self):
        with tempfile.TemporaryDirectory(prefix='mr3_v15_old_roots_test_') as temporary:
            root = Path(temporary)
            roots = (root / 'a14', root / 'a13')
            for index, old in enumerate(roots):
                old.mkdir()
                raw = gzip.compress(('raw' + str(index)).encode(), mtime=0)
                selected = old / 'identity.gz'
                selected.write_bytes(raw)
                manifest = dict(files=[dict(source='/tmp/old' + str(index),
                                           selected='identity.gz', encoding='identity',
                                           raw_sha256=H.sha(raw), encoded_sha256=H.sha(raw))])
                (old / 'manifest.json').write_text(json.dumps(manifest))
            with patch.object(H, 'ROOT', root), patch.object(H, 'OLD_ROOTS', roots):
                originals, manifests = H.old_originals()
                self.assertEqual(len(originals), 2)
                self.assertEqual(len(manifests), 2)
                self.assertTrue(all(row['encoding'] == 'identity' for row in originals.values()))
                (roots[0] / 'identity.gz').write_bytes(b'corrupted exact selected bytes')
                with self.assertRaisesRegex(ValueError, 'encoded SHA mismatch'):
                    H.old_originals()

    def test_discovery_retains_fail_logs_and_explicit_extra_root_originals(self):
        with tempfile.TemporaryDirectory(prefix='mr3_v15_sources_test_') as temporary:
            root = Path(temporary)
            folder = root / 'mr3_p2a0_v15_test'
            folder.mkdir()
            failure = folder / 'real_CPU_FAIL.log'
            failure.write_bytes(b'FAILED (failures=1)')
            mock = folder / 'mock_worktree'
            mock.mkdir()
            (mock / 'generated_native_leaf.json').write_text('{}')
            extra = root / 'root_mr3_v14_closeout.json'
            extra.write_bytes(b'original root closeout failure')
            index = root / 'mr3_p2a0_v15_additional_closeout_originals_v1.json'
            index.write_text(json.dumps(dict(entries=[dict(
                source=str(extra), sha256=H.sha(extra.read_bytes()), bytes=extra.stat().st_size)])))
            with patch.object(H, 'TEMP', root), patch.object(H, 'ADDITIONAL_INDEX', index):
                found, omitted = H.source_paths()
                self.assertIn(failure, found)
                self.assertIn(extra, found)
                self.assertTrue(any('mock' in row['reason'] for row in omitted))
                extra.write_bytes(b'changed')
                with self.assertRaisesRegex(ValueError, 'indexed original changed'):
                    H.source_paths()

    def test_mutable_outputs_and_exclusive_json_are_not_overwritten(self):
        with tempfile.TemporaryDirectory(prefix='mr3_v15_output_test_') as temporary:
            root = Path(temporary)
            active = root / 'mr3_p2a0_v15_root_continuation_state_v1.json'
            console = root / 'mr3_p2a0_v15_active_archive_stdout.log'
            with patch.object(H, 'TEMP', root), patch.object(H, 'OWN_OUTPUTS', {console}):
                self.assertIsNotNone(H.excluded(active))
                self.assertIn('stdout', H.excluded(console))
            path = root / 'original.json'
            H.new_json(path, {'actual': True})
            original_sha = hashlib.sha256(path.read_bytes()).hexdigest()
            with self.assertRaises(FileExistsError):
                H.new_json(path, {'replacement': True})
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), original_sha)


if __name__ == '__main__':
    unittest.main(verbosity=2)
