"""V13 closeout only. Default review reads metadata/Git, never active large traces.

--publish is reserved for root GO after all native/formal/observer writers finish.
It verifies and copies existing selected packs; it never runs packers or auditors.
"""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

ROOT = Path('/home/zhuyulab/ns3-workspace')
FREEZE = None
A = ROOT / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
            'report/assets/20261017_mr3_p2a0_v13')
TEMP = Path('/tmp')
PREFIX = 'mr3_p2a0_v13'
STAGES = ('interface', 'terminal', 'reset', 'deadline')
PLAN_SHA = None


def sha(data):
    return hashlib.sha256(data).hexdigest()


def stable(path):
    before = path.stat()
    data = path.read_bytes()
    after = path.stat()
    if (before.st_ino, before.st_size, before.st_mtime_ns) != (
            after.st_ino, after.st_size, after.st_mtime_ns):
        raise ValueError('input changed while read: ' + str(path))
    return data


def read(path):
    return json.loads(stable(path))


def new_json(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def git_bytes(path):
    return subprocess.check_output(['git', 'show', FREEZE + ':' + path], cwd=ROOT)


def bind_preflight(preflight, plan_raw, git_plan_raw):
    """Bind real post-push metadata; never inherit a historical freeze or digest."""
    freeze = preflight.get('freeze')
    assert preflight.get('passed') is True
    assert isinstance(freeze, str) and re.fullmatch('[0-9a-f]{40}', freeze)
    assert preflight.get('plan_sha256') == sha(plan_raw) and plan_raw == git_plan_raw
    plan = json.loads(plan_raw)
    assert plan['schema'] == 'mr3-p2a0-predeclaration-v13'
    assert plan['readiness']['status'] == 'ready' and not plan['readiness']['pending_bindings']
    assert tuple(row['stage'] for row in plan['stages']) == STAGES
    assert preflight['independent_source_bindings'] == plan['independent_source_bindings']
    return freeze, sha(plan_raw), plan


def load_context():
    global FREEZE, PLAN_SHA
    preflight = read(TEMP / (PREFIX + '_source_preflight.json'))
    freeze = preflight.get('freeze')
    assert isinstance(freeze, str) and re.fullmatch('[0-9a-f]{40}', freeze)
    plan_path = A / 'predeclared_plan_v13.json'
    frozen_plan = subprocess.check_output(
        ['git', 'show', freeze + ':' + str(plan_path.relative_to(ROOT))], cwd=ROOT)
    FREEZE, PLAN_SHA, plan = bind_preflight(preflight, stable(plan_path), frozen_plan)
    return plan


def safe_relative(path):
    relative = Path(path)
    if relative.is_absolute() or '..' in relative.parts:
        raise ValueError('unsafe archive path: ' + str(path))
    return relative


def frozen_sources(plan):
    """Read only exact old Git, source pack, and prefreeze originals."""
    archive = subprocess.check_output(
        ['git', 'archive', '--format=tar', FREEZE, '--', str(A.relative_to(ROOT))],
        cwd=ROOT)
    frozen = []
    with tarfile.open(fileobj=io.BytesIO(archive), mode='r:') as stream:
        for member in stream:
            if member.isfile():
                data = stream.extractfile(member).read()
                assert stable(ROOT / member.name) == data, member.name
                frozen.append(dict(path=member.name, bytes=len(data), sha256=sha(data)))
    inventory = read(A / 'inventory_prefreeze_v1.json')
    for row in inventory['files']:
        data = stable(A / safe_relative(row['path']))
        assert len(data) == row['bytes'] and sha(data) == row['sha256'], row['path']
        if 'decoded_sha256' in row:
            decoded = gzip.decompress(data)
            assert len(decoded) == row['decoded_bytes'] and sha(decoded) == row['decoded_sha256']
    preflight_path = TEMP / (PREFIX + '_source_preflight.json')
    preflight = read(preflight_path)
    proof_path = TEMP / ('source_bindings_' + FREEZE[:12] + '.json')
    source_archive = proof_path.with_suffix('.tar.gz')
    proof = read(proof_path)
    encoded = stable(source_archive)
    decoded = gzip.decompress(encoded)
    assert preflight['passed'] is True and preflight['freeze'] == proof['freeze'] == FREEZE
    assert preflight['plan_sha256'] == PLAN_SHA
    assert sha(encoded) == proof['encoded_sha256'] and sha(decoded) == proof['tar_sha256']
    assert proof['preflight_sha256'] == sha(stable(preflight_path))
    paths = preflight['source_bindings']
    template = read(A / 'independent/source_bindings_template_v1.json')
    expected_paths = {row['path'] for row in template['runtime_paths']}
    assert set(paths) == expected_paths
    assert len(paths) == len(proof['files']) == len(expected_paths)
    assert {row['path'] for row in proof['files']} == expected_paths
    with tarfile.open(fileobj=io.BytesIO(decoded), mode='r:') as stream:
        members = {member.name: member for member in stream if member.isfile()}
        assert set(members) == set(paths)
        for path, binding in paths.items():
            data = stream.extractfile(members[path]).read()
            assert data == git_bytes(path) and sha(data) == binding['sha256'], path
    independent = preflight['independent_source_bindings']
    assert independent == plan['independent_source_bindings']
    for binding in independent:
        assert sha(git_bytes(binding['path'])) == binding['sha256'], binding['path']
    binary_proof_path = Path(preflight['binary_proof'])
    binary_proof = read(binary_proof_path)
    assert sha(stable(binary_proof_path)) == preflight['binary_proof_sha256']
    assert binary_proof['freeze'] == FREEZE
    build = plan['drive_contract']['binary_build_receipt']
    build_receipt = read(ROOT / safe_relative(build['path']))
    assert sha(git_bytes(build['path'])) == build['sha256']
    for key, relative in {
            'compiled_source_sha256': 'src/mr3_gazebo_diff_drive.cpp',
            'compiled_header_sha256': 'include/multi_robot/mr3_gazebo_diff_drive.hpp',
            'compiled_helper_sha256': 'include/multi_robot/paired_wheel_slew.hpp',
            'compiled_target_contract_sha256': 'include/multi_robot/mr3_drive_target.hpp'}.items():
        path = 'ros2_ws/ros2-multi-robot-automap/src/multi_robot/' + relative
        assert binary_proof[key] == build_receipt[key] == sha(git_bytes(path))
    encoded_binary = stable(ROOT / safe_relative(build_receipt['archived_library_gzip']))
    actual_binary = stable(Path(build_receipt['library_path']))
    assert sha(encoded_binary) == build_receipt['archived_library_encoded_sha256']
    assert gzip.decompress(encoded_binary) == actual_binary
    assert sha(actual_binary) == build_receipt['library_sha256'] == binary_proof['library_sha256']
    assert Path(build_receipt['installed_path']).resolve() == Path(
        build_receipt['library_path']).resolve()
    return dict(frozen_canonical_originals_unchanged=frozen,
                prefreeze_inventory_entries_unchanged=len(inventory['files']),
                sourcepack_files=len(paths), independent_source_bindings=len(independent),
                frozen_binary_build_receipt_sha256=build['sha256'],
                four_compiled_sources_and_current_archived_binary_match=True,
                actual_binary_sha256=sha(actual_binary),
                source_archive_encoded_sha256=sha(encoded),
                source_archive_tar_sha256=sha(decoded)), (proof_path, source_archive)


def validate_final_states(plan, mode, stop_stage, loader=read, exists=Path.exists):
    """No missing future stage is silently relabelled SKIPPED during a live matrix."""
    if mode not in ('complete', 'stopped'):
        raise ValueError('publish mode must be complete or stopped')
    if (mode == 'complete' and stop_stage is not None) or (
            mode == 'stopped' and stop_stage not in STAGES):
        raise ValueError('stopped needs exact failed --stop-stage; complete forbids it')
    final_index = 3 if mode == 'complete' else STAGES.index(stop_stage)
    outcomes = []
    for index, spec in enumerate(plan['stages']):
        stage = spec['stage']
        assert stage == STAGES[index]
        launch_path = TEMP / (PREFIX + '_' + stage + '_launch.json')
        execution_path = TEMP / (PREFIX + '_' + stage + '_audit_execution_v1.json')
        if index > final_index:
            assert not exists(launch_path) and not exists(execution_path), stage
            assert not exists(Path(spec['run_directory'])), stage
            assert not exists(TEMP / (PREFIX + '_selected_native') / stage), stage
            outcomes.append(dict(stage=stage, status='SKIPPED_after_' + stop_stage + '_failure'))
            continue
        launch, execution = loader(launch_path), loader(execution_path)
        assert launch['status'] in ('completed', 'failed'), stage
        assert launch['freeze'] == execution['freeze'] == FREEZE, stage
        assert launch['plan_sha256'] == execution['plan_sha256'] == PLAN_SHA, stage
        assert execution['all_submitted_jobs_finished'] is True, stage
        assert type(launch.get('passed')) is bool and type(execution.get('passed')) is bool
        assert {r['path'] for r in execution['receipts']} == set(spec['required_audit_receipts'])
        successful = (launch['status'] == 'completed' and launch['passed'] is True
                      and execution['passed'] is True)
        if mode == 'complete' or index < final_index:
            assert successful, stage
        else:
            assert not successful, 'stopped mode requires actual failed final stage'
        outcomes.append(dict(stage=stage, status='PASS' if successful else 'FAIL',
                             launch=launch, execution=execution,
                             run_directory=spec['run_directory']))
    return outcomes


def closed_identities(outcomes):
    """Absence is distinct from every formal closure/exit-status verdict."""
    saved = {}

    def collect(value):
        if isinstance(value, dict):
            if type(value.get('pid')) is int and type(value.get('start_ticks')) is int:
                assert value['pid'] > 0 and value['start_ticks'] > 0
                saved[(value['pid'], value['start_ticks'])] = value
            for item in value.values():
                collect(item)
        elif isinstance(value, list):
            for item in value:
                collect(item)

    for outcome in outcomes:
        if 'launch' not in outcome:
            continue
        collect(outcome['launch'])
        summary_path = Path(outcome['run_directory']) / 'benchmark_summary.json'
        if summary_path.exists():
            collect(read(summary_path))
        for pattern in ('worker*/episode*/supervisor_metadata.json',
                        'worker*/episode*/supervisor_shutdown.json'):
            for path in Path(outcome['run_directory']).glob(pattern):
                collect(read(path))
    provenance = []
    for suffix in ('remaining_matrix_v1.jsonl', 'cross_stage_mapping_start_v1.json',
                   'cross_stage_mapping_summary_v1.json'):
        path = TEMP / (PREFIX + '_' + suffix)
        if path.exists():
            raw = stable(path)
            collect([json.loads(line) for line in raw.splitlines() if line.strip()]
                    if path.suffix == '.jsonl' else json.loads(raw))
            provenance.append(dict(path=str(path), sha256=sha(raw)))
    current = [dict(saved_identity=row, current=pid_identity(row)) for row in saved.values()]
    alive = [row for row in current if row['current'] and row['current']['same_saved_identity']]
    assert not alive, 'saved owned native identity still present'
    return dict(saved_identities=len(saved), fixed_expected_count=None,
                all_saved_identities_absent=True, fresh_checks=current,
                controller_and_observer_provenance=provenance,
                scope='Fresh PID/start absence only, not a substitute for any failed native '
                      'closure, parameter, task or formal verdict.')


def verify_formals(outcome):
    execution = outcome['execution']
    for receipt in execution['receipts']:
        path = Path(receipt['path'])
        if path.exists():
            data = stable(path)
            assert sha(data) == receipt['sha256'], path
            assert read(path).get('passed') is receipt['passed'], path
        else:
            assert receipt.get('passed') is False and receipt.get('sha256') is None, path
    for command in execution['commands']:
        if command.get('output_exists'):
            assert sha(stable(Path(command['output']))) == command['output_sha256']
        if command.get('console_sha256') is not None:
            assert sha(stable(Path(command['console']))) == command['console_sha256']
    if outcome['status'] == 'PASS':
        assert not execution['runner_errors']
        assert all(r['passed'] is True for r in execution['receipts'])
        assert all(c.get('passed') is True for c in execution['commands']
                   if c.get('required_success') is True)


def verify_pack(stage, source_directory):
    directory = TEMP / (PREFIX + '_selected_native') / stage
    manifest = read(directory / 'manifest.json')
    assert manifest['schema'] == 'mr3-p2a-selected-originals-v1'
    assert manifest['freeze'] == FREEZE and manifest['stage'] == stage
    assert manifest['source'] == source_directory
    actual_files = set()
    original_files = set()
    raw_total = encoded_total = 0
    for row in manifest['files']:
        relative = safe_relative(row['selected'])
        assert relative not in actual_files
        actual_files.add(relative)
        data = stable(directory / relative)
        assert row['encoding'] in ('identity', 'gzip')
        raw = gzip.decompress(data) if row['encoding'] == 'gzip' else data
        assert len(data) == row['selected_bytes'] and sha(data) == row['selected_sha256']
        assert len(raw) == row['raw_bytes'] and sha(raw) == row['raw_sha256']
        src = Path(row['source'])
        original_relative = src.relative_to(source_directory)
        assert original_relative not in original_files
        original_files.add(original_relative)
        assert stable(src) == raw, src
        raw_total += len(raw)
        encoded_total += len(data)
    selected_files = {p.relative_to(directory) for p in directory.rglob('*') if p.is_file()}
    assert selected_files == actual_files | {Path('manifest.json')}
    assert len(actual_files) == manifest['source_files']
    assert raw_total == manifest['raw_bytes'] and encoded_total == manifest['selected_bytes']
    duplicate_paths = set()
    source_root = Path(source_directory)
    for name in manifest['duplicate_encoded_copies_not_selected']:
        relative = safe_relative(name)
        assert relative.suffix == '.gz' and relative.with_suffix('') in original_files
        assert gzip.decompress(stable(source_root / relative)) == stable(
            source_root / relative.with_suffix(''))
        duplicate_paths.add(relative)
    caches = {safe_relative(name) for name in manifest['excluded_python_cache']}
    assert all(path.suffix == '.pyc' or '__pycache__' in path.parts for path in caches)
    current_originals = {path.relative_to(source_root) for path in source_root.rglob('*')
                         if path.is_file()}
    assert current_originals == original_files | duplicate_paths | caches
    return directory, manifest


def support_paths(extras):
    included, excluded = set(extras) | {Path(__file__)}, []
    for top in sorted(TEMP.glob(PREFIX + '*')):
        if top.name in (PREFIX + '_closed_archive_publish_v1.log',
                        PREFIX + '_closed_archive_publish_v1.json'):
            excluded.append(dict(path=str(top), reason='self_active_archive_execution_output'))
            continue
        if top.name in (PREFIX + '_selected_native', PREFIX + '_active_state.json'):
            excluded.append(dict(path=str(top), reason='selected_pack_separately' if top.is_dir()
                                 else 'mutable_launcher_active_state'))
            continue
        for path in sorted(top.rglob('*')) if top.is_dir() else [top]:
            if path.is_dir():
                continue
            reason = None
            if path.is_symlink():
                reason = 'symlink_not_original_regular_file'
            elif '__pycache__' in path.parts or path.suffix == '.pyc':
                reason = 'python_cache'
            elif path.suffix == '.lock':
                reason = 'observer_or_launcher_lock'
            elif not path.is_file():
                reason = 'nonregular'
            elif is_elf(path):
                reason = 'CPU_executable_not_source_or_native_raw_evidence'
            if reason:
                excluded.append(dict(path=str(path), reason=reason))
            else:
                included.add(path)
    return sorted(included), excluded


def is_elf(path):
    with path.open('rb') as stream:
        return stream.read(4) == b'\x7fELF'


def prior_original_index():
    """Use explicit frozen original mappings, never name-only deduplication."""
    index = {}
    for path in sorted((A / 'independent').glob('*_offline/manifest.json')):
        manifest = read(path)
        for row in manifest.get('entries', manifest.get('files', [])):
            if not isinstance(row.get('source'), str) or not row.get('raw_sha256'):
                continue
            selected = safe_relative(row['selected'])
            selected = ROOT / selected if (ROOT / selected).is_file() else path.parent / selected
            index.setdefault(row['source'], []).append(dict(
                selected=selected, raw_sha256=row['raw_sha256'], manifest=path))
    return index


def canonical_duplicate(source, raw, index):
    for entry in index.get(str(source), []):
        if entry['raw_sha256'] != sha(raw):
            continue
        encoded = stable(entry['selected'])
        assert gzip.decompress(encoded) == raw
        return dict(path=str(source), reason='identical_original_already_canonical',
                    raw_sha256=sha(raw), canonical_path=str(entry['selected'].relative_to(ROOT)),
                    canonical_encoded_sha256=sha(encoded),
                    original_mapping_manifest=str(entry['manifest'].relative_to(ROOT)))
    return None


def pid_identity(identity):
    if not isinstance(identity, dict) or not identity.get('pid'):
        return None
    try:
        raw = Path('/proc/' + str(identity['pid']) + '/stat').read_text()
        parts = raw[raw.rfind(')') + 2:].split()
        return dict(pid=identity['pid'], start_ticks=int(parts[19]), state=parts[0],
                    same_saved_identity=int(parts[19]) == identity['start_ticks'])
    except (FileNotFoundError, ProcessLookupError):
        return None


def accounting(outcomes, plan):
    stages = []
    for outcome in outcomes:
        if outcome['status'].startswith('SKIPPED'):
            stages.append(outcome)
            continue
        run = Path(outcome['run_directory'])
        summary = read(run / 'benchmark_summary.json')
        metadata = read(run / 'benchmark_metadata.json')
        assert summary['freeze'] == metadata['freeze'] == FREEZE
        episodes = []
        for ep in sorted(run.glob('worker*/episode*')):
            if not ep.is_dir():
                continue
            rows = [json.loads(line) for line in stable(ep / 'transitions.jsonl').splitlines()
                    if line.strip()] if (ep / 'transitions.jsonl').exists() else []
            assert all(row['kind'] in ('reset', 'step') for row in rows)
            shutdown_path = ep / 'supervisor_shutdown.json'
            shutdown = read(shutdown_path) if shutdown_path.exists() else None
            steps = [row for row in rows if row['kind'] == 'step']
            alive = [p for p in (pid_identity(i) for i in (
                shutdown.get('owned_processes_seen', []) if shutdown else []))
                if p and p['same_saved_identity']]
            episodes.append(dict(directory=str(ep), saved_transition_records=len(rows),
                                 returned_resets=sum(r['kind'] == 'reset' for r in rows),
                                 returned_steps=len(steps),
                                 step_dt=[r['info'].get('dt') for r in steps],
                                 physical_dt=[r['info'].get('physical_dt') for r in steps],
                                 dt_field_missing_steps=sum('dt' not in r['info'] for r in steps),
                                 physical_dt_field_missing_steps=sum(
                                     'physical_dt' not in r['info'] for r in steps),
                                 dt_field_source='transitions.jsonl step.info.dt',
                                 physical_dt_field_source='transitions.jsonl step.info.physical_dt',
                                 strict_supervisor_shutdown=shutdown,
                                 current_saved_owned_identities=alive))
        launch = outcome['launch']
        stages.append(dict(stage=outcome['stage'], status=outcome['status'],
                           launcher_benchmark_only_passed=launch['passed'],
                           formal_stage_passed=outcome['execution']['passed'],
                           launcher_wall_seconds=launch['wall_duration_sec'],
                           sampler_wall_seconds=summary['wall_sec_including_all_attempts'],
                           sampler_valid_transitions=summary.get('valid_transitions'),
                           episodes=episodes,
                           formal_commands=[{k: command.get(k) for k in (
                               'label', 'returncode', 'passed', 'output_exists', 'required_success',
                               'wall_seconds', 'error')}
                               for command in outcome['execution']['commands']],
                           launcher_identity_after=pid_identity(launch.get('launcher_identity')),
                           benchmark_parent_identity_after=pid_identity(
                               launch.get('benchmark_parent'))))
    resets = sum(ep['returned_resets'] for stage in stages for ep in stage.get('episodes', []))
    steps = sum(ep['returned_steps'] for stage in stages for ep in stage.get('episodes', []))
    wall = sum(stage.get('launcher_wall_seconds', 0) for stage in stages)
    return dict(schema='mr3-v13-closed-engineering-cost-v1', freeze=FREEZE, stages=stages,
                total_returned_resets=resets, total_returned_steps=steps,
                total_saved_api_records=resets + steps,
                native_launcher_wall_seconds=wall,
                declared_ceiling_checks=dict(
                    saved_worker_api_records_le_declared=resets + steps <= plan['max_api_records'],
                    saved_worker_step_records_le_declared=(
                        steps <= plan['max_submitted_script_decisions']),
                    native_wall_le_declared=wall <= plan['max_total_wall_seconds']),
                gpu_calls=0, optimizer_updates=0, learning_training_samples=0,
                pilot_budget_unchanged=plan['pilot_budget_unchanged'],
                scope='Engineering API records and actual native launcher wall only. Sampler wall '
                      'is reported separately, never summed with launcher wall. Formal read-only '
                      'audit wall is not native/pilot cost. No task95%, PPO or acceptance claim.')


def publish(plan, mode, stop_stage, source_check, sourcepack):
    outcomes = validate_final_states(plan, mode, stop_stage)
    identities = closed_identities(outcomes)
    for outcome in outcomes:
        if 'execution' in outcome:
            verify_formals(outcome)
    packs = [(outcome['stage'],) + verify_pack(outcome['stage'], outcome['run_directory'])
             for outcome in outcomes if 'execution' in outcome]
    account = accounting(outcomes, plan)
    originals, excluded = support_paths(sourcepack)
    # Capture original bytes now; all writers must already be finished by explicit root GO.
    captured = []
    prior = prior_original_index()
    for path in originals:
        raw = stable(path)
        duplicate = canonical_duplicate(path, raw, prior)
        if duplicate:
            excluded.append(duplicate)
        else:
            captured.append((path, raw))
    targets = [A / 'native', A / 'accounting', A / 'independent/native_originals_v1',
               A / 'independent/native_archive_verification_v1.json',
               A / 'inventory_native_v1.json']
    for target in targets:
        assert not target.exists(), 'refuse overwrite: ' + str(target)
    for source in sourcepack:
        assert not (A / 'independent' / source.name).exists()
    for stage, directory, manifest in packs:
        target = A / 'native' / stage
        target.parent.mkdir(exist_ok=True)
        shutil.copytree(directory, target)
        for row in manifest['files']:
            assert stable(target / row['selected']) == stable(directory / row['selected'])
        assert stable(target / 'manifest.json') == stable(directory / 'manifest.json')
    for source in sourcepack:
        with (A / 'independent' / source.name).open('xb') as stream:
            stream.write(stable(source))
    destination = A / 'independent/native_originals_v1'
    destination.mkdir()
    entries = []
    for source, raw in captured:
        relative = source.relative_to(TEMP)
        target = destination / (str(relative) + '.gz')
        target.parent.mkdir(parents=True, exist_ok=True)
        encoded = gzip.compress(raw, mtime=0)
        with target.open('xb') as stream:
            stream.write(encoded)
        actual = stable(target)
        decoded = gzip.decompress(actual)
        assert decoded == raw and stable(source) == raw
        entries.append(dict(source=str(source), selected_path=str(target.relative_to(ROOT)),
                            raw_bytes=len(raw), raw_sha256=sha(raw), selected_bytes=len(actual),
                            selected_encoded_sha256=sha(actual),
                            selected_decoded_sha256=sha(decoded),
                            decoded_equals_raw=True))
    support = dict(schema='mr3-v13-closed-support-originals-v1', freeze=FREEZE,
                   count=len(entries), entries=entries, exclusions=excluded,
                   scope='All V13-prefix regular support originals including observer errors and '
                         'corrections; selected raw runs separate; source_bindings '
                         'different-prefix; already-canonical identical raw originals deduplicated '
                         'JSON and tar.gz also preserved. Existing FAIL bytes are never rewritten.')
    new_json(destination / 'manifest.json', support)
    (A / 'accounting').mkdir()
    new_json(A / 'accounting/native_cost_v1.json', account)
    verification = dict(schema='mr3-v13-native-archive-verification-v1', passed=True,
                        freeze=FREEZE, matrix_mode=mode,
                        matrix_all_formal_stages_passed=mode == 'complete',
                        original_gate_statuses=[dict(stage=o['stage'], status=o['status'])
                                               for o in outcomes],
                        saved_identity_absence=identities,
                        **source_check,
                        native_selected_files=sum(len(m['files']) for _, _, m in packs),
                        native_raw_bytes=sum(m['raw_bytes'] for _, _, m in packs),
                        native_selected_bytes=sum(m['selected_bytes'] for _, _, m in packs),
                        native_manifests=[dict(stage=s, sha256=sha(stable(d / 'manifest.json')))
                                          for s, d, _ in packs],
                        support_originals=len(entries), support_manifest_sha256=sha(
                            stable(destination / 'manifest.json')),
                        scope='Lossless byte/Git/source/archive verification only; formal outcomes '
                              'are preserved separately. No pilot spending or task/learning '
                              'credit.')
    output = A / 'independent/native_archive_verification_v1.json'
    new_json(output, verification)
    inventory = A / 'inventory_native_v1.json'
    rows, caches = [], []
    for path in sorted(A.rglob('*')):
        if not path.is_file() or path == inventory:
            continue
        if path.suffix == '.pyc' or '__pycache__' in path.parts:
            caches.append(str(path.relative_to(A)))
            continue
        data = stable(path)
        rows.append(dict(path=str(path.relative_to(A)), bytes=len(data), sha256=sha(data)))
    new_json(inventory, dict(schema='mr3-inventory-native-v1', freeze=FREEZE, self_excluded=True,
                             exclude_python_cache=True, excluded_python_cache=caches, files=rows))
    for row in rows:
        raw = stable(A / row['path'])
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    # A later producer source repair cannot change this old-freeze comparison.
    frozen_sources(plan)
    result = dict(passed=True, freeze=FREEZE, matrix_mode=mode,
                  inventory_count=len(rows), inventory_sha256=sha(stable(inventory)),
                  archive_verification_sha256=sha(stable(output)), support_originals=len(entries),
                  native_selected_files=verification['native_selected_files'],
                  native_raw_bytes=verification['native_raw_bytes'],
                  native_selected_bytes=verification['native_selected_bytes'],
                  total_returned_resets=account['total_returned_resets'],
                  total_returned_steps=account['total_returned_steps'],
                  native_launcher_wall_seconds=account['native_launcher_wall_seconds'])
    new_json(TEMP / (PREFIX + '_closed_archive_receipt_v1.json'), result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--publish', action='store_true')
    parser.add_argument('--mode', choices=('complete', 'stopped'))
    parser.add_argument('--stop-stage', choices=STAGES)
    parser.add_argument('--review-output', type=Path)
    args = parser.parse_args()
    plan = load_context()
    source_check, sourcepack = frozen_sources(plan)
    if args.publish:
        assert not args.review_output
        result = publish(plan, args.mode, args.stop_stage, source_check, sourcepack)
    else:
        assert args.review_output and not args.mode and not args.stop_stage
        paths, exclusions = support_paths(sourcepack)
        states = {}
        for stage in STAGES:
            path = TEMP / (PREFIX + '_' + stage + '_launch.json')
            states[stage] = read(path).get('status') if path.exists() else 'not_started'
        result = dict(schema='mr3-v13-archive-helper-preflight-review-v1',
                      freeze=FREEZE, source_sha256=sha(stable(Path(__file__))),
                      source_validation=source_check,
                      current_small_stage_states=states,
                      prospective_support_files=len(paths), exclusions=exclusions,
                      native_packs_not_reopened=True, active_trace_payloads_not_read=True,
                      canonical_written=False, publish_executed=False,
                      scope='Preparation only, not completed archive or native/matrix PASS.')
        new_json(args.review_output, result)
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == '__main__':
    main()
