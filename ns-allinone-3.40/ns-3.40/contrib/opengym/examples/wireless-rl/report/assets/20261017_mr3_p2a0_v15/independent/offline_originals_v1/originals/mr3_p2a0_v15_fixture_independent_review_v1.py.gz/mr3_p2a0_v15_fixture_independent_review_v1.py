"""Read-only v4 received-snapshot fixture review, including two concrete gaps."""
import ast
import hashlib
import itertools
import json
import math
from pathlib import Path

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
S = Path('/tmp/mr3_p2a0_v15_fixture_independent_review_sources_v1')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    raw = (S / 'benchmark.py').read_bytes()
    tree = ast.parse(raw)
    selected = {'_probe_goal_order', 'probe_action', 'probe_action_v3', 'probe_action_v4',
                'record_probe_v4_submission'}
    namespace = {'math': math}
    exec(compile(ast.Module(body=[node for node in tree.body if isinstance(node, ast.FunctionDef)
                                 and node.name in selected], type_ignores=[]),
                 str(S / 'benchmark.py'), 'exec'), namespace)
    scaffold = {'itertools': itertools, 'NAMES': ('tb1', 'tb2', 'tb3')}
    scaffold_tree = ast.parse((S / 'test_stimulus_v4.py').read_bytes())
    exec(compile(ast.Module(body=[node for node in scaffold_tree.body if isinstance(node, ast.FunctionDef)
                                 and node.name in ('snapshot', 'result')], type_ignores=[]),
                 str(S / 'test_stimulus_v4.py'), 'exec'), scaffold)
    snapshot, result = scaffold['snapshot'], scaffold['result']
    choose, submit = namespace['probe_action_v4'], namespace['record_probe_v4_submission']
    findings = []
    diagnostics = {}
    snap = snapshot(10., speed=.1, path=.5, waiting=False)
    assert choose(snap, diagnostics) == 888
    assert not diagnostics['v4_stimulus']['rounds']['initial']['waits']
    submit(diagnostics, result(snap, 888))
    assert not diagnostics['v4_stimulus']['rounds']['initial']['waits']
    findings.append({'check': 'authoritative commitment WAIT mask', 'passed': True,
                     'chosen': 888, 'WAIT_latched_after_KEEP': False})

    diagnostics = {}
    snap = snapshot(10.)
    action = choose(snap, diagnostics)
    assert action == 999 and not diagnostics['v4_stimulus']['rounds']['initial']['waits']
    submit(diagnostics, result(snap, action))
    assert len(diagnostics['v4_stimulus']['rounds']['initial']['waits']) == 3
    findings.append({'check': 'WAIT state only after returned exact typed command', 'passed': True,
                     'WAIT_before_submission': False, 'WAIT_after_submission': True})

    diagnostics = {}
    snap = snapshot(10.)
    action = choose(snap, diagnostics)
    submit(diagnostics, result(snap, action, action_submitted=0))
    integer_alias_latched = bool(diagnostics['v4_stimulus']['rounds']['initial']['waits'])
    assert integer_alias_latched
    findings.append({'check': 'explicit action_submitted=0 typed counterexample',
                     'gap_confirmed': True, 'WAIT_latched': integer_alias_latched,
                     'scope': 'malformed optional flag; real current normal worker omits it. '
                              'Missing remains legitimate; explicit nonbool should fail.'})

    diagnostics = {}
    for elapsed in (10., 11., 12.):
        snap = snapshot(elapsed, speed=.02, path=.01, waiting=False)
        action = choose(snap, diagnostics)
        assert action == 888
        submit(diagnostics, result(snap, action))
    second = snapshot(13., active=False)
    for robot in second['robots']:
        robot['navigation']['accepted_goal_count'] = 1  # Preserve actual epoch-cumulative count.
    second_action = choose(second, diagnostics)
    assert second['joint_action_mask'][second_action]
    components = (second_action // 100, second_action // 10 % 10, second_action % 10)
    assert sum(choice < 8 for choice in components) == 3
    assert not diagnostics['v4_stimulus']['rounds']['initial']['waits']
    findings.append({'check': 'no initial successful WAIT record still allows second goals',
                     'gap_confirmed': True, 'second_action': second_action,
                     'GOAL_components': 3, 'initial_WAIT_records': 0,
                     'scope': 'contradicts the stronger declared minimum3s actual WAIT before '
                              'second goal; not a body/safety threshold counterexample.'})

    old_tree = ast.parse((W / 'mr3_learning/benchmark.py').read_bytes())
    old_functions = {n.name: n for n in old_tree.body if isinstance(n, ast.FunctionDef)}
    current_functions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
    preserved = []
    for name in ('_probe_goal_order', 'probe_action', 'probe_action_v3',
                 '_new_preparation_abort', '_preparation_failure', '_abort_requested'):
        assert ast.dump(old_functions[name]) == ast.dump(current_functions[name])
        preserved.append(name)
    actual_step = [node for node in ast.walk(tree) if isinstance(node, ast.Assign)
                   and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Attribute)
                   and node.value.func.attr == 'step' and isinstance(node.value.func.value, ast.Name)
                   and node.value.func.value.id == 'environment' and node.value.args
                   and isinstance(node.value.args[0], ast.Name) and node.value.args[0].id == 'action']
    record_calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call)
                    and isinstance(node.func, ast.Name) and node.func.id == 'record_probe_v4_submission']
    assert len(actual_step) == len(record_calls) == 1 and actual_step[0].lineno < record_calls[0].lineno
    body = ast.unparse(current_functions['probe_action_v4'])
    assert not any(word in body for word in ('ground_truth', 'own_odom', 'raw_guard', 'open(', 'read_text'))
    sources = {str(p): {'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size}
               for p in S.glob('*.py')}
    report = {'schema': 'mr3-v15-fixture-independent-review-v1',
              'review_status': 'two narrow v4 contract boundary gaps require correction',
              'source_files': sources, 'findings': findings, 'preserved_AST_functions': preserved,
              'actual_step_call_line': actual_step[0].lineno,
              'submission_record_call_line': record_calls[0].lineno,
              'read_only_review': {'received_snapshot_and_diagnostics_only': True,
                                   'no_raw_guard_truth_or_private_runtime_source': True,
                                   'per_robot_and_joint_WAIT_masks_authoritative': True,
                                   'no_alternate_goal_direction_or_production_policy_fallback': True,
                                   'typed_command_matches_planned_epoch_seq_digest_action': True,
                                   'three_second_rest_is_received_linear_proxy_not_physical_credit': True,
                                   'immutable_native_physics_and_task_gates_unchanged': True},
              'limits': 'Small synthetic same-function review only. No author suite repeated, '
                        'no native/ROS/GPU/control. Initial phase baseline/planned diagnostics '
                        'may be created before step, but WAIT committed state is intended to '
                        'advance only after actual RPC return; an exception ends the attempt.',
              'source_bytes_stable': sha((S / 'benchmark.py').read_bytes()) == sha(raw)}
    output = Path('/tmp/mr3_p2a0_v15_fixture_independent_review_v1.json')
    with output.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'review_status': report['review_status'], 'gaps_confirmed': 2,
                      'output': str(output), 'sha256': sha(output.read_bytes())}))


if __name__ == '__main__':
    main()
