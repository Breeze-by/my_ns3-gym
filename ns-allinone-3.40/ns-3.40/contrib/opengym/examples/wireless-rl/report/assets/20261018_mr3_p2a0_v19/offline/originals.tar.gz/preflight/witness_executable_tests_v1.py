"""CPU-only actual ELF/symlink and inherited PID/maps regression checks."""
import ast
import importlib.util
import json
import os
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location(
    'proposed_witness', HERE / 'proposed_live_admission_v1.py')
WITNESS = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(WITNESS)


def declaration():
    return json.loads((HERE / 'gazebo_executable_plan_fragment_v1.json').read_text())[
        'gazebo_executable']


class ActualExecutableTests(unittest.TestCase):
    def test_real_installed_symlink_and_versioned_elf_are_same_entity(self):
        spec = declaration()
        self.assertTrue(Path(spec['path']).is_symlink())
        self.assertTrue(os.path.samefile(spec['path'], spec['resolved_path']))
        proof = WITNESS.executable_identity(spec['resolved_path'], spec)
        self.assertTrue(proof['samefile'])
        self.assertEqual(proof['actual']['sha256'], spec['sha256'])
        self.assertEqual(proof['actual']['bytes'], spec['bytes'])

    def test_original_basename_rejects_the_actual_versioned_gazebo_elf(self):
        spec = declaration()
        self.assertNotEqual(Path(spec['resolved_path']).name, 'gzserver')
        self.assertFalse(Path(spec['path']).resolve(strict=True).name == 'gzserver')
        self.assertTrue(WITNESS.executable_identity(
            spec['resolved_path'], spec)['samefile'])

    def test_live_cpu_process_with_different_elf_is_rejected(self):
        self.assertTrue(Path('/proc/self/exe').exists())
        with self.assertRaisesRegex(ValueError, 'differs from declared gazebo entity'):
            WITNESS.executable_identity('/proc/self/exe', declaration())

    def test_declared_sha_and_size_remain_hard_gates(self):
        for field, value in [('sha256', '0' * 64), ('bytes', True),
                             ('bytes', declaration()['bytes'] + 1)]:
            with self.subTest(field=field, value=value):
                spec = declaration()
                spec[field] = value
                with self.assertRaisesRegex(ValueError, 'ELF/SHA/size differs'):
                    WITNESS.declared_gazebo_executable(spec)

    def test_declared_resolved_path_remains_a_hard_gate(self):
        spec = declaration()
        spec['resolved_path'] = '/proc/self/exe'
        with self.assertRaisesRegex(ValueError, 'resolved path changed'):
            WITNESS.declared_gazebo_executable(spec)

    def test_original_actual_pid_and_start_ticks_checks_are_preserved(self):
        actual = WITNESS.identity(os.getpid())
        self.assertEqual(WITNESS.ancestry(os.getpid(), actual)[0], actual)
        wrong = dict(actual, start_ticks=actual['start_ticks'] + 1)
        with self.assertRaisesRegex(ValueError, 'benchmark PID reused'):
            WITNESS.ancestry(os.getpid(), wrong)

    def test_original_actual_maps_and_inode_checks_are_preserved(self):
        raw = Path('/proc/self/maps').read_bytes()
        actual_executable = str(Path('/proc/self/exe').resolve(strict=True))
        selected = WITNESS.mapped(raw, actual_executable)
        self.assertTrue(selected)
        altered = raw.decode().splitlines()
        for index, line in enumerate(altered):
            fields = line.split(None, 5)
            if len(fields) == 6 and fields[5] == actual_executable:
                fields[4] = str(int(fields[4]) + 1)
                altered[index] = ' '.join(fields)
        with self.assertRaisesRegex(ValueError, 'device/inode differs'):
            WITNESS.mapped(('\n'.join(altered) + '\n').encode(), actual_executable)

    def test_only_two_witness_statements_and_two_new_helpers_differ(self):
        original = (HERE / 'original_v18_live_admission_v1.py').read_text()
        proposal = (HERE / 'proposed_live_admission_v1.py').read_text()
        before = ast.parse(original)
        after = ast.parse(proposal)
        new_names = {'declared_gazebo_executable', 'executable_identity'}
        after.body = [node for node in after.body
                      if not isinstance(node, ast.FunctionDef) or node.name not in new_names]
        replacement = ast.parse(
            'require(Path(f"/proc/{pid}/exe").resolve(strict=True).name == "gzserver", '
            '"observer PID is not gzserver")').body[0]
        for node in after.body:
            if not isinstance(node, ast.FunctionDef) or node.name != 'witness':
                continue
            replaced = 0
            for index, statement in enumerate(node.body):
                if (isinstance(statement, ast.Assign)
                        and any(isinstance(target, ast.Name)
                                and target.id == 'executable_proof'
                                for target in statement.targets)):
                    node.body[index] = replacement
                    replaced += 1
            self.assertEqual(replaced, 1)
            for child in ast.walk(node):
                if isinstance(child, ast.Dict):
                    pairs = [(key, value) for key, value in zip(child.keys, child.values)
                             if not (isinstance(key, ast.Constant)
                                     and key.value == 'executable')]
                    child.keys, child.values = map(list, zip(*pairs)) if pairs else ([], [])
        self.assertEqual(ast.dump(before, include_attributes=False),
                         ast.dump(after, include_attributes=False))
        before_functions = {node.name: ast.get_source_segment(original, node)
                            for node in ast.parse(original).body
                            if isinstance(node, ast.FunctionDef) and node.name != 'witness'}
        after_functions = {node.name: ast.get_source_segment(proposal, node)
                           for node in ast.parse(proposal).body
                           if isinstance(node, ast.FunctionDef) and node.name in before_functions}
        self.assertEqual(before_functions, after_functions)


if __name__ == '__main__':
    unittest.main(verbosity=2)
