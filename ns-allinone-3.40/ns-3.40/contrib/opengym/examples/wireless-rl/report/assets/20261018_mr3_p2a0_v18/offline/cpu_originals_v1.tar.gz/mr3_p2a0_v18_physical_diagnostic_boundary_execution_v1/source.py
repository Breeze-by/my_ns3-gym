#!/usr/bin/python3
"""Static source/contract review only. Does not start ROS/Gazebo or a participant."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
ROS = ROOT / 'ros2_ws/ros2-multi-robot-automap'
CORE = ROS / 'src/multi_robot_exploration/multi_robot_exploration'
PRIMARY = Path('/tmp/mr3_p2a0_v18_solver_primary_sources_v1')
OUTPUT = Path('/tmp/mr3_p2a0_v18_physical_diagnostic_boundary_review_v1.json')
MARKDOWN = Path('/tmp/mr3_p2a0_v18_physical_diagnostic_boundary_review_v1.md')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def main():
    assert not OUTPUT.exists() and not MARKDOWN.exists()
    inputs = [W / name for name in ('RESEARCH_PLAN.md', 'IMPLEMENTATION_PLAN.md', 'AGENTS.md',
        'MR3_ENV_CONTRACT.md', 'MR3_ADAPTER_CONTRACT.md', 'MR3_TASK_CONTRACT.md')]
    inputs += [ROS / name for name in ('user_guide.md', 'launch_commands.md',
        'src/multi_robot/src/mr3_gazebo_diff_drive.cpp',
        'src/multi_robot/models/turtlebot3_waffle/model.sdf',
        'src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py')]
    inputs += [CORE / name for name in ('mr3_task_contract.py', 'mr3_contacts.py')]
    inputs += [ROS / 'src/multi_robot/worlds' / ('p1c_' + scene + '.world')
               for scene in ('open', 'rooms', 'corridors')]
    inputs += [W / 'mr3_learning/audit_ppo.py', W / 'report/assets/20261017_mr3_p2a0_v3/independent/mr3_independent_physics_review.py']
    inputs += [Path('/usr/share/sdformat9/1.7/physics.sdf'),
        Path('/usr/include/gazebo-11/gazebo/common/Events.hh'),
        Path('/usr/include/gazebo-11/gazebo/physics/ContactManager.hh'),
        Path('/usr/include/gazebo-11/gazebo/physics/Contact.hh'),
        Path('/usr/include/gazebo-11/gazebo/physics/ode/ODEPhysics.hh')]
    inputs += [PRIMARY / name for name in ('World_11_10_2.cc', 'ODEPhysics_11_10_2.cc',
        'ode_objects_11_10_2.h', 'receipt.json', 'packages.stdout')]
    raw = {str(path): path.read_bytes() for path in inputs}
    bindings = {path: {'bytes': len(data), 'sha256': sha(data)} for path, data in raw.items()}

    def anchors(path, needles):
        lines = raw[str(path)].decode().splitlines()
        return [{'needle': needle, 'line_numbers': [i for i, text in enumerate(lines, 1) if needle in text]}
                for needle in needles]

    worlds = []
    for scene in ('open', 'rooms', 'corridors'):
        path = ROS / 'src/multi_robot/worlds' / ('p1c_' + scene + '.world')
        root = ET.fromstring(raw[str(path)])
        physics = root.find('world/physics')
        assert physics is not None and physics.get('type') == 'ode'
        values = {x.tag: x.text for x in physics}
        assert values == {'max_step_size': '0.001', 'real_time_factor': '1',
                          'real_time_update_rate': '1000'}
        worlds.append({'scene': scene, 'path': str(path), 'physics_type': physics.get('type'),
                       'explicit_physics': values, 'explicit_ode_solver_subtree': False})
    spec = ET.fromstring(raw['/usr/share/sdformat9/1.7/physics.sdf'])
    solver = spec.find("element[@name='ode']/element[@name='solver']")
    constraints = spec.find("element[@name='ode']/element[@name='constraints']")
    defaults = {x.get('name'): x.get('default') for x in solver if x.tag == 'element'}
    constraint_defaults = {x.get('name'): x.get('default') for x in constraints if x.tag == 'element'}
    assert defaults['type'] == 'quick' and defaults['iters'] == '50' and defaults['sor'] == '1.3'
    model_path = ROS / 'src/multi_robot/models/turtlebot3_waffle/model.sdf'
    model = ET.fromstring(raw[str(model_path)])
    surfaces = []
    for collision in model.findall('.//collision'):
        if collision.get('name') in ('wheel_left_collision', 'wheel_right_collision'):
            surface = collision.find('surface')
            surfaces.append({'collision': collision.get('name'),
                'friction_ode': {x.tag: x.text for x in surface.find('friction/ode')},
                'contact_ode': {x.tag: x.text for x in surface.find('contact/ode')}})
    assert len(surfaces) == 2
    source_anchors = {
        'environment': anchors(W / 'MR3_ENV_CONTRACT.md', ['95%/300', '命令硬上限',
            '物理参数保持', '原`.30m/s`', '连续最终零线速度', '该分支依赖新增条件物理模型',
            '所有原生/GPU尝试先预声明']),
        'implementation': anchors(W / 'IMPLEMENTATION_PLAN.md', ['### MR3-P2A.0',
            '用户已要求继续完成本步', '原95%/300秒']),
        'task': anchors(W / 'MR3_TASK_CONTRACT.md', ['## 成功门禁', '每台任务内真值路径',
            '全机体非支撑接触', 'ground_plane::link::collision']),
        'task_loader': anchors(CORE / 'mr3_task_contract.py', ['digest = hashlib.sha256(world_path.read_bytes())',
            'World SHA256 differs', 'Contract world path or content changed']),
        'full_auditor': anchors(W / 'mr3_learning/audit_ppo.py', ['machine_paths +=',
            'machine task/geometry changed from accepted W7 contract']),
        'driver': anchors(ROS / 'src/multi_robot/src/mr3_gazebo_diff_drive.cpp',
            ['ConnectWorldUpdateBegin', 'PublishOdometryMsg(_info.simTime)',
             'UpdateWheelVelocities();', 'Audit("actuation"', 'void MR3GazeboDiffDrivePrivate::UpdateOdometryWorld()',
             'float yaw', 'WorldLinearVel()', 'WorldAngularVel().Z()']),
        'world_update_primary': anchors(PRIMARY / 'World_11_10_2.cc',
            ['this->dataPtr->simTime += stepTime', 'this->dataPtr->iterations++',
             'event::Events::worldUpdateBegin', 'event::Events::beforePhysicsUpdate',
             'this->dataPtr->physicsEngine->UpdatePhysics()', 'event::Events::worldUpdateEnd()']),
        'engine_primary': anchors(PRIMARY / 'ODEPhysics_11_10_2.cc',
            ['void ODEPhysics::Load', 'dWorldSetQuickStepNumIterations', 'int ODEPhysics::GetSORPGSIters()',
             'bool ODEPhysics::GetParam', '_key == "iters"', '_key == "rms_error"',
             '_key == "constraint_residual"', 'void ODEPhysics::SetStepType']),
        'contact_manager': anchors(Path('/usr/include/gazebo-11/gazebo/physics/ContactManager.hh'),
            ['If no one is listening', 'SetNeverDropContacts', 'GetContactCount()', 'GetContacts()']),
        'physical_consumer': anchors(W / 'report/assets/20261017_mr3_p2a0_v3/independent/mr3_independent_physics_review.py',
            ['HORIZON_NS=', 'PATH_BOUND_M=', 'REST_SPEED=', 'missing_rest_evidence',
             'observed_nonrest_beyond_horizon', 'physical_evidence_complete'])}
    result = {
        'schema': 'mr3-v18-physical-diagnostic-boundary-independent-review-v1',
        'review_kind': 'static contracts/source and primary-document review only',
        'native_started': False, 'ros_or_gazebo_participant_started': False,
        'formal_audits_or_tests_rerun': False, 'canonical_mutation': False,
        'parent_reported_evidence_not_independently_replayed_here':
            'V17 actual zero target and applied wheel references coexist with lateral raw vy about .011m/s. This review does not promote that observation to solver root cause.',
        'verified_world_source': worlds,
        'installed_sdformat_1_7_defaults_not_live_measurements': {'solver': defaults, 'constraints': constraint_defaults},
        'verified_wheel_surface_source': surfaces,
        'source_anchors': source_anchors,
        'decision': 'Proceed first with a separately predeclared bounded, evaluator-isolated 1ms pre/post diagnostic; require a causal measurement-vs-body/contact split before adopting a solver profile. Do not retry a complete four-stage matrix as a substitute for diagnosis.',
        'current_authorisation': 'Continuing repair and diagnostic work stays inside authorised incomplete P2A.0. No fresh user permission is needed for necessary bounded preparation. It is not P2A training, new algorithm research, P2B or gateway credit.',
        'hard_gates_to_preserve': {
            'command_linear_mps': .20, 'command_angular_radps': .8,
            'measured_planar_mps': .30, 'measured_angular_radps': 1.2,
            'sampled_angular_accel_radps2': 7.0, 'native_target_latency_sec': .16,
            'stop_horizon_sec': .78, 'stop_path_per_robot_m': .144,
            'rest_planar_norm_mps': .01, 'rest_consecutive_raw_sources': 3,
            'meaningful_prior_nonzero_span_sec': .10, 'meaningful_initial_speed_mps': .05,
            'maximum_raw_source_gap_sec': .10, 'task_peer_body_distance_m': .50,
            'settled_segment_path_m': .0078, 'coverage': .95, 'duration_sec': 300,
            'evaluator_participation_truth_path_each_m': 1.0, 'contact_streams': 18,
            'physical_tick_sec': .001, 'controlled_quantum_sec': .020,
            'robots': ['tb1', 'tb2', 'tb3']},
        'minimum_diagnostic_evidence': [
            'One epoch, robot and exact scoped canonical/base/wheel link names; reset/release/task-end/cleanup identities remain explicit. Fixed three-robot scene/seed; no robot removal, teleport, force injection or bypassed guard to make a convenient trajectory.',
            'Unique monotonic record_sequence and physics iteration, exact sim_time_ns, step_size_ns, phase before_physics or after_physics. Pair one pre/post per real step; missing/duplicate/rewound rows and truncated output are evidence failures, not interpolated.',
            'Gazebo11 increments simTime and iteration before WorldUpdateBegin. The same T labels a pre-integration state and its post-integration state; record actual labels plus interval [T-h,T] and do not relabel old source stamps or failures.',
            'At both phases copy full model/canonical-link pose quaternion, world linearXYZ/angularXYZ, inertial/COM offsets and stable reference points. Compare same-point displacement/velocity; account for omega cross r before calling a mismatch. Preserve Z/roll/pitch rather than flattening the body.',
            'Bind the latest tagged target epoch/seq/source clock, actual target-storage receipt, driver actuation seq and actual current/desired/applied rim references; read wheel GetVelocity plus retained motor reference/fmax at the matching physics phase. Zero target/reference is not zero measured joint or zero body velocity.',
            'Bind actual raw WORLD odom header/frame/full twist to its publisher phase and independent reproduction of the existing yaw rotation. Current WORLD code rotates model WorldLinearVel with float yaw and only populates angular.z; do not present raw angular.x/y defaults as a measured full-world angular guarantee.',
            'Include ground/wheel/caster support geometry in the new isolated diagnostic and retain the original 18-stream non-support evaluator unchanged. Save exact scoped pair IDs, valid contact count, positions/normals/depth and post-solve wrenches when actually available, with the force reference frame/COM convention.',
            'ContactManager may omit retained feedback when no subscriber exists; record NeverDropContacts/subscriber/feedback availability and only copy GetContactCount valid entries. Never interpret an unobserved contact vector as no forces. Any extra retention/feedback setting must be declared and identical across compared profiles.',
            'Dump active physics type/profile, expanded/effective SDF and actual ODE settings before release and at end. GetParam(iters/sor) and GetSORPGSIters are SDF-backed; use public GetWorldId with dWorldGetQuickStepNumIterations/W/CFM/ERP plus GetStepType and active engine source/library provenance to verify the applied numeric profile.',
            'Record active gravity, dt, SOR/iters/precon, CFM/ERP, friction model, contact correction/layer/maxcontacts, inertia-rescaling, damping/auto-disable/thread/randomisation settings and all model surfaces/inertias. Unsupported getters must remain unsupported, not default to zero.',
            'At post-solve, record available rms_error/constraint_residual/num_contacts from the actual engine. These are diagnostics, not replacements for the unchanged physical stop tests. Capture eligible motion, the entire subsequent zero-only interval and enough raw tail for the original three-source rest check.',
            'All world/body/contact additions are evaluator-isolated evidence only: no new actor/candidate/mask/reward inputs or feedback into target ranking. Observer code only reads; no SetLinearVel/SetAngularVel/force clamp/contact disabling or after-the-fact velocity smoothing.',
            'Raw buffering is bounded; dropped pairs or write failures must be explicit. Logging overhead and full wall charge are retained. Close through existing stop/storage/Nav2/SLAM/native protocol with all owned PID/start identities gone.'],
        'causal_interpretation': [
            'Zero references while measured joints remain moving identifies an unresolved motor/joint/constraint response, not proof that the command interface is late.',
            'Measured wheel rims near zero while same-point world pose and velocities drift coherently identifies real simulated body motion requiring contact/constraint analysis; it is not repaired by dropping vy from the norm.',
            'Odometry differs from the same-point, same-phase world values while pose motion does not corroborate it suggests a measurement/frame/timing bug to reproduce exactly; a phase mismatch is not itself proof of that bug.',
            'A purely homogeneous yaw rotation maps exact world zero velocity to zero. Float yaw alone cannot create .011m/s from exact world zero; the existing applied wheel zero observation does not establish world zero.',
            'Only if the persistent lateral component and contact/constraint residual improve under a predeclared solver-only refinement, with actual applied parameters and all other settings fixed, is solver convergence supported. Larger iters is not guaranteed monotonic improvement.'],
        'minimal_solver_experiment_boundary': [
            'First instrument the existing profile without changing solver/physics settings; prove the diagnostic can observe a meaningful event and reproduce the same stop failure class. No new native has been run in this review.',
            'If that supports a convergence hypothesis, predeclare a small fixed refinement family, normally iters only with dt/SOR/CFM/ERP/friction/model/driver/commands unchanged. Preserve every level and failed attempt; do not search until one passes then retain only it.',
            'Changing quick to world is an algorithm comparison/reference profile, not an iterations-only fix. Changing friction/slip/CFM/ERP/damping/mass/inertia/torque/caster/support/contact geometry alters the plant; it needs its own causal justification and cannot be called solver accuracy tuning.',
            'Closed-loop Nav2 commands can diverge across solver profiles. A comparison must state exactly which actual inputs/prefix remain matched. A separately predeclared fixed-input component replay may diagnose physics but supplies no actor/navigation/whole-episode credit.',
            'Adopt one explicit profile before the next formal matrix, bind its effective source/configuration and runtime-applied values, then use one new clean pushed freeze for all required stages. Diagnostic success is not matrix/P2A.0 acceptance; old V17 failures remain.'],
        'world_hash_contract_issue': {
            'verified': 'Task loader binds the entire selected world SHA, not geometry-only; audit_ppo also requires all three world bytes and machine task contracts equal accepted W7 bytes.',
            'impact': 'Adding an ODE solver subtree directly to p1c_*.world will fail those gates even if all collisions/ROI are identical.',
            'minimal_option': 'Keep accepted world/model bytes, declare an independently pinned load-time physics-profile source with explicit limited writes and native readback; no unrecorded post-release SetParam. This still changes active simulation configuration and requires a new freeze/profile receipt.',
            'alternative_if_world_file_changes': 'First version a narrowly reviewed physics-subtree adapter with exact old-vs-new collision geometry, ROI/rasterization/truth equality, unchanged task fields and explicit world/profile hashes. Do not delete the complete accepted-task source gate or silently overwrite contract digests.',
            'acceptance': 'Solver-specific metadata/versioning must be decided before running; this is technical preparation within current authorisation, not a reason to ask the user to reauthorise completing P2A.0.'},
        'risks': [
            'Normal-support contact exclusion means zero task contacts does not rule out solver/ground impulses.',
            'QuickStep iteration/SOR refinement may change contact ordering, trajectory, sensor generation and wall throughput; finite step data does not prove continuous safety.',
            'Diagnostic feedback retention or synchronous file I/O can alter scheduling; compare identical observers and retain timing/overflow facts.',
            'A lower lateral component in one stopped segment does not establish robust rest across worlds, repeated reset, both turn signs or both worker loads.',
            'The .01 rest threshold and .01 surface contact max_vel are distinct concepts; their similar units/magnitudes do not establish causality or justify changing either.',
            'Actual engine parameters cannot be inferred solely from source defaults, installed system libode version or a nominal world filename. Loaded library/profile custody and native values are required.'],
        'verification_exit': [
            'A bounded component diagnostic may establish measurement/solver cause only, with all raw failures and limits retained; charge it separately and predeclare its finite wall/sim limits.',
            'No .01/rest/three-source, .78/.144, .30/1.2/7, .50, 95%/300s, activity/contacts/owned close, source freshness, target latency, reward or actor/mask gate is weakened.',
            'Later P2A.0 acceptance still requires the new same-freeze complete preparation matrix and mandatory readers; pooled A OR B cannot cancel an observed eligible nonrest violation. No PPO/pilot budget is used or reset.'],
        'official_primary_sources': [
            {'url': 'https://raw.githubusercontent.com/gazebosim/gazebo-classic/gazebo11_11.10.2/gazebo/physics/World.cc', 'local': str(PRIMARY / 'World_11_10_2.cc')},
            {'url': 'https://raw.githubusercontent.com/gazebosim/gazebo-classic/gazebo11_11.10.2/gazebo/physics/ode/ODEPhysics.cc', 'local': str(PRIMARY / 'ODEPhysics_11_10_2.cc')},
            {'url': 'https://classic.gazebosim.org/tutorials?cat=physics&tut=physics_params', 'scope': 'Official conceptual discussion: quick iterative vs world direct solver, iters/SOR scope and friction model; not proof of current runtime settings.'}],
        'original_source_bindings': bindings,
        'helper_sha256': sha(Path(__file__).read_bytes()),
        'limits': ['No actual runtime engine readback, native diagnostic, formal rerun, solver sweep or new participant was performed.',
            'V17 parent-supplied lateral observation and failure facts are preserved, not relabelled or independently recomputed from large raw traces here.',
            'Versioned upstream11.10.2 primary source and installed11.10.2 package/ELF metadata do not alone prove distro patch equivalence or symbol interposition.']}
    for path, proof in bindings.items():
        assert sha(Path(path).read_bytes()) == proof['sha256'], 'source changed during static review: ' + path
    OUTPUT.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + '\n')
    text = """# V18 受控物理诊断：独立边界复核（仅静态）

建议先做有界、隔离的1ms物理更新前/后诊断，再决定solver修复。本次未启动ROS/Gazebo、未新建participant、未重跑formal，未改Git。V17零target/轮参考仍vy约.011来自parent既有原件分析；本复核不把它升级为solver根因。

## 已证源码事实

- 原three worlds只声明ODE、dt=.001、RTF1/update1000；solver子树未显式声明。安装SDFormat1.7 schema默认quick/50/1.3只是静态默认，不能称live配置。
- actual driver接WorldUpdateBegin，先WORLD odom发布，再读取轮反馈并写actuation。官方11.10.2先增加simTime/iteration，随后Begin→碰撞检测→BeforePhysics→求解/dirtyPose→End；相同T的pre/post应按iteration+phase配对，不能把前态当后态或重写旧FAIL。
- WORLD odom由model WorldLinearVel做yaw旋转；该函数只填angular.z。需要同点、同相位full world XYZ/姿态/COM偏置来分辨测量与真实机体运动。零轮参考不等于零机体速度，单独float yaw不能从精确world零制造.011。
- 18路任务contact有意排除wheel/caster–ground支撑。ContactManager无listener可不留反馈；GetContacts只取GetContactCount有效前缀。空数组不能自动排除地面冲量。
- ODE GetParam(iters/sor)与GetSORPGSIters返回SDF缓存；public GetWorldId允许配合dWorldGetQuickStepNumIterations/W/CFM/ERP作实际双读。官方源与实际包/库SHA已在同目录primary receipt保留。

## 最小新增证据

每个实际1ms tick恰一对before_physics/after_physics，绑定epoch/robot/scoped link、iteration、原clock、dt；保存同点world pose/linearXYZ/angularXYZ及COM、当前轮速/电机参考/fmax、实际tagged target/storage/actuation引用、原odom及其发布相位。contact保存真实pair、有效个数、位置/normal/depth与实际可用post-solve wrench；反馈未启用/遗漏须显式，不补0。

保存active engine/profile/effectiveSDF、实际ODE读回、step/gravity/solver/friction/CFM/ERP/damping等，以及加载库/模型SHA。额外日志为evaluator-isolated原件，不进入actor、候选、mask、reward或目标排名；不得SetLinearVel归零、忽略vy、低通/clip出静止、关碰撞或删支撑。buffer溢出/缺pre-post/wall成本都留证，最后仍须原严格关闭。

先用原profile观察eligible movement及整段zero尾部：若wheel仍动查joint/motor；若joint近0但world pose/vel同向漂移查contact/约束；若同点同相位raw/世界不符再查测量。只有一变量solver细化使残差与横漂同降，才支持收敛假说。iters增大并不保证单调；closed-loop动作也可能分叉，必须标明实际matched prefix。world直接求解可作独立参考，不能伪称仅iterations变更。friction、CFM/ERP、damping、mass/inertia、torque/几何变化是plant变更，须另作有据论证。

## 原门与source接线

不改rest全平面≤.01/三raw源、.78s/.144m、有意义初速≥.05且先前输出≥.1s、源gap≤.1s、.30/1.2/7、160ms实际存储、.50机体、.0078 settled整段预算、95%/300s、三机真值≥1m/目标、18源/reward/所有权/关闭。pooled A或B不能抵消真实eligible nonrest；诊断PASS不替完整同冻结四stage。

重要：mr3_task_contract.py:74–78/379–395核整个world SHA；audit_ppo.py:367–384还要求三world和machine task契约逐字等于W7。直接添加solver XML也会触发原source门。最小选项是保留原world/model字节，另冻结一个load-time有限physics profile来源，所有写入和实际读回显式归档；若改world，须事前版本化仅physics子树适配并证明collision/ROI/栅格/任务值完全同，不能删除旧门或悄悄改digest。

必要有界诊断与有据修复仍在已授权P2A.0内，无须再次索取完成权限。新profile进入正式验收前须clean push/新run-id/预声明scope与预算/独立读回和来源绑定；保留所有baseline/refinement失败，后续完整矩阵仅使用一个冻结profile。无新PPO/pilot或余额重置。

完整可检索字段、逐源SHA、精确line anchors及primary URLs见同名JSON。该复核只证明契约/源码事实和最小证据义务，未证明实时solver值、实际接触因果、连续机体安全或修复有效。
"""
    MARKDOWN.write_text(text)
    print(json.dumps({'output': str(OUTPUT), 'output_sha256': sha(OUTPUT.read_bytes()),
        'markdown': str(MARKDOWN), 'markdown_sha256': sha(MARKDOWN.read_bytes()),
        'source': str(Path(__file__)), 'source_sha256': sha(Path(__file__).read_bytes()),
        'source_inputs': len(bindings), 'source_before_after_stable': True,
        'native_started': False, 'canonical_mutation': False}, sort_keys=True))

if __name__ == '__main__':
    main()
