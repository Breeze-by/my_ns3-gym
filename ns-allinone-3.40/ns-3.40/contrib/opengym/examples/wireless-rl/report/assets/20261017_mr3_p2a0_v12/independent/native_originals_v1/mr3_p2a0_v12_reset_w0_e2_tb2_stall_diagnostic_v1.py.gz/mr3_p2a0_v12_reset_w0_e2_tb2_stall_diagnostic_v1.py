"""Closed episode read-only causal stall diagnosis. No source imports, truth or control."""
from pathlib import Path
import collections
import hashlib
import json
import math

ROOT=Path('/home/zhuyulab/ns3-workspace')
E=ROOT/'ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261017_v12_reset/worker0/episode002_open_101'
OUT=Path('/tmp/mr3_p2a0_v12_reset_w0_e2_tb2_stall_diagnostic_v1.json')
FREEZE='6b1b4a0108351f5bfb70ec0c96ba895248d4f7a8'
RELEASE=74.3
END=106.3
inputs={}

def rows(name):
 p=E/name;before=p.stat();h=hashlib.sha256()
 with p.open('rb')as stream:
  for n,raw in enumerate(stream,1):
   h.update(raw)
   if raw.strip():yield n,json.loads(raw)
 after=p.stat();assert(before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)
 inputs[name]={'sha256':h.hexdigest(),'bytes':after.st_size}

def phase(t):
 dt=t-RELEASE
 return 'goal1'if dt<10 else'wait1'if dt<13 else'goal2'if dt<28 else'wait2'

def wrap(a):return math.atan2(math.sin(a),math.cos(a))

trans=[r for _,r in rows('transitions.jsonl')]
initial=trans[0]['snapshot'];snaps=[r['snapshot']for r in trans]
adapter=[];goals=[];delivery=[]
for n,r in rows('adapter.jsonl'):
 p=r['payload']
 if r['kind']=='native_send'and p['robot']=='tb2':goals.append(dict(line=n,row=r))
 if r['kind']in('native_send','native_cancel','protocol','delivery')and'tb2'in str(p):
  if r['kind']!='delivery'or p.get('kind')in('ack','goal_result')or'status'in str(p):
   adapter.append(dict(line=n,row=r))
summary=collections.defaultdict(lambda:{'decision_count':0,'reasons':collections.Counter(),
 'request_v_nonzero':0,'output_v_nonzero':0,'request_w_nonzero':0,'output_w_nonzero':0,
 'max_abs_request_v':0,'max_abs_request_w':0,'max_abs_output_v':0,'max_abs_output_w':0})
samples={};per_second={};nonzero_v_examples=[];raw_counts=collections.Counter();raw_maxv=0
own=[];decision_full_examples={}
for n,r in rows('motion_safety.jsonl'):
 t=r['sim_time_sec'];p=r['payload']
 if r['kind']=='own_odom'and p['robot']=='tb2':
  m=p['message'];stamp=m['header']['stamp'];source=stamp['sec']+stamp['nanosec']/1e9
  if RELEASE<=source<=END:
   pose=m['pose']['pose'];q=pose['orientation'];v=m['twist']['twist']
   own.append(dict(line=n,source_stamp=source,callback_clock=t,
      x=pose['position']['x'],y=pose['position']['y'],
      yaw=math.atan2(2*(q['w']*q['z']+q['x']*q['y']),1-2*(q['y']**2+q['z']**2)),
      planar_speed=math.hypot(v['linear']['x'],v['linear']['y']),w=v['angular']['z']))
 if not RELEASE<=t<=END or p.get('robot')!='tb2':continue
 if r['kind']=='raw_request':
  raw_counts[phase(t)]+=1;raw_maxv=max(raw_maxv,abs(p['request']['v']))
 if r['kind']!='decision':continue
 ph=phase(t);s=summary[ph];d=p['decision'];req=p['request']or{'v':0,'w':0};state=p['own_state'];s['decision_count']+=1;s['reasons'][d['reason']]+=1
 for component,index in(('v',0),('w',1)):
  s['request_'+component+'_nonzero']+=req[component]!=0
  s['output_'+component+'_nonzero']+=d['output'][index]!=0
  s['max_abs_request_'+component]=max(s['max_abs_request_'+component],abs(req[component]))
  s['max_abs_output_'+component]=max(s['max_abs_output_'+component],abs(d['output'][index]))
 active_goal=goals[0]['row']['payload']['pose']if ph in('goal1','wait1')else goals[1]['row']['payload']['pose']
 bearing=math.atan2(active_goal['y']-state['y'],active_goal['x']-state['x'])if state else None
 compact=dict(line=n,record_sequence=r['record_sequence'],clock=t,phase=ph,
  decision_sequence=p['decision_sequence'],request={k:req.get(k)for k in('v','w','received_stamp','sequence')},
  own_state={k:state.get(k)for k in('x','y','yaw','v','w','source_stamp','odom_source_stamp','tf_source_stamp')}if state else None,
  goal_xy={k:active_goal[k]for k in('x','y')},goal_distance=math.hypot(active_goal['x']-state['x'],active_goal['y']-state['y'])if state else None,
  goal_bearing=bearing,relative_goal_bearing=wrap(bearing-state['yaw'])if state else None,
  decision={k:d.get(k)for k in('allow','reason','output','minimum_margin_m','body_margin_m','component_filter')},
  peers={name:{k:v.get(k)for k in('x','y','yaw','source_stamp','v','w')}for name,v in p['received_peers'].items()if v})
 key=ph+':'+d['reason']
 if key not in samples:samples[key]=compact;decision_full_examples[key]=dict(line=n,row=r)
 second=int(round((t-RELEASE)*1e9)//1000000000)
 if second not in per_second:per_second[second]=compact
 if req['v']and len(nonzero_v_examples)<12:nonzero_v_examples.append(compact)
for s in summary.values():s['reasons']=dict(s['reasons'])
drive=collections.defaultdict(lambda:{'actuations':0,'desired_v_nonzero':0,'max_abs_desired_v':0,'max_abs_desired_w':0,'max_abs_rim':0})
for n,r in rows('drive_tb2.jsonl'):
 t=r['sim_time_ns']/1e9
 if r['kind']!='actuation'or not RELEASE<=t<=END:continue
 d=drive[phase(t)];d['actuations']+=1;d['desired_v_nonzero']+=r['desired_v']!=0
 d['max_abs_desired_v']=max(d['max_abs_desired_v'],abs(r['desired_v']));d['max_abs_desired_w']=max(d['max_abs_desired_w'],abs(r['desired_w']))
 d['max_abs_rim']=max(d['max_abs_rim'],*map(abs,r['applied_rim_mps']))
unique={o['source_stamp']:o for o in own};ordered=[unique[k]for k in sorted(unique)]
path=sum(math.hypot(b['x']-a['x'],b['y']-a['y'])for a,b in zip(ordered,ordered[1:]))
snapshots=[]
for snap in snaps:
 bot=snap['robots'][1];mask=snap['per_robot_action_masks'][1]if'per_robot_action_masks'in snap else None
 snapshots.append(dict(sequence=snap['sequence'],stamp=snap.get('stamp'),digest=snap['digest'],
  robot={k:bot.get(k)for k in('name','x','y','yaw','activity','navigation')},
  candidate_reachable=[c['index']for c in snap['candidates']if c['reachable'][1]],
  legal_joint_tb2_goal_indices=sorted({(a//10)%10 for a,allowed in enumerate(snap['joint_action_mask'])if allowed and(a//10)%10<8})))
result=dict(schema='mr3-v12-closed-tb2-stall-diagnostic-v1',freeze=FREEZE,episode=str(E),task_interval=[RELEASE,END],
 scope='Read-only raw causal diagnosis; no changed gates, source, native experiment, truth, or formal PASS. Upstream controller cmd_vel before smoother not archived; received requests are actual smoother output.',
 inputs=inputs,goals=goals,adapter_tb2_protocol_delivery=adapter,decisions_by_phase=dict(summary),
 raw_request_callbacks_by_phase=dict(raw_counts),raw_request_max_abs_v=raw_maxv,
 first_reason_examples=samples,full_raw_first_reason_examples=decision_full_examples,
 per_second=list(per_second.values()),nonzero_v_examples=nonzero_v_examples,drive_by_phase=dict(drive),
 actual_local_odom=dict(unique_sources=len(ordered),path_chord_sum_m=path,first=ordered[0],last=ordered[-1],
  max_planar_speed=max(o['planar_speed']for o in ordered),max_abs_w=max(abs(o['w'])for o in ordered)),
 candidate_snapshot_summary=snapshots,
 final_received_activity=snaps[-1]['robots'][1]['activity'])
with OUT.open('x')as f:f.write(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:result[k]for k in('decisions_by_phase','raw_request_max_abs_v','drive_by_phase','actual_local_odom','final_received_activity')},indent=2))
print('PER_SECOND_COMPACT')
for s in result['per_second']:print(s['clock'],s['phase'],round(s['own_state']['yaw'],3),round(s['relative_goal_bearing'],3),s['request']['v'],s['request']['w'],s['decision']['reason'],s['decision']['output'])
