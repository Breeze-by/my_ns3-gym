#!/usr/bin/python3
"""Source-only lifecycle review. Does not build/load/run Gazebo/ROS or tests."""
import difflib
import hashlib
import json
from pathlib import Path
import re
import sys
import time

P=Path(__file__).parent
SOURCES={
 'world':Path('/tmp/mr3_p2a0_v18_driver_diagnostic_proposal_v5/World_11.10.2.cc'),
 'private':Path('/tmp/mr3_p2a0_v24_install_lifecycle_proposal_v1/primary/WorldPrivate.hh'),
 'server':Path('/tmp/mr3_p2a0_v22_ray_box_corrector_proposal_v1/primary/Server_11.10.2.cc'),
 'physics_iface':Path('/tmp/mr3_p2a0_v22_ray_box_corrector_proposal_v1/primary/PhysicsIface_11.10.2.cc'),
 'gazebo':Path('/tmp/mr3_p2a0_v22_ray_box_corrector_proposal_v1/primary/gazebo_11.10.2.cc'),
 'shared':Path('/tmp/mr3_p2a0_v24_install_lifecycle_proposal_v1/primary/gazebo_shared.cc'),
 'ode':Path('/tmp/mr3_p2a0_v18_driver_diagnostic_proposal_v5/ODEPhysics_11.10.2.cc'),
 'sensor_manager':Path('/tmp/mr3_p2a0_v21_ray_cache_lock_review_v1/SensorManager_11.10.2.cc'),
 'event_header':Path('/usr/include/gazebo-11/gazebo/common/Event.hh'),
 'world_header':Path('/usr/include/gazebo-11/gazebo/physics/World.hh'),
 'model_header':Path('/usr/include/gazebo-11/gazebo/physics/Model.hh'),
 'link':Path('/tmp/mr3_p2a0_v13_stop_point_review_v1/Link.cc'),
 'time':P/'Time_11.10.2.cc',
 'old_cpp':Path('/tmp/mr3_p2a0_v22_ray_box_corrector_native_readback_proposal_v2/mr3_ray_box_corrector.cpp'),
 'proposed_cpp':Path('/tmp/mr3_p2a0_v24_install_lifecycle_proposal_v1/mr3_ray_box_corrector.proposed.cpp'),
 'previous_own_review':Path('/tmp/mr3_p2a0_v22_corrector_source_independent_review_v2/review_v2.json')}

def sha(raw):return hashlib.sha256(raw).hexdigest()
def identity(path):
 st=path.stat();return {'path':str(path),'sha256':sha(path.read_bytes()),'bytes':st.st_size,
  'mtime_ns':st.st_mtime_ns,'inode':st.st_ino,'device':st.st_dev}
def require(value,reason):
 if not value:raise ValueError(reason)
def block(source,start,end):
 a=source.index(start);b=source.index(end,a);return source[a:b]
def ref(key,text):
 value=source[key];require(value.count(text)==1,'nonunique source anchor '+key+text)
 return {'input':key,'path':str(SOURCES[key]),'line_1based':value[:value.index(text)].count('\n')+1,'anchor':text}

started=time.monotonic()
before={k:identity(p) for k,p in SOURCES.items()}
source={k:p.read_text() for k,p in SOURCES.items()}
world=source['world'];private=source['private'];server=source['server']
ctor=block(world,'World::World(const std::string &_name)','World::~World()')
load=block(world,'void World::Load(sdf::ElementPtr _sdf)','const sdf::ElementPtr World::SDF()')
init=block(world,'void World::Init(UpdateScenePosesFunc _func)','void World::Run(')
require(': dataPtr(new WorldPrivate)' in ctor and 'iterations' not in ctor,
        'world constructor initialization differs')
require('public: uint64_t iterations;' in private and 'WorldPrivate(' not in private,
        'counter has a hidden initializer/constructor')
require('iterations' not in load and 'this->dataPtr->iterations = 0;' in init,
        'iteration counter lifecycle differs')
require('this->dataPtr->stop = false;' in ctor and 'return !this->dataPtr->stop;' in world,
        'Running getter differs from !stop')
require('this->dataPtr->loaded = false;' in ctor and 'this->dataPtr->sensorsInitialized = false;' in ctor,
        'boolean getter backing not explicitly initialized')
require(load.index('event::Events::worldCreated(this->Name());') < load.index('this->dataPtr->loaded = true;'),
        'created not before load completion')
require('bool World::IsLoaded() const\n{\n  return this->dataPtr->loaded;\n}' in world,
        'IsLoaded no longer reads initialized loaded backing')
require('bool World::SensorsInitialized() const\n{\n  return this->dataPtr->sensorsInitialized;\n}' in world,
        'SensorsInitialized no longer reads initialized backing')
require('public: common::Time simTime;' in private and
        'Time::Time()\n{\n  this->sec = 0;\n  this->nsec = 0;' in source['time'],
        'SimTime class default does not establish zero')
require('gazebo::common::Time World::SimTime() const\n{\n  return this->dataPtr->simTime;\n}' in world,
        'SimTime getter not backing read')
require('Model_V World::Models() const\n{\n  return this->dataPtr->models;\n}' in world and
        'private: Link_V links;' in source['model_header'] and
        'public: std::vector<std::string> sensors;' in source['link'] and
        'unsigned int Link::GetSensorCount() const\n{\n  return this->dataPtr->sensors.size();\n}' in source['link'],
        'model/link sensor-count containers are not the expected initialized vectors')
require(server.index('physics::load_world(world, worldElem);') < server.index('physics::init_worlds(nullptr);')
        < server.index('sensors::run_once(true);') < server.index('sensors::run_threads();')
        < server.index('physics::run_worlds(iterations);'), 'declared initial server lifecycle order differs')
require(source['shared'].index('(*iter)->Load(_argc, _argv);') < source['shared'].index('(*iter)->Init();'),
        'SystemPlugin setup order differs')
require(source['gazebo'].index('gazebo_shared::setup(') < source['gazebo'].index('sensors::load()')
        < source['gazebo'].index('gazebo::physics::load()'), 'system Init no longer predates world physics creation')
require('iter.second->callback(_p);' in source['event_header'], 'event no longer invokes callback synchronously')
require('void ODEPhysics::Init()\n{\n}' in source['ode'], 'ODE Init now mutates registered collider table')
require(source['physics_iface'].index('g_worlds.push_back(world);') < source['physics_iface'].index('physics::get_world('),
        'create_world ownership registration differs')
old=source['old_cpp'];new=source['proposed_cpp']
a=old.index('      const auto world = gazebo::physics::get_world(name);',old.index('worldCreated')) if 'worldCreated' in old else old.index('      const auto world = gazebo::physics::get_world(name);')
# Limit the implementation delta to the single actual created callback body.
start=old.index('      const auto world = gazebo::physics::get_world(name);')
end=old.index('\n    });\n    ended =',start)
newstart=new.index('      Json observed{{"world", name},')
newend=new.index('\n    });\n    ended =',newstart)
require(old[:start]==new[:newstart] and old[end:]==new[newend:], 'proposal changed outside created callback')
created=new[newstart:newend]
require('->Iterations(' not in created, 'proposal still reads preInit iteration counter')
for value in ['{"installation_phase", "world_created_during_load_before_world_init"}',
              '{"world_iterations", nullptr}', '{"world_iterations_available", false}',
              '{"world_iterations_unavailable_reason", "counter_initialized_only_in_World_Init"}',
              'world->IsLoaded()', 'world->SensorsInitialized()', 'link->GetSensorCount()',
              'dWorldGetQuickStepNumIterations(ode->GetWorldId())', 'physics->GetMaxStepSize()']:
 require(value in created,'expected actual phase/getter field missing '+value)
require('!world->Running()' not in created and 'if (world->Running()' not in created,
        'Running still used as a false-valued readiness guard')
require('fatal_installation_precondition' in created and 'failed_preconditions' in created,
        'actual installation failure reporting absent')
require(before['old_cpp']['sha256']=='b165ce49eaf5b3d52853cd759e4809962192d1922f0f210f5c82cff79c2a6b2a'
        and before['proposed_cpp']['sha256']=='f82646c8434b77c42f585ac1828eda84640bac873f70cc7de6848cfbd6493473',
        'reviewed implementation source changed')
after={k:identity(p) for k,p in SOURCES.items()};require(before==after,'source changed during independent review')
report={'schema':'mr3-v24-world-created-independent-source-review-v1','passed':True,'blockers':[],
 'scope':'Read-only exact primary/installed-header source and single proposed callback delta review. No SDK probe, test, build, ELF loading, native, ROS or DDS invocation.',
 'inputs':before,'inputs_after':after,'final_source_sha_stat_stable':True,
 'findings':[
 {'id':'uninitialized-counter','conclusion':'WorldPrivate iterations is an uninitialized fundamental member before World::Init, because new WorldPrivate is default-initialized and neither its class nor World constructor/Load initializes the counter. Reading it in WorldCreated is invalid; reject that read, not the physical limits.',
  'evidence':[ref('private','public: uint64_t iterations;'),ref('world',': dataPtr(new WorldPrivate)'),ref('world','  this->dataPtr->iterations = 0;\n  this->dataPtr->logPrevIteration = 0;')]},
 {'id':'Running-not-thread-state','conclusion':'Running returns !stop and ctor sets stop=false. Thus normal preInit Running may be true; its false value is not a legal prerequisite. Record typed actual value only.',
  'evidence':[ref('world','bool World::Running() const'),ref('world','  this->dataPtr->stop = false;\n  this->dataPtr->sensorsInitialized = false;')]},
 {'id':'defined-getters','conclusion':'IsLoaded and SensorsInitialized are explicitly initialized false. SimTime contains a default-constructed Time with sec=nsec=0. Models/GetLinks/GetSensorCount use fully constructed vector containers; no analogous uninitialized scalar count.',
  'time_primary_url':'https://raw.githubusercontent.com/gazebosim/gazebo-classic/gazebo11_11.10.2/gazebo/common/Time.cc',
  'link_primary_url':'https://raw.githubusercontent.com/gazebosim/gazebo-classic/gazebo11_11.10.2/gazebo/physics/Link.cc'},
 {'id':'before-first-physics-and-sensor','conclusion':'On the declared initial single-world Server startup path, worldCreated runs synchronously inside World::Load, after ODE constructor/Load and entity loading, before Load completes and World::Init. Server first run_once/sensor threads/world threads occur later. Rejecting already-created model sensors preserves the sensor-free installation precondition. This source/event ordering, not Running=false, establishes the intended phase.',
  'evidence':[ref('world','  event::Events::worldCreated(this->Name());'),ref('server','      physics::load_world(world, worldElem);'),ref('server','    physics::init_worlds(nullptr);'),ref('server','  sensors::run_once(true);'),ref('server','  sensors::run_threads();'),ref('server','  physics::run_worlds(iterations);')]},
 {'id':'system-Init-too-early','conclusion':'SystemPlugin Load/Init runs in gazebo_shared.setup during Server.PreLoad before the world/ODE engine exists. Moving installation blindly to SystemPlugin::Init would lose required native ODE world/table availability.',
  'evidence':[ref('shared','    (*iter)->Init();'),ref('server','  return gazebo::setupServer(this->dataPtr->systemPluginsArgc,')]},
 {'id':'narrow-proposal','conclusion':'Only the created callback body changes from exact b165 to f826. It does not read Iterations, records explicit phase/null/availability/reason, validates initialized actual getters, preserves actual150/.001 native readback, CAS/dSetColliderOverride/lifetime/core math and failures remain source-bound. No physical/braking/task gate was lowered.'}
 ],
 'correction_to_previous_own_review':{'path':str(SOURCES['previous_own_review']),'sha256':before['previous_own_review']['sha256'],
  'withdrawn_inference':'WorldCreated implies a valid/initialized iteration0 getter. The old source event ordering observation remains, but iteration0 at that event was not established and the old guard read was invalid.',
  'old_bytes_preserved':True,'not_retroactively_fixed':'V23 crash/forced cleanup and all old failures remain original. Future afterInit SDK result may establish0 only for its own probe; never fill or relabel past native data.'},
 'limits':['This is the declared initial one-world/no-sensor Server path, not a general guarantee for arbitrary custom plugins, live reload, manual early Run or multi-world concurrency.',
           'Source review does not assert actual future library load, native installed-ledger, callback use or complete matrix PASS; new source/ELF/consumer pins and same-freeze native gates remain necessary.',
           'No author SDK probe/test was rerun or independently claimed. No new threshold, physical bound, stopping coverage or reward/task rule introduced.'],
 'argv':sys.argv,'cwd':str(Path.cwd()),'wall_seconds':time.monotonic()-started,'writers_stopped':True}
print(json.dumps(report,indent=2,allow_nan=False))
