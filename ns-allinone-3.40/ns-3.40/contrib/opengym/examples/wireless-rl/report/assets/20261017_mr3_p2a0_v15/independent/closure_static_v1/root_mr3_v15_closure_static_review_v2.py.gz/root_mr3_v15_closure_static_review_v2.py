"""Static closure verification only; no simulator or formal audit invocation."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A = W / 'report/assets/20261017_mr3_p2a0_v15'
FREEZE = '17ef3cb212aacd6e9e4fcde65783bdf2528da955'
OUT = Path('/tmp/root_mr3_v15_closure_static_review_v2.json')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    started = time.monotonic()
    inv = json.loads((A / 'inventory_native_v1.json').read_text())
    assert len(inv['files']) == 1079
    for row in inv['files']:
        data = (A / row['path']).read_bytes()
        assert len(data) == row['bytes'] and sha(data) == row['sha256'], row
    docs = [ROOT / 'AGENTS.md', W / 'AGENTS.md', W / 'IMPLEMENTATION_PLAN.md',
            W / 'RESEARCH_PLAN.md', W / 'log.md', W / 'report/20261017_mr3_p2a0_v15.md',
            W / 'report/ARCHIVE_INDEX.json', W / 'report/README.md']
    ros = ROOT / 'ros2_ws/ros2-multi-robot-automap'
    docs += [ros / name for name in ('AGENTS.md', 'user_guide.md', 'launch_commands.md')]
    log_rel = str((W / 'log.md').relative_to(ROOT))
    old_log = subprocess.check_output(['git', 'show', f'{FREEZE}:{log_rel}'], cwd=ROOT)
    assert (W / 'log.md').read_bytes().startswith(old_log)
    links = 0
    for doc in docs:
        if doc.suffix != '.md':
            continue
        for target in re.findall(r'\]\(([^)]+)\)', doc.read_text()):
            if target.startswith(('http:', 'https:', '#', 'app:', 'plugin:', '$')):
                continue
            target = target.strip('<>').split('#', 1)[0]
            if not target:
                continue
            assert (doc.parent / target).exists(), (doc, target)
            links += 1
    execution = json.loads(Path('/tmp/mr3_p2a0_v15_interface_audit_execution_v1.json').read_text())
    failures = sorted(row['label'] for row in execution['commands']
                      if row['required_success'] and not row['passed'])
    assert failures == ['fixed_physics_v1', 'full_audit', 'input_001'], failures
    assert execution['all_submitted_jobs_finished'] and not execution['runner_errors']
    cost = json.loads((A / 'accounting/native_cost_v1.json').read_text())
    assert cost['total_returned_resets'] == 1
    assert cost['total_returned_steps'] == 32
    assert cost['total_saved_api_records'] == 33
    assert cost['native_launcher_wall_seconds'] == 803.9527572728693
    subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
    dryrun = subprocess.check_output(['git', 'add', '-n', '.'], cwd=ROOT, text=True)
    drypaths = []
    for line in dryrun.splitlines():
        assert line.startswith("add '") and line.endswith("'"), line
        drypaths.append(line[5:-1])
    allowed = {str(p.relative_to(ROOT)) for p in docs}
    allowed |= {str((A / row['path']).relative_to(ROOT)) for row in inv['files']}
    allowed.add(str((A / 'inventory_native_v1.json').relative_to(ROOT)))
    assert not (set(drypaths) - allowed), sorted(set(drypaths) - allowed)
    result = dict(passed=True, freeze=FREEZE, inventory_entries=len(inv['files']),
                  inventory_sha256=sha((A / 'inventory_native_v1.json').read_bytes()),
                  formal_fail_and_skips_preserved=True, failures=failures,
                  log_original_prefix_unchanged=True, local_links_checked=links,
                  dryrun_paths=len(drypaths), dryrun_sha256=sha(dryrun.encode()),
                  allowed_document_paths=sorted(str(p.relative_to(ROOT)) for p in docs),
                  wall_seconds=time.monotonic() - started,
                  scope='Static closure docs/encoded custody only, no native/formal rerun')
    OUT.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
