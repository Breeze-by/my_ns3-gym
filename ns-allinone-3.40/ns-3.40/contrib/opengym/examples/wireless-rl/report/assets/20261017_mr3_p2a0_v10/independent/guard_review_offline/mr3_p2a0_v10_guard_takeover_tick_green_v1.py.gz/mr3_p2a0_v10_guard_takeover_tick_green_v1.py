"""Production-method CPU race: completed older zero plus newer pending zero at takeover."""
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
from geometry_msgs.msg import Twist
from std_msgs.msg import String
from multi_robot_exploration.motion_safety import MotionSafety
from multi_robot_exploration.mr3_motion_control import MotionControlPhase
from multi_robot_exploration.mr3_control_phase import canonical

ROOT = Path('/home/zhuyulab/ns3-workspace')
BASE = ROOT/'ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration'
spec = importlib.util.spec_from_file_location('actual_guard_fixtures', BASE/'test/test_motion_safety.py')
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)
node, clock, events = fixture.node_fixture()
node.completed_motion, node.issued_motion = {}, set()
node.timer = SimpleNamespace(cancel=lambda: events.append(('timer_cancelled',)))


class Publisher:
    def __init__(self):
        self.messages = []

    def publish(self, message):
        self.messages.append(json.loads(message.data))


node.create_publisher = lambda *args: Publisher()
node.create_subscription = lambda *args: None
node.create_timer = lambda *args, **kwargs: None
node.ensure_motion_output = lambda target, stop=False: MotionSafety.ensure_motion_output(node, target, stop)
phase = MotionControlPhase(node)
node.control_phase = phase
MotionSafety.tick(node)
for name in fixture.ROBOTS:
    MotionSafety.receive_actual(node, Twist(), name)
completed = dict(node.completed_motion[clock[0], 'normal']['decision_sequences'])
MotionSafety.tick(node)
latest = dict(node.decision_sequences)
assert completed == latest and not any(node.pending_outputs[name] for name in fixture.ROBOTS)
request = {'schema': 'mr3-motion-control-request-v1', 'epoch': node.epoch,
           'request_id': 'takeover' + str(clock[0]), 'target_time_ns': clock[0],
           'operation': 'takeover'}
phase.receive_request(String(data=canonical(request)))
ack = phase.publisher.messages[-1] if phase.publisher.messages else None
result = {'schema': 'mr3-p2a0-v10-takeover-pending-production-counterexample-v1',
          'clock_ns': clock[0], 'completed_older_zero_sequences': completed,
          'actual_latest_issued_zero_sequences': latest,
          'still_pending_zero_sequences': {name: [row['sequence'] for row in node.pending_outputs[name]]
                                           for name in fixture.ROBOTS},
          'actual_takeover_ack': ack,
          'second_tick_at_same_clock_did_not_issue': completed == latest,
          'takeover_ack_covers_latest_issued_target': ack is not None and ack.get('status', {}).get('decision_sequences') == latest,
          'source_bindings': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                              for p in (BASE/'multi_robot_exploration/mr3_motion_control.py',
                                        BASE/'multi_robot_exploration/motion_safety.py')},
          'native_starts': 0, 'ROS_init_or_spin': 0,
          'scope': 'exact production methods with real ROS messages/fake publishers; not a claim this ordering occurred natively'}
out=Path('/tmp/mr3_p2a0_v10_guard_takeover_tick_green_v1.json')
assert not out.exists()
out.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
