"""Closed episode raw vector/target/wheel causality; pure stdlib, no control."""
from pathlib import Path
import bisect,collections,hashlib,json,math
EP=Path("/home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261017_v12_reset/worker0/episode003_rooms_101")
OUT=Path("/tmp/mr3_p2a0_v12_reset_w0e3_body_forensics_v1.json")
def sha(path):
 h=hashlib.sha256()
 with path.open("rb")as f:
  for chunk in iter(lambda:f.read(1024*1024),b""):h.update(chunk)
 return h.hexdigest()
def rows(name):
 with (EP/name).open()as f:
  for line in f:
   if line.strip():yield json.loads(line)
meta=json.loads((EP/"metadata.json").read_text());trans=list(rows("transitions.jsonl"));release=trans[0]["info"]["release_time_ns"];physics=list(rows("physics.jsonl"));end=physics[-1]["end_time_ns"]
names=["metadata.json","transitions.jsonl","physics.jsonl","motion_safety.jsonl","adapter.jsonl",*['drive_'+n+'.jsonl'for n in ('tb1','tb2','tb3')],meta['epoch']+'.json']
inputs={n:{"path":str(EP/n),"sha256":sha(EP/n)}for n in names}
samples={n:{}for n in ('tb1','tb2','tb3')};decisions={n:[]for n in samples};errors=[]
for r in rows("motion_safety.jsonl"):
 p=r.get("payload",{});kind=r['kind'];n=p.get('robot')
 if kind in ('settled_turn_model_failure','control_failure','invalid_received_states','clock_changed_during_decision'):errors.append(r)
 if kind=='own_odom'and n in samples:
  m=p['message'];stamp=m['header']['stamp'];t=stamp['sec']*10**9+stamp['nanosec']
  if not release<=t<=end:continue
  tw=m['twist']['twist'];q=m['pose']['pose']['orientation'];pos=m['pose']['pose']['position'];vx,vy=tw['linear']['x'],tw['linear']['y'];yaw=math.atan2(2*(q['w']*q['z']+q['x']*q['y']),1-2*(q['y']**2+q['z']**2))
  s={'source_ns':t,'body_vx':vx,'body_vy':vy,'world_vx_from_yaw':math.cos(yaw)*vx-math.sin(yaw)*vy,'world_vy_from_yaw':math.sin(yaw)*vx+math.cos(yaw)*vy,'planar_norm':math.hypot(vx,vy),'wz':tw['angular']['z'],'angular_norm':math.sqrt(sum(tw['angular'][k]**2for k in ('x','y','z'))),'position_xy':[pos['x'],pos['y']],'yaw':yaw,'original':r}
  if t in samples[n]:
   if json.dumps(samples[n][t]['original']['payload']['message'],sort_keys=True)!=json.dumps(m,sort_keys=True):errors.append({'kind':'duplicate_source_conflict','robot':n,'source_ns':t})
  else:samples[n][t]=s
 elif kind=='decision'and n in decisions and release<=p['clock_ns']<=end:
  decisions[n].append(r)
profile={};peak_records={}
for n,by_stamp in samples.items():
 values=[by_stamp[t]for t in sorted(by_stamp)];peak=max(values,key=lambda s:s['planar_norm']);peak_records[n]=peak
 acc=[]
 for a,b in zip(values,values[1:]):
  dt=(b['source_ns']-a['source_ns'])/1e9
  acc.append({'from_ns':a['source_ns'],'to_ns':b['source_ns'],'dt_sec':dt,'abs_wz_acceleration':abs(b['wz']-a['wz'])/dt,'position_chord_speed':math.dist(b['position_xy'],a['position_xy'])/dt,'world_planar_velocity_change_rate':math.hypot(b['world_vx_from_yaw']-a['world_vx_from_yaw'],b['world_vy_from_yaw']-a['world_vy_from_yaw'])/dt})
 over=[s for s in values if s['planar_norm']>.30]
 drivers=list(rows('drive_'+n+'.jsonl'));act=[r for r in drivers if r['kind']=='actuation'and release<=r['sim_time_ns']<=end];cmd=[r for r in drivers if r['kind']=='command_received'and release<=r['sim_time_ns']<=end]
 max_formula_error=0.;max_per_rim_excess=0.
 for r in act:
  maximum=max(abs(d-c)for d,c in zip(r['desired_rim_mps'],r['current_rim_mps']));alpha=min(1.,r['max_acceleration_mps2']*r['dt_sec']/maximum)if maximum else 1.
  max_formula_error=max(max_formula_error,abs(r['alpha']-alpha),*(abs(a-(c+alpha*(d-c)))for a,c,d in zip(r['applied_rim_mps'],r['current_rim_mps'],r['desired_rim_mps'])))
  max_per_rim_excess=max(max_per_rim_excess,*(abs(a-c)-r['max_acceleration_mps2']*r['dt_sec']for a,c in zip(r['applied_rim_mps'],r['current_rim_mps'])))
 profile[n]={'samples':len(values),'peak':peak,'maximum_abs_body_vx':max(abs(s['body_vx'])for s in values),'maximum_abs_body_vy':max(abs(s['body_vy'])for s in values),'maximum_angular_norm':max(s['angular_norm']for s in values),'maximum_abs_wz_sampled_acceleration':max(acc,key=lambda a:a['abs_wz_acceleration']),'maximum_position_chord_speed':max(acc,key=lambda a:a['position_chord_speed']),'over_0_30_sample_count':len(over),'over_0_30_samples':over,'maximum_native_desired_abs_v':max(abs(r['desired_v'])for r in cmd),'maximum_native_desired_abs_w':max(abs(r['desired_w'])for r in cmd),'maximum_native_actuation_desired_abs_v':max(abs(r['desired_v'])for r in act),'maximum_native_actuation_desired_abs_w':max(abs(r['desired_w'])for r in act),'maximum_coupled_formula_error':max_formula_error,'maximum_per_rim_delta_excess':max_per_rim_excess,'maximum_current_joint_rim_abs_speed':max(abs(v)for r in act for v in r['current_rim_mps'])}
 t=peak['source_ns'];lo=t-1_000_000_000;hi=t+1_000_000_000
 profile[n]['peak_neighborhood']={'raw_own_odom':[s for s in values if lo<=s['source_ns']<=hi],'actual_guard_decisions':[r for r in decisions[n]if lo<=r['payload']['clock_ns']<=hi],'native_actuation':[r for r in act if lo<=r['sim_time_ns']<=hi],'native_command_received':[r for r in cmd if lo<=r['sim_time_ns']<=hi],'adjacent_differences':[a for a in acc if lo<=a['to_ns']<=hi]}
evaluator=json.loads((EP/(meta['epoch']+'.json')).read_text());safety=[]
for r in rows('adapter.jsonl'):
 if r['kind']in ('safety_stop','task_stopped'):safety.append(r)
assert all(sha(Path(v['path']))==v['sha256']for v in inputs.values())
report={'schema':'mr3-actual-body-forensics-v1','freeze':meta['freeze'],'epoch':meta['epoch'],'release_ns':release,'final_physics_end_ns':end,'inputs':inputs,'inputs_unchanged':True,'robots':profile,'actual_failures':errors,'adapter_safety_events':safety,'evaluator_recorded':{k:evaluator.get(k)for k in ['termination_reason','control_failure','collision_events','collision_monitoring_active','collision_monitoring_fresh','contact_clock_overflow_diagnostic','contact_monitor_summary','peer_safety_failure']},'scope':['Pure read-only actual raw local odometry/commands/native wheel-feedback analysis; no production import, control, simulation or formal acceptance.','A zero recorded contact count is not proof of no external force/contact.','Full planar norm is rotation-invariant. Comparing wheel-mean speed with body lateral velocity diagnoses sampled nonholonomic discrepancy; does not prove mechanical cause.','Position chord speed/adjacent source angular acceleration are sampled necessary observations, not continuous bounds.']}
with OUT.open('x')as f:json.dump(report,f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps({'output':str(OUT),'robots':{n:{'peak_source_ns':v['peak']['source_ns'],'peak_task_sec':(v['peak']['source_ns']-release)/1e9,'peak_norm':v['peak']['planar_norm'],'peak_vx':v['peak']['body_vx'],'peak_vy':v['peak']['body_vy'],'peak_wz':v['peak']['wz'],'over_count':v['over_0_30_sample_count'],'maximum_angular_norm':v['maximum_angular_norm'],'maximum_wz_acceleration':v['maximum_abs_wz_sampled_acceleration']['abs_wz_acceleration'],'maximum_chord_speed':v['maximum_position_chord_speed']['position_chord_speed'],'desired_v_bound':v['maximum_native_desired_abs_v'],'desired_w_bound':v['maximum_native_desired_abs_w'],'coupled_formula_error':v['maximum_coupled_formula_error'],'rim_delta_excess':v['maximum_per_rim_delta_excess']}for n,v in profile.items()},'evaluator':{k:evaluator.get(k)for k in ['termination_reason','control_failure','collision_events','collision_monitoring_fresh']},'errors':errors}))
