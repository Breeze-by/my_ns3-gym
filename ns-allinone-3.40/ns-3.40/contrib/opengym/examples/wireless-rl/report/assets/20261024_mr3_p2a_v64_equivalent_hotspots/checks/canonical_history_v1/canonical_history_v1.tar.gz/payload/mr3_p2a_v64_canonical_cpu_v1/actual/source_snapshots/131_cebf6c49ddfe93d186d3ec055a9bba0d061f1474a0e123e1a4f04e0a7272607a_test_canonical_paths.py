from pathlib import Path
import hashlib
from multi_robot_exploration import mr3_reach_runtime,motion_safety

def test_actual_canonical_loaded_sources():
    expected={"mr3_reach_runtime.py":"576c235901a51223f1d2723757f60c490045ba897d445d5c6fb3c739512a466b","motion_safety.py":"b1aaa465f6fe1c940674b97f347d14840f79d04a3d233be6f143fb06fbbb6b1e"}
    for module in [mr3_reach_runtime,motion_safety]:
        source=Path(module.__file__).resolve()
        assert source.parent == Path('/home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/multi_robot_exploration')
        assert hashlib.sha256(source.read_bytes()).hexdigest()==expected[source.name]
