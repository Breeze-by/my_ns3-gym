#include <gazebo/ode/ode.h>
#include <nlohmann/json.hpp>
#include <dlfcn.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <iostream>
#include <limits>
#include <string>
#include <vector>

using Json = nlohmann::json;

struct Oracle
{
  bool hit;
  long double depth;
};

// Analytic oriented-box slab check, here an identity box. Zero means exact
// zero, so an outside nearly-parallel axis can never silently disappear.
Oracle ExactSlabs(const dVector3 origin, const dVector3 direction,
  const dVector3 lengths, const dReal maxLength)
{
  long double lo = -std::numeric_limits<long double>::infinity();
  long double hi = std::numeric_limits<long double>::infinity();
  for (int axis = 0; axis < 3; ++axis)
  {
    const long double s = origin[axis];
    const long double v = direction[axis];
    const long double h = static_cast<long double>(lengths[axis]) / 2;
    if (v == 0)
    {
      if (s < -h || s > h)
        return {false, 0};
      continue;
    }
    long double a = (-h - s) / v;
    long double b = (h - s) / v;
    if (a > b)
      std::swap(a, b);
    lo = std::max(lo, a);
    hi = std::min(hi, b);
    if (lo > hi)
      return {false, 0};
  }
  const long double depth = lo >= 0 ? lo : hi;
  return {depth >= 0 && depth <= maxLength, depth};
}

int main()
{
  if (dInitODE2(0) == 0 || dAllocateODEDataForThread(dAllocateMaskAll) == 0)
    return 2;
  dGeomID box = dCreateBox(nullptr, .265, .265, .089);
  dGeomID ray = dCreateRay(nullptr, 9.88);
  dGeomSetPosition(box, 0, 0, 0);
  const dQuaternion identity = {1, 0, 0, 0};
  dGeomSetQuaternion(box, identity);
  dVector3 lengths;
  dGeomBoxGetLengths(box, lengths);
  struct Case { const char *name; double z; double dz; };
  const std::vector<Case> cases = {
    {"above_exact_parallel", .073, 0},
    {"above_tiny_negative_1e12", .073, -1e-12},
    {"above_tiny_negative_1e9", .073, -1e-9},
    {"above_tiny_negative_1e7", .073, -1e-7},
    {"above_negative_within_epsilon", .073, -.999e-6},
    {"above_negative_at_epsilon_input", .073, -1e-6},
    {"above_negative_beyond_epsilon", .073, -1.01e-6},
    {"above_negative_1e5", .073, -1e-5},
    {"above_tiny_positive", .073, 1e-9},
    {"below_exact_parallel", -.073, 0},
    {"below_tiny_positive", -.073, 1e-9},
    {"below_tiny_negative", -.073, -1e-9},
    {"valid_inside_exit_parallel", 0, 0},
    {"valid_inside_exit_nearparallel", 0, -1e-9},
    {"valid_top_boundary_exit", lengths[2] / 2, 0}
  };
  Json rows = Json::array();
  unsigned int falsePositives = 0;
  bool controls = true;
  for (const auto &test : cases)
  {
    dGeomRaySet(ray, 0, -.12, test.z, 0, -1, test.dz);
    dGeomRaySetLength(ray, 9.88);
    dVector3 start, direction;
    dGeomRayGet(ray, start, direction);
    dContactGeom contact{};
    const int count = dCollide(ray, box, 1, &contact, sizeof(contact));
    const auto reference = ExactSlabs(start, direction, lengths,
      dGeomRayGetLength(ray));
    const bool actual = count > 0;
    const bool falsePositive = actual && !reference.hit;
    falsePositives += falsePositive;
    if (!falsePositive)
      controls = controls && actual == reference.hit;
    Json row = {{"name", test.name}, {"input_dz", test.dz},
      {"origin", {start[0], start[1], start[2]}},
      {"native_normalized_direction", {direction[0], direction[1], direction[2]}},
      {"native_ray_body_null", dGeomGetBody(ray) == nullptr},
      {"original_ode_contact_count", count}, {"analytic_slab_hit", reference.hit},
      {"false_positive", falsePositive}};
    if (actual)
    {
      row["original_depth"] = contact.depth;
      row["original_contact_position"] = {contact.pos[0], contact.pos[1], contact.pos[2]};
      row["original_contact_normal"] = {contact.normal[0], contact.normal[1], contact.normal[2]};
      row["contact_g1_is_ray"] = contact.g1 == ray;
      row["contact_g2_is_box"] = contact.g2 == box;
    }
    rows.push_back(row);
  }
  Dl_info collInfo{}, overrideInfo{};
  const bool collLoaded = dladdr(reinterpret_cast<const void *>(&dCollide), &collInfo) != 0;
  const bool overrideLoaded = dladdr(reinterpret_cast<const void *>(&dSetColliderOverride), &overrideInfo) != 0;
  Json out = {{"schema", "mr3-v22-ray-box-cpu-reproduction-v1"},
    {"scope", "Pure CPU synthetic ODE collision library calls; no Gazebo server/world, stepping, ROS, DDS, native research run or current-ray trace reads."},
    {"box_lengths", {lengths[0], lengths[1], lengths[2]}},
    {"max_ray_length", dGeomRayGetLength(ray)},
    {"sizeof_dReal", sizeof(dReal)}, {"false_positive_cases", falsePositives},
    {"other_case_classifications_agree", controls},
    {"defect_reproduced", falsePositives > 0 && controls},
    {"actual_dCollide_library", collLoaded ? collInfo.dli_fname : "unavailable"},
    {"actual_dSetColliderOverride_library", overrideLoaded ? overrideInfo.dli_fname : "unavailable"},
    {"cases", rows}, {"physical_or_original_cast_rootcause_credit", false}};
  std::cout << out.dump(2) << '\n';
  dGeomDestroy(ray);
  dGeomDestroy(box);
  dCloseODE();
  return falsePositives > 0 && controls ? 0 : 1;
}
