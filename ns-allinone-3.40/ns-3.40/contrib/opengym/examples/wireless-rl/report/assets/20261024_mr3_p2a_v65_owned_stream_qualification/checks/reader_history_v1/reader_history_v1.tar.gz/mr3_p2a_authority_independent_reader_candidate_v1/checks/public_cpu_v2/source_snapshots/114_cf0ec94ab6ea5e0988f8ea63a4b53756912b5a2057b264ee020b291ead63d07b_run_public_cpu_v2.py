import hashlib,json,os
from pathlib import Path
import subprocess

ROOT=Path('/home/zhuyulab/ns3-workspace')
W=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A=Path(__file__).resolve().parent
S=A/'shadow'/W.relative_to(ROOT)/'mr3_learning'
PY='/home/zhuyulab/miniconda3/envs/ns3gym/bin/python'

def main():
    out=A/'checks/public_cpu_v2';out.mkdir(parents=True,exist_ok=False)
    sources=sorted(set([*S.rglob('*.py'),A/'conftest.py',Path(__file__),
        *(W/'mr3_learning').glob('*.py'),
        *(ROOT/'ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/multi_robot_exploration').glob('*.py'),
        *(ROOT/'ros2_ws/ros2-multi-robot-automap/scripts').glob('*.py'),Path(PY).resolve()]))
    snapshots=out/'source_snapshots';snapshots.mkdir();bindings=[]
    for ordinal,path in enumerate(sources):
        raw=path.read_bytes();sha=hashlib.sha256(raw).hexdigest();snapshot=snapshots/(f'{ordinal:03d}_{sha}_{path.name}')
        snapshot.open('xb').write(raw)
        bindings.append(dict(path=str(path),bytes=len(raw),sha256=sha,snapshot=str(snapshot)))
    tests=[str(S/'tests/test_motion_authority_audit.py'),str(S/'tests/test_authority_public_reader_wiring.py')]
    command=[PY,'-B','-m','pytest','-q','-p','no:cacheprovider','--rootdir='+str(A),*tests,'--junitxml='+str(out/'pytest.xml')]
    (out/'source_recovery_v1.json').open('x').write(json.dumps(dict(
        schema='mr3-authority-reader-private-public-route-cpu-source-v1',base_HEAD=subprocess.check_output(
            ['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),sources=bindings,pytest_argv=command,
        private_overlay=True,canonical_installed_credit=False),indent=2)+'\n')
    argv=[PY,'-B','-m','mr3_learning.reach_execution','--scope','cpu','--output',str(out/'actual')]
    for path in sources:argv.extend(['--source',str(path)])
    env=dict(os.environ,PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONPATH',None)
    return subprocess.call([*argv,'--',*command],cwd=W,env=env)

if __name__=='__main__':raise SystemExit(main())
