"""Archive one sealed V21 posthoc without rerunning its analysis."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
SOURCE = Path('/tmp/mr3_p2a0_v21_posthoc_ray_v1')
TARGET = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v21_ray/closed_posthoc_v1'
assert not TARGET.exists()
started = time.monotonic()
handoff = SOURCE/'handoff_v1.json'
assert hashlib.sha256(handoff.read_bytes()).hexdigest() == '2bc8301ca08d09a66ae144184bb53191f423f8e0f83b0ebec096253f47bea8ea'
d = json.loads(handoff.read_text())
assert d['writers_stopped'] and d['full_posthoc_exit'] == 0
manifest = SOURCE/'manifest_v1.json'
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == '5ffe403e77201a4e3f1150103ab8bc452ca5e3936bfbaacc02620e315fe7c66c'
m = json.loads(manifest.read_text())
assert m['writers_stopped'] and m['count'] == 14 and m['raw_bytes'] == 86123005
files = []
for row in m['files']:
    p = Path(row['source'])
    assert p.is_relative_to(SOURCE) and p.stat().st_size == row['bytes']
    assert hashlib.sha256(p.read_bytes()).hexdigest() == row['sha256']
    files.append(p)
files.extend((manifest, Path(__file__)))
files = sorted(set(files))
entries = []
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for path in files:
        before = path.stat()
        raw = path.read_bytes()
        name = str(path.relative_to('/tmp'))
        info = tarfile.TarInfo(name)
        info.size, info.mtime, info.mode = len(raw), 0, 0o644
        archive.addfile(info, io.BytesIO(raw))
        entries.append({'source': str(path), 'member': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                        'stat': [before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns]})
encoded = gzip.compress(buffer.getvalue(), compresslevel=6, mtime=0)
assert len(encoded) < 100000000
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(encoded))) as archive:
    assert archive.getnames() == [row['member'] for row in entries]
    for row in entries:
        raw = archive.extractfile(row['member']).read()
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
        p = Path(row['source']); after = p.stat()
        assert [after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns] == row['stat']
        assert hashlib.sha256(p.read_bytes()).hexdigest() == row['sha256']
TARGET.mkdir()
(TARGET/'originals.tar.gz').write_bytes(encoded)
(TARGET/'handoff_v1.json').write_bytes(handoff.read_bytes())
result = {'schema':'mr3-v21-posthoc-canonical-custody-v1', 'freeze':d['freeze'],
          'scope':'One original posthoc and its exact sources/results; no gate or native replay.',
          'archive':'originals.tar.gz', 'archive_bytes':len(encoded), 'archive_sha256':hashlib.sha256(encoded).hexdigest(),
          'original_count':len(entries), 'original_bytes':sum(x['bytes'] for x in entries), 'files':entries,
          'full_roundtrip_and_source_final_sha_stat_verified':True, 'wall_seconds':time.monotonic()-started}
(TARGET/'manifest_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('original_count','original_bytes','archive_bytes','archive_sha256','wall_seconds')}))
