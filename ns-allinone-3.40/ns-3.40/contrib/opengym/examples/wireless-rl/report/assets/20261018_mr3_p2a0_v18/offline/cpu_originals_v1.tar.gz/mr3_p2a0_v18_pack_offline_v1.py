"""Seal stopped CPU proposals/checks and all failed originals, before native work."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
DEST = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v18/offline'
TMP = Path('/tmp')
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def main():
    started = time.monotonic()
    candidates = set()
    for selected in [*TMP.glob('mr3_p2a0_v18*'),
                     *TMP.glob('mr3_independent_stop_observer_v1*')]:
        if selected.name.endswith(('root_continuation_state_v1.json', '.lock')):
            continue
        if selected.is_file():
            candidates.add(selected)
        elif selected.is_dir():
            candidates.update(path for path in selected.rglob('*') if path.is_file()
                              and '__pycache__' not in path.parts and not path.is_symlink())
    assert candidates, 'no stopped source/check artifacts'
    manifest = []
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w', format=tarfile.PAX_FORMAT) as archive:
        for path in sorted(candidates):
            before = path.stat()
            raw = path.read_bytes()
            after = path.stat()
            assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (
                after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), str(path)
            assert len(raw) == before.st_size
            member = str(path.relative_to(TMP))
            info = tarfile.TarInfo(member)
            info.size = len(raw)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(raw))
            manifest.append({'source': str(path), 'member': member, 'sha256': sha(raw), 'bytes': len(raw),
                             'stat_identity': [before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns]})
    tar_raw = buffer.getvalue()
    encoded = gzip.compress(tar_raw, mtime=0)
    assert gzip.decompress(encoded) == tar_raw
    with tarfile.open(fileobj=io.BytesIO(tar_raw)) as archive:
        assert len(archive.getmembers()) == len(manifest)
        for item in manifest:
            assert sha(archive.extractfile(item['member']).read()) == item['sha256']
            actual = Path(item['source'])
            assert sha(actual.read_bytes()) == item['sha256'], 'source changed before seal'
    blob = DEST / 'cpu_originals_v1.tar.gz'
    with blob.open('xb') as stream:
        stream.write(encoded)
    value = {'schema': 'mr3-stopped-offline-originals-v1', 'passed': True,
        'entries': manifest, 'entry_count': len(manifest), 'raw_bytes': sum(item['bytes'] for item in manifest),
        'archive_path': str(blob.relative_to(ROOT)), 'encoded_sha256': sha(encoded),
        'encoded_bytes': len(encoded), 'tar_sha256': sha(tar_raw), 'tar_bytes': len(tar_raw),
        'all_originals_rechecked': True, 'wall_seconds': time.monotonic() - started,
        'helper_source_sha256': sha(Path(__file__).read_bytes()),
        'scope': 'Stopped pre-native CPU/code/review originals including failures; no native/PPO/matrix credit. '
                 'Mutable root continuation state and caches excluded. Future native evidence is separate.'}
    with (DEST / 'cpu_originals_manifest_v1.json').open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')
    print(json.dumps({key: value[key] for key in ('passed', 'entry_count', 'raw_bytes', 'encoded_bytes', 'wall_seconds')}))


if __name__ == '__main__':
    main()
