"""Private fixture lookup; final tests still import actual production modules."""
from pathlib import Path
import sys

ROOT=Path('/home/zhuyulab/ns3-workspace')
W=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
sys.path.insert(0,str(W))
import mr3_learning.tests
C=Path(__file__).resolve().parent/'candidate'/W.relative_to(ROOT)/'mr3_learning/tests'
mr3_learning.tests.__path__.insert(0,str(C))
