"""Record prospective integration CPU checks and actual unchanged source bytes."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
DRAFT = Path('/tmp/mr3_p2a0_v19_root_draft_v1')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    originals = {str(path): sha(path.read_bytes()) for path in DRAFT.iterdir() if path.is_file()}
    env = dict(os.environ, PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1')
    commands = [
        ['rtk', 'proxy', '/usr/bin/python3', '-B', str(HERE / 'witness_executable_tests_v1.py')],
        ['rtk', 'proxy', '/usr/bin/python3', '-B', str(HERE / 'preflight_runner_tests_v1.py')],
        ['rtk', 'proxy', '/usr/bin/python3', '-B', str(HERE / 'runner_checks_v1.py')],
        ['rtk', 'proxy', '/usr/bin/python3', '-B', '-m', 'flake8', '--select=E9,F63,F7,F82',
         str(HERE / 'proposed_preflight_v1.py'), str(HERE / 'preflight_runner_tests_v1.py'),
         str(HERE / 'runner_v19_draft_snapshot.py'), str(HERE / 'witness_executable_tests_v1.py')],
    ]
    started = time.monotonic()
    records = []
    for index, argv in enumerate(commands):
        wall = time.monotonic()
        utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
        result = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True)
        path = HERE / f'checks_{index:02d}.log'
        with path.open('xb') as stream:
            stream.write(result.stdout)
            stream.write(result.stderr)
        records.append({'argv': argv, 'cwd': str(ROOT),
                        'environment_overrides': {'PYTHONNOUSERSITE': '1',
                                                  'PYTHONDONTWRITEBYTECODE': '1'},
                        'started_utc': utc, 'exit_code': result.returncode,
                        'wall_seconds': time.monotonic() - wall,
                        'stdout_stderr_path': str(path), 'stdout_stderr_sha256': sha(path.read_bytes())})
        if result.returncode:
            break
    old_proof_path = Path('/tmp/mr3_p2a0_v18_source_preflight.json')
    old_raw = old_proof_path.read_bytes()
    old = json.loads(old_raw)
    source_changes = []
    for path, binding in old['source_bindings'].items():
        actual = sha((ROOT / path).read_bytes())
        if actual != binding['sha256']:
            source_changes.append({'path': path, 'expected': binding['sha256'], 'actual': actual})
    old_plan = json.loads((ROOT / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/'
                                  'wireless-rl/report/assets/20261018_mr3_p2a0_v18/'
                                  'predeclared_plan_v18.json')).read_bytes())
    independent_changes = []
    for binding in old_plan['independent_source_bindings']:
        actual = sha((ROOT / binding['path']).read_bytes())
        if actual != binding['sha256']:
            independent_changes.append({'path': binding['path'], 'expected': binding['sha256'],
                                        'actual': actual})
    plan = json.loads((HERE / 'plan_v19_draft_snapshot.json').read_bytes())
    libraries = []
    for key, binding in plan['diagnostic_libraries'].items():
        source = sha((ROOT / binding['source_path']).read_bytes())
        actual = sha(Path(binding['library_path']).read_bytes())
        installed = sha(Path(binding['installed_path']).read_bytes())
        libraries.append({'library': key, 'source_sha256': source, 'actual_sha256': actual,
                          'installed_sha256': installed,
                          'passed': source == binding['source_sha256']
                          and actual == installed == binding['library_sha256']})
    driver = plan['original_driver']
    driver_sha = sha(Path(driver['installed_path']).read_bytes())
    after = {str(path): sha(path.read_bytes()) for path in DRAFT.iterdir() if path.is_file()}
    passed = (len(records) == len(commands) and all(row['exit_code'] == 0 for row in records)
              and not source_changes and not independent_changes
              and all(row['passed'] for row in libraries)
              and driver_sha == driver['library_sha256'] and originals == after)
    receipt = {'schema': 'mr3-v19-prospective-preflight-integration-checks-v1',
               'passed': passed, 'commands': records, 'wall_seconds': time.monotonic() - started,
               'old_preflight': {'path': str(old_proof_path), 'sha256': sha(old_raw),
                                 'freeze': old['freeze']},
               'actual_old_runtime_sources': len(old['source_bindings']), 'source_changes': source_changes,
               'actual_old_independent_sources': len(old_plan['independent_source_bindings']),
               'independent_changes': independent_changes,
               'diagnostic_libraries': libraries, 'original_driver_sha256': driver_sha,
               'root_draft_source_before': originals, 'root_draft_source_after': after,
               'root_draft_unchanged': originals == after,
               'plan_admission': False,
               'known_draft_pending': ['new versioned tool bindings not appended yet',
                                       'both new stage configuration_binding hashes not finalized yet',
                                       'clean pushed new source freeze and actual preflight not yet run'],
               'scope': '20 CPU methods: actual executable 8, integration/static 8, actual CPU subprocess 4; '
                        'integration isolates future Git bytes only, not a new source/native admission',
               'native_calls': 0, 'formal_audits': 0}
    with (HERE / 'checks_v1.json').open('x') as stream:
        json.dump(receipt, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'passed': passed, 'wall_seconds': receipt['wall_seconds'],
                      'runtime_sources': receipt['actual_old_runtime_sources'],
                      'independent_sources': receipt['actual_old_independent_sources'],
                      'source_changes': source_changes, 'independent_changes': independent_changes,
                      'root_draft_unchanged': originals == after}))
    raise SystemExit(0 if passed else 1)


if __name__ == '__main__':
    main()
