from pathlib import Path
import hashlib
import json
import time
ROOT=Path('/home/zhuyulab/ns3-workspace')
P=ROOT/'ros2_ws/ros2-multi-robot-automap'
W=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
paths=[P/'scripts/mr3_env_worker.py',P/'src/multi_robot_exploration/multi_robot_exploration/peer_obstacles.py',P/'src/multi_robot_exploration/multi_robot_exploration/mr3_information.py',P/'src/multi_robot_exploration/multi_robot_exploration/mr3_motion_control.py',P/'src/multi_robot_exploration/multi_robot_exploration/mr3_control_phase.py',W/'report/assets/20261017_mr3_p2a0_v10/independent/mr3_independent_control_phase_v1.py']
ep=next((P/'log/mr3_p2a0/mr3_p2a0_20261017_v10_interface').glob('worker*/episode*'))
inputs={}
def readrows(name):
 p=ep/name;raw=p.read_bytes();inputs[name]={'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'partial_ongoing_file':not(ep/'supervisor_shutdown.json').exists()}
 rows=[]
 for i,s in enumerate(raw.splitlines(),1):
  try:rows.append((i,json.loads(s)))
  except json.JSONDecodeError:continue
 return rows
worker=readrows('control_phase_worker.jsonl');peer=readrows('peer_phase.jsonl');physics=readrows('physics.jsonl')
request=next((i,r)for i,r in worker if r['kind']=='request'and r['component']=='peer')
abort=next((i,r)for i,r in worker if r['kind']=='infrastructure_abort_started')
ack=next((i,r)for i,r in peer if r['kind']=='ack_published')
warn=[]
for name in ('worker.log','launch.log'):
 p=ep/name;raw=p.read_bytes();inputs[name]={'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
 for i,line in enumerate(raw.decode(errors='replace').splitlines(),1):
  if 'incompatible' in line and ('peer_phase_ack' in line or 'DURABILITY' in line):warn.append({'file':name,'line':i,'text':line})
result={'schema':'mr3-v10-readonly-protocol-interface-review-v1','freeze':'631d8c35c43fdb7ed45e984376543e55395066ef','wall_monotonic_ns':time.monotonic_ns(),'git_writes':0,'native_starts':0,
 'scope':'Final source and actual first interface startup records; no formal episode or task credit',
 'source_bindings':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths},'inputs':inputs,
 'blocking_finding':{'name':'Peer ACK offered VOLATILE against worker requested TRANSIENT_LOCAL','status':'native-confirmed',
  'producer_source':'peer_obstacles.py:207 create_publisher(String, /mr3/peer_phase_ack, 10)',
  'consumer_source':'mr3_env_worker.py:140 qos=TRANSIENT_LOCAL; :277-279 all control ACK subscriptions use qos',
  'native_middleware_warnings':warn,'worker_peer_request':{'line':request[0],'row':request[1]},'actual_peer_ack_publication':{'line':ack[0],'row':ack[1]},
  'actual_worker_peer_ack_receipts':sum(r['kind']=='ack_received'and r.get('component')=='peer'for _,r in worker),
  'wall_wait_to_infrastructure_abort_sec':(abort[1]['wall_monotonic_ns']-request[1]['wall_monotonic_ns'])/1e9,
  'actual_abort':{'line':abort[0],'row':abort[1]},
  'conclusion':'Successful peer takeover ACK call was incompatible with worker reader; no bootstrap/first normal chain/reset credit. Subsequent strict-zero stop is cleanup only.',
  'ownership':'Peer publisher QoS pairing was missed in the earlier review; no same-freeze edits made.'},
 'other_checked_interfaces':[
  {'interface':'bootstrap_zero','source_compatible':True,'notes':'Current worker records explicit bootstrap_zero and real takeover control_request_id; reader requires unique pre-release20 ticks and actual3stored zero. This run never reached it.'},
  {'interface':'normal chain refs','source_compatible':True,'notes':'Info full stateACK, peer state_commit, guard peer_commit/state_commit, actual publish-start windows and local receipt status names agree. No native normal commit reached.'},
  {'interface':'stop category','source_compatible':True,'notes':'phase_kind=stop strictthreezero readyFalse separate from immutable normal status, origin stop_topic/control_ack and duplicate fields agree. Root complete driver/full gates still required.'},
  {'interface':'terminal cancelled oldhubclock','source_compatible':True,'notes':'Reader narrow actual-prior-notice + explicit terminal scope permits0<=clock<=target only for state_phase_task_terminal; successful ACK stays exact.'}],
 'known_reader_coverage_limit':{'standalone_control_reader_misses_sticky_negative_callback_when_old_request_abandoned':True,'counterexample':'/tmp/mr3_p2a0_v10_reader_sticky_negative_review_v1.json','scope':'Overall mandatory full native audit and actual worker still reject. No frozen reader changed and no successful whole-stage credit inferred.'},
 'limits':['This is not a full matrix audit. Original formal consumers must run on closed original artifacts and preserve real failures.','No dynamics, braking, angular coverage, activity or95% credit from startup zero/cleanup.','Source-side stop whose DDS notification is in flight remains diagnostic; actual processed-worker stop prefix and original20ms/160ms/body gates stay mandatory.']}
out=Path('/tmp/mr3_p2a0_v10_protocol_readonly_review_v1.json');out.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps({'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'native_qos_mismatch':bool(warn),'actual_peer_ack_calls':1,'worker_peer_receipts':result['blocking_finding']['actual_worker_peer_ack_receipts'],'wall_wait':result['blocking_finding']['wall_wait_to_infrastructure_abort_sec']}))
