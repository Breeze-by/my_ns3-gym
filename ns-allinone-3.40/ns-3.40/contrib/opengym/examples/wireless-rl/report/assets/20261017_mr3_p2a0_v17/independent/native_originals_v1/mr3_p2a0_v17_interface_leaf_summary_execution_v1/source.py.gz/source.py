"""Summarize finished original V17 leaves only; never launch an audit or raw scan."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

FREEZE = 'eee6b2f90f697b28a1c20a2af5d1a6d2f044465e'
PREFIX = Path('/tmp/mr3_p2a0_v17_interface')
RUN = Path('/home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/'
           'mr3_p2a0_20261017_v17_interface')
LEAVES = ('fixed_physics_v1', 'fixed_angular_v1', 'full_audit', 'input_review_v1',
          'closure_binary_review_v1')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def summarize(aggregate_path):
    bindings = {}

    def read(path):
        path = Path(path)
        if path.stat().st_size > 16 * 1024 * 1024:
            raise ValueError('diagnostic refuses a large input; use formal receipt only: ' + str(path))
        raw = path.read_bytes()
        bindings[str(path)] = {'bytes': len(raw), 'sha256': sha(raw)}
        return raw

    # This completion check MUST precede every leaf or transitions read.
    aggregate = json.loads(read(aggregate_path))
    if (aggregate.get('all_submitted_jobs_finished') is not True
            or aggregate.get('schema') != 'mr3-p2a0-audit-execution-v17'
            or aggregate.get('stage') != 'interface' or aggregate.get('freeze') != FREEZE
            or type(aggregate.get('passed')) is not bool):
        raise ValueError('refuse: original interface aggregate is incomplete or identity differs')
    receipts = {row['path']: row for row in aggregate['receipts']}
    if len(receipts) != len(aggregate['receipts']):
        raise ValueError('duplicate original aggregate receipt path')
    failed = {row['path'] for row in aggregate['receipts'] if row.get('passed') is not True}
    failed.update(row['output'] for row in aggregate['commands']
                  if row.get('required_success') is True and row.get('passed') is not True)
    leaves, availability = {}, {}
    for name in LEAVES:
        path = Path(str(PREFIX) + '_' + name + '.json')
        if str(path) not in receipts:
            availability[name] = {'path': str(path), 'error': 'not listed in original aggregate'}
            continue
        if not path.is_file():
            availability[name] = {'path': str(path), 'error': 'original leaf missing'}
            continue
        raw = read(path)
        if sha(raw) != receipts[str(path)]['sha256']:
            raise ValueError('leaf differs from completed aggregate SHA: ' + str(path))
        value = json.loads(raw)
        if type(value.get('passed')) is not bool:
            raise ValueError('leaf passed is not a typed bool: ' + str(path))
        if 'freeze' in value and value['freeze'] != FREEZE:
            raise ValueError('leaf source freeze differs: ' + str(path))
        leaves[name] = value
        availability[name] = {**bindings[str(path)], 'path': str(path), 'passed': value['passed']}

    physical, angular = leaves.get('fixed_physics_v1'), leaves.get('fixed_angular_v1')
    physical_rows, activity, reasons = {}, [], []
    closure = None
    if physical is not None:
        if physical['script_sha256'] != '2516e394f60eac5dd24fd66b51c4c48fc37245090eb1626ebe1c7a3a23f8bafb':
            raise ValueError('physical leaf is not the immutable original consumer')
        if len(physical['episodes']) != 1:
            raise ValueError('interface physical leaf is not exactly one episode')
        episode = physical['episodes'][0]
        directory = Path(episode['directory'])
        if directory.parent.parent != RUN:
            raise ValueError('original physical episode is outside this V17 interface run')
        closure = {key: episode['closure'].get(key) for key in
                   ('passed', 'errors', 'started_processes', 'exited_processes',
                    'still_present_saved_identities')}
        if closure['passed'] is not True:
            reasons.append('strict native closure did not pass')
        for name, robot in episode['robots'].items():
            events = robot['stop_responses'] + robot['cancel_stop_responses']
            row = {key: robot.get(key) for key in (
                'errors', 'physical_evidence_complete', 'eligible_stop_events',
                'credited_sampled_stop_events', 'eligible_cancel_stop_events',
                'credited_cancel_stop_events', 'maximum_planar_speed_task',
                'maximum_angular_norm_task', 'maximum_raw_odom_chord_speed_task',
                'maximum_task_source_gap_ns', 'bound_violation_counts')}
            row.update(A_events=len(robot['stop_responses']),
                       A_statuses=dict(Counter(item['status'] for item in robot['stop_responses'])),
                       B_statuses=dict(Counter(item['status'] for item in robot['cancel_stop_responses'])),
                       A_prior_nonzero_spans_ns=dict(Counter(str(item.get('prior_nonzero_command_span_ns'))
                                                            for item in robot['stop_responses'])),
                       A_event_initial_planar_norm_max_mps=max(
                           [item.get('initial_observed_planar_speed') or 0.
                            for item in robot['stop_responses']], default=None),
                       observed_nonrest_beyond_horizon_count=sum(
                           item.get('observed_nonrest_beyond_horizon') is True for item in events),
                       observed_bound_violation_status_count=sum(
                           item.get('status') == 'observed_bound_violation' for item in events))
            physical_rows[name] = row
            if robot['errors']:
                reasons.append(name + ': original raw identity/source/frame errors')
            if any(robot['bound_violation_counts'].values()):
                reasons.append(name + ': original sampled body/chord bounds violated')
            if row['observed_nonrest_beyond_horizon_count'] or row['observed_bound_violation_status_count']:
                reasons.append(name + ': observed response bound or nonrest violation')
            if (not robot['credited_sampled_stop_events']
                    and not robot['credited_cancel_stop_events']):
                reasons.append(name + ': no credited meaningful A-or-B stopping response')
        transitions = directory / 'transitions.jsonl'
        records = [json.loads(line) for line in read(transitions).splitlines()]
        final = records[-1]
        if final['snapshot']['epoch'] != episode['epoch']:
            raise ValueError('final received snapshot epoch differs from original physical leaf')
        for robot in final['snapshot']['robots']:
            activity.append({'robot': robot['name'],
                             'estimated_received_path_m': robot['activity'].get('estimated_path_m'),
                             'path_observation_complete': robot['activity'].get('path_observation_complete'),
                             'accepted_goal_count': robot['navigation'].get('accepted_goal_count')})
        transition_scope = {'records': len(records), 'final_terminated': final.get('terminated'),
                            'final_truncated': final.get('truncated'),
                            'final_reason': final.get('info', {}).get('reason')}
    else:
        transition_scope = None

    angular_scope = None
    if angular is not None:
        if angular['script_sha256'] != '7a472ba7efdd55addc710b98c66c89feff7f5092f214f76fd76cd4ca526343d0':
            raise ValueError('angular leaf is not the immutable original consumer')
        angular_scope = {key: angular.get(key) for key in
                         ('passed', 'sampled_bounds_passed', 'stimulus_coverage_passed', 'missing',
                          'positive_span_robots', 'negative_span_robots',
                          'sequential_opposite_sign_span_robots', 'criteria')}
    for path, proof in bindings.items():
        if sha(Path(path).read_bytes()) != proof['sha256']:
            raise ValueError('finished receipt changed during summary: ' + path)
    physical_path = str(PREFIX) + '_fixed_physics_v1.json'
    sole_reason = None
    if failed == {physical_path}:
        sole_reason = '; '.join(reasons) or 'original physical completeness failed; inspect original leaf'
    elif failed:
        sole_reason = 'multiple or other original required outputs failed; no sole physical-cause inference'
    return {'schema': 'mr3-v17-interface-finished-formal-leaf-summary-v1',
            'freeze': FREEZE, 'aggregate_original_passed': aggregate['passed'],
            'all_submitted_jobs_finished': True, 'runner_errors': aggregate['runner_errors'],
            'required_failed_outputs': sorted(failed), 'sole_failure_reason_if_identified': sole_reason,
            'original_leaf_status': availability, 'physical': physical_rows,
            'physical_failure_facts': reasons, 'angular_original_scope': angular_scope,
            'final_received_activity': activity, 'small_transition_scope': transition_scope,
            'strict_closure_from_physical_leaf': closure, 'original_inputs': bindings,
            'helper_sha256': sha(Path(__file__).read_bytes()),
            'limits': ['This is a diagnostic summary of existing finished receipts, not a new formal auditor.',
                       'Missing meaningful motion or rest evidence remains missing even with no observed violation.',
                       'Original stopping requires one credited A OR B per robot, not both.',
                       'Original angular requires every robot one sign span, team both signs, at least one same-robot bidirectional span.',
                       'Received>.05m preparation activity is not every-robot1m task participation or95% mapping success.',
                       'No big raw logs/ModelStates, ROS/native/formal/tests/control/Git/source mutation.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--aggregate', type=Path,
                        default=Path(str(PREFIX) + '_audit_execution_v1.json'))
    parser.add_argument('--output', type=Path,
                        default=Path(str(PREFIX) + '_finished_leaf_summary_v1.json'))
    args = parser.parse_args()
    if args.output.exists():
        parser.error('never overwrite an existing diagnostic')
    try:
        result = summarize(args.aggregate)
    except (OSError, ValueError, TypeError, KeyError, IndexError) as error:
        parser.exit(2, 'summary refused before output: ' + repr(error) + '\n')
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'output': str(args.output), 'original_aggregate_passed':
                      result['aggregate_original_passed'],
                      'failed_outputs': result['required_failed_outputs']}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
