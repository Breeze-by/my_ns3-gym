from pathlib import Path
import gzip
import hashlib
import json

root=Path('/home/zhuyulab/ns3-workspace')
a=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v9'
out=a/'independent/archive_completion_v2';out.mkdir(exist_ok=True)
files=[Path('/tmp/mr3_p2a0_v9_archive_receipt_v1.json'),Path('/tmp/mr3_p2a0_v9_archive_console_v1.log'),Path('/tmp/archive_mr3_p2a0_v9_closed_v1.py')]
files.append(Path(__file__))
records=[]
for src in files:
    raw=src.read_bytes();encoded=gzip.compress(raw,mtime=0);dst=out/(src.name+'.gz')
    with dst.open('xb') as f:f.write(encoded)
    assert gzip.decompress(dst.read_bytes())==raw
    records.append(dict(original=str(src),archived=str(dst.relative_to(a)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),encoded_sha256=hashlib.sha256(encoded).hexdigest()))
manifest={'schema':'mr3-originals-completion-v2','prior_inventory_unchanged':{'path':'inventory_native_v1.json','sha256':hashlib.sha256((a/'inventory_native_v1.json').read_bytes()).hexdigest()},'originals':records,'scope':'actual successful archive completion and exact helper bytes added after v1; no native rerun or FAIL rewrite'}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
inventory=[]
for p in sorted(a.rglob('*')):
    if p.is_file() and '__pycache__' not in p.parts:
        raw=p.read_bytes();inventory.append({'path':str(p.relative_to(a)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
payload={'schema':'mr3-asset-inventory-v2','self_excluded':True,'files':inventory}
dst=a/'inventory_native_v2.json';assert not dst.exists();dst.write_text(json.dumps(payload,indent=2)+'\n')
print(json.dumps({'passed':True,'files':len(inventory),'inventory_sha256':hashlib.sha256(dst.read_bytes()).hexdigest()}))
