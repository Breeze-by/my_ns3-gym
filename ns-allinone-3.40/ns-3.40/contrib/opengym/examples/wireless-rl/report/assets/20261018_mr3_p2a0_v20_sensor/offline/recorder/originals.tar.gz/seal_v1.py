#!/usr/bin/python3
"""Seal completed TMP-only recorder evidence, without running ROS or a build."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tarfile
import time


BASE = Path('/tmp/mr3_p2a0_v20_sensor_recorder_proposal_v1')
OUT = Path('/tmp/mr3_p2a0_v20_sensor_recorder_sealed_v1')
ARCHIVE = Path(str(OUT) + '.tar.gz')
BINARY_GZ = Path('/tmp/mr3_p2a0_v20_sensor_recorder_binary_v1.gz')
RECEIPT = Path('/tmp/mr3_p2a0_v20_sensor_recorder_seal_receipt_v1.json')
HANDOFF = Path('/tmp/mr3_p2a0_v20_sensor_recorder_handoff_v1.json')
POSTPROBE = Path('/tmp/mr3_p2a0_v20_sensor_recorder_postprobe_identity_v1.json')
SOURCE = BASE / 'mr3_startup_sensor_recorder.cpp'
ELF = BASE / 'build/mr3_startup_sensor_recorder'
REVIEW = Path('/tmp/mr3_p2a0_v20_recorder_interface_independent_review_v1.json')
CPP_SHA = '4707c8eaef49e4b763023b2b5d18e9be003ceed04bc9cebcd5c2bbf11f187caf'
ELF_SHA = 'efd8a8f849da96c54753d168762dd8b4d5200077d5c490aaac070ea66f881f64'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()


def stable(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise ValueError('Not a regular original: ' + str(path))
    data = path.read_bytes()
    after = path.lstat()
    keys = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    if any(getattr(before, k) != getattr(after, k) for k in keys):
        raise ValueError('Original changed while reading: ' + str(path))
    return data, {k: getattr(before, k) for k in keys}


def create(path, data):
    with path.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


started = time.monotonic()
for target in (OUT, ARCHIVE, BINARY_GZ, RECEIPT, HANDOFF, POSTPROBE):
    if target.exists():
        raise ValueError('Refuse overwrite: ' + str(target))
source_data, _ = stable(SOURCE)
elf_data, elf_stat = stable(ELF)
assert sha(source_data) == CPP_SHA
assert sha(elf_data) == ELF_SHA and len(elf_data) == 2659040

process = json.loads((BASE / 'ros_loopback_probe_v1/recorder_process.json').read_text())
pid = process['pid']
original_ticks = int(process['stat_raw'].rsplit(')', 1)[1].split()[19])
proc = Path('/proc') / str(pid) / 'stat'
current_raw = proc.read_text() if proc.exists() else None
current_ticks = (int(current_raw.rsplit(')', 1)[1].split()[19])
                 if current_raw is not None else None)
identity_gone = current_ticks != original_ticks
assert identity_gone
create(POSTPROBE, encode({
    'schema': 'mr3-v20-recorder-postprobe-owned-identity-v1',
    'pid': pid, 'saved_start_ticks': original_ticks,
    'current_stat_raw': current_raw, 'current_start_ticks': current_ticks,
    'same_saved_identity_present': not identity_gone,
    'probe_exit_code': 0,
    'scope': 'Read-only later identity check; no signals, no ROS initialization.'
}))

handoff = {
    'schema': 'mr3-v20-startup-sensor-recorder-handoff-v1',
    'source': {'path': str(SOURCE), 'sha256': CPP_SHA},
    'cmake': {'path': str(BASE / 'CMakeLists.txt'),
              'sha256': sha((BASE / 'CMakeLists.txt').read_bytes())},
    'actual_elf': {'path': str(ELF), 'sha256': ELF_SHA, 'bytes': len(elf_data),
                   'built_source_macro': CPP_SHA},
    'cli': [str(ELF), '--config', 'ABS_CONFIG_JSON'],
    'config_schema': 'mr3-startup-sensor-capture-config-v1',
    'ready_schema': 'mr3-startup-sensor-recorder-ready-v1',
    'stop_schema': 'mr3-startup-sensor-recorder-stop-v1',
    'final_schema': 'mr3-startup-sensor-recorder-final-v1',
    'topics': 22,
    'checks': {
        'first_build': {'exit_code': 2, 'reason': 'Werror misleading-indentation',
                        'original_receipt': str(BASE / 'checks/build01.json')},
        'final_build': {'exit_code': 0, 'wall_seconds': 112.37127894628793,
                        'original_receipt': str(BASE / 'checks/build02.json')},
        'cpu': {'passed_checks': 15, 'wall_seconds': 0.17197621520608664,
                'scope': 'SDK serialization without rclcpp init or DDS',
                'original_receipt': str(BASE / 'checks/cpu_selftest01.json')},
        'probe_style_initial_failure_retained': True,
        'actual_ros_sdk_probe': {
            'attempts': 1, 'domain_id': 171, 'captured_exact_cdr_messages': 3,
            'outer_wall_seconds': 3.3036216092295945, 'exit_code': 0,
            'original_receipt': str(BASE / 'checks/ros_probe01.json'),
            'result_path': str(BASE / 'ros_loopback_probe_v1/result_v1.json'),
            'result_sha256': sha((BASE / 'ros_loopback_probe_v1/result_v1.json').read_bytes()),
            'scope': 'Synthetic actual RMW loopback, no Gazebo/native benchmark or SLAM RPC'
        },
        'independent_interface_review': {'path': str(REVIEW),
                                         'sha256': sha(REVIEW.read_bytes())}
    },
    'limitations': [
        'Ready proves local subscriptions created, not discovery of the first native scan.',
        'Actual SLAM ListParameters/GetParameters response availability is untested by this scan-only probe.',
        'Public SLAM pose is successful-processing proxy, not a full internal beam ledger.',
        'Map header is not one-to-one with an accepted scan or occupied-cell cause.',
        'Pure subscription still imposes CPU, IO and DDS load; no zero-interference theorem.',
        'Capture completion is process/custody scope, not P2A.0 matrix, task95 or solver150 credit.'
    ],
    'prospective_native': {'started_by_this_agent': False, 'attempts_allowed': 1,
                           'returned_steps': 4, 'api_calls': 5, 'wall_ceiling_sec': 900},
    'archive_policy': {
        'exclude': [str(BASE / 'build')],
        'build_text_exceptions': ['flags.make', 'link.txt'],
        'optional_actual_runtime_binary_gzip': str(BINARY_GZ),
        'note': 'Keep actual compiled ELF separately if canonical runtime custody is desired; no cache, objects or CPU-test ELF.'
    }
}
create(HANDOFF, encode(handoff))

selections = [(p, str(p.relative_to(BASE))) for p in sorted(BASE.rglob('*'))
              if p.is_file() and 'build' not in p.relative_to(BASE).parts]
selections += [
    (BASE / 'build/CMakeFiles/mr3_startup_sensor_recorder.dir/flags.make',
     'build_text/flags.make'),
    (BASE / 'build/CMakeFiles/mr3_startup_sensor_recorder.dir/link.txt',
     'build_text/link.txt'),
    (REVIEW, 'independent/recorder_interface_review_v1.json'),
    (HANDOFF, 'handoff_v1.json'),
    (POSTPROBE, 'postprobe_owned_identity_v1.json'),
    (Path(__file__), 'seal_v1.py')
]
OUT.mkdir()
entries = []
for path, relative in selections:
    data, original_stat = stable(path)
    destination = OUT / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    create(destination, data)
    reread, final_stat = stable(path)
    if final_stat != original_stat or reread != data:
        raise ValueError('Original changed before seal completion: ' + str(path))
    assert destination.read_bytes() == data
    entries.append({'source_absolute_path': str(path), 'relative_path': relative,
                    'bytes': len(data), 'raw_sha256': sha(data), 'encoding': 'raw',
                    'encoded_sha256': sha(data), 'decoded_sha256': sha(data),
                    'source_before_stat': original_stat, 'source_after_stat': final_stat,
                    'stable_before_after': True})
manifest = {
    'schema': 'mr3-v20-recorder-offline-originals-manifest-v1',
    'scope': 'Lossless completed TMP development and one synthetic ROS SDK probe only.',
    'source_cpp_sha256': CPP_SHA, 'actual_elf_sha256': ELF_SHA,
    'entries': entries, 'entry_count': len(entries),
    'raw_bytes': sum(entry['bytes'] for entry in entries),
    'excluded_entire_tree': str(BASE / 'build'),
    'exceptions_are_text_copies_only': ['build_text/flags.make', 'build_text/link.txt'],
    'symlinks_or_cpu_test_binaries_included': False,
    'self_manifest_not_self_hashed': True
}
manifest_bytes = encode(manifest)
create(OUT / 'manifest_v1.json', manifest_bytes)

archive_buffer = io.BytesIO()
with tarfile.open(fileobj=archive_buffer, mode='w', format=tarfile.PAX_FORMAT) as archive:
    for path in sorted(OUT.rglob('*')):
        if not path.is_file():
            continue
        data = path.read_bytes()
        member = tarfile.TarInfo(str(path.relative_to(OUT)))
        member.size, member.mode, member.mtime = len(data), 0o644, 0
        archive.addfile(member, io.BytesIO(data))
compressed = gzip.compress(archive_buffer.getvalue(), mtime=0)
create(ARCHIVE, compressed)
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(compressed)), mode='r:') as archive:
    expected = {str(p.relative_to(OUT)): p.read_bytes() for p in OUT.rglob('*') if p.is_file()}
    actual = {}
    for member in archive.getmembers():
        if not member.isfile() or member.name in actual:
            raise ValueError('Unexpected tar member')
        actual[member.name] = archive.extractfile(member).read()
    assert actual == expected

binary_compressed = gzip.compress(elf_data, mtime=0)
create(BINARY_GZ, binary_compressed)
assert gzip.decompress(BINARY_GZ.read_bytes()) == elf_data
elf_after, elf_after_stat = stable(ELF)
assert elf_after == elf_data and elf_after_stat == elf_stat
assert stable(SOURCE)[0] == source_data
receipt = {
    'schema': 'mr3-v20-recorder-offline-seal-receipt-v1',
    'argv': ['/usr/bin/python3', '-B', str(Path(__file__))],
    'cwd': str(Path.cwd()),
    'environment': {key: os.environ.get(key) for key in
                    ('PYTHONNOUSERSITE', 'PYTHONDONTWRITEBYTECODE', 'ROS_DOMAIN_ID',
                     'RMW_IMPLEMENTATION', 'ROS_LOCALHOST_ONLY', 'FASTRTPS_DEFAULT_PROFILES_FILE')},
    'exit_code': 0, 'wall_seconds': time.monotonic() - started,
    'script_sha256': sha(Path(__file__).read_bytes()),
    'source_cpp_sha256': CPP_SHA,
    'manifest': {'path': str(OUT / 'manifest_v1.json'), 'sha256': sha(manifest_bytes),
                 'entries': len(entries), 'raw_bytes': manifest['raw_bytes']},
    'archive': {'path': str(ARCHIVE), 'sha256': sha(compressed),
                'encoded_bytes': len(compressed), 'tar_bytes': len(archive_buffer.getvalue()),
                'all_members_roundtrip_byte_equal': True},
    'optional_actual_runtime_binary': {
        'source_path': str(ELF), 'raw_sha256': ELF_SHA, 'raw_bytes': len(elf_data),
        'encoded_path': str(BINARY_GZ), 'encoded_sha256': sha(binary_compressed),
        'encoded_bytes': len(binary_compressed), 'decoded_sha256': sha(gzip.decompress(binary_compressed)),
        'source_before_stat': elf_stat, 'source_after_stat': elf_after_stat,
        'stable_before_after': True, 'roundtrip_byte_equal': True},
    'source_stable_before_after': True,
    'no_build_or_ROS_or_native_executed_by_this_seal': True,
    'scope': 'Custody verification, not new SDK test or task/matrix acceptance.'
}
create(RECEIPT, encode(receipt))
print(json.dumps(receipt, sort_keys=True, allow_nan=False))
