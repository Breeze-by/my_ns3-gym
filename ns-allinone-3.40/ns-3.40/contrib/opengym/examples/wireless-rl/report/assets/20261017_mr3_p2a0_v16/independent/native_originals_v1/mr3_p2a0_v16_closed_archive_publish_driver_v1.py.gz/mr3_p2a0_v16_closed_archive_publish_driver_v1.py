import pathlib,subprocess,os,time,json,hashlib,datetime
R=pathlib.Path("/home/zhuyulab/ns3-workspace");T=pathlib.Path("/tmp");helper=T/"mr3_p2a0_v16_archive_closed_v1.py";sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(helper)=="b4116df807527b4d59baf2e091e5b12b19716eee5d97559a8c9b3fd2d77b243c"
argv=["/usr/bin/python3",str(helper),"--publish","--mode","stopped","--stop-stage","interface"];console=T/"mr3_p2a0_v16_closed_archive_publish_v1.log";receipt=T/"mr3_p2a0_v16_closed_archive_publish_v1.json";assert not console.exists() and not receipt.exists()
env=os.environ.copy();env.pop("PYTHONPATH",None);env.update(PYTHONNOUSERSITE="1",PYTHONDONTWRITEBYTECODE="1");started=datetime.datetime.now(datetime.timezone.utc).isoformat();begin=time.monotonic()
with console.open("xb") as f:r=subprocess.run(argv,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,check=False)
record=dict(argv=argv,cwd=str(R),env={"PYTHONPATH":"unset","PYTHONNOUSERSITE":"1","PYTHONDONTWRITEBYTECODE":"1"},started_utc=started,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),returncode=r.returncode,wall_seconds=time.monotonic()-begin,console=str(console),console_sha256=sha(console),source_sha256=sha(helper))
with receipt.open("x") as f:json.dump(record,f,indent=2);f.write("\n")
print(json.dumps(record,indent=2));print(console.read_text());raise SystemExit(r.returncode)
