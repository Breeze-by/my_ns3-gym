#!/usr/bin/python3
"""V24 selected raw-vs-guard table and installed/primary smoother source evidence."""
from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import time
import urllib.request

D = Path('/tmp/mr3_p2a0_v24_body_trigger_independent_v1')
SUBSET = Path('/tmp/mr3_p2a0_v24_model_fault_review_v1/motion_tb2_window.jsonl.gz')
CHAIN = Path('/tmp/mr3_p2a0_v24_model_fault_review_v1/chain_review_v1.json')
ROOT = Path('/home/zhuyulab/ns3-workspace')
PARAM = ROOT / 'ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261018_v24_interface/worker0/episode001_open_101/actual_nav2_parameters.json'
SOURCE = ROOT / 'ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/multi_robot_exploration/motion_safety.py'
PRIMARY_URL = 'https://raw.githubusercontent.com/ros-navigation/navigation2/1.1.20/nav2_velocity_smoother/src/velocity_smoother.cpp'
PRIMARY_CACHE = Path('/tmp/mr3_p2a0_v25_smoother_clock_source_review_v1/primary/tag_1_1_20_velocity_smoother.cpp')
PRIMARY_DIR = PRIMARY_CACHE.parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def bound(path):
    def identity(s):
        return [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns]
    s = path.stat()
    raw = path.read_bytes()
    assert identity(s) == identity(path.stat())
    return raw, {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw), 'stat': identity(s)}


def main():
    start = time.monotonic()
    paths = [Path(__file__), SUBSET, CHAIN, PARAM, SOURCE,
             Path('/opt/ros/humble/share/nav2_velocity_smoother/package.xml'),
             Path('/opt/ros/humble/include/nav2_velocity_smoother/velocity_smoother.hpp'),
             Path('/opt/ros/humble/lib/libvelocity_smoother_core.so'), PRIMARY_CACHE,
             PRIMARY_DIR / 'release_humble_1_1_20_1_velocity_smoother.cpp',
             PRIMARY_DIR / 'tag_1_1_20_velocity_smoother.hpp',
             PRIMARY_DIR / 'tag_1_1_20_package.xml']
    captured = [bound(x) for x in paths]
    chain = json.loads(captured[2][0])
    assert captured[2][1]['sha256'] == '44efd14c15533dc8e35b29350d387e98e36edae033eae26ec45a23b383da90df'
    selected_record = chain['selected_originals']['motion_tb2_window']
    assert sha(captured[1][0]) == selected_record['encoded_sha256']
    raw = gzip.decompress(captured[1][0])
    assert sha(raw) == selected_record['raw_sha256']
    lookup = {r['record_sequence']: r for r in selected_record['rows']}
    rows = []
    for line in raw.splitlines(keepends=True):
        row = json.loads(line)
        if 56.5 <= row['sim_time_sec'] <= 56.98 and row['kind'] in ('raw_request', 'decision'):
            ref = lookup[row['record_sequence']]
            assert ref['sha256'] == sha(line)
            rows.append((row, ref))
    requests = {r['payload']['request']['sequence']: (r, ref) for r,ref in rows if r['kind'] == 'raw_request'}
    table = []
    raw_out = []
    for r, ref in rows:
        if r['kind'] != 'decision':
            continue
        p = r['payload']
        req = p['request']
        raw_r, raw_ref = requests[req['sequence']]
        assert raw_r['payload']['request'] == req
        decision = p['decision']
        kind = p.get('phase_kind', 'normal')
        if kind == 'normal':
            assert decision['reason'] == 'clear' and decision.get('component_filter') is None
            assert decision['output'] == [req['v'], req['w']]
        table.append({'clock_ns': p['clock_ns'], 'phase_kind': kind,
                      'request_sequence': req['sequence'], 'raw_v': req['v'], 'raw_w': req['w'],
                      'raw_callback_wall_ns': raw_r['wall_monotonic_ns'],
                      'raw_callback_sim_sec': raw_r['sim_time_sec'],
                      'graph_identity_at_callback': req['publisher_identity'],
                      'decision_sequence': p['decision_sequence'], 'decision_reason': decision['reason'],
                      'final_output': decision['output'], 'component_filter': decision.get('component_filter'),
                      'raw_original_ref': raw_ref, 'decision_original_ref': ref})
    normal = [r for r in table if r['phase_kind'] == 'normal']
    assert len(normal) == 24 and len(table) == 25
    a = next(r for r in table if r['clock_ns'] == 56660000000)
    b = next(r for r in table if r['clock_ns'] == 56680000000)
    transition = {'previous': a, 'next': b,
                  'sim_delta_ns': b['clock_ns'] - a['clock_ns'],
                  'wall_delta_ns': b['raw_callback_wall_ns'] - a['raw_callback_wall_ns'],
                  'selected_request_sequence_delta': b['request_sequence'] - a['request_sequence'],
                  'selected_v_delta_per_sim_second': (b['raw_v'] - a['raw_v']) / 0.02,
                  'selected_v_delta_per_wall_second': (b['raw_v'] - a['raw_v']) / ((b['raw_callback_wall_ns'] - a['raw_callback_wall_ns']) / 1e9)}
    params = json.loads(captured[3][0])
    assert params['passed'] is True
    smoother = next(x for x in params['nodes'] if x['node'] == '/tb2/velocity_smoother')
    command = ['dpkg-query', '-W', '-f=${Package} ${Version}\n', 'ros-humble-nav2-velocity-smoother']
    package = subprocess.run(command, capture_output=True, check=False)
    assert package.returncode == 0
    (D / 'installed_version_stdout_v2.txt').write_bytes(package.stdout)
    (D / 'installed_version_stderr_v2.txt').write_bytes(package.stderr)
    primary = captured[8][0]
    assert primary == captured[9][0]
    assert captured[6][0] == captured[10][0] and captured[5][0] == captured[11][0]
    assert sha(primary) == '788822f4ac41a03a46e73b6a7a73f876a75792e093d6c3f7b3dceecb69bcc50d'
    primary_path = D / 'cached_official_tag_1_1_20_velocity_smoother.cpp'
    assert not primary_path.exists()
    primary_path.write_bytes(primary)
    text = primary.decode()
    assert text.count('this->create_wall_timer(') == 2
    assert 'current_ = last_cmd_' in text
    assert 'accel / smoothing_frequency_' in text
    assert 'last_cmd_ = *cmd_vel' in text
    for index, name in ((4, 'frozen_motion_safety.py'), (5, 'installed_package.xml'), (6, 'installed_velocity_smoother.hpp')):
        (D / name).write_bytes(captured[index][0])
    result = {
        'schema': 'mr3-v24-raw-guard-installed-smoother-description-v1',
        'scope': 'Closed selected raw lines and source/SDK metadata only; no new ROS/DDS/native/probe/test/formal and no canonical changes.',
        'freeze': '5d684c46f9f99a867a94f1fed8c52e923e2486ef',
        'input_bindings': [x[1] for x in captured], 'selected_raw_vs_guard_table': table,
        'ordinary_decisions_checked': len(normal), 'fault_stop_decisions_separate': 1,
        'all_ordinary_outputs_exactly_equal_bound_raw_requests': True,
        'selected_transition': transition,
        'actual_parameter_readback': {'original_passed': params['passed'], 'freeze': params['freeze'], 'node': smoother},
        'installed_package': {'argv': command, 'exit_code': package.returncode,
                              'stdout': package.stdout.decode(), 'stderr': package.stderr.decode()},
        'primary_source': {'url': PRIMARY_URL, 'path': str(primary_path), 'bytes': len(primary), 'sha256': sha(primary),
                           'version': 'Exact official1.1.20tag bytes equal release_humble1.1.20-1 bytes; installed header/package.xml exact same bytes. Actual package ELF separately bound, not package compiler-source attestation',
                           'exact_tag_reference_read_only': 'https://raw.githubusercontent.com/ros-navigation/navigation2/1.1.20/nav2_velocity_smoother/src/velocity_smoother.cpp'},
        'official_humble_documentation': 'https://api.nav2.org/nav2-humble/html/velocity__smoother_8cpp_source.html',
        'source_contract': {'activation_and_dynamic_frequency_timer': 'create_wall_timer',
                            'open_loop_feedback': 'last_cmd_', 'per_tick_component_delta': 'accel or decel divided by smoothing_frequency_',
                            'integrates_actual_sim_dt': False, 'use_sim_time_does_not_change_wall_timer_clock': True},
        'conclusions_zh': [
            '56.50–56.96共24次普通guard决策均clear直通绑定raw输入；56.98另为真实model fault后的全零stop，不把它混作正常滤波。',
            '56.66到56.68的v0→.1已在velocity_smoother图身份的unguarded输入中出现，故当前跃迁不是guard解除线速度限制造成。',
            '两个已选callback在sim20ms内相隔wall299825384ns，序号增加6；原callback ledger每回调都有record，但本CI选存subset只含绑定到决策的raw行，本报告不声称已分析全部中间published samples。',
            '官方同版本OPEN_LOOP用墙钟timer且每tick固定accel/frequency，physics暂停时仍可累计内部last_cmd；此设计与本次simtime快速过渡一致。它是已证时间基不一致，尚不能凭本窗口唯一证明机体超速的完整动力学原因或新timer修复充分。',
            'actual参数API PASS独立于V24身体/完整attempt FAIL；保持1.2/.30/7/.78/.144/.01三样本及所有原门，不以参数值代替实际执行斜率。',
            '下一版若改为实际simtime累计，需覆盖相同clock不重复积分、clock变化/回退/激活/动态频率、硬零/timeout及真输出，不新增探索方向或策略fallback；本报告未实施或验证修复。'
        ],
        'correction_to_earlier_message': '中间样本未全分析仅指CI selected subset，原motion receive_request会逐callback写raw_request，不声称原完整ledger遗漏。',
        'prior_direct_primary_fetch': 'V1 read-only urllib20s source request timed out; raw traceback/exit/wall retained, no network retry. V2 uses already cached primary source and records its limited identity.',
        'exploratory_table_failure_preserved': 'interactive optional-field access at faultstop raised KeyError component_filter; no production/native failure and no input changed; final table handles stop separately.'}
    assert [x[1] for x in captured] == [bound(p)[1] for p in paths]
    result['all_input_bindings_end_stable'] = True
    result['wall_seconds'] = time.monotonic() - start
    out = D / 'raw_guard_smoother_review_v2.json'
    assert not out.exists()
    out.write_text(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    print(json.dumps({'output': str(out), 'sha256': sha(out.read_bytes()), 'normal_decisions': len(normal),
                      'primary_source_sha256': sha(primary), 'inputs_stable': True}))

if __name__ == '__main__':
    main()
