"""Metadata/helper tests only. No native, formal CLI or canonical archive execution."""
import copy
import importlib.util
from pathlib import Path
import tempfile
import unittest

SPEC = importlib.util.spec_from_file_location(
    'archive_helper', '/tmp/mr3_p2a0_v12_archive_closed_v1.py')
H = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(H)


class FinalStateTests(unittest.TestCase):
    def setUp(self):
        self.plan = {'stages': []}
        self.values = {}
        for stage in H.STAGES:
            spec = {'stage': stage, 'run_directory': '/fake/run/' + stage,
                    'required_audit_receipts': ['/fake/' + stage + '.json']}
            self.plan['stages'].append(spec)
            self.values[str(self.path(stage, 'launch.json'))] = dict(
                status='completed', freeze=H.FREEZE, plan_sha256=H.PLAN_SHA, passed=True)
            self.values[str(self.path(stage, 'audit_execution_v1.json'))] = dict(
                freeze=H.FREEZE, plan_sha256=H.PLAN_SHA, all_submitted_jobs_finished=True,
                passed=True, receipts=[dict(path=spec['required_audit_receipts'][0])])

    def path(self, stage, suffix):
        return H.TEMP / (H.PREFIX + '_' + stage + '_' + suffix)

    def load(self, path):
        return copy.deepcopy(self.values[str(path)])

    def exists(self, path):
        return str(path) in self.values

    def validate(self, mode='complete', stop=None):
        return H.validate_final_states(self.plan, mode, stop, self.load, self.exists)

    def stopped(self):
        for stage in H.STAGES[2:]:
            self.values.pop(str(self.path(stage, 'launch.json')))
            self.values.pop(str(self.path(stage, 'audit_execution_v1.json')))
        self.values[str(self.path('terminal', 'audit_execution_v1.json'))]['passed'] = False

    def test_complete_all_four(self):
        self.assertEqual([r['status'] for r in self.validate()], ['PASS'] * 4)

    def test_stopped_keeps_real_fail_and_skips(self):
        self.stopped()
        self.assertEqual([r['status'] for r in self.validate('stopped', 'terminal')],
                         ['PASS', 'FAIL', 'SKIPPED_after_terminal_failure',
                          'SKIPPED_after_terminal_failure'])

    def test_live_and_unfinished_jobs_rejected(self):
        for key, value in [('status', 'running'), ('passed', None)]:
            with self.subTest(key=key):
                original = self.values[str(self.path('reset', 'launch.json'))].copy()
                self.values[str(self.path('reset', 'launch.json'))][key] = value
                with self.assertRaises(AssertionError):
                    self.validate()
                self.values[str(self.path('reset', 'launch.json'))] = original
        self.values[str(self.path('reset', 'audit_execution_v1.json'))][
            'all_submitted_jobs_finished'] = False
        with self.assertRaises(AssertionError):
            self.validate()

    def test_failed_stage_never_complete(self):
        self.values[str(self.path('terminal', 'audit_execution_v1.json'))]['passed'] = False
        with self.assertRaises(AssertionError):
            self.validate()

    def test_earlier_fail_and_fake_stop_rejected(self):
        self.stopped()
        self.values[str(self.path('interface', 'launch.json'))]['passed'] = False
        with self.assertRaises(AssertionError):
            self.validate('stopped', 'terminal')
        self.values[str(self.path('interface', 'launch.json'))]['passed'] = True
        self.values[str(self.path('terminal', 'audit_execution_v1.json'))]['passed'] = True
        with self.assertRaises(AssertionError):
            self.validate('stopped', 'terminal')

    def test_later_run_receipt_or_pack_not_hidden(self):
        self.stopped()
        for path in [self.path('reset', 'launch.json'), Path('/fake/run/reset'),
                     H.TEMP / (H.PREFIX + '_selected_native/reset')]:
            with self.subTest(path=str(path)):
                self.values[str(path)] = {}
                with self.assertRaises(AssertionError):
                    self.validate('stopped', 'terminal')
                self.values.pop(str(path))

    def test_freeze_plan_and_exact_mandatory_set_rejected(self):
        for key in ['freeze', 'plan_sha256', 'receipts']:
            original = self.values[str(self.path('reset', 'audit_execution_v1.json'))].copy()
            self.values[str(self.path('reset', 'audit_execution_v1.json'))][key] = (
                [] if key == 'receipts' else 'bad')
            with self.assertRaises(AssertionError):
                self.validate()
            self.values[str(self.path('reset', 'audit_execution_v1.json'))] = original

    def test_safe_paths_and_exclusive_outputs(self):
        for value in ('../escape', '/absolute'):
            with self.assertRaises(ValueError):
                H.safe_relative(value)
        with tempfile.TemporaryDirectory(prefix='mr3_v12_archive_metadata_test_') as tmp:
            path = Path(tmp) / 'new.json'
            H.new_json(path, {'original': True})
            with self.assertRaises(FileExistsError):
                H.new_json(path, {'replacement': True})
            self.assertEqual(H.read(path), {'original': True})


if __name__ == '__main__':
    unittest.main(verbosity=2)
