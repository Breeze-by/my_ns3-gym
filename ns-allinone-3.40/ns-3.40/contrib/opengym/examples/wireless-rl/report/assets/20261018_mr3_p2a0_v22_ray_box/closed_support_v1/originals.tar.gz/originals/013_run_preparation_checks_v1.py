#!/usr/bin/python3
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

P=Path(__file__).resolve().parent
ROOT=Path('/home/zhuyulab/ns3-workspace')
BASE=Path('/tmp/mr3_p2a0_v21_ray_pack_closed_v1.py')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def inventory():
 return {str(p):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns,'inode':p.stat().st_ino}
         for p in [BASE,P/'mr3_p2a0_v22_matrix_pack_closed_v1.py',P/'test_pack_selection_v1.py',Path(__file__)]}
env={'PATH':'/usr/bin:/bin','PYTHONNOUSERSITE':'1','PYTHONDONTWRITEBYTECODE':'1','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC'}
before=inventory()
base=BASE.read_text();source=(P/'mr3_p2a0_v22_matrix_pack_closed_v1.py').read_text()
old=ast.parse(base);new=ast.parse(source)
codec={}
for name in ['sha','identity','file_digest','verify_file','pack_file','inventory']:
 a=next(x for x in old.body if isinstance(x,ast.FunctionDef) and x.name==name)
 b=next(x for x in new.body if isinstance(x,ast.FunctionDef) and x.name==name)
 assert ast.get_source_segment(base,a)==ast.get_source_segment(source,b)
 codec[name]=sha(ast.get_source_segment(source,b).encode())
commands=[('selection_only_tests',['/usr/bin/python3','-B',str(P/'test_pack_selection_v1.py'),'-v']),
 ('fatal_style',['/usr/bin/python3','-m','flake8','--select=E9,F63,F7,F82',str(P/'mr3_p2a0_v22_matrix_pack_closed_v1.py'),str(P/'test_pack_selection_v1.py')]),
 ('cli_help',['/usr/bin/python3','-B',str(P/'mr3_p2a0_v22_matrix_pack_closed_v1.py'),'--help'])]
results=[]
for name,argv in commands:
 start=time.monotonic();r=subprocess.run(argv,cwd=ROOT,env=env,capture_output=True);wall=time.monotonic()-start
 for stream,data in [('stdout',r.stdout),('stderr',r.stderr)]:
  (P/(name+'.'+stream+'.log')).write_bytes(data)
 results.append({'name':name,'argv':argv,'cwd':str(ROOT),'environment_exact':env,'exit_code':r.returncode,
                 'wall_seconds':wall,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr),
                 'stderr_tail':r.stderr.decode(errors='replace')[-3000:]})
after=inventory();assert before==after
report={'schema':'mr3-v22-closed-pack-preparation-checks-v1','passed':all(x['exit_code']==0 for x in results),
 'scope':'Only five new fixed-selection fake-files tests, syntax/CLI/fatal style; no compression/codec old suite/native/formal/active artifact read.',
 'codec_base':str(BASE),'codec_base_sha256':sha(BASE.read_bytes()),'six_codec_functions_exact_source_bytes':codec,
 'results':results,'source_before':before,'source_after':after,'actual_pack_invoked':False,
 'canonical_write':False,'all_proposal_writers_stopped_after_handoff':True}
(P/'checks_v1.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'passed':report['passed'],'results':results},indent=2))
raise SystemExit(0 if report['passed'] else 1)
