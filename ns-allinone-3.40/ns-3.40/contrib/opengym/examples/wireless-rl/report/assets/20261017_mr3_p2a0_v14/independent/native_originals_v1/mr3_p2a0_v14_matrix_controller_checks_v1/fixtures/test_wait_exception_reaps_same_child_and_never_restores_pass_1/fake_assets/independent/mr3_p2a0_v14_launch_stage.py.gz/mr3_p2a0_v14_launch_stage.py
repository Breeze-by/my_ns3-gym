import hashlib,json,sys,time
from pathlib import Path
TEMP=Path('/tmp/mr3_v14_matrix_cpu_jnvxnrbd/runtime')
A=Path('/tmp/mr3_v14_matrix_cpu_jnvxnrbd/repo/wireless/assets')
stage,freeze=sys.argv[1:]
planpath=A/'predeclared_plan_v14.json'
raw=planpath.read_bytes()
plan=json.loads(raw)
plan_sha=hashlib.sha256(raw).hexdigest()
spec=next(x for x in plan['stages'] if x['stage']==stage)
behavior=plan['fake_behavior']
prefix=TEMP/('mr3_p2a0_v14_'+stage)
role='launch' if 'launch_stage' in Path(__file__).name else 'audit'
def write(path,value):
 with path.open('x') as output:json.dump(value,output)
def proof(path):return {'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
time.sleep(.02)
if role=='launch':
 run=Path(spec['run_directory']);run.mkdir()
 success=behavior.get('launch_fail')!=stage
 summary=run/'benchmark_summary.json'
 write(summary,{'freeze':freeze,'passed':success})
 write(Path(str(prefix)+'_launch.json'),{'freeze':freeze,'stage':stage,'plan_sha256':plan_sha,
  'status':'completed','passed':success,'returncode':0 if success else 1,
  'within_wall_budget':True,'benchmark_summary':proof(summary),'wall_duration_sec':.02})
 if behavior.get('mutate_plan')==stage:planpath.write_text(raw.decode()+'\n')
 if behavior.get('mutate_source')==stage:
  source=A/'independent/mr3_p2a0_v14_audit_stage.py'
  source.write_text(source.read_text()+'\n# unexpected source mutation\n')
 sys.exit(0 if success else 1)
else:
 success=behavior.get('audit_fail')!=stage
 leaves=[]
 for path in spec['required_audit_receipts']:
  path=Path(path)
  write(path,{'passed':success and behavior.get('false_leaf_cli0')!=stage,'freeze':freeze})
  leaves.append({**proof(path),'passed':success})
 write(Path(str(prefix)+'_audit_execution_v1.json'),{'freeze':freeze,'stage':stage,
  'plan_sha256':plan_sha,'passed':success,'all_submitted_jobs_finished':True,
  'runner_errors':[],'commands':[{'required_success':True,'passed':success,'returncode':0}],
  'receipts':leaves})
 sys.exit(0 if success else 1)
