// Read-only, opt-in Gazebo Classic stop-response diagnostic observer.
// Candidate only: no production source or binary has been changed.
#include <gazebo/common/Events.hh>
#include <gazebo/common/Plugin.hh>
#include <gazebo/physics/Joint.hh>
#include <gazebo/physics/Link.hh>
#include <gazebo/physics/Model.hh>
#include <gazebo/physics/PhysicsEngine.hh>
#include <gazebo/physics/World.hh>
#include <sdf/sdf.hh>
#include <nlohmann/json.hpp>
#include <boost/any.hpp>
#include <algorithm>
#include <chrono>
#include <cctype>
#include <cstdio>
#include <dlfcn.h>
#include <filesystem>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

#ifndef MR3_OBSERVER_SOURCE_SHA256
#define MR3_OBSERVER_SOURCE_SHA256 "unconfigured_candidate_not_native_credit"
#endif

namespace mr3_diagnostics
{
namespace
{
using Json = nlohmann::json;
void LibraryAnchor() {}

int64_t Ns(const gazebo::common::Time & time)
{
  return static_cast<int64_t>(time.sec) * 1000000000LL + time.nsec;
}

Json Vector(const ignition::math::Vector3d & v)
{
  return {v.X(), v.Y(), v.Z()};
}

Json Pose(const ignition::math::Pose3d & p)
{
  return {{"position_xyz", Vector(p.Pos())},
    {"quaternion_wxyz", {p.Rot().W(), p.Rot().X(), p.Rot().Y(), p.Rot().Z()}}};
}

Json Link(const gazebo::physics::LinkPtr & link)
{
  return {{"name", link->GetScopedName()}, {"world_pose", Pose(link->WorldPose())},
    {"world_cog_pose", Pose(link->WorldCoGPose())},
    {"world_origin_linear_velocity_xyz", Vector(link->WorldLinearVel())},
    {"world_cog_linear_velocity_xyz", Vector(link->WorldCoGLinearVel())},
    {"world_angular_velocity_xyz", Vector(link->WorldAngularVel())}};
}

int64_t ReadNanoseconds(const sdf::ElementPtr & sdf, const std::string & key)
{
  if (!sdf->HasElement(key)) {throw std::invalid_argument("diagnostic ns field missing");}
  const auto text = sdf->Get<std::string>(key);
  if (text.empty() || !std::all_of(text.begin(), text.end(), [](unsigned char ch) {
      return std::isdigit(ch) != 0;
    }))
  {throw std::invalid_argument("diagnostic ns must be a nonnegative decimal integer");}
  return std::stoll(text);
}

Json Parameter(const gazebo::physics::PhysicsEnginePtr & physics, const std::string & key)
{
  boost::any value;
  if (!physics->GetParam(key, value)) {
    return {{"available", false}};
  }
  Json result{{"available", true}, {"cpp_type", value.type().name()}};
  if (const auto p = boost::any_cast<double>(&value)) {result["value"] = *p;}
  else if (const auto p = boost::any_cast<int>(&value)) {result["value"] = *p;}
  else if (const auto p = boost::any_cast<unsigned int>(&value)) {result["value"] = *p;}
  else if (const auto p = boost::any_cast<bool>(&value)) {result["value"] = *p;}
  else if (const auto p = boost::any_cast<std::string>(&value)) {result["value"] = *p;}
  else {result["available"] = false; result["unsupported_return_type"] = true;}
  return result;
}
}  // namespace

class State
{
public:
  gazebo::physics::ModelPtr model;
  gazebo::physics::LinkPtr canonical;
  gazebo::physics::LinkPtr base;
  std::vector<gazebo::physics::JointPtr> joints;
  gazebo::event::ConnectionPtr before;
  gazebo::event::ConnectionPtr after;
  std::unique_ptr<std::FILE, decltype(&std::fclose)> output{nullptr, &std::fclose};
  std::string epoch;
  std::string robot;
  int64_t start_ns{0};
  int64_t end_ns{0};
  int64_t pair_clock_ns{0};
  uint64_t sequence{0};
  uint64_t pair_sequence{0};
  uint64_t before_record_sequence{0};
  bool pair_active{false};
  bool capture_complete{false};

  // These callbacks run on the world's physics-update thread. They never
  // publish ROS/Gazebo messages, call setters, or access another robot.
  void Write(const char * kind, int64_t clock_ns, Json row)
  {
    row.update({{"schema", "mr3-stop-response-observer-v1"}, {"kind", kind},
      {"epoch", epoch}, {"robot", robot}, {"record_sequence", ++sequence},
      {"sim_time_ns", clock_ns}, {"world_iterations", model->GetWorld()->Iterations()},
      {"wall_monotonic_ns", std::chrono::duration_cast<std::chrono::nanoseconds>(
          std::chrono::steady_clock::now().time_since_epoch()).count()}});
    const auto bytes = row.dump() + "\n";
    // Buffered stdio avoids a per-row fsync/fflush burden. Every completed
    // post-physics pair is flushed; any write failure invalidates the run.
    if (std::fwrite(bytes.data(), 1, bytes.size(), output.get()) != bytes.size()) {
      throw std::runtime_error("cannot write stop-response diagnostic");
    }
  }

  void Sample(const char * phase, int64_t clock_ns)
  {
    const auto physics = model->GetWorld()->Physics();
    Json solver;
    for (const auto & key : {"rms_error", "constraint_residual", "num_contacts"}) {
      solver[key] = Parameter(physics, key);
    }
    Json wheel = Json::array();
    for (const auto & joint : joints) {
      wheel.push_back({{"name", joint->GetScopedName()},
        {"position_rad", joint->Position(0)}, {"velocity_radps", joint->GetVelocity(0)},
        {"motor_velocity_target_radps", joint->GetParam("vel", 0)},
        {"motor_fmax_nm", joint->GetParam("fmax", 0)},
        {"axis_get_force_nm", joint->GetForce(0)}});
    }
    Write("sample", clock_ns, {{"phase", phase}, {"pair_sequence", pair_sequence},
      {"before_record_sequence", before_record_sequence},
      {"before_clock_ns", pair_clock_ns},
      {"model", {{"name", model->GetScopedName()}, {"world_pose", Pose(model->WorldPose())},
          {"world_linear_velocity_xyz", Vector(model->WorldLinearVel())},
          {"world_angular_velocity_xyz", Vector(model->WorldAngularVel())}}},
      {"canonical", Link(canonical)}, {"base", Link(base)}, {"joints_right_left", wheel},
      {"solver_diagnostics_world_scope", solver},
      {"scope", "read_only_physics_getters; motor target is GetParam(vel), not private driver desired or actuator feedback ACK"}});
  }

  void Before(const gazebo::common::UpdateInfo & info)
  {
    if (capture_complete) {return;}
    if (pair_active) {
      throw std::runtime_error("diagnostic prior physics pair not closed");
    }
    const auto clock_ns = Ns(info.simTime);
    if (clock_ns < start_ns) {return;}
    if (clock_ns > end_ns) {
      if (!capture_complete) {
        Write("capture_complete", clock_ns, {{"last_pair_sequence", pair_sequence}});
        if (std::fflush(output.get()) != 0) {throw std::runtime_error("diagnostic flush failed");}
        capture_complete = true;
      }
      return;
    }
    pair_active = true;
    pair_clock_ns = clock_ns;
    ++pair_sequence;
    before_record_sequence = sequence + 1;
    Sample("before_physics_after_collision", clock_ns);
  }

  void After()
  {
    if (!pair_active) {return;}
    const auto clock_ns = Ns(model->GetWorld()->SimTime());
    if (clock_ns != pair_clock_ns) {
      throw std::runtime_error("diagnostic pre/post physics world-clock mismatch");
    }
    Sample("world_update_end_after_physics_and_pose_propagation", clock_ns);
    pair_active = false;
    if (std::fflush(output.get()) != 0) {throw std::runtime_error("diagnostic flush failed");}
  }
};

class StopResponseObserver : public gazebo::ModelPlugin
{
public:
  ~StopResponseObserver() override
  {
    // Disconnect future weak callbacks. An in-flight callback owns State until
    // it returns, so its FILE/model pointers cannot be destroyed mid-read.
    auto state = std::move(state_);
    if (state) {state->before.reset(); state->after.reset();}
  }

  void Load(gazebo::physics::ModelPtr model, sdf::ElementPtr sdf) override
  {
    auto state = std::make_shared<State>();
    state->model = model;
    state->epoch = sdf->Get<std::string>("epoch", "").first;
    state->robot = sdf->Get<std::string>("robot", "").first;
    state->start_ns = ReadNanoseconds(sdf, "start_ns");
    state->end_ns = ReadNanoseconds(sdf, "end_ns");
    const auto path = sdf->Get<std::string>("output_path", "").first;
    if (state->epoch.empty() || state->robot.empty() || path.empty() ||
      state->start_ns < 0 || state->end_ns <= state->start_ns)
    {
      throw std::invalid_argument("diagnostic requires epoch/robot/exclusive output and finite increasing window");
    }
    // Names are explicitly taken from the same effective diagnostic SDF and
    // must be verified against its unchanged original driver plugin by admission.
    const auto base_name = sdf->Get<std::string>("base_link", "base_footprint").first;
    state->canonical = model->GetLink();
    state->base = model->GetLink(base_name);
    for (const auto & tag : {"right_joint", "left_joint"}) {
      auto joint = model->GetJoint(sdf->Get<std::string>(tag, "").first);
      if (!joint) {throw std::invalid_argument("diagnostic wheel joint missing");}
      state->joints.push_back(joint);
    }
    if (!state->canonical || !state->base) {throw std::invalid_argument("diagnostic body link missing");}
    const auto parent = std::filesystem::path(path).parent_path();
    if (!parent.empty()) {std::filesystem::create_directories(parent);}
    state->output.reset(std::fopen(path.c_str(), "wx"));
    if (!state->output) {throw std::runtime_error("cannot exclusively create diagnostic output");}
    auto physics = model->GetWorld()->Physics();
    Json params;
    for (const auto & key : {"solver_type", "cfm", "erp", "precon_iters", "iters", "sor",
      "contact_max_correcting_vel", "contact_surface_layer", "max_contacts", "max_step_size",
      "sor_lcp_tolerance", "use_dynamic_moi_rescaling", "friction_model", "world_step_solver"})
    {params[key] = Parameter(physics, key);}
    Dl_info loaded{};
    std::string library;
    if (dladdr(reinterpret_cast<void *>(&LibraryAnchor), &loaded) && loaded.dli_fname) {
      library = std::filesystem::canonical(loaded.dli_fname).string();
    }
    state->Write("configuration", Ns(model->GetWorld()->SimTime()), {
      {"loaded_library_path", library}, {"compiled_source_sha256", MR3_OBSERVER_SOURCE_SHA256},
      {"physics_type", physics->GetType()}, {"max_step_size_sec", physics->GetMaxStepSize()},
      {"physics_parameters", params}, {"gravity_xyz", Vector(model->GetWorld()->Gravity())},
      {"start_ns", state->start_ns}, {"end_ns", state->end_ns},
      {"canonical_name", state->canonical->GetScopedName()}, {"base_name", state->base->GetScopedName()},
      {"read_only", true}, {"per_packet_or_driver_private_sequence", false},
      {"axis_get_force_scope", "Joint::GetForce readback, not a promised motor/solver reaction wrench"}});
    state->before = gazebo::event::Events::ConnectBeforePhysicsUpdate(
      [weak = std::weak_ptr<State>(state)](const gazebo::common::UpdateInfo & info) {
        if (auto current = weak.lock()) {current->Before(info);}
      });
    state->after = gazebo::event::Events::ConnectWorldUpdateEnd(
      [weak = std::weak_ptr<State>(state)]() {
        if (auto current = weak.lock()) {current->After();}
      });
    state_ = std::move(state);
  }

private:
  std::shared_ptr<State> state_;
};
GZ_REGISTER_MODEL_PLUGIN(StopResponseObserver)
}  // namespace mr3_diagnostics
