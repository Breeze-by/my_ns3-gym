"""Private overlay for actual candidate imports; no main/World/raw calls."""
import json
import os
from pathlib import Path
import sys
import unittest
ROOT=Path('/home/zhuyulab/ns3-workspace')
W=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
BASE=Path(__file__).resolve().parent
os.environ['MR3_V3_ARTIFICIAL_TRACE_OUTPUT']=str(BASE/'toy_trace_v3.json')
SHADOW=BASE/'shadow/ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
os.environ['GIT_DIR']=str(ROOT/'.git')  # Private overlay only: immutable historical Git blobs.
sys.path.insert(0,str(SHADOW))
import mr3_learning
mr3_learning.__path__.append(str(W/'mr3_learning'))
import mr3_learning.tests
mr3_learning.tests.__path__.append(str(W/'mr3_learning/tests'))
from mr3_learning.preparation import identity
write=lambda path,value:Path(path).write_text(json.dumps(value,indent=2)+'\n')
write(BASE/'toy_identity_v1.json',identity(__import__('os').getpid()))
names=['mr3_learning.tests.test_reach_outward_cancel_v3_producer',
       'mr3_learning.tests.test_reach_outward_cancel_v2_producer']
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n) for n in names)
result=unittest.TextTestRunner(verbosity=2).run(suite)
write(BASE/'toy_result_v1.json',dict(passed=result.wasSuccessful(),tests=result.testsRun,
    failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),
    scope='artificial dispatcher/mask/producer only; no main, native, original input or scientific credit'))
raise SystemExit(0 if result.wasSuccessful() else 1)
