#!/usr/bin/python3
"""Read root's final actual binary custody into a TMP frozen binding; no native."""
import hashlib
import importlib.util
import json
from pathlib import Path
import time

D = Path(__file__).parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
receipt_path = W / 'report/assets/20261018_mr3_p2a0_v22_ray_box/binary/receipt_v1.json'
sha = lambda x: hashlib.sha256(x).hexdigest()
start = time.monotonic()
raw = receipt_path.read_bytes()
assert sha(raw) == 'e522c3000097fcf4fd5c065fbcbd074f0f56167cc82da663081d84b60f0d6670'
receipt = json.loads(raw)
assert receipt['passed'] is True
spec = importlib.util.spec_from_file_location('corrector_custody', D / 'mr3_v22_corrector_custody_v1.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
names = dict(zip(h.SOURCE_FIELDS, ('src/mr3_ray_box_corrector.cpp', 'src/mr3_ray_box_collision.cpp',
                                 'include/multi_robot/mr3_ray_box_collision.hpp')))
binding = {'schema': 'mr3-ray-box-corrector-binding-v1', 'status': 'ready',
    'monitor': {'path': str(h.MONITOR), 'sha256': h.MONITOR_SHA},
    'library': receipt['installed_library'], 'ode_library': receipt['actual_ode_library'],
    'sources': {key: {'path': receipt['sources'][name]['path'], 'sha256': receipt['sources'][name]['sha256']}
                for key, name in names.items()},
    'binary_receipt': {'path': str(receipt_path), 'sha256': sha(raw)},
    'ledger_filename': 'ray_box_corrector.jsonl',
    'world_names': {'open': 'p1c_open', 'rooms': 'p1c_rooms', 'corridors': 'p1c_corridors'},
    'scope': 'Ready binary/source identity only. Not plan/freeze/native admission; original34 mathematical and task gates remain required.'}
assert binding['library']['sha256'] == '7be79c7f3d2cac53a9d1692aa868d91d4b9977e2b7541203ce4ffe90c605a08f'
assert binding['library']['bytes'] == 389312
out = D / 'mr3_v22_corrector_binding_v1.json'
with out.open('x') as stream:
    json.dump(binding, stream, indent=2)
    stream.write('\n')
reader = h.Reader()
loaded = h.load_binding(out, reader)
libraries = {name: h.file_proof(loaded[name], reader) for name in ('library', 'ode_library')}
assert all(value['sha256'].encode() in reader(Path(loaded['library']['path'])) for value in loaded['sources'].values())
reader.finish()
assert receipt_path.read_bytes() == raw
result = {'schema': 'mr3-v22-corrector-actual-binding-compatibility-v1', 'passed': True,
    'scope': 'Read-only actual source3/SO/ODE/binary receipt/header macro bytes; no dlopen, ODE call, fake producer/native/mapping/ledger or old consumer invoked.',
    'binding': {'path': str(out), 'sha256': sha(out.read_bytes())}, 'libraries': libraries,
    'source3_macros_present': True, 'input_bindings': reader.bindings,
    'helper_sha256': sha((D / 'mr3_v22_corrector_custody_v1.py').read_bytes()),
    'source_sha256': sha(Path(__file__).read_bytes()), 'wall_seconds': time.monotonic() - start}
proof = D / 'actual_binding_compatibility_v1.json'
with proof.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({'passed': True, 'binding_sha256': sha(out.read_bytes()),
                  'compatibility_receipt': str(proof), 'sha256': sha(proof.read_bytes())}))
