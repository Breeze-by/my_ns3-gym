"""Version-only V15 coordinator drafts; no Git write, native or formal execution."""
import ast
import copy
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
A14 = W + 'report/assets/20261017_mr3_p2a0_v14/'
A15 = W + 'report/assets/20261017_mr3_p2a0_v15/'
TEMP = Path('/tmp')
DRAFT = TEMP / 'mr3_p2a0_v15_matrix_draft_v1'
NAMES = (
    'mr3_p2a0_v14_buildproof_preflight.py', 'mr3_p2a0_v14_launch_stage.py',
    'mr3_p2a0_v14_audit_stage.py', 'mr3_v14_multiepoch_closure_binary_review_v1.py',
    'mr3_p2a0_v14_cross_stage_mapping_monitor_v1.py',
    'mr3_p2a0_v14_plan_launcher_tests_v1.py', 'mr3_p2a0_v14_audit_stage_tests_v1.py',
    'mr3_v14_shim_path_adapter_tests_v1.py', 'mr3_v14_nested_closure_read_tests_v1.py')

OLD_REQUIRE = """    require(audit.get('passed') is True and audit.get('all_submitted_jobs_finished') is True
            and audit.get('runner_errors') == [] and isinstance(commands, list) and commands
            and any(item.get('required_success') is True for item in commands)
            and all(
                type(item.get('required_success')) is bool and (
                    item['required_success'] is False or item.get('passed') is True
                    and type(item.get('returncode')) is int and item['returncode'] == 0)
                for item in commands), 'actual audit runner did not close every required job')"""
NEW_REQUIRE = """    require(audit.get('all_submitted_jobs_finished') is True
            and audit.get('runner_errors') == [] and isinstance(commands, list) and commands
            and any(item.get('required_success') is True for item in commands)
            and all(type(item.get('required_success')) is bool for item in commands),
            'actual audit runner jobs unfinished or invalid runner records')
    require(
        audit.get('passed') is True and all(
            item['required_success'] is False or item.get('passed') is True
            and type(item.get('returncode')) is int and item['returncode'] == 0
            for item in commands),
        'actual required audit gates failed after all submitted jobs finished')"""

NEW_TESTS = '''    def test_finished_real_gate_failure_is_not_reported_as_unfinished_jobs(self):
        self.prepare(audit_fail='interface')
        self.assertEqual(self.run_main(), 1)
        final = self.ledger()[-1]
        self.assertIn(
            'required audit gates failed after all submitted jobs finished', final['error'])
        self.assertEqual(final['later_stages'], ['terminal', 'reset', 'deadline'])
        self.assert_closed()

    def test_unfinished_runner_is_distinct_and_cannot_start_later_stage(self):
        self.prepare(unfinished_jobs='interface')
        self.assertEqual(self.run_main(), 1)
        final = self.ledger()[-1]
        self.assertIn('jobs unfinished or invalid runner records', final['error'])
        self.assertEqual(final['later_stages'], ['terminal', 'reset', 'deadline'])
        self.assertFalse(any(row.get('stage') in ('terminal', 'reset', 'deadline')
                             for row in self.ledger()))
        self.assert_closed()
'''


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def version(raw):
    return raw.replace(b'v14', b'v15').replace(b'V14', b'V15')


def unversion(raw):
    return raw.replace(b'v15', b'v14').replace(b'V15', b'V14')


def main():
    base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    assert base.startswith('f7376d0'), 'draft must derive from the actual closed V14 commit'

    def git(relative):
        return subprocess.check_output(['git', 'show', base + ':' + relative], cwd=ROOT)

    DRAFT.mkdir()
    independent = DRAFT / 'independent'
    independent.mkdir()
    records = []
    for name in NAMES:
        old = git(A14 + 'independent/' + name)
        path = independent / version(name.encode()).decode()
        raw = version(old)
        assert unversion(raw) == old
        with path.open('xb') as stream:
            stream.write(raw)
        ast.parse(raw)
        records.append(dict(source=A14 + 'independent/' + name, source_git=base,
                            source_sha256=sha(old), draft=str(path), draft_sha256=sha(raw),
                            reverse_version_bytes_equal=True))
    plan_original = json.loads(git(A14 + 'predeclared_plan_v14.json'))
    plan = json.loads(version(json.dumps(plan_original).encode()))
    # Immutable bindings remain the old real mappings. New/updated pins need root review.
    plan['independent_source_bindings'] = copy.deepcopy(plan_original['independent_source_bindings'])
    plan['readiness'] = dict(
        status='draft_pending_root_final_review', freeze=None,
        pending_bindings=['root reviewed current source pins and ENV digest',
                          'legal dynamic cancel v4 producer/32step metadata audit wrappers',
                          'root review of new versioned coordinators and final clean pushed freeze'],
        no_native_or_formal_authorized_by_this_template=True)
    plan['new_source_bindings_pending'] = [A15 + 'independent/' + row['draft'].rsplit('/', 1)[-1]
                                           for row in records]
    plan['source_binding'] = 'Pending root-reviewed V15 exact40; no V15 freeze/admission claimed'
    plan['draft_baseline'] = dict(
        source_commit=base, source_plan_sha256=sha(git(A14 + 'predeclared_plan_v14.json')),
        previous_105_bindings_kept_as_history_not_current_source_claim=True,
        unchanged_workload_steps=32, unchanged_api_ceiling=608, unchanged_action_ceiling=596,
        unchanged_native_wall_ceiling=18000,
        legal_dynamic_cancel_v4_pending=True,
        command_scope='Current v3 command is a historical placeholder, not V15 final workload.')
    with (DRAFT / 'predeclared_plan_v15.json').open('x') as stream:
        json.dump(plan, stream, indent=2, allow_nan=False)
        stream.write('\n')

    def archived_original(name):
        for folder in ('native_originals_v1/', 'offline_originals_v1/originals/'):
            relative = A14 + 'independent/' + folder + name + '.gz'
            if (ROOT / relative).exists():
                return gzip.decompress(git(relative)), relative
        raise ValueError('missing original V14 support source: ' + name)

    old_parent, parent_source = archived_original('mr3_p2a0_v14_run_matrix_v1.py')
    parent = version(old_parent).decode()
    assert parent.count(OLD_REQUIRE) == 1
    parent = parent.replace(OLD_REQUIRE, NEW_REQUIRE)
    parent_path = TEMP / 'mr3_p2a0_v15_run_matrix_v1.py'
    with parent_path.open('x') as stream:
        stream.write(parent)
    assert unversion(parent.replace(NEW_REQUIRE, OLD_REQUIRE).encode()) == old_parent
    old_tests, tests_source = archived_original('mr3_p2a0_v14_run_matrix_v1_tests.py')
    tests = version(old_tests).decode()
    original_fake_flag = "'all_submitted_jobs_finished':True,"
    changed_fake_flag = "'all_submitted_jobs_finished':behavior.get('unfinished_jobs')!=stage,"
    assert tests.count(original_fake_flag) == 1
    tests = tests.replace(original_fake_flag, changed_fake_flag)
    marker = "\n\nif __name__ == '__main__':"
    assert tests.count(marker) == 1
    tests = tests.replace(marker, '\n' + NEW_TESTS + marker)
    test_path = TEMP / 'mr3_p2a0_v15_run_matrix_v1_tests.py'
    with test_path.open('x') as stream:
        stream.write(tests)
    restored = tests.replace('\n' + NEW_TESTS + marker, marker).replace(
        changed_fake_flag, original_fake_flag)
    assert unversion(restored.encode()) == old_tests
    for source in (parent.encode(), tests.encode()):
        ast.parse(source)
    # Exhaustively show that splitting the diagnostic require preserves its boolean gate.
    truth_table_cases = 0
    for aggregate in (False, True):
        for complete in (False, True):
            for valid_runner in (False, True):
                for valid_flags in (False, True):
                    for required_success in (False, True):
                        old = aggregate and complete and valid_runner and valid_flags and required_success
                        new = (complete and valid_runner and valid_flags) and (
                            aggregate and required_success)
                        assert old == new
                        truth_table_cases += 1
    result = dict(
        schema='mr3-v15-coordinator-draft-generation-v1', passed=True, source_commit=base,
        draft_root=str(DRAFT), records=records,
        parent=dict(source=parent_source, source_sha256=sha(old_parent), path=str(parent_path),
                    draft_sha256=sha(parent.encode()), authorized_change='Equivalent split of '
                    'completion/schema and required gate outcome diagnostic requires only.'),
        parent_tests=dict(source=tests_source, source_sha256=sha(old_tests), path=str(test_path),
                          draft_sha256=sha(tests.encode()), inherited_tests=7, new_diagnostic_tests=2),
        diagnostic_gate_boolean_truth_table_cases=truth_table_cases,
        all_code_reverse_version_bytes_equal_except_explicit_parent_diagnostic=True,
        new_workload_version='pending legal-cancel-v4 final producer/wrappers',
        no_current_source_pins_guessed=True, canonical_written=False, native_admission=False,
        scope='Versioned /tmp drafts only; old immutable A13 Shim/drive/math references remain. '
              'Historical bindings/command are placeholders and cannot launch without root finalization.')
    with (DRAFT / 'generation_v1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'records'}, indent=2))


if __name__ == '__main__':
    main()
