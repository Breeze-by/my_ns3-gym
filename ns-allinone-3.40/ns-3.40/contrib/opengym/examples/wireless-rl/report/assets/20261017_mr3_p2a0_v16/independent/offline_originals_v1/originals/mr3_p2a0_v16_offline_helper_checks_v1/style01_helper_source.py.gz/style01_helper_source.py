"""Prepare one V16 CPU-originals archive after root confirms every writer stopped.

No native, DDS, audit, Git staging or commit calls. Never overwrite originals.
Execution requires --writers-stopped and a new canonical output directory.
The author only prepared/compiled this helper; root owns execution authorization.
"""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
ASSETS = ROOT / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
                 'report/assets')
OLD_ROOTS = (ASSETS / '20261017_mr3_p2a0_v15', ASSETS / '20261017_mr3_p2a0_v14',
             ASSETS / '20261017_mr3_p2a0_v13')
DESTINATION = ASSETS / '20261017_mr3_p2a0_v16/independent/offline_originals_v1'
TEMP = Path('/tmp')
OWN_OUTPUTS = set()
ADDITIONAL_INDEX = TEMP / 'mr3_p2a0_v16_additional_closeout_originals_v1.json'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def signature(value):
    return {'device': value.st_dev, 'inode': value.st_ino,
            'size': value.st_size, 'mtime_ns': value.st_mtime_ns,
            'ctime_ns': value.st_ctime_ns}


def capture(path):
    """Bind bytes to one open regular file; reject swaps, mutations and symlinks."""
    with path.open('rb') as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode), 'not a regular file: ' + str(path))
        raw = stream.read()
        after = os.fstat(stream.fileno())
    path_stat = path.lstat()
    require(signature(before) == signature(after) == signature(path_stat)
            and not stat.S_ISLNK(path_stat.st_mode), 'input changed: ' + str(path))
    return raw, signature(after)


def decoded_original(row, encoded):
    """Explicit codec wins even for identity gzip; missing codec uses the raw SHA."""
    if 'encoding' in row or 'compression' in row:
        codec = row.get('encoding', row.get('compression'))
        require(codec in ('identity', 'gzip'), 'unknown selected codec: ' + str(codec))
        require('encoding' not in row or 'compression' not in row
                or row['encoding'] == row['compression'], 'conflicting selected codecs')
    else:
        codec = 'identity' if sha(encoded) == row['raw_sha256'] else 'gzip'
    decoded = gzip.decompress(encoded) if codec == 'gzip' else encoded
    require(sha(decoded) == row['raw_sha256'], 'selected raw SHA mismatch')
    return codec, decoded


def old_originals():
    """Dedup only verified selected originals, never an unchecked manifest claim."""
    by_digest, manifests = {}, []
    roots = tuple(root.resolve() for root in OLD_ROOTS)
    require(all(root.is_dir() for root in roots), 'old canonical source root missing')
    paths = sorted({path for root in OLD_ROOTS for path in root.rglob('*manifest*.json')})
    for path in paths:
        raw, info = capture(path)
        value = json.loads(raw)
        if not isinstance(value, dict):
            continue
        rows = value.get('entries', value.get('files', []))
        if not isinstance(rows, list):
            continue
        manifests.append({'path': str(path), 'sha256': sha(raw), 'stat': info})
        for row in rows:
            if not isinstance(row, dict):
                continue
            selected = row.get('selected', row.get('selected_path', row.get('path')))
            digest = row.get('raw_sha256')
            if not isinstance(selected, str) or not isinstance(digest, str):
                continue
            selected = Path(selected)
            if not selected.is_absolute():
                selected = (ROOT / selected if selected.parts[0] == 'ns-allinone-3.40'
                            else path.parent / selected)
            require(any(selected.resolve().is_relative_to(root) for root in roots),
                    'old selected original escapes declared roots: ' + str(selected))
            encoded, _ = capture(selected)
            expected_encoded = row.get(
                'encoded_sha256', row.get('selected_encoded_sha256',
                                         row.get('selected_sha256', row.get('sha256'))))
            require(expected_encoded is None or sha(encoded) == expected_encoded,
                    'old selected encoded SHA mismatch: ' + str(selected))
            codec, decoded = decoded_original(row, encoded)
            by_digest.setdefault(digest, {
                'manifest': str(path), 'manifest_sha256': sha(raw),
                'original_source': row.get('source'), 'selected': str(selected),
                'selected_encoded_sha256': sha(encoded), 'raw_sha256': digest,
                'encoding': codec, 'raw_bytes': len(decoded)})
    return by_digest, manifests


def excluded(path):
    """Exclude mutable state/cache/ELF and fixture worktrees, retain actual logs."""
    if path.resolve() in OWN_OUTPUTS:
        return 'current archive stdout/stderr, excluded while this process writes it'
    parts = path.relative_to(TEMP).parts
    name = path.name
    if path.is_symlink():
        return 'symlink, never dereferenced'
    if any(part in ('__pycache__', '.git', '.pytest_cache', 'node_modules') for part in parts):
        return 'cache or mock Git internals'
    if path.suffix in ('.pyc', '.pyo'):
        return 'compiled Python cache'
    if any(marker in name for marker in ('root_continuation_state', 'active_state',
                                         'current_state', '.lock', '.pid')):
        return 'mutable continuation/active state or lock'
    if any(part.startswith(('mr3_v16_scheduler_fixture_', 'mr3_v16_matrix_cpu_'))
           or 'mockworktree' in part or 'mock_worktree' in part for part in parts):
        return 'temporary mock worktree; exact fixture constructor retained separately'
    if any(part == 'mock' or part.startswith('mock_') for part in parts[:-1]):
        return 'temporary mock directory; actual test code, FAIL reports and consoles kept'
    if 'fake_assets' in parts:
        return 'fake coordinator worktree, reproduced by retained fixture source'
    if 'fixtures' in parts and 'runtime' in parts:
        if not (name.endswith('_remaining_matrix_v1.jsonl')
                or '_controller_' in name and name.endswith('.log')):
            return 'fake runtime leaf/worktree; retain actual invocation ledger and consoles'
    if 'ros_view' in parts and name not in {
            'mr3_fastdds_loopback_udp.xml', 'test_fastdds_environment.py',
            'control.py', 'mr3_motion_safety.py', 'test_navigation_peer_geometry.py'}:
        return 'synthetic package view/stub; original fixture constructor and changed sources kept'
    if any('selected_native' in part or part.endswith('_selected') for part in parts):
        return 'native selected directory outside offline archive scope'
    return None


def source_paths():
    found, omitted = [], []
    tops = set(TEMP.glob('mr3_*v16*')) | set(TEMP.glob('root_mr3_v16*'))
    for top in sorted(tops):
        if top.is_symlink():
            omitted.append({'source': str(top), 'reason': 'symlink'})
            continue
        paths = sorted(top.rglob('*')) if top.is_dir() else [top]
        for path in paths:
            if path.is_dir():
                continue
            reason = excluded(path)
            if reason:
                omitted.append({'source': str(path), 'reason': reason})
            else:
                found.append(path)
    require(ADDITIONAL_INDEX.is_file(), 'explicit root closeout originals index missing')
    raw, _ = capture(ADDITIONAL_INDEX)
    for row in json.loads(raw)['entries']:
        path = Path(row['source'])
        require(path.is_absolute() and path.is_relative_to(TEMP),
                'additional original is not under /tmp: ' + str(path))
        payload, _ = capture(path)
        require(sha(payload) == row['sha256'] and len(payload) == row['bytes'],
                'additional indexed original changed: ' + str(path))
        reason = excluded(path)
        if reason:
            omitted.append({'source': str(path), 'reason': reason})
        else:
            found.append(path)
    return sorted(set(found)), omitted


def new_json(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--writers-stopped', action='store_true',
                      help='root assertion that all V16 offline writers have stopped')
    mode.add_argument('--verify-old-manifests', action='store_true')
    parser.add_argument('--review-output', type=Path)
    args = parser.parse_args()
    if args.verify_old_manifests:
        require(args.review_output and args.review_output.is_absolute()
                and args.review_output.is_relative_to(TEMP), 'new /tmp review output required')
        old, manifests = old_originals()
        result = {'passed': True, 'schema': 'mr3-v16-prior-originals-readonly-review-v1',
                  'old_roots': [str(root) for root in OLD_ROOTS], 'manifests': manifests,
                  'distinct_verified_raw_sha256': len(old), 'canonical_written': False,
                  'source_sha256': sha(capture(Path(__file__))[0]),
                  'scope': 'Only immutable selected-original custody verification; no V16 '
                           'source capture/publish, formal audit, native or admission credit.'}
        new_json(args.review_output, result)
        print(json.dumps({'passed': True, 'manifests': len(manifests),
                          'distinct_verified_raw_sha256': len(old),
                          'review_output': str(args.review_output)}))
        return 0
    require(args.review_output is None, '--review-output only applies to read-only verification')
    require(args.writers_stopped, 'writers must stop before collecting any source')
    for descriptor in (1, 2):
        target = Path('/proc/self/fd/' + str(descriptor))
        try:
            output_path = Path(os.readlink(target))
            if output_path.is_absolute():
                OWN_OUTPUTS.add(output_path.resolve())
        except OSError:
            pass
    require(not DESTINATION.exists(), 'archive already exists; never overwrite')
    own_path = Path(__file__).resolve()
    own_raw, own_stat = capture(own_path)
    paths, omitted = source_paths()
    require(own_path in paths, 'archive helper must preserve itself')
    # Complete all source reads and old-custody validation before publishing anything.
    old, old_manifests = old_originals()
    captures, duplicate = [], []
    for path in paths:
        raw, info = capture(path)
        if raw.startswith(b'\x7fELF'):
            omitted.append({'source': str(path), 'reason': 'ELF executable/library excluded'})
            continue
        digest = sha(raw)
        if digest in old:
            duplicate.append({'source': str(path), 'raw_sha256': digest,
                              'raw_bytes': len(raw), 'source_stat': info,
                              'already_canonical': old[digest]})
            continue
        captures.append((path, raw, info))
    # Detect any writer still changing the captured originals before creating output.
    for path, raw, info in captures:
        second, now = capture(path)
        require(now == info and second == raw, 'source changed before archive: ' + str(path))
    for row in duplicate:
        raw, now = capture(Path(row['source']))
        require(now == row['source_stat'] and sha(raw) == row['raw_sha256'],
                'deduplicated source changed: ' + row['source'])
    DESTINATION.mkdir(parents=True, exist_ok=False)
    entries = []
    for path, raw, info in captures:
        relative = path.relative_to(TEMP)
        selected = DESTINATION / 'originals' / (str(relative) + '.gz')
        selected.parent.mkdir(parents=True, exist_ok=True)
        encoded = gzip.compress(raw, compresslevel=9, mtime=0)
        with selected.open('xb') as stream:
            stream.write(encoded)
        saved, _ = capture(selected)
        decoded = gzip.decompress(saved)
        require(saved == encoded and decoded == raw, 'archive roundtrip mismatch')
        final_raw, final_stat = capture(path)
        require(final_raw == raw and final_stat == info,
                'source changed after archive: ' + str(path))
        entries.append({'source': str(path), 'selected': str(selected.relative_to(ROOT)),
                        'encoding': 'gzip',
                        'raw_bytes': len(raw), 'raw_sha256': sha(raw),
                        'encoded_bytes': len(saved), 'encoded_sha256': sha(saved),
                        'decoded_bytes': len(decoded), 'decoded_sha256': sha(decoded),
                        'source_stat_before': info, 'source_stat_after': final_stat,
                        'source_stable': True})
    for entry in entries:
        raw, now = capture(Path(entry['source']))
        require(now == entry['source_stat_before'] and sha(raw) == entry['raw_sha256'],
                'source changed at final manifest boundary: ' + entry['source'])
    for item in old_manifests:
        raw, now = capture(Path(item['path']))
        require(now == item['stat'] and sha(raw) == item['sha256'], 'old manifest changed')
    for row in duplicate:
        previous = row['already_canonical']
        raw, _ = capture(Path(previous['selected']))
        require(sha(raw) == previous['selected_encoded_sha256'], 'old selected bytes changed')
        decoded_original(previous, raw)
    require(capture(own_path) == (own_raw, own_stat), 'archive helper source changed')
    manifest = {'schema': 'mr3-v16-offline-originals-v1',
                'scope': 'CPU source/patch/argv/receipts/log originals only; no native credit. '
                         'Historical FAIL and observer/style corrections retained without '
                         'relabeling.',
                'archive_argv': [sys.executable, *sys.argv], 'archive_cwd': str(Path.cwd()),
                'wall_monotonic_ns': time.monotonic_ns(),
                'writers_stopped_asserted_by_root': True,
                'source': str(own_path), 'source_sha256': sha(own_raw),
                'encoding': 'gzip original bytes once, mtime0; decoded bytes equal source '
                            'raw bytes',
                'entries': entries, 'deduplicated_prior': duplicate,
                'old_canonical_roots': [str(root) for root in OLD_ROOTS],
                'old_manifests': old_manifests, 'exclusions': omitted,
                'counts': {'selected': len(entries), 'deduplicated_prior': len(duplicate),
                           'excluded': len(omitted),
                           'raw_bytes': sum(r['raw_bytes'] for r in entries),
                           'encoded_bytes': sum(r['encoded_bytes'] for r in entries)},
                'self_exclusion': 'This manifest is not part of its own entries. Cache excluded.'}
    new_json(DESTINATION / 'manifest.json', manifest)
    print(json.dumps({'manifest': str(DESTINATION / 'manifest.json'),
                      'manifest_sha256': sha((DESTINATION / 'manifest.json').read_bytes()),
                      'counts': manifest['counts']}, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
