"""Explicit one-shot V19 descriptive analysis wrapper; only run after root GO.

No native/ROS/DDS launch, timeout, process signal, retry or task PASS is issued.
"""
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time
import traceback

ROOT = Path('/home/zhuyulab/ns3-workspace')
HELPER = Path('/tmp/mr3_p2a0_v19_paired_zero_motor_analysis_v1.py')
HELPER_SHA = '025a4aa566f352b9c33fecaaf5c2299b919c98a6cd2061f5b8a38c473aed43e6'
FORMAL_SHA = 'e61ce4e00907ab35e196f7abe9fadfd9da099af3542f98dc773d593c33ca2b65'
PLAN = ROOT / (
    'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/'
    '20261018_mr3_p2a0_v19/predeclared_plan_v19.json')
PLAN_SHA = 'd9dede80fcdf7521c66f37c6400acd3a5d2f0eb837472412d05197f1441d12a9'
FREEZE = '72d0465ddd1bbee09af117cfd9d89b7e729f8578'
REPORTS = (
    Path('/tmp/mr3_p2a0_v19_baseline_observer_review.json'),
    Path('/tmp/mr3_p2a0_v19_iters150_observer_review.json'))
OUTPUT = Path('/tmp/mr3_p2a0_v19_paired_zero_motor_description_v1.json')
STDOUT = Path('/tmp/mr3_p2a0_v19_paired_zero_motor_description_v1.stdout')
STDERR = Path('/tmp/mr3_p2a0_v19_paired_zero_motor_description_v1.stderr')
RECEIPT = Path('/tmp/mr3_p2a0_v19_paired_zero_motor_analysis_execution_v1.json')
ARGV = ['/usr/bin/python3', '-B', str(HELPER), '--plan', str(PLAN), '--freeze', FREEZE,
        '--baseline-review', str(REPORTS[0]), '--contrast-review', str(REPORTS[1]),
        '--output', str(OUTPUT)]


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def stat_identity(value):
    return [value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns]


def snapshot(path):
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    require(stat_identity(before) == stat_identity(after), 'small input changed while read')
    return raw, {'sha256': digest(raw), 'bytes': len(raw),
                 'stat_identity': stat_identity(before)}


def child_usage():
    usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    return {'user_cpu_seconds': usage.ru_utime, 'system_cpu_seconds': usage.ru_stime,
            'maximum_resident_kib': usage.ru_maxrss,
            'input_blocks': usage.ru_inblock, 'output_blocks': usage.ru_oublock}


def main():
    for path in (OUTPUT, STDOUT, STDERR, RECEIPT):
        require(not path.exists(), 'refusing to replace existing artifact: ' + str(path))
    environment = {'PATH': '/usr/bin:/bin', 'HOME': os.environ['HOME'],
                   'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8',
                   'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1'}
    before, after = {}, {}
    exception = None
    child_exit = None
    child_spawn_requested = False
    child_started = False
    child_wall = None
    analysis_completed = False
    description_sha = None
    started_ns = time.monotonic_ns()
    usage_before = child_usage()
    wrapper_before = snapshot(Path(__file__))[1]
    with STDOUT.open('xb') as out, STDERR.open('xb') as err:
        try:
            # First inspect only the two small formal receipts. Missing/non-PASS
            # data refuses analysis without spawning the helper or reading raw.
            for stage, path in zip(('baseline', 'iters150'), REPORTS):
                raw, before[str(path)] = snapshot(path)
                report = json.loads(raw)
                require(type(report) is dict
                        and report.get('schema') == 'mr3-independent-stop-observer-review-v1'
                        and report.get('passed') is True
                        and type(report.get('errors')) is list and report['errors'] == [],
                        'formal observer receipt is not PASS: ' + stage)
                require(report.get('freeze') == FREEZE and report.get('stage') == stage
                        and report.get('consumer_sha256') == FORMAL_SHA,
                        'formal observer identity differs: ' + stage)
                formal_plan = report.get('plan_path')
                require(type(formal_plan) is str and Path(formal_plan).resolve() == PLAN.resolve(),
                        'formal observer plan path differs: ' + stage)
                require(report['inputs'][formal_plan]['sha256'] == PLAN_SHA,
                        'formal observer plan SHA differs: ' + stage)
            for path, expected in ((HELPER, HELPER_SHA), (PLAN, PLAN_SHA)):
                _, before[str(path)] = snapshot(path)
                require(before[str(path)]['sha256'] == expected, 'sealed source/plan differs')
            child_started_ns = time.monotonic_ns()
            child_spawn_requested = True
            child = subprocess.run(ARGV, cwd=ROOT, env=environment, stdout=out, stderr=err)
            child_started = True
            child_wall = (time.monotonic_ns() - child_started_ns) / 1e9
            child_exit = child.returncode
            if OUTPUT.exists():
                raw, output_proof = snapshot(OUTPUT)
                description_sha = output_proof['sha256']
                result = json.loads(raw)
                analysis_completed = (type(result) is dict
                                      and result.get('analysis_completed') is True
                                      and result.get('preparation_matrix_credit') is False
                                      and result.get('freeze') == FREEZE
                                      and result.get('plan_sha256') == PLAN_SHA)
        except Exception as error:
            exception = {'type': type(error).__name__, 'message': str(error),
                         'traceback': traceback.format_exc()}
        finally:
            # Only small source/receipt files are re-read here, never raw captures.
            for path in before:
                try:
                    _, after[path] = snapshot(Path(path))
                except Exception as error:
                    after[path] = {'error_type': type(error).__name__, 'message': str(error)}
    usage_after = child_usage()
    stopped_ns = time.monotonic_ns()
    wrapper_after = snapshot(Path(__file__))[1]
    stable = before == after and wrapper_before == wrapper_after
    stdout_raw, stdout_proof = snapshot(STDOUT)
    stderr_raw, stderr_proof = snapshot(STDERR)
    del stdout_raw, stderr_raw
    receipt = {
        'schema': 'mr3-v19-paired-description-execution-v1',
        'wrapper_completed': True, 'child_spawn_requested': child_spawn_requested,
        'child_started': child_started,
        'analysis_completed': analysis_completed and child_exit == 0 and stable,
        'task_or_matrix_pass_claim': False, 'exit_code': child_exit,
        'exception': exception, 'argv': ARGV, 'cwd': str(ROOT), 'environment': environment,
        'monotonic_start_ns': started_ns, 'monotonic_end_ns': stopped_ns,
        'wrapper_wall_seconds': (stopped_ns - started_ns) / 1e9,
        'child_wall_seconds': child_wall,
        'children_resource_before': usage_before, 'children_resource_after': usage_after,
        'child_user_cpu_seconds': usage_after['user_cpu_seconds'] - usage_before['user_cpu_seconds'],
        'child_system_cpu_seconds': (
            usage_after['system_cpu_seconds'] - usage_before['system_cpu_seconds']),
        'inputs_before': before, 'inputs_after': after, 'small_inputs_stable': stable,
        'wrapper_before': wrapper_before, 'wrapper_after': wrapper_after,
        'stdout': {'path': str(STDOUT), **stdout_proof},
        'stderr': {'path': str(STDERR), **stderr_proof},
        'description_output': str(OUTPUT), 'description_sha256': description_sha,
        'scope': ('Synchronous descriptive child only; no timeout, signal, retry, native or '
                  'ROS/DDS call. Original task/physical/matrix verdicts are unchanged.')}
    with RECEIPT.open('x') as stream:
        json.dump(receipt, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'receipt': str(RECEIPT), 'sha256': digest(RECEIPT.read_bytes()),
                      'analysis_completed': receipt['analysis_completed'],
                      'child_exit_code': child_exit, 'task_or_matrix_pass_claim': False}), flush=True)
    return 0 if receipt['analysis_completed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
