import ast,hashlib,json,pathlib,subprocess
R=pathlib.Path("/home/zhuyulab/ns3-workspace");D=pathlib.Path("/tmp/mr3_p2a0_v16_matrix_draft_v1");C=pathlib.Path("/tmp/mr3_p2a0_v16_matrix_mechanical_checks_v1")
sha=lambda raw:hashlib.sha256(raw).hexdigest()
generation=json.loads((D/"generation_v1.json").read_bytes());rows=[]
for row in generation["files"]:
 raw=(subprocess.check_output(["git","show",row["source_git"]],cwd=R) if "source_git" in row else pathlib.Path(row["source"]).read_bytes())
 current=pathlib.Path(row["draft"]).read_bytes();reverse=current.replace(b"v16",b"v15").replace(b"V16",b"V15")
 assert sha(raw)==row["source_sha256"] and sha(current)==row["draft_sha256"]
 assert reverse==raw
 assert ast.dump(ast.parse(reverse),include_attributes=False)==ast.dump(ast.parse(raw),include_attributes=False)
 rows.append(dict(draft=row["draft"],source_sha256=sha(raw),draft_sha256=sha(current),reverse_bytes_equal=True,whole_AST_equal=True))
old=json.loads((R/"ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v15/predeclared_plan_v15.json").read_bytes());plan=json.loads((D/"predeclared_plan_v16.json").read_bytes())
assert plan["independent_source_bindings"]==old["independent_source_bindings"] and len(plan["independent_source_bindings"])==121
allowed=plan["authorized_current_binding_refresh_pending"];assert len(allowed)==4 and {pathlib.Path(p).name for p in allowed}=={"benchmark.py","test_preparation_comparison.py","audit_preparation.py","audit_ppo.py"}
for key in ["unchanged_gates","physical_response_criteria","settled_turn_criteria","angular_interface_criteria","angular_reset_criteria","full_execution_model_failfast","pilot_budget_unchanged","max_api_records","max_submitted_script_decisions","max_total_wall_seconds"]:assert plan[key]==old[key],key
assert plan["readiness"]["status"]=="draft_pending_root_final_review" and plan["readiness"]["pending_bindings"]
assert [old[k] for k in ["max_api_records","max_submitted_script_decisions","max_total_wall_seconds"]]==[608,596,18000]
result=dict(passed=True,files=rows,exact_reverse_bytes_and_AST_equal=True,historical_binding_values_retained_pending_authorized_refresh=121,authorized_current_refresh_paths=allowed,remaining_old_bindings_required_unchanged=117,budgets=[608,596,18000],draft_plan_sha256=sha((D/"predeclared_plan_v16.json").read_bytes()),scope="Only temporary mechanical coordinator source and draft metadata checks. No canonical promotion, native/formal execution, final fixture ID or admission.")
output=C/"reverse_AST_v1.json"
with output.open("x") as stream:json.dump(result,stream,indent=2);stream.write("\n")
print(json.dumps({k:v for k,v in result.items() if k!="files"},indent=2));print("OUTPUT_SHA",sha(output.read_bytes()))
