import hashlib
import json
from pathlib import Path

ROOT = Path('/home/zhuyulab/ns3-workspace')
HANDOFF = Path('/tmp/mr3_p2a0_v21_ray_proposal_v4/handoff_v2.json')
assert hashlib.sha256(HANDOFF.read_bytes()).hexdigest() == '20a473e11dd866a4e6b7010c537fda386919f1e49483d00b57ee9c5608c8a12b'
handoff = json.loads(HANDOFF.read_text())
assert handoff['source_writers_stopped'] and len(handoff['promotion_files']) == 11
A = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v21_ray'
rows = []
for row in handoff['promotion_files']:
    source, target = Path(row['source']), ROOT / row['prospective_canonical']
    raw = source.read_bytes()
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
    if target.name == 'gazebo_multirobot_mapping_with_nav2.launch.py':
        assert hashlib.sha256(target.read_bytes()).hexdigest() == handoff['launch_base_sha256']
    else:
        assert not target.exists(), target
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    assert target.read_bytes() == raw
    if target.name == 'gazebo_multirobot_mapping_with_nav2.launch.py':
        installed = ROOT / 'ros2_ws/ros2-multi-robot-automap/install/multi_robot/share/multi_robot/launch' / target.name
        assert installed.read_bytes() == raw
    rows.append(row)
plan_path = A / 'predeclared_plan_v21_ray.json'
draft = json.loads(plan_path.read_text())
assert draft['status'] == 'draft_not_native_admission'
assert len(draft['independent_source_bindings']) == 173
old = json.loads((A.parent / '20261018_mr3_p2a0_v20_sensor/predeclared_plan_v20_sensor.json').read_text())
current = {row['path']: row['sha256'] for row in draft['independent_source_bindings']}
assert len(current) == 173
assert all(current[row['path']] == row['sha256'] for row in old['independent_source_bindings'])
for row in draft['independent_source_bindings']:
    assert hashlib.sha256((ROOT / row['path']).read_bytes()).hexdigest() == row['sha256'], row['path']
final = {**draft, 'status': 'ready', 'pending': [], 'new_source_bindings_pending': []}
assert {key for key in draft if draft[key] != final[key]} == {'status', 'pending', 'new_source_bindings_pending'}
plan_path.write_text(json.dumps(final, indent=2) + '\n')
result = {'schema': 'mr3-v21-source-promotion-v1',
          'scope': 'Reviewed exact source/config copies and ONLY three plan readiness fields. No native admission yet.',
          'files': rows, 'old160_bindings_exact_unchanged': True,
          'independent_source_bindings': len(current),
          'draft_plan_sha256': handoff['promotion_files'][7]['sha256'],
          'final_plan_sha256': hashlib.sha256(plan_path.read_bytes()).hexdigest(),
          'changed_plan_fields': ['status', 'pending', 'new_source_bindings_pending']}
(A / 'promotion_v1.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ('old160_bindings_exact_unchanged', 'independent_source_bindings', 'final_plan_sha256')}))
