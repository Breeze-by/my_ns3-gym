"""Only focused stdlib tests + actual prepared file bytes with Git I/O replaced; no ROS/native."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import time

D=Path(__file__).parent
paths=[p for p in D.glob('*.py') if p.name!='run_final_cpu_v1.py']
source_sha={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
records=[]
for label,name in [('launch','test_launch_ray_binding.py'),('witness','test_ray_witness.py'),('coordinator','test_ray_coordinator.py')]:
    command=['/usr/bin/python3','-B',str(D/name),'-v'];start=time.monotonic()
    result=subprocess.run(command,capture_output=True)
    stdout=D/(label+'_final.stdout.log');stderr=D/(label+'_final.stderr.log')
    stdout.write_bytes(result.stdout);stderr.write_bytes(result.stderr)
    records.append({'label':label,'argv':command,'exit_code':result.returncode,'wall_seconds':time.monotonic()-start,
                    'stdout':str(stdout),'stderr':str(stderr),'passed':result.returncode==0})
    print(label,result.returncode,result.stderr.decode())
for p in paths:compile(p.read_bytes(),str(p),'exec')
spec=importlib.util.spec_from_file_location('new_preflight',D/'mr3_p2a0_v21_ray_preflight_v1.py')
pre=importlib.util.module_from_spec(spec);spec.loader.exec_module(pre)
plan=json.loads((D/'predeclared_plan_v21_ray.json').read_bytes())
config=json.loads((D/'configuration/iters150.json').read_bytes())
checked=[]
def existing_only(freeze,binding):
    raw=(pre.ROOT/binding['path']).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=binding['sha256']:raise ValueError('actual file mismatch')
    checked.append(binding)
    return raw
pre.frozen=existing_only
ray=pre.check_ray('Git I/O stub only; not actual source admission',plan,config)
old=json.loads((pre.ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v20_sensor/predeclared_plan_v20_sensor.json').read_bytes())
assert plan['independent_source_bindings'][:160]==old['independent_source_bindings']
source_stable=all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v for p,v in source_sha.items())
assert source_stable
output={'passed':all(row['passed'] for row in records),'scope':'6 launch+3 witness+5 coordinator stdlib methods. Actual prepared source/ELF/archive check_ray uses only frozen Git I/O replacement; no actual source admission/SDK/ROS/DDS/Gazebo/native.',
        'records':records,'source_sha256':source_sha,'source_stable':source_stable,'old160_exact':True,
        'preflight_check_ray_actual_bytes':ray,'frozen_io_stub_reads':checked,
        'python_compile_all':True,'wall_seconds':sum(row['wall_seconds'] for row in records)}
(D/'checks_final_v1.json').write_text(json.dumps(output,indent=2)+'\n')
if not output['passed']:raise SystemExit(1)
