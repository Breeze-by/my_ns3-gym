"""Future fixed open101/eight-step invocation; /tmp draft cannot execute it."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

from fixed_integration_v1 import HERE, ROOT, RUN, W, install_supervisor, require


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--freeze', required=True)
    args = parser.parse_args(argv)
    path = Path(__file__).resolve()
    require(path.is_relative_to(ROOT), 'only a new canonical frozen diagnostic launcher may execute')
    git = lambda *v: subprocess.check_output(['git', *v], cwd=ROOT)
    require(git('rev-parse', 'HEAD').decode().strip() == args.freeze
            == git('rev-parse', 'origin/main').decode().strip() and not git('status', '--porcelain'),
            'exact clean pushed diagnostic source freeze required')
    for source in [*HERE.glob('*.py'), HERE / 'base_source_pins_v1.json', HERE.parent / 'fixed_process_profile_v1.py']:
        require(source.is_relative_to(ROOT) and
                git('show', args.freeze+':'+str(source.relative_to(ROOT))) == source.read_bytes(),
                'fixed integration source differs from its new freeze')
    RUN.mkdir(exist_ok=False)
    (RUN / 'launcher.json').open('x').write(json.dumps(dict(freeze=args.freeze,
        actual_argv=[value.decode() for value in Path('/proc/self/cmdline').read_bytes().split(b'\0') if value],
        diagnostic_only=True, scientific_qualification=False, capacity_qualified=False,
        nav2_parameter_readback_taken=False), indent=2)+'\n')
    sys.path.insert(0, str(W))
    install_supervisor()
    from mr3_learning import benchmark
    command = ['--workers', '1', '--schedule', 'open:101', '--steps', '8',
               '--base-domain', '230', '--base-port', '15901', '--output-root', str(RUN), '--run-id', 'native',
               '--work-wall-seconds', '1500', '--close-reserve-seconds', '120',
               '--safety-contract', 'mr3-reach-v1', '--seed-rule', 'exact-point-bridge-v2',
               '--start-graph-rule', 'point-attachment-3x3-v1', '--reach-geometry-rule', 'cone-support-v2']
    sys.argv = [str(W / 'mr3_learning/benchmark.py'), *command]
    return benchmark.main()


if __name__ == '__main__':
    raise SystemExit(main())
