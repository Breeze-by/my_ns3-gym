#!/usr/bin/python3
"""Sealed V21 proposal review only; no canonical reads or execution entry points."""
import ast
import hashlib
import json
import os
from pathlib import Path
import sys
import time

P = Path('/tmp/mr3_p2a0_v21_ray_proposal_v4')
OUT = Path('/tmp/mr3_p2a0_v21_ray_source_independent_review_v2.json')
EXPECTED = {
    'proposed_launch.py': '6c76a4f0afbeb4c26f8c28b8e1139bbd12e5162a54ca3a193b99a156ef47a2d2',
    'mr3_p2a0_v21_ray_run_v1.py': '93d43df2378accf13f9f01503ee921f90ad1d19a936e277ad1bc025f0dfac64e',
    'mr3_p2a0_v21_ray_preflight_v1.py': 'deeb61c911b610981ffa35a67721c84adca723831e5926ffcb951e82c0389430',
    'mr3_p2a0_v21_ray_live_admission_v1.py': '101c57802187647a27f3bdd4213a60fdfe7a98004ea8f276771eb9e55f0f0b9d',
    'test_ray_coordinator.py': '5b70f80a1ea3fbc7bba67cdb4f1d259cc4dd539ddc02005a1bcc515982b3bf06',
    'test_runtime_projection.py': 'b71f8e437f337758924bc80167fa6da050d3337380c3ced974555e3b54c2897a',
    'test_launch_ray_binding.py': '030602880648294867a8475d3f02496ad567f28c1c11040af4a88e7911b353fe',
    'test_ray_witness.py': '160f4cb2247c224030cb5212be33e92e8d465a6ba4362df58e240b0259e58571',
    'predeclared_plan_v21_ray.json': 'f06352744d6d9f9c49ac4b32db10c2982423a044c963deee654fcc42cb0b3e7d',
    'handoff_v2.json': '20a473e11dd866a4e6b7010c537fda386919f1e49483d00b57ee9c5608c8a12b',
    'sealed_manifest_v2.json': 'b545df2fd622419649f5549f211784e056fbc2a5ad50193c58d1894e904152ef',
    'checks_final_v1.json': '2fbc2c9001fd31841f7c723233fea3139b7525c8a1cf43174bce8e2b7be7fe70',
    'checks_sensor_identity_v2.json': '0568fd0a5914397d3f0909b5a724a4b0ebbd84009bfeb546afe59014494ab030',
    'checks_runtime_projection_v1.json': 'f7c01204d90eb53dd99b2d7c5350a494eb12e3df2c2ac4de6e534455d5f7ea63',
}
INPUTS = {}
RAW = {}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(stat):
    return (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns)


def read(path, expected=None):
    path = Path(path)
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    assert identity(before) == identity(after), str(path)
    if expected is not None:
        assert sha(raw) == expected, str(path)
    RAW[str(path)] = raw
    INPUTS[str(path)] = {'sha256': sha(raw), 'bytes': len(raw),
                         'stat_identity': list(identity(after))}
    return raw


def main():
    started = time.monotonic()
    contents = {name: read(P / name, expected) for name, expected in EXPECTED.items()}
    snapshot_path = Path('/tmp/mr3_p2a0_v21_ray_review_canonical_snapshot_v2.json')
    snapshot = json.loads(read(snapshot_path, '8f74abf14d08e99e86f8391e406994c59eb88a7056e8d7873b504b5b1fd2062d'))
    old_review_path = Path('/tmp/mr3_p2a0_v21_ray_source_independent_review_v1.json')
    read(old_review_path, '7bd358c316ccdf331da536231d58e89ee4bf5e9d1abeba4b65812af87c58d7c9')
    counterexample_path = Path('/tmp/mr3_p2a0_v21_ray_identity_counterexample_v1/counterexample_v1.json')
    read(counterexample_path, '357cb4409339953cf141bf43a0feab8e7cf959882a2d1afdd703a52155ecb1d7')
    plan = json.loads(contents['predeclared_plan_v21_ray.json'])
    assert plan['status'] == 'draft_not_native_admission'
    assert len(plan['independent_source_bindings']) == 173
    assert snapshot['passed'] is True and snapshot['old160_exact_unchanged'] is True
    assert snapshot['old160_actual_file_sha_verified'] is True
    assert len(snapshot['runtime103']) == 103
    assert snapshot['prospective_final_runtime_unchanged_count'] == 101
    assert all(value['whole_byte_inverse_equal'] is True
               for value in snapshot['fixed2_projection'].values())
    assert snapshot['ray_actual_library']['sha256'] == plan['ray_library']['library_sha256']
    assert snapshot['ray_actual_library']['bytes'] == 463272
    assert snapshot['ray_actual_library']['encoded_bytes'] == 148644
    stage, = plan['stages']
    assert (stage['stage'], stage['scene'], stage['seed'], stage['workers'], stage['steps'],
            stage['domain'], stage['port']) == ('iters150', 'open', 101, 1, 4, 174, 13471)
    assert plan['budget']['max_native_runs'] == 1
    assert plan['budget']['max_native_launcher_wall_seconds'] == 350.0
    assert stage['saved_api_records_max'] == 5
    assert not any('preparation' in argument for argument in stage['command'])
    assert plan['e61c_consumer']['status'] == 'SKIP'
    assert plan['research_credit'] == {
        'matrix': False, 'physical_repair': False, '32step_fixture': False,
        'PPO': False, 'pilot': False}
    required = plan['ray_basic_measurement_required']
    assert (required['configuration_per_robot'], required['sensor_connected_per_robot'],
            required['minimum_complete360_scans_per_robot'],
            required['diagnostic_errors_allowed']) == (1, 1, 1, 0)
    for name in EXPECTED:
        if name.endswith('.py'):
            ast.parse(contents[name], filename=str(P / name))
    for key in ('checks_final_v1.json', 'checks_sensor_identity_v2.json',
                'checks_runtime_projection_v1.json'):
        assert json.loads(contents[key])['passed'] is True
    identity_checks = json.loads(contents['checks_sensor_identity_v2.json'])
    assert identity_checks['focused_methods'] == 6
    assert identity_checks['red_green']['old_passed'] is True
    assert identity_checks['red_green']['new_passed'] is False
    projection_checks = json.loads(contents['checks_runtime_projection_v1.json'])
    assert projection_checks['methods'] == 4
    # The following are source-review conclusions, not rerun author tests or
    # proof that the future root native process has already satisfied them.
    reviewed = [
        {'area': 'SensorPlugin source and lifecycle',
         'result': 'Previous v1 source review remains valid for exact CPP65b1 and launch6c76. Load directly binds actual RaySensor before its container updates; no Discover/manager registration, recast, physics setter or actor input.'},
        {'area': 'Actual source and binary custody',
         'result': 'Canonical stable snapshot verifies installed/build b761 463272 bytes, encoded39f729 148644 bytes, lossless decode and embedded65b1 source. TMP Debug a48 is not the admitted library. Original a014 and all four compiled source macros preserved.'},
        {'area': 'Parent and basic measurement identity',
         'result': 'Parent93d43 requires configuration world/model/link/sensor and exact derived Sensor::ScopedName parent/scoped identity on connected and every scan; complete360 shape and diagnostic errors are checked. Every raw line is hashed before parsing; failure does not truncate stream hashing.'},
        {'area': 'Finite execution and old runtime103 dictionary',
         'result': 'Parent keeps actual dictionary-to-binding projection, recorder-ready before one ordinary4step benchmark, natural wait/reap, exclusive stop marker after benchmark closure, no signal/retry. Process completion and original scientific2516 verdict remain distinct; overall also requires basic ray measurements.'},
        {'area': 'Live witness',
         'result': 'Witness101c checks unique sensor-nested seven tags and root-model old observer eight tags, independently renders the old template, removes exact added blocks to whole-byte equality, binds actual source/dladdr/PID/start/ancestor/maps inode-device and rechecks mapped library identity. Future actual witness evidence remains pending.'},
        {'area': 'Fixed two-pin adapter and full CLI',
         'result': 'Preflightdeeb61 checks current and frozen Git exact two new source bytes, fixed4f8 old blobs and exact whole-byte inverse; only two EXECUTION_CONFIG_PINS entries change during unchanged load_native_gates, with finally restoring original dict object. main uses this adapter; all other old101 runtime rows remain authoritative. No loader/admission invocation occurred in this review.'},
        {'area': 'Runtime loader reachability',
         'result': 'Read-only source search found no load_native_gates call in the ordinary benchmark/environment/supervisor/worker/2516/e61c profile subset or V19 run_consumer path; old full audit_ppo/audit_preparation references are outside this diagnostic execution path.'},
        {'area': 'Preserved scope',
         'result': 'Old160 independent rows and actual files unchanged; 13 explicitly bound additions. Existing physical/angular/task/reward/actor/driver gates are not replaced by ray measurement availability. Solver150 remains diagnostic, not selected production or physical repair.'},
    ]
    sources = {key: {'path': str(P / key), 'sha256': value}
               for key, value in EXPECTED.items() if key.endswith('.py')}
    for path, raw in RAW.items():
        again = Path(path).read_bytes()
        assert again == raw and list(identity(Path(path).stat())) == INPUTS[path]['stat_identity']
    result = {
        'schema': 'mr3-v21-ray-independent-source-review-v2',
        'passed': True,
        'verdict': 'No remaining concrete producer-consumer blocker identified in sealed sources; ready promotion and fresh frozen full admission are root responsibilities.',
        'native_credit': False, 'actual_source_admission_executed': False,
        'author_tests_reexecuted': False,
        'scope': 'Read-only sealed TMP source/static metadata review plus earlier canonical snapshot. No canonical reads after snapshot STOP, no SDK/ROS/DDS/Gazebo/native/formal execution.',
        'reviewed_sources': sources, 'review_findings': reviewed,
        'resolved_issues': [
            {'issue': 'Old8619 accepted mismatched connected/scan sensor identity.',
             'evidence': str(counterexample_path),
             'resolution': 'Versioned93d43 narrows config/connected/every scan identity; original8619 and original FAIL evidence retained.'},
            {'issue': 'Immutable auditor old CMake/launch pins would reject the explicitly changed ray-diagnostic runtime.',
             'resolution': 'Versioneddeeb61 adds only fixed2pin byteprojection adapter. Old auditor, old160 artifacts and old failures remain unchanged.'},
        ],
        'author_evidence_reviewed_not_rerun': {
            'unchanged_launch_methods': 6, 'unchanged_witness_methods': 3,
            'current_identity_methods': 6, 'current_projection_methods': 4,
            'historical_old_parent_methods': 5,
            'historical_old_parent_not_current_credit': True,
            'projection_scope': projection_checks['scope'],
            'rt_sdk_pure_factory_lddr': 'Exact prior v1 review only; no repeated SDK checks.'},
        'canonical_snapshot': {'path': str(snapshot_path),
            'sha256': INPUTS[str(snapshot_path)]['sha256'],
            'bound_files': len(snapshot['inputs']),
            'old160_actual_equal': True,
            'runtime_before_launch_promotion': snapshot['runtime_unchanged_count'],
            'prospective_final_runtime_old_equal': 101,
            'fixed2_projection': snapshot['fixed2_projection'],
            'actual_ray': snapshot['ray_actual_library'],
            'driver_sha256': snapshot['original_driver_actual_sha256']},
        'limitations': [
            'Actual freshfreeze full preflight, runtime source macros/maps and SensorPlugin Load/callback evidence are still pending; CPU finite loader stubs are not those results.',
            'Basic complete360 availability is not per-beam cached-range/CDR equality or whole-scan physics validation. Those can only be described from actual closed evidence.',
            'Cached cast data and current collision/model geometry have distinct non-atomic scopes; current getters cannot establish the original cast pose.',
            'Best-effort recorder may miss earliest scans; unmatched accepted public pose or initial map origins remain unknown rather than manufactured.',
            'Ordinary4step startup capture cannot earn32step/e61c matrix, scientific physical repair, P2A95%, PPO or iters150-selection credit.'
        ],
        'input_bindings': INPUTS, 'tmp_inputs_stable': True,
        'helper_source_sha256': sha(Path(__file__).read_bytes()),
        'argv': sys.argv, 'cwd': os.getcwd(),
        'selected_environment': {key: os.environ.get(key) for key in (
            'PYTHONNOUSERSITE', 'PYTHONDONTWRITEBYTECODE', 'ROS_DOMAIN_ID',
            'RMW_IMPLEMENTATION', 'FASTRTPS_DEFAULT_PROFILES_FILE', 'CONDA_PREFIX')},
        'wall_seconds': time.monotonic() - started,
        'writer_state': 'STOP after this output; root may archive unchanged originals.'}
    with OUT.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'passed': True, 'scope': 'static review only',
                      'output': str(OUT), 'sha256': sha(OUT.read_bytes()),
                      'inputs': len(INPUTS), 'author_tests_reexecuted': False,
                      'native_credit': False}))


if __name__ == '__main__':
    main()
