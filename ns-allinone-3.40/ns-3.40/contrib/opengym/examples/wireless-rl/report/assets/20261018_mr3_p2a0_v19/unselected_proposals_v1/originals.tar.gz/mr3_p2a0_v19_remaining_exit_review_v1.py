"""Static contract review only; no active V19 files, production imports or tests."""
import ast
import hashlib
import json
from pathlib import Path


ROOT = Path("/home/zhuyulab/ns3-workspace")
W = ROOT / "ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl"
A = W / "report/assets"
PATHS = {
    "research": W / "RESEARCH_PLAN.md",
    "implementation": W / "IMPLEMENTATION_PLAN.md",
    "env": W / "MR3_ENV_CONTRACT.md",
    "task": W / "MR3_TASK_CONTRACT.md",
    "component_memory": W / "AGENTS.md",
    "guide": ROOT / "ros2_ws/ros2-multi-robot-automap/user_guide.md",
    "launch": ROOT / "ros2_ws/ros2-multi-robot-automap/launch_commands.md",
    "plan17": A / "20261017_mr3_p2a0_v17/predeclared_plan_v17.json",
    "physics": A / "20261017_mr3_p2a0_v3/independent/mr3_independent_physics_review.py",
    "physics_matrix": A / "20261017_mr3_p2a0_v17/independent/mr3_independent_physics_matrix_v17.py",
    "angular": A / "20261017_mr3_p2a0_v4/independent/mr3_independent_angular_interface_v1.py",
    "angular_matrix": A / "20261017_mr3_p2a0_v17/independent/mr3_independent_angular_reset_matrix_v17.py",
    "settled": A / "20261017_mr3_p2a0_v8/independent/mr3_independent_settled_turn_v3.py",
}
EXPECTED = {
    "physics": "2516e394f60eac5dd24fd66b51c4c48fc37245090eb1626ebe1c7a3a23f8bafb",
    "physics_matrix": "50651f8b8ed5bee161f4c44a18e1ce68f7d8a27cda88fc466756b91f0f35cee8",
    "angular": "7a472ba7efdd55addc710b98c66c89feff7f5092f214f76fd76cd4ca526343d0",
    "angular_matrix": "8c9f04929cd9a52df0bea22106d64756c42c51350adae9ee20823e0054028901",
    "settled": "c43fadbb74bef948f14c39e74fefb64fc9103b45191f593b8c089a63127b0a69",
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def locate(key, phrase):
    lines = raw[key].decode().splitlines()
    return {"path": str(PATHS[key]), "line": next(
        index for index, line in enumerate(lines, 1) if phrase in line)}


raw = {key: path.read_bytes() for key, path in PATHS.items()}
before = {key: sha(value) for key, value in raw.items()}
assert all(before[key] == value for key, value in EXPECTED.items())
plan = json.loads(raw["plan17"])
assert [stage["stage"] for stage in plan["stages"]] == [
    "interface", "terminal", "reset", "deadline"]
assert (plan["max_api_records"], plan["max_submitted_script_decisions"],
        plan["max_total_wall_seconds"]) == (608, 596, 18000)
assert (plan["gpu_calls"], plan["optimizer_steps"]) == (0, 0)
for source in ("physics", "physics_matrix", "angular", "angular_matrix", "settled"):
    ast.parse(raw[source])
text = {key: value.decode() for key, value in raw.items()}
assert "bool(credited or cancel_credited)" in text["physics"]
assert 'if not row["A"] and not row["B"]:' in text["physics_matrix"]
assert 'event.get("observed_nonrest_beyond_horizon") is True' in text["physics_matrix"]
assert 'event["status"] == "observed_bound_violation"' in text["physics_matrix"]
assert 'event["observed_odom_polyline_m"] > .144' in text["physics_matrix"]
assert 'require(row["sampled_bounds_passed"] is True' in text["angular_matrix"]
assert "stimulus_coverage_is_not_a_reset_gate" in text["angular_matrix"]
assert plan["physical_response_criteria"]["matrix_coverage"]["excluded_from_response_pool"] == [
    "interface", "terminal", "deadline"]
after = {key: sha(path.read_bytes()) for key, path in PATHS.items()}
assert before == after
findings = [
    {"id": "full_fresh_matrix", "rule": "After an evidenced repair/config decision, declare and pass a complete new same-freeze interface->terminal->reset->deadline matrix. Isolated V18/V19 diagnostics and earlier stage PASS cannot fill a new matrix slot.",
     "evidence": [locate("implementation", "只有该新矩阵通过"), locate("env", "不计四阶段矩阵或95%任务信用")]},
    {"id": "physics_or", "rule": "Original2516 interface evidence is A OR B per robot, not A AND B. Reset pool requires at least one meaningful credited A OR B per robot across exactly its eight same-freeze reset episodes. Interface/terminal/deadline are excluded from that pool.",
     "evidence": [locate("physics", '"physical_evidence_complete":bool(credited or cancel_credited)'),
                  locate("physics_matrix", 'if not row["A"] and not row["B"]:')]},
    {"id": "observed_failure_independent", "rule": "Every reset episode still needs raw source integrity, speed/chord/angular bounds and strict closure. Any eligible observed nonrest after .78s, observed_bound_violation or observed path>.144m fails the matrix even if all pool counters are sufficient. Per-episode missing credit is retained and is not an added per-episode A/B mandatory condition.",
     "evidence": [locate("physics_matrix", 'if event["eligible"] and (event.get("observed_nonrest_beyond_horizon")'),
                  locate("physics_matrix", '"missing_meaningful_stop_robots": missing')]},
    {"id": "meaningful_rest", "rule": "Meaningful prior nonzero output span>=.1s, recent full planar norm>=.05m/s and source age<=.1s; original rest<=.01m/s for3 consecutive fresh source samples; .78s/.144m response. Preserve eligible/missing/unresolved/observed failure distinctions and finite-sample limitations.",
     "evidence": [locate("physics_matrix", 'event["initial_observed_planar_speed"] >= .05'),
                  locate("physics_matrix", 'event["observed_latency_sec"] <= .78')]},
    {"id": "angular_scopes", "rule": "Interface: every robot one >=3-fresh-sample same-sign |wz|>=.1 span, aggregate positive and negative spans, and at least one robot both signs; no per-robot dual-sign addition. Reset: every episode sampled_bounds_passed only, retaining original stimulus_coverage_passed/false. Both preserve full angular norm1.2, sampled vector acceleration7 and source continuity<=.1s.",
     "evidence": [locate("angular", 'covered = all(row["sign_spans"]'),
                  locate("angular_matrix", '"stimulus_coverage_is_not_a_reset_gate": True')]},
    {"id": "activity_separation", "rule": "Interface/reset each episode still requires all3 native accepted goals and received-estimated path>.05m with full raw cumulative-activity/map replay. These engineering availability probes do not replace task truth path>=1m/goal participation or95% mapping.",
     "evidence": [locate("task", "每台任务内真值路径≥1m"), locate("implementation", "原95%/300秒")]},
    {"id": "terminal_deadline_closure", "rule": "Retain two4-API terminal probes including real3.02 short action and exact3.0 no-action zero-tail branches, plus original300KEEP deadline. Match actual scalar/reward/evaluator clocks, single terminal settlement and bootstrap0; no actor sample for action_submitted=false. Strict native shutdown, Nav2/SLAM/helper ordering, actual PID/start absence and eighteen healthy contact sources remain required. Neither probe supplies stop-pool, angular stimulus or95% success credit.",
     "evidence": [locate("env", "此唯一零时长例外必须"), locate("env", "终态只结算真实终态奖罚"),
                  locate("launch", "300秒KEEP用于截止与关闭验证")]},
    {"id": "causal_execution", "rule": "Keep actual information selection/publication->six peer callbacks/obstacle publication->immutable guard/self receipt->three tagged target-storage receipts before each20ms advance, permanent strict-zero stop, sticky actual negativeACK except exact actual terminal cancellation, source/driver freshness and full body model limits. Actual source/library/installed/parameter/loaded Shim and driver provenance must remain bound to the new freeze.",
     "evidence": [locate("env", "normal回执同clock不可覆"),
                  locate("guide", "MR3适配器每20ms物理推进前")]},
    {"id": "settled_no_substitution", "rule": "Every actual settled activation and full actual-storage zero-segment tail must retain raw full norm/chord/path/source audit; interface additionally requires real use. .94 publication history, actual zero storage>=.78, .0078 whole-segment path and continuous conditional assumptions are not relaxed by finite1ms diagnostic data.",
     "evidence": [{"path": str(PATHS["plan17"]), "json_pointer": "/settled_turn_criteria"}]},
    {"id": "research_exit", "rule": "P2A.0 completion only supports engineering readiness and requires evidence/report/commit-push then user acceptance. It is not a learned policy result. P2A still needs actual network-selected goals, no hand-coded exploration/truth input, an end-to-end reproducible same-version training+validation chain reaching the unchanged95%/300s task/quality/safety/participation gate. No PPO route rejection or task reduction follows from these preparation failures.",
     "evidence": [locate("implementation", "出口：真正由网络选目标的三机器人 Gazebo episode"),
                  locate("task", "当前融合图的正确自由覆盖≥.95")]},
]
result = {
    "schema": "mr3-p2a0-remaining-exit-static-review-v1",
    "review_only": True,
    "no_new_gates_or_scope": True,
    "active_v19_raw_or_receipts_read": False,
    "native_ros_dds_or_formal_calls": 0,
    "current_checkpoint": "P2A.0 incomplete; V19 isolated diagnostics in progress, no result reviewed",
    "source_bindings_before": before, "source_bindings_after": after,
    "immutable_consumers_verified": EXPECTED,
    "findings": findings,
    "matrix_budget_to_retain": {"max_api_records": 608, "conservative_step_call_ceiling": 596,
                              "max_wall_seconds": 18000,
                              "stages": [{"stage": stage["stage"], "command": stage["command"],
                                          "wall_ceiling_seconds": stage["wall_ceiling_seconds"]}
                                         for stage in plan["stages"]]},
    "pilot_balance_unchanged": plan["pilot_budget_unchanged"],
    "minimal_evidence": [
        "A reviewed repair with prospective new source/config/binary bindings, necessary relevant CPU/build checks and clean pushed exact freeze.",
        "One complete new four-stage matrix, every required audit receipt/strict closure and honest original per-episode/pool scopes; later stages stop on failure.",
        "All attempts, charges, raw failures, provenance and no-native-GPU/update scope retained, no cross-freeze PASS assembly.",
        "Only then a concrete engineering delivery for user acceptance; no automatic pilot balance reset, PPO restart, P2B or gateway advance."
    ],
    "coordination": "candidate_interface owns prospective V20 mechanical plan only; original gate interpretations shared, not duplicated.",
}
target = Path("/tmp/mr3_p2a0_v19_remaining_exit_review_v1.json")
target.write_text(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False) + "\n")
report = """P2A.0剩余出口静态复核：原门应保留，没有新增门。

- 隔离50/150诊断不提供四阶段或策略信用；有依据修复后仍须新clean/pushed同冻结的interface、terminal、8轮reset、deadline完整链，失败即停、不拼旧PASS。
- 物理响应是A OR B：interface原2516每机至少一类；reset跨自己的八轮每机至少一类。原有eligible已观测超时/路径超界不能被pool信用抵消。每轮缺信用保留missing，不另加每轮A AND B。
- interface角运动覆盖为每机一个3fresh的|wz|>=.1同号段、总体双号、至少一台双号；reset仅逐轮sampled_bounds，coverage false如实保留。1.2/7/.1s源连续性保持。
- 每轮三台received path>.05m/native accept只是工程可用性；不替代任务真值1m/goal、95%/300s、地图质量、18源接触及.50m安全门。
- terminal两分支须保留真实短步和同边界零动作结算，API≠实际策略动作；deadline原300KEEP和严格关闭保留，均无95%或运动刺激信用。
- 完整state→peer→guard→self receipt→三台实际target storage→20ms物理链、sticky负ACK、永久零停、全body/source与settled整区间门均不能由1ms诊断代替。
- 原四阶段预算608 API/596保守step调用/18000墙秒，无GPU/更新；pilot余额不重置。

P2A.0通过后是工程交付待用户验收。P2A仍需网络实际选目标且无手工探索/真值输入的同版本训练—验证链，达到原95%任务。P2B/P2C/gateway不因此自动开始。

本次只读源码、冻结V17计划和契约，未读取活动V19 raw/回执，未运行native/ROS/DDS/正式审计或完整tests。详见同名JSON的逐项原件行号和SHA。
"""
Path("/tmp/mr3_p2a0_v19_remaining_exit_review_v1.md").write_text(report)
print(json.dumps({"review": str(target), "sha256": sha(target.read_bytes()),
                  "findings": len(findings), "source_before_after_equal": before == after}))
