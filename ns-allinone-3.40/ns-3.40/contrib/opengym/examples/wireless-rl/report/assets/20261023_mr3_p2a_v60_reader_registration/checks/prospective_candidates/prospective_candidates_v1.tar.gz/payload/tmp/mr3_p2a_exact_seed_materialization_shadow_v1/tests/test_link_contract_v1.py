"""Artificial link-contract checks only: no native/readers/scientific raw data."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile
import time
import unittest
from unittest.mock import patch

BASE = Path(__file__).resolve().parents[1]
REL = Path("ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl")
CANDIDATE = BASE / "candidate" / REL / "mr3_learning"
spec = importlib.util.spec_from_file_location("artificial_materialization", CANDIDATE / "exact_seed_materialization.py")
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True) + "\n")


class LinkContract(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="mr3-seed-contract-artificial-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        for name, value in (("WORKSPACE", self.root), ("WIRELESS", self.root / REL)):
            change = patch.object(m, name, value);change.start();self.addCleanup(change.stop)
        pure = Path("ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/multi_robot_exploration")
        self.math = {str(REL / "mr3_learning" / name) for name in ("audit_seed_inputs.py", "navigation_archive.py", "supervisor.py")}
        self.math.add("ros2_ws/ros2-multi-robot-automap/scripts/mr3_env_worker.py")
        self.math.update(str(pure / name) for name in ("__init__.py", "mr3_observation.py", "mr3_episode.py", "mr3_seed_certificate.py", "mr3_reach_geometry.py"))
        for relative in self.math | set(m.EXTRA_SOURCES):
            path = self.root / relative;path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("# ARTIFICIAL source fixture: " + relative + "\n")
        subprocess.run(["git", "init", "-q", str(self.root)], check=True, stdout=subprocess.DEVNULL)
        subprocess.run(["git", "add", "."], cwd=self.root, check=True)
        subprocess.run(["git", "-c", "user.name=Artificial Fixture", "-c", "user.email=fixture@invalid", "commit", "-qm", "artificial source fixture"], cwd=self.root, check=True)
        self.freeze = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=self.root, text=True).strip()
        self.run = self.root / "run"
        self.episode = self.run / "worker0/episode001_rooms_101"
        self.episode.mkdir(parents=True)
        write(self.episode / "metadata.json", {"freeze":self.freeze,"epoch":"ARTIFICIAL_epoch", "seed_rule":"ARTIFICIAL_exact", "safety_contract":"mr3-reach-v1"})
        write(self.episode / "summary.json", {"ARTIFICIAL":True})
        self.snapshot = self.episode / "observation_inputs/snapshots/00000001_artificial.json"
        self.map = self.episode / "observation_inputs/maps/artificial.json.gz"
        write(self.snapshot, {"ARTIFICIAL":True});self.map.parent.mkdir(parents=True);self.map.write_bytes(b"ARTIFICIAL_ENCODED_NOT_SCIENTIFIC")
        self.requested = self.episode / "transitions.jsonl"
        self.encoded = Path(str(self.requested) + ".gz");self.encoded.write_bytes(b"ARTIFICIAL_ENCODED_TRANSITIONS")
        self.plan_path = self.root / "plan.json"
        self.output = self.root / "audit/input_001_result.json"
        self.receipt_path = self.root / "audit/input_001_command.json"
        self.job = {"id":"input_001", "role":"input", "required":True, "depends_on":[],
                    "argv":m.input_argv(self.episode,self.output,self.plan_path), "output":str(self.output),
                    "receipt":str(self.receipt_path),"console":str(self.root / "audit/input_001.log")}
        self.full = {"id":"full","role":"full","depends_on":["input_001"],"argv":["ARTIFICIAL_full","--plan",str(self.plan_path)]}
        self.plan = {"audit_resource_profile":m.PROFILE,"seed_rule":"ARTIFICIAL_exact",
            "source_bindings":{relative:m.file_spec(self.root / relative)["sha256"] for relative in self.math | set(m.EXTRA_SOURCES)},
            "stages":[{"stage":"interface","expected_episodes":1,"run_directory":str(self.run),
                       "native":{"argv":["ARTIFICIAL_native","--workers","1","--schedule","rooms:101"]},"audits":[self.job,self.full]}]}
        write(self.plan_path,self.plan)
        inputs = [self.episode / "metadata.json",self.snapshot,self.map,self.encoded]
        self.result = {"schema":m.SCHEMA,"passed":True,"errors":[],"freeze":self.freeze,
            "episode":str(self.episode),"seed_rule":"ARTIFICIAL_exact",
            "whole_observation_and_seven_map_replay_passed":True,"exact_full_snapshot_replays":1,
            "input_bindings":{str(path):m.file_spec(path) for path in inputs},
            "encoded_input_resolution":{str(self.requested if path==self.encoded else path):str(path) for path in inputs},
            "encoded_archive_members":{"snapshots":[str(self.snapshot)],"maps":[str(self.map)]},
            "source_proof":{relative:{"sha256":m.file_spec(self.root / relative)["sha256"],"git_source":self.freeze+":"+relative} for relative in self.math}}
        m.seal_origin(self.result,self.plan_path,self.output)
        write(self.output,self.result)
        self.child = {"pid":987654321,"start_ticks":1,"parent":987654320}
        launcher = {"pid":987654320,"start_ticks":1}
        self.receipt = {"schema":"mr3-reach-native-wait-v1","safety_contract":"mr3-reach-v1",
            "id":"input_001","role":"input","freeze":self.freeze,"plan_sha256":m.file_spec(self.plan_path)["sha256"],
            "argv":self.job["argv"],"command_argv":self.job["argv"],"cwd":str(m.WIRELESS),"required":True,
            "output":str(self.output),"receipt":str(self.receipt_path),"console":self.job["console"],
            "result_pass_key":"passed","execution_kind":"subprocess_waited","passed":True,"returncode":0,"errors":[],
            "output_sha256":m.file_spec(self.output)["sha256"],"started_wall_monotonic_ns":time.monotonic_ns()-1000,
            "ended_wall_monotonic_ns":time.monotonic_ns()-500,"process_identity":self.child,
            "launcher_identity":launcher,"coordinator_identity":launcher,"benchmark_parent":self.child,"pid":self.child["pid"]}
        write(self.receipt_path,self.receipt)

    def reuse(self):
        # These identifiers model a saved/gone origin. They are not real scientific wait evidence.
        with patch.object(m,"proc_identity",return_value=None):
            return m.reuse(self.plan_path,self.episode)

    def update_result(self):
        write(self.output,self.result);self.receipt["output_sha256"]=m.file_spec(self.output)["sha256"];write(self.receipt_path,self.receipt)

    def test_exact_link_has_origin_not_fabricated_child_wait(self):
        result=self.reuse();execution=result["exact_seed_execution"]
        self.assertEqual(execution["execution_kind"],"verified_same_activity_fact")
        self.assertEqual(execution["origin_receipt"]["sha256"],m.file_spec(self.receipt_path)["sha256"])
        self.assertNotIn("system_python_execution",result)
        self.assertNotIn("actual_waited",execution)

    def test_complete_original_byte_change_rejects(self):
        self.encoded.write_bytes(b"CHANGED");self.assertRaises(ValueError,self.reuse)

    def test_added_preferred_plain_input_rejects(self):
        self.requested.write_bytes(b"ADDED_PLAIN");self.assertRaises(ValueError,self.reuse)

    def test_new_archive_member_rejects(self):
        write(self.snapshot.parent / "extra.json",{});self.assertRaises(ValueError,self.reuse)

    def test_source_change_and_missing_source_proof_reject(self):
        target=self.root / next(iter(self.math));old=target.read_bytes();target.write_bytes(b"CHANGED")
        self.assertRaises(ValueError,self.reuse);target.write_bytes(old)
        self.result["source_proof"].pop(next(iter(self.math)));self.update_result();self.assertRaises(ValueError,self.reuse)

    def test_bad_receipt_and_failed_origin_reject(self):
        self.receipt["command_argv"]=["WRONG"]
        write(self.receipt_path,self.receipt);self.assertRaises(ValueError,self.reuse)
        self.receipt["command_argv"]=self.job["argv"];self.result["passed"]=False;self.update_result()
        self.assertRaises(ValueError,self.reuse)

    def test_environment_epoch_and_freeze_reject(self):
        original=copy.deepcopy(self.result)
        for change in (lambda r:r["origin_materialization"].update(environment_sha256="0"*64),
                       lambda r:r["origin_materialization"]["key"].update(epoch="OTHER"),
                       lambda r:r.update(freeze="0"*40)):
            self.result=copy.deepcopy(original);change(self.result);self.update_result();self.assertRaises(ValueError,self.reuse)

    def test_present_child_and_missing_receipt_reject(self):
        with patch.object(m,"proc_identity",return_value={"pid":self.child["pid"],"start_ticks":1}):
            self.assertRaises(ValueError,m.reuse,self.plan_path,self.episode)
        self.receipt_path.unlink();self.assertRaises(FileNotFoundError,self.reuse)

    def test_missing_qualified_leaf_is_not_not_applicable(self):
        self.plan["stages"][0]["audits"]=[self.full];self.full["depends_on"]=[];write(self.plan_path,self.plan)
        self.assertRaises(ValueError,self.reuse)

    def test_explicit_not_applicable_and_default(self):
        self.assertIsNone(m.profile({}));m.validate_plan({})
        self.plan["stages"][0]["stage"]="terminal";self.plan["stages"][0]["audits"]=[self.full]
        self.full["depends_on"]=[];write(self.plan_path,self.plan)
        self.assertIsNone(self.reuse())
        policy_run=self.root/"policy_minimum"
        policy_episode=policy_run/"native/round0000/worker0/episode001_open_101"
        policy_episode.mkdir(parents=True)
        self.plan["policy_stages"]={"minimum":{"run_directory":str(policy_run)}}
        write(self.plan_path,self.plan)
        self.assertIsNone(m.reuse(self.plan_path,policy_episode))
        wrong=policy_run/"native/EXTRA/round0000/worker0/episode001_open_101"
        wrong.mkdir(parents=True)
        self.assertRaises(ValueError,m.reuse,self.plan_path,wrong)
        self.plan["audit_resource_profile"]="UNKNOWN";self.assertRaises(ValueError,m.profile,self.plan)


if __name__=="__main__":unittest.main(verbosity=2)
