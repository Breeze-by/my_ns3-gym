"""Read existing V16 formal leaves only; never re-run a consumer or raw scan."""
from collections import Counter
import hashlib
import json
from pathlib import Path


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    leaves, inputs = {}, {}
    for name in ('fixed_physics_v1', 'fixed_angular_v1', 'full_audit', 'input_review_v1'):
        path = Path('/tmp/mr3_p2a0_v16_interface_' + name + '.json')
        raw = path.read_bytes()
        leaves[name] = json.loads(raw)
        inputs[str(path)] = {'bytes': len(raw), 'sha256': sha(raw), 'passed': leaves[name]['passed']}
    physical = leaves['fixed_physics_v1']
    angular = leaves['fixed_angular_v1']
    assert physical['script_sha256'] == '2516e394f60eac5dd24fd66b51c4c48fc37245090eb1626ebe1c7a3a23f8bafb'
    assert angular['script_sha256'] == '7a472ba7efdd55addc710b98c66c89feff7f5092f214f76fd76cd4ca526343d0'
    assert physical['passed'] is False and angular['passed'] is True
    assert leaves['full_audit']['passed'] is True and leaves['full_audit']['errors'] == []
    assert leaves['input_review_v1']['passed'] is True
    episode = physical['episodes'][0]
    robots = {}
    for name, robot in episode['robots'].items():
        all_events = robot['stop_responses'] + robot['cancel_stop_responses']
        row = {key: robot[key] for key in (
            'errors', 'maximum_planar_speed_task', 'maximum_angular_norm_task',
            'maximum_raw_odom_chord_speed_task', 'maximum_task_source_gap_ns',
            'bound_violation_counts', 'physical_evidence_complete', 'eligible_stop_events',
            'credited_sampled_stop_events', 'eligible_cancel_stop_events', 'credited_cancel_stop_events')}
        row.update(
            A_events=len(robot['stop_responses']),
            A_statuses=dict(Counter(item['status'] for item in robot['stop_responses'])),
            A_prior_nonzero_spans_ns=dict(Counter(str(item['prior_nonzero_command_span_ns'])
                                                 for item in robot['stop_responses'])),
            maximum_A_initial_observed_planar_speed=max(
                [item.get('initial_observed_planar_speed') or 0. for item in robot['stop_responses']],
                default=None),
            B_statuses=dict(Counter(item['status'] for item in robot['cancel_stop_responses'])),
            observed_nonrest_beyond_horizon_count=sum(
                item.get('observed_nonrest_beyond_horizon') is True for item in all_events),
            observed_bound_violation_status_count=sum(
                item['status'] == 'observed_bound_violation' for item in all_events),
            credited_events=[{key: item.get(key) for key in (
                'event_category', 'event_clock_ns', 'initial_observed_planar_speed',
                'prior_nonzero_command_span_ns', 'observed_latency_sec',
                'observed_odom_polyline_m', 'maximum_observation_gap_ns')}
                for item in all_events if item['status'] == 'sampled_response_within_declared_bounds'])
        assert robot['errors'] == []
        assert all(value == 0 for value in robot['bound_violation_counts'].values())
        assert row['observed_nonrest_beyond_horizon_count'] == 0
        assert row['observed_bound_violation_status_count'] == 0
        robots[name] = row
    tb1 = robots['tb1']
    assert tb1['A_events'] == 38 and tb1['eligible_stop_events'] == tb1['credited_sampled_stop_events'] == 0
    assert tb1['B_statuses'] == {'no_active_prior_linear_output': 1}
    assert all(int(span) < 100000000 for span in tb1['A_prior_nonzero_spans_ns'])
    transition = Path(episode['directory']) / 'transitions.jsonl'
    transition_raw = transition.read_bytes()
    records = [json.loads(line) for line in transition_raw.splitlines()]
    final = records[-1]
    assert len(records) == 33 and records[0]['kind'] == 'reset'
    assert final['terminated'] is False and final['truncated'] is True
    assert final['info']['reason'] == 'external_sampler_limit'
    assert leaves['full_audit']['freeze'] == 'ebe7d51bdb7bf9d77a28b77cfb4296876afb0100'
    activity = [{ 'robot': robot['name'], 'estimated_received_path_m': robot['activity']['estimated_path_m'],
                  'path_observation_complete': robot['activity']['path_observation_complete'],
                  'accepted_goal_count': robot['navigation']['accepted_goal_count']}
                for robot in final['snapshot']['robots']]
    assert all(row['path_observation_complete'] is True and row['estimated_received_path_m'] > .05
               and row['accepted_goal_count'] >= 1 for row in activity)
    inputs[str(transition)] = {'bytes': len(transition_raw), 'sha256': sha(transition_raw)}
    for path, proof in inputs.items():
        assert sha(Path(path).read_bytes()) == proof['sha256'], 'receipt changed while reading'
    report = {
        'schema': 'mr3-v16-interface-formal-physical-leaf-summary-v1',
        'freeze': leaves['full_audit']['freeze'], 'original_leaf_bindings': inputs,
        'overall_physical_gate_passed': False,
        'physical_failure': 'tb1 has no eligible meaningful sampled A or B response. All38 A '
                            'events have only20-80ms prior nonzero output (<100ms), and A-event '
                            'initial sampled planar norm max.0354386 is below.05. Its isolated '
                            'task raw planar peak.0658254 does not satisfy either event-specific '
                            'prerequisite. The sole B has no active prior linear output.',
        'robots': robots,
        'sampled_bounds': 'All three recorded errors lists empty, planar/angular/chord violation '
                          'counts0, no observed_bound_violation event status and no '
                          'observed_nonrest_beyond_horizon=true. Missing/ineligible responses '
                          'remain missing; these zeros do not prove tb1 braking.',
        'angular': {'passed': angular['passed'], 'sampled_bounds_passed': angular['sampled_bounds_passed'],
                    'stimulus_coverage_passed': angular['stimulus_coverage_passed'],
                    'positive_span_robots': angular['positive_span_robots'],
                    'negative_span_robots': angular['negative_span_robots'],
                    'bidirectional_robots': angular['sequential_opposite_sign_span_robots'],
                    'criteria': angular['criteria']},
        'other_existing_leaves': {'full_audit_passed': True, 'input_review_passed': True,
                                  'final_received_activity': activity,
                                  'scope': 'Engineering received path>.05m and accepted GOAL gate; '
                                           'not every-robot1m task participation or95% success.'},
        'strict_closure_from_original_physical_leaf': {
            key: episode['closure'][key] for key in ('passed', 'errors', 'checks',
                'started_processes', 'exited_processes', 'still_present_saved_identities')},
        'unchanged_immutable_gate': {
            'physical_consumer_sha256': physical['script_sha256'],
            'angular_consumer_sha256': angular['script_sha256'],
            'meaningful_prior_output_seconds_min': .1, 'event_initial_planar_norm_min_mps': .05,
            'source_age_max_seconds': .1, 'sampled_rest_planar_norm_mps_max': .01,
            'fresh_rest_samples': 3, 'elapsed_to_rest_seconds_max': .78,
            'sampled_path_to_rest_m_max': .144, 'per_robot_coverage': 'one credited A OR B; '
            'A and B separately reported, never require both or waive missing tb1.'},
        'scope': 'Read only four existing formal JSON leaves and small transitions file. '
                 'No big raw scans, new formal/native/tests/controls, Git/source mutations '
                 'or claim overall PASS. Original physical FAIL and later-stage disposition '
                 'remain owned by the canonical coordinator.'}
    output = Path('/tmp/mr3_p2a0_v16_interface_physical_leaf_summary_v1.json')
    with output.open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'output': str(output), 'sha256': sha(output.read_bytes()),
                      'physical_passed': False, 'angular_bidirectional': angular['sequential_opposite_sign_span_robots'],
                      'full_passed': True, 'input_passed': True, 'activity': activity}))


if __name__ == '__main__':
    main()
