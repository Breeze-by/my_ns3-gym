"""Static-only coordinator inverse and exact stage metadata checks; no subprocess native."""
import argparse
import ast
import copy
import difflib
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
CI = Path('/tmp/mr3_p2a0_v25_smoother_custody_proposal_v2')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def assigned(node, name):
    return isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name
                                               for t in node.targets)


def mechanical(old):
    result = old.replace('20261018_mr3_p2a0_v24_install', '20261018_mr3_p2a0_v25_smoother')
    result = result.replace('v24', 'v25')
    for tail in ('corrector_custody_v3.py', 'corrector_binding_v1.json'):
        result = result.replace('mr3_v25_' + tail, 'mr3_v24_' + tail)
    result = result.replace('custody_asset = asset\n',
                            "custody_asset = asset.replace('20261018_mr3_p2a0_v25_smoother', "
                            "'20261018_mr3_p2a0_v24_install')\n")
    result = result.replace('report/assets/20261018_mr3_p2a0_v25_smoother/independent/mr3_v24_corrector',
                            'report/assets/20261018_mr3_p2a0_v24_install/independent/mr3_v24_corrector')
    result = result.replace("asset = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/"
                            "wireless-rl/report/assets/20261018_mr3_p2a0_v25_smoother/independent'",
                            "asset = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/"
                            "wireless-rl/report/assets/20261018_mr3_p2a0_v24_install/independent'")
    return result.replace('PRIOR_ENGINEERING_WALL_SECONDS = 71.97839368507266',
                          'PRIOR_ENGINEERING_WALL_SECONDS = 569.733696886804')


def inverse(tree, filename):
    """Remove only enumerated new custody/worker metadata nodes, retain every old AST node."""
    tree = copy.deepcopy(tree)
    tree.body = [n for n in tree.body if not (isinstance(n, ast.FunctionDef)
                 and n.name in ('load_checked_smoother', 'observe_smoother'))]
    funcs = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
    main = funcs['main']
    # Three actual entrypoints validate every stage using the one pinned helper.
    main.body = [n for n in main.body if not (
        isinstance(n, ast.ImportFrom) and n.module == 'mr3_v25_stage_worker_bindings_v1')
        and not (isinstance(n, ast.For) and len(n.body) == 1
                 and isinstance(n.body[0], ast.Expr) and isinstance(n.body[0].value, ast.Call)
                 and isinstance(n.body[0].value.func, ast.Name)
                 and n.body[0].value.func.id == 'validate_worker_bindings')]
    if 'buildproof_preflight' in filename:
        start = next(i for i, n in enumerate(main.body) if assigned(n, 'smoother_binding'))
        end = next(i for i, n in enumerate(main.body) if assigned(n, 'binary'))
        del main.body[start:end]
    if 'run_matrix' in filename:
        start = next(i for i, n in enumerate(main.body) if assigned(n, 'worker_helper'))
        end = next(i for i, n in enumerate(main.body) if assigned(n, 'env'))
        del main.body[start:end]
    if 'cross_stage_mapping' in filename:
        main.body = [n for n in main.body if not assigned(n, 'smoother_asset')]
        for n in main.body:
            if isinstance(n, ast.For) and isinstance(n.iter, ast.Tuple):
                assert len(n.iter.elts) == 7
                n.iter.elts = n.iter.elts[:-2]
        capture = funcs['capture']
        capture.body = [n for n in capture.body if not (
            isinstance(n, ast.If) and any(assigned(child, 'smoother_output') for child in n.body))]
    if 'multiepoch_closure' in filename:
        start = next(i for i, n in enumerate(main.body) if isinstance(n, ast.Try)
                     and n.body and isinstance(n.body[0], ast.Assign)
                     and isinstance(n.body[0].value, ast.Call)
                     and isinstance(n.body[0].value.func, ast.Name)
                     and n.body[0].value.func.id == 'load_checked_smoother')
        end = next(i for i, n in enumerate(main.body) if isinstance(n, ast.For)
                   and isinstance(n.target, ast.Tuple)
                   and any(isinstance(v, ast.Name) and v.id == 'bound_path' for v in n.target.elts))
        del main.body[start:end]

    class RemoveMetadata(ast.NodeTransformer):
        def visit_Call(self, node):
            self.generic_visit(node)
            node.keywords = [k for k in node.keywords if k.arg not in (
                'native_smoother_installed_and_source_binding',
                'validated_stage_worker_bindings', 'worker_bindings')]
            return node

        def visit_Dict(self, node):
            self.generic_visit(node)
            pairs = [(k, v) for k, v in zip(node.keys, node.values) if not (
                isinstance(k, ast.Constant) and k.value in (
                    'smoother_mapping_outputs', 'smoother_custody_review',
                    'smoother_custody_passed'))]
            node.keys, node.values = [k for k, _ in pairs], [v for _, v in pairs]
            return node

        def visit_Constant(self, node):
            if node.value == 572.9355761036277:
                node.value = 569.733696886804
            elif isinstance(node.value, str):
                node.value = node.value.replace('creates new /tmp v25 receipts',
                                               'creates new /tmp v22 receipts')
                node.value = node.value.replace('observe existing V25 runs', 'observe existing V22 runs')
                node.value = node.value.replace('V25 template not finalized', 'V23 template not finalized')
                node.value = node.value.replace('final four-stage V25 plan', 'final four-stage V23 plan')
                for suffix in (
                    ' The separately bound smoother mapping outputs preserve actual three-robot '
                    'loaded overlay provenance without changing original monitor rules.',
                    ' Actual three-robot smoother overlay mapping/build/source custody is '
                    'additionally required; all original task/body/stop mathematics remain unchanged.',
                ):
                    node.value = node.value.removesuffix(suffix)
            return node
    return RemoveMetadata().visit(tree)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    args.output.mkdir()
    started = time.monotonic()
    tracked = {}

    def read(path):
        path = Path(path)
        before = path.stat()
        raw = path.read_bytes()
        after = path.stat()
        shape = lambda value: [value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns]
        assert shape(before) == shape(after), str(path)
        tracked[str(path)] = {'sha256': sha(raw), 'bytes': len(raw), 'stat': shape(after)}
        return raw

    sources = []
    for path in sorted((BASE / 'independent').glob('*.py')):
        raw = read(path)
        old = read(BASE / 'baseline_v24' / path.name.replace('v25', 'v24'))
        initial = read(BASE / 'mechanical_draft_v1/independent' / path.name)
        expected = mechanical(old.decode())
        assert expected.encode() == initial, 'initial mechanical whole-byte mismatch ' + path.name
        tree = ast.parse(raw)
        restored = inverse(tree, path.name)
        assert ast.dump(restored, include_attributes=False) == ast.dump(
            ast.parse(initial), include_attributes=False), 'enumerated AST inverse mismatch ' + path.name
        patch = ''.join(difflib.unified_diff(initial.decode().splitlines(True),
                        raw.decode().splitlines(True), fromfile='mechanical/' + path.name,
                        tofile='proposed/' + path.name))
        (args.output / (path.name + '.patch')).write_text(patch)
        sources.append({'path': str(path), 'sha256': sha(raw), 'bytes': len(raw),
                        'baseline_sha256': sha(old), 'mechanical_sha256': sha(initial),
                        'original_AST_after_enumerated_inverse': True,
                        'initial_mechanical_whole_bytes_verified': True})

    plan = json.loads(read(BASE / 'predeclared_plan_v25.draft.json'))
    old_plan_path = ROOT / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
                           'report/assets/20261018_mr3_p2a0_v24_install/predeclared_plan_v24.json')
    old_plan = json.loads(read(old_plan_path))
    gates = ('unchanged_gates', 'physical_response_criteria', 'angular_interface_criteria',
             'angular_reset_criteria', 'settled_turn_criteria', 'full_execution_model_failfast',
             'pilot_budget_unchanged', 'max_api_records', 'max_submitted_script_decisions',
             'max_total_wall_seconds', 'native_ray_box_correction')
    assert all(plan[k] == old_plan[k] for k in gates)
    assert [len(s['required_audit_receipts']) for s in plan['stages']] == [10, 7, 10, 7]
    assert plan['native_admission_granted'] is False
    assert plan['readiness']['status'] != 'ready'
    helper_path = Path('/tmp/mr3_p2a0_v25_smoother_custody_proposal_v1/') / 'mr3_v25_stage_worker_bindings_v1.py'
    helper = read(helper_path)
    assert sha(helper) == '3b685448644d5e1ad50adf3f551107120e13c692865a4e7f6bc0facd2c844e70'
    module = {}
    exec(compile(helper, str(helper_path), 'exec'), module)
    for stage, wanted, old_stage in zip(plan['stages'],
            [[(208, 13801)], [(210, 13811)], [(212, 13821), (213, 13822)], [(216, 13831)]],
            old_plan['stages']):
        rows = module['validate_worker_bindings'](stage)
        assert [(row['domain'], row['port']) for row in rows] == wanted
        assert stage['wall_ceiling_seconds'] == old_stage['wall_ceiling_seconds']
        # Keep every command token except exact version/run/address options byte-for-byte.
        argv = list(stage['command'])
        old_argv = list(old_stage['command'])
        for flag in ('--base-domain', '--base-port'):
            argv[argv.index(flag) + 1] = old_argv[old_argv.index(flag) + 1]
        argv = [x.replace('v25', 'v24') for x in argv]
        assert argv == old_argv, stage['stage']
        normalize = lambda value: value.replace('v25', 'v24')
        assert list(map(normalize, stage['required_audit_receipts'])) == old_stage['required_audit_receipts']
    pair_path = Path('/tmp/mr3_p2a0_v25_actual_probe_pair_v1/execution_v1.json')
    pair_raw = read(pair_path)
    assert sha(pair_raw) == '7d8b6a43de8cdcc5dc41659e95b462e84fb3ed5c1cecb5aa8ec69c44a5161ac0'
    assert plan['prior_engineering_cost']['wall_seconds'] == 572.9355761036277
    assert 569.733696886804 + 3.201879216823727 == plan['prior_engineering_cost']['wall_seconds']
    command = ['/usr/bin/python3', '-m', 'flake8', '--select=E9,F63,F7,F82',
               *map(str, sorted((BASE / 'independent').glob('*.py')))]
    env = dict(os.environ, PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1')
    completed = subprocess.run(command, capture_output=True, env=env, cwd=ROOT)
    (args.output / 'fatalstyle.stdout').write_bytes(completed.stdout)
    (args.output / 'fatalstyle.stderr').write_bytes(completed.stderr)
    assert completed.returncode == 0, 'fatal style failed'
    for path, expected in tracked.items():
        current = Path(path).stat()
        assert [current.st_dev, current.st_ino, current.st_size, current.st_mtime_ns] == expected['stat']
        assert sha(Path(path).read_bytes()) == expected['sha256']
    result = {'passed': True, 'sources': sources, 'unchanged_gate_fields': gates,
              'old34_required_receipts': [10, 7, 10, 7], 'old_reset_pool_and_math_reused': True,
              'actual_command_worker_bindings': [s['worker_bindings'] for s in plan['stages']],
              'actual_carried_wall_seconds': 572.9355761036277,
              'opening_remaining_wall_seconds': 17427.064423896372,
              'fatalstyle': {'argv': command, 'cwd': str(ROOT), 'returncode': completed.returncode,
                             'environment_delta': {'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1'}},
              'inputs': tracked, 'all_input_sha_stat_final_verified': True,
              'wall_seconds': time.monotonic() - started,
              'scope': 'Static AST/whole-byte mechanical inverse, exact stage command/metadata and fatal lint only. '
                       'No preflight/ROS/DDS, benchmark, native, formal reader, test suite or build executed; '
                       'V25 draft is unadmitted pending root final source review.'}
    (args.output / 'checks.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'passed': True, 'output': str(args.output), 'sources': len(sources),
                      'wall_seconds': result['wall_seconds']}))


if __name__ == '__main__':
    main()
