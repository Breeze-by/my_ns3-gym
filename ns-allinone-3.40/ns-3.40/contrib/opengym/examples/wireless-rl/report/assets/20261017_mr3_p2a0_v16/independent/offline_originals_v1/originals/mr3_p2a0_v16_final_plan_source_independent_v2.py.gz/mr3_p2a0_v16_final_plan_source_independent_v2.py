"""Independent read-only V16 plan/source/binary comparison; no auditor imports."""
import ast
import copy
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/home/zhuyulab/ns3-workspace')
WIRELESS = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
ASSETS = WIRELESS / 'report/assets'
FREEZE = '17ef3cb212aacd6e9e4fcde65783bdf2528da955'
PLAN_PATH = ASSETS / '20261017_mr3_p2a0_v16/predeclared_plan_v16.json'
EXPECTED_PLAN_SHA = '5eca58447b8075782bb56ef2506c2bcb8a84e01b5a8233242fe08d963b46bd07'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def frozen(path):
    return subprocess.check_output(['git', 'show', FREEZE + ':' + str(Path(path).relative_to(ROOT))],
                                   cwd=ROOT)


def constants(tree):
    values = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            try:
                value = eval(compile(ast.Expression(node.value), '<static>', 'eval'),
                             {'__builtins__': {}}, values)
            except (NameError, AttributeError, TypeError):
                continue
            values[node.targets[0].id] = value
    return values


def main():
    observed = {}

    def read(path):
        path = Path(path)
        raw = path.read_bytes()
        digest = sha(raw)
        if str(path) in observed:
            assert observed[str(path)] == digest, 'input changed: ' + str(path)
        observed[str(path)] = digest
        return raw

    plan_raw = read(PLAN_PATH)
    assert sha(plan_raw) == EXPECTED_PLAN_SHA
    plan = json.loads(plan_raw)
    old_plan_path = ASSETS / '20261017_mr3_p2a0_v15/predeclared_plan_v15.json'
    old_plan_raw = frozen(old_plan_path)
    old = json.loads(old_plan_raw)
    assert sha(old_plan_raw) == plan['preparation_baseline']['predecessor_plan_sha256']
    assert plan['readiness']['status'] == 'ready' and plan['readiness']['freeze'] is None
    assert plan['readiness']['pending_bindings'] == []
    assert plan['readiness']['native_admission_requires_clean_pushed_exact40_preflight'] is True
    hard_fields = (
        'robots_per_environment', 'kind', 'gpu_calls', 'optimizer_steps', 'max_api_records',
        'max_submitted_script_decisions', 'max_total_wall_seconds', 'pilot_budget_unchanged',
        'unchanged_gates', 'scope_limits', 'next_gate', 'offline_prerequisites',
        'new_execution_contracts', 'physical_response_criteria', 'angular_interface_criteria',
        'angular_reset_criteria', 'drive_contract', 'settled_turn_criteria',
        'information_selection_audit', 'launcher_failure_cleanup_scope', 'controlled_execution_audit',
        'navigation_profile', 'full_execution_model_failfast', 'drive_command_cap_audit',
        'navigation_peer_geometry_repair', 'parameter_reply_wait', 'transport_readback_scope',
        'api_budget_breakdown', 'wall_budget_basis')
    metadata_normalizations = {}
    for field in hard_fields:
        if field in ('physical_response_criteria', 'angular_reset_criteria'):
            normalized_criteria = copy.deepcopy(plan[field])
            metadata_key = ('matrix_eligibility' if field == 'physical_response_criteria' else 'exact_workload')
            consumer = normalized_criteria['matrix_consumer']
            assert '/20261017_mr3_p2a0_v16/independent/' in consumer['path']
            assert sha(read(ROOT / consumer['path'])) == consumer['sha256']
            metadata_normalizations[field] = {
                'current_consumer': consumer, 'previous_consumer': old[field]['matrix_consumer'],
                'current_workload': normalized_criteria[metadata_key],
                'previous_workload': old[field][metadata_key],
                'all_other_values_exactly_unchanged': True}
            normalized_criteria['matrix_consumer'] = old[field]['matrix_consumer']
            normalized_criteria[metadata_key] = normalized_criteria[metadata_key].replace('v5/32-step', 'v3/32-step')
            assert normalized_criteria == old[field], 'non-metadata criteria changed: ' + field
        else:
            assert plan[field] == old[field], 'hard field changed: ' + field
    assert (plan['max_api_records'], plan['max_submitted_script_decisions'],
            plan['max_total_wall_seconds'], plan['gpu_calls'], plan['optimizer_steps']) == (608, 596, 18000, 0, 0)
    assert [stage['stage'] for stage in plan['stages']] == ['interface', 'terminal', 'reset', 'deadline']
    budgets = {}
    for previous, stage in zip(old['stages'], plan['stages']):
        command = stage['command']
        normalized = [value.replace('mr3_p2a0_20261017_v16_', 'mr3_p2a0_20261017_v15_')
                      .replace('mr3-p2a0-outward-cancel-v5', 'mr3-p2a0-outward-cancel-v4')
                      for value in command]
        assert normalized == previous['command']
        assert stage['required_audits'] == previous['required_audits']
        assert stage['wall_ceiling_seconds'] == previous['wall_ceiling_seconds']
        assert stage['on_error'] == previous['on_error']
        assert stage['worker_bindings'] == previous['worker_bindings']
        assert [value.replace('_v16_', '_v15_') for value in stage['required_audit_receipts']] == previous['required_audit_receipts']
        name = stage['stage']
        workers = int(command[command.index('--workers') + 1])
        episodes = workers * len(command[command.index('--schedule') + 1].split(','))
        steps = int(command[command.index('--steps') + 1])
        if name in ('interface', 'reset'):
            assert steps == 32 and '--preparation-motion-probe' in command
            assert command[command.index('--preparation-probe-version') + 1] == 'mr3-p2a0-outward-cancel-v5'
        else:
            assert '--preparation-probe-version' not in command
            assert steps == (4 if name == 'terminal' else 300)
        budgets[name] = {'workers': workers, 'episodes': episodes, 'steps_per_episode': steps,
                         'submitted_decisions': episodes * steps,
                         'api_records': episodes * (steps + 1),
                         'wall_ceiling_seconds': stage['wall_ceiling_seconds']}
        for key in ('information_audit_command_template', 'peer_audit_command_template',
                    'control_audit_command_template', 'settled_turn_audit_command_template'):
            assert [v.replace('_v16_', '_v15_') for v in stage[key]] == previous[key]
    assert sum(row['submitted_decisions'] for row in budgets.values()) == 596
    assert sum(row['api_records'] for row in budgets.values()) == 608
    assert sum(row['wall_ceiling_seconds'] for row in budgets.values()) == 18000

    prior = {row['path']: row['sha256'] for row in old['independent_source_bindings']}
    current = {row['path']: row['sha256'] for row in plan['independent_source_bindings']}
    assert len(prior) == len(old['independent_source_bindings']) == 121
    assert len(current) == len(plan['independent_source_bindings']) == 134
    changed = {path for path in prior if prior[path] != current.get(path)}
    authorized = {str((WIRELESS / 'mr3_learning' / name).relative_to(ROOT)) for name in
                  ('audit_ppo.py', 'audit_preparation.py', 'benchmark.py', 'tests/test_preparation_comparison.py')}
    assert changed == authorized and not (prior.keys() - current.keys())
    added = current.keys() - prior.keys()
    assert len(added) == 13 and sum(current[path] == digest for path, digest in prior.items()) == 117
    for path, digest in current.items():
        assert sha(read(ROOT / path)) == digest, 'binding mismatch: ' + path

    sourcepack_path = ASSETS / '20261017_mr3_p2a0_v15/independent/source_bindings_17ef3cb212aa.json'
    sourcepack = json.loads(read(sourcepack_path))
    assert sourcepack['freeze'] == FREEZE and len(sourcepack['files']) == 101
    runtime_changes = []
    for row in sourcepack['files']:
        path = ROOT / row['path']
        old_raw = frozen(path)
        assert sha(old_raw) == row['sha256']
        actual = sha(read(path))
        if actual != row['sha256']:
            runtime_changes.append({'path': row['path'], 'old_sha256': row['sha256'], 'sha256': actual})
    expected_runtime = {str((WIRELESS / name).relative_to(ROOT)) for name in
                        ('MR3_ENV_CONTRACT.md', 'mr3_learning/audit_ppo.py',
                         'mr3_learning/audit_preparation.py', 'mr3_learning/benchmark.py')}
    assert {row['path'] for row in runtime_changes} == expected_runtime
    ros_production_diff = subprocess.check_output(['git', 'diff', '--name-only', FREEZE, '--',
        'ros2_ws/ros2-multi-robot-automap/src', 'ros2_ws/ros2-multi-robot-automap/scripts'], cwd=ROOT).decode().splitlines()
    ros_untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--',
        'ros2_ws/ros2-multi-robot-automap/src', 'ros2_ws/ros2-multi-robot-automap/scripts'], cwd=ROOT).decode().splitlines()
    assert not ros_production_diff and not ros_untracked

    ppo_path = WIRELESS / 'mr3_learning/audit_ppo.py'
    current_tree = ast.parse(read(ppo_path))
    old_tree = ast.parse(frozen(ppo_path))
    ppo_constants, old_constants = constants(current_tree), constants(old_tree)
    normalized = copy.deepcopy(current_tree)
    changed_literals = 0
    for node in ast.walk(normalized):
        if isinstance(node, ast.Constant) and node.value == ppo_constants['ENV_DOCUMENT_SHA256']:
            node.value = old_constants['ENV_DOCUMENT_SHA256']
            changed_literals += 1
    assert changed_literals == 1 and ast.dump(normalized) == ast.dump(old_tree)
    assert ppo_constants['ENV_DOCUMENT_SHA256'] == sha(read(WIRELESS / 'MR3_ENV_CONTRACT.md'))
    pins = {path: digest for group in ('EVALUATOR_PHASE_PINS', 'PREPARATION_RUNTIME_PINS',
                                     'EXECUTION_CONFIG_PINS') for path, digest in ppo_constants[group].items()}
    assert len(pins) == 36
    assert all(sha(read(ROOT / path)) == digest for path, digest in pins.items())

    wrappers = []
    for stem in ('angular_reset_matrix', 'physics_matrix'):
        before_path = ASSETS / ('20261017_mr3_p2a0_v15/independent/mr3_independent_' + stem + '_v15.py')
        after_path = ASSETS / ('20261017_mr3_p2a0_v16/independent/mr3_independent_' + stem + '_v16.py')
        previous = read(before_path)
        actual = read(after_path)
        inverse = actual.decode().replace('v16 workload adapter: v5/32', 'v15 workload adapter: v4/32')
        inverse = inverse.replace('mr3-p2a0-outward-cancel-v5', 'mr3-p2a0-outward-cancel-v4')
        inverse = inverse.replace('v5 reset', 'v4 reset').replace('predeclared v5 probe', 'predeclared v4 probe')
        assert ast.dump(ast.parse(inverse)) == ast.dump(ast.parse(previous))
        wrappers.append({'path': str(after_path), 'sha256': sha(actual),
                         'old_path': str(before_path), 'old_sha256': sha(previous),
                         'whole_AST_same_after_only_workload_version_doc_message_inverse': True})
    reset = next(stage for stage in plan['stages'] if stage['stage'] == 'reset')
    for key, stem in (('angular_matrix_audit_command_template', 'angular_reset_matrix'),
                      ('physics_matrix_audit_command_template', 'physics_matrix')):
        assert any(value.endswith('/20261017_mr3_p2a0_v16/independent/mr3_independent_' + stem + '_v16.py')
                   for value in reset[key])
    audit_stage = read(ASSETS / '20261017_mr3_p2a0_v16/independent/mr3_p2a0_v16_audit_stage.py').decode()
    assert 'mr3_independent_angular_reset_matrix_v16.py' in audit_stage
    assert 'mr3_independent_physics_matrix_v16.py' in audit_stage

    build_path = ASSETS / '20261017_mr3_p2a0_v13/binary/mr3_p2a0_v13_drive_build_receipt_v1.json'
    build = json.loads(read(build_path))
    assert build['library_sha256'] == 'a014f2c618e38fc8a306d76c100083d952606333045a2e35bffce6f8b25b10c8'
    library = read(build['library_path'])
    installed_library = read(build['installed_path'])
    assert sha(library) == sha(installed_library) == build['library_sha256']
    archived = read(ROOT / build['archived_library_gzip'])
    assert sha(archived) == build['archived_library_encoded_sha256']
    assert gzip.decompress(archived) == library
    macro_paths = {
        'compiled_source_sha256': 'src/mr3_gazebo_diff_drive.cpp',
        'compiled_header_sha256': 'include/multi_robot/mr3_gazebo_diff_drive.hpp',
        'compiled_helper_sha256': 'include/multi_robot/paired_wheel_slew.hpp',
        'compiled_target_contract_sha256': 'include/multi_robot/mr3_drive_target.hpp'}
    macros = {}
    package = ROOT / 'ros2_ws/ros2-multi-robot-automap/src/multi_robot'
    for key, suffix in macro_paths.items():
        path = package / suffix
        assert read(path) == frozen(path)
        assert sha(read(path)) == build[key] and build[key].encode() in library
        macros[key] = {'path': str(path), 'sha256': build[key], 'literal_in_identical_actual_ELF': True}
    installed_configs = []
    for suffix in ('params/nav2_params_tb1_0.yaml', 'params/nav2_params_tb2_0.yaml',
                   'params/nav2_params_tb3_0.yaml', 'config/nav2_params.yaml',
                   'models/turtlebot3_waffle/model.sdf'):
        path = package / suffix
        installed = ROOT / 'ros2_ws/ros2-multi-robot-automap/install/multi_robot/share/multi_robot' / suffix
        assert read(path) == frozen(path) == read(installed)
        installed_configs.append({'source': str(path), 'installed': str(installed), 'sha256': sha(read(path))})
    for path, digest in observed.items():
        assert sha(Path(path).read_bytes()) == digest, 'source changed during review: ' + path
    report = {'schema': 'mr3-v16-final-plan-source-independent-v2', 'passed': True,
              'plan': {'path': str(PLAN_PATH), 'sha256': sha(plan_raw), 'readiness': plan['readiness']},
              'predecessor': {'freeze': FREEZE, 'plan_sha256': sha(old_plan_raw)},
              'unchanged_plan_hard_fields_exactly_compared': [field for field in hard_fields if field not in metadata_normalizations],
              'criteria_after_explicit_workload_metadata_normalization': metadata_normalizations,
              'stage_budgets': budgets, 'budgets': {'api': 608, 'submitted': 596, 'wall_seconds': 18000},
              'stage_commands': 'Only interface/reset V4->V5 probe selector and all stage run-ID V15->V16; terminal/deadline workload unchanged.',
              'bindings': {'old': 121, 'unchanged': 117, 'authorized_current_refresh': sorted(changed),
                           'new': 13, 'added_paths': sorted(added), 'all_134_current_files_SHA_match': True},
              'runtime_101': {'sourcepack': str(sourcepack_path), 'sourcepack_sha256': observed[str(sourcepack_path)],
                              'all_old_pack_hashes_bound_to_original_git_bytes': True,
                              'only_current_changes': runtime_changes},
              'ROS_production_and_scripts_diff_from_V15': ros_production_diff,
              'ROS_untracked_production_files': ros_untracked,
              'audit_ppo': {'only_ENV_digest_literal_changed': True, 'whole_remaining_AST_equal': True,
                            'current36_pins_match': True, 'ENV_digest': ppo_constants['ENV_DOCUMENT_SHA256']},
              'reset_metadata_wrappers': wrappers,
              'actual_binary': {'library_sha256': sha(library), 'installed_matches': True,
                                'old_archived_a014_bytes_identical': True, 'four_macros': macros,
                                'scope': 'Static byte/literal identity with old reviewed a014; not a new loaded-process/runtime custody proof.'},
              'installed_configs': installed_configs,
              'all_observed_source_hashes_before_after': observed,
              'historical_baseline_leaves': 'The formerly stale reset template and matrix workload consumer leaves are now explicitly A16/V5. Those exact metadata changes were normalized above; no assertion that entire criteria objects remain identical. Original raw/angular/physical consumers, all numeric limits and other criteria values remain immutable.',
              'prior_template_failure_retained': {
                  'path': '/tmp/mr3_p2a0_v16_predeclared_before_reset_template_fix_v1.json',
                  'sha256': sha(read('/tmp/mr3_p2a0_v16_predeclared_before_reset_template_fix_v1.json')),
                  'original_execution': '/tmp/mr3_p2a0_v16_final_plan_source_independent_execution_v1.json',
                  'scope': 'Original expected old-A8-workload-template mismatch FAIL, not native failure; no old result rewritten.'},
              'scope': 'Read-only static plan, AST, Git/source/hash/installed binary identity. No ROS imports, native/formal auditors, test suites, process control or Git writes. Ready plan still requires clean pushed exact40 preflight before admission; no inherited native PASS or training credit.'}
    output = Path('/tmp/mr3_p2a0_v16_final_plan_source_independent_v2.json')
    with output.open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'passed': True, 'output': str(output), 'sha256': sha(output.read_bytes()),
                      'bindings': [117, 4, 13], 'runtime_changes': len(runtime_changes),
                      'binary_sha256': sha(library)}))


if __name__ == '__main__':
    main()
