"""Capture draft-only compatibility/tests; never invoke coordinator/native main."""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
OUT = Path('/tmp/mr3_p2a0_v13_matrix_templates_v1')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def dump_new(path, data):
    with path.open('x') as stream:
        stream.write(json.dumps(data, indent=2, allow_nan=False) + '\n')


def main():
    plan = json.loads((OUT / 'predeclared_plan_v13.json').read_bytes())
    old = json.loads((W / 'report/assets/20261017_mr3_p2a0_v12/predeclared_plan_v12.json').read_bytes())
    assert plan['unchanged_gates'] == old['unchanged_gates']
    assert plan['physical_response_criteria'] == old['physical_response_criteria']
    assert plan['angular_interface_criteria'] == old['angular_interface_criteria']
    assert plan['angular_reset_criteria'] == old['angular_reset_criteria']
    assert plan['independent_source_bindings'] == old['independent_source_bindings']
    assert plan['pilot_budget_unchanged'] == old['pilot_budget_unchanged']
    assert plan['max_api_records'] == 608 and plan['max_submitted_script_decisions'] == 596
    assert plan['max_total_wall_seconds'] == 18000 and plan['external_probe_v3'] == old['external_probe_v3']
    for binding in plan['independent_source_bindings']:
        assert sha(ROOT / binding['path']) == binding['sha256']
    for stage, previous in zip(plan['stages'], old['stages']):
        assert len(stage['required_audit_receipts']) == len(previous['required_audit_receipts'])
        assert all('mr3_p2a0_v13_' + stage['stage'] in p for p in stage['required_audit_receipts'])
        assert all('mr3_p2a0_20261017_v13_' + stage['stage'] in stage[k]
                   for k in ('run_directory',))
        for key in ('--steps', '--workers', '--schedule'):
            assert stage['command'][stage['command'].index(key) + 1] == previous['command'][previous['command'].index(key) + 1]
    source_rows = []
    for p in OUT.glob('*.py'):
        text = p.read_text(); ast.parse(text)
        if 'closure' not in p.name:
            assert "plan['readiness']['status'] == 'ready'" in text
        assert 'mr3_p2a0_v12' not in text
        source_rows.append({'path': str(p), 'sha256': sha(p)})
    audit = (OUT / 'mr3_p2a0_v13_audit_stage.py').read_text()
    assert "mr3_independent_drive_trace_v6.py" in audit
    assert "'/tmp/mr3_p2a0_v13_binaryproof.json'" in audit
    assert 'ThreadPoolExecutor(max_workers=4)' in audit
    assert 'physical_job.result()' in audit and 'for future in fifo_jobs:' in audit
    assert "pool.shutdown(wait=True)" in audit
    closure = (OUT / 'mr3_v13_multiepoch_closure_binary_review_v1.py').read_text()
    assert 'mr3_p2a0_v13_binaryproof.json' in closure
    checks = [{'name': 'template_static_gates_and_paths', 'passed': True,
               'scope': 'AST/content inspection only, no coordinator main/subprocess/native execution'}]
    commands = [
        ('new_cap_13', ['/usr/bin/python3', '/tmp/mr3_independent_drive_trace_v6_tests.py']),
        ('immutable_v5_and_v4_mutations', ['/usr/bin/python3', str(W / 'report/assets/20261017_mr3_p2a0_v10/independent/mr3_independent_drive_trace_v5_tests.py')])]
    for label, command in commands:
        start = time.monotonic()
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONNOUSERSITE': '1'}, check=False)
        for name, raw in [('stdout', result.stdout), ('stderr', result.stderr)]:
            with (OUT / (label + '.' + name)).open('xb') as stream:
                stream.write(raw)
        checks.append({'name': label, 'argv': command, 'returncode': result.returncode,
            'passed': result.returncode == 0, 'wall_seconds': time.monotonic() - start,
            'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
            'stderr_sha256': hashlib.sha256(result.stderr).hexdigest(),
            'scope': 'Synthetic CPU mutations only; mocks in new-cap composition tests explicitly scoped; no native result'})
    compatibility = {'schema': 'mr3-v13-consumer-compatibility-review-v1',
        'status': 'source_review_and_CPU_only',
        'immutable_consumers': [
            {'name': 'wholeinput ab102', 'command_dot26_hardcode': False, 'action': 'reuse unchanged exact CLI; candidate/tensor/map reconstruction uses episode exact Git source'},
            {'name': 'angular7a472', 'command_dot26_hardcode': False, 'action': 'retain full angular1.2/vector sampled acceleration7 and interface bidirectional coverage; no command-cap substitution'},
            {'name': 'physical2516', 'command_dot26_hardcode': False, 'action': 'retain rawbody.30/.78/.144 and original reset pooled wrapper; original per-episode missing-stop FAIL remains'},
            {'name': 'drive v5 1010 + v4 6aa1', 'command_dot26_hardcode': True,
             'locations': ['v5 guard_outputs line114', 'v4 guard_outputs line199', 'v4 robot_audit command_received line395'],
             'action': 'new v6 actually calls immutable full v5 review then adds exact final.20/.8 guard/publication/native received/actuation desired target checks; no old gates disabled'},
        ],
        'compiled_helper_binding': 'Immutable v4 source_bindings computes all four SHAs from exact requested Git objects; no fixed80cf helper SHA exemption. New directed helper requires real new build receipt/SO gzip/four compiled macros/source/install SHA and new binaryproof. Prior d0d receipt is not reusable.',
        'parameter_readback': {'old_v4_immutable': True, 'new_reader_and_spec': '/tmp/mr3_p2a0_v13_navigation_profile_draft_v1',
            'root_hook_change_required': ['benchmark.PARAMETER_REVIEW_SCRIPT new frozen asset path/Git bytes',
                'same canonical seven-key transport/profile/None-pop checks and finite cleanup unchanged',
                'new actual9 profile typed caps/plugin/primary/shim/accel/critic values; actual source/install/plugin mapping separately required']},
        'pending_final_source': plan['readiness']['pending_bindings'],
        'raw_final_boundary': 'Only inspect already-final normalized output values, never rewrite original request/raw/log. Exact .20 passes; nextafter(.20,+inf) final output fails. Original request can be +1ULP if producer truly normalized final output.'}
    dump_new(OUT / 'consumer_compatibility_v1.json', compatibility)
    bindings = [{'path': str(p), 'sha256': sha(p)} for p in [
        Path('/tmp/mr3_independent_drive_trace_v6.py'), Path('/tmp/mr3_independent_drive_trace_v6_tests.py'),
        OUT / 'predeclared_plan_v13.json', OUT / 'source_bindings_template_v1.json',
        OUT / 'consumer_compatibility_v1.json', Path(__file__)]]
    dump_new(OUT / 'checks_v1.json', {'schema': 'mr3-v13-template-and-cap-reader-checks-v1',
        'passed': all(row['passed'] for row in checks), 'checks': checks, 'bindings': bindings,
        'coordinator_draft_sources': source_rows,
        'native_or_formal_run_started': False, 'git_files_modified': False,
        'scope': 'New source draft only; inherited sources immutable; no V12 audit repeated and no V13 native credit'})
    print(json.dumps({'passed': all(row['passed'] for row in checks), 'output': str(OUT / 'checks_v1.json'),
        'sha256': sha(OUT / 'checks_v1.json'), 'readers': bindings[:2]}))


if __name__ == '__main__':
    main()
