import ast,hashlib,json,pathlib,subprocess
R=pathlib.Path("/home/zhuyulab/ns3-workspace");T=pathlib.Path("/tmp");W=pathlib.Path("ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl");BASE="ebe7d51bdb7bf9d77a28b77cfb4296876afb0100";OLD=W/"report/assets/20261017_mr3_p2a0_v16";D=T/"mr3_p2a0_v17_matrix_draft_v1"
D.mkdir(exist_ok=False);(D/"independent").mkdir();sha=lambda b:hashlib.sha256(b).hexdigest()
names=["mr3_p2a0_v16_buildproof_preflight.py","mr3_p2a0_v16_launch_stage.py","mr3_p2a0_v16_audit_stage.py","mr3_p2a0_v16_cross_stage_mapping_monitor_v1.py","mr3_v16_multiepoch_closure_binary_review_v1.py","mr3_p2a0_v16_plan_launcher_tests_v1.py","mr3_p2a0_v16_audit_stage_tests_v1.py","mr3_v16_nested_closure_read_tests_v1.py","mr3_v16_shim_path_adapter_tests_v1.py"]
files=[];changes=[]
for name in names:
 relative=OLD/"independent"/name;raw=subprocess.check_output(["git","show",BASE+":"+str(relative)],cwd=R);assert (R/relative).read_bytes()==raw
 new=raw.replace(b"v16",b"v17").replace(b"V16",b"V17");target=D/"independent"/name.replace("v16","v17")
 with target.open("xb") as f:f.write(new)
 reverse=new.replace(b"v17",b"v16").replace(b"V17",b"V16");assert reverse==raw;assert ast.dump(ast.parse(reverse),include_attributes=False)==ast.dump(ast.parse(raw),include_attributes=False)
 for node in ast.walk(ast.parse(raw)):
  if isinstance(node,ast.Constant) and isinstance(node.value,str) and (node.value in ["20261017_mr3_p2a0_v16/independent/mr3_independent_angular_reset_matrix_v16.py","20261017_mr3_p2a0_v16/independent/mr3_independent_physics_matrix_v16.py"] or name.endswith("audit_stage_tests_v1.py") and node.value=="mr3_independent_physics_matrix_v16.py"):
   changes.append(dict(file=target.name,previous=node.value,current=node.value.replace("v16","v17")))
 files.append(dict(source_git=BASE+":"+str(relative),source_sha256=sha(raw),draft=str(target),draft_sha256=sha(new),reverse_bytes_and_whole_AST_equal=True))
assert len(changes)==4
for name in ["mr3_p2a0_v16_run_matrix_v1.py","mr3_p2a0_v16_run_matrix_v1_tests.py"]:
 source=T/name;raw=source.read_bytes();new=raw.replace(b"v16",b"v17").replace(b"V16",b"V17");target=D/name.replace("v16","v17")
 with target.open("xb") as f:f.write(new)
 assert new.replace(b"v17",b"v16").replace(b"V17",b"V16")==raw
 files.append(dict(source=str(source),source_sha256=sha(raw),draft=str(target),draft_sha256=sha(new),reverse_bytes_and_whole_AST_equal=True))
old=json.loads(subprocess.check_output(["git","show",BASE+":"+str(OLD/"predeclared_plan_v16.json")],cwd=R));assert len(old["independent_source_bindings"])==134
def version(v):
 if isinstance(v,str):return v.replace("v16","v17").replace("V16","V17")
 if isinstance(v,list):return [version(x) for x in v]
 if isinstance(v,dict):return {k:version(x) for k,x in v.items()}
 return v
plan=version(old);plan["independent_source_bindings"]=old["independent_source_bindings"]
for key in ["external_probe_v3","external_probe_v4","external_probe_v5"]:
 if key in old:plan[key]=old[key]
for stage in plan["stages"]:
 command=stage["command"]
 if stage["stage"] in ("interface","reset"):
  assert command[command.index("--steps")+1]=="32";assert command[command.index("--preparation-probe-version")+1]=="mr3-p2a0-outward-cancel-v5";command[command.index("--preparation-probe-version")+1]="mr3-p2a0-outward-cancel-v6"
reset=next(s for s in plan["stages"] if s["stage"]=="reset")
for key in ["angular_matrix_audit_command_template","physics_matrix_audit_command_template"]:assert "20261017_mr3_p2a0_v17/" in reset[key][1] and "_v17.py" in reset[key][1]
for key in ["physical_response_criteria","angular_reset_criteria"]:
 plan[key]["matrix_consumer"]["sha256"]=None;plan[key]["matrix_consumer"]["pending_binding"]=True
plan["physical_response_criteria"]["matrix_eligibility"]=old["physical_response_criteria"]["matrix_eligibility"].replace("v5/32","v6/32")
plan["angular_reset_criteria"]["exact_workload"]=old["angular_reset_criteria"]["exact_workload"].replace("v5/32","v6/32")
authorized=[row["path"] for row in old["independent_source_bindings"] if pathlib.Path(row["path"]).name in {"audit_ppo.py","audit_preparation.py","benchmark.py","test_preparation_comparison.py"}];assert len(authorized)==4
plan["authorized_current_binding_refresh_pending"]=authorized;plan["historical_bindings_scope"]="134 predecessor bindings are historical draft inputs; root must refresh only four authorized current paths and retain the other130 exact SHA values. New dependencies are listed pending, final count not asserted."
plan["new_source_bindings_pending"]=[dict(path=str(W/"report/assets/20261017_mr3_p2a0_v17/independent"/pathlib.Path(row["draft"]).name),sha256=row["draft_sha256"]) for row in files[:9]]
plan["readiness"]={"status":"draft_pending_root_final_review","freeze":None,"pending_bindings":["final externalV6 source/portabletest/reset-wrapper dependencies and actual SHA","root authorized four-current refresh, final source checks and dynamic binding count","offline custody, final commit/push and exact40 preflight"],"no_native_or_formal_authorized_by_this_template":True};plan["native_admission_granted"]=False
plan["external_probe_v6"]={"version":"mr3-p2a0-outward-cancel-v6","steps_per_episode":32,"status":"draft_pending_final_candidate_semantics_and_bindings","reset_metadata_wrappers":[reset["angular_matrix_audit_command_template"][1],reset["physics_matrix_audit_command_template"][1]],"scope":"Versioned external engineering fixture only; no production actor/candidate/truth/safety/math changes. Raw7a472/2516 consumers and required gates unchanged."}
plan["preparation_baseline"]={"source_freeze":BASE,"closed_commit":"db6410f","predecessor_plan_sha256":sha((R/OLD/"predeclared_plan_v16.json").read_bytes()),"unchanged_workload_steps":32,"unchanged_api_ceiling":608,"unchanged_action_ceiling":596,"unchanged_native_wall_ceiling":18000}
for key in ["unchanged_gates","settled_turn_criteria","angular_interface_criteria","full_execution_model_failfast","pilot_budget_unchanged","max_api_records","max_submitted_script_decisions","max_total_wall_seconds"]:assert plan[key]==old[key],key
assert [plan[k] for k in ["max_api_records","max_submitted_script_decisions","max_total_wall_seconds"]]==[608,596,18000]
for key,changes_allowed in [("physical_response_criteria",["matrix_consumer","matrix_eligibility"]),("angular_reset_criteria",["matrix_consumer","exact_workload"])]:assert {k:v for k,v in plan[key].items() if k not in changes_allowed}=={k:v for k,v in old[key].items() if k not in changes_allowed}
output=D/"predeclared_plan_v17.json"
with output.open("x") as f:json.dump(plan,f,indent=2);f.write("\n")
result=dict(passed=True,files=files,whole_reverse_bytes_and_AST_equal=True,extra_reset_tool_literals=changes,historical_bindings_pending=134,authorized_current_refresh=authorized,required_unchanged_old_bindings=130,final_binding_count_not_guessed=True,plan_sha256=sha(output.read_bytes()),scope="Only /tmp V17 mechanical draft; no canonical promotion, native/formal or admission. New active reset templates and matrix-consumer paths target A17; exactV6 metadata only, new wrapper SHA remains pending.")
with (D/"generation_v1.json").open("x") as f:json.dump(result,f,indent=2);f.write("\n")
print(json.dumps({k:v for k,v in result.items() if k!="files"},indent=2));print("GENERATION_SHA",sha((D/"generation_v1.json").read_bytes()))
