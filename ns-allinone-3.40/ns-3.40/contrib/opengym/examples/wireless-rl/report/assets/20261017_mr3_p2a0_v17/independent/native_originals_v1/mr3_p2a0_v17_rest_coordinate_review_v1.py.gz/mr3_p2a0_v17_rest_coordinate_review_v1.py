"""Independent source-point and post-stop arithmetic diagnosis; never runs formal gates."""
import ctypes
import gzip
import hashlib
import json
import math
from pathlib import Path
import statistics
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
ROS = ROOT / 'ros2_ws/ros2-multi-robot-automap'
DATA = Path('/tmp/mr3_p2a0_v17_stop_response_raw_diagnostic_v1')
OUT = Path('/tmp/mr3_p2a0_v17_rest_coordinate_review_v1.json')
SOURCE = ROS / 'src/multi_robot/src/mr3_gazebo_diff_drive.cpp'
READER = W / 'report/assets/20261017_mr3_p2a0_v3/independent/mr3_independent_physics_review.py'
OLD = W / ('report/assets/20261017_mr3_p2a0_v13/independent/candidate_offline/originals/'
           'mr3_p2a0_v13_stop_point_review_v1')
INPUTS = {}


def digest(value):
    return hashlib.sha256(value).hexdigest()


def read(path):
    value = path.read_bytes()
    INPUTS[str(path)] = digest(value)
    return value


def span(values):
    return {'min': min(values), 'max': max(values), 'mean': statistics.fmean(values)}


def yaw(q):
    w, x, y, z = (q[key] for key in ('w', 'x', 'y', 'z'))
    scale = math.sqrt(w*w + x*x + y*y + z*z)
    w, x, y, z = w/scale, x/scale, y/scale, z/scale
    return math.atan2(2*(x*y + w*z), w*w + x*x - y*y - z*z)


started = time.monotonic()
result = {'schema': 'mr3-v17-independent-rest-coordinate-review-v1', 'passed': False,
          'scope': 'Read-only source and selected-row arithmetic diagnosis, not a formal '
                   'consumer rerun/native experiment. Original V17 physical FAIL preserved. '
                   'Runtime-selected rows independently bound to compressed original-row bytes; '
                   'large original motion files are not scanned again.'}
try:
    driver = read(SOURCE)
    reader = read(READER)
    if digest(driver) != '09f741ee154d620fb3d62f8473853929231093fd8cc0b9a4be62b535b514dc05':
        raise ValueError('driver bytes differ')
    if digest(reader) != '2516e394f60eac5dd24fd66b51c4c48fc37245090eb1626ebe1c7a3a23f8bafb':
        raise ValueError('immutable reader bytes differ')
    official = json.loads(gzip.decompress(read(OLD / 'official_sources_v1.json.gz')))
    official_sources = {}
    for name in ('Model.cc', 'Link.cc', 'Entity.cc', 'ODELink.cc'):
        path = OLD / (name + '.gz')
        decoded = gzip.decompress(read(path))
        expected = next(item for item in official if Path(item['path']).name == name)
        if digest(decoded) != expected['sha256']:
            raise ValueError('archived official source mismatch')
        official_sources[name] = {'canonical_archive': str(path), 'encoded_sha256': INPUTS[str(path)],
                                  'decoded_sha256': digest(decoded), 'official_url': expected['url']}
    for name in ('Model', 'Link', 'Entity'):
        read(Path('/usr/include/gazebo-11/gazebo/physics') / (name + '.hh'))
    read(Path('/usr/include/ignition/math6/gz/math/Quaternion.hh'))
    libm = ctypes.CDLL('libm.so.6')
    for name in ('cosf', 'sinf'):
        fun = getattr(libm, name)
        fun.argtypes = [ctypes.c_float]
        fun.restype = ctypes.c_float
    physical = json.loads(read(Path('/tmp/mr3_p2a0_v17_reset_physical_per_episode_v1.json')))
    episodes = []
    for name in ('episode002_open_101', 'episode003_rooms_101'):
        directory = DATA / name
        report = json.loads(read(directory / 'report.json'))
        unique = json.loads(read(directory / 'unique_own_odom.json'))
        selected = directory / 'motion_tb1_selected.jsonl.gz'
        encoded = read(selected)
        decoded = gzip.decompress(encoded)
        manifest = next(item for item in report['input_manifest'] if item['selected_path'] == str(selected))
        if (digest(encoded) != manifest['selected_encoded_sha256']
                or digest(decoded) != manifest['selected_decoded_sha256']):
            raise ValueError('selected original row archive differs')
        raw_odom = {}
        commands = []
        for line in decoded.splitlines(keepends=True):
            row = json.loads(line)
            if row['epoch'] != report['epoch']:
                raise ValueError('selected row epoch differs')
            if row['kind'] == 'own_odom':
                message = row['payload']['message']
                stamp = message['header']['stamp']
                source = stamp['sec'] * 10**9 + stamp['nanosec']
                if source in raw_odom:
                    raise ValueError('unexpected duplicate selected own source')
                raw_odom[source] = (row, message, digest(line))
            elif row['kind'] == 'actual_cmd_vel':
                commands.append(row)
        rows = []
        for item in unique:
            original, msg, line_sha = raw_odom[item['source_ns']]
            linear = [msg['twist']['twist']['linear'][key] for key in ('x', 'y', 'z')]
            position = [msg['pose']['pose']['position'][key] for key in ('x', 'y', 'z')]
            if (line_sha != item['raw_line_sha256'] or linear != item['linear_xyz']
                    or position != item['position_xyz']):
                raise ValueError('derived own odom differs from raw selected row')
            body_speed = math.hypot(*linear[:2])
            if body_speed != item['planar_speed']:
                raise ValueError('raw planar hypot differs from derived value')
            if [msg['header']['frame_id'], msg['child_frame_id']] != item['frames']:
                raise ValueError('frame binding differs')
            angle = ctypes.c_float(yaw(msg['pose']['pose']['orientation'])).value
            c, s = libm.cosf(angle), libm.sinf(angle)
            normscale = math.hypot(c, s)
            point = dict(item, independent_planar_hypot=body_speed,
                         float_rotation_norm_scale=normscale,
                         reconstructed_world_xy_velocity=[(c*linear[0] - s*linear[1])/(c*c+s*s),
                                                          (s*linear[0] + c*linear[1])/(c*c+s*s)])
            rows.append(point)
        if len(rows) != len(raw_odom) or any(b['source_ns'] <= a['source_ns'] for a, b in zip(rows, rows[1:])):
            raise ValueError('source sample coverage/order differs')
        event_report = next(item for item in physical['episodes'] if item['epoch'] == report['epoch'])['robots']['tb1']
        failures = [event for field in ('stop_responses', 'cancel_stop_responses')
                    for event in event_report[field]
                    if event['eligible'] and event['status'] != 'sampled_response_within_declared_bounds']
        event_stats = []
        for event in failures:
            clock = event['event_clock_ns']
            post = [item for item in rows if clock < item['source_ns'] <= report['physics_end_ns']]
            first_rest = next((post[index:index+3] for index in range(len(post)-2)
                               if all(item['independent_planar_hypot'] <= .01 for item in post[index:index+3])), [])
            expected_rest = event.get('rest_source_ns')
            actual_rest = first_rest[0]['source_ns'] if first_rest else None
            if actual_rest != expected_rest:
                raise ValueError('independent selected raw first rest differs from original physical report')
            horizon = [item for item in post if item['source_ns'] > clock + 780_000_000]
            edges = []
            for a, b in zip(horizon, horizon[1:]):
                dt = (b['source_ns'] - a['source_ns']) / 1e9
                chord = math.dist(a['position_xyz'][:2], b['position_xyz'][:2])
                edges.append({'start_ns': a['source_ns'], 'end_ns': b['source_ns'],
                              'chord_m': chord, 'chord_speed_mps': chord/dt})
            examples = [horizon[0], max(horizon, key=lambda item: abs(item['linear_xyz'][1])),
                        min(horizon, key=lambda item: item['independent_planar_hypot']), horizon[-1]] + first_rest
            event_stats.append({'category': event['event_category'], 'event_ns': clock,
                                'original_status': event['status'], 'original_first_rest_source_ns': expected_rest,
                                'independent_first_rest_source_ns': actual_rest,
                                'independent_latency_sec': None if actual_rest is None else (actual_rest-clock)/1e9,
                                'post_horizon_samples': len(horizon),
                                'post_horizon_above_rest_speed': sum(item['independent_planar_hypot'] > .01 for item in horizon),
                                'post_horizon_forward_abs_mps': span([abs(item['linear_xyz'][0]) for item in horizon]),
                                'post_horizon_lateral_abs_mps': span([abs(item['linear_xyz'][1]) for item in horizon]),
                                'post_horizon_planar_norm_mps': span([item['independent_planar_hypot'] for item in horizon]),
                                'post_horizon_pose_chord_path_m': sum(item['chord_m'] for item in edges),
                                'post_horizon_pose_chord_speed_mps': span([item['chord_speed_mps'] for item in edges]),
                                'float_rotation_norm_relative_error_max': max(abs(item['float_rotation_norm_scale']-1.) for item in horizon),
                                'max_source_gap_ns': max(b['source_ns']-a['source_ns'] for a, b in zip(post, post[1:])),
                                'row_examples_with_original_line_identity': examples})
        # Read only first configuration row, rather than repeat runtime wheel extraction.
        original_ep = Path(next(item['source'] for item in report['input_manifest']
                                if item['source'].endswith('/drive_tb1.jsonl'))).parent
        drive = original_ep / 'drive_tb1.jsonl'
        with drive.open('rb') as handle:
            configuration_raw = handle.readline()
        configuration = json.loads(configuration_raw)
        if (configuration['compiled_source_sha256'] != digest(driver)
                or configuration['odometry_source'] != 1):
            raise ValueError('actual producer configuration source/mode differs')
        sdf_path = original_ep / 'drive_model_tb1.sdf'
        sdf = ET.fromstring(read(sdf_path)).find('model')
        links = [{'name': link.attrib['name'], 'pose': link.findtext('pose', '0 0 0 0 0 0'),
                  'inertial_pose': link.findtext('inertial/pose'), 'mass': link.findtext('inertial/mass')}
                 for link in sdf.findall('link')]
        joints = [{'name': joint.attrib['name'], 'type': joint.attrib['type'],
                   'parent': joint.findtext('parent'), 'child': joint.findtext('child'),
                   'pose': joint.findtext('pose', '0 0 0 0 0 0')}
                  for joint in sdf.findall('joint') if joint.attrib['name'] in
                  ('base_joint', 'wheel_left_joint', 'wheel_right_joint')]
        if links[0]['name'] != 'base_footprint' or links[0]['pose'] != '0 0 0 0 0 0':
            raise ValueError('canonical point premise differs in actual spawned SDF')
        zero_clock = next(event['event_ns'] for event in event_stats if event['category'] == 'A_final_linear_zero')
        after = [item for item in commands if zero_clock <= round(item['sim_time_sec']*1e9) <= report['physics_end_ns']]
        all_zero = bool(after) and all(item['payload']['twist']['linear']['x'] == 0.
                                      and item['payload']['twist']['angular']['z'] == 0. for item in after)
        if not all_zero:
            raise ValueError('selected actual output stream resumed')
        episodes.append({'epoch': report['epoch'], 'raw_source_provenance_from_runtime_single_read': {
                            'source': manifest['source'], 'sha256': manifest['source_sha256'],
                            'bytes': manifest['source_bytes'], 'scope': 'Original full-file SHA inherited '
                            'from runtime single-pass extraction; not independently rescanned here.'},
                         'selected_raw_verified_against_derived_rows': len(rows),
                         'frames': rows[0]['frames'], 'physics_end_ns': report['physics_end_ns'],
                         'post_A_actual_final_output_zero_samples': len(after),
                         'all_selected_post_A_actual_vw_zero': all_zero,
                         'configuration_row_sha256': digest(configuration_raw),
                         'actual_configuration': configuration, 'actual_sdf_links': links,
                         'actual_sdf_joints': joints, 'events': event_stats})
    result.update(passed=True, episodes=episodes,
                  installed_packages=subprocess.check_output(['dpkg-query', '-W', '-f=${Package} ${Version}\n',
                                                              'gazebo', 'libgazebo-dev', 'libgazebo11'], text=True).splitlines(),
                  official_source_custody=official_sources,
                  source_point_findings=[
                      'Gazebo11 Model::WorldLinearVel delegates to canonical link. Link no-argument '
                      'WorldLinearVel delegates zero offset; ODE offset getter subtracts inertial CoG '
                      'and calls dBodyGetRelPointVel. It measures link-frame origin, not bare CoG.',
                      'Actual SDF first link base_footprint has default zero relative pose. Entity '
                      'updates model pose as canonical-link pose minus initial relative pose; the '
                      'declared canonical origin and model pose origin coincide in this SDF.',
                      'base_link has explicit CoG(-.064,0,.048) and zero-pose fixed base_joint. '
                      'That is not evidence that Model::WorldLinearVel returns base_link CoG velocity.',
                      'Actual WORLD mode driver publishes model pose and canonical-origin world '
                      'linear XY, rotated with floatyaw cosf/sinf into base_footprint. This is an '
                      'XY rotation without point translation; raw XY norm is almost invariant.',
                      'Wheel feedback is joint angular velocity times radius. Paired wheel slew '
                      'bounds commanded/measured rim increments, not world-body lateral motion. '
                      'Zero wheel targets alone do not establish canonical-origin rest.'],
                  reader_findings=[
                      'Immutable2516 computes math.hypot(rawlinear.x,rawlinear.y), not abs(vx), '
                      'while position polyline/chord is a separate observed quantity.',
                      'Meaningful stop requires prior span>=.1 and anchor speed>=.05. Rest uses '
                      'three consecutive fresh source samples with planar norm<=.01. Current '
                      'independent subset first-rest scan matches both delayed/missing results.',
                      'Per-robot A-or-B positive credit does not cancel any observed nonrest '
                      'beyond .78s or bound violation. Earlier credited stop cannot hide later failure.'],
                  limitations=[
                      'Independent arithmetic consumes preserved runtime selected raw rows and '
                      'validates compressed/decoded SHA and every derived row raw-line SHA; large '
                      'full motion-file hashes are extraction provenance, not another independent scan.',
                      'Small finite pose path and larger instantaneous velocity norm are different '
                      'sampled measures. Disagreement alone proves neither a measurement bug nor noise.',
                      'Floatyaw error is measured; no CoG/point correction is justified by current '
                      'SDF/API evidence. Unlogged per-link/contact/solver/update-phase state remains unknown.',
                      'Reconstructed world XY velocity is the inverse of the same published driver '
                      'formula, not an independent physical oracle. No new truth/actor input or gate change.'])
    if not all(digest(Path(path).read_bytes()) == value for path, value in INPUTS.items()):
        raise ValueError('review inputs changed')
    result['source_before_after_stable'] = True
except Exception as error:
    result['passed'] = False
    result['error'] = type(error).__name__ + ': ' + str(error)
result['inputs_sha256'] = INPUTS
result['tool_sha256'] = digest(Path(__file__).read_bytes())
result['wall_seconds'] = time.monotonic() - started
with OUT.open('x') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
print(json.dumps({'output': str(OUT), 'sha256': digest(OUT.read_bytes()),
                  'passed': result['passed'], 'error': result.get('error'),
                  'events': [{'epoch': episode['epoch'],
                              'category': event['category'], 'event_ns': event['event_ns'],
                              'latency': event['independent_latency_sec'],
                              'lateral': event['post_horizon_lateral_abs_mps'],
                              'chord_path': event['post_horizon_pose_chord_path_m'],
                              'float_norm_error': event['float_rotation_norm_relative_error_max']}
                             for episode in result.get('episodes', []) for event in episode['events']]}, indent=2))
raise SystemExit(0 if result['passed'] else 1)
