#!/usr/bin/env python3
"""Archive already completed TMP-only proposals; never runs their commands."""
import gzip
import hashlib
import json
from pathlib import Path
import sys
import tarfile
import time

TMP = Path('/tmp')
PREFIXES = ('mr3_p2a0_v19_conditional', 'mr3_p2a0_v19_six_file',
            'mr3_p2a0_v19_remaining_exit', 'mr3_p2a0_v20_matrix_draft')
ARCHIVE = TMP / 'mr3_p2a0_v19_unselected_proposals_v1.tar.gz'
MANIFEST = TMP / 'mr3_p2a0_v19_unselected_proposals_manifest_v1.json'

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def stat(path):
    item = path.stat()
    return {'device': item.st_dev, 'inode': item.st_ino, 'bytes': item.st_size,
            'mtime_ns': item.st_mtime_ns, 'ctime_ns': item.st_ctime_ns}

def main():
    started = time.monotonic()
    selected = sorted(p for p in TMP.iterdir() if any(p.name.startswith(s) for s in PREFIXES))
    sources = []
    for path in selected:
        if path.is_dir():
            sources.extend(p for p in path.rglob('*') if p.is_file())
        elif path.is_file():
            sources.append(path)
    sources.append(Path(__file__).resolve())
    entries, excluded = [], []
    for path in sorted(set(sources)):
        assert not path.is_symlink(), path
        before = stat(path)
        raw = path.read_bytes()
        assert before == stat(path), path
        entry = {'source': str(path), 'member': path.relative_to(TMP).as_posix(),
                 'raw_sha256': digest(raw), 'raw_bytes': len(raw), 'stat_before': before}
        if raw.startswith(b'\x7fELF') or '__pycache__' in path.parts or path.suffix == '.pyc':
            entry['reason'] = 'compiled CPU executable/cache excluded; source, exact command and result retained'
            excluded.append(entry)
        else:
            entries.append(entry)
    with ARCHIVE.open('xb') as target:
        with gzip.GzipFile(filename='', fileobj=target, mode='wb', compresslevel=6, mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.PAX_FORMAT) as archive:
                for entry in entries:
                    archive.add(entry['source'], arcname=entry['member'], recursive=False)
    expected = {entry['member']: entry for entry in entries}
    checked = []
    with tarfile.open(ARCHIVE, 'r|gz') as archive:
        for member in archive:
            assert member.isfile(), member.name
            raw = archive.extractfile(member).read()
            entry = expected.pop(member.name)
            assert len(raw) == entry['raw_bytes'] and digest(raw) == entry['raw_sha256'], member.name
            checked.append(member.name)
    assert not expected
    for entry in entries + excluded:
        path = Path(entry['source'])
        entry['stat_final'] = stat(path)
        assert entry['stat_before'] == entry['stat_final']
        assert digest(path.read_bytes()) == entry['raw_sha256']
    encoded = ARCHIVE.read_bytes()
    result = {'schema': 'mr3-unselected-proposal-custody-v1',
              'status': {'iters150': 'UNSELECTED', 'four_stage_draft': 'NOT RUN',
                         'all_proposed_production_changes': 'UNAPPLIED',
                         'native_or_cpu_commands_executed_by_archiver': 0},
              'purpose': 'Preserve already executed CPU/proposal cost, original failures and source provenance; no task or matrix credit.',
              'selected_roots': [str(p) for p in selected],
              'archive': {'path': str(ARCHIVE), 'encoding': 'gzip_tar_original_files',
                          'encoded_sha256': digest(encoded), 'encoded_bytes': len(encoded)},
              'files': entries, 'file_count': len(entries),
              'total_raw_file_bytes': sum(e['raw_bytes'] for e in entries),
              'excluded': excluded, 'excluded_count': len(excluded),
              'roundtrip': {'passed': True, 'members': len(checked), 'per_member_size_and_sha256': True},
              'source_stat_and_sha_final_unchanged': True,
              'execution': {'argv': sys.argv, 'wall_seconds': time.monotonic() - started},
              'manifest_self_excluded': True, 'writers': 'STOP'}
    with MANIFEST.open('x') as stream:
        stream.write(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'manifest': str(MANIFEST), 'manifest_sha256': digest(MANIFEST.read_bytes()),
                      'files': len(entries), 'excluded': len(excluded),
                      'raw_bytes': result['total_raw_file_bytes'], 'archive': result['archive'],
                      'wall_seconds': result['execution']['wall_seconds']}))

if __name__ == '__main__':
    main()
