#!/usr/bin/env python3
"""Build unapplied source proposals against exact saved canonical bases."""
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def replace_once(value, before, after):
    if value.count(before) != 1:
        raise ValueError('base splice no longer unique')
    return value.replace(before, after, 1)


def main():
    launch_name = 'gazebo_multirobot_mapping_with_nav2.launch.py'
    old = (HERE / 'base' / launch_name).read_text()
    new = replace_once(old, 'import json\n', 'import hashlib\nimport json\nfrom pathlib import Path\n')
    new = replace_once(new, '\ndef drive_spawn_model(', '\n' +
                       (HERE / 'diagnostic_launch_helpers.py').read_text() + '\n\ndef drive_spawn_model(')
    new = replace_once(new,
        'def drive_spawn_model(model_path, robot_name, audit_path, epoch, tagged_commands=False):',
        'def drive_spawn_model(model_path, robot_name, audit_path, epoch, tagged_commands=False,\n'
        '                      *, physics_diagnostic=None):')
    new = replace_once(new, '    if audit_path:\n        destination = os.path.join(',
        '    if physics_diagnostic is not None:\n'
        '        model = append_physics_observer(model, robot_name, physics_diagnostic)\n'
        '    if audit_path:\n        destination = os.path.join(')
    new = replace_once(new,
        '    adapter_audit_path = LaunchConfiguration("mr3_audit_path").perform(context)\n',
        '    adapter_audit_path = LaunchConfiguration("mr3_audit_path").perform(context)\n'
        '    physics_diagnostic = prepare_physics_diagnostic(\n'
        '        context.environment.get(PHYSICS_DIAGNOSTIC_ENV, ""),\n'
        '        adapter_mode=adapter_mode, stepped_mode=stepped_mode, robot_count=robot_count,\n'
        '        epoch=episode_epoch.perform(context), audit_path=adapter_audit_path, world=world,\n'
        '        seed=gazebo_seed.perform(context), package_prefix=get_package_prefix("multi_robot"))\n'
        '    if physics_diagnostic is not None:\n'
        '        actions.append(LogInfo(msg="MR3_PHYSICS_DIAGNOSTIC_SELECTED " +\n'
        '                               json.dumps(physics_diagnostic, sort_keys=True)))\n')
    new = replace_once(new,
        '        # Humble\'s included gzserver launch appends extra_gazebo_args after the ROS \'--\'.\n',
        '        diagnostic_system_args = []\n'
        '        if physics_diagnostic is not None:\n'
        '            diagnostic_system_args = [\n'
        '                "-s", physics_diagnostic["binding"]["profile_library"]["path"]]\n'
        '            gazebo_environment[PHYSICS_DIAGNOSTIC_ENV] = physics_diagnostic["binding_path"]\n'
        '        # Humble\'s included gzserver launch appends extra_gazebo_args after the ROS \'--\'.\n')
    new = replace_once(new,
        '                 "-s", "libgazebo_ros_force_system.so", "-s", step_plugin,\n',
        '                 "-s", "libgazebo_ros_force_system.so", "-s", step_plugin,\n'
        '                 *diagnostic_system_args,\n')
    new = replace_once(new,
        '            model, robot_name, adapter_audit_path, episode_epoch.perform(context), adapter_mode)\n',
        '            model, robot_name, adapter_audit_path, episode_epoch.perform(context), adapter_mode,\n'
        '            physics_diagnostic=physics_diagnostic)\n')
    (HERE / 'proposed' / launch_name).write_text(new)
    cmake_old = (HERE / 'base/CMakeLists.txt').read_text()
    cmake_extra = '''
# Diagnostic-only opt-in SystemPlugin. No change to original driver/step targets.
set(mr3_profile_source ${CMAKE_CURRENT_SOURCE_DIR}/src/mr3_physics_diagnostic_profile.cpp)
set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS ${mr3_profile_source})
file(SHA256 ${mr3_profile_source} mr3_profile_source_sha)
add_library(mr3_physics_diagnostic_profile SHARED src/mr3_physics_diagnostic_profile.cpp)
target_compile_features(mr3_physics_diagnostic_profile PUBLIC cxx_std_17)
target_include_directories(mr3_physics_diagnostic_profile PRIVATE ${GAZEBO_INCLUDE_DIRS})
target_link_libraries(mr3_physics_diagnostic_profile ${GAZEBO_LIBRARIES}
  nlohmann_json::nlohmann_json ${CMAKE_DL_LIBS})
target_compile_definitions(mr3_physics_diagnostic_profile PRIVATE
  MR3_PHYSICS_DIAGNOSTIC_SOURCE_SHA256="${mr3_profile_source_sha}")
install(TARGETS mr3_physics_diagnostic_profile DESTINATION lib)
'''
    cmake_new = replace_once(cmake_old, '\nament_package()\n', cmake_extra + '\nament_package()\n')
    (HERE / 'proposed/CMakeLists.txt').write_text(cmake_new)
    pieces = []
    base_root = 'ros2_ws/ros2-multi-robot-automap/src/multi_robot/'
    for name, rel in [(launch_name, 'launch/' + launch_name), ('CMakeLists.txt', 'CMakeLists.txt')]:
        before = (HERE / 'base' / name).read_text().splitlines(keepends=True)
        after = (HERE / 'proposed' / name).read_text().splitlines(keepends=True)
        pieces.extend(difflib.unified_diff(before, after, fromfile='a/' + base_root + rel,
                                          tofile='b/' + base_root + rel))
    source = (HERE / 'proposed/mr3_physics_diagnostic_profile.cpp').read_text().splitlines(keepends=True)
    pieces.extend(difflib.unified_diff([], source, fromfile='/dev/null',
                                      tofile='b/' + base_root + 'src/mr3_physics_diagnostic_profile.cpp'))
    (HERE / 'review_only.patch').write_text(''.join(pieces))
    print(json.dumps({name: hashlib.sha256((HERE / 'proposed' / name).read_bytes()).hexdigest()
                      for name in [launch_name, 'CMakeLists.txt', 'mr3_physics_diagnostic_profile.cpp']},
                     sort_keys=True))


if __name__ == '__main__':
    main()
