"""Tiny synthetic arithmetic check only; no native input."""
import importlib.util
import json
from pathlib import Path


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


D = load("postmortem", "/tmp/mr3_p2a0_v18_closed_observer_diagnostic_v1.py")
T = load("fixture", "/tmp/mr3_independent_stop_observer_v1_tests.py")
OUT = Path("/tmp/mr3_p2a0_v18_closed_diagnostic_cpu_v1")
OUT.mkdir(exist_ok=False)
rows = T.rows()
source = OUT / "synthetic.jsonl"
source.write_bytes(b"".join(T.raw(row) for row in rows))
datum = rows[1]
message = {"pose": {"pose": {"position": dict(zip(("x", "y", "z"),
               datum["model"]["world_pose"]["position_xyz"]))}},
           "twist": {"twist": {"linear": {"x": 0.0, "y": .011, "z": 0.0},
                               "angular": {"x": 0.0, "y": 0.0, "z": 0.0}}}}
odom = {1000000: [{"line": 1, "input_sequence": 1, "message": message, "raw": T.raw(message)}]}
instance = D.Diagnostic("tb1", T.EPOCH, 1000000, 3000000, T.native(), odom, OUT, source)
for index, row in enumerate(rows, 1):
    instance.feed(index, T.raw(row), row)
result = instance.result()
assert result["own_odom_same_T_pre_join"]["joined_rows"] == 1
assert result["own_odom_same_T_pre_join"]["unmatched_source_ns"] == []
assert result["extra_residuals"]["own_odom.xy_wz_minus_same_T_pre_float_yaw_projection"]["maximum_abs_xyz"] == [0.0] * 3
assert result["zero_motor_windows"]["count"] == 1
assert result["zero_motor_windows"]["intervals"] == 2
assert result["zero_motor_windows"]["longest_ten"][0]["maximum_model_planar_speed"] == .011
assert max(abs(value) for value in result["post_velocity_pose_integral_residual_xyz"]["canonical_cog"]) < 1e-18
(OUT / "result.json").write_text(json.dumps({"synthetic_check": True, "result": result}, indent=2) + "\n")
print("PASS: exact PRE odom join; zero reference with .011 drift retained; post integration residual.")
