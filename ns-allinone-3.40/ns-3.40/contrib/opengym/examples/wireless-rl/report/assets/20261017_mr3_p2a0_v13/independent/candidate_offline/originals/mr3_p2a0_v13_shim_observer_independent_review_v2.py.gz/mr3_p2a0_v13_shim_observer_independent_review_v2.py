"""Targeted read-only observer review; fake proc fixtures, not native evidence."""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import tempfile
from unittest import mock

ROOT = Path('/home/zhuyulab/ns3-workspace')
INDIE = ROOT / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
                'report/assets/20261017_mr3_p2a0_v13/independent')
SNAPSHOT = Path('/tmp/mr3_p2a0_v13_shim_observer_review_sources_v2')
OUTPUT = Path('/tmp/mr3_p2a0_v13_shim_observer_independent_review_v2.json')
NAMES = [
    'mr3_readonly_v13_drive_shim_process_monitor_v2.py',
    'mr3_readonly_v13_drive_shim_process_monitor_v2_tests.py',
    'mr3_v13_shim_mapping_review_v1.py',
    'mr3_v13_shim_mapping_review_v1_tests.py',
    'mr3_v13_shim_binding_v1.json',
    'mr3_v13_upstream_rotation_shim_1_1_20.cpp',
]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def require(value, message):
    if not value:
        raise AssertionError(message)


def main():
    SNAPSHOT.mkdir(exist_ok=False)
    sources = {}
    for name in NAMES:
        source = INDIE / name
        raw = source.read_bytes()
        (SNAPSHOT / name).write_bytes(raw)
        sources[str(source)] = {'bytes': len(raw), 'sha256': sha(raw)}
    # Fixtures supply fake /proc and saved-record scaffolding only. No author
    # unittest suite is invoked, and no actual /proc scan is performed here.
    fixtures = load('independent_review_monitor_fixture', INDIE / NAMES[1])
    saved = load('independent_review_saved_fixture', INDIE / NAMES[3])
    monitor = fixtures.M
    checks = []

    def check(name, detail):
        checks.append({'name': name, 'passed': True, **detail})

    with tempfile.TemporaryDirectory(prefix='mr3_v13_independent_proc_') as tmp:
        f = fixtures.Fixture(Path(tmp))
        row = f.inspect()
        require(row['complete'], 'positive fake proc fixture rejected')
        for process in f.base['owned_current_processes']:
            f.stat(dict(process['identity'], state='S'))
        sleeping = f.inspect()
        require(sleeping['complete'], 'ordinary R/S scheduling change rejected')
        check('positive_exact_worker_and_R_to_S', {
            'synthetic_only': True, 'worker_actual_argv': row['worker_actual_argv'],
            'three_robot_roles': sorted(row['controllers'])})

        other = f.root / 'worker4/episode018_open_801'
        shutil.copytree(f.ep, other)
        metadata = json.loads((other / 'metadata.json').read_bytes())
        metadata['epoch'] = 'different-epoch'
        (other / 'metadata.json').write_text(json.dumps(metadata))
        supervisor = copy.deepcopy(f.supervisor)
        supervisor['epoch'] = metadata['epoch']
        supervisor['command'][-1] = str(other)
        (other / 'supervisor_metadata.json').write_text(json.dumps(supervisor))
        f.base['episodes'].append({'directory': str(other)})
        rows = monitor.inspect_episodes(f.base, f.binding, f.proc)
        require(rows[0]['complete'] and not rows[1]['complete'],
                'different epoch/directory borrowed the original actual worker')
        require('not this episode' in ' '.join(rows[1]['errors']),
                'clone did not fail on actual argv/episode binding')
        check('previous_cross_episode_borrow_counterexample_now_rejected', {
            'synthetic_only': True, 'cloned_errors': rows[1]['errors']})

    with tempfile.TemporaryDirectory(prefix='mr3_v13_independent_swap_') as tmp:
        f = fixtures.Fixture(Path(tmp))
        original = monitor.stable_file
        replacement = f.root / 'replacement.so'
        replacement.write_bytes(b'new file B after payload/stat A has been read')
        old_inode = f.library.stat().st_ino
        switched = False

        def switch(path):
            nonlocal switched
            result = original(path)
            if Path(path) == f.library and not switched:
                switched = True
                replacement.replace(f.library)
                # Supply the new inode in the live map. Hash/stat A cannot be
                # paired with B, and the stable reread must also reject B.
                f.maps(f.controllers['tb1']['pid'])
            return result

        with mock.patch.object(monitor, 'stable_file', side_effect=switch):
            row = f.inspect()
        require(switched and f.library.stat().st_ino != old_inode and not row['complete'],
                'file replacement escaped same-FD mapping proof')
        check('previous_payload_stat_file_swap_counterexample_now_rejected', {
            'synthetic_only': True,
            'tb1_errors': row['controllers']['tb1']['errors']})

    def saved_case(mutate, expected):
        case = saved.ReviewTests('test_complete_correct_saved_original_and_exact_episode')
        case.setUp()
        try:
            mutate(case)
            result = case.review()
            require(result['passed'] is expected, 'saved-wrapper expected verdict differs')
            return result
        finally:
            case.doCleanups()

    result = saved_case(lambda case: None, True)
    check('saved_wrapper_positive_base_and_episode_proof', {
        'synthetic_only': True, 'episodes': len(result['episodes'])})

    def typed_change(case):
        case.base['original_typed_field'] = False
        case.save_base()
        case.wrapper['original_typed_field'] = 0

    result = saved_case(typed_change, False)
    check('typed_original_base_field_False_to_zero_rejected', {
        'synthetic_only': True, 'errors': result['errors']})

    def borrowed_argv(case):
        row = case.selected()
        row['worker_actual_argv'] = list(row['worker_actual_argv'])
        row['worker_actual_argv'][-1] = '/tmp/different-real-episode'
        row['worker_cmdline_sha256'] = sha(
            ('\0'.join(row['worker_actual_argv']) + '\0').encode())

    result = saved_case(borrowed_argv, False)
    check('saved_actual_worker_relabel_with_self_consistent_SHA_rejected', {
        'synthetic_only': True,
        'episode_rejections': result['episodes'][0]['rejected_captures']})

    def changed_console(case):
        (case.support / 'base.stdout').write_bytes(b'not the recorded original console')

    result = saved_case(changed_console, False)
    check('saved_original_console_raw_binding_rejected', {
        'synthetic_only': True, 'errors': result['errors']})

    reader = load('independent_saved_reader_actual_binding', INDIE / NAMES[2])
    actual_monitor_binding = monitor.check_binding(INDIE / NAMES[4])
    actual_reader_binding = reader.binding_inputs(Path.read_bytes)
    require(all(reader.canonical(actual_monitor_binding[key]) ==
                reader.canonical(actual_reader_binding[key])
                for key in ('path', 'sha256', 'files')),
            'actual installed binding producer/consumer interface mismatch')
    require(monitor.sha(monitor.BASE.read_bytes()) == monitor.BASE_SHA == reader.BASE_SHA,
            'old immutable base source pin differs')
    check('actual_installed_five_artifact_binding_and_immutable_base_source', {
        'native_or_DDS': False, 'roles': sorted(actual_reader_binding['files']),
        'immutable_base_source_sha256': monitor.BASE_SHA,
        'scope': 'disk bytes/header/XML/tag identity only, no source-to-ELF proof'})

    for path, entry in sources.items():
        require(sha(Path(path).read_bytes()) == entry['sha256'],
                'reviewed canonical bytes changed during review')
    result = {
        'schema': 'mr3-v13-shim-observer-independent-review-v2',
        'passed': True, 'targeted_checks': checks,
        'reviewed_sources': sources,
        'source_snapshot': str(SNAPSHOT),
        'previous_counterexamples': {
            'preserved_v1_review': '/tmp/mr3_p2a0_v13_shim_observer_independent_review_v1.json',
            'preserved_v1_review_sha256': sha(Path(
                '/tmp/mr3_p2a0_v13_shim_observer_independent_review_v1.json').read_bytes()),
            'scope': 'Synthetic demonstrated gaps in v1; no claim they occurred natively.'},
        'read_only_static_review': {
            'same_FD_stat_hash': 'same open descriptor before/read/after plus linked path stat; '
                                 'mapped file hash/inode/device rechecked after capture',
            'episode_binding': 'actual worker 4-argument argv and supervisor episode path; '
                               'PID/start, actual ancestry, unique namespace per controller',
            'original_base': 'frozen 7126969 source is delegated unchanged; supplement reader '
                             'requires typed canonical whole-base equality and raw support hashes',
            'no_process_control': 'imports/calls reviewed: disk and /proc reads, subprocess only '
                                  'delegates immutable read-only base; no DDS, ROS or signals',
            'no_new_blocking_interface_mismatch_found': True},
        'limits': [
            'Eight targeted checks reuse author fake proc/saved fixture scaffolding; '
            'author 23/22 suites were not rerun and are separate evidence.',
            'No native /proc snapshot or formal closure command was executed.',
            'Loaded library proof is capture-time namespace/ancestry/maps inode/device/disk '
            'SHA custody, not process memory equivalence or a physical/task/PPO result.',
            'R/S process state is deliberately outside immutable PID/start identity.',
            'Saved supplement must accompany original closure gates; it cannot replace them.'],
        'source_bytes_stable_before_after': True,
    }
    with OUTPUT.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'passed': True, 'targeted_checks': len(checks),
                      'output': str(OUTPUT)}))


if __name__ == '__main__':
    main()
