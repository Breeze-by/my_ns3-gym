"""Review completed descriptive small JSONs only; never reopen raw captures."""
import hashlib
import json
from pathlib import Path
import sys
import time

DESCRIPTION = Path('/tmp/mr3_p2a0_v19_paired_zero_motor_description_v1.json')
EXECUTION = Path('/tmp/mr3_p2a0_v19_paired_zero_motor_analysis_execution_v1.json')
OWNERSHIP = Path('/tmp/mr3_p2a0_v19_goal_ownership_small_review_v1.json')
OUTPUT = Path('/tmp/mr3_p2a0_v19_paired_result_review_v1.json')
EXECUTION_SHA = '4b38031bb543f385e7a9ce1615d6fb49d0b5d2578b27fd1763cc176675ebdbab'
ENTITIES = ('model', 'canonical_origin', 'canonical_cog', 'base_origin', 'base_cog')
TICK = 1_000_000
LATE = 780_000_000


def main():
    started = time.monotonic()
    inputs = {}

    def load(path):
        raw = path.read_bytes()
        inputs[str(path)] = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
        return json.loads(raw)

    description, execution, ownership = [load(path) for path in
                                        (DESCRIPTION, EXECUTION, OWNERSHIP)]
    assert inputs[str(EXECUTION)]['sha256'] == EXECUTION_SHA
    assert execution['description_sha256'] == inputs[str(DESCRIPTION)]['sha256']
    assert execution['analysis_completed'] is True and execution['exit_code'] == 0
    assert execution['exception'] is None and execution['task_or_matrix_pass_claim'] is False
    assert execution['small_inputs_stable'] is True
    assert execution['inputs_before'] == execution['inputs_after']
    assert execution['wrapper_before'] == execution['wrapper_after']
    assert description['analysis_completed'] is True
    assert description['preparation_matrix_credit'] is False
    assert description['execution']['analysis_source_sha256'] == (
        '025a4aa566f352b9c33fecaaf5c2299b919c98a6cd2061f5b8a38c473aed43e6')
    assert description['selection']['continuous_sampled_zero_elapsed_ns'] == LATE
    summaries = []
    for stage in description['stages']:
        native = next(row for row in ownership['stages'] if row['stage'] == stage['stage'])
        assert native['epoch'] == stage['epoch']
        interval = stage['interval']
        start, end = interval['start_ns'], interval['end_ns']
        assert end - start == 32_000_000_000 and interval['returned_step_calls'] == 32
        robots = []
        for robot in stage['robots']:
            name = robot['robot']
            n = robot['late_zero_pairs']
            assert robot['task_pairs'] == (end - start) // TICK + 1 == 32001
            assert sum(row['pair_count'] for row in robot['all_zero_streaks']) == (
                robot['both_motor_zero_pairs'])
            assert sum(row['late_pair_count'] for row in robot['all_zero_streaks']) == n
            expected_late = []
            previous_end = None
            for row in robot['all_zero_streaks']:
                assert start <= row['start_ns'] <= row['end_ns'] <= end
                assert row['pair_count'] == (row['end_ns'] - row['start_ns']) // TICK + 1
                if previous_end is not None:
                    assert row['start_ns'] >= previous_end + 2 * TICK
                previous_end = row['end_ns']
                assert row['late_pair_count'] == max(0, row['pair_count'] - LATE // TICK)
                if row['late_pair_count']:
                    assert row['first_late_ns'] == row['start_ns'] + LATE
                    assert row['last_late_ns'] == row['end_ns']
                    expected_late.append(row)
                else:
                    assert row['first_late_ns'] is None and row['last_late_ns'] is None
            assert expected_late == robot['all_late_zero_streaks']
            bound = stage['raw_files'][name]['expected']
            assert robot['input']['sha256'] == bound['sha256']
            assert robot['input']['bytes'] == bound['bytes']
            assert robot['input']['whole_file_single_pass'] is True
            stats = robot['late_zero_vectors']
            entity_rows = {}
            for entity in ENTITIES:
                phases = {}
                for phase in ('pre', 'post', 'both_phases'):
                    vector = stats[entity + '.' + phase + '_getter_velocity']
                    expected = n * (2 if phase == 'both_phases' else 1)
                    assert vector['planar_norm']['count'] == expected
                    assert all(axis['count'] == expected for axis in vector['xyz'])
                    phases[phase] = vector['planar_norm']
                for suffix in ('pre_to_post_displacement_m', 'pre_to_post_difference_velocity',
                               'difference_minus_pre_getter', 'difference_minus_post_getter'):
                    assert stats[entity + '.' + suffix]['planar_norm']['count'] == n
                entity_rows[entity] = {
                    'getter_planar_mps_by_phase': phases,
                    'getter_combined_xyz_mean': [row['mean'] for row in
                                                stats[entity + '.both_phases_getter_velocity']['xyz']],
                    'pre_post_pose_difference_velocity_xyz_mean': [row['mean'] for row in
                                                                  stats[entity + '.pre_to_post_difference_velocity']['xyz']],
                    'difference_minus_post_getter_xyz_mean': [row['mean'] for row in
                                                            stats[entity + '.difference_minus_post_getter']['xyz']]}
            for phase in ('pre', 'post', 'both_phases'):
                values = [stats[entity + '.' + phase + '_getter_velocity'] for entity in
                          ('model', 'canonical_origin', 'canonical_cog')]
                assert values[0] == values[1] == values[2]
            if stage['stage'] == 'iters150':
                assert robot['both_motor_zero_pairs'] == 32001
                assert n == 31221 and len(robot['all_zero_streaks']) == 1
                assert robot['all_zero_streaks'][0]['start_ns'] == start
                assert robot['all_zero_streaks'][0]['carryin_before_task_release_not_counted'] is True
            robots.append({'robot': name, 'task_pairs': robot['task_pairs'],
                           'both_motor_zero_pairs': robot['both_motor_zero_pairs'],
                           'late_zero_pairs': n, 'all_streaks': robot['all_zero_streaks'],
                           'five_entities': entity_rows,
                           'actual_wheel_velocity_radps': robot['late_zero_actual_wheel_velocity_radps'],
                           'raw_input_binding_from_completed_description': robot['input']})
        summaries.append({'stage': stage['stage'], 'epoch': stage['epoch'], 'actual_interval': interval,
                          'actual_goal_component_requests': native['new_goal_component_requests'],
                          'observed_nav_goal_uuids': native['event']['nav_goal_count'], 'robots': robots})
    for path, proof in inputs.items():
        raw = Path(path).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == proof['sha256'] and len(raw) == proof['bytes']
    result = {'schema': 'mr3-v19-completed-paired-description-review-v1',
              'review_completed': True, 'integrity_findings': [], 'raw_reread': False,
              'inputs': inputs, 'inputs_before_after_stable': True, 'stages': summaries,
              'conclusion': 'Baseline6GOAL versus contrast0GOAL is unmatched motion excitation. '
                            'Contrast all32001 task pairs per robot had sampled pre/post motor '
                            'targets0; lower late-zero readings cannot establish braking repair.',
              'measurement_observation': 'Both stages retain negative model getter vz means '
                                         'about-.087 to-.090m/s while sampled pre/post pose vz '
                                         'means are near0. This getter/pose consistency difference '
                                         'is preserved, without unique physical or solver cause.',
              'scope': ['Five measured locations are not five independent robot trials. '
                        'Model/canonical-origin/canonical-CoG getter statistics coincide here; '
                        'base-origin and base-CoG are distinct points, all retained.',
                        'Both phases are separately retained and equal-weight combined; '
                        'raw source hashes are checked against completed execution bindings, '
                        'not independently recomputed by rereading the raw captures.',
                        'All late-zero streaks with inclusive780ms boundary and task-release '
                        'carryin truncation are included; no longest-window selection.',
                        'No original30Hz .01/three-source/.78/.144 verdict, coverage, matrix, '
                        'task95% or policy acceptance is changed; iters150 remains conditional.'],
              'execution': {'argv': sys.argv, 'cwd': str(Path.cwd()),
                            'wall_seconds': time.monotonic() - started,
                            'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}}
    with OUTPUT.open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'review': str(OUTPUT), 'sha256': hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),
                      'raw_reread': False, 'integrity_findings': []}))


if __name__ == '__main__':
    main()
