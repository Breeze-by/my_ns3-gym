"""Targeted read-only review of corrected external v4 stimulus source."""
import ast
import copy
import hashlib
import itertools
import json
import math
from pathlib import Path

ROOT = Path('/home/zhuyulab/ns3-workspace')
WIRELESS = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
SNAPSHOT = Path('/tmp/mr3_p2a0_v15_fixture_independent_review_sources_v2')
PROPOSAL = Path('/tmp/mr3_p2a0_v15_stop_fixture_v4_proposal')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    sources = json.loads((SNAPSHOT / 'sources.json').read_text())
    before = {str(p): sha(p.read_bytes()) for p in SNAPSHOT.glob('*.py')}
    tree = ast.parse((SNAPSHOT / 'benchmark.py').read_bytes())
    names = {'_probe_goal_order', 'probe_action', 'probe_action_v3', 'probe_action_v4',
             'record_probe_v4_submission'}
    namespace = {'math': math}
    exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n, ast.FunctionDef)
                                 and n.name in names], type_ignores=[]),
                 str(SNAPSHOT / 'benchmark.py'), 'exec'), namespace)
    scaffold = {'itertools': itertools, 'NAMES': ('tb1', 'tb2', 'tb3')}
    fixture_tree = ast.parse((SNAPSHOT / 'test_stimulus_v4.py').read_bytes())
    exec(compile(ast.Module(body=[n for n in fixture_tree.body if isinstance(n, ast.FunctionDef)
                                 and n.name in ('snapshot', 'result')], type_ignores=[]),
                 str(SNAPSHOT / 'test_stimulus_v4.py'), 'exec'), scaffold)
    choose, submit = namespace['probe_action_v4'], namespace['record_probe_v4_submission']
    snapshot, result = scaffold['snapshot'], scaffold['result']
    findings = []

    def mark(name, **details):
        findings.append({'check': name, 'passed': True, **details})

    for flag in (0, 1, None, 'true'):
        diagnostics = {}
        snap = snapshot(10.)
        action = choose(snap, diagnostics)
        try:
            submit(diagnostics, result(snap, action, action_submitted=flag))
        except ValueError as error:
            assert str(error) == 'explicit action_submitted must be bool'
        else:
            raise AssertionError('explicit non-bool submission accepted')
        assert not diagnostics['v4_stimulus']['rounds']['initial']['waits']
    mark('previous non-bool alias counterexample rejected', tested=[0, 1, None, 'true'])

    for explicit in (False, True):
        diagnostics = {}
        snap = snapshot(10.)
        action = choose(snap, diagnostics)
        assert action == 999 and not diagnostics['v4_stimulus']['rounds']['initial']['waits']
        receipt = result(snap, action)
        if explicit:
            receipt['action_submitted'] = True
        submit(diagnostics, receipt)
        assert len(diagnostics['v4_stimulus']['rounds']['initial']['waits']) == 3
        assert diagnostics['v4_stimulus']['pending_submission'] is None
    mark('normal omitted flag and explicit true only latch after exact actual step return')

    diagnostics = {}
    snap = snapshot(10.)
    choose(snap, diagnostics)
    submit(diagnostics, {'action_submitted': False})
    assert not diagnostics['v4_stimulus']['rounds']['initial']['waits']
    assert diagnostics['v4_stimulus']['pending_submission'] is None
    mark('terminal reused not-submitted result gives no WAIT latch')

    for key, replacement in (('epoch', 'other'), ('observation_digest', False),
                              ('observation_sequence', False), ('action', 998),
                              ('command_id', False), ('command_id', 0)):
        diagnostics = {}
        snap = snapshot(10.)
        action = choose(snap, diagnostics)
        receipt = result(snap, action)
        receipt['command'][key] = replacement
        try:
            submit(diagnostics, receipt)
        except ValueError:
            pass
        else:
            raise AssertionError('unbound or mistyped submission accepted')
        assert not diagnostics['v4_stimulus']['rounds']['initial']['waits']
    mark('matching typed command is required for committed WAIT', subcases=6)

    diagnostics = {}
    for elapsed in (10., 11., 12.):
        snap = snapshot(elapsed, speed=.02, path=.01, waiting=False)
        assert choose(snap, diagnostics) == 888
        submit(diagnostics, result(snap, 888))
    second = snapshot(13., active=False)
    for robot in second['robots']:
        robot['navigation']['accepted_goal_count'] = 1
    assert choose(second, diagnostics) == 888
    assert not diagnostics['v4_stimulus']['rounds']['initial']['waits']
    mark('previous missing first WAIT counterexample holds KEEP', second_action=888,
         accepted_goal_count_preserved=1)

    diagnostics = {}
    first = snapshot(11., speed=.02)
    submit(diagnostics, result(first, choose(first, diagnostics)))
    early = snapshot(13., active=False)
    assert choose(early, diagnostics) == 888
    submit(diagnostics, result(early, 888))
    not_rest = snapshot(14., active=False, speed=.02)
    assert choose(not_rest, diagnostics) == 888
    submit(diagnostics, result(not_rest, 888))
    ready = snapshot(14., active=False)
    ready['sequence'] += 1
    ready['digest'] += '-new-snapshot'
    action = choose(ready, diagnostics)
    assert all(component < 8 for component in (action // 100, action // 10 % 10, action % 10))
    assert ready['joint_action_mask'][action] is True
    mark('second goal needs submitted WAIT duration and received rest',
         before_three_seconds_action=888, not_rest_action=888, ready_action=action,
         scope='received linear proxy; no physical stopping proof')

    diagnostics = {}
    first = snapshot(10., active=False)
    submit(diagnostics, result(first, choose(first, diagnostics)))
    second = snapshot(13., active=False)
    submit(diagnostics, result(second, choose(second, diagnostics)))
    masked = snapshot(15., speed=.19, path=.5, waiting=False)
    assert choose(masked, diagnostics) == 888
    assert not diagnostics['v4_stimulus']['rounds']['second']['waits']
    submit(diagnostics, result(masked, 888))
    assert not diagnostics['v4_stimulus']['rounds']['second']['waits']
    moving = snapshot(19., speed=.19, path=.5)
    assert choose(moving, diagnostics) == 999
    assert not diagnostics['v4_stimulus']['rounds']['second']['waits']
    submit(diagnostics, result(moving, 999))
    held = snapshot(20., active=False)
    assert choose(held, diagnostics) == 999
    mark('five second commitment mask and post-submission WAIT hold are respected',
         masked_action=888, legal_received_motion_action=999, held_action=999)

    diagnostics = {}
    snap = snapshot(10.)
    choose(snap, diagnostics)
    before_waits = copy.deepcopy(diagnostics['v4_stimulus']['rounds']['initial']['waits'])
    try:
        choose(snapshot(11.), diagnostics)
    except ValueError as error:
        assert 'unresolved' in str(error)
    else:
        raise AssertionError('pending request overwritten')
    assert diagnostics['v4_stimulus']['rounds']['initial']['waits'] == before_waits == {}
    mark('unreturned or raised step cannot advance committed WAIT state')

    diagnostics = {}
    impossible = snapshot(10.)
    impossible['joint_action_mask'] = [False] * 1000
    impossible['joint_action_mask'][888] = True
    try:
        choose(impossible, diagnostics)
    except ValueError as error:
        assert 'never override a mask' in str(error)
    else:
        raise AssertionError('joint mask overridden')
    mark('joint contradiction fails without selecting fallback')

    old_tree = ast.parse((WIRELESS / 'mr3_learning/benchmark.py').read_bytes())
    old = {n.name: n for n in old_tree.body if isinstance(n, ast.FunctionDef)}
    current = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
    preserved = ('_probe_goal_order', 'probe_action', 'probe_action_v3',
                 '_new_preparation_abort', '_preparation_failure', '_abort_requested')
    for name in preserved:
        assert ast.dump(old[name]) == ast.dump(current[name])
    step = [n for n in ast.walk(tree) if isinstance(n, ast.Assign)
            and isinstance(n.value, ast.Call) and isinstance(n.value.func, ast.Attribute)
            and n.value.func.attr == 'step' and isinstance(n.value.func.value, ast.Name)
            and n.value.func.value.id == 'environment' and n.value.args
            and isinstance(n.value.args[0], ast.Name) and n.value.args[0].id == 'action']
    record = [n for n in ast.walk(tree) if isinstance(n, ast.Call)
              and isinstance(n.func, ast.Name) and n.func.id == 'record_probe_v4_submission']
    assert len(step) == len(record) == 1 and step[0].lineno < record[0].lineno
    selector = ast.unparse(current['probe_action_v4'])
    assert not any(word in selector for word in
                   ('ground_truth', 'own_odom', 'raw_guard', 'open(', 'read_text'))
    mark('old v2/v3 and abort helper AST preserved; actual step precedes recorder',
         preserved=list(preserved), step_line=step[0].lineno, record_line=record[0].lineno)

    after = {str(p): sha(p.read_bytes()) for p in SNAPSHOT.glob('*.py')}
    assert before == after
    for path, binding in sources.items():
        assert sha(Path(path).read_bytes()) == binding['sha256']
    output = Path('/tmp/mr3_p2a0_v15_fixture_independent_review_v2.json')
    report = {'schema': 'mr3-v15-fixture-independent-review-v2', 'passed': True,
              'source_files': sources, 'checks': findings, 'source_before': before,
              'source_after': after, 'proposal_and_snapshot_stable': True,
              'corrected_initial_review': {
                  'path': '/tmp/mr3_p2a0_v15_fixture_independent_review_v1.json',
                  'sha256': sha(Path('/tmp/mr3_p2a0_v15_fixture_independent_review_v1.json').read_bytes()),
                  'both_initial_gaps_now_rejected_or_held': True},
              'scope': 'Independent targeted AST-extracted same-function synthetic checks and '
                       'read-only integration review. No author suite repeated, no ROS/native '
                       'or physical/task acceptance credit. Selector consumes received snapshot '
                       'and diagnostics only. Mask controls five second commitment; no rawguard '
                       'or truth and no production policy fallback. Three second WAIT/rest '
                       'selector condition is a received linear proxy; immutable real cancel, '
                       'full-body, braking, participation and task audits remain necessary.'}
    with output.open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'passed': True, 'checks': len(findings), 'output': str(output),
                      'sha256': sha(output.read_bytes())}))


if __name__ == '__main__':
    main()
