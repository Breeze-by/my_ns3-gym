#!/usr/bin/python3
"""Final source/lifecycle review only. No C++ CPU/build/native execution."""
import hashlib
import json
from pathlib import Path
import time

D = Path('/tmp/mr3_p2a0_v22_corrector_source_independent_review_v2')
P = Path('/tmp/mr3_p2a0_v22_ray_box_corrector_proposal_v1')
S = Path('/tmp/mr3_p2a0_v18_driver_diagnostic_proposal_v5')
inputs = {}
raws = {}
sha = lambda x: hashlib.sha256(x).hexdigest()


def read(path, expected=None):
    path = Path(path)
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    ident = lambda x: [x.st_dev, x.st_ino, x.st_size, x.st_mtime_ns, x.st_ctime_ns]
    assert ident(before) == ident(after)
    if expected:
        assert sha(raw) == expected
    inputs[str(path)] = {'sha256': sha(raw), 'bytes': len(raw), 'stat': ident(after)}
    raws[str(path)] = raw
    return raw


start = time.monotonic()
for name, expected in {
    'mr3_ray_box_corrector.cpp': 'b9926b569d39dfe846483b11c6d1748f48aa9a48c561fbf8859a9dc59c7a51ca',
    'mr3_ray_box_collision.cpp': 'd556dda57250da3680a7d5a9862416f6196cab9763e495ee75269307b87715cb',
    'mr3_ray_box_collision.hpp': 'c619442d038e4bc6ea0695ada34d7074ee83d775b2137222ab9fb6bf8193879b'
}.items():
    read(P / name, expected)
for path in [P / 'primary/Server_11.10.2.cc', P / 'primary/PhysicsIface_11.10.2.cc',
             P / 'primary/gazebo_11.10.2.cc', S / 'World_11.10.2.cc',
             S / 'ODEPhysics_11.10.2.cc',
             Path('/tmp/mr3_p2a0_v21_ray_cache_lock_review_v1/SensorManager_11.10.2.cc'),
             Path('/usr/include/gazebo-11/gazebo/common/Plugin.hh'),
             P / 'probe05.stdout.json', P / 'probe05_execution.json',
             P / 'plugin_build03_execution.json',
             Path('/tmp/mr3_p2a0_v22_ray_box_source_api_review_v1/review_v1.json')]:
    read(path)
probe = json.loads(raws[str(P / 'probe05.stdout.json')])
assert probe['passed'] is True and len(probe['corrected_results']) == 36
assert all(x['agrees_with_reference_including_depth_normal_ids'] is True for x in probe['corrected_results'])
assert probe['deterministic_cases'] == 512 and probe['deterministic_failures'] == 0
assert probe['invalid_primitive_rejections'] == 3
assert probe['broadphase_original']['contacts'] == 1
assert probe['broadphase_corrected']['contacts'] == 0
plugin = raws[str(P / 'mr3_ray_box_corrector.cpp')].decode()
assert plugin.index('state->world = name;') < plugin.index('installedRuntime.compare_exchange_strong')
assert 'compare_exchange_strong(expected, 3, std::memory_order_acq_rel)' in plugin
findings = [
    {'area': 'Finite slab/contact math', 'result': 'No blocking defect found in finite bounded native geometry domain.',
     'evidence': 'ReadInput uses original binary64 translation and box-frame rotation through public ODE getters. Solve mirrors direction, constrains every exactly nonzero axis with long-double divisions, preserves original face tie ordering, entering/inside-exit choice and opposite-travel normal sign; finite alpha stays within native ray length. WriteContact preserves ray-first g1/g2/side and kernel owns reversed pair correction. No name/self filter or other collider override.'},
    {'area': 'Source-only mathematical boundary',
     'result': 'The named/rotated CPU evidence was reviewed, not reexecuted or generalized into a physical theorem.',
     'evidence': 'Actual normalized primitive cases include tiny real entry with correct first depth/normal, finite endpoint/grazing, subnormal direction, reverse pair and transformed box cases. All36 named results agree with the probe reference,512 deterministic rotated classifications have0 failures,3 invalid primitives reject. Full preservation of arbitrary ill-conditioned unbounded user geometry is not inferred from these finite tests.'},
    {'area': 'Startup ordering', 'result': 'Source lifecycle supports exactly one initial MR3 world installation before sensors run.',
     'evidence': 'PhysicsIface.create_world50-54 inserts the world before Load. World.Load337-347 constructs/loads ODE (ODEPhysics ctor141 calls dInitODE2), then LoadEntities400 and worldCreated414. Callback requires ODE/T0/iteration0/no existing model sensors, sets world before publishing installedRuntime and registers exactly ray/box once. Server.Run651/654 performs run_once and starts sensor threads only later. A second world/repeated install throws instead of writing a live table.'},
    {'area': 'Callback and atomic one-shot', 'result': 'No callback JSON/file I/O, recast, uncontrolled exception escape or mutable snapshot race found.',
     'evidence': 'InstalledCollider is noexcept; successful work uses public primitive getters, fixed-array math, relaxed counters and two fixed Packet copies. A writer wins0->1, stores packet then release2; Drain must win acquire/release2->3 before reading and the packet is never overwritten. Invalid input exceptions may allocate but are contained, counted and converted to fatal boundary error rather than successful geometric credit. No old dCollide recursive/shadow call runs.'},
    {'area': 'Normal shutdown/state/code lifetime', 'result': 'Normal actual Gazebo shutdown source closes the callback threads before plugin destruction.',
     'evidence': 'gazebo.shutdown stops/joins physics worlds, then sensors::stop joins sensor containers before g_plugins.clear. Corrector plugin disconnects hooks/drains/snapshots while processRuntime still owns state; Runtime persists until process-global destruction and appends final summary. Plugin.hh disables dlclose, so global dispatch does not point into an unloaded module. This reasoning is bounded to orderly single-process shutdown, not arbitrary asynchronous process termination.'},
    {'area': 'Ledger/error semantics', 'result': 'No synthetic normal_close assertion is added.',
     'evidence': 'Actual configuration carries epoch/PID/source3 SHA and loaded corrector/ODE real paths; installed row reports T0/iter0. Counters and optional first primitives are written outside collision callback. Final summary and old independent strict closure must both be checked; silent destructor I/O failure would be detected as absent/partial expected rows, not accepted by mere file existence. First outside-nearparallel branch is descriptive and not a legacy false-hit claim or mandatory occurrence.'},
]
for path, raw in raws.items():
    assert Path(path).read_bytes() == raw
result = {'schema': 'mr3-v22-corrector-independent-source-review-v2', 'passed': True,
          'verdict': 'No remaining source-level blocker identified for the declared single MR3 world/finite scene path.',
          'scope': 'Read-only source/API/lifecycle review; no duplicate author CPU, C++ build, ROS/DDS/native or formal execution.',
          'findings': findings, 'source3_expected': {Path(k).name: v['sha256'] for k, v in inputs.items()
              if Path(k).name in ('mr3_ray_box_corrector.cpp', 'mr3_ray_box_collision.cpp', 'mr3_ray_box_collision.hpp')},
          'reviewed_not_rerun': {'named_bidirectional_cases': 36, 'deterministic_rotated_cases': 512,
                                 'invalid_primitive_rejections': 3, 'broadphase_old_contacts': 1,
                                 'broadphase_corrected_contacts': 0},
          'future_required_actual_evidence': ['Canonical rebuilt source3/ELF identity; SDK03 ELF alone is not the native library.',
              'Per actual epoch/worker-owned gzserver PID/start maps for new corrector and original ODE.',
              'Actual installed T0/iter0 ledger, callbacks>0/errors0/final summary plus independent normal strict closure.',
              'Fresh same-freeze original four-stage gates; this review cannot grant physical repair/PPO/95% or production solver150 choice.'],
          'inputs': inputs, 'inputs_stable': True,
          'source_sha256': sha(Path(__file__).read_bytes()), 'wall_seconds': time.monotonic() - start,
          'writer_state': 'STOP; original source/API v1 unchanged.'}
out = D / 'review_v2.json'
with out.open('x') as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps({'passed': True, 'output': str(out), 'sha256': sha(out.read_bytes()), 'inputs': len(inputs)}))
