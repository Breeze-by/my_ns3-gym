"""Run finite fake-process orchestration fixtures against /tmp versioned drafts."""
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
import unittest
from unittest.mock import patch

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A13 = W / 'report/assets/20261017_mr3_p2a0_v13'
A14 = W / 'report/assets/20261017_mr3_p2a0_v14'
DRAFT = Path('/tmp/mr3_p2a0_v14_coord_draft_v1')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    original_bytes = Path.read_bytes
    original_text = Path.read_text

    def selected(path):
        try:
            return DRAFT / path.relative_to(A14)
        except ValueError:
            return path

    def draft_bytes(path):
        return original_bytes(selected(path))

    def draft_text(path, *args, **kwargs):
        return original_text(selected(path), *args, **kwargs)

    names = ['mr3_p2a0_v14_plan_launcher_tests_v1.py', 'mr3_p2a0_v14_audit_stage_tests_v1.py',
             'mr3_v14_nested_closure_read_tests_v1.py', 'mr3_v14_shim_path_adapter_tests_v1.py']
    source_bindings = {str(p): sha(p.read_bytes()) for p in DRAFT.rglob('*') if p.is_file()}
    began = time.monotonic()
    suite = unittest.TestSuite()
    with patch.object(Path, 'read_bytes', draft_bytes), patch.object(Path, 'read_text', draft_text):
        for index, name in enumerate(names):
            path = DRAFT / 'independent' / name
            spec = importlib.util.spec_from_file_location('v14_fixture_' + str(index), path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
        result = unittest.TextTestRunner(verbosity=2).run(suite)
    wall = time.monotonic() - began
    stable = all(sha(Path(p).read_bytes()) == expected for p, expected in source_bindings.items())
    report = {'schema': 'mr3-v14-coordinator-draft-checks-v1', 'passed': result.wasSuccessful() and stable,
              'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
              'wall_sec': wall, 'source_bindings': source_bindings, 'sources_stable': stable,
              'argv': [sys.executable, str(Path(__file__))], 'cwd': os.getcwd(),
              'scope': '30 finite fake-process/stdlib fixtures. Only Path.read_bytes/read_text '
                       'mapping canonical not-yet-created A14 inputs to /tmp drafts is patched; '
                       'no Git writes, actual ROS/service/native subprocess or control signal.',
              'new_native': 0, 'ready': False}
    output = Path('/tmp/mr3_p2a0_v14_coord_draft_checks_v1.json')
    output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ('passed', 'tests', 'failures', 'errors', 'wall_sec')}))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
