import json,os
from pathlib import Path
p=Path(__file__).parent/'cpu_v3/spec_v3.json'
v=json.loads(p.read_bytes())
os.chdir(v['cwd'])
os.environ['PYTHONDONTWRITEBYTECODE']='1'
os.execv(v['actual_argv'][0],v['actual_argv'])
