#!/usr/bin/python3
"""Summarize completed original terminal receipts and two small transitions only."""
import argparse
import hashlib
import json
from pathlib import Path

FREEZE = 'eee6b2f90f697b28a1c20a2af5d1a6d2f044465e'
AGG_SHA = 'a2833418f21b7bc6fbe5b0323058c9bf2da7756bd5e7cb95a23f0bca7be46ae1'
ROOT = Path('/home/zhuyulab/ns3-workspace')
RUN = ROOT / 'ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/mr3_p2a0_20261017_v17_terminal'
PREFIX = '/tmp/mr3_p2a0_v17_terminal_'

def digest(value):
    return hashlib.sha256(value).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--aggregate', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    output = Path(args.output)
    assert not output.exists(), 'Refuse to replace diagnostic output'
    originals = {}

    def load(path, expected_sha=None, jsonl=False):
        path = Path(path)
        raw = path.read_bytes()
        assert len(raw) <= 2 * 1024 * 1024, 'Small-receipt diagnostic size limit'
        sha = digest(raw)
        assert expected_sha is None or sha == expected_sha, str(path)
        originals[str(path)] = {'bytes': len(raw), 'sha256': sha}
        return [json.loads(line) for line in raw.splitlines() if line] if jsonl else json.loads(raw)

    aggregate = load(args.aggregate, AGG_SHA)
    assert aggregate['schema'] == 'mr3-p2a0-audit-execution-v17'
    assert aggregate['freeze'] == FREEZE and aggregate['stage'] == 'terminal'
    assert aggregate['all_submitted_jobs_finished'] is True
    assert aggregate['passed'] is True and aggregate['runner_errors'] == []
    commands = aggregate['commands']
    assert all(c['passed'] is True and type(c['returncode']) is int and c['returncode'] == 0 for c in commands)
    receipt_shas = {x['path']: x['sha256'] for x in aggregate['receipts']}
    assert all(x['passed'] is True for x in aggregate['receipts'])

    def leaf(label):
        path = PREFIX + label + '.json'
        result = load(path, receipt_shas[path])
        assert result['passed'] is True and result['freeze'] == FREEZE
        assert result.get('errors', []) == []
        return result

    full = leaf('full_audit')
    closure = leaf('closure_binary_review_v1')
    control = leaf('control_review_v1')
    launch = load(PREFIX + 'launch.json')
    assert launch['freeze'] == FREEZE and launch['stage'] == 'terminal'
    assert launch['passed'] is True and launch['returncode'] == 0
    native = full['native']
    assert native['passed'] is True and native['errors'] == []
    assert native['workers'] == 1 and native['steps_per_episode'] == 4
    assert native['terminal_probe'] is True and native['complete_episode_count'] == 2
    assert all(len(x['episodes']) == 2 for x in (full, closure, control))
    assert len(native['episodes']) == 2
    episodes = []
    for number in (1, 2):
        directory = RUN / 'worker0' / ('episode%03d_open_101' % number)
        n = native['episodes'][number - 1]
        e = full['episodes'][number - 1]
        c = closure['episodes'][number - 1]
        p = control['episodes'][number - 1]
        assert n['directory'] == e['directory'] == c['directory'] == str(directory)
        assert p['episode'] == str(directory)
        assert n['epoch'] == c['epoch'] == p['epoch']
        assert n['passed'] is True and c['passed'] is True and p['passed'] is True
        rows = load(directory / 'transitions.jsonl', n['evidence_sha256']['transitions.jsonl'], jsonl=True)
        assert len(rows) == 5 and rows[0]['kind'] == 'reset'
        steps = rows[1:]
        assert all(x['kind'] == 'step' and x['info']['epoch'] == n['epoch'] for x in steps)
        assert all(x['terminated'] is False and x['truncated'] is False and x['info']['dt'] == 1.0 for x in steps[:3])
        last = steps[-1]
        info = last['info']
        rd = info['reward_diagnostics']
        assert last['terminated'] is True and last['truncated'] is False
        assert info['reason'] == 'navigation_failure'
        assert n['terminal_probe_proof']['reason'] == 'P1C_DIAGNOSTIC_FAILURE'
        phase = e['evaluator_phase']
        assert phase['passed'] is True
        transition = n['transitions']
        assert transition['transition_count'] == 4 and transition['complete'] is True
        assert e['scalar']['passed'] is True and e['scalar']['errors'] == []
        if number == 1:
            assert info['command'] is not None
            assert info['dt'] == info['physical_dt'] == 0.02
            assert transition['sampled_physical_time_sec'] == 3.02
            assert transition['submitted_action_count'] == 4
            assert transition['final_action_submitted'] is True
            assert transition['final_terminal_reused'] is False
            assert transition['zero_duration_terminal_count'] == 0
            assert phase['policy_quanta'] == 151 and phase['terminal_ack'] is not None
            branch = 'submitted_command_short_terminal_quantum'
        else:
            assert info['command'] is None and info['action_submitted'] is False
            assert info['terminal_observation_reused'] is True and info['bootstrap'] == 0
            assert info['dt'] == info['physical_dt'] == 0.0
            assert transition['sampled_physical_time_sec'] == 3.0
            assert transition['submitted_action_count'] == 3
            assert transition['final_action_submitted'] is False
            assert transition['final_terminal_reused'] is True
            assert transition['zero_duration_terminal_count'] == 1
            assert phase['policy_quanta'] == 150 and phase['terminal_ack'] is None
            branch = 'terminal_known_before_dispatch_no_command_no_physics'
        assert n['processes']['no_live_or_zombie_leftovers'] is True
        assert n['processes']['forced_cleanup'] is False
        assert n['closure']['navigation_closed'] is True
        assert n['closure']['safety_failures'] == []
        assert c['native_started'] == c['native_clean_exits'] == 39
        supervisor = c['supervisor']
        assert supervisor['worker_returncode'] == 0 and supervisor['forced_shutdown'] is False
        assert supervisor['failed_sample'] is False
        assert supervisor['remaining_owned_processes'] == supervisor['remaining_owned_zombies'] == []
        assert n['contacts']['passed'] is True and n['contacts']['raw_stream_count'] == 18
        assert n['contacts']['zero_contact'] is True
        episodes.append({
            'directory': str(directory), 'epoch': n['epoch'], 'original_contract_passed': True,
            'terminal_branch': branch, 'api_step_returns': len(steps),
            'sampled_physical_time_sec': transition['sampled_physical_time_sec'],
            'submitted_action_count': transition['submitted_action_count'],
            'final_dt': info['dt'], 'final_physical_dt': info['physical_dt'],
            'final_command': info['command'], 'final_action_submitted': transition['final_action_submitted'],
            'final_terminal_observation_reused': transition['final_terminal_reused'],
            'final_bootstrap': info.get('bootstrap'),
            'final_reward': last['reward'], 'reward_sum': transition['reward_sum'],
            'reward_effective_step_end': rd['effective_step_end'],
            'reward_elapsed_sim_time': rd['elapsed_sim_time'],
            'termination_reason': info['reason'], 'terminal_probe_proof': n['terminal_probe_proof'],
            'evaluator_phase': {k: phase[k] for k in ('passed', 'initial_and_policy_acks', 'policy_quanta', 'terminal_ack')},
            'command_time_gate': {k: n['protocol']['command_time'][k] for k in ('passed', 'commands_checked', 'accepted_commands', 'rejected_commands', 'excluded_no_action_terminal_steps')},
            'control_ack_storage_scope': p['control'],
            'physics': n['physics'],
            'closure': {'passed': c['passed'], 'native_started': c['native_started'], 'native_clean_exits': c['native_clean_exits'], 'owned_identity_rows': c['owned_identity_rows'], 'worker_identity': c['worker_identity'], 'saved_owned_pid_start_identities': n['processes']['owned_pid_identities'], 'no_live_or_zombie_leftovers': True, 'supervisor': supervisor, 'native_stop': c['native_stop']},
            'contacts': {k: n['contacts'][k] for k in ('passed', 'raw_stream_count', 'zero_contact', 'termination_reason')}
        })
    assert len({x['epoch'] for x in episodes}) == 2
    accounting = {'reset_calls': 2, 'returned_step_calls': sum(x['api_step_returns'] for x in episodes), 'actually_submitted_commands': sum(x['submitted_action_count'] for x in episodes), 'zero_duration_terminal_settlements': 1, 'task_sampled_physical_time_sec': sum(x['sampled_physical_time_sec'] for x in episodes), 'benchmark_wall_seconds_including_all_attempts': native['wall_sec_including_all_attempts'], 'launcher_wall_seconds': launch['wall_duration_sec'], 'launcher_cumulative_matrix_wall_seconds': launch['cumulative_wall_seconds'], 'scope': '8 returned step API calls, 7 actual submitted commands; zero-duration terminal API return still counted, no native time fabricated.'}
    assert accounting['returned_step_calls'] == native['valid_transitions'] == 8
    assert accounting['actually_submitted_commands'] == 7
    result = {'schema': 'mr3-v17-terminal-finished-leaf-summary-v1', 'freeze': FREEZE, 'original_aggregate_passed': True, 'all_submitted_jobs_finished': True, 'runner_errors': [], 'formal_command_count': len(commands), 'formal_commands_all_passed': True, 'diagnostic_consistency_passed': True, 'episodes': episodes, 'accounting': accounting, 'original_inputs': originals, 'helper_sha256': digest(Path(__file__).read_bytes()), 'limitations': ['Diagnostic summary of existing finished formal receipts; no formal audit rerun.', 'Injected navigation_failure terminal paths supply engineering protocol/reward/closure evidence, not mapping success or trained-policy reliability.', 'Actual command publication/driver storage ACK is not proof of physical rest or Nav2 consumption.', 'No large raw reads, ModelStates, ROS calls, process control, native launch, or canonical mutation.']}
    for path, expected in originals.items():
        assert digest(Path(path).read_bytes()) == expected['sha256'], 'Input changed during summary: ' + path
    output.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + '\n')
    print(json.dumps({'summary': str(output), 'sha256': digest(output.read_bytes()), 'original_aggregate_passed': True, 'diagnostic_consistency_passed': True, 'accounting': accounting, 'branches': [x['terminal_branch'] for x in episodes]}, sort_keys=True))

if __name__ == '__main__':
    main()
