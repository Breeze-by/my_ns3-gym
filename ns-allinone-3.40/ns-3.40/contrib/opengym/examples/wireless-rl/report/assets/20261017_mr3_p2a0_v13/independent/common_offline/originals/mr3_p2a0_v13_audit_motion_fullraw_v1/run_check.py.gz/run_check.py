import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
WORK = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
SOURCES = [WORK / 'mr3_learning/audit_motion.py', WORK / 'mr3_learning/tests/test_audit_motion.py']


def hashes():
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in SOURCES}


name, *argv = sys.argv[1:]
env = dict(os.environ, PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1')
before = hashes()
started = time.monotonic()
with (OUT / (name + '.log')).open('xb') as stream:
    result = subprocess.run(argv, cwd=WORK, env=env, stdout=stream, stderr=subprocess.STDOUT)
receipt = {'argv': argv, 'cwd': str(WORK),
           'explicit_environment': {key: env[key] for key in
                                    ('PYTHONNOUSERSITE', 'PYTHONDONTWRITEBYTECODE')},
           'returncode': result.returncode, 'wall_seconds': time.monotonic() - started,
           'stdout_path': str(OUT / (name + '.log')),
           'stdout_sha256': hashlib.sha256((OUT / (name + '.log')).read_bytes()).hexdigest(),
           'source_before': before, 'source_after': hashes()}
(OUT / (name + '.json')).write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps(receipt), flush=True)
raise SystemExit(result.returncode)
