import hashlib
import json
import math
import os
from pathlib import Path
import xml.etree.ElementTree as ET

OUT = Path(__file__).parent
MAX_LINE = 1048576
PRE = 'before_physics_after_collision'
POST = 'world_update_end_after_physics_and_pose_propagation'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(stat):
    return [stat.st_dev, stat.st_ino, stat.st_size,
            stat.st_mtime_ns, stat.st_ctime_ns]


def ref(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def qmul(a, b):
    w, x, y, z = a
    v, i, j, k = b
    return [w*v-x*i-y*j-z*k, w*i+x*v+y*k-z*j,
            w*j-x*k+y*v+z*i, w*k+x*j-y*i+z*v]


def normal(q):
    n = math.sqrt(sum(v*v for v in q))
    assert math.isfinite(n) and n > 0
    return [v/n for v in q]


def inverse(q):
    w, x, y, z = normal(q)
    return [w, -x, -y, -z]


def rotate(q, p):
    return qmul(qmul(normal(q), [0]+p), inverse(q))[1:]


def rpy(q):
    w, x, y, z = normal(q)
    return [math.atan2(2*(w*x+y*z), 1-2*(x*x+y*y)),
            math.asin(max(-1., min(1., 2*(w*y-z*x)))),
            math.atan2(2*(w*z+x*y), 1-2*(y*y+z*z))]


def relative(a, b):
    p = rotate(inverse(a['quaternion_wxyz']),
               [v-u for u, v in zip(a['position_xyz'], b['position_xyz'])])
    q = qmul(inverse(a['quaternion_wxyz']), normal(b['quaternion_wxyz']))
    return {'position_xyz': p, 'quaternion_wxyz': q,
            'rpy_degrees': [math.degrees(v) for v in rpy(q)]}


class BoundedReader:
    def __init__(self, stream):
        self.stream = stream
        self.read_bytes = 0
        self.readline_calls = 0
        self.seek_calls = 0

    def seek(self, offset):
        self.seek_calls += 1
        self.stream.seek(offset)

    def line(self):
        self.readline_calls += 1
        raw = self.stream.readline(MAX_LINE+1)
        self.read_bytes += len(raw)
        assert len(raw) <= MAX_LINE, 'bounded line read overflow'
        assert not raw or raw.endswith(b'\n'), 'unterminated selected line'
        assert self.read_bytes < 16777216, 'bounded per-file IO guard'
        return raw

    def locate(self, target, size):
        low, high = 0, size
        probes = 0
        while high-low > 32768:
            middle = (low+high)//2
            self.seek(middle)
            if middle:
                self.line()
            pos = self.stream.tell()
            raw = self.line()
            probes += 1
            assert probes <= 64
            if not raw:
                high = middle
                continue
            row = json.loads(raw)
            if row['sim_time_ns'] < target:
                low = self.stream.tell()
            else:
                high = middle
        # low is a known line boundary or zero; high may bisect a line.
        self.seek(low)
        selected = []
        lines = 0
        while True:
            offset = self.stream.tell()
            raw = self.line()
            assert raw, 'target outside complete captured range'
            row = json.loads(raw)
            lines += 1
            assert lines < 256
            if row.get('kind') != 'sample':
                continue
            clock = row['sim_time_ns']
            if clock >= target:
                if clock > target+2000000:
                    break
                selected.append((offset, raw, row))
            if clock >= target+2000000 and row['phase'] == POST:
                break
        return selected, {'binary_probes': probes, 'tail_scan_lines': lines}


def derive(row):
    result = {'record_sequence': row['record_sequence'],
              'pair_sequence': row['pair_sequence'], 'phase': row['phase'],
              'clock_ns': row['sim_time_ns'], 'world_iterations': row['world_iterations']}
    for key in ('model', 'canonical', 'base'):
        body = row[key]
        pose = body['world_pose']
        result[key] = {'name': body['name'], 'world_pose': pose,
                       'quaternion_norm': math.sqrt(sum(v*v for v in pose['quaternion_wxyz'])),
                       'rpy_degrees': [math.degrees(v) for v in rpy(pose['quaternion_wxyz'])],
                       'world_linear_velocity_xyz': body.get('world_origin_linear_velocity_xyz', body.get('world_linear_velocity_xyz')),
                       'world_angular_velocity_xyz': body['world_angular_velocity_xyz']}
        if 'world_cog_pose' in body:
            result[key]['world_cog_pose'] = body['world_cog_pose']
    result['base_relative_canonical'] = relative(row['canonical']['world_pose'], row['base']['world_pose'])
    result['model_relative_canonical'] = relative(row['canonical']['world_pose'], row['model']['world_pose'])
    result['joints_right_left'] = row['joints_right_left']
    return result


def main():
    results = []
    formal_refs = []
    for stage in ('baseline', 'iters150'):
        formal_path = Path('/tmp/mr3_p2a0_v19_'+stage+'_observer_review.json')
        formal_raw = formal_path.read_bytes()
        formal = json.loads(formal_raw)
        assert formal['passed'] is True
        assert formal['consumer_sha256'] == 'e61ce4e00907ab35e196f7abe9fadfd9da099af3542f98dc773d593c33ca2b65'
        formal_refs.append(ref(formal_path))
        manifest_path = Path('/tmp/mr3_p2a0_v19_selected_native_v1')/stage/'manifest.json'
        manifest = json.loads(manifest_path.read_bytes())
        inventory = {row['source']: row for row in manifest['files']}
        interval = formal['actual_interval']
        for robot in ('tb1', 'tb2', 'tb3'):
            raw_path = Path(formal['episode_directory'])/('physics_'+robot+'.jsonl')
            stored = inventory[str(raw_path)]
            raw_proof = formal['inputs'][str(raw_path)]
            assert raw_proof['decoded_stream_complete'] is True
            assert stored['raw_sha256'] == raw_proof['sha256'] == raw_proof['decoded_sha256']
            assert stored['raw_bytes'] == raw_proof['bytes'] == raw_proof['decoded_bytes']
            before_path = identity(raw_path.stat())
            assert before_path == stored['source_stat_final']
            offsets = {}
            endpoints = []
            with raw_path.open('rb', buffering=0) as stream:
                before_fd = identity(os.fstat(stream.fileno()))
                assert before_fd == before_path
                reader = BoundedReader(stream)
                config_raw = reader.line()
                config = json.loads(config_raw)
                assert config['epoch'] == formal['epoch'] and config['robot'] == robot
                config_path = OUT/(stage+'_'+robot+'_configuration.jsonl')
                config_path.write_bytes(config_raw)
                for name, clock in [('task_start', interval['start_ns']), ('task_end', interval['end_ns'])]:
                    records, seek_stats = reader.locate(clock-1000000, stored['raw_bytes'])
                    chosen = [(offset, raw, row) for offset, raw, row in records
                              if clock-1000000 <= row['sim_time_ns'] <= clock+1000000]
                    exact = [row for _, _, row in chosen if row['sim_time_ns'] == clock]
                    assert len(exact) == 2 and {r['phase'] for r in exact} == {PRE, POST}
                    assert exact[0]['record_sequence']+1 == exact[1]['record_sequence']
                    assert exact[0]['pair_sequence'] == exact[1]['pair_sequence']
                    assert exact[0]['world_iterations'] == exact[1]['world_iterations']
                    for offset, raw, row in chosen:
                        assert row['epoch'] == formal['epoch'] and row['robot'] == robot
                        offsets[offset] = (raw, row)
                    endpoints.append({'name': name, 'clock_ns': clock,
                                      'seek': seek_stats,
                                      'exact_same_clock_pre_post': [derive(row) for row in exact]})
                after_fd = identity(os.fstat(stream.fileno()))
                io = {'bytes_read_including_binary_probes': reader.read_bytes,
                      'readline_calls': reader.readline_calls, 'seek_calls': reader.seek_calls,
                      'max_per_file_read_guard_bytes': 16777216,
                      'whole_file_rehash_performed': False}
            after_path = identity(raw_path.stat())
            assert before_fd == after_fd == before_path == after_path
            selected_path = OUT/(stage+'_'+robot+'_selected_rows.jsonl')
            selected_path.write_bytes(b''.join(offsets[offset][0] for offset in sorted(offsets)))
            selected_rows = []
            for offset in sorted(offsets):
                raw, row = offsets[offset]
                selected_rows.append({'source_offset_bytes': offset,
                                      'raw_bytes_including_newline': len(raw),
                                      'raw_sha256': sha(raw), 'record_sequence': row['record_sequence'],
                                      'clock_ns': row['sim_time_ns'], 'phase': row['phase']})
            results.append({'stage': stage, 'robot': robot, 'epoch': formal['epoch'],
                            'source': str(raw_path), 'full_raw_sha256': raw_proof['sha256'],
                            'full_raw_sha_scope': 'Inherited from completed e61c formal and exact closed-custody manifest; no second whole-file scan.',
                            'raw_bytes': raw_proof['bytes'],
                            'stat_before_fd': before_fd, 'stat_after_fd': after_fd,
                            'stat_before_path': before_path, 'stat_after_path': after_path,
                            'configuration': ref(config_path),
                            'selected': ref(selected_path), 'selected_rows': selected_rows,
                            'io': io, 'endpoints': endpoints})
    # Parse actual XML, which excludes commented tray/wall content.
    model_path = Path('/home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/src/multi_robot/models/turtlebot3_waffle/model.sdf')
    model_raw = model_path.read_bytes()
    for formal_ref in formal_refs:
        proof = json.loads(Path(formal_ref['path']).read_bytes())
        assert sha(model_raw) == proof['inputs'][str(model_path)]['sha256']
    model = ET.fromstring(model_raw).find('model')
    links = {node.attrib['name']: node for node in model.findall('link')}
    joints = {node.attrib['name']: node for node in model.findall('joint')}
    model_summary = {'source': ref(model_path), 'active_link_names': list(links),
                     'active_fixed_joints': [{'name': name, 'xml': ET.tostring(node, encoding='unicode')}
                                             for name, node in joints.items() if node.attrib.get('type') == 'fixed'],
                     'base_scan_xml': ET.tostring(links['base_scan'], encoding='unicode'),
                     'commented_content_excluded_by_xml_parser': True,
                     'scope': 'Source geometry only; sensor world pose derived from SDF defaults requires separate frame semantics and is not directly measured by observer.'}
    urdf_path = model_path.parent.parent.parent/'urdf'/'turtlebot3_waffle.urdf'
    urdf = ET.fromstring(urdf_path.read_bytes())
    model_summary['urdf_source'] = ref(urdf_path)
    model_summary['urdf_relevant_fixed_joints'] = [ET.tostring(node, encoding='unicode') for node in urdf.findall('joint') if node.attrib.get('type') == 'fixed' and any((node.find(tag) is not None and node.find(tag).attrib.get('link') in {'base_link', 'base_footprint', 'base_scan'}) for tag in ('parent', 'child'))]
    report = {'schema': 'mr3-v19-bounded-endpoint-pose-diagnostic-v1',
              'passed': True, 'pass_scope': 'Bounded extraction/provenance correctness only, no new physical/task/matrix or causal credit.',
              'freeze': formal['freeze'], 'formal_reviews': formal_refs,
              'sampling': 'Exact task start/end PRE+POST with adjacent +/-1ms original context; no full raw rescan.',
              'results': results, 'source_geometry': model_summary,
              'limitations': ['Endpoints alone do not characterize all task or startup pose extrema.',
                              'GetParam motor targets are not private driver desired/applied identity; existing 30Hz driver trace is separate.',
                              'No laser scan samples are extracted and no mapping root cause is inferred from pose alone.',
                              'Six full-file hashes inherit completed formal/custody proofs; this diagnostic independently hashes selected original bytes only.']}
    report_path = OUT/'review_v1.json'
    report_path.write_text(json.dumps(report, indent=2)+'\n')
    summary = []
    for row in results:
        values = {'stage': row['stage'], 'robot': row['robot'], 'bytes_read': row['io']['bytes_read_including_binary_probes']}
        for endpoint in row['endpoints']:
            values[endpoint['name']] = [{'phase': r['phase'],
                                        'model_xyz': r['model']['world_pose']['position_xyz'],
                                        'model_rpy_degrees': r['model']['rpy_degrees'],
                                        'base_xyz': r['base']['world_pose']['position_xyz'],
                                        'base_rpy_degrees': r['base']['rpy_degrees'],
                                        'fixed_relative': r['base_relative_canonical'],
                                        'wheel_targets_radps': [v['motor_velocity_target_radps'] for v in r['joints_right_left']],
                                        'wheel_actual_radps': [v['velocity_radps'] for v in r['joints_right_left']]}
                                       for r in endpoint['exact_same_clock_pre_post']]
        summary.append(values)
    print(json.dumps({'review': ref(report_path), 'total_source_bytes_read': sum(row['io']['bytes_read_including_binary_probes'] for row in results), 'summary': summary}, indent=2))


if __name__ == '__main__':
    main()
