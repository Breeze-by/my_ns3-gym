"""Losslessly archive stopped V13 CPU originals; never copy native payloads."""

import gzip
import hashlib
import json
from pathlib import Path
import sys


REPOSITORY = Path('/home/zhuyulab/ns3-workspace')
DESTINATION = REPOSITORY / (
    'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/'
    '20261017_mr3_p2a0_v13/independent/common_offline')
SAFETY = DESTINATION.parent / 'safety_offline/manifest.json'
CANDIDATE = DESTINATION.parent / 'candidate_offline/manifest.json'
PRIOR_MANIFESTS = sorted(DESTINATION.parent.glob('*/manifest.json'))
EXISTING = {entry['source'] for manifest in PRIOR_MANIFESTS
            for data in [json.loads(manifest.read_text())]
            for entry in data.get('entries', data.get('files', []))}
DIRECTORIES = []
STANDALONE = []
for item in sorted(Path('/tmp').glob('mr3_*v13*')):
    if ('root_continuation_state' in item.name
            or item.name.startswith('mr3_v13_scheduler_fixture_')
            or item.name.endswith('_archive_receipt.json')):
        continue
    (DIRECTORIES if item.is_dir() and not item.is_symlink() else STANDALONE).append(item)
DIRECTORIES.append(Path('/tmp/mr3_paired_wheel_numeric_proposal_v1'))
STANDALONE += [Path('/tmp/mr3_independent_drive_trace_v6.py')]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def stat(path):
    value = path.stat()
    return {'size': value.st_size, 'mtime_ns': value.st_mtime_ns,
            'inode': value.st_ino, 'device': value.st_dev}


def main():
    DESTINATION.mkdir(parents=True, exist_ok=False)
    originals = DESTINATION / 'originals'
    originals.mkdir()
    sources = []
    excluded = []
    for directory in DIRECTORIES:
        assert directory.is_dir() and not directory.is_symlink(), directory
        for path in sorted(directory.rglob('*')):
            if path.is_symlink():
                excluded.append({'source': str(path), 'reason': 'symbolic link'})
            elif path.is_file():
                sources.append((path, Path(directory.name) / path.relative_to(directory)))
    sources.extend((path, Path('standalone') / path.name) for path in STANDALONE)
    sources.append((Path(__file__).resolve(), Path('tools') / Path(__file__).name))
    sources = list({str(path): (path, relative) for path, relative in sources
                    if str(path) not in EXISTING}.values())
    entries = []
    for path, relative in sources:
        assert path.is_absolute() and path.is_file() and not path.is_symlink(), path
        if ('.git' in path.parts or '__pycache__' in path.parts
                or path.suffix in ('.pyc', '.so', '.o', '.a')):
            excluded.append({'source': str(path), 'reason': 'compiled binary/cache'})
            continue
        initial_stat = stat(path)
        raw = path.read_bytes()
        if raw.startswith(b'\x7fELF'):
            excluded.append({'source': str(path), 'reason': 'ELF compiled binary'})
            continue
        target = originals / (str(relative) + '.gz')
        target.parent.mkdir(parents=True, exist_ok=True)
        encoded = gzip.compress(raw, mtime=0)
        with target.open('xb') as stream:
            stream.write(encoded)
        actual = target.read_bytes()
        decoded = gzip.decompress(actual)
        later_raw = path.read_bytes()
        final_stat = stat(path)
        assert actual == encoded and decoded == raw and later_raw == raw, path
        assert initial_stat == final_stat, path
        item = {
            'source': str(path),
            'selected': str(target.relative_to(DESTINATION)),
            'compression': 'gzip',
            'raw_bytes': len(raw), 'encoded_bytes': len(actual),
            'raw_sha256': sha(raw), 'encoded_sha256': sha(actual),
            'decoded_sha256': sha(decoded),
            'source_before_sha256': sha(raw), 'source_after_sha256': sha(later_raw),
            'source_stat_before': initial_stat, 'source_stat_after': final_stat,
            'source_stable': True,
        }
        if path.suffix == '.gz':
            # The outer archive encoding preserves this already-compressed
            # original byte-for-byte; retain its inner decoded-content digest too.
            item['source_was_already_gzip'] = True
            try:
                item['source_gzip_decoded_sha256'] = sha(gzip.decompress(raw))
            except Exception as error:
                item['source_gzip_decode_error_preserved'] = repr(error)
        entries.append(item)
    # Recheck every selected source after all copying, not just each local read.
    for entry in entries:
        source = Path(entry['source'])
        target = DESTINATION / entry['selected']
        assert sha(source.read_bytes()) == entry['source_after_sha256']
        assert stat(source) == entry['source_stat_after']
        assert sha(target.read_bytes()) == entry['encoded_sha256']
        assert sha(gzip.decompress(target.read_bytes())) == entry['decoded_sha256']
    manifest = {
        'schema': 'mr3-offline-originals-manifest-v1', 'passed': True,
        'scope': 'Stopped V13 prospective CPU proposals, corrections, '
                 'actual-source unit checks and independent reviews only. '
                 'V12 canonical native/formal archives are untouched.',
        'archive_argv': list(sys.argv),
        'archive_command': 'rtk proxy env PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 '
                           '/tmp/mr3_archive_common_offline_v13_v1.py',
        'archive_cwd': str(REPOSITORY),
        'counts': {'originals': len(entries),
                   'raw_bytes': sum(entry['raw_bytes'] for entry in entries),
                   'encoded_bytes': sum(entry['encoded_bytes'] for entry in entries),
                   'explicit_discovered_exclusions': len(excluded)},
        'verification': 'Every archive encoded file and decoded original matched SHA256 '
                        'and byte comparison, and every /tmp original SHA/stat stayed '
                        'stable across initial read, local copy and whole-copy end.',
        'encoding_note': 'All originals use one deterministic outer gzip layer. An '
                         'already-gzip original therefore has .gz.gz and an additional '
                         'source_gzip_decoded_sha256; its original encoded bytes remain exact.',
        'deduplication_key_for_other_archivers': 'entries[].source absolute original path',
        'exclusions': excluded,
        'already_archived_originals_manifest': str(SAFETY),
        'already_archived_originals_manifest_sha256': sha(SAFETY.read_bytes()),
        'deduplicated_prior_manifests': [{'path': str(p), 'sha256': sha(p.read_bytes())} for p in PRIOR_MANIFESTS],
        'candidate_originals_manifest': str(CANDIDATE),
        'candidate_originals_manifest_sha256': sha(CANDIDATE.read_bytes()),
        'deliberate_external_exclusions': [
            {'source': 'entries[].source from Safety and Candidate manifests',
             'reason': 'One canonical copy is already checked and preserved by source path'},
            {'source': '/tmp/mr3_p2a0_v12_*',
             'reason': 'Original native and failure evidence preserved in d48b939'},
            {'source': 'ELF/CPU compiled binaries, cache/.git and symlinks',
             'reason': 'Reproduction commands/results and sources retained; actual new drive SO '
                       'is intentionally preserved in the separate canonical binary receipt'}],
        'entries': entries,
    }
    output = DESTINATION / 'manifest.json'
    output.write_text(json.dumps(manifest, sort_keys=True, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'destination': str(DESTINATION), 'counts': manifest['counts'],
                      'manifest_sha256': sha(output.read_bytes())}, sort_keys=True))


if __name__ == '__main__':
    main()
