"""New synthetic contracts only; no ROS graph, native, raw replay or physics credit."""
import copy
import importlib.util
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest import mock

ROOT=Path("/home/zhuyulab/ns3-workspace")
COMP=ROOT/"ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration"
sys.path.insert(0,str(COMP))
from multi_robot_exploration.mr3_protocol import GoalDispatcher
import multi_robot_exploration

HERE=Path(__file__).resolve().parent
HELPER=HERE/"mr3_motion_authority.py"
if not HELPER.exists():HELPER=HERE.parent/"multi_robot_exploration/mr3_motion_authority.py"
spec=importlib.util.spec_from_file_location("multi_robot_exploration.mr3_motion_authority",HELPER)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
support_spec=importlib.util.spec_from_file_location("authority_real_reach_feed",COMP/"test/test_mr3_reach_runtime_independent.py")
f=importlib.util.module_from_spec(support_spec);support_spec.loader.exec_module(f)
EPOCH,ROBOT=f.EPOCH,f.ROBOT
GID="ARTIFICIAL_expected_publisher_gid"


def native_handle(byte):
    return SimpleNamespace(accepted=True,goal_id=SimpleNamespace(uuid=bytes([byte])*16))


def accepted(now_ns,command=1):
    events=[];d=GoalDispatcher(EPOCH,events.append)
    now=now_ns/1e9
    result=d.submit(ROBOT,"GOAL",now,1,command,now+2,goal={"x":2.,"y":0.},command_epoch=EPOCH,created_at=now)
    if result!="sent":raise AssertionError(result)
    goal=d.states[ROBOT].goal_id;handle=native_handle(command)
    d.on_accept(ROBOT,goal,True,now)
    return d,{goal:handle},events


def raw(sequence,v=.1,w=0.):
    return {"sequence":sequence,"v":v,"w":w}


def revoked(grant,sequence,clock):
    result=copy.deepcopy(grant)
    result.update(operation="revoke",authority_sequence=sequence,source_clock_ns=clock,lease_until_ns=clock)
    return result


class AuthorityContracts(unittest.TestCase):
    def initial(self,command=1):
        feed=f.Feed().disk();gate=m.MotionAuthority(EPOCH,ROBOT,GID)
        ack=gate.observe_stop(feed.r,feed.now)
        self.assertIsNotNone(ack)
        self.assertIs(ack["witness"]["continuous_physics_proved"],False)
        d,handles,events=accepted(feed.now,command)
        grant=m.from_accepted_owner(d,ROBOT,handles,1,feed.now,accepted_goal_id=d.states[ROBOT].goal_id)
        received=gate.receive(grant,publisher_gid=GID,clock_ns=feed.now,latest_raw_sequence=50)
        self.assertTrue(received["accepted"])
        return feed,gate,d,handles,grant

    def test_missing_authority_blocks_59_fresh_callbacks_through_original_reach(self):
        feed=f.Feed().disk();gate=m.MotionAuthority(EPOCH,ROBOT,GID)
        anchor=copy.deepcopy(feed.r.anchor)
        for sequence in range(1,60):
            request=gate.input(raw(sequence,.2,.3),clock_ns=feed.now+f.STEP)
            self.assertEqual(request["effective_request"],[0.,0.])
            decision=feed.tick(request["effective_request"])
            self.assertEqual(decision["output"],[0.,0.])
            self.assertFalse(feed.r.stopped)
        self.assertEqual(feed.r.anchor,anchor)

    def test_source_requires_real_dispatcher_accept_and_legal_commitment(self):
        now=2.;events=[];d=GoalDispatcher(EPOCH,events.append)
        self.assertEqual(d.submit(ROBOT,"GOAL",now,1,1,now+2,goal={"x":2.,"y":0.},command_epoch=EPOCH,created_at=now),"sent")
        goal=d.states[ROBOT].goal_id;handles={goal:native_handle(1)}
        with self.assertRaises(ValueError):m.from_accepted_owner(d,ROBOT,handles,1,2_000_000_000,accepted_goal_id=goal)
        d.on_accept(ROBOT,goal,True,now)
        grant=m.from_accepted_owner(d,ROBOT,handles,1,2_000_000_000,accepted_goal_id=goal)
        with self.assertRaises(ValueError):m.from_accepted_owner(d,ROBOT,{},2,2_000_000_000,accepted_goal_id=goal)
        with self.assertRaises(ValueError):m.from_accepted_owner(d,ROBOT,handles,2,2_000_000_000,accepted_goal_id=goal+"_OLD")
        with self.assertRaises(ValueError):m.from_terminal_owner(d,grant,2,2_000_000_000,terminal_goal_id=goal+"_OLD",status=5)
        terminal=m.from_terminal_owner(d,grant,2,2_000_000_000,terminal_goal_id=goal,status=4)
        self.assertEqual(terminal["operation"],"revoke")
        self.assertEqual(d.submit(ROBOT,"WAIT",now+.1,2,2,now+2.1,command_epoch=EPOCH,created_at=now+.1),"commitment_locked")
        with self.assertRaises(ValueError):m.from_canceling_owner(d,grant,2,2_100_000_000)
        for tenth in range(1,52):
            time=now+tenth/10
            d.renew(ROBOT,goal,EPOCH,time,time+2)
        time=now+5.1
        self.assertEqual(d.submit(ROBOT,"WAIT",time,3,3,time+2,command_epoch=EPOCH,created_at=time),"waiting")
        calls=[]
        message,future=m.issue_owned_cancel(d,grant,2,7_100_000_000,
            lambda packet:calls.append(("publish_only",packet["source_clock_ns"])),
            lambda:calls.append(("native_cancel_attempt",7_100_000_000)) or "unresolved_future")
        self.assertEqual(calls,[("publish_only",7_100_000_000),("native_cancel_attempt",7_100_000_000)])
        self.assertEqual(future,"unresolved_future")
        self.assertEqual(message["operation"],"revoke")
        d.on_cancel_response(ROBOT,goal,False,time)
        with self.assertRaises(ValueError):m.from_accepted_owner(d,ROBOT,handles,3,7_100_000_000,accepted_goal_id=goal)
        # A failed publication still cannot delay/skip the native call attempt.
        calls=[]
        def bad_publish(packet):calls.append("publication_failure");raise OSError("ARTIFICIAL")
        with self.assertRaises(OSError):m.issue_owned_cancel(d,grant,3,7_100_000_000,bad_publish,lambda:calls.append("native_attempt"))
        self.assertEqual(calls,["publication_failure","native_attempt"])

    def test_witness_needs_real_storage_actual_application_and_rest(self):
        feed=f.Feed();gate=m.MotionAuthority(EPOCH,ROBOT,GID)
        self.assertIsNone(gate.observe_stop(feed.r,feed.now))
        feed.disk();good=gate.observe_stop(feed.r,feed.now)
        self.assertIsNotNone(good)
        applied=feed.r.causal_applied;seq=applied["target"]["decision_sequence"]
        stored=feed.r.storage.pending[ROBOT].pop(seq)
        self.assertIsNone(gate.observe_stop(feed.r,feed.now))
        feed.r.storage.pending[ROBOT][seq]=stored
        rest=feed.r.rest;feed.r.rest=rest[:2]
        self.assertIsNone(gate.observe_stop(feed.r,feed.now))
        feed.r.rest=rest
        old=feed.r.causal_applied;feed.r.causal_applied=None
        self.assertIsNone(gate.observe_stop(feed.r,feed.now))
        feed.r.causal_applied=old
        anchor=copy.deepcopy(feed.r.anchors)
        self.assertIsNotNone(gate.observe_stop(feed.r,feed.now))
        self.assertEqual(feed.r.anchors,anchor)
        # Target-zero is not a claim that legitimate initial encoder
        # correction has actual zero rim commands. The schema permits it.
        original_applied=f.applied
        def corrective(*args,**kwargs):
            value=original_applied(*args,**kwargs)
            value["pairs"][0]["applied_rim_mps"]=[.0001,-.0001]
            return value
        with mock.patch.object(f,"applied",side_effect=corrective):
            initial=f.Feed().disk()
        initial_gate=m.MotionAuthority(EPOCH,ROBOT,GID)
        honest=initial_gate.observe_stop(initial.r,initial.now)
        self.assertIsNotNone(honest)
        self.assertFalse(honest["witness"]["actual_rims_zero"])
        self.assertFalse(honest["witness"]["after_real_nonzero_application"])
        self.assertIsNone(m.normal_zero_witness(initial.r,initial.now,initial.r.release_ns,after_real_motion=True))

    def test_receiving_floor_is_not_generation_attribution(self):
        feed,gate,_,_,_=self.initial()
        self.assertEqual(gate.input(raw(50),clock_ns=feed.now)["effective_request"],[0.,0.])
        after=gate.input(raw(51),clock_ns=feed.now)
        self.assertEqual(after["effective_request"],[.1,0.])
        self.assertIsNone(after["raw_goal_generation"])
        self.assertEqual(after["raw_goal_association"],"UNKNOWN_UNSTAMPED_TWIST")
        # A message generated before cancel but delivered after GRANT is
        # observationally identical. We explicitly DO NOT claim to reject it.
        indistinguishable=gate.input(raw(52),clock_ns=feed.now)
        self.assertEqual(indistinguishable["permission"],"normal_reach")
        self.assertIsNone(indistinguishable["raw_goal_generation"])

    def test_real_reach_stop_debt_then_next_actual_owner_grant(self):
        feed,gate,_,_,grant=self.initial()
        for sequence in range(51,55):
            effective=gate.input(raw(sequence),clock_ns=feed.now+f.STEP)["effective_request"]
            feed.tick(effective);gate.note_real_application(feed.r)
        self.assertEqual(feed.r.role,"N")
        self.assertTrue(gate.after_real_motion)
        cancel=revoked(grant,2,feed.now)
        self.assertTrue(gate.receive(cancel,publisher_gid=GID,clock_ns=feed.now,latest_raw_sequence=54)["accepted"])
        self.assertIsNone(gate.observe_stop(feed.r,feed.now))
        for sequence in range(55,114):
            effective=gate.input(raw(sequence,.2,.3),clock_ns=feed.now+f.STEP)["effective_request"]
            self.assertEqual(effective,[0.,0.])
            feed.tick(effective);gate.note_real_application(feed.r)
        ready=gate.observe_stop(feed.r,feed.now)
        self.assertIsNotNone(ready)
        self.assertTrue(ready["witness"]["actual_rims_zero"])
        self.assertFalse(feed.r.stopped)
        new_d,new_handles,_=accepted(feed.now,2)
        new_grant=m.from_accepted_owner(new_d,ROBOT,new_handles,3,feed.now,accepted_goal_id=new_d.states[ROBOT].goal_id)
        self.assertTrue(gate.receive(new_grant,publisher_gid=GID,clock_ns=feed.now,latest_raw_sequence=113)["accepted"])
        late_cancel=revoked(grant,4,feed.now)
        self.assertFalse(gate.receive(late_cancel,publisher_gid=GID,clock_ns=feed.now,latest_raw_sequence=114)["accepted"])
        self.assertEqual(gate.state,"ACTIVE")
        self.assertEqual(gate.owner["goal_id"],new_grant["goal_id"])
        self.assertIsNone(gate.fault)
        self.assertEqual(gate.input(raw(114),clock_ns=feed.now)["effective_request"],[.1,0.])

    def test_duplicate_revoke_old_grant_and_overlap_are_fail_closed(self):
        feed,gate,_,_,grant=self.initial()
        revoke=revoked(grant,2,feed.now)
        first=gate.receive(revoke,publisher_gid=GID,clock_ns=feed.now,latest_raw_sequence=51)
        start=gate.stop_not_before_ns
        duplicate=gate.receive(revoke,publisher_gid=GID,clock_ns=feed.now+1,latest_raw_sequence=52)
        self.assertTrue(first["accepted"] and duplicate["accepted"])
        self.assertEqual(duplicate["reason"],"duplicate")
        self.assertEqual(gate.stop_not_before_ns,start)
        self.assertFalse(gate.receive(grant,publisher_gid=GID,clock_ns=feed.now+1,latest_raw_sequence=53)["accepted"])
        resurrect=copy.deepcopy(grant);resurrect.update(authority_sequence=3,owner_grant_sequence=3)
        self.assertFalse(gate.receive(resurrect,publisher_gid=GID,clock_ns=feed.now+1,latest_raw_sequence=54)["accepted"])
        self.assertEqual(gate.state,"REVOKED")
        self.assertEqual(gate.input(raw(59),clock_ns=feed.now+1)["effective_request"],[0.,0.])
        # A distinct overlapping owner also cannot open an ACTIVE stream.
        other_feed,other,_,_,_=self.initial()
        d,handles,_=accepted(other_feed.now,2)
        overlap=m.from_accepted_owner(d,ROBOT,handles,2,other_feed.now,accepted_goal_id=d.states[ROBOT].goal_id)
        self.assertFalse(other.receive(overlap,publisher_gid=GID,clock_ns=other_feed.now,latest_raw_sequence=60)["accepted"])
        self.assertEqual(other.input(raw(61),clock_ns=other_feed.now)["effective_request"],[0.,0.])

    def test_invalid_missing_foreign_and_conflicting_packets_block(self):
        feed=f.Feed().disk()
        d,handles,_=accepted(feed.now);message=m.from_accepted_owner(d,ROBOT,handles,1,feed.now,accepted_goal_id=d.states[ROBOT].goal_id)
        for change,gid in ((lambda p:p.pop("native_goal_uuid"),GID),(lambda p:p.update(epoch="OTHER"),GID),
                           (lambda p:p.update(robot="tb2"),GID),(lambda p:None,"OTHER_PUBLISHER"),
                           (lambda p:p.update(lease_until_ns=feed.now-1),GID)):
            gate=m.MotionAuthority(EPOCH,ROBOT,GID);gate.observe_stop(feed.r,feed.now)
            packet=copy.deepcopy(message);change(packet)
            self.assertFalse(gate.receive(packet,publisher_gid=gid,clock_ns=feed.now,latest_raw_sequence=10)["accepted"])
            self.assertEqual(gate.input(raw(59),clock_ns=feed.now)["effective_request"],[0.,0.])
        feed,gate,_,_,grant=self.initial()
        modified=copy.deepcopy(grant);modified["lease_until_ns"]-=1
        self.assertFalse(gate.receive(modified,publisher_gid=GID,clock_ns=feed.now,latest_raw_sequence=51)["accepted"])
        self.assertEqual(gate.input(raw(59),clock_ns=feed.now)["effective_request"],[0.,0.])

    def test_expired_lease_and_new_callback_cannot_restore_permission(self):
        feed,gate,_,_,grant=self.initial()
        clock=grant["lease_until_ns"]
        self.assertEqual(gate.input(raw(59),clock_ns=clock)["effective_request"],[0.,0.])
        self.assertEqual(gate.state,"REVOKED")
        self.assertEqual(gate.input(raw(60),clock_ns=clock+1)["effective_request"],[0.,0.])
        self.assertIsNone(gate.ready)


if __name__=="__main__":unittest.main(verbosity=2)
