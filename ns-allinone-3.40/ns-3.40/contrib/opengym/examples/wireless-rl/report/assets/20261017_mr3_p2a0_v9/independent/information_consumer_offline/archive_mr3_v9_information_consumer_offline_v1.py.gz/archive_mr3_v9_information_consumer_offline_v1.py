"""Losslessly select independent information-reader CPU originals; no native."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/zhuyulab/ns3-workspace')
TMP = Path('/tmp')
BASE = ROOT / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/'
               '20261017_mr3_p2a0_v9/independent')
OUT = BASE / 'information_consumer_offline'
CANONICAL = [BASE / name for name in ('mr3_independent_information_v1.py',
                                     'mr3_independent_information_v1_tests.py')]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


source_bytes = {str(path): path.read_bytes() for path in CANONICAL}
files = set()
for pattern in ('mr3_p2a0_v9_information_consumer_*',
                'mr3_p2a0_v9_information_raw_counterexample_v1.*',
                'mr3_independent_information_v1*',
                'mr3_information_producer_ledger_fixture_v*'):
    files.update(path for path in TMP.glob(pattern) if path.is_file())
for version in (1, 2):
    folder = TMP / ('mr3_p2a0_v9_information_producer_fixture_v' + str(version))
    files.update(path for path in folder.rglob('*') if path.is_file())
files.add(Path(__file__))
require_checks = TMP / 'mr3_p2a0_v9_information_consumer_checks_v1.json'
assert require_checks in files
OUT.mkdir(parents=True, exist_ok=False)
items = []
for source in sorted(files):
    assert source.suffix not in ('.pyc', '.so')
    raw = source.read_bytes()
    relative = source.relative_to(TMP)
    target = OUT / (str(relative) + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    encoded = gzip.compress(raw, mtime=0)
    with target.open('xb') as stream:
        stream.write(encoded)
    reread = target.read_bytes()
    decoded = gzip.decompress(reread)
    assert decoded == raw and reread == encoded
    items.append({'source_path': str(source),
                  'selected_path': str(target.relative_to(ROOT)),
                  'encoding': 'lossless-gzip-mtime0',
                  'raw_bytes': len(raw), 'encoded_bytes': len(encoded),
                  'raw_sha256': sha(raw), 'encoded_sha256': sha(reread),
                  'decoded_sha256': sha(decoded), 'decoded_equals_original': True})
for item in items:
    source = Path(item['source_path'])
    target = ROOT / item['selected_path']
    assert sha(source.read_bytes()) == item['raw_sha256']
    assert sha(target.read_bytes()) == item['encoded_sha256']
    assert sha(gzip.decompress(target.read_bytes())) == item['decoded_sha256']
for name, raw in source_bytes.items():
    assert Path(name).read_bytes() == raw
manifest = {'schema': 'mr3-v9-information-consumer-offline-originals-v1', 'passed': True,
            'scope': 'Independent reader CPU-only selected originals, no native or continuous-body proof. '
                     'Historical absolute /tmp links inside untouched original receipts map through this manifest.',
            'canonical_sources_unchanged': [{'path': name, 'sha256': sha(raw)}
                                            for name, raw in source_bytes.items()],
            'files': items, 'file_count': len(items),
            'total_original_bytes': sum(item['raw_bytes'] for item in items),
            'total_encoded_bytes': sum(item['encoded_bytes'] for item in items),
            'history': 'Early style failures and all intermediate test stdout are original untouched outputs. '
                       'They do not imply final-source bytes equal unpinned historical drafts. '
                       'The before-cache snapshot has its own binding; it is not substituted for early review.',
            'review_evidence': 'Original message review is summarized with explicit limits in the immutable '
                               'consumer_checks_v1 receipt; no new original execution log is invented.'}
manifest_path = OUT / 'originals_manifest_v1.json'
with manifest_path.open('x') as stream:
    json.dump(manifest, stream, indent=2, sort_keys=True, allow_nan=False)
    stream.write('\n')
print(json.dumps({'passed': True, 'manifest': str(manifest_path),
                  'manifest_sha256': sha(manifest_path.read_bytes()),
                  'file_count': len(items), 'raw_bytes': manifest['total_original_bytes'],
                  'encoded_bytes': manifest['total_encoded_bytes']}, sort_keys=True))
