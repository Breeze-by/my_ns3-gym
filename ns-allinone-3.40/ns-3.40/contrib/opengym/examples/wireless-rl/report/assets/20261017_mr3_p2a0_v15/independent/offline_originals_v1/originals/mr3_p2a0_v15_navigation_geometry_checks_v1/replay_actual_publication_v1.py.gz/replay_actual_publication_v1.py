"""Replay the full real producer with six V14 selected raw callbacks, offline."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

from geometry_msgs.msg import TransformStamped
from nav_msgs.msg import Odometry

from multi_robot_exploration import control, peer_obstacles
from multi_robot_exploration.mr3_information import restore_message
from multi_robot_exploration.mr3_motion_safety import COMMAND_SPEED_LIMIT

ROOT = Path('/home/zhuyulab/ns3-workspace')
OLD = ROOT / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/'
              '20261017_mr3_p2a0_v10/independent/mr3_independent_control_phase_v1.py')
INPUTS = Path('/tmp/mr3_p2a0_v14_peer_geometry_diagnostic_v1/selected_inputs.json')
OUT = Path(__file__).parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    assert sha(OLD.read_bytes()) == '04cd7d079c16004b20320868943bcdac899da7646304d30cbad0804d1a6ee8d3'
    spec = importlib.util.spec_from_file_location('immutable_A10_geometry', OLD)
    original = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(original)
    raw = INPUTS.read_bytes()
    selected = {tuple(k.split(':')): value for k, value in json.loads(raw).items()}
    odometry = {name: restore_message(Odometry(), selected['odom', name]['raw'])
                for name in original.ROBOTS}
    transforms = {name: restore_message(TransformStamped(), selected['tf', name]['raw'])
                  for name in original.ROBOTS}
    messages = {(name, kind): [] for name in original.ROBOTS for kind in ('scan', 'cloud')}
    failures = []
    publisher = lambda key: SimpleNamespace(publish=lambda msg: messages[key].append(copy.deepcopy(msg)))
    node = SimpleNamespace(
        names=list(original.ROBOTS), mission_started=True, failed=False, tf_source_lead_sec=.2,
        publishers_by_robot={name: publisher((name, 'scan')) for name in original.ROBOTS},
        body_publishers={name: publisher((name, 'cloud')) for name in original.ROBOTS},
        failure_publisher=SimpleNamespace(publish=lambda value: failures.append(copy.deepcopy(value))),
        get_logger=lambda: SimpleNamespace(error=failures.append))
    outputs = peer_obstacles.PeerObstacles._publish_inputs(
        node, odometry, transforms, 73_240_000_000, capture=True)
    expected = original.expected_outputs(selected, 73_240_000_000)
    assert not failures and not node.failed and len(outputs) == 6
    comparisons = []
    for item in outputs:
        key = item['robot'], item['kind']
        payload = item['payload']
        assert len(messages[key]) == 1
        assert original.canonical(payload) == original.canonical(expected[key])
        assert peer_obstacles.obstacle_payload(messages[key][0], key[1]) == payload
        comparisons.append({'robot': key[0], 'kind': key[1],
                            'metadata_sha256': original.digest(payload),
                            'equals_immutable_A10_geometry': True,
                            'cloud_bytes': len(messages[key][0].data) if key[1] == 'cloud' else None,
                            'cloud_sha256': sha(bytes(messages[key][0].data)) if key[1] == 'cloud' else None})
    result = {'schema': 'mr3-v15-navigation-full-producer-offline-replay-v1', 'passed': True,
              'source_bytes': {control.__file__: sha(Path(control.__file__).read_bytes()),
                               peer_obstacles.__file__: sha(Path(peer_obstacles.__file__).read_bytes()),
                               str(OLD): sha(OLD.read_bytes())},
              'input': {'path': str(INPUTS), 'sha256': sha(raw), 'recorded_target_clock_ns': 73240000000},
              'command_cap': COMMAND_SPEED_LIMIT, 'navigation_peer_speed': control.PEER_SPEED_BOUND_MPS,
              'comparisons': comparisons, 'actual_production_publish_calls': 6,
              'publisher': 'in-memory capture only; no ROS init/DDS',
              'scope': 'Full real _publish_inputs with actual ROS messages restored from native '
                       'selected callbacks; every field and cloud byte hash now matches frozen '
                       'A10 geometry. This counterfactual offline repair replay does not alter '
                       'V14 actual cloud/FAIL or grant new native/physical/task credit.'}
    with (OUT / 'actual_publication_replay_v1.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    with (OUT / 'actual_publication_replay_outputs_v1.json').open('x') as stream:
        json.dump(outputs, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'passed': True, 'actual_source_publish_calls': len(outputs),
                      'command_cap': COMMAND_SPEED_LIMIT, 'navigation_peer_speed': control.PEER_SPEED_BOUND_MPS}))


if __name__ == '__main__':
    main()
