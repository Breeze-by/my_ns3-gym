#include <fastrtps/xmlparser/XMLProfileManager.h>
#include <fastrtps/attributes/PublisherAttributes.h>
#include <fastdds/dds/core/policy/QosPolicies.hpp>
#include <iostream>
#include <string>

int main(int argc, char ** argv)
{
  using eprosima::fastrtps::xmlparser::XMLProfileManager;
  using eprosima::fastrtps::xmlparser::XMLP_ret;
  if (argc != 2 || XMLProfileManager::loadXMLFile(argv[1]) != XMLP_ret::XML_OK) {
    return 2;
  }
  std::cout << "{\"no_participant_or_endpoint_created\":true,\"profiles\":[";
  const char * robots[] = {"tb1", "tb2", "tb3"};
  const char * nodes[] = {"controller_server", "behavior_server", "velocity_smoother"};
  bool first = true;
  for (const auto * robot : robots) {
    for (const auto * node : nodes) {
      const std::string name = std::string("rr/") + robot + "/" + node + "/get_parametersReply";
      eprosima::fastrtps::PublisherAttributes attrs;
      XMLProfileManager::getDefaultPublisherAttributes(attrs);
      const auto found = XMLProfileManager::fillPublisherAttributes(name, attrs, false);
      const auto & duration = attrs.qos.m_reliability.max_blocking_time;
      if (!first) { std::cout << ','; }
      first = false;
      std::cout << "{\"name\":\"" << name << "\",\"exact_profile_found\":"
                << (found == XMLP_ret::XML_OK ? "true" : "false")
                << ",\"seconds\":" << duration.seconds << ",\"nanoseconds\":"
                << duration.nanosec << "}";
    }
  }
  eprosima::fastdds::dds::ReliabilityQosPolicy defaults;
  std::cout << "],\"library_default_max_blocking_seconds\":" << defaults.max_blocking_time.seconds
            << ",\"library_default_max_blocking_nanoseconds\":"
            << defaults.max_blocking_time.nanosec << "}\n";
  return 0;
}
