"""CPU only: pure isolated namespaces, old-equivalence and original snapshots."""
import ast
import itertools
import json
import math
from pathlib import Path
import unittest

ROOT = Path('/home/zhuyulab/ns3-workspace')
HERE = Path('/tmp/mr3_p2a0_v16_stimulus_v5_proposal')
NAMES = ('tb1', 'tb2', 'tb3')
SELECTORS = {'_probe_goal_order', 'probe_action', 'probe_action_v3', 'probe_action_v4',
             'probe_action_v5', '_probe_nonapproaching_goal_action', 'record_probe_v4_submission'}


def load_pure(path):
    namespace = {'math': math}
    definitions = [node for node in ast.parse(path.read_bytes()).body
                   if isinstance(node, ast.FunctionDef) and node.name in SELECTORS]
    exec(compile(ast.Module(body=definitions, type_ignores=[]), str(path), 'exec'), namespace)
    return namespace


OLD = load_pure(HERE / 'old_frozen_v4_benchmark.py')
NEW = load_pure(HERE / 'benchmark.py')
fixture_file = (ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
                'mr3_learning/tests/test_benchmark_stimulus_v4.py')
fixture_namespace = {'itertools': itertools, 'NAMES': NAMES}
fixture_defs = [node for node in ast.parse(fixture_file.read_bytes()).body
                if isinstance(node, ast.FunctionDef) and node.name in ('snapshot', 'result')]
exec(compile(ast.Module(body=fixture_defs, type_ignores=[]), str(fixture_file), 'exec'),
     fixture_namespace)
snapshot = fixture_namespace['snapshot']
result = fixture_namespace['result']


def recorded(version):
    episode = ROOT / ('ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/'
                      'mr3_p2a0_20261017_' + version + '_interface/worker0/episode001_open_101')
    path = episode / 'transitions.jsonl'
    return [json.loads(line) for line in path.read_bytes().splitlines()]


def prepared_second(selector='probe_action_v5'):
    diagnostics = {}
    first = snapshot(10., active=False)
    action = NEW[selector](first, diagnostics)
    NEW['record_probe_v4_submission'](diagnostics, result(first, action))
    start = snapshot(13., active=False)
    action = NEW[selector](start, diagnostics)
    NEW['record_probe_v4_submission'](diagnostics, result(start, action))
    return diagnostics


class StimulusV5Tests(unittest.TestCase):
    def test_v2_v3_and_submission_functions_ast_unchanged(self):
        old = ast.parse((HERE / 'old_frozen_v4_benchmark.py').read_bytes())
        new = ast.parse((HERE / 'benchmark.py').read_bytes())
        for name in ('_probe_goal_order', 'probe_action', 'probe_action_v3',
                     'record_probe_v4_submission'):
            a = next(n for n in old.body if isinstance(n, ast.FunctionDef) and n.name == name)
            b = next(n for n in new.body if isinstance(n, ast.FunctionDef) and n.name == name)
            self.assertEqual(ast.dump(a), ast.dump(b))

    def test_v4_default_actions_and_diagnostics_exact_for_both_actual_runs(self):
        for version in ('v14', 'v15'):
            with self.subTest(version=version):
                first, second = {}, {}
                for row in recorded(version)[:-1]:
                    snap = row['snapshot']
                    before = json.dumps(snap, sort_keys=True)
                    a = OLD['probe_action_v4'](snap, first)
                    b = NEW['probe_action_v4'](snap, second)
                    self.assertEqual(a, b)
                    self.assertEqual(first, second)
                    OLD['record_probe_v4_submission'](first, result(snap, a))
                    NEW['record_probe_v4_submission'](second, result(snap, b))
                    self.assertEqual(first, second)
                    self.assertEqual(json.dumps(snap, sort_keys=True), before)

    def test_v5_actual_t0_412_and_t13_321_without_input_or_global_changes(self):
        diagnostics = {}
        old_function = OLD['probe_action_v4']
        first_difference = None
        for row in recorded('v15'):
            snap = row['snapshot']
            if snap['task_elapsed_sec'] > 13.:
                break
            before = json.dumps(snap, sort_keys=True)
            chosen = NEW['probe_action_v5'](snap, diagnostics)
            if snap['task_elapsed_sec'] == 0.:
                self.assertEqual(chosen, 412)
            if snap['task_elapsed_sec'] == 13.:
                self.assertEqual(chosen, 321)
                first_difference = 13.
            self.assertTrue(snap['joint_action_mask'][chosen])
            self.assertTrue(NEW['_probe_nonapproaching_goal_action'](snap, chosen))
            NEW['record_probe_v4_submission'](diagnostics, result(snap, chosen))
            self.assertEqual(json.dumps(snap, sort_keys=True), before)
        self.assertEqual(first_difference, 13.)
        self.assertIs(OLD['probe_action_v4'], old_function)

    def test_toward_goal_is_filtered_and_v4_default_still_selects_it(self):
        snap = snapshot(0., active=False)
        snap['candidates'][0].update(x=0., y=1.)
        snap['joint_action_mask'] = [index in (88, 888) for index in range(1000)]
        self.assertEqual(NEW['probe_action_v4'](snap, {}), 88)
        self.assertEqual(NEW['probe_action_v5'](snap, {}), 888)

    def test_nonapproach_subset_allows_two_goal_opportunity(self):
        snap = snapshot(0., active=False)
        for index, xy in enumerate(((0., 1.), (2., 0.), (2., 2.), (2., 4.))):
            snap['candidates'][index].update(x=xy[0], y=xy[1])
        snap['joint_action_mask'] = [index in (111, 128, 888) for index in range(1000)]
        self.assertEqual(NEW['probe_action_v4'](snap, {}), 111)
        self.assertEqual(NEW['probe_action_v5'](snap, {}), 128)

    def test_zero_margin_is_allowed_and_negative_not_rounded_up(self):
        snap = snapshot(0., active=False)
        snap['candidates'][0].update(x=2., y=0.)
        self.assertTrue(NEW['_probe_nonapproaching_goal_action'](snap, 88))
        snap['candidates'][0]['y'] = 1e-15
        self.assertFalse(NEW['_probe_nonapproaching_goal_action'](snap, 88))

    def test_unknown_stale_invalid_or_nonfinite_peer_disables_new_goal_only(self):
        for key, value in (('fresh', False), ('valid', False), ('x', float('nan')),
                           ('y', True), ('x', float('inf'))):
            with self.subTest(key=key, value=value):
                snap = snapshot(0., active=False)
                snap['robots'][2][key] = value
                snap['joint_action_mask'] = [index in (88, 888, 999) for index in range(1000)]
                self.assertFalse(NEW['_probe_nonapproaching_goal_action'](snap, 88))
                self.assertTrue(NEW['_probe_nonapproaching_goal_action'](snap, 888))
                self.assertTrue(NEW['_probe_nonapproaching_goal_action'](snap, 999))
                self.assertEqual(NEW['probe_action_v5'](snap, {}), 888)

    def test_nonfinite_goal_zero_length_and_coincident_peer_rejected(self):
        for fault in ('nan', 'bool', 'zero_length', 'coincident_peer'):
            snap = snapshot(0., active=False)
            if fault == 'nan':
                snap['candidates'][0]['x'] = float('nan')
            elif fault == 'bool':
                snap['candidates'][0]['x'] = True
            elif fault == 'zero_length':
                snap['candidates'][0].update(x=snap['robots'][0]['x'], y=snap['robots'][0]['y'])
            else:
                snap['robots'][1].update(x=snap['robots'][0]['x'], y=snap['robots'][0]['y'])
            with self.subTest(fault=fault):
                self.assertFalse(NEW['_probe_nonapproaching_goal_action'](snap, 88))

    def test_false_joint_goal_and_five_second_wait_masks_never_overridden(self):
        snap = snapshot(0., active=False)
        snap['joint_action_mask'] = [index == 888 for index in range(1000)]
        self.assertEqual(NEW['probe_action_v5'](snap, {}), 888)
        diagnostics = prepared_second()
        snap = snapshot(15., speed=.2, path=.4, waiting=False)
        self.assertEqual(NEW['probe_action_v5'](snap, diagnostics), 888)
        NEW['record_probe_v4_submission'](diagnostics, result(snap, 888))
        self.assertFalse(diagnostics['v4_stimulus']['rounds']['second']['waits'])

    def test_explicit_false_flag_does_not_latch_and_wrong_types_fail(self):
        for flag in (False, 0, None):
            diagnostics = prepared_second()
            snap = snapshot(19., speed=.2, path=1.)
            action = NEW['probe_action_v5'](snap, diagnostics)
            self.assertEqual(action, 999)
            if flag is False:
                receipt = result(snap, action, action_submitted=flag)
                NEW['record_probe_v4_submission'](diagnostics, receipt)
            else:
                with self.assertRaises(ValueError):
                    receipt = result(snap, action, action_submitted=flag)
                    NEW['record_probe_v4_submission'](diagnostics, receipt)
            self.assertFalse(diagnostics['v4_stimulus']['rounds']['second']['waits'])

    def test_three_second_hold_and_initial_wait_are_still_required(self):
        self.assertEqual(NEW['probe_action_v5'](snapshot(13., active=False), {}), 888)
        diagnostics = {}
        first = snapshot(11., active=False)
        action = NEW['probe_action_v5'](first, diagnostics)
        NEW['record_probe_v4_submission'](diagnostics, result(first, action))
        early = snapshot(13., active=False)
        action = NEW['probe_action_v5'](early, diagnostics)
        self.assertEqual(action, 888)
        NEW['record_probe_v4_submission'](diagnostics, result(early, action))
        ready = snapshot(14., active=False)
        self.assertNotEqual(NEW['probe_action_v5'](ready, diagnostics), 888)

    def test_no_global_monkeypatch_and_two_versions_are_independent(self):
        old_state, new_state = {}, {}
        snap = snapshot(0., active=False)
        snap['candidates'][0].update(x=0., y=1.)
        snap['joint_action_mask'] = [index in (88, 888) for index in range(1000)]
        before = dict(NEW)
        a = NEW['probe_action_v4'](snap, old_state)
        b = NEW['probe_action_v5'](snap, new_state)
        self.assertEqual((a, b), (88, 888))
        self.assertEqual(before, NEW)
        self.assertNotIn('new_goal_filter', old_state['v4_stimulus']['pending_submission'])
        self.assertEqual(new_state['v4_stimulus']['pending_submission']['new_goal_filter'],
                         'received_straight_nonapproach_v1')


if __name__ == '__main__':
    unittest.main(verbosity=2)
