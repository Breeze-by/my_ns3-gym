"""Narrow sensor-identity red/green and six focused stdlib tests; no native."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import time
import test_ray_coordinator as fixtures

D=Path(__file__).parent;OLD=Path('/tmp/mr3_p2a0_v21_ray_proposal_v2')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
parent=D/'mr3_p2a0_v21_ray_run_v1.py';test=D/'test_ray_coordinator.py';planpath=D/'predeclared_plan_v21_ray.json'
plan=json.loads(planpath.read_bytes())
for binding in plan['independent_source_bindings']:
    if binding['path'].endswith('/mr3_p2a0_v21_ray_run_v1.py'):binding['sha256']=sha(parent.read_bytes())
    if binding['path'].endswith('/test_ray_coordinator.py'):binding['sha256']=sha(test.read_bytes())
planpath.write_text(json.dumps(plan,indent=2)+'\n')
source_sha={str(p):sha(p.read_bytes()) for p in (parent,test,D/'ray_availability_function.py')}
start=time.monotonic();command=['/usr/bin/python3','-B',str(test),'-v'];result=subprocess.run(command,capture_output=True)
(D/'sensor_identity_checks_v2.stdout.log').write_bytes(result.stdout);(D/'sensor_identity_checks_v2.stderr.log').write_bytes(result.stderr)
wall=time.monotonic()-start
spec=importlib.util.spec_from_file_location('old8619',OLD/'mr3_p2a0_v21_ray_run_v1.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
case=fixtures.RayCoordinator();case.setUp()
try:
    expected=case.write_streams();path=case.directory/'ray_tb2.jsonl';rows=[json.loads(line) for line in path.read_bytes().splitlines()]
    rows[1]['sensor_parent']='tb1::base_scan'
    raw=b''.join((json.dumps(row)+'\n').encode() for row in rows);path.write_bytes(raw)
    previous=old.ray_availability(case.directory,'CPU_epoch',expected)
    corrected=case.parent.ray_availability(case.directory,'CPU_epoch',expected)
    assert previous['passed'] is True and corrected['passed'] is False
    redgreen={'old_source_sha256':sha((OLD/'mr3_p2a0_v21_ray_run_v1.py').read_bytes()),
              'old_passed':previous['passed'],'new_passed':corrected['passed'],'mutation':'Only tb2 connected.sensor_parent replaced tb1::base_scan',
              'full_stream_sha256':sha(raw),'new_report':corrected['robots']['tb2']}
finally:case.doCleanups()
def functions(path):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef)}
a=functions(OLD/parent.name);b=functions(parent);changed=[n for n in a if a[n]!=b[n]]
assert changed==['ray_availability','execute_capture']
assert all(sha(Path(p).read_bytes())==v for p,v in source_sha.items())
for p in (parent,test):compile(p.read_bytes(),str(p),'exec')
output={'passed':result.returncode==0,'argv':command,'exit_code':result.returncode,'wall_seconds':wall,
        'focused_methods':6,'scope':'Sensor identity correction only; no old14 retest/SDK/DDS/ROS/Gazebo/native.',
        'source_sha256':source_sha,'source_stable':True,'old8619_preserved':True,'red_green':redgreen,
        'AST_changed_functions':changed,'other_functions_AST_unchanged':True,'python_compile':True,
        'stdout':str(D/'sensor_identity_checks_v2.stdout.log'),'stderr':str(D/'sensor_identity_checks_v2.stderr.log')}
(D/'checks_sensor_identity_v2.json').write_text(json.dumps(output,indent=2)+'\n')
print(result.stderr.decode());print(json.dumps({'passed':output['passed'],'wall_seconds':wall,'source':source_sha}))
if not output['passed']:raise SystemExit(1)
