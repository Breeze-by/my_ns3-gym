import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

A = Path(__file__).parent
P = Path('/home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration')
OUT = A/'record_cpu_v1'
OUT.mkdir(exist_ok=False)

def identity(pid):
    fields = Path('/proc', str(pid), 'stat').read_text().rsplit(')', 1)[1].split()
    return dict(pid=pid, start_ticks=int(fields[19]))

def sources():
    files = sorted(set(P.joinpath('multi_robot_exploration').glob('*.py')) | set(P.joinpath('test').glob('*reach*.py')) | set(A.glob('*.py')) | set(A.joinpath('multi_robot_exploration').glob('*.py')))
    rows=[]
    for path in files:
        raw=path.read_bytes(); stat=path.stat()
        rows.append(dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),stat=[stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns]))
    return rows

owner=identity(os.getpid())
before=sources()
(OUT/'source_before.json').write_text(json.dumps(before,indent=2)+'\n')
snap=OUT/'source_snapshots';snap.mkdir()
for i,row in enumerate(before):
    (snap/f'{i:03d}_{row["sha256"]}_{Path(row["path"]).name}').write_bytes(Path(row['path']).read_bytes())
cmd=['/usr/bin/python3','-B','-m','pytest','-q','-p','no:cacheprovider',str(A/'test_record_equivalence.py'),f'--junitxml={OUT}/pytest.xml']
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','PYTHONPATH':str(A)+':'+str(P)+':'+str(P/'test')}
started=time.monotonic_ns()
with (OUT/'console.log').open('xb') as output:
    proc=subprocess.Popen(cmd,cwd=A,env=env,stdout=output,stderr=subprocess.STDOUT)
    child=identity(proc.pid)
    try:
        rc=proc.wait(timeout=120)
    except subprocess.TimeoutExpired:
        proc.terminate()
        try:rc=proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill();rc=proc.wait()
ended=time.monotonic_ns()
after=sources()
record=dict(actual_argv=cmd,actual_waited=True,returncode=rc,actual_child_wait_ns=ended-started,runner_identity=owner,child_identity=child,source_before=before,source_after=after,source_stable=before==after,engineering_added_seconds='0',no_world=True)
(OUT/'actual_wait.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['returncode','actual_child_wait_ns','source_stable']}))
raise SystemExit(0 if rc==0 and before==after else 1)
