# V25 closed-only selector handoff

This is a TMP source template, not an executed pack or a scientific receipt.
Root must first confirm all native children, submitted mandatory/formal children, parent and watcher naturally closed, and all selected diagnostic writers STOP. The helper independently requires final existing ledger/watcher and drained attempted-stage audit metadata; failed outcomes remain raw originals.

Future invocation (not executed):

```bash
env -i PATH=/usr/bin:/bin PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 LANG=C.UTF-8 LC_ALL=C.UTF-8 TZ=UTC /usr/bin/python3 -B /tmp/mr3_p2a0_v25_matrix_pack_proposal_v1/mr3_p2a0_v25_matrix_pack_closed_v1.py --freeze 579f7ad21d33c6de9351eb5308f155f0fc903fd7 --target /tmp/mr3_p2a0_v25_selected_closed_v1 --all-writers-closed
```

Append `--extra /tmp/EXACT_CLOSED_ORIGINAL` per root-selected existing file for global parent/watcher consoles, sourcepacks, actual preflight wrapper/execution, and non-stage-prefix diagnostics. Do not guess their final names or recursively select mutable continuation/active outputs. Stage-prefix originals and all existing native tree files are already selected; every existing stage is supported, later genuine skipped stages stay absent.

At future canonical copying, read each group manifest named by the top manifest. For each part select `GROUP / part.selected` and copy to `ROOT / part.prospective_canonical`, checking it equals `ROOT / manifest.prospective_prefix / part.selected`. Copy that group manifest to `ROOT / manifest.prospective_prefix / manifest.json`; copy the top manifest/helper configuration to A25/native/. Do not append a second native/interface directory and do not assume interface-only close. No copying is authorized or performed now.

The original six codec functions are byte-identical to V24: raw32MiB ordered chunks, 2 workers, deterministic gzip; every encoded part below100MB, all encoded/decoded/reassembled SHA and final fd/path/source inventory verified at future execution. Original gzip inputs remain original gzip bytes after this custody layer. No old codec tests, ROS, DDS, SDK, native, formal reader, active trace scan or canonical/Git mutation is performed.
