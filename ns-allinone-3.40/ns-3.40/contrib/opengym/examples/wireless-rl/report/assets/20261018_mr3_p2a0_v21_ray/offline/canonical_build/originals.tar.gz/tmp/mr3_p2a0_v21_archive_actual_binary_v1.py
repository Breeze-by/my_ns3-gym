import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/zhuyulab/ns3-workspace')
A = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v21_ray'
source = ROOT / 'ros2_ws/ros2-multi-robot-automap/install/multi_robot/lib/libmr3_ray_provenance_observer.so'
raw = source.read_bytes()
assert len(raw) == 463272
assert hashlib.sha256(raw).hexdigest() == 'b76138132ae7dbb35936c2e0971e909f688189d240de3910516157b3553d57b8'
encoded = gzip.compress(raw, compresslevel=6, mtime=0)
assert gzip.decompress(encoded) == raw
assert source.read_bytes() == raw
target = A / 'binary/libmr3_ray_provenance_observer.so.gz'
assert not target.exists()
target.parent.mkdir(parents=True, exist_ok=True)
target.write_bytes(encoded)
result = {'schema': 'mr3-v21-canonical-binary-custody-v1',
          'scope': 'Actual canonical colcon build installed library only. SDK TMP binary excluded.',
          'installed_source': str(source), 'resolved': str(source.resolve()),
          'source_cpp_sha256': '65b1c1db64861366811266580daf8cf43bcf565fc856a405f473b02bdefd082c',
          'canonical_cmake_sha256': '170eb49947c4daa61d30f45ab8fde637aa12766182dddfda15c9ca6453d0cc0d',
          'decoded_bytes': len(raw), 'decoded_sha256': hashlib.sha256(raw).hexdigest(),
          'archive': str(target.relative_to(ROOT)), 'encoded_bytes': len(encoded),
          'encoded_sha256': hashlib.sha256(encoded).hexdigest(), 'full_roundtrip_verified': True}
(A / 'binary/receipt_v1.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
