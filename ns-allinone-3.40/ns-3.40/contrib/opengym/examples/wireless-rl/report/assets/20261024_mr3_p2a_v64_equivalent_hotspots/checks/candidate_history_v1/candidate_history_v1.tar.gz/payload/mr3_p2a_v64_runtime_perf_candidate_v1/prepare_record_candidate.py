from pathlib import Path
import json,hashlib
A=Path(__file__).parent
source=Path('/home/zhuyulab/ns3-workspace/ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/multi_robot_exploration/motion_safety.py')
raw=source.read_bytes();text=raw.decode()
old='''        self.audit.write(json.dumps({
            "schema": "mr3-motion-safety-v1", "epoch": self.epoch,
            "record_sequence": self.record_sequence, "kind": kind,
            "sim_time_sec": self.now(), "wall_monotonic_ns": time.monotonic_ns(),
            "payload": finite_json(payload)}, allow_nan=False, separators=(",", ":")) + "\\n")'''
new='''        entry = {
            "schema": "mr3-motion-safety-v1", "epoch": self.epoch,
            "record_sequence": self.record_sequence, "kind": kind,
            "sim_time_sec": self.now(), "wall_monotonic_ns": time.monotonic_ns(),
            "payload": payload}
        try:
            encoded = json.dumps(entry, allow_nan=False, separators=(",", ":"))
        except ValueError:
            # Most records already contain finite JSON. Retain the original
            # sanitization for exceptional nonfinite payloads, without a full
            # tree copy before every successful strict encoding.
            entry["payload"] = finite_json(payload)
            encoded = json.dumps(entry, allow_nan=False, separators=(",", ":"))
        self.audit.write(encoded + "\\n")'''
assert text.count(old)==1
(A/'original_motion_safety.py').write_bytes(raw)
(A/'motion_safety.py').write_text(text.replace(old,new))
(A/'record_edit_v1.json').write_text(json.dumps(dict(source=str(source),source_sha256=hashlib.sha256(raw).hexdigest(),old=old,new=new,production_installed=False),indent=2)+'\n')
