"""Lossless sealed V23 source/CPU custody only; no native or canonical writes."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import sys
import tarfile
import time

B = Path('/tmp/mr3_p2a0_v23_entry_proposal_v1')
OUT = Path('/tmp/mr3_p2a0_v23_entry_offline_sealed_v1.tar.gz')
RECEIPT = Path('/tmp/mr3_p2a0_v23_entry_offline_custody_v1.json')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert not OUT.exists() and not RECEIPT.exists()
started = time.monotonic()
manifest = json.loads((B / 'manifest_final_v1.json').read_bytes())
items = []
for row in manifest['files']:
    path = Path(row['source'])
    raw = path.read_bytes()
    stat = path.stat()
    assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
    assert stat.st_size == row['stat']['size'] and stat.st_mtime_ns == row['stat']['mtime_ns']
    assert stat.st_ino == row['stat']['inode']
    items.append((path, 'proposal/' + row['relative_path'], raw, stat))
for path, name in [(B / 'manifest_final_v1.json', 'proposal/manifest_final_v1.json'),
                   (Path(__file__), 'pack_entry_offline_v1.py')]:
    items.append((path, name, path.read_bytes(), path.stat()))
assert len({name for _, name, _, _ in items}) == len(items)
with OUT.open('xb') as dest:
    with gzip.GzipFile(fileobj=dest, mode='wb', filename='', mtime=0) as encoded:
        with tarfile.open(fileobj=encoded, mode='w|') as archive:
            for path, name, raw, stat in items:
                assert not raw.startswith(b'\x7fELF') and '__pycache__' not in path.parts
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(raw), 0o644, stat.st_mtime
                archive.addfile(info, io.BytesIO(raw))
expected = {name: sha(raw) for _, name, raw, _ in items}
with tarfile.open(OUT, mode='r:gz') as archive:
    actual = {}
    for member in archive:
        assert member.isfile()
        actual[member.name] = sha(archive.extractfile(member).read())
assert actual == expected
rows = []
for path, name, raw, before in items:
    after = path.stat()
    assert (after.st_size, after.st_mtime_ns, after.st_ino) == (before.st_size, before.st_mtime_ns, before.st_ino)
    assert sha(path.read_bytes()) == sha(raw)
    rows.append({'source': str(path), 'archive_member': name, 'bytes': len(raw), 'sha256': sha(raw)})
result = {'schema': 'mr3-v23-entry-offline-custody-v1', 'passed': True,
          'argv': [sys.executable, *sys.argv], 'cwd': os.getcwd(),
          'source_sha256': sha(Path(__file__).read_bytes()),
          'archive': str(OUT), 'encoded_bytes': OUT.stat().st_size,
          'encoded_sha256': sha(OUT.read_bytes()), 'files': rows,
          'file_count': len(rows), 'raw_bytes': sum(row['bytes'] for row in rows),
          'roundtrip_all_members': True, 'source_final_stat_and_sha': True,
          'wall_seconds': time.monotonic() - started,
          'scope': 'TMP-only exact source/CPU originals and preserved failures. No native, simulator, DDS, model training or canonical publication. Launcher mock subprocesses are only fixtures.'}
with RECEIPT.open('x') as stream:
    stream.write(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'files'}))
