<nav2_rotation_shim_controller::RotationShimController::getSampledPathPt()@plt>:
    fd10:	f3 0f 1e fa          	endbr64 
    fd14:	f2 ff 25 3d 74 03 00 	bnd jmp *0x3743d(%rip)        # 47158 <nav2_rotation_shim_controller::RotationShimController::getSampledPathPt()@@Base+0x2d638>
    fd1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
