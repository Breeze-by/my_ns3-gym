"""Metadata/helper tests only. No native, formal CLI or canonical archive execution."""
import copy
import gzip
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

SPEC = importlib.util.spec_from_file_location(
    'archive_helper', '/tmp/mr3_p2a0_v13_archive_closed_v1.py')
H = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(H)


class FinalStateTests(unittest.TestCase):
    def setUp(self):
        H.FREEZE = 'a' * 40
        H.PLAN_SHA = 'b' * 64
        self.plan = {'stages': []}
        self.values = {}
        for stage in H.STAGES:
            spec = {'stage': stage, 'run_directory': '/fake/run/' + stage,
                    'required_audit_receipts': ['/fake/' + stage + '.json']}
            self.plan['stages'].append(spec)
            self.values[str(self.path(stage, 'launch.json'))] = dict(
                status='completed', freeze=H.FREEZE, plan_sha256=H.PLAN_SHA, passed=True)
            self.values[str(self.path(stage, 'audit_execution_v1.json'))] = dict(
                freeze=H.FREEZE, plan_sha256=H.PLAN_SHA, all_submitted_jobs_finished=True,
                passed=True, receipts=[dict(path=spec['required_audit_receipts'][0])])

    def path(self, stage, suffix):
        return H.TEMP / (H.PREFIX + '_' + stage + '_' + suffix)

    def load(self, path):
        return copy.deepcopy(self.values[str(path)])

    def exists(self, path):
        return str(path) in self.values

    def validate(self, mode='complete', stop=None):
        return H.validate_final_states(self.plan, mode, stop, self.load, self.exists)

    def stopped(self):
        for stage in H.STAGES[2:]:
            self.values.pop(str(self.path(stage, 'launch.json')))
            self.values.pop(str(self.path(stage, 'audit_execution_v1.json')))
        self.values[str(self.path('terminal', 'audit_execution_v1.json'))]['passed'] = False

    def test_complete_all_four(self):
        self.assertEqual([r['status'] for r in self.validate()], ['PASS'] * 4)

    def test_stopped_keeps_real_fail_and_skips(self):
        self.stopped()
        self.assertEqual([r['status'] for r in self.validate('stopped', 'terminal')],
                         ['PASS', 'FAIL', 'SKIPPED_after_terminal_failure',
                          'SKIPPED_after_terminal_failure'])

    def test_interface_failure_preserves_failed_launch_and_real_skips(self):
        for stage in H.STAGES[1:]:
            self.values.pop(str(self.path(stage, 'launch.json')))
            self.values.pop(str(self.path(stage, 'audit_execution_v1.json')))
        launch = self.values[str(self.path('interface', 'launch.json'))]
        launch.update(status='failed', passed=False)
        self.values[str(self.path('interface', 'audit_execution_v1.json'))]['passed'] = False
        result = self.validate('stopped', 'interface')
        self.assertEqual([r['status'] for r in result],
                         ['FAIL'] + ['SKIPPED_after_interface_failure'] * 3)
        self.assertEqual(result[0]['launch']['status'], 'failed')
        self.assertIs(result[0]['launch']['passed'], False)
        with self.assertRaises(AssertionError):
            self.validate()

    def test_live_and_unfinished_jobs_rejected(self):
        for key, value in [('status', 'running'), ('passed', None)]:
            with self.subTest(key=key):
                original = self.values[str(self.path('reset', 'launch.json'))].copy()
                self.values[str(self.path('reset', 'launch.json'))][key] = value
                with self.assertRaises(AssertionError):
                    self.validate()
                self.values[str(self.path('reset', 'launch.json'))] = original
        self.values[str(self.path('reset', 'audit_execution_v1.json'))][
            'all_submitted_jobs_finished'] = False
        with self.assertRaises(AssertionError):
            self.validate()

    def test_failed_stage_never_complete(self):
        self.values[str(self.path('terminal', 'audit_execution_v1.json'))]['passed'] = False
        with self.assertRaises(AssertionError):
            self.validate()

    def test_earlier_fail_and_fake_stop_rejected(self):
        self.stopped()
        self.values[str(self.path('interface', 'launch.json'))]['passed'] = False
        with self.assertRaises(AssertionError):
            self.validate('stopped', 'terminal')
        self.values[str(self.path('interface', 'launch.json'))]['passed'] = True
        self.values[str(self.path('terminal', 'audit_execution_v1.json'))]['passed'] = True
        with self.assertRaises(AssertionError):
            self.validate('stopped', 'terminal')

    def test_later_run_receipt_or_pack_not_hidden(self):
        self.stopped()
        for path in [self.path('reset', 'launch.json'), Path('/fake/run/reset'),
                     H.TEMP / (H.PREFIX + '_selected_native/reset')]:
            with self.subTest(path=str(path)):
                self.values[str(path)] = {}
                with self.assertRaises(AssertionError):
                    self.validate('stopped', 'terminal')
                self.values.pop(str(path))

    def test_freeze_plan_and_exact_mandatory_set_rejected(self):
        for key in ['freeze', 'plan_sha256', 'receipts']:
            original = self.values[str(self.path('reset', 'audit_execution_v1.json'))].copy()
            self.values[str(self.path('reset', 'audit_execution_v1.json'))][key] = (
                [] if key == 'receipts' else 'bad')
            with self.assertRaises(AssertionError):
                self.validate()
            self.values[str(self.path('reset', 'audit_execution_v1.json'))] = original

    def test_safe_paths_and_exclusive_outputs(self):
        for value in ('../escape', '/absolute'):
            with self.assertRaises(ValueError):
                H.safe_relative(value)
        with tempfile.TemporaryDirectory(prefix='mr3_v13_archive_metadata_test_') as tmp:
            path = Path(tmp) / 'new.json'
            H.new_json(path, {'original': True})
            with self.assertRaises(FileExistsError):
                H.new_json(path, {'replacement': True})
            self.assertEqual(H.read(path), {'original': True})


class PreflightBindingTests(unittest.TestCase):
    def setUp(self):
        self.plan = dict(schema='mr3-p2a0-predeclaration-v13',
                         readiness=dict(status='ready', pending_bindings=[]),
                         stages=[dict(stage=stage) for stage in H.STAGES],
                         independent_source_bindings=[dict(path='actual/new.py', sha256='c' * 64)])
        self.raw = json.dumps(self.plan).encode()
        self.preflight = dict(passed=True, freeze='d' * 40, plan_sha256=H.sha(self.raw),
                              independent_source_bindings=self.plan['independent_source_bindings'])

    def test_actual_freeze_and_plan_are_dynamic(self):
        freeze, digest, plan = H.bind_preflight(self.preflight, self.raw, self.raw)
        self.assertEqual(freeze, 'd' * 40)
        self.assertEqual(digest, H.sha(self.raw))
        self.assertEqual(plan, self.plan)

    def test_bad_freeze_pass_source_or_independent_binding_rejected(self):
        for field, value in [('freeze', 'historical'), ('freeze', True), ('passed', False),
                             ('passed', 1), ('plan_sha256', '0' * 64),
                             ('independent_source_bindings', [])]:
            with self.subTest(field=field, value=value):
                bad = copy.deepcopy(self.preflight)
                bad[field] = value
                with self.assertRaises(AssertionError):
                    H.bind_preflight(bad, self.raw, self.raw)
        with self.assertRaises(AssertionError):
            H.bind_preflight(self.preflight, self.raw, self.raw + b' ')

    def test_pending_plan_cannot_be_used(self):
        self.plan['readiness']['pending_bindings'] = ['approval']
        raw = json.dumps(self.plan).encode()
        self.preflight['plan_sha256'] = H.sha(raw)
        with self.assertRaises(AssertionError):
            H.bind_preflight(self.preflight, raw, raw)


class DeduplicationTests(unittest.TestCase):
    def test_only_exact_canonical_raw_bytes_are_reused(self):
        with tempfile.TemporaryDirectory(prefix='mr3_v13_archive_dedup_test_') as tmp:
            root = Path(tmp)
            source, selected, manifest = root / 'raw.py', root / 'old.py.gz', root / 'manifest.json'
            raw = b'actual original bytes\n'
            selected.write_bytes(gzip.compress(raw, mtime=0))
            index = {str(source): [dict(selected=selected, raw_sha256=H.sha(raw),
                                        manifest=manifest)]}
            with patch.object(H, 'ROOT', root):
                found = H.canonical_duplicate(source, raw, index)
                self.assertEqual(found['canonical_path'], 'old.py.gz')
                self.assertIsNone(H.canonical_duplicate(source, raw + b'changed', index))
                selected.write_bytes(gzip.compress(raw + b'corrupted', mtime=0))
                with self.assertRaises(AssertionError):
                    H.canonical_duplicate(source, raw, index)


if __name__ == '__main__':
    unittest.main(verbosity=2)
