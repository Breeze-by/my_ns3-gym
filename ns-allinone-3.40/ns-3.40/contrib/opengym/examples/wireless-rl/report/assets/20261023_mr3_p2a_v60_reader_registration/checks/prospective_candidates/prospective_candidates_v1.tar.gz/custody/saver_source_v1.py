#!/usr/bin/env python3
"""Preserve the explicitly fixed, uninstalled P2A candidates as opaque bytes.

Invoke only after the coordinator has truly reaped the primary V60 archive.
This script neither launches candidates nor grants scientific/source credit.
It intentionally has no arbitrary input, extraction, deletion, or split mode.
"""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import tarfile
import time
import traceback


ROOT = Path('/home/zhuyulab/ns3-workspace')
DEST = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261023_mr3_p2a_v60_reader_registration/checks/prospective_candidates'
INPUTS = Path('/tmp/p2a60_prospective_candidate_inputs_v1.json')
SELF = Path('/tmp/p2a60_save_prospective_candidates_v1.py')
ROOTS = (
    '/tmp/mr3_p2a_v60_cancel_causality_static_v1',
    '/tmp/mr3_p2a_v61_original_path_v3_review',
    '/tmp/mr3_p2a_outward_cancel_probe_review_v1',
    '/tmp/mr3_p2a_outward_cancel_v2_shadow_v1',
    '/tmp/mr3_p2a_fixed_process_profile_candidate_v1',
    '/tmp/mr3_p2a_v60_policy_capacity_source_review_v1',
    '/tmp/mr3_p2a_same_activity_audit_reuse_source_review_v1',
    '/tmp/mr3_p2a_exact_seed_materialization_shadow_v1',
    '/tmp/mr3_p2a_v61_run_cancel_forensics_draft_v1.py',
    '/tmp/mr3_p2a_v61_cancel_scope_pending_v1.json',
    '/tmp/mr3_p2a_v61_cancel_parent_draft_v1.md',
    '/tmp/mr3_p2a_v61_cancel_parent_draft_v2.md',
    '/tmp/mr3_p2a_v61_cancel_parent_manifest_v1.json',
    '/tmp/mr3_p2a_v60_documentation_templates_v2.md',
)
FIELDS = ('st_dev', 'st_ino', 'st_mode', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
CHUNK = 1024 * 1024


def fingerprint(s):
    return {k: getattr(s, k) for k in FIELDS}


def canonical_parents(p):
    if not p.is_absolute() or p.parent.resolve(strict=True) != p.parent:
        raise ValueError(f'noncanonical/symlink parent: {p}')


def snapshot():
    result = {}
    for root in ROOTS:
        pending = [Path(root)]
        while pending:
            p = pending.pop()
            canonical_parents(p)
            s = p.lstat()
            row = {'original_path': str(p), 'lstat': fingerprint(s)}
            if stat.S_ISLNK(s.st_mode):
                literal = os.readlink(p)
                literal_bytes = os.fsencode(literal)
                row.update(kind='symlink', literal_target=literal,
                           literal_target_bytes=len(literal_bytes),
                           literal_target_sha256=hashlib.sha256(literal_bytes).hexdigest())
                if fingerprint(p.lstat()) != row['lstat']:
                    raise ValueError(f'link changed during lstat/readlink: {p}')
            elif stat.S_ISREG(s.st_mode):
                row.update(kind='regular', bytes=s.st_size)
            elif stat.S_ISDIR(s.st_mode):
                row['kind'] = 'directory'
                with os.scandir(p) as children:
                    pending.extend(Path(e.path) for e in children)
            else:
                raise ValueError(f'unsupported special input retained at source: {p}')
            if str(p) in result:
                raise ValueError(f'overlapping/duplicate input: {p}')
            result[str(p)] = row
    return dict(sorted(result.items()))


def opened(p, expected):
    canonical_parents(p)
    fd = os.open(p, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode) or fingerprint(os.fstat(fd)) != expected:
            raise ValueError(f'opened source differs from lstat: {p}')
        return os.fdopen(fd, 'rb')
    except BaseException:
        os.close(fd)
        raise


class HashingReader:
    def __init__(self, stream):
        self.stream = stream
        self.digest = hashlib.sha256()
        self.count = 0

    def read(self, n=-1):
        data = self.stream.read(n)
        self.digest.update(data)
        self.count += len(data)
        return data


def hash_stream(f):
    h = hashlib.sha256()
    count = 0
    while True:
        data = f.read(CHUNK)
        if not data:
            return count, h.hexdigest()
        h.update(data)
        count += len(data)


def safe_member(name):
    q = PurePosixPath(name)
    if not name or q.is_absolute() or str(q) != name or any(x in ('', '.', '..') for x in q.parts) or '\x00' in name:
        raise ValueError(f'unsafe archive member: {name!r}')
    return name


def member_for(p):
    return safe_member('payload/' + str(p).lstrip('/'))


def tarinfo(name, size, mode, directory=False):
    t = tarfile.TarInfo(safe_member(name))
    t.size = size
    t.mode = stat.S_IMODE(mode)
    t.mtime = 0
    t.uid = t.gid = 0
    t.uname = t.gname = ''
    if directory:
        t.type = tarfile.DIRTYPE
    return t


def json_write(path, value):
    data = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    with path.open('xb') as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())


def regular_copy(tar, p, row, name):
    with opened(p, row['lstat']) as f:
        reader = HashingReader(f)
        tar.addfile(tarinfo(name, row['bytes'], row['lstat']['st_mode']), reader)
        if reader.read(1) or reader.count != row['bytes']:
            raise ValueError(f'source length changed: {p}')
        if fingerprint(os.fstat(f.fileno())) != row['lstat'] or fingerprint(p.lstat()) != row['lstat']:
            raise ValueError(f'source stat changed while archiving: {p}')
    return {**row, 'archive_member': name, 'sha256': reader.digest.hexdigest()}


def main():
    start = time.monotonic_ns()
    if Path(__file__).absolute() != SELF:
        raise ValueError('invoke the fixed saver source path')
    spec_stat = fingerprint(INPUTS.lstat())
    with opened(INPUTS, spec_stat) as f:
        spec_bytes = f.read()
    spec = json.loads(spec_bytes)
    if spec.get('schema') != 'mr3-v60-prospective-candidate-fixed-inputs-v1' or spec.get('roots') != list(ROOTS):
        raise ValueError('fixed input specification mismatch')
    before = snapshot()
    totals = {k: sum(r['kind'] == k for r in before.values()) for k in ('regular', 'directory', 'symlink')}
    totals['regular_bytes'] = sum(r.get('bytes', 0) for r in before.values())
    expected = spec['preparation_lstat_only']
    if (totals['regular'], totals['regular_bytes'], totals['directory'], totals['symlink']) != (expected['regular_count'], expected['regular_bytes'], expected['directory_count'], expected['symlink_count']):
        raise ValueError(f'candidate membership/size counts changed since preparation: {totals}')
    source_stat = fingerprint(SELF.lstat())
    custody = [
        (SELF, {'original_path': str(SELF), 'kind': 'regular', 'lstat': source_stat, 'bytes': source_stat['st_size']}, 'custody/saver_source_v1.py'),
        (INPUTS, {'original_path': str(INPUTS), 'kind': 'regular', 'lstat': spec_stat, 'bytes': len(spec_bytes)}, 'custody/fixed_inputs_v1.json'),
    ]
    canonical_parents(DEST)
    DEST.mkdir(exist_ok=False)
    archive = DEST / 'prospective_candidates_v1.tar.gz'
    complete = []
    manifest = {
        'schema': 'mr3-v60-prospective-candidate-opaque-manifest-v1',
        'passed': False,
        'candidate_status': 'not installed; byte preservation only; zero scientific credit',
        'root_inputs': list(ROOTS),
        'source_originals_removed': False,
        'automatic_split': False,
        'archive': str(archive),
        'pre_source_totals': totals,
        'input_payload_read_scope': 'One full source copy/hash plus one full source rehash after all tar writers close. Archive verification streams the gzip tar; no extraction/execution.',
        'symlink_policy': 'Only lstat/readlink literal metadata; never followed; no symlink/hardlink archive headers.',
        'archive_format': 'gzip level6 mtime0 containing PAX tar; all logical member names checked as relative traversal-free paths',
        'source_entries': complete,
    }
    try:
        with archive.open('xb') as raw:
            with gzip.GzipFile(filename='', mode='wb', fileobj=raw, compresslevel=6, mtime=0) as gz:
                with tarfile.open(fileobj=gz, mode='w|', format=tarfile.PAX_FORMAT) as tar:
                    for pstr, row in before.items():
                        p = Path(pstr)
                        if row['kind'] == 'regular':
                            complete.append(regular_copy(tar, p, row, member_for(p)))
                        elif row['kind'] == 'directory':
                            name = member_for(p)
                            tar.addfile(tarinfo(name, 0, row['lstat']['st_mode'], directory=True))
                            complete.append({**row, 'archive_member': name})
                        else:
                            complete.append({**row, 'archive_member': None})
                    for p, row, name in custody:
                        complete.append(regular_copy(tar, p, row, name))
                    links = [r for r in complete if r['kind'] == 'symlink']
                    data = (json.dumps(links, indent=2, sort_keys=True) + '\n').encode()
                    tar.addfile(tarinfo('custody/literal_symlinks_v1.json', len(data), 0o100644), io.BytesIO(data))
                    generated = {'archive_member': 'custody/literal_symlinks_v1.json', 'kind': 'regular', 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'generated_metadata': True}
            raw.flush()
            os.fsync(raw.fileno())
        if snapshot() != before:
            raise ValueError('candidate tree membership/stable stat/link literal changed')
        for row in complete:
            if row['kind'] != 'regular':
                continue
            p = Path(row['original_path'])
            with opened(p, row['lstat']) as f:
                size, digest = hash_stream(f)
                if fingerprint(os.fstat(f.fileno())) != row['lstat']:
                    raise ValueError(f'post-hash source stat drift: {p}')
            if fingerprint(p.lstat()) != row['lstat'] or (size, digest) != (row['bytes'], row['sha256']):
                raise ValueError(f'post-source byte/stat mismatch: {p}')
        if snapshot() != before:
            raise ValueError('candidate tree changed during final byte verification')
        expected_members = {r['archive_member']: r for r in complete if r['archive_member'] is not None}
        expected_members[generated['archive_member']] = generated
        seen = set()
        verified_regular = verified_bytes = 0
        with gzip.open(archive, 'rb') as gz:
            with tarfile.open(fileobj=gz, mode='r|') as tar:
                for member in tar:
                    name = safe_member(member.name.rstrip('/') if member.isdir() else member.name)
                    if name in seen or name not in expected_members:
                        raise ValueError(f'unexpected/duplicate archive member: {name}')
                    seen.add(name)
                    row = expected_members[name]
                    if row['kind'] == 'directory':
                        if not member.isdir() or member.size != 0:
                            raise ValueError(f'archive directory mismatch: {name}')
                        continue
                    if not member.isreg() or member.size != row['bytes']:
                        raise ValueError(f'archive regular/header mismatch: {name}')
                    stream = tar.extractfile(member)
                    if stream is None:
                        raise ValueError(f'missing archive regular stream: {name}')
                    with stream:
                        size, digest = hash_stream(stream)
                    if (size, digest) != (row['bytes'], row['sha256']):
                        raise ValueError(f'archive restored byte mismatch: {name}')
                    verified_regular += 1
                    verified_bytes += size
            while gz.read(CHUNK):
                pass  # Reach gzip EOF so its complete decoding/CRC is checked.
        if seen != set(expected_members):
            raise ValueError('archive is missing expected members')
        with archive.open('rb') as f:
            archive_bytes, archive_sha = hash_stream(f)
        if archive_bytes > 64 * 1024 * 1024:
            raise ValueError('actual archive exceeds 64MiB: retained intact; coordinator must decide disposition; no automatic split')
        manifest.update(passed=True, source_before_after_exact=True,
                        archive_regular_restore_verified=True,
                        archive_bytes=archive_bytes, archive_sha256=archive_sha,
                        verified_regular_count=verified_regular,
                        verified_regular_bytes=verified_bytes,
                        generated_metadata=[generated],
                        elapsed_monotonic_ns=time.monotonic_ns() - start)
        json_write(DEST / 'manifest_v1.json', manifest)
        print(json.dumps({'passed': True, 'archive_bytes': archive_bytes, 'archive_sha256': archive_sha, 'candidate_regular_count': totals['regular'], 'candidate_regular_bytes': totals['regular_bytes'], 'manifest': str(DEST / 'manifest_v1.json')}))
        return 0
    except BaseException as exc:
        manifest.update(error_type=type(exc).__name__, error=str(exc), traceback=traceback.format_exc(), elapsed_monotonic_ns=time.monotonic_ns() - start,
                        partial_archive_retained=archive.exists(), partials_and_sources_never_deleted=True)
        try:
            json_write(DEST / 'failed_manifest_v1.json', manifest)
        except BaseException:
            traceback.print_exc()
        raise


if __name__ == '__main__':
    sys.exit(main())
