from pathlib import Path
import hashlib,json
root=Path('/home/zhuyulab/ns3-workspace');w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';a=w/'report/assets/20261017_mr3_p2a0_v11';ind=a/'independent';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=a/'predeclared_plan_v11.json';d=json.loads(p.read_text())
base=json.loads((w/'report/assets/20261017_mr3_p2a0_v10/predeclared_plan_v10.json').read_text())
bindings={b['path']:{'path':b['path'],'sha256':sha(root/b['path'])} for b in base['independent_source_bindings']}
changed=[b['path'] for b in base['independent_source_bindings'] if b['sha256']!=bindings[b['path']]['sha256']]
assert changed==[str((w/'mr3_learning/audit_ppo.py').relative_to(root))],changed
for f in [*sorted(ind.glob('*.py')), w/'mr3_learning/audit_protocol.py']:bindings[str(f.relative_to(root))]={'path':str(f.relative_to(root)),'sha256':sha(f)}
d['independent_source_bindings']=list(bindings.values())
core=ind/'mr3_independent_control_phase_v2.py';tests=ind/'mr3_independent_control_phase_v2_tests.py';assert core.is_file() and tests.is_file()
d['controlled_execution_audit'].update(consumer_sha256=sha(core),tests_sha256=sha(tests),consumer_path=str(core.relative_to(root)),status='ready')
d['audit_orchestration']['script']=str((ind/'mr3_p2a0_v11_audit_stage.py').relative_to(root))
d['historical_bindings_scope']='Prior v10 sourceplan59 remains immutable. V11 keeps58 exact plus repins audit_ppo two actual runtime-source hashes; adds new coordinator/control-wrapper/check sources. Prior33 exact order/hashes retained.'
p.write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({'passed':True,'bindings':len(bindings),'plan_sha256':sha(p),'changed_prior_live_binding':changed}))
