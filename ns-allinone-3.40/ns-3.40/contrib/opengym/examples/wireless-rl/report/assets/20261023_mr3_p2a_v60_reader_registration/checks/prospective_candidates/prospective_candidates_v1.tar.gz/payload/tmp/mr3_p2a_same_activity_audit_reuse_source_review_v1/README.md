# 同活动 exact-seed 重复审计：源码可行性结论

基准 E：`935b466bd076002afdfe161b55a508938de2a8b0`。本次只读源码与 Git 元数据，未读活动结果或科学原件，未调用 reader/native，未修改仓库。下列均为下一显式版本设计，不给当前 E 追加信用。

可行的最小范围是：同一活动、同一 episode 的 `input_00x` 已实际完成后，full 引用其 `audit_seed_inputs.audit_episode` 的完整判定。full 自己仍实际执行，原 `audit_archives` 与其余所有判据照常运行，30 必要角色和最终合取不变。当前 full 的 `exact_archives` 先运行原 archive gate，再以 system Python 重做同一 full-snapshot/seven-map 判定；reset 的八个输入叶因而存在明确重复。terminal/deadline/PPO 没有相同上游叶时不能套用该依据。

当前 E 不能直接充当严格缓存：输入叶 argv 没有 `-B`，full 的子进程有 `-B`；Runner 仅移除 PYTHONPATH，full 还移除 PYTHONHOME；输出位置也不同。未来固定 profile 必须先统一解释器、`-B`、cwd 和 env，并把 output 明确列为仅结果落盘参数。不能称现有 argv/env 已字面相同。

下一最小设计

- profile 固定由 plan 传递，旧默认保持；仅支持 plan 内已知输入叶，不开放任意 report 路径或通用 reader cache。full 显式依赖同阶段输入叶完成，避免当前无依赖的重叠执行。
- 校验原结果与 receipt 的完整 SHA/bytes、原真实 rc/wait/argv、保存的 PID/start 与该叶子进程现已退出。同活动 coordinator 仍可存活；要求它先退出会使活动内引用死锁。引用写 `execution_kind=verified_same_activity_fact` 和 origin receipt，不捏造一个新子进程的等待或时间。
- 同活动/阶段/run/epoch/exact freeze、规则、几何前提、全部入口与依赖源码、Git pin、解释器/env/科学参数必须相同。seed 结果没有单独证明 Reach geometry 前提，full 仍须核实。
- 校验完整 encoded 原件原路径、SHA、bytes，且 plain/gzip 的选择不变。必须封存并复核 maps/snapshots 目录成员集合；只核已有 input_bindings 会漏掉新增未引用文件或新增优先 plain 文件。inode/mtime、当前源 freeze 或 owner gone 都不证明输入字节未变。
- 引用时仍需全字节 SHA 与目录成员校验；仅省去重复解压、JSON 与完整 snapshot 重建。未另证不可变存储之前，不能用 stat-only 命中。没有任何实际速度或容量保证。
- 声明有资格叶的阶段，缺叶、坏引用、不同源/参数/文件/失败结果全部 FAIL，不在内部悄悄重跑修复。PPO 等 plan 明确没有上游叶者标记 not-applicable，再按原真实 helper 路线执行。

其它重叠的边界

| 调用 | 源码事实 | 本候选处理 |
|---|---|---|
| cadence → runtime.audit_episode | 与 runtime 角色同函数，但 cadence 自身数学仍必要 | 不复用 |
| full → peer_control 与独立 FIFO | expected_freeze 参数当前不同；full 还连接 bootstrap/readiness | 不复用 |
| full 的 physics/readiness/execution_inputs | 已经共享 motion_cache | 不重复计算优化收益 |
| 原 audit_archives 与 exact-seed | 有共同文件和导航重建，但不是已证明的等价判据 | 原 archive gate 仍真实运行 |
| PPO 内多 reader | 多重合取且缺上游 exact-input 叶 | 维持原执行 |

必要的人工契约反例应覆盖 freeze/epoch/source/env/argv、原件修改、成员新增、plain/gzip 解析变化、错误 receipt、未知/仍存活 child、原 FAIL、循环依赖及默认旧行为；正例只证明引用机制，不证明新 native 或实际容量。

账目仍按真实完整 parent union 收费，原叶耗时不撤销，full 的引用校验费照收，不伪造 nested wait 或减费用。该优化不能修复真实 B 停车超限，也不替代约 31s/native-step 吞吐问题；pilot/final 前仍需实际含全部 reader/finalizer 的新 profile 容量证据。
