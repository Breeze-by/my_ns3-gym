#!/usr/bin/python3
"""One narrow stdlib fakeproc case; does not run author suite, ROS or subprocess."""
from pathlib import Path
import hashlib
import importlib.util
import json
import tempfile
import time

D = Path(__file__).parent
AUTHOR = Path('/tmp/mr3_p2a0_v25_smoother_custody_proposal_v1')


def bind(path):
    def ident(s):
        return [s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
    s=path.stat()
    raw=path.read_bytes()
    assert ident(s)==ident(path.stat())
    return {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'stat':ident(s)}


def main():
    start=time.monotonic()
    sources=[Path(__file__),AUTHOR/'test_smoother_custody_v1.py',AUTHOR/'mr3_v25_smoother_custody_v1.py',AUTHOR/'mr3_v25_stage_worker_bindings_v1.py']
    before=[bind(p) for p in sources]
    assert before[2]['sha256']=='e890f04f291e4eded65bb36507c7270291046467d420e4c0be9cd45286c21a70'
    spec=importlib.util.spec_from_file_location('v25_author_fixture_for_one_case',sources[1])
    fixture_module=importlib.util.module_from_spec(spec)
    exec(compile(sources[1].read_bytes(),str(sources[1]),'exec'),fixture_module.__dict__)
    results=[]
    for reused in (False,True):
        with tempfile.TemporaryDirectory(prefix='mr3_v25_z_identity_') as name:
            fixture=fixture_module.Fixture(Path(name))
            path=fixture.proc/'112/stat'
            original=path.read_bytes()
            changed=original.replace(b') S ',b') Z ')
            if reused:
                changed=changed.replace(b'1012',b'9999')
            path.write_bytes(changed)
            proof=fixture.observe()
            results.append({'reused':reused,'original_stat':original.decode(),'mutated_stat':changed.decode(),
                            'observer_passed':proof['passed'],'observer_errors':proof['errors'],
                            'episode_complete':proof['episodes'][0]['complete'],
                            'namespace_keys':list(proof['episodes'][0]['processes']),
                            'pending_reason':proof['episodes'][0].get('pending_reason')})
    assert results[0]['observer_passed'] is False and results[0]['observer_errors']==[]
    assert results[1]['observer_passed'] is False and results[1]['observer_errors']==[]
    after=[bind(p) for p in sources]
    assert before==after
    result={'schema':'mr3-v25-reused-z-classification-counterexample-v1','source_bindings':before,
            'results':results,'finding':'Sameidentity-Z correctly gets no credit; reused-start-Z is also silently pending because initialZcheck precedes paircheck. No incorrect active mapping credit, but observed reuse lacks promised sticky error.',
            'proposed_narrow_change':'ifNone pending; otherwise validate typedPID/start first; only matchingPID/start Z may pending. Do not swallow source/hash/permission errors.',
            'scope':'Two new narrow pure fakeproc cases only, reusing author fixture without running its18 methods. No actualproc/ROS/DDS/build/native. Sealed author source unmodified.',
            'source_before_after_stable':True,'wall_seconds':time.monotonic()-start}
    out=D/'reused_z_counterexample_v1.json'
    assert not out.exists()
    out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
                      'reused_Z_errors':results[1]['observer_errors'],'source_stable':True}))

if __name__=='__main__':
    main()
