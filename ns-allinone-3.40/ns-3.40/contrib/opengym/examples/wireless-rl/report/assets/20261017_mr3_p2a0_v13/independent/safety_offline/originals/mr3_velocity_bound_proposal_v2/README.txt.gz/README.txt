REVIEW-ONLY OFFLINE PARTIAL PROPOSAL. No tracked source changed; no ROS/native execution.
This v2 only tightens scalar speed nonnegativity over v1, retaining v1 source/failure fixtures.
valid_state scalar own/raw-required peer and MotionControlPhase negative-ACK branch are proposed; no raw-history activation/source-window latch is implemented.
Current worker has no same-T LIVE before normal commit(T); dependency_review_v1.json records actual order. Do not classify task membership from callback order or silently integrate a whole-commit reorder.
Suggested minimal scope is normal control model eligibility rejection; true task physical failure attribution needs actual evaluator release/end clipping. Explicit stop must remain usable for strict zero/storage cleanup.
Command caps/physical/task gates and actor/wire schemas are unchanged.
