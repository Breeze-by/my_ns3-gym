"""Read-only source review; no live process or native launch."""
import ast
import copy
import hashlib
import json
from pathlib import Path

ROOT = Path("/home/zhuyulab/ns3-workspace")
OLD = ROOT / ("ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/"
              "assets/20261018_mr3_p2a0_v18/independent/mr3_p2a0_v18_live_admission_v1.py")
NEW = Path("/tmp/mr3_p2a0_v19_witness_proposal_v1/proposed_live_admission_v1.py")
PATCH = NEW.parent / "review_only.patch"
inputs = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in (OLD, NEW, PATCH)}
a, b = ast.parse(OLD.read_text()), ast.parse(NEW.read_text())
fa = {node.name: node for node in a.body if isinstance(node, ast.FunctionDef)}
fb = {node.name: node for node in b.body if isinstance(node, ast.FunctionDef)}
same = [name for name in fa if name != "witness" and ast.dump(fa[name]) == ast.dump(fb[name])]
assert len(same) == len(fa) - 1
restored = copy.deepcopy(fb["witness"])
old_executable_check = next(node for node in fa["witness"].body
    if isinstance(node, ast.Expr) and "observer PID is not gzserver" in ast.unparse(node))
for index, node in enumerate(restored.body):
    if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name)
        and target.id == "executable_proof" for target in node.targets):
        restored.body[index] = copy.deepcopy(old_executable_check)
for node in ast.walk(restored):
    if isinstance(node, ast.Dict):
        pairs = [(key, value) for key, value in zip(node.keys, node.values)
            if not (isinstance(key, ast.Constant) and key.value == "executable"
                and isinstance(value, ast.Name) and value.id == "executable_proof")]
        node.keys, node.values = [v[0] for v in pairs], [v[1] for v in pairs]
assert ast.dump(restored) == ast.dump(fa["witness"])
assert inputs == {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in (OLD, NEW, PATCH)}
result = {"schema": "mr3-v19-witness-independent-review-v1", "review_only": True,
    "blocking_interface_issue_found": False, "inputs_before_after_unchanged": inputs,
    "unchanged_common_function_asts": same,
    "witness_ast_equal_after_exact_two_authorized_executable_changes": True,
    "observations": [
        "The old basename guard rejects the actual versioned ELF despite /usr/bin/gzserver samefile identity.",
        "New declaration strictly binds absolute path, resolved entity, ELF magic, actual bytes/SHA and typed positive byte count.",
        "The live /proc/PID/exe must be samefile with that predeclared entity and have the exact resolved path and SHA.",
        "Existing PID/start/ancestry before-after, actual library inode/device maps and library SHA checks remain unchanged.",
        "Package provenance is explicitly unavailable optional metadata, not an invented new mandatory gate.",
        "No claim that this prospective repair is a new V18 admission proof or native success."
    ], "limitations": ["Static source/AST review only; sibling's8 CPU tests were not rerun here.",
                       "No live DDS, process signals, simulator or Git/canonical mutation."]}
target = Path("/tmp/mr3_p2a0_v19_witness_independent_review_v1.json")
target.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
print(json.dumps({"review": str(target), "sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
                  "unchanged_functions": len(same)}))
