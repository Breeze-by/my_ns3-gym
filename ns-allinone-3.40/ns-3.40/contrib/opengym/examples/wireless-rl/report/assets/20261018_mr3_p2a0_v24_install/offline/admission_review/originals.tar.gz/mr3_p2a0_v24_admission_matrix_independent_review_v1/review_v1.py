"""Read-only final V24 source-identity and matrix review; no entrypoints/tests."""
import ast
import copy
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
S = Path('/tmp/mr3_p2a0_v24_source_admission_proposal_v1')
M = Path('/tmp/mr3_p2a0_v24_matrix_proposal_v1')
ADD = Path('/tmp/mr3_p2a0_v24_matrix_metadata_addendum_v2')
OUT = Path(__file__).parent
OLD = W / 'report/assets/20261018_mr3_p2a0_v23_entry'
INPUTS = {}
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def stat(path):
    value = path.stat()
    return [value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns]


def read(path):
    path = Path(path).absolute()
    before = stat(path)
    raw = path.read_bytes()
    assert stat(path) == before
    row = dict(path=str(path), bytes=len(raw), sha256=sha(raw), stat=before)
    assert str(path) not in INPUTS or INPUTS[str(path)] == row
    INPUTS[str(path)] = row
    return raw


def js(path):
    return json.loads(read(path))


def dump(node):
    return ast.dump(node, include_attributes=False)


def assigns(tree):
    return {node.targets[0].id: node for node in tree.body
            if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)}


began = time.monotonic()
handoff = js(M / 'handoff_final_v1.json')
addendum = js(ADD / 'handoff_final_v2.json')
plan_raw = read(ADD / 'predeclared_plan_v24.json')
plan = json.loads(plan_raw)
assert sha(plan_raw) == 'd682f40c01a660f598cdf6c81d9faa640c25af1ba87d9e96e56701bb2fec4ffc'
original_plan_raw = read(M / 'predeclared_plan_v24.json')
original_plan = json.loads(original_plan_raw)
assert sha(original_plan_raw) == '631d2412d4a224addee7028c1b2cc527ea1a63ff7f132cee3aba9d43f6888f61'
restored = copy.deepcopy(plan)
restored['native_ray_box_correction']['actual_library_sha256'] = original_plan['native_ray_box_correction']['actual_library_sha256']
assert restored == original_plan
assert plan['native_ray_box_correction']['actual_library_sha256'] == '782d388fea8df3646524e54f41d71de5f53480b9d04cc0ea1c453c70e2c1f7d8'
prospective = {str(Path(row['destination']).relative_to(ROOT)): Path(row['source'])
               for row in handoff['promotion_list']}
for row in handoff['promotion_list']:
    assert sha(read(row['source'])) == row['sha256']
old_plan = js(OLD / 'predeclared_plan_v23.json')
old_pins = {row['path']: row['sha256'] for row in old_plan['independent_source_bindings']}
pins = {row['path']: row['sha256'] for row in plan['independent_source_bindings']}
assert len(old_pins) == 198 and len(pins) == len(plan['independent_source_bindings']) == 210
changes = {row['path']: row for row in plan['historical_bindings_scope']['authorized_current_changes']}
assert len(changes) == 2
for path, expected in pins.items():
    assert sha(read(prospective.get(path, ROOT / path))) == expected, path
for path, expected in old_pins.items():
    if path in changes:
        assert changes[path]['before_sha256'] == expected and changes[path]['sha256'] == pins[path]
    else:
        assert pins[path] == expected
assert len(set(pins) - set(old_pins)) == 12
hard = ['robots_per_environment', 'max_api_records', 'max_submitted_script_decisions',
        'max_total_wall_seconds', 'pilot_budget_unchanged', 'unchanged_gates',
        'physical_response_criteria', 'angular_interface_criteria', 'angular_reset_criteria',
        'settled_turn_criteria', 'full_execution_model_failfast', 'api_budget_breakdown',
        'external_probe_v6', 'world_solver_candidate', 'production_environment']
assert all(plan[key] == old_plan[key] for key in hard)
assert [len(stage['required_audit_receipts']) for stage in plan['stages']] == [10, 7, 10, 7]
assert plan['native_admission_granted'] is False and plan['readiness']['status'] == 'ready'
assert plan['readiness']['pending_bindings'] == []
assert plan['prior_engineering_cost']['wall_seconds'] == 71.97839368507266
assert plan['prior_engineering_cost']['opening_remaining_wall_seconds'] == 17928.021606314927
assert plan['max_total_wall_seconds'] == 18000

baseline = read(S / 'baseline_auditor.py')
auditor = read(S / 'audit_ppo.proposed_v24_v2.py')
assert sha(baseline) == 'de297d83fd5436651e526fe9782ac0ebed02573ed9aa735a58d9fdcf613c0adf'
assert sha(auditor) == 'cc467064ab66e04507ed4d4e805a4e23cdf09b3716fd85517ebb34fe7b2de521'
assert read(W / 'mr3_learning/audit_ppo.py') == auditor
old_tree, new_tree = ast.parse(baseline), ast.parse(auditor)
old_assigns, new_assigns = assigns(old_tree), assigns(new_tree)
changed = [name for name in old_assigns if dump(old_assigns[name]) != dump(new_assigns[name])]
assert changed == ['ENV_DOCUMENT_SHA256', 'ENV_EXECUTION_APPENDIX_SHA256', 'ENV_EXECUTION_APPENDIX_BYTES',
                   'RAY_BOX_SOURCE_PINS', 'RAY_BOX_LIBRARY_SPEC']
inverse = copy.deepcopy(new_tree)
for node in inverse.body:
    if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name) and node.targets[0].id in changed:
        node.value = copy.deepcopy(old_assigns[node.targets[0].id].value)
assert dump(inverse) == dump(old_tree)
old_functions = {node.name: ast.get_source_segment(baseline.decode(), node) for node in old_tree.body
                 if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
new_functions = {node.name: ast.get_source_segment(auditor.decode(), node) for node in new_tree.body
                 if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
assert old_functions == new_functions
literal_body = [copy.deepcopy(node) for node in new_tree.body if isinstance(node, ast.Assign)]
assert not any(isinstance(node, ast.Call) for statement in literal_body for node in ast.walk(statement))
ns = {}
exec(compile(ast.Module(body=literal_body, type_ignores=[]), '<only static literals>', 'exec'), ns)
env = read(S / 'MR3_ENV_CONTRACT.proposed_pending_v4.md')
assert read(W / 'MR3_ENV_CONTRACT.md') == env
old_env = read(S / 'baseline_environment.md')
assert sha(old_env) == 'cace2f98cca4553f6cc618e7f43d7ead24451c7d802aac816583b74527eb5377'
assert env.startswith(old_env) and len(old_env) == 47721 and len(env) == 50061
assert sha(env) == ns['ENV_DOCUMENT_SHA256'] == 'f1e0be60d35db3677fb9194341c1ae4133a5c74ed7199056fe18f7e797f40416'
assert sha(env[:40186]) == ns['ENV_NORMATIVE_SHA256'] == '96d9bd3e3d597899b3d44a69ef9138e77b62b3641bd7261eb38846d5b003f155'
assert len(env[40186:]) == ns['ENV_EXECUTION_APPENDIX_BYTES'] == 9875
assert sha(env[40186:]) == ns['ENV_EXECUTION_APPENDIX_SHA256']
assert '具体失败\n分支未观测' in env.decode()
spec = ns['RAY_BOX_LIBRARY_SPEC']
for key in ('receipt', 'build', 'archive', 'library', 'ode_library'):
    entry = spec[key]
    raw = read(ROOT / entry['path'])
    assert len(raw) == entry['bytes'] and sha(raw) == entry['sha256']
    if 'resolved' in entry:
        assert (ROOT / entry['path']).resolve() == (ROOT / entry['resolved']).resolve()
library = read(ROOT / spec['library']['path'])
assert sha(library) == plan['native_ray_box_correction']['actual_library_sha256']
assert gzip.decompress(read(ROOT / spec['archive']['path'])) == library
receipt = js(ROOT / spec['receipt']['path'])
assert receipt['passed'] is True and receipt['old_four_libraries_byte_unchanged'] is True
for path, expected in ns['RAY_BOX_SOURCE_PINS'].items():
    assert sha(read(ROOT / path)) == expected and expected.encode() in library
    short = str(Path(path).relative_to(ns['ROS'] + 'src/multi_robot'))
    assert receipt['sources'][short]['sha256'] == expected
for entry in spec['unchanged_libraries'].values():
    assert sha(read(ROOT / entry['path'])) == entry['sha256']
binding = js(M / 'independent/mr3_v24_corrector_binding_v1.json')
assert binding['library'] == receipt['installed_library']
assert binding['ode_library'] == receipt['actual_ode_library']
assert binding['binary_receipt']['sha256'] == spec['receipt']['sha256']
phase_delta = js(S / 'custody_phase_delta_v2.json')
custody = read(M / 'independent/mr3_v24_corrector_custody_v3.py')
old_custody = read(S / 'baseline_custody.py')
assert sha(old_custody) == phase_delta['baseline_source_sha256']
assert sha(custody) == phase_delta['new_source_sha256'] == 'f65c9c68e6203c499b53d4b75f0ee4e41b256250aae014c783f69cd41af14ab3'
assert custody.decode().count(phase_delta['after']) == 1
assert custody.decode().replace(phase_delta['after'], phase_delta['before'], 1).encode() == old_custody
source_inverse = js(M / 'source_inverse_checks_v2.json')
assert source_inverse['passed'] is True
# Reconstruct exact inverse mechanically without executing any coordinator/helper.
source_checks = []
for row in source_inverse['sources']:
    path = Path(row['source'])
    raw = read(path)
    back = raw.decode()
    if 'launch_stage' in path.name:
        back = back.replace('PRIOR_ENGINEERING_WALL_SECONDS', 'PRIOR_ENTRY_WALL_SECONDS')
        back = back.replace('71.97839368507266', '0.24578428314998746')
        back = back.replace('"prior_engineering_cost"', '"prior_entry_cost"')
        back = back.replace('prior_engineering_wall_seconds=', 'prior_entry_wall_seconds=')
    if 'load_checked_corrector' in back:
        back = back.replace('    custody_asset = asset', "    legacy = asset.replace('20261018_mr3_p2a0_v24_install', '20261018_mr3_p2a0_v22_ray_box')")
        back = back.replace("relative = custody_asset + 'independent/mr3_v24_corrector_custody_v3.py'", "relative = legacy + 'independent/mr3_v22_corrector_custody_v2.py'")
        back = back.replace("binding = root / (custody_asset + 'independent/mr3_v24_corrector_binding_v1.json')", "binding = root / (legacy + 'independent/mr3_v22_corrector_binding_v1.json')")
    if 'buildproof_preflight' in path.name:
        back = back.replace('report/assets/20261018_mr3_p2a0_v24_install/independent/mr3_v24_corrector_custody_v3.py', 'report/assets/20261018_mr3_p2a0_v22_ray_box/independent/mr3_v22_corrector_custody_v2.py')
    if 'cross_stage_mapping' in path.name:
        prefix = "    asset = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/"
        back = back.replace(prefix + "20261018_mr3_p2a0_v24_install/independent'", prefix + "20261018_mr3_p2a0_v22_ray_box/independent'")
        back = back.replace("asset/'mr3_v24_corrector_custody_v3.py'", "asset/'mr3_v22_corrector_custody_v2.py'")
        back = back.replace("asset/'mr3_v24_corrector_binding_v1.json'", "asset/'mr3_v22_corrector_binding_v1.json'")
    back = back.replace('20261018_mr3_p2a0_v24_install', '20261018_mr3_p2a0_v23_entry').replace('v24', 'v23')
    original = read(row['normative'])
    assert back.encode() == original and sha(raw) == row['sha256'] and sha(original) == row['normative_sha256']
    source_checks.append(dict(path=str(path), sha256=sha(raw), whole_byte_inverse=True))
assert len(source_checks) == 6
for path, row in INPUTS.items():
    assert stat(Path(path)) == row['stat'] and sha(Path(path).read_bytes()) == row['sha256']
report = dict(schema='mr3-v24-final-admission-matrix-independent-review-v1', passed=True, blockers=[],
              final_plan_sha256=sha(plan_raw), auditor_sha256=sha(auditor), environment_sha256=sha(env),
              installed_library_sha256=sha(library), installed_library_bytes=len(library),
              old198_bindings_retained=True, old196_exact=True, authorized_changes=list(changes), new12=True, actual210=True,
              auditor_only_five_constants=changed, all_function_class_source_bytes_unchanged=True,
              whole_module_ast_inverse_exact_to_de297=True,
              environment=dict(old_cace_whole_prefix_exact=True, normative_96d9_prefix_exact=True, normative_bytes=40186,
                               appendix_bytes=9875, final_bytes=50061, unique_original_runtime_branch_not_claimed=True),
              fixed_actual_source_binary_receipts='f826/d556/c619 + actual782d + fixed3A24receipt/Git-worktree verifier unchanged; no caller-provided normative/newSHA or broad path override.',
              custody_only_installed_predicate_inverse_to862e=True,
              custody_semantics='Pinned phase/clock0, null unavailable preInit counter, all typed actual lookup/physics/nativeODE/loaded/sensor/failure-list fields; Running boolean descriptive only. Existing actual source/maps/PID/start/epoch/ancestry, 150/.001, closed lifecycle, callback errors and old34 unchanged.',
              original34_counts=[10, 7, 10, 7], hard_gate_fields_exact_to_A23=hard,
              budget=dict(max_total=18000, prior_debit=71.97839368507266, opening_remaining=17928.021606314927, api=608, decisions=596),
              six_coordinator_source_inverse=source_checks,
              execution_environment='A23 fixed-Conda learner executable guard/benchmark/full-audit path is preserved by exact source inverse; stdlib/system ROS separation unchanged.',
              corrected_plan_metadata=dict(old631d_preserved=True, only_active_SO_scalar_changed=True, final_active_SO_matches_binding_receipt_actual=True),
              all_input_final_sha_stat_stable=True, inputs=list(INPUTS.values()),
              source_native_admission=False,
              scope='Static source/AST/JSON/SHA/stat and archive byte review only. No unit/identity test, entrypoint/import/help probe, SDK, math, compiler, factory, native or formal rerun. Actual new clean pushed exact40 preflight and full matrix remain future.',
              wall_seconds=time.monotonic()-began)
report_path = OUT / 'review_v1.json'
with report_path.open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
files = [Path(__file__), report_path, OUT / 'initial_review_script_v1.py', OUT / 'initial_review_failure_v1.json']
manifest = dict(schema='mr3-v24-final-independent-review-custody-v1',
                files=[dict(path=str(path), member=str(path.relative_to('/tmp')), bytes=path.stat().st_size, sha256=sha(path.read_bytes())) for path in files],
                scope='Compact raw independent reviewer and result only; all cited original files remain in their author/canonical custody.', exclusions=[])
manifest_raw = (json.dumps(manifest, indent=2) + '\n').encode()
manifest_path = OUT / 'manifest_v1.json'
manifest_path.write_bytes(manifest_raw)
archive = OUT.parent / 'mr3_p2a0_v24_admission_matrix_review_sealed_v1.tar.gz'
with archive.open('xb') as target:
    with gzip.GzipFile(fileobj=target, filename='', mode='wb', mtime=0) as encoded:
        with tarfile.open(fileobj=encoded, mode='w') as tar:
            for path in [*files, manifest_path]:
                raw = path.read_bytes()
                info = tarfile.TarInfo(str(path.relative_to('/tmp')))
                info.size = len(raw)
                info.mtime = 0
                info.mode = 0o644
                tar.addfile(info, io.BytesIO(raw))
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(files) + 1
    for path in [*files, manifest_path]:
        assert tar.extractfile(str(path.relative_to('/tmp'))).read() == path.read_bytes()
handoff = dict(passed=True, review=str(report_path), review_sha256=sha(report_path.read_bytes()),
               manifest=str(manifest_path), manifest_sha256=sha(manifest_raw),
               archive=str(archive), archive_sha256=sha(archive.read_bytes()), archive_bytes=archive.stat().st_size,
               roundtrip_members=len(files) + 1, inputs=len(INPUTS), source_and_metadata_STOP=True)
(OUT / 'handoff_v1.json').write_text(json.dumps(handoff, indent=2) + '\n')
print(json.dumps(handoff))
