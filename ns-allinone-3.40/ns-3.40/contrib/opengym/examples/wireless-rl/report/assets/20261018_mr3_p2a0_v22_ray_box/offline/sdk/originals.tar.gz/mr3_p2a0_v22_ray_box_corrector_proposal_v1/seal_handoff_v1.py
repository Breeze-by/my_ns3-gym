#!/usr/bin/env python3
"""Seal only completed TMP proposal/CPU evidence, excluding CPU executables."""
import datetime
import hashlib
import json
import os
import pathlib
import sys
import tarfile
import time

P = pathlib.Path(__file__).parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def state(path):
    item = path.stat()
    return {key: getattr(item, key) for key in
            ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns')}


started = time.monotonic()
names = ['mr3_ray_box_corrector.cpp', 'mr3_ray_box_collision.cpp',
         'mr3_ray_box_collision.hpp']
source = {name: sha((P / name).read_bytes()) for name in names}
sdk = json.loads((P / 'plugin_build03_execution.json').read_text())
assert sdk['returncode'] == 0
assert sdk['source_sha'] == source == sdk['source_sha_after']
core = json.loads((P / 'probe05.stdout.json').read_text())
assert core['passed'] is True and core['named_cases'] == 36
assert core['deterministic_cases'] == 512 and core['invalid_primitive_rejections'] == 3
assert core['broadphase_original']['contacts'] == 1
assert core['broadphase_corrected']['contacts'] == 0
factory = json.loads((P / 'factory01.stdout').read_text())
assert factory == {'system_plugin_factory': True, 'load_called': False,
                   'init_called': False}
ldd = (P / 'ldd_r01.stdout').read_bytes() + (P / 'ldd_r01.stderr').read_bytes()
assert b'undefined symbol' not in ldd and b'not found' not in ldd
library = (P / 'libmr3_ray_box_corrector.so').read_bytes()
for digest in source.values():
    assert digest.encode() in library
sdk_library = {'path': str(P / 'libmr3_ray_box_corrector.so'),
               'sha256': sha(library), 'bytes': len(library),
               'scope': 'TMP SDK build only. It is not the canonical installed/native library.'}
ode_path = pathlib.Path('/lib/x86_64-linux-gnu/libgazebo_ode.so.11').resolve()
ode = ode_path.read_bytes()
production_paths = {
    'mr3_ray_box_corrector.cpp': 'ros2_ws/ros2-multi-robot-automap/src/multi_robot/src/mr3_ray_box_corrector.cpp',
    'mr3_ray_box_collision.cpp': 'ros2_ws/ros2-multi-robot-automap/src/multi_robot/src/mr3_ray_box_collision.cpp',
    'mr3_ray_box_collision.hpp': 'ros2_ws/ros2-multi-robot-automap/src/multi_robot/include/multi_robot/mr3_ray_box_collision.hpp'}
checks = {
    'schema': 'mr3-ray-box-corrector-author-checks-v1', 'passed': True,
    'scope': 'TMP source proposal, actual installed ODE synthetic CPU checks, SDK compilation, no-load/no-init factory and dependency resolution. No new Gazebo native run, ROS/DDS, canonical build or research PASS.',
    'source_sha256': source, 'prospective_production_paths': production_paths,
    'source_stopped': True,
    'core_probe': {'path': str(P / 'probe05.stdout.json'),
                   'sha256': sha((P / 'probe05.stdout.json').read_bytes()),
                   'named_cases_both_pair_orders': 36,
                   'deterministic_oriented_cases': 512,
                   'invalid_primitive_rejections': 3,
                   'grazing_entry_depth': .1000000013351432,
                   'finite_length_depth_normal_identity_checks': True,
                   'actual_simple_space_old_false_contact': 1,
                   'actual_simple_space_corrected_contacts': 0},
    'original_library_defect_checks': {
        'path': '/tmp/mr3_p2a0_v22_ray_box_cpu_reproduction_v1/checks_v1.json',
        'sha256': sha(pathlib.Path('/tmp/mr3_p2a0_v22_ray_box_cpu_reproduction_v1/checks_v1.json').read_bytes()),
        'cases': 15, 'false_positive_cases': 6},
    'actual_ode_library': {'path': str(ode_path), 'sha256': sha(ode),
                           'bytes': len(ode), 'direct_old_ray_box_export': False,
                           'public_override_export': True},
    'sdk_library': sdk_library,
    'sdk_compile': {'path': str(P / 'plugin_build03_execution.json'),
                    'sha256': sha((P / 'plugin_build03_execution.json').read_bytes()),
                    'source_before_after_equal': True},
    'factory': factory,
    'ldd_r': {'exit_code': 0, 'undefined_or_notfound': False},
    'registration_contract': {
        'pair': ['dRayClass', 'dBoxClass'], 'public_abi': 'dSetColliderOverride / dColliderFn',
        'register_once': True, 'world_created_after_ode_init': True,
        'required_before': 'world iteration/time zero and no model sensors',
        'global_scope': 'All ray/box pairs in this single server, not only own robot.',
        'lifetime': 'PluginT disables dlclose; process-global Runtime owner outlives plugin callbacks. Normal shutdown stops sensor/world threads before plugins.clear; independent source review records exact chain.',
        'baseline_scope_selected_by_root': 'Only stepped adapter launch automatically loads correction; existing baseline include branch stays unchanged.',
        'audit_path_env': 'MR3_RAY_BOX_CORRECTOR_AUDIT_PATH',
        'epoch_env': 'MR3_RAY_BOX_CORRECTOR_EPOCH'},
    'callback_contract': 'Normal callback uses public primitive getters, a complete exact-nonzero finite slab test, atomic counters and at most two immutable fixed packets. It does not cast, filter ranges, do JSON/I/O or run a legacy shadow. Invalid-input exceptions may allocate, are caught, counted, and cause failure at the next world boundary.',
    'ledger_schema': 'mr3-ray-box-corrector-audit-v1',
    'ledger_kinds': ['configuration', 'installed', 'first_actual_callback',
                     'first_outside_nearparallel_toward_slab',
                     'fatal_callback_input_error', 'plugin_destructor_snapshot',
                     'process_lifetime_summary'],
    'ledger_scope': 'First outside-nearparallel is descriptive and not required. It does not assert the old collider would hit; independent offline reconstruction may test that condition. No self-reported normal_close boolean replaces strict process closure.',
    'preserved_failures': [
        'Original reproduction SDK -I/-Werror build rejected pre-existing ode/misc.h declarations; source/compiler stderr/argv preserved in the reproduction directory.',
        'Correction probe01/02/03 failed only the new broadphase fixture assertion because its Euler pitch sign produced disjoint world AABBs. All named corrected math cases and random cases already agreed. Original sources and outputs remain. Probe04 fixed the synthetic orientation; probe05 adds finite validation/padding and invalid mutations.',
        'SystemPlugin SDK build01 failed because common::Time has no IntegerNanoSeconds(). Exact failed source retained; build02 uses integer sec/nsec. Final build03 additionally moves immutable world metadata before atomic pointer publication.'],
    'not_claimed': ['original V21 cast-time geom identity', 'old native failure erased',
                    'a physical/rest-bound repair', 'iters150 selected',
                    'new same-freeze matrix PASS', 'canonical native ELF identity'],
    'execution': {'argv': sys.argv, 'cwd': os.getcwd(), 'executable': sys.executable,
                  'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  'wall_seconds': time.monotonic() - started}}
with (P / 'checks_final_v1.json').open('x') as out:
    json.dump(checks, out, indent=2)
    out.write('\n')

files, excluded = [], []
for path in sorted(P.rglob('*')):
    if not path.is_file(): continue
    if path.name in ('sealed_manifest_v1.json', 'handoff_v1.json'):
        continue
    before = state(path)
    data = path.read_bytes()
    after = state(path)
    assert before == after
    row = {'path': str(path), 'bytes': len(data), 'sha256': sha(data),
           'stat_before': before, 'stat_after': after}
    if data.startswith(b'\x7fELF'):
        row['reason'] = 'CPU/SDK test ELF excluded from source/evidence tar; original identity retained.'
        excluded.append(row)
    else:
        files.append(row)
manifest = {'schema': 'mr3-ray-box-corrector-proposal-sealed-manifest-v1',
            'files': files, 'excluded_cpu_elf': excluded,
            'raw_bytes': sum(row['bytes'] for row in files),
            'source_stopped': True}
with (P / 'sealed_manifest_v1.json').open('x') as out:
    json.dump(manifest, out, indent=2)
    out.write('\n')
archive = P.parent / 'mr3_p2a0_v22_ray_box_corrector_sealed_v1.tar.gz'
with tarfile.open(archive, 'x:gz') as tar:
    for row in files:
        tar.add(row['path'], arcname=str(pathlib.Path(row['path']).relative_to('/tmp')), recursive=False)
    tar.add(P / 'sealed_manifest_v1.json', arcname=str((P / 'sealed_manifest_v1.json').relative_to('/tmp')), recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    for row in files:
        member = str(pathlib.Path(row['path']).relative_to('/tmp'))
        assert sha(tar.extractfile(member).read()) == row['sha256']
for row in files + excluded:
    path = pathlib.Path(row['path'])
    assert state(path) == row['stat_after']
    assert sha(path.read_bytes()) == row['sha256']
handoff = {'schema': 'mr3-ray-box-corrector-handoff-v1',
           'source_sha256': source, 'sdk_library': sdk_library,
           'checks': {'path': str(P / 'checks_final_v1.json'),
                      'sha256': sha((P / 'checks_final_v1.json').read_bytes())},
           'manifest': {'path': str(P / 'sealed_manifest_v1.json'),
                        'sha256': sha((P / 'sealed_manifest_v1.json').read_bytes()),
                        'files': len(files), 'raw_bytes': manifest['raw_bytes']},
           'archive': {'path': str(archive), 'sha256': sha(archive.read_bytes()),
                       'bytes': archive.stat().st_size, 'member_roundtrip_verified': True},
           'excluded_cpu_elf_count': len(excluded), 'source_final_sha_stat_stable': True,
           'scope': 'TMP CPU/SDK evidence only; canonical build/native admission still separate.',
           'wall_seconds': time.monotonic() - started}
with (P / 'handoff_v1.json').open('x') as out:
    json.dump(handoff, out, indent=2)
    out.write('\n')
print(json.dumps(handoff))
