"""Actual two-group consumer CPU only; original pstats are never sources."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path('/home/zhuyulab/ns3-workspace')
W=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A=Path(__file__).resolve().parent
B=A/'checks/consumer_cpu_v1'
G='81e63f50699073286c9773dcb92106de63fdf4ca'


def identity():
    fields=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()
    return dict(pid=os.getpid(),parent=int(fields[1]),group=int(fields[2]),session=int(fields[3]),start_ticks=int(fields[19]))


def main():
    B.mkdir(parents=True,exist_ok=False)
    spec=json.loads((A/'spec_v1.json').read_text())
    metadata=[Path(row['path']) for row in spec['finished_metadata']]
    metadata += [Path(spec['old_scope']['path']),Path(spec['closed_inventory']['path'])]
    sources=sorted(set([*A.glob('*.py'),A/'spec_v1.json',A/'consumer_cpu_spec_v1.json',
        *[Path(row['path']) for row in [spec['description_source']]],*metadata,
        *(W/'mr3_learning').glob('*.py'),
        W/'report/assets/20261024_mr3_p2a_v62_process_profile/run_profile_v1.py',
        W/'report/assets/20261024_mr3_p2a_v62_process_profile/bootstrap_v1.py',
        W/'report/assets/20261024_mr3_p2a_v61_cancel_forensics/run_cancel_forensics_v1.py',
        Path('/usr/bin/python3')]))
    if any(path.suffix=='.pstats' for path in sources):
        raise ValueError('CPU source set must not open any original pstats')
    snapshots=B/'source_snapshots';snapshots.mkdir()
    rows=[]
    for ordinal,path in enumerate(sources):
        raw=path.read_bytes();digest=hashlib.sha256(raw).hexdigest()
        snapshot=snapshots/(str(ordinal).zfill(3)+'_'+digest+'_'+path.name)
        snapshot.open('xb').write(raw)
        row=dict(path=str(path),bytes=len(raw),sha256=digest,snapshot=str(snapshot),kind='snapshot')
        if path.is_relative_to(ROOT) and path.suffix=='.py':
            relative=str(path.relative_to(ROOT))
            frozen=subprocess.check_output(['git','show',G+':'+relative],cwd=ROOT)
            if frozen!=raw:raise ValueError('G code dependency changed: '+relative)
            row.update(kind='historical_git_blob',freeze=G,relative_path=relative)
        rows.append(row)
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    (B/'source_recovery_v1.json').open('x').write(json.dumps(dict(repository_HEAD_at_seal=head,
        historical_description_source_freeze=G,sources=rows),indent=2)+'\n')
    (B/'runner_identity_v1.json').open('x').write(json.dumps(identity(),indent=2)+'\n')
    command=json.loads((A/'consumer_cpu_spec_v1.json').read_text())['actual_argv']
    argv=[sys.executable,'-B','-m','mr3_learning.reach_execution','--scope','cpu','--output',str(B/'actual')]
    for path in sources:argv.extend(['--source',str(path)])
    argv.extend(['--',*command])
    env=dict(os.environ,PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1')
    env.pop('PYTHONPATH',None);env.pop('PYTHONHOME',None)
    return subprocess.call(argv,cwd=W,env=env)


if __name__=='__main__':
    raise SystemExit(main())
