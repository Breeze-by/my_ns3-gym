"""Record CPU proposal generation/tests without invoking native or formal tools."""
import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
SOURCE = ROOT / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/'
                 'report/assets/20261018_mr3_p2a0_v18/independent/'
                 'mr3_p2a0_v18_live_admission_v1.py')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    source_before = SOURCE.read_bytes()
    commands = [
        ['rtk', 'proxy', '/usr/bin/python3', '-B', str(HERE / 'generate_proposal.py')],
        ['rtk', 'proxy', '/usr/bin/python3', '-B', str(HERE / 'witness_executable_tests_v1.py')],
        ['rtk', 'proxy', '/usr/bin/python3', '-B', '-m', 'flake8',
         '--select=E9,F63,F7,F82', str(HERE / 'proposed_live_admission_v1.py'),
         str(HERE / 'generate_proposal.py'), str(HERE / 'witness_executable_tests_v1.py'),
         str(HERE / 'execute_checks_v1.py')],
    ]
    env = dict(os.environ, PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1')
    records = []
    started = time.monotonic()
    for index, argv in enumerate(commands):
        wall_start = time.monotonic()
        utc_start = datetime.datetime.now(datetime.timezone.utc).isoformat()
        result = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True)
        output = HERE / f'checks_{index:02d}.log'
        with output.open('xb') as stream:
            stream.write(result.stdout)
            stream.write(result.stderr)
        records.append({'argv': argv, 'cwd': str(ROOT),
                        'environment_overrides': {'PYTHONNOUSERSITE': '1',
                                                  'PYTHONDONTWRITEBYTECODE': '1'},
                        'started_utc': utc_start, 'exit_code': result.returncode,
                        'wall_seconds': time.monotonic() - wall_start,
                        'stdout_stderr_path': str(output),
                        'stdout_stderr_sha256': sha(output.read_bytes())})
        if result.returncode:
            break
    proposed = (HERE / 'proposed_live_admission_v1.py').read_bytes()
    patch = ''.join(difflib.unified_diff(
        source_before.decode().splitlines(True), proposed.decode().splitlines(True),
        fromfile='immutable_v18_live_admission_v1.py',
        tofile='prospective_live_admission_v1.py'))
    with (HERE / 'review_only.patch').open('x') as stream:
        stream.write(patch)
    report = {'schema': 'mr3-witness-executable-cpu-checks-v1',
              'passed': len(records) == len(commands) and all(
                  row['exit_code'] == 0 for row in records),
              'scope': 'CPU actual installed symlink/entity/ELF and inherited current CPU PID/maps; '
                       'no Gazebo process launch, no new native/formal credit, V18 FAIL retained',
              'source_before_sha256': sha(source_before),
              'source_after_sha256': sha(SOURCE.read_bytes()),
              'source_unchanged': SOURCE.read_bytes() == source_before,
              'proposed_source_sha256': sha(proposed),
              'commands': records, 'wall_seconds': time.monotonic() - started,
              'actual_process': {'pid': os.getpid(), 'executable': os.readlink('/proc/self/exe')},
              'native_calls': 0, 'formal_audits': 0}
    with (HERE / 'checks_v1.json').open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps(report))
    raise SystemExit(0 if report['passed'] and report['source_unchanged'] else 1)


if __name__ == '__main__':
    main()
