"""Final V13 plan/coordinator/nested-Shim static review and narrow replay."""
import ast
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A = W / 'report/assets/20261017_mr3_p2a0_v13'
I = A / 'independent'
OUT = Path('/tmp/mr3_p2a0_v13_final_control_readonly_review_v1.json')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def main():
    sources = {}

    def read(path):
        raw = path.read_bytes()
        entry = {'bytes': len(raw), 'sha256': sha(raw)}
        require(str(path) not in sources or sources[str(path)] == entry, 'changed source')
        sources[str(path)] = entry
        return raw

    plan = json.loads(read(A / 'predeclared_plan_v13.json'))
    old = json.loads(read(W / 'report/assets/20261017_mr3_p2a0_v12/predeclared_plan_v12.json'))
    current = {item['path']: item['sha256'] for item in plan['independent_source_bindings']}
    prior = {item['path']: item['sha256'] for item in old['independent_source_bindings']}
    require(len(current) == len(plan['independent_source_bindings']) == 96, 'unique final binding count')
    for path, expected in current.items():
        require(sha(read(ROOT / path)) == expected, 'binding differs: ' + path)
    require(not prior.keys() - current.keys(), 'historical binding removed')
    changed = sorted(k for k in prior if prior[k] != current[k])
    require(changed == sorted(str((W / 'mr3_learning' / n).relative_to(ROOT)) for n in (
        'audit_motion.py', 'audit_ppo.py', 'tests/test_audit_motion.py')), 'old binding changed')
    for key in ('unchanged_gates', 'pilot_budget_unchanged', 'max_total_wall_seconds',
                'max_api_records', 'max_submitted_script_decisions'):
        require(plan[key] == old[key], 'old gate/budget changed: ' + key)
    require(plan['readiness']['status'] == 'ready' and not plan['readiness']['pending_bindings'],
            'final source readiness not ready')
    require([stage['stage'] for stage in plan['stages']] ==
            ['interface', 'terminal', 'reset', 'deadline'], 'stage order changed')
    for stage in plan['stages']:
        paths = stage['required_audit_receipts']
        require(len(paths) == (10 if stage['stage'] in ('interface', 'reset') else 7)
                and len(set(paths)) == len(paths), 'mandatory receipt count/uniqueness differs')
        for key in ('settled_turn', 'information', 'peer', 'control'):
            argv = stage[key + '_audit_command_template']
            path = argv[argv.index('--output') + 1]
            require(path in paths, 'template output not mandatory')

    closure = I / 'mr3_v13_multiepoch_closure_binary_review_v1.py'
    before = Path('/tmp/mr3_p2a0_v13_nested_closure_read_checks_v1/'
                  'before_mr3_v13_multiepoch_closure_binary_review_v1.py')
    old_ast, new_ast = ast.parse(read(before)), ast.parse(read(closure))
    old_main = next(n for n in old_ast.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
    new_main = next(n for n in new_ast.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
    old_read = next(n for n in old_main.body if isinstance(n, ast.FunctionDef) and n.name == 'read')
    new_main.body = [copy.deepcopy(old_read) if isinstance(n, ast.FunctionDef) and n.name == 'read'
                     else n for n in new_main.body]
    loops = [n for n in new_main.body if isinstance(n, ast.For) and
             isinstance(n.target, ast.Tuple) and any(isinstance(t, ast.Name) and
             t.id == 'bound_path' for t in n.target.elts)]
    require(len(loops) == 1, 'missing unique final source recheck')
    new_main.body.remove(loops[0])
    removed = 0
    for node in ast.walk(new_main):
        if isinstance(node, ast.Dict):
            indices = [i for i, key in enumerate(node.keys) if isinstance(key, ast.Constant)
                       and key.value == 'input_bindings_rechecked']
            for index in reversed(indices):
                del node.keys[index]
                del node.values[index]
                removed += 1
    require(removed == 1 and ast.dump(new_ast) == ast.dump(old_ast),
            'closure changed beyond read stability and result metadata')

    # Exactly the three new actual-main/no-episode callback fixtures, not any
    # ROS/conda/native suite. Their stub supplies no native source or body proof.
    test = I / 'mr3_v13_nested_closure_read_tests_v1.py'
    read(test)
    argv = ['/usr/bin/python3', str(test)]
    began = time.monotonic()
    env = dict(os.environ, PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1')
    cp = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True)
    wall = time.monotonic() - began
    log = Path('/tmp/mr3_p2a0_v13_final_control_nested_replay_v1.log')
    with log.open('xb') as stream:
        stream.write(cp.stdout + cp.stderr)
    require(cp.returncode == 0 and b'Ran 3 tests' in cp.stderr,
            'new nested stability fixtures did not pass')

    runtime = Path('/tmp/mr3_p2a0_v13_research_gate_static_review_v3.json')
    runtime_review = json.loads(read(runtime))
    require(runtime_review.get('passed') is True, 'runtime delegated review not passed')
    # Code was also read in full before this script: fail-closed result is the
    # conjunction of required child exit+typed passed, mandatory receipts and
    # runner errors; only the unchanged reset per-episode coverage report has
    # required=False, and its original FAIL survives beside the pooled verdict.
    coordinator = I / 'mr3_p2a0_v13_audit_stage.py'
    coordinator_raw = read(coordinator).decode()
    require(coordinator_raw.count('required=False') == 1 and
            'Original missing-coverage FAIL is still retained.' in coordinator_raw and
            "all(v['passed'] for v in commands if v['required_success'])" in coordinator_raw and
            "all(v['passed'] for v in receipts)" in coordinator_raw and
            "'all_submitted_jobs_finished': all(f.done() for f in jobs)" in coordinator_raw,
            'coordinator fail-closed/drain invariants differ')
    for path, entry in sources.items():
        require(sha(Path(path).read_bytes()) == entry['sha256'], 'source changed before review verdict')
    result = {
        'schema': 'mr3-v13-final-control-readonly-review-v1', 'passed': True,
        'independent_bindings': 96, 'immutable_old_bindings': 73,
        'authorized_current_binding_updates': changed,
        'new_bindings': len(current.keys() - prior.keys()),
        'closure_read_stability_only_AST_change': True,
        'nested_callback_replay': {'argv': argv, 'cwd': str(ROOT),
                                  'env': {'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1'},
                                  'exit': cp.returncode, 'wall_sec': wall, 'tests': 3,
                                  'stdout_stderr': str(log), 'stdout_stderr_sha256': sha(log.read_bytes()),
                                  'scope': 'author fixtures independently rerun; no native credit'},
        'coordinator_review': {
            'max_audit_subprocesses': 4, 'all_children_drained': True,
            'mandatory_receipts': {'interface': 10, 'terminal': 7, 'reset': 10, 'deadline': 7},
            'math_gate_changes': False,
            'raw_reset_completeness_FAIL_preserved': True,
            'only_declared_reset_pool_can_supply_missing_stop_coverage': True,
            'FIFO_before_closure_and_raw_physics_before_pool': True,
            'existing_output_overwrite_rejected': True},
        'shim_review': {
            'prior_targeted_review': '/tmp/mr3_p2a0_v13_shim_observer_independent_review_v2.json',
            'prior_targeted_review_sha256': sha(read(Path(
                '/tmp/mr3_p2a0_v13_shim_observer_independent_review_v2.json'))),
            'actual_worker_per_EP_and_base_typed_equality_unchanged': True,
            'nested_interface_stability_gap_now_fixed': True},
        'delegated_core_source_binary_review': {'path': str(runtime),
                                                 'sha256': sha(runtime.read_bytes()),
                                                 'original_result_preserved': True,
                                                 'note': 'v3 predates only the closure stability '
                                                 'change; final v4 belongs to runtime agent'},
        'sources': sources, 'source_bytes_stable_before_after': True,
        'limits': ['Clean pushed exact40 admission and new formal same-freeze native stages still '
                   'required; no V13 native ran in this review.',
                   'No repeat ROS1192/conda253, build or physical experiment.',
                   'No hard task/body/contact/phase/stop threshold relaxed and no original '
                   'failure converted to pass by coordinator changes.'],
    }
    with OUT.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'passed': True, 'bindings': 96, 'nested_tests': 3, 'output': str(OUT)}))


if __name__ == '__main__':
    main()
