"""Static mechanical coordinator inverse; no entrypoints or production gates run."""
from pathlib import Path
import ast
import hashlib
import json

B = Path(__file__).resolve().parent
W = Path('/home/zhuyulab/ns3-workspace/ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl')
OLD = W / 'report/assets/20261018_mr3_p2a0_v23_entry'
current_name = '20261018_mr3_p2a0_v24_install'
previous_name = '20261018_mr3_p2a0_v23_entry'
rows = []
for path in sorted((B / 'independent').glob('*.py')):
    ast.parse(path.read_bytes())
    if 'custody' in path.name or path.name.startswith('test_'):
        continue
    text = path.read_text()
    back = text
    if 'launch_stage' in path.name:
        back = back.replace('PRIOR_ENGINEERING_WALL_SECONDS', 'PRIOR_ENTRY_WALL_SECONDS')
        back = back.replace('71.97839368507266', '0.24578428314998746')
        back = back.replace('"prior_engineering_cost"', '"prior_entry_cost"')
        back = back.replace('prior_engineering_wall_seconds=', 'prior_entry_wall_seconds=')
    if 'load_checked_corrector' in back:
        back = back.replace('    custody_asset = asset',
            "    legacy = asset.replace('20261018_mr3_p2a0_v24_install', '20261018_mr3_p2a0_v22_ray_box')")
        back = back.replace("relative = custody_asset + 'independent/mr3_v24_corrector_custody_v3.py'",
                            "relative = legacy + 'independent/mr3_v22_corrector_custody_v2.py'")
        back = back.replace("binding = root / (custody_asset + 'independent/mr3_v24_corrector_binding_v1.json')",
                            "binding = root / (legacy + 'independent/mr3_v22_corrector_binding_v1.json')")
    if 'buildproof_preflight' in path.name:
        back = back.replace('report/assets/20261018_mr3_p2a0_v24_install/independent/mr3_v24_corrector_custody_v3.py',
                            'report/assets/20261018_mr3_p2a0_v22_ray_box/independent/mr3_v22_corrector_custody_v2.py')
    if 'cross_stage_mapping' in path.name:
        prefix = "    asset = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/"
        back = back.replace(prefix + current_name + "/independent'",
                            prefix + "20261018_mr3_p2a0_v22_ray_box/independent'")
        back = back.replace("asset/'mr3_v24_corrector_custody_v3.py'", "asset/'mr3_v22_corrector_custody_v2.py'")
        back = back.replace("asset/'mr3_v24_corrector_binding_v1.json'", "asset/'mr3_v22_corrector_binding_v1.json'")
    back = back.replace(current_name, previous_name).replace('v24', 'v23')
    original = OLD / 'independent' / path.name.replace('v24', 'v23')
    assert back.encode() == original.read_bytes(), str(path)
    rows.append({'source': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                 'normative': str(original), 'normative_sha256': hashlib.sha256(original.read_bytes()).hexdigest(),
                 'whole_byte_inverse': True})
assert len(rows) == 6
old = json.loads((OLD / 'predeclared_plan_v23.json').read_bytes())
new = json.loads((B / 'predeclared_plan_v24.json').read_bytes())
for key in ('max_api_records', 'max_submitted_script_decisions', 'max_total_wall_seconds',
            'unchanged_gates', 'physical_response_criteria', 'angular_interface_criteria',
            'angular_reset_criteria', 'external_probe_v6', 'world_solver_candidate',
            'production_environment', 'pilot_budget_unchanged'):
    assert old[key] == new[key], key
assert [len(s['required_audit_receipts']) for s in new['stages']] == [10,7,10,7]
assert new['readiness']['status'] == 'draft' and new['readiness']['pending_bindings']
assert new['native_admission_granted'] is False
result = {'schema':'mr3-v24-mechanical-source-inverse-v1', 'passed':True, 'sources':rows,
          'pending_rejects_admission':True, 'old34_and_core_gates_preserved':True,
          'plan_sha256':hashlib.sha256((B/'predeclared_plan_v24.json').read_bytes()).hexdigest(),
          'scope':'Static bytes/AST/JSON only. ActualSO/loader/ENV readiness pending. No old tests, entrypoint, ROS/DDS/SDK/native.'}
with (B/'source_inverse_checks_v1.json').open('x') as stream:
    stream.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':True,'sources':len(rows),'plan_sha256':result['plan_sha256']}))
