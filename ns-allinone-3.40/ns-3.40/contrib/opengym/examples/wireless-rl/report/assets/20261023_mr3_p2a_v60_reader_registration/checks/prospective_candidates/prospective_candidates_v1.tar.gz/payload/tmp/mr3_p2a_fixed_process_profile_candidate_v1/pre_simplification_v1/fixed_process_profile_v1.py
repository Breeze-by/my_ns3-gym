"""Fixed three-role profiler for one future open101/eight-step diagnostic.

No native invocation is admitted by this draft. A trusted fixed launcher hook
must create the exact role command manifest before using this entry point.
"""
import argparse
import cProfile
import hashlib
import json
import os
from pathlib import Path
import runpy
import sys
import threading
import time

PROFILE_ID = 'mr3-p2a-open101-8step-cprofile-v1'
ROOT = Path('/home/zhuyulab/ns3-workspace')
ROS = ROOT / 'ros2_ws/ros2-multi-robot-automap'
OWNED_EPISODE = Path('/tmp/mr3_p2a_open101_8step_profile_v1/native/worker0/episode001_open_101')
COMMAND_ROOT = OWNED_EPISODE / 'profile_commands'
PROGRAMS = {
    'motion_safety': ROS / 'install/multi_robot_exploration/lib/multi_robot_exploration/motion_safety',
    'adapter': ROS / 'install/multi_robot_exploration/lib/multi_robot_exploration/mr3_adapter',
    'worker': ROS / 'scripts/mr3_env_worker.py',
}
LANES = {'motion_safety': ('main',), 'adapter': ('main', 'encoder'), 'worker': ('main', 'ros_spin')}
_ACTIVE = None


def require(value, reason):
    if not value:
        raise ValueError(reason)


def identity():
    fields = Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()
    return dict(pid=os.getpid(), parent=int(fields[1]), group=int(fields[2]),
                session=int(fields[3]), start_ticks=int(fields[19]))


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def fingerprint(value):
    return {key: getattr(value, key) for key in
            ('st_dev', 'st_ino', 'st_mode', 'st_size', 'st_mtime_ns', 'st_ctime_ns')}


def program_identity(path):
    # Installed console entries may be legitimate known symlinks. Bind both.
    return dict(literal_lstat=fingerprint(path.lstat()), resolved_path=str(path.resolve(strict=True)),
                resolved_target_stat=fingerprint(path.stat()))


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


class Capture:
    def __init__(self, role, directory):
        self.role, self.directory = role, directory
        self.main_thread = threading.get_ident()
        self.profiles, self.threads, self.active, self.calls, self.cpu_ns = {}, {}, {}, {}, {}
        self.thread_objects = {}
        self.lock = threading.Lock()

    def call(self, lane, function, *args, **kwargs):
        require(lane in LANES[self.role], 'lane is not whitelisted for this fixed role')
        thread = threading.get_ident()
        require((lane == 'main') == (thread == self.main_thread), 'lane/thread ownership differs')
        with self.lock:
            require(lane not in self.threads or self.threads[lane] == thread, 'lane moved to another thread')
            require(not self.active.get(lane, False), 'nested/reentrant use of one profiler')
            self.threads[lane] = thread
            self.thread_objects[lane] = threading.current_thread()
            self.profiles.setdefault(lane, cProfile.Profile())
            self.active[lane] = True
        started = time.thread_time_ns()
        try:
            # runcall propagates SystemExit and BaseException; CLI runctx does not.
            return self.profiles[lane].runcall(function, *args, **kwargs)
        finally:
            self.cpu_ns[lane] = self.cpu_ns.get(lane, 0) + time.thread_time_ns() - started
            self.calls[lane] = self.calls.get(lane, 0) + 1
            self.active[lane] = False

    def finish(self):
        rows, errors = [], []
        for lane in LANES[self.role]:
            path = self.directory / (lane + '.pstats')
            if (lane not in self.profiles or self.active.get(lane)
                    or lane != 'main' and self.thread_objects[lane].is_alive()):
                errors.append(lane + ': unobserved or still active; no complete profile claim')
                continue
            try:
                require(not path.exists(), 'profile output exists')
                self.profiles[lane].dump_stats(path)
                raw = path.read_bytes()
                rows.append(dict(lane=lane, path=str(path), bytes=len(raw), sha256=sha(raw),
                                 thread_ident=self.threads[lane], calls=self.calls[lane],
                                 thread_exit_observed=lane != 'main',
                                 thread_cpu_ns=self.cpu_ns[lane]))
            except Exception as error:
                errors.append(lane + ': ' + repr(error))
        return rows, errors


def profiled_call(lane, function, *args, **kwargs):
    """Only the fixed encoder or ROS-spin source hook calls this in its own thread."""
    require(_ACTIVE is not None, 'fixed diagnostic capture is not active')
    require(lane != 'main', 'main entry cannot be called through a thread hook')
    return _ACTIVE.call(lane, function, *args, **kwargs)


def run_role(role, program_argv):
    global _ACTIVE
    require(role in PROGRAMS and role in LANES, 'unknown fixed profiling role')
    require(_ACTIVE is None, 'one active role capture per process')
    require(type(program_argv) is list and program_argv and all(type(v) is str for v in program_argv),
            'exact original program argv required')
    require(program_argv[0] == str(PROGRAMS[role]), 'program is outside the exact role whitelist')
    manifest_path = COMMAND_ROOT / (role + '.json')
    require(manifest_path == manifest_path.resolve(strict=True), 'command manifest path is not canonical')
    before = fingerprint(manifest_path.stat())
    manifest_raw = manifest_path.read_bytes()
    manifest = json.loads(manifest_raw)
    require(before == fingerprint(manifest_path.stat()), 'command manifest changed')
    require(manifest.get('schema') == 'mr3-fixed-profile-command-v1'
            and type(manifest.get('admitted')) is bool and manifest['admitted'] is True
            and manifest.get('profile_id') == PROFILE_ID and manifest.get('role') == role
            and manifest.get('scene') == 'open' and manifest.get('seed') == 101
            and manifest.get('workers') == 1 and manifest.get('steps') == 8
            and all(type(manifest.get(key)) is int for key in ('seed', 'workers', 'steps'))
            and manifest.get('program_argv') == program_argv
            and manifest.get('owned_episode') == str(OWNED_EPISODE),
            'fixed role/source/argv/workload manifest differs or is unadmitted')
    program = PROGRAMS[role]
    program_stat, program_raw = program_identity(program), program.read_bytes()
    require(sha(program_raw) == manifest.get('program_sha256')
            and type(manifest.get('program_bytes')) is int and len(program_raw) == manifest['program_bytes']
            and program_stat == program_identity(program),
            'fixed program bytes differ from trusted command manifest')
    directory = OWNED_EPISODE / 'profiles' / role
    require(directory.parent == directory.parent.resolve(strict=True), 'owned output parent is not canonical')
    directory.mkdir(exist_ok=False)
    owner = identity()
    started, cpu_started = time.monotonic_ns(), time.process_time_ns()
    actual_argv = [value.decode() for value in Path('/proc/self/cmdline').read_bytes().split(b'\0') if value]
    write(directory / 'started.json', dict(profile_id=PROFILE_ID, role=role, identity=owner,
          actual_argv=actual_argv, program_argv=program_argv, manifest_sha256=sha(manifest_raw),
          program_sha256=sha(program_raw), program_identity=program_stat, manifest_stat=before,
          started_monotonic_ns=started))
    old_argv, outcome = sys.argv, dict(kind='returned')
    capture = Capture(role, directory)
    _ACTIVE = capture
    try:
        sys.argv = list(program_argv)
        capture.call('main', runpy.run_path, str(program), run_name='__main__')
    except BaseException as error:
        outcome = dict(kind=type(error).__name__, repr=repr(error))
        if isinstance(error, SystemExit):
            outcome['exit_code_repr'] = repr(error.code)
        raise
    finally:
        sys.argv, _ACTIVE = old_argv, None
        # Ordinary auxiliary dump errors never replace the target exception/rc.
        # KeyboardInterrupt/SystemExit are not suppressed; no signal handler is installed.
        try:
            profiles, errors = capture.finish()
            stable = (program_stat == program_identity(program) and program.read_bytes() == program_raw
                      and before == fingerprint(manifest_path.stat()) and manifest_path.read_bytes() == manifest_raw)
            write(directory / 'finished.json', dict(profile_id=PROFILE_ID, role=role, identity=owner,
                  target_outcome=outcome, profiles=profiles, profile_errors=errors,
                  profile_complete=not errors and stable, source_manifest_stable=stable,
                  started_monotonic_ns=started, ended_monotonic_ns=time.monotonic_ns(),
                  process_cpu_ns=time.process_time_ns() - cpu_started,
                  coverage='main plus only explicit role thread hooks; other threads/native internals not decomposed',
                  scientific_qualification=False))
        except Exception as error:
            # Missing/failed finish receipt makes the future parent diagnostic FAIL.
            # Preserve the target's real SystemExit/exception/signal semantics.
            try:
                write(directory / 'profile_dump_error.json', dict(error=repr(error), target_outcome=outcome))
            except Exception:
                pass


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--role', required=True, choices=tuple(PROGRAMS))
    parser.add_argument('program_argv', nargs=argparse.REMAINDER)
    args = parser.parse_args(argv)
    command = args.program_argv[1:] if args.program_argv[:1] == ['--'] else args.program_argv
    run_role(args.role, command)
    return 0
