"""Seal TMP-only correction artifacts; preserve initial failed fixture and checks."""
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).parent
OLD = Path('/tmp/mr3_p2a0_v20_sensor_coordinator_proposal_v1')


def proof(path):
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    assert tuple(getattr(before, field) for field in fields) == tuple(getattr(after, field) for field in fields)
    return {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def main():
    parent = HERE / 'mr3_p2a0_v20_sensor_run_v1.py'
    final = json.loads((HERE / 'checks_final_v2.json').read_bytes())
    assert final['passed'] is True
    handoff = {
        'schema': 'mr3-v20-sensor-binding-correction-handoff-v2',
        'production_change': proof(parent),
        'original_parent': proof(OLD / parent.name),
        'diff': proof(HERE / 'parent_minimal.patch'),
        'minimal_change': "Normalize only actual preflight source_bindings.items() into path/value['sha256'] rows before concatenating the existing independent list.",
        'reverse_entire_bytes_and_ast_same': final['whole_parent_reverse_bytes_and_ast_equal'],
        'real_preflight': proof(HERE / 'source_preflight_941ae862_original.json'),
        'real_ready_plan': proof(HERE / 'ready_plan_941ae862_original.json'),
        'counts': {'runtime_dict_items': 103, 'independent_list_rows': 160, 'combined_sha_check_rows': 263},
        'unchanged_files': [proof(HERE / name) for name in
                            ('mr3_p2a0_v20_sensor_preflight_v1.py', 'mr3_p2a0_v20_sensor_coordinator_tests_v1.py')],
        'final_checks': proof(HERE / 'checks_final_v2.json'),
        'checks': {'old_cpu_tests': 14, 'new_actual_main_cpu_tests': 4, 'fatal_style_passed': True},
        'meaningful_cases': ['Original sealed parent raises real list/dict TypeError before capture.',
                            'Corrected actual main checks all 103 runtime plus 160 independent file hashes.',
                            'Wrong runtime digest rejects before capture.',
                            'Unsupported guessed list shape rejects; no polymorphic fallback.'],
        'initial_failure_preserved': {'receipt': proof(HERE / 'checks_v2.json'),
                                      'source': proof(HERE / 'runtime_binding_tests_initial_exact_metadata_keys_failure_v1.py'),
                                      'reason': 'New fixture incorrectly required exactly three metadata keys; actual provenance metadata has additional valid key shapes. Parent fix was unchanged.'},
        'native_ros_dds_sdk_runs': 0,
        'canonical_git_mutations': 0,
        'source_status': 'STOP; parent/preflight/tests stable. No native admission or experiment PASS claimed.'}
    write(HERE / 'handoff_v2.json', handoff)
    files = [path for path in sorted(HERE.iterdir()) if path.is_file()]
    entries = [proof(path) for path in files]
    manifest = {'schema': 'mr3-v20-sensor-coordinator-correction-manifest-v2',
                'entries': entries, 'file_count': len(entries),
                'raw_bytes': sum(row['bytes'] for row in entries),
                'encoding': 'identity; exact original bytes',
                'excluded': ['manifest_final_v2.json: self-reference'],
                'all_recorded_files_final_stat_stable': True,
                'handoff': proof(HERE / 'handoff_v2.json')}
    path = HERE / 'manifest_final_v2.json'
    write(path, manifest)
    print(json.dumps({'manifest': proof(path), 'files': len(entries),
                      'raw_bytes': manifest['raw_bytes'], 'handoff': proof(HERE / 'handoff_v2.json')}))


if __name__ == '__main__':
    main()
