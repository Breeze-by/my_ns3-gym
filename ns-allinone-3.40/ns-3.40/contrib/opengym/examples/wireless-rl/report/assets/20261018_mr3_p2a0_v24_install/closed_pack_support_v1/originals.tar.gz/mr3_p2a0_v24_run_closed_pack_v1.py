#!/usr/bin/python3
"""One root-authorized V24 closed byte-custody invocation, no audit/native."""
from pathlib import Path
import hashlib
import json
import os
import resource
import subprocess
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
D = Path('/tmp/mr3_p2a0_v24_closed_pack_execution_v1')
HELPER = Path('/tmp/mr3_p2a0_v24_matrix_pack_proposal_v1/mr3_p2a0_v24_matrix_pack_closed_v1.py')
EXPECTED = 'c2651688874bbc7379dfd0e317c916f2eee3fc845194831524d5780e2af035e6'
FREEZE = '5d684c46f9f99a867a94f1fed8c52e923e2486ef'
PLAN = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v24_install/predeclared_plan_v24.json'
TARGET = Path('/tmp/mr3_p2a0_v24_selected_closed_v1')
ENV = {'PATH': '/usr/bin:/bin', 'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1',
       'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'TZ': 'UTC'}

def bind(path):
    s = path.stat()
    raw = path.read_bytes()
    t = path.stat()
    def ident(v):
        return [v.st_dev, v.st_ino, v.st_size, v.st_mtime_ns, v.st_ctime_ns]
    assert ident(s) == ident(t)
    return {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(),
            'bytes': len(raw), 'stat': ident(s)}


def main():
    assert not D.exists() and not TARGET.exists()
    D.mkdir()
    extras = [Path('/tmp') / name for name in (
        'mr3_p2a0_v24_matrix_parent_console_v1.log',
        'mr3_p2a0_v24_cross_stage_mapping_parent_console_v1.log',
        'mr3_p2a0_v24_actual_preflight_execution_v1/execution.json',
        'mr3_p2a0_v24_actual_preflight_execution_v1/stdout.txt',
        'mr3_p2a0_v24_actual_preflight_execution_v1/stderr.txt',
        'mr3_p2a0_v24_run_actual_preflight_v1.py',
        'mr3_p2a0_v24_final_root_static_v1.py',
        'mr3_p2a0_v24_final_root_static_v1.json',
        'mr3_p2a0_v24_precommit_add_dry_v1.txt',
        'mr3_p2a0_v24_precommit_pathspec_v1.json',
        'mr3_p2a0_v24_finalize_precommit_v1.py',
        'mr3_p2a0_v24_copy_root_final_static_v2.py')]
    entry_files = sorted(Path('/tmp').glob('mr3_p2a0_v24_preflight_learner_entry_*'))
    assert entry_files and all(x.is_file() and not x.is_symlink() for x in entry_files)
    extras.extend(entry_files)
    assert all(x.is_file() and not x.is_symlink() for x in extras)
    before = [bind(x) for x in [Path(__file__), HELPER, PLAN, *extras]]
    assert before[1]['sha256'] == EXPECTED
    argv = ['/usr/bin/python3', '-B', str(HELPER), '--freeze', FREEZE,
            '--target', str(TARGET), '--all-writers-closed']
    for path in extras:
        argv.extend(['--extra', str(path)])
    invocation = {'schema': 'mr3-v24-closed-pack-invocation-v1', 'argv': argv,
                  'cwd': str(ROOT), 'environment_exact': ENV, 'bound_inputs_before': before,
                  'operator_GO': 'Root explicitly confirmed native, mandatory audit and mapping watcher all closed.',
                  'scope': 'Lossless byte custody; no scientific PASS and no missing episode credit.'}
    (D / 'invocation.json').write_text(json.dumps(invocation, indent=2) + '\n')
    usage_before = resource.getrusage(resource.RUSAGE_CHILDREN)
    start = time.monotonic()
    with (D / 'stdout.txt').open('xb') as out, (D / 'stderr.txt').open('xb') as err:
        result = subprocess.run(argv, cwd=ROOT, env=ENV, stdout=out, stderr=err, check=False)
    wall = time.monotonic() - start
    usage_after = resource.getrusage(resource.RUSAGE_CHILDREN)
    after = [bind(Path(x['path'])) for x in before]
    receipt = {**invocation, 'bound_inputs_after': after, 'input_bindings_stable': before == after,
               'exit_code': result.returncode, 'wall_seconds': wall,
               'child_user_cpu_seconds': usage_after.ru_utime - usage_before.ru_utime,
               'child_system_cpu_seconds': usage_after.ru_stime - usage_before.ru_stime,
               'stdout': bind(D / 'stdout.txt'), 'stderr': bind(D / 'stderr.txt'),
               'helper_invoked_once': True, 'retry_or_signals': False,
               'custody_completed': result.returncode == 0 and before == after and (TARGET / 'manifest.json').exists()}
    if (TARGET / 'manifest.json').exists():
        receipt['output_manifest'] = bind(TARGET / 'manifest.json')
    (D / 'execution.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'execution': str(D / 'execution.json'), 'exit_code': result.returncode,
                      'wall_seconds': wall, 'custody_completed': receipt['custody_completed']}))
    raise SystemExit(result.returncode if before == after else 1)

if __name__ == '__main__':
    main()
