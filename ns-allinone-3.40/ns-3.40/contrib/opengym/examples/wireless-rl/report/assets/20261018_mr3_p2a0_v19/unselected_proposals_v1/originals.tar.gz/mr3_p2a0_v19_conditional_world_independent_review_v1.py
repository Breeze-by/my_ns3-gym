"""Read-only conditional proposal review; no V19 raw or native imports."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path('/home/zhuyulab/ns3-workspace')
PROPOSAL = Path('/tmp/mr3_p2a0_v19_conditional_world_iters150_proposal_v1')
W7 = 'cdb1f5947302a0b3a071b78a9077e61b8e6b6a7a'
OUTPUT = Path('/tmp/mr3_p2a0_v19_conditional_world_independent_review_v1.json')
BLOCK = (b'      <ode>\n'
         b'        <solver>\n'
         b'          <type>quick</type>\n'
         b'          <iters>150</iters>\n'
         b'        </solver>\n'
         b'      </ode>\n')
ANCHOR = b'      <real_time_update_rate>1000</real_time_update_rate>\n'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def flatten(node, prefix=''):
    path = prefix + '/' + node.tag
    result = {path + '/@' + key: value for key, value in node.attrib.items()}
    if node.text and node.text.strip():
        result[path] = node.text.strip()
    for child in node:
        values = flatten(child, path)
        if set(result) & set(values):
            raise ValueError('ambiguous repeated schema field')
        result.update(values)
    return result


def main():
    started = time.monotonic()
    actual_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT,
                                          text=True).strip()
    assert actual_head.startswith('72d0465d')
    bound = {}

    def read(path):
        path = Path(path)
        raw = path.read_bytes()
        digest = sha(raw)
        if str(path) in bound:
            assert bound[str(path)] == digest, str(path)
        bound[str(path)] = digest
        return raw

    def load(name):
        return json.loads(read(PROPOSAL / name))

    manifest = load('manifest_v1.json')
    assert type(manifest['file_count']) is int
    assert len(manifest['entries']) == manifest['file_count'] == 124
    assert len({row['path'] for row in manifest['entries']}) == 124
    raw_bytes = 0
    for row in manifest['entries']:
        path = Path(row['path'])
        assert path.is_relative_to(PROPOSAL) and not path.is_symlink()
        raw = read(path)
        assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
        assert not raw.startswith(b'\x7fELF')
        raw_bytes += len(raw)
    assert raw_bytes == manifest['raw_bytes']

    review = load('review_v1.json')
    checks = load('attempt02/checks_v1.json')
    complete = load('attempt02/complete_schema_defaults_v1.json')
    initial = load('initial_failure_v1.json')
    for key in ('conditional_only', 'cpu_checks_passed'):
        assert review[key] is True
    for key in ('production_change_authorized_or_applied', 'v19_result_assumed'):
        assert review[key] is False
    assert checks['passed'] is True and complete['passed'] is True
    assert checks['v19_formal_result_consumed'] is False
    assert checks['sdformat_version'] == '9.7.0'
    for source in review['reviewed_source_bindings']:
        assert sha(read(ROOT / source['path'])) == source['sha256']

    projection_source = read(PROPOSAL / 'attempt02/world_projection_proposal.py')
    namespace = {}
    exec(compile(projection_source, '<sealed-proposal-projection>', 'exec'), namespace)
    assert namespace['ODE_BLOCK'] == BLOCK and namespace['ANCHOR'] == ANCHOR
    rows = []
    git_commands = []
    reject_cases = []
    for scene in ('open', 'rooms', 'corridors'):
        world = ('ros2_ws/ros2-multi-robot-automap/src/multi_robot/worlds/'
                 + 'p1c_' + scene + '.world')
        config = ('ros2_ws/ros2-multi-robot-automap/src/multi_robot/config/mr3_p1a/'
                  + scene + '.json')
        old_world = read(PROPOSAL / 'attempt02/old/worlds' / Path(world).name)
        new_world = read(PROPOSAL / 'attempt02/proposed/worlds' / Path(world).name)
        old_config = read(PROPOSAL / 'attempt02/old/config' / Path(config).name)
        new_config = read(PROPOSAL / 'attempt02/proposed/config' / Path(config).name)
        for relative, old in ((world, old_world), (config, old_config)):
            argv = ['git', 'show', W7 + ':' + relative]
            result = subprocess.run(argv, cwd=ROOT, capture_output=True, check=True)
            git_commands.append({'argv': argv, 'exit_code': result.returncode,
                                 'stdout_sha256': sha(result.stdout),
                                 'stderr_sha256': sha(result.stderr)})
            assert result.stdout == old == read(ROOT / relative)
        assert old_world.count(ANCHOR) == 1 and b'<ode>' not in old_world
        assert new_world == old_world.replace(ANCHOR, ANCHOR + BLOCK, 1)
        assert new_world.count(BLOCK) == 1
        assert new_world.replace(BLOCK, b'', 1) == old_world
        assert sha(new_world) == review['prospective_world_pins'][world]
        assert sha(new_config) == review['prospective_task_metadata_pins'][config]
        before = ('  "world_sha256": "' + sha(old_world) + '",\n').encode()
        after = ('  "world_sha256": "' + sha(new_world) + '",\n').encode()
        assert old_config.count(before) == new_config.count(after) == 1
        assert new_config == old_config.replace(before, after, 1)
        assert new_config.replace(after, before, 1) == old_config
        assert json.loads(new_config)['world_sha256'] == sha(new_world)
        assert namespace['projected_world'](
            world, old_world, new_world, review['prospective_world_pins']) == old_world
        assert namespace['projected_task_metadata'](
            config, old_config, new_config, review['prospective_task_metadata_pins'],
            sha(old_world), sha(new_world)) == old_config
        geometry = next(row for row in checks['geometry'] if row['scene'] == scene)
        assert geometry['mask_identical'] is True
        assert geometry['actual_new_truth_world_sha256'] == sha(new_world)
        assert geometry['expected_new_world_sha256'] == sha(new_world)
        assert geometry['old_contract_with_new_world_rejected'] == (
            'World SHA256 differs from the declared task geometry')
        for complete_mode, old_label, proposed_label in (
                (False, 'old_normalize', 'proposed_normalize'),
                (True, 'complete_old', 'complete_proposed')):
            old_values = flatten(ET.fromstring(read(
                PROPOSAL / 'attempt02' / (scene + '_' + old_label + '.stdout'))))
            new_values = flatten(ET.fromstring(read(
                PROPOSAL / 'attempt02' / (scene + '_' + proposed_label + '.stdout'))))
            differences = {key: [old_values.get(key), new_values.get(key)]
                           for key in set(old_values) | set(new_values)
                           if old_values.get(key) != new_values.get(key)}
            assert differences == {'/physics/ode/solver/iters': ['50', '150']}
            assert len(old_values) == len(new_values) == (43 if complete_mode else 14)
            if complete_mode:
                recorded = next(row for row in complete['rows'] if row['scene'] == scene)
                assert old_values == recorded['old']
                assert new_values == recorded['proposed']
        rows.append({'scene': scene, 'world': world, 'task': config,
                     'old_world_sha256': sha(old_world), 'new_world_sha256': sha(new_world),
                     'old_task_sha256': sha(old_config), 'new_task_sha256': sha(new_config),
                     'byte_projection': True, 'schema_fields': 43,
                     'truth_mask_evidence': geometry,
                     'truth_mask_reexecution': False})

    # Focused independent counterexamples, not the author's full check program.
    base_world = rows[0]['world']
    old = read(PROPOSAL / 'attempt02/old/worlds/p1c_open.world')
    new = read(PROPOSAL / 'attempt02/proposed/worlds/p1c_open.world')
    for name, relative, actual, pins in (
            ('fourth_world', base_world.replace('p1c_open', 'p1c_other'), new,
             review['prospective_world_pins']),
            ('changed_dt_even_with_matching_actual_pin', base_world,
             new.replace(b'>0.001<', b'>0.002<', 1), None),
            ('extra_solver_field_even_with_matching_actual_pin', base_world,
             new.replace(b'<iters>150</iters>', b'<iters>150</iters><sor>1.4</sor>'), None)):
        selected = dict(review['prospective_world_pins']) if pins is None else pins
        if pins is None:
            selected[relative] = sha(actual)
        try:
            namespace['projected_world'](relative, old, actual, selected)
        except ValueError as error:
            reject_cases.append({'case': name, 'rejected': True, 'error': str(error)})
        else:
            raise AssertionError('counterexample accepted: ' + name)

    assert len(checks['projection_mutations']) == 8
    assert all(row['rejected'] is True for row in checks['projection_mutations'])
    assert initial['exit_code'] == 1 and 'CPU' in initial['scope']
    for name, digest in initial['original_sources'].items():
        assert sha(read(PROPOSAL / name)) == digest
    old_serialized = flatten(ET.fromstring(read(PROPOSAL / 'open_old_normalize.stdout')))
    new_serialized = flatten(ET.fromstring(read(PROPOSAL / 'open_proposed_normalize.stdout')))
    assert '/physics/ode/solver/iters' not in old_serialized
    assert new_serialized['/physics/ode/solver/iters'] == '150'
    original_parser = read(PROPOSAL / 'normalize_physics.cpp')
    second_parser = read(PROPOSAL / 'attempt02/normalize_physics.cpp')
    addition = (b'  // Match ODEPhysics::Load: instantiate the optional ODE schema parent.\n'
                b'  physics->GetElement("ode");\n')
    assert second_parser.replace(addition, b'', 1) == original_parser
    assert len(review['cpu_receipts']) == 4
    for receipt in review['cpu_receipts']:
        assert sha(read(receipt['path'])) == receipt['sha256']

    # Verify all referenced proposal/canonical inputs again; never read active run data.
    assert all(sha(Path(path).read_bytes()) == digest for path, digest in bound.items())
    report = {
        'schema': 'mr3-conditional-world-iters150-independent-review-v1',
        'passed': True, 'conditional_only': True, 'selected_iters150': False,
        'native_result_read_or_assumed': False, 'canonical_edits': 0,
        'source_freeze_context': actual_head,
        'proposal_manifest_sha256': bound[str(PROPOSAL / 'manifest_v1.json')],
        'manifest_entries_verified': 124, 'manifest_raw_bytes_verified': raw_bytes,
        'actual_six_sources_still_w7': True, 'six_file_projection': rows,
        'independent_counterexamples': reject_cases,
        'schema_scope': ('43 fields per scene, not 43 independent tests. '
                         'Inactive engine branches are schema-only. No native getter readback.'),
        'truth_mask_scope': ('Reviewed saved actual production loader/truth-builder CPU code '
                             'and hash-bound receipts; did not rerun the three raster checks.'),
        'initial_failure_scope': ('Preserved exit1 CPU serializer normalization error: '
                                  'optional ODE parent absent in old serialization. '
                                  'Attempt02 adds explicit parent instantiation; no native failure.'),
        'blocking_findings': [],
        'required_if_separately_selected': [
            'Keep actual world and task metadata as one identity; task loader unchanged.',
            'Auditor projection restricted to six fixed paths, fixed reviewed actual SHA pins, '
            'independently retrieved immutable W7 normative bytes; all other machine files exact.',
            'Derive each task new world SHA from its matching exact actual world; do not trust '
            'a caller-supplied new_world_sha or caller-supplied normative bytes as authority.',
            'Record actual source/install world and task SHA; create fresh geometry/static '
            'receipts and retain old receipts without relabeling.',
            'Version ENV/source and explicit reviewed audit pins plus future plan/sourcepack; '
            'do not refresh original W7 digests or change validation/test data or schedule.',
            'Separately design/review native effect/source/owned PID/library proof; parser '
            'schema cannot prove active private solver dispatch or later tick invariance.',
            'Fresh one-freeze four-stage matrix under unchanged original gates; CPU '
            'proposal does not establish dynamics repair, P2A.0 acceptance, or P2A95% policy.'
        ],
        'author_check_claims': {'projection_positive_worlds': 3,
                                'projection_positive_metadata': 3,
                                'projection_rejected_mutations': 8,
                                'truth_masks_unchanged': 3,
                                'schema_fields_per_scene': [43, 43, 43]},
        'not_repeated': ['SDFormat executable builds', 'author complete check programs',
                         'production truth raster checks', 'ROS', 'DDS', 'native', 'formal readers'],
        'git_read_commands': git_commands,
        'inputs_sha256': bound, 'inputs_stable_before_after': True,
        'execution': {'argv': sys.argv, 'cwd': str(Path.cwd()),
                      'environment': {key: os.environ.get(key) for key in
                                      ('PYTHONNOUSERSITE', 'PYTHONDONTWRITEBYTECODE')},
                      'wall_seconds': time.monotonic() - started,
                      'script_sha256': sha(Path(__file__).read_bytes())},
    }
    OUTPUT.write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + '\n')
    print(json.dumps({'passed': True, 'output': str(OUTPUT),
                      'sha256': sha(OUTPUT.read_bytes()), 'conditional_only': True,
                      'six_file_projection': 6, 'manifest_entries_verified': 124,
                      'independent_counterexamples_rejected': len(reject_cases)}))


if __name__ == '__main__':
    main()
