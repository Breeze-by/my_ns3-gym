"""One streaming closed-log first-goal causal diagnostic; no native/ROS calls."""
from collections import Counter
import hashlib
import json
import math
from pathlib import Path

ROOT = Path('/home/zhuyulab/ns3-workspace')
EP = ROOT / ('ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/'
             'mr3_p2a0_20261017_v15_interface/worker0/episode001_open_101')
OUT = Path('/tmp/mr3_p2a0_v15_interface_first_phase_v1')


def binding(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}, raw


def main():
    OUT.mkdir(exist_ok=False)
    with (EP / 'transitions.jsonl').open() as stream:
        release = json.loads(next(stream))['info']['release_time_ns']
    adapter_proof, adapter_raw = binding(EP / 'adapter.jsonl')
    adapter_selected, initial_goal = [], None
    for number, line in enumerate(adapter_raw.splitlines(), 1):
        row = json.loads(line)
        if row['kind'] == 'native_send' and row['payload']['robot'] == 'tb1' and initial_goal is None:
            initial_goal = row['payload']['pose']
            adapter_selected.append({'source_line': number, 'row': row})
        if row['kind'] == 'observation' and 0 <= row['payload']['task_elapsed_sec'] <= 10:
            robot = next(item for item in row['payload']['robots'] if item['name'] == 'tb1')
            adapter_selected.append({'source_line': number, 'kind': 'observation',
                                     'task_elapsed_sec': row['payload']['task_elapsed_sec'],
                                     'sequence': row['payload']['sequence'], 'tb1': robot})
    assert initial_goal is not None
    path = EP / 'motion_safety.jsonl'
    before = path.stat()
    digest, requests, actuals, decisions = hashlib.sha256(), {}, {}, []
    failure_rows = []
    with path.open('rb') as stream:
        for number, line in enumerate(stream, 1):
            digest.update(line)
            row = json.loads(line)
            payload = row['payload']
            if row['kind'] in ('settled_turn_model_failure', 'normal_control_model_invalid',
                                'invalid_received_states', 'control_failure', 'failure'):
                failure_rows.append({'source_line': number, 'row': row})
            if payload.get('robot') != 'tb1':
                continue
            if row['kind'] == 'raw_request':
                requests[payload['request']['sequence']] = (number, row)
            elif row['kind'] == 'actual_cmd_vel':
                actuals[payload.get('observed_decision_sequence')] = (number, row)
            elif row['kind'] == 'decision':
                elapsed = (payload['clock_ns'] - release) / 1e9
                if 0 <= elapsed <= 10 and payload.get('phase_kind') != 'stop':
                    decisions.append((number, row))
    after = path.stat()
    assert (before.st_ino, before.st_size, before.st_mtime_ns) == (
        after.st_ino, after.st_size, after.st_mtime_ns)
    compact, original_rows = [], []
    for number, row in decisions:
        payload = row['payload']
        own, request, decision = payload['own_state'], payload['request'], payload['decision']
        raw = requests.get(request['sequence']) if request else None
        actual = actuals.get(payload['decision_sequence'])
        if request is not None:
            assert raw is not None and raw[1]['payload']['request'] == request
        assert actual is not None
        assert [actual[1]['payload']['twist']['linear']['x'],
                actual[1]['payload']['twist']['angular']['z']] == decision['output']
        bearing = math.atan2(initial_goal['y'] - own['y'], initial_goal['x'] - own['x'])
        error = math.atan2(math.sin(bearing - own['yaw']), math.cos(bearing - own['yaw']))
        compact.append({'source_line': number, 'record_sequence': row['record_sequence'],
                        'task_elapsed_sec': (payload['clock_ns'] - release) / 1e9,
                        'decision_sequence': payload['decision_sequence'],
                        'raw_request_line': raw[0] if raw else None,
                        'actual_receipt_line': actual[0],
                        'request': request, 'output': decision['output'], 'reason': decision['reason'],
                        'own': {key: own.get(key) for key in ('x', 'y', 'yaw', 'v', 'w',
                                'source_stamp', 'odom_source_stamp', 'planar_speed_mps', 'settled_turn')},
                        'direct_goal_bearing_rad': bearing,
                        'direct_goal_angle_error_rad': error,
                        'direct_goal_scope': 'Geometric direct target vector, NOT recorded Nav2 sampled-path point.',
                        'near_peer_checks': decision.get('near_peer_checks'),
                        'component_filter': decision.get('component_filter')})
        if raw:
            original_rows.append({'source_line': raw[0], 'row': raw[1]})
        original_rows.extend([{'source_line': number, 'row': row},
                              {'source_line': actual[0], 'row': actual[1]}])
    first_forward = next((row for row in compact if row['request'] and row['request']['v']), None)
    first_near_threshold = next((row for row in compact if abs(row['direct_goal_angle_error_rad']) <= .5), None)
    timeline = []
    for tick in range(21):
        target = tick / 2
        row = min(compact, key=lambda item: abs(item['task_elapsed_sec'] - target))
        timeline.append(row)
    parameter_proof, parameter_raw = binding(EP / 'actual_nav2_parameters.json')
    params = json.loads(parameter_raw)
    controllers = {node['node']: {item['name']: {'type': item['type'], 'value': item['value']}
                                 for item in node['typed_parameters']
                                 if item['name'] in ('FollowPath.plugin', 'FollowPath.primary_controller',
                                     'FollowPath.angular_dist_threshold', 'FollowPath.angular_disengage_threshold',
                                     'FollowPath.forward_sampling_distance', 'FollowPath.closed_loop',
                                     'FollowPath.rotate_to_heading_angular_vel', 'FollowPath.max_angular_accel')}
                   for node in params['nodes'] if node['node'].endswith('/controller_server')}
    shim = ROOT / ('ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/'
                   '20261017_mr3_p2a0_v13/independent/mr3_v13_upstream_rotation_shim_1_1_20.cpp')
    shim_proof, shim_raw = binding(shim)
    assert shim_proof['sha256'] == 'e06b6c6a64853334b20398f750c517018c17a2017bec864c626726fcea261288'
    native_log_proof, native_log_raw = binding(EP / 'launch.log')
    debug_markers = ('rough heading', 'sampling point', 'Rotation Shim Controller')
    shim_messages = [{'source_line': i, 'text': line}
                     for i, line in enumerate(native_log_raw.decode().splitlines(), 1)
                     if any(text in line for text in debug_markers)]
    report = {'schema': 'mr3-v15-first-phase-closed-causal-diagnostic-v1',
              'source': {'path': str(path), 'bytes': before.st_size, 'sha256': digest.hexdigest(),
                         'stable_before_after': True},
              'adapter': adapter_proof, 'actual_parameters': parameter_proof,
              'official_1_1_20_source': shim_proof, 'launch_log': native_log_proof,
              'release_ns': release, 'initial_goal': initial_goal,
              'first_forward_request': first_forward,
              'first_direct_goal_error_at_most_half_radian': first_near_threshold,
              'half_second_timeline': timeline, 'all_first_phase_decision_count': len(compact),
              'reasons': dict(Counter(row['reason'] for row in compact)),
              'nonzero_forward_request_decisions': sum(bool(row['request'] and row['request']['v']) for row in compact),
              'nonzero_forward_output_decisions': sum(row['output'][0] != 0 for row in compact),
              'controller_actual_typed_parameters': controllers,
              'native_shim_branch_messages': shim_messages, 'failure_rows': failure_rows,
              'scope': 'One closed 252MB motion stream; original requests/actual local topic '
                       'receipts exactly bound. No ModelStates, controls, formal rerun, native, '
                       'or Git writes. Goal-bearing differences do not identify actual sampled '
                       'Nav2 path heading; no shim branch/path point telemetry in inspected logs.'}
    (OUT / 'first_phase_decisions.jsonl').write_text(''.join(
        json.dumps(row, separators=(',', ':'), allow_nan=False) + '\n' for row in compact))
    (OUT / 'selected_original_motion_rows.jsonl').write_text(''.join(
        json.dumps(row, separators=(',', ':'), allow_nan=False) + '\n' for row in original_rows))
    (OUT / 'adapter_selected.json').write_text(json.dumps(adapter_selected, indent=2, allow_nan=False) + '\n')
    (OUT / 'review.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'directory': str(OUT), 'first_forward_t': first_forward['task_elapsed_sec'],
                      'first_forward_yaw': first_forward['own']['yaw'],
                      'first_forward_direct_error': first_forward['direct_goal_angle_error_rad'],
                      'nonzero_forward_requests': report['nonzero_forward_request_decisions'],
                      'nonzero_forward_outputs': report['nonzero_forward_output_decisions'],
                      'shim_branch_messages': len(shim_messages)}))


if __name__ == '__main__':
    main()
