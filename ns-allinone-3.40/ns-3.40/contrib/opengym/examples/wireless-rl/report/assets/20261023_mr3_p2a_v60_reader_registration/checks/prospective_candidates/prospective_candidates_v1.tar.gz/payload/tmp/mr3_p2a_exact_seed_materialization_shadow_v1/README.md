# Exact-seed auxiliary 一次 materialization：未应用 shadow

精确 E 基准：`935b466bd076002afdfe161b55a508938de2a8b0`。仓库无改动，未读取任何 V60 科学原件或活动结果，未运行 reader/native/World。V60 原 FAIL 不变。本候选没有 canonical CPU、新冻结资格或容量信用，不能自动进入 pilot/final。

`seed_only.patch` 只为下一显式版本准备。固定 profile 为 `mr3-same-activity-exact-input-reuse-v1`，由下一活动的 prepare 源码常量传给 `reach_preparation.build_plan(audit_resource_profile=...)`；没有新增 CLI 开关、任意结果路径接口或其它 reader cache。未生成任何正式 plan。

## 五个文件

- `exact_seed_materialization.py`：新专用 helper，只接受 plan 内精确的 input 叶、episode 与回执；校验来源及完整字节闭包。
- `audit_seed_inputs.py`：原数学保持；只在显式 `--plan` 分支记录请求路径→实际 encoded 原件映射、原判定时的 archive 成员集合及 origin seal。旧默认不输出这些字段。
- `audit_reach_preparation.py`：原 `audit_archives` 仍先真实执行；仅其 exact-seed 辅助子判据可引用既有叶。full 本身仍由原 Runner 真实等待。
- `reach_preparation.py`：固定 plan profile、精确输入 argv、full→input-leaves DAG 及同一 source inventory；新 profile 的原 Runner 环境额外移除 PYTHONHOME，保持 HOME。
- `reach_policy_chain.py`：只一行把 plan profile 交给同一 executor，维持政策阶段相同的固定环境分支；不增加任何 reader 复用。

## 成功与失败路径

interface/reset 必须有完整一一对应的 input 叶，固定 `/usr/bin/python3 -B -m mr3_learning.audit_seed_inputs --episode ... --output ... --plan ...`。full 等真实叶完成，核对同活动 plan SHA、run、stage、episode、epoch、freeze、规则、当前 Git/source、科学 argv、环境指纹、解释器、已加载 Python 文件及原 system 输入进程实际 regular file-backed 映射文件（含 OpenBLAS/loader，记录 literal/resolved/dev/inode/SHA；deleted/不可核命名映射拒绝）、原结果和原回执 SHA。原回执必须来自实际 `subprocess_waited`/rc0，真实 PID/start 已保存且该叶身份当前已退出；存活的活动 coordinator 不被虚称已退出。

每次引用仍对全部 bound encoded 原路径做完整 SHA/bytes 校验，核对 plain/gzip 优先解析未变，核对原判定时 snapshots/maps 的精确成员集合，并在 verdict 前复核输入/源码/plan。inode/mtime 只用于发现单次哈希中的修改，从不代替 SHA。原件、引用或来源有错直接 FAIL，不启动新 helper 修复。

命中结果明确为 `exact_seed_execution.execution_kind=verified_same_activity_fact`，携带 `origin_result`、`origin_receipt` 原路径/SHA/bytes、原 PID/start 与原执行类型；仅写当前 validation 时间，不捏造新的子进程、`actual_waited` 或新的原数学执行时间。

terminal/deadline 及 plan 注册的 minimum/pilot/validation 没有上游 input 叶，明确为 `not_applicable_actual_helper`，继续原 system Python helper 的实际运行/实际 wait。这与“应当有叶却缺失”严格分开。未知活动目录或 profile 拒绝。当前 E 的旧叶结果没有新 origin seal/argv/env，绝不被本 profile 接受。

原 archive、runtime、cadence、FIFO、information、physics/readiness 及最终 30 必要角色与合取均保留。此候选不试图把不同 reader 判据相互替代。

## 验证范围

5 个 shadow 源 AST 通过；统一 patch 对 clean E 的 `git apply --check` rc0，仅检查、未应用。最终 v2 的 10 项小型人工关联契约实际 tool 84661 reap rc0，wrapper 真实 wall `9.4125119` 秒，7 份源 before/after/current 相同，runner/child 两个保存身份 freshgone。

**这些 fixture 的科学 PASS、来源 receipt/PID 值是明确标注的人工模型。** 它们只测链接契约接受/拒绝，不是 reader 数学运行或真实原件来源资格。CPU wrapper 自身的实际等待回执保存在 `checks/provisional_contract_cpu_v2`，不能与模型中的 origin receipt 混淆。测试覆盖正关联、原件变化、plain 优先变化、新 archive 成员、源变化/缺项、坏回执/原 FAIL、env/epoch/freeze、活 child/缺回执、缺资格叶、明确 not-applicable/旧默认。v2 的同一 not-applicable 测试包含真实 PPO `policy_run/native/roundXXXX/worker/episode` 布局及多一层目录反例，绝不接受任意 descendant。

## 合并与正式准入

不可把这些文件整份覆盖其它候选：outward-cancel-v2 同时修改 `reach_preparation.py` 的 workload/version/validator 和 `audit_reach_preparation.py` 的唯一版本逆投影；须把两套显式分支合并。根的未来容量 gate/政策 driver 可能也修改 `reach_policy_chain.py`，本候选只保留其 profile 传递一行。当前 helper 的 native profile 取证投影不占这些源。`audit_seed_inputs.py`/新增专用 helper 与 probe shadow 无文件冲突。最终旧/新 SHA 与源位置见 `static_review_v2.json`。独立短审在初版发现 PPO 布局阻断，并建议补实际 regular 映射 pin；两项已进入 v2。初版 10 项人工 CPU 本身 PASS/3.666374497 秒，但没有覆盖该真实路径；其代码/patch/docs/回执/恢复快照完整保留，仅作历史，不覆盖最终源码。

根在 V60 真闭合、V61 固定原始五流取证之后，决定是否一并采用。必要工作仍包括：在下一活动 prepare 固定该 profile；把新 module/所有修改源及新增 canonical 测试纳入 source recovery/CPU 分类；合并后重跑真正的 seed full-snapshot 数学、plan/DAG/executor/default/PPO-not-applicable/wrapper-no-fallback 测试及双环境 readiness；新 source freeze 后完整 12EP/30 资格，不复用旧 E 科学信用。

输入哈希仍全读，实际收益未知。账按真实完整 parent union，不撤销原叶费用、不伪造新 wait、不把 nested 加两次。候选不能修复真实 B 的 3.031s 停车超限，也不替代 native 吞吐 profile；最终实际容量 gate 仍 False。
