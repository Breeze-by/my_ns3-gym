"""Read only completed posthoc summary; descriptive current-box/cached-point comparison."""
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import time
import xml.etree.ElementTree as ET

D=Path(__file__).parent;P=D/'analysis_v1/summary.json'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def stat(path):
    s=path.stat();return [s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
def subtract(a,b):return [x-y for x,y in zip(a,b)]
def rotate(q,v):
    w,x,y,z=q;n=w*w+x*x+y*y+z*z
    u=[x,y,z]
    cross=lambda a,b:[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
    uv=cross(u,v);uuv=cross(u,uv)
    return [v[i]+2*(w*uv[i]+uuv[i])/n for i in range(3)]
def local(pose,point):
    q=pose['quaternion_wxyz'];return rotate([q[0],-q[1],-q[2],-q[3]],subtract(point,pose['position_xyz']))
def extent(values):return [min(values),max(values)] if values else None

start=time.monotonic();before=stat(P);raw=P.read_bytes();data=json.loads(raw);robots={}
for robot,value in data['robots'].items():
    scans=value['scan_summaries'];name=robot+'::base_link::base_collision';hits=[r for r in scans if r['current_valid_hit_names'].get(name,0)]
    first=hits[0]['ray']['measurement_time_ns'] if hits else None
    tail=[r for r in scans if first is not None and r['ray']['measurement_time_ns']>=first]
    outside=Counter();maxexcess=[];zexcess=[];localz=[];bodypositions=[];examples=[];count=0
    for report in scans:
        for beam in report['near_raw_beams']:
            if not beam['current_hit_name_valid'] or beam['cached_collision_name']!=name:continue
            geometry=beam['collision_current_geometry'];point=beam['hit_point_from_cached_cast']
            if not geometry.get('available'):outside['geometry_unavailable']+=1;continue
            node=ET.fromstring(geometry['collision_sdf']);size=[float(v) for v in node.findtext('geometry/box/size').split()]
            xyz=local(geometry['world_pose_current'],point);excess=[abs(v)-s/2 for v,s in zip(xyz,size)]
            flags=[v>0 for v in excess];outside['points']+=1;outside['outside_current_box']+=any(flags)
            for axis,flag in zip('xyz',flags):outside['outside_'+axis]+=flag
            maxexcess.append(max(excess));zexcess.append(excess[2]);localz.append(xyz[2]);bodypositions.append(geometry['parent_link_world_pose_current']['position_xyz'])
            if len(examples)<3:examples.append({'ray':report['ray'],'beam_index':beam['index'],'range':beam['range'],
              'name':name,'cached_point':point,'current_collision_world_pose':geometry['world_pose_current'],
              'box_size':size,'point_in_current_box_frame':xyz,'axis_excess_m':excess,
              'world_clock_interval_ns':[report['world_clock_before_ns'],report['world_clock_after_ns']],
              'measurement_stable':report['cached_measurement_stable_during_read']})
            count+=1
    nearpos=[]
    if bodypositions:
        anchor=bodypositions[0];nearpos=[math.sqrt(sum((p[i]-anchor[i])**2 for i in range(3))) for p in bodypositions]
    poses=value['public_processed_poses'];maps=value['maps']
    first_mapping=[]
    for m in maps:
        linked=[p for p in m['processed_endpoints_before_callback'] if p['karto_round']['value']==100 and p.get('cached_source') and p['cached_source'].get('cached_collision_name')==name]
        if linked:
            first_mapping={'map_reference':m['CDR_reference'],'map_header_ns':m['header_ns'],
              'map_data_sha256':m['data_sha256'],'own_base_named_endpoint_count':len(linked),'first_5':linked[:5]};break
    robots[robot]={'ray_scans':len(scans),'raw_scans':value['raw_scans'],'comparisons':value['comparisons'],
      'own_base_hit_scans':len(hits),'first_own_hit_ns':first,'last_own_hit_ns':hits[-1]['ray']['measurement_time_ns'] if hits else None,
      'scans_from_first_hit':len(tail),'later_scans_without_own_hit':[r['ray']['measurement_time_ns'] for r in tail if not r['current_valid_hit_names'].get(name,0)],
      'first_scan_own_hit_beams':scans[0]['current_valid_hit_names'].get(name,0),'last_scan_own_hit_beams':scans[-1]['current_valid_hit_names'].get(name,0),
      'all_valid_own_base_hit_beams':value['all_current_valid_hit_names'].get(name,0),
      'near_raw_less_point2_own_beams':value['near_raw_current_valid_hit_names'].get(name,0),
      'all_scans_cache_measurement_stable':all(r['cached_measurement_stable_during_read'] for r in scans),
      'world_start_minus_measurement_ns_range':extent([r['world_clock_before_ns']-r['ray']['measurement_time_ns'] for r in scans]),
      'world_within_callback_delta_ns_range':extent([r['world_clock_after_ns']-r['world_clock_before_ns'] for r in scans]),
      'cached_near_hit_vs_current_SDF_box':{'counts':dict(outside),'max_axis_excess_range_m':extent(maxexcess),
        'z_axis_excess_range_m':extent(zexcess),'local_z_range_m':extent(localz),'current_parent_position_drift_from_first_m':extent(nearpos),
        'examples':examples,'scope':'Descriptive cached hitpoint vs current getter/SDF box; distinct times, not native dGeom readback or continuous-motion theorem.'},
      'processed_pose_count':len(poses),'processed_pose_source_ns':[p['source_ns'] for p in poses],
      'map_count':len(maps),'distinct_map_data':len({m['data_sha256'] for m in maps}),
      'first_public_pose':poses[0] if poses else None,'first_own_named_map100_association':first_mapping}
assert stat(P)==before
output={'scope':'Completed-data posthoc summary only, no newnative or frozenacceptance; world/currentbox non-atomic limitation retained.',
        'source':{'path':str(P),'sha256':sha(raw),'bytes':len(raw),'stat_before':before,'stat_after':stat(P)},
        'robots':robots,'wall_seconds':time.monotonic()-start,'source_sha256':sha(Path(__file__).read_bytes())}
out=D/'box_persistence_summary_v1.json';out.write_text(json.dumps(output,indent=2,allow_nan=False)+'\n')
print(json.dumps({r:{k:v[k] for k in ('ray_scans','own_base_hit_scans','first_own_hit_ns','last_own_hit_ns','later_scans_without_own_hit','last_scan_own_hit_beams','processed_pose_count','map_count','distinct_map_data')} for r,v in robots.items()}))
print(json.dumps({r:v['cached_near_hit_vs_current_SDF_box'] for r,v in robots.items()}))
