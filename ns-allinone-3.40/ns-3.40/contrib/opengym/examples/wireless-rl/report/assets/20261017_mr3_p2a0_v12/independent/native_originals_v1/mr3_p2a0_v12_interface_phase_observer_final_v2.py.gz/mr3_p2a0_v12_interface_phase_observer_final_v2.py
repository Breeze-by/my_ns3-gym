"""Independent final observation facts; no formal auditor invocation or native control."""
import hashlib
import json
from pathlib import Path
import re
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
RUN = ROOT / ('ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/'
              'mr3_p2a0_20261017_v12_interface')
EPISODE = RUN / 'worker0/episode001_open_101'
LAUNCH = Path('/tmp/mr3_p2a0_v12_interface_launch.json')
OUT = Path('/tmp/mr3_p2a0_v12_interface_phase_observer_final_v2.json')
FREEZE = '6b1b4a0108351f5bfb70ec0c96ba895248d4f7a8'


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def saved(value, origin, output):
    if isinstance(value, dict):
        if type(value.get('pid')) is int and type(value.get('start_ticks')) is int:
            key = value['pid'], value['start_ticks']
            record = output.setdefault(key, {'identity': value, 'origins': []})
            record['origins'].append(origin)
        for key, item in value.items():
            saved(item, origin + '.' + str(key), output)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            saved(item, origin + '[' + str(index) + ']', output)


def fresh(identity):
    path = Path('/proc') / str(identity['pid']) / 'stat'
    try:
        raw = path.read_text()
        fields = raw[raw.rfind(')') + 2:].split()
        return {'pid': identity['pid'], 'start_ticks': int(fields[19]), 'state': fields[0]}
    except FileNotFoundError:
        return None


launch = json.loads(LAUNCH.read_text())
summary = json.loads((EPISODE / 'summary.json').read_text())
nav = json.loads((EPISODE / 'nav2_shutdown.json').read_text())
stop = json.loads((EPISODE / 'native_stop.json').read_text())
worker = json.loads((RUN / 'worker0/worker_summary.json').read_text())
transitions = [json.loads(line) for line in (EPISODE / 'transitions.jsonl').open()]
physical = [json.loads(line) for line in (EPISODE / 'physics.jsonl').open()]
steps = [row for row in transitions if row['kind'] == 'step']
identities = {}
sources = [LAUNCH, *sorted(RUN.glob('worker*/*.json')),
           *sorted(EPISODE.glob('*.json'))]
for path in sources:
    saved(json.loads(path.read_text()), str(path), identities)
sources += [EPISODE / name for name in (
    'control_phase_worker.jsonl', 'drive_phase_worker.jsonl', 'physics.jsonl',
    'transitions.jsonl', 'worker.log', 'launch.log')]
proof = {str(path): sha(path) for path in sources}
checked = time.monotonic_ns()
checks = []
for identity in identities.values():
    actual = fresh(identity['identity'])
    checks.append({**identity, 'actual': actual, 'saved_identity_gone': actual is None
                   or actual['start_ticks'] != identity['identity']['start_ticks']})
text = (EPISODE / 'launch.log').read_text(errors='replace')
report = {
    'schema': 'mr3-v12-independent-phase-observation-final-v1',
    'observation_complete': launch.get('status') == 'completed', 'freeze': FREEZE,
    'scope': 'Saved final facts and fresh dynamic identity absence only; '
             'not the formal closure/FIFO/physics/source or overall stage verdict',
    'source_proof': proof, 'launcher_returncode': launch.get('returncode'),
    'actual_reset_records': sum(row['kind'] == 'reset' for row in transitions),
    'actual_step_records': len(steps), 'sampled_dt_sec': sum(row['info']['dt'] for row in steps),
    'release_time_ns': transitions[0]['info']['release_time_ns'],
    'final_physical_time_ns': physical[-1]['end_time_ns'],
    'worker_forced_cleanup': any(row['forced_shutdown'] for row in worker['shutdown_receipts']),
    'worker_returncodes': [row['worker_returncode'] for row in worker['shutdown_receipts']],
    'worker_log_empty': (EPISODE / 'worker.log').stat().st_size == 0,
    'infrastructure_failure_exists': (EPISODE / 'infrastructure_failure.json').exists(),
    'failed_sample_exists': (EPISODE / 'failed_sample.json').exists(),
    'native_shutdown_returncode': stop.get('returncode'),
    'native_server_clean_exit_recorded': stop.get('server_clean_exit_recorded'),
    'nav2_shutdown_success': nav.get('success'),
    'managed_nodes_finalized': sum(check.get('state', {}).get('id') == 4
                                   for robot in nav.get('robots', [])
                                   for check in robot.get('states', [])),
    'native_failures': summary.get('native_failures'), 'worker_error': worker.get('error'),
    'cleanup_wall_sec': summary.get('cleanup_wall_sec'),
    'launch_text_started_process_lines': len(re.findall('process started with pid', text)),
    'launch_text_clean_exit_lines': len(re.findall('process has finished cleanly', text)),
    'owned_identity_union_count': len(checks), 'no_fixed_identity_count_gate': True,
    'owned_identity_absence_checked_wall_monotonic_ns': checked,
    'owned_saved_identity_checks': checks,
    'all_saved_identities_gone': bool(checks) and all(c['saved_identity_gone'] for c in checks),
    'source_bytes_unchanged_during_observation': proof == {str(p): sha(p) for p in sources},
    'prior_observer_fact_correction': {
        'path': '/tmp/mr3_p2a0_v12_interface_phase_observer_final_v1.json',
        'sha256': sha(Path('/tmp/mr3_p2a0_v12_interface_phase_observer_final_v1.json')),
        'scope': 'v1 used absent robots.checks and worker.forced_cleanup paths; v2 reads '
                 'actual robots.states and shutdown_receipts.forced_shutdown; no native change'},
    'observer_correction_receipt': '/tmp/mr3_p2a0_v12_interface_observer_correction_v1.json',
}
with OUT.open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: report[key] for key in ('observation_complete', 'actual_step_records',
    'native_shutdown_returncode', 'managed_nodes_finalized', 'owned_identity_union_count',
    'all_saved_identities_gone', 'source_bytes_unchanged_during_observation')}))
