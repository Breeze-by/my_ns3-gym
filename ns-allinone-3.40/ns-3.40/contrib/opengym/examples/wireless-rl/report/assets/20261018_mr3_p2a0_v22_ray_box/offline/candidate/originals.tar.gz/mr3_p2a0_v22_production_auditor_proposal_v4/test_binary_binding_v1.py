"""Real final ELF/archive bytes, exact proposed helper; Git freeze I/O is substituted.
No participant, simulator, SDK build or dynamic library loading is performed.
"""
import ast
import copy
import gzip
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/zhuyulab/ns3-workspace')
TREE = ast.parse((HERE / 'proposed_audit_ppo.py').read_text())
NAMES = {'ROS', 'RAY_BOX_SOURCE_PINS', 'RAY_BOX_LIBRARY_SPEC'}
FUNCTIONS = {'require', 'sha', 'verify_frozen_pins', 'verify_ray_box_library'}
BODY = [node for node in TREE.body if (
    isinstance(node, ast.FunctionDef) and node.name in FUNCTIONS) or (
    isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id in NAMES for t in node.targets))]

class BinaryBinding(unittest.TestCase):
    def setUp(self):
        self.freeze = 'e' * 40
        self.ns = {'Path': Path, 'hashlib': hashlib, 'gzip': gzip, 'json': json,
                   'subprocess': SimpleNamespace(check_output=self.git)}
        exec(compile(ast.Module(body=copy.deepcopy(BODY), type_ignores=[]),
                     str(HERE / 'proposed_audit_ppo.py'), 'exec'), self.ns)
        self.spec = self.ns['RAY_BOX_LIBRARY_SPEC']

    def git(self, argv, cwd):
        self.assertEqual(Path(cwd), ROOT)
        self.assertEqual(argv[:2], ['git', 'show'])
        revision, relative = argv[2].split(':', 1)
        self.assertEqual(revision, self.freeze)
        return (ROOT / relative).read_bytes()

    def review(self):
        return self.ns['verify_ray_box_library'](ROOT, self.freeze)

    def changed_read(self, path, transform):
        original = Path.read_bytes
        def read(selected):
            raw = original(selected)
            return transform(raw) if str(selected) == str(path) else raw
        return patch.object(Path, 'read_bytes', read)

    def test_actual_final_elf_archive_and_old_four_libraries_bound(self):
        proof = self.review()
        self.assertEqual(set(proof), {self.spec[key]['path'] for key in ('receipt', 'build', 'archive')})
        details = proof[self.spec['receipt']['path']]
        self.assertEqual(details['installed_library_sha256'],
                         '7be79c7f3d2cac53a9d1692aa868d91d4b9977e2b7541203ce4ffe90c605a08f')
        self.assertEqual(details['installed_library_bytes'], 389312)
        self.assertEqual(len(details['compiled_source_sha256']), 3)

    def test_installed_elf_changed_rejected(self):
        with self.changed_read(ROOT / self.spec['library']['path'], lambda raw: raw[:-1] + bytes([raw[-1] ^ 1])):
            with self.assertRaisesRegex(ValueError, 'actual installed ELF differs'):
                self.review()

    def test_archive_changed_rejected(self):
        with self.changed_read(ROOT / self.spec['archive']['path'], lambda raw: raw + b'x'):
            with self.assertRaisesRegex(ValueError, 'binary custody source freeze/worktree'):
                self.review()

    def test_actual_ode_changed_rejected(self):
        with self.changed_read(ROOT / self.spec['ode_library']['path'], lambda raw: raw + b'x'):
            with self.assertRaisesRegex(ValueError, 'ODE/unchanged library bytes differ'):
                self.review()

    def test_any_unchanged_library_change_rejected(self):
        for record in self.spec['unchanged_libraries'].values():
            with self.subTest(path=record['path']), self.changed_read(ROOT / record['path'], lambda raw: raw + b'x'):
                with self.assertRaisesRegex(ValueError, 'ODE/unchanged library bytes differ'):
                    self.review()

    def test_false_build_receipt_cannot_be_substituted(self):
        with self.changed_read(ROOT / self.spec['receipt']['path'], lambda raw: raw.replace(b'"passed": true', b'"passed":false', 1)):
            with self.assertRaisesRegex(ValueError, 'binary custody source freeze/worktree'):
                self.review()

if __name__ == '__main__':
    unittest.main(verbosity=2)
