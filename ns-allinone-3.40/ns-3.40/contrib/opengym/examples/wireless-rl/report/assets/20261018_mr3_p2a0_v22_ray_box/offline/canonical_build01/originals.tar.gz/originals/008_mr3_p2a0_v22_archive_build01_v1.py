"""Preserve the completed first canonical build before the readback-only delta."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
import time

ROOT=Path('/home/zhuyulab/ns3-workspace')
ROS=ROOT/'ros2_ws/ros2-multi-robot-automap'
PKG=ROS/'src/multi_robot'
OUT=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v22_ray_box/offline/canonical_build01'
assert not OUT.exists()
start=time.monotonic()
execution=Path('/tmp/mr3_p2a0_v22_canonical_build_v1/execution.json')
d=json.loads(execution.read_text()); assert d['passed'] and d['actual_installed_probe_passed']
files=[p for p in execution.parent.iterdir() if p.is_file() and p.name!='actual_installed_probe']
files.extend([Path('/tmp/mr3_p2a0_v22_canonical_build_v1.py'),Path(__file__),
 Path('/tmp/mr3_p2a0_v22_ray_box_corrector_proposal_v1/probe.cpp'),
 Path('/tmp/mr3_p2a0_v22_ray_box_corrector_proposal_v1/factory.cpp')])
files.extend(Path(x['path']) for x in d['sources_before'].values())
files.extend(Path(d[k]['path']) for k in ('new_target_flags','new_target_link'))
files=sorted(set(files))
entries=[]; buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as tar:
    for i,p in enumerate(files):
        raw=p.read_bytes(); v=p.stat()
        assert not raw.startswith(b'\x7fELF')
        name=f'originals/{i:03d}_{p.name}'
        info=tarfile.TarInfo(name); info.size=len(raw); info.mtime=0
        tar.addfile(info,io.BytesIO(raw))
        entries.append({'source':str(p),'member':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),
            'stat':[v.st_dev,v.st_ino,v.st_size,v.st_mtime_ns,v.st_ctime_ns]})
    lib=Path(d['installed_new_library']['path']); raw=lib.read_bytes()
    assert hashlib.sha256(raw).hexdigest()=='f9a252237e71db9ac762658288d9a2d6cdb997acd6ee1712d3002c3912748469'
    packed=gzip.compress(raw,mtime=0); assert gzip.decompress(packed)==raw
    info=tarfile.TarInfo('unused_actual_library.so.gz'); info.size=len(packed); info.mtime=0
    tar.addfile(info,io.BytesIO(packed))
encoded=gzip.compress(buffer.getvalue(),mtime=0)
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(encoded))) as tar:
    assert tar.getnames()==[x['member'] for x in entries]+['unused_actual_library.so.gz']
    for row in entries:
        raw=tar.extractfile(row['member']).read()
        assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
        p=Path(row['source']); v=p.stat()
        assert [v.st_dev,v.st_ino,v.st_size,v.st_mtime_ns,v.st_ctime_ns]==row['stat']
        assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
    assert hashlib.sha256(gzip.decompress(tar.extractfile('unused_actual_library.so.gz').read())).hexdigest()==d['installed_new_library']['sha256']
OUT.mkdir(parents=True)
(OUT/'originals.tar.gz').write_bytes(encoded)
result={'schema':'mr3-v22-canonical-build01-custody-v1','passed':True,
 'scope':'Completed first canonical build/actualSO pureCPU evidence, never native. Superseded only by prospective readback-only plugin delta; no geometry algorithm change.',
 'archive':'originals.tar.gz','archive_bytes':len(encoded),'archive_sha256':hashlib.sha256(encoded).hexdigest(),
 'files':entries,'original_count':len(entries),'original_bytes':sum(x['bytes'] for x in entries),
 'unused_library_raw_binding':d['installed_new_library'],'unused_library_gzip_bytes':len(packed),
 'excluded_actual_probe_executable':d['actual_installed_probe_executable'],
 'full_member_roundtrip_and_source_final_stat_sha':True,'wall_seconds':time.monotonic()-start}
(OUT/'manifest_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('passed','original_count','archive_bytes','archive_sha256','wall_seconds')}))
