"""Execute the exact proposed helper AST with only Git-object I/O substituted."""
import ast
import copy
import hashlib
import inspect
import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import textwrap
import unittest

HERE = Path(__file__).resolve().parent
SEALED = Path('/tmp/mr3_p2a0_v19_conditional_world_iters150_proposal_v1/attempt02')
SOURCE = (HERE / 'proposed_audit_ppo.py').read_text()
TREE = ast.parse(SOURCE)
NAMES = {'ROS', 'TASK_BASE_FREEZE', 'ENV_DOCUMENT_SHA256',
         'SOLVER150_WORLD_PINS', 'SOLVER150_TASK_PINS'}
FUNCTIONS = {'require', 'sha', 'verify_machine_task_file'}
BODY = [node for node in TREE.body if (
    isinstance(node, ast.FunctionDef) and node.name in FUNCTIONS) or (
    isinstance(node, ast.Assign) and any(
        isinstance(target, ast.Name) and target.id in NAMES for target in node.targets))]


class StrictMachineProjection(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.normative, self.actual = {}, {}
        self.git_calls = []
        self.ns = {'Path': Path, 'hashlib': hashlib,
                   'subprocess': SimpleNamespace(check_output=self.git_read)}
        exec(compile(ast.Module(body=copy.deepcopy(BODY), type_ignores=[]),
                     str(HERE / 'proposed_audit_ppo.py'), 'exec'), self.ns)
        for prefix, folder, extension in [
            ('src/multi_robot/worlds/', 'worlds', '.world'),
            ('src/multi_robot/config/mr3_p1a/', 'config', '.json')]:
            for scene in ('open', 'rooms', 'corridors'):
                basename = ('p1c_' if folder == 'worlds' else '') + scene + extension
                relative = self.ns['ROS'] + prefix + basename
                self.normative[relative] = (SEALED / 'old' / folder / basename).read_bytes()
                self.actual[relative] = (SEALED / 'proposed' / folder / basename).read_bytes()
                self.write(relative, self.actual[relative])
        self.freeze = 'e' * 40

    def write(self, relative, raw):
        path = self.root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)

    def git_read(self, argv, cwd):
        self.assertEqual(argv[:2], ['git', 'show'])
        self.assertEqual(Path(cwd), self.root)
        freeze, relative = argv[2].split(':', 1)
        self.git_calls.append((freeze, relative))
        if freeze == self.ns['TASK_BASE_FREEZE']:
            return self.normative[relative]
        self.assertEqual(freeze, self.freeze)
        return self.actual[relative]

    def invoke(self, relative):
        return self.ns['verify_machine_task_file'](self.root, self.freeze, relative)

    def world(self, scene='open'):
        return self.ns['ROS'] + 'src/multi_robot/worlds/p1c_' + scene + '.world'

    def config(self, scene='open'):
        return self.ns['ROS'] + 'src/multi_robot/config/mr3_p1a/' + scene + '.json'

    def mutate(self, relative, raw, *, refresh_internal_pin=False):
        self.actual[relative] = raw
        self.write(relative, raw)
        if refresh_internal_pin:
            name = 'SOLVER150_WORLD_PINS' if relative in self.ns['SOLVER150_WORLD_PINS'] else 'SOLVER150_TASK_PINS'
            # Deliberate simulated source mistake only: tests prove byte
            # projection still rejects even if a future editor repinned it.
            self.ns[name][relative] = hashlib.sha256(raw).hexdigest()

    def test_all_six_actual_sources_have_explicit_revision_not_raw_w7_credit(self):
        for relative in self.actual:
            with self.subTest(relative=relative):
                result = self.invoke(relative)
                self.assertEqual(result['sha256'], hashlib.sha256(self.actual[relative]).hexdigest())
                self.assertEqual(result['normative_sha256'], hashlib.sha256(self.normative[relative]).hexdigest())
                self.assertNotEqual(result['sha256'], result['normative_sha256'])
                self.assertIn('machine_revision', result)
                self.assertEqual(result['git_source'], self.freeze + ':' + relative)
                self.assertEqual(result['normative_source'], self.ns['TASK_BASE_FREEZE'] + ':' + relative)

    def test_config_independently_verifies_its_matching_actual_world(self):
        result = self.invoke(self.config('rooms'))
        world = self.world('rooms')
        self.assertEqual(result['actual_world'], {
            'path': world, 'sha256': hashlib.sha256(self.actual[world]).hexdigest()})
        self.assertIn((self.ns['TASK_BASE_FREEZE'], world), self.git_calls)
        self.assertIn((self.freeze, world), self.git_calls)

    def test_all_other_machine_files_retain_original_strict_bytes_and_proof(self):
        path = self.ns['ROS'] + 'src/multi_robot/config/mr3_p1a/protocol.json'
        raw = b'{"unchanged_legacy_fixture":true}\n'
        self.normative[path] = self.actual[path] = raw
        self.write(path, raw)
        self.assertEqual(self.invoke(path), {
            'sha256': hashlib.sha256(raw).hexdigest(), 'git_source': self.freeze + ':' + path,
            'normative_source': self.ns['TASK_BASE_FREEZE'] + ':' + path})
        self.actual[path] = b'{"unchanged_legacy_fixture":false}\n'
        self.write(path, self.actual[path])
        with self.assertRaisesRegex(ValueError, 'changed from accepted W7'):
            self.invoke(path)

    def test_source_freeze_and_worktree_sha_both_remain_mandatory(self):
        world = self.world()
        self.write(world, self.normative[world])
        with self.assertRaisesRegex(ValueError, 'source freeze/worktree SHA mismatch'):
            self.invoke(world)

    def test_additional_world_physics_and_geometry_rejected_even_with_repinned_test_constant(self):
        world = self.world()
        original = self.actual[world]
        changes = [original.replace(b'<iters>150</iters>', b'<iters>150</iters><sor>1.4</sor>'),
                   original.replace(b'>0.001<', b'>0.002<', 1),
                   original.replace(b'12.2 0.2 2', b'12.3 0.2 2', 1)]
        for raw in changes:
            with self.subTest(sha=hashlib.sha256(raw).hexdigest()):
                self.mutate(world, raw, refresh_internal_pin=True)
                with self.assertRaisesRegex(ValueError, 'world does not project exactly'):
                    self.invoke(world)

    def test_duplicate_solver_block_is_rejected_even_with_repinned_test_constant(self):
        world = self.world()
        original = self.actual[world]
        begin = original.index(b'      <ode>\n')
        end = original.index(b'      </ode>\n', begin) + len(b'      </ode>\n')
        block = original[begin:end]
        self.mutate(world, original.replace(block, block * 2), refresh_internal_pin=True)
        with self.assertRaisesRegex(ValueError, 'world does not project exactly'):
            self.invoke(world)

    def test_wrong_scene_world_is_rejected_even_with_repinned_test_constant(self):
        self.mutate(self.world(), self.actual[self.world('rooms')], refresh_internal_pin=True)
        with self.assertRaisesRegex(ValueError, 'world does not project exactly'):
            self.invoke(self.world())

    def test_task_numeric_extra_parameter_and_roi_changes_are_rejected(self):
        config = self.config()
        original = self.actual[config]
        changes = [original.replace(b'0.95', b'0.94', 1),
                   original.replace(b'-6.1', b'-6.2', 1),
                   original.replace(b'{\n', b'{\n  "extra_parameter": 1,\n', 1)]
        for raw in changes:
            with self.subTest(sha=hashlib.sha256(raw).hexdigest()):
                self.mutate(config, raw, refresh_internal_pin=True)
                with self.assertRaisesRegex(ValueError, 'metadata does not project exactly'):
                    self.invoke(config)

    def test_wrong_world_sha_and_duplicate_world_field_are_rejected(self):
        config = self.config()
        original = self.actual[config]
        digest = hashlib.sha256(self.actual[self.world()]).hexdigest().encode()
        wrong_scene = hashlib.sha256(self.actual[self.world('rooms')]).hexdigest().encode()
        changes = [original.replace(digest, wrong_scene),
                   original.replace(b'  "world_sha256":',
                                    b'  "world_sha256": "' + digest + b'",\n  "world_sha256":', 1)]
        for raw in changes:
            with self.subTest(sha=hashlib.sha256(raw).hexdigest()):
                self.mutate(config, raw, refresh_internal_pin=True)
                with self.assertRaisesRegex(ValueError, 'metadata does not project exactly'):
                    self.invoke(config)

    def test_valid_config_cannot_bypass_bad_matching_world(self):
        world = self.world()
        self.mutate(world, self.actual[world].replace(b'>0.001<', b'>0.002<', 1))
        with self.assertRaisesRegex(ValueError, 'source freeze/worktree SHA mismatch'):
            self.invoke(self.config())

    def test_w7_normative_bytes_are_independently_requested_not_caller_supplied(self):
        self.assertEqual(list(inspect.signature(self.ns['verify_machine_task_file']).parameters),
                         ['root', 'freeze', 'relative'])
        world = self.world()
        self.normative[world] = self.normative[world].replace(b'>0.001<', b'>0.002<', 1)
        with self.assertRaisesRegex(ValueError, 'world does not project exactly'):
            self.invoke(world)

    def test_whole_auditor_ast_is_identical_after_only_authorized_inverse_delta(self):
        original = ast.parse((HERE / 'original_audit_ppo.py').read_text())
        proposed = copy.deepcopy(TREE)
        proposed.body = [node for node in proposed.body if not (
            isinstance(node, ast.FunctionDef) and node.name in ('verify_machine_task_file', 'verify_environment_appendix')) and not (
            isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and
                t.id in ('SOLVER150_WORLD_PINS', 'SOLVER150_TASK_PINS', 'ENV_NORMATIVE_FREEZE', 'ENV_NORMATIVE_SHA256', 'ENV_EXECUTION_APPENDIX_SHA256', 'ENV_EXECUTION_APPENDIX_BYTES') for t in node.targets))]
        old_env = next(n.value.value for n in original.body if isinstance(n, ast.Assign)
                       and any(isinstance(t, ast.Name) and t.id == 'ENV_DOCUMENT_SHA256' for t in n.targets))
        for node in proposed.body:
            if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'ENV_DOCUMENT_SHA256' for t in node.targets):
                node.value = ast.Constant(value=old_env)
        added_env_update = ast.parse('proof[WIRELESS + "MR3_ENV_CONTRACT.md"].update(verify_environment_appendix(root, freeze))').body[0]
        env_updates_removed = 0
        for node in proposed.body:
            if isinstance(node, ast.FunctionDef) and node.name == 'load_native_gates':
                retained=[]
                for statement in node.body:
                    if ast.dump(statement, include_attributes=False) == ast.dump(added_env_update, include_attributes=False):
                        env_updates_removed += 1
                    else:
                        retained.append(statement)
                node.body = retained
        self.assertEqual(env_updates_removed, 1)
        old_loop = ast.parse(textwrap.dedent((HERE / 'original_machine_loop.txt').read_text())).body[0]
        replaced = 0
        for node in proposed.body:
            if isinstance(node, ast.FunctionDef) and node.name == 'load_native_gates':
                for index, item in enumerate(node.body):
                    if isinstance(item, ast.For) and isinstance(item.iter, ast.Name) and item.iter.id == 'machine_paths':
                        node.body[index] = old_loop
                        replaced += 1
        self.assertEqual(replaced, 1)
        self.assertEqual(ast.dump(original, include_attributes=False),
                         ast.dump(proposed, include_attributes=False))
        old_env = next(n.value.value for n in original.body if isinstance(n, ast.Assign)
                       and any(isinstance(t, ast.Name) and t.id == 'ENV_DOCUMENT_SHA256' for t in n.targets))
        self.assertNotEqual(self.ns['ENV_DOCUMENT_SHA256'], old_env)
        self.assertEqual(self.ns['ENV_DOCUMENT_SHA256'], hashlib.sha256((HERE/'MR3_ENV_CONTRACT.proposed.md').read_bytes()).hexdigest())


if __name__ == '__main__':
    unittest.main(verbosity=2)
