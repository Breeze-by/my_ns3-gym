#!/usr/bin/env python3
"""Closed offline CDR diagnostic; no ROS initialization, participants or control."""
import bisect
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import sys
import time
from rclpy.serialization import deserialize_message
from rosidl_runtime_py.utilities import get_message

BASE = Path('/tmp/mr3_p2a0_v20_sensor_capture_v1')
PRIOR = Path('/tmp/mr3_p2a0_v20_scan_map_source_analysis_v2.json')
OUT = Path('/tmp/mr3_p2a0_v20_scan_return_persistence_v1.json')

def sha(raw): return hashlib.sha256(raw).hexdigest()
def ns(stamp): return stamp.sec * 1000000000 + stamp.nanosec
def yaw(q): return math.atan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z))
def stat(path):
    x = path.stat()
    return [x.st_dev, x.st_ino, x.st_size, x.st_mtime_ns, x.st_ctime_ns]
def ref(row):
    return {'line': row['_line'], 'record_sequence': row['record_sequence'],
            'topic': row['payload']['topic'], 'CDR': row['payload']['CDR'],
            'wall_monotonic_ns': row['wall_monotonic_ns']}
def normal(a): return math.atan2(math.sin(a), math.cos(a))
def nearest(samples, stamp):
    i = bisect.bisect_left([x['source_ns'] for x in samples], stamp)
    options = samples[max(0, i - 1):i + 1]
    return min(options, key=lambda x: abs(x['source_ns'] - stamp))

def main():
    started = time.monotonic()
    paths = [BASE / 'messages.cdr', BASE / 'records.jsonl', PRIOR]
    before = {str(p): stat(p) for p in paths}
    binary = paths[0].read_bytes()
    priorraw = PRIOR.read_bytes()
    prior = json.loads(priorraw)
    samples, transforms = defaultdict(list), defaultdict(list)
    types, parameters, counts = {}, {}, Counter()
    digest = hashlib.sha256()
    with paths[1].open('rb') as stream:
        for number, line in enumerate(stream, 1):
            digest.update(line)
            row = json.loads(line)
            row['_line'] = number
            if row['kind'] == 'parameter_values_response': parameters[row['payload']['robot']] = row
            if row['kind'] != 'sample': continue
            p = row['payload']; topic = p['topic']; counts[topic] += 1
            if not topic.endswith(('/scan', '/tf')): continue
            part = p['CDR']; raw = binary[part['offset']:part['offset'] + part['length']]
            assert sha(raw) == part['sha256']
            cls = types.setdefault(p['type'], get_message(p['type']))
            message = deserialize_message(raw, cls)
            robot = topic.split('/')[1]
            if topic.endswith('/scan'):
                samples[robot].append((row, message))
            else:
                for t in message.transforms:
                    if t.header.frame_id == 'odom' and t.child_frame_id == 'base_footprint':
                        transforms[robot].append({'source_ns': ns(t.header.stamp),
                          'xy': [t.transform.translation.x, t.transform.translation.y],
                          'yaw': yaw(t.transform.rotation), 'reference': ref(row)})
    result = {}
    for robot in ('tb1', 'tb2', 'tb3'):
        data = prior['robots'][robot]
        poses = data['processed_poses']
        first = poses[0]
        offset = first['static_offset_actual']
        firstmap = data['maps'][0]
        original_cells = {(c['row'], c['column']) for c in firstmap['near_body_occupied_cells']}
        first_indices = {b['beam_index'] for b in first.get('near_body_eligible_endpoints', [])}
        tf = sorted(transforms[robot], key=lambda x: x['source_ns'])
        assert tf
        scanmeta = {(m.header.frame_id, m.range_min, m.range_max, m.angle_min, m.angle_max,
                     m.angle_increment, len(m.ranges)) for _, m in samples[robot]}
        assert len(scanmeta) == 1
        trace = []
        for row, scan in samples[robot]:
            stamp = ns(scan.header.stamp)
            available = [p for p in poses if p['pose_source_ns'] <= stamp]
            anchor = available[-1] if available else first
            oldtf = nearest(tf, anchor['pose_source_ns'])
            currenttf = nearest(tf, stamp)
            correction = anchor['pose']['yaw'] - oldtf['yaw']
            dx = currenttf['xy'][0] - oldtf['xy'][0]
            dy = currenttf['xy'][1] - oldtf['xy'][1]
            bx = anchor['pose']['xyz'][0] + math.cos(correction) * dx - math.sin(correction) * dy
            by = anchor['pose']['xyz'][1] + math.sin(correction) * dx + math.cos(correction) * dy
            byaw = normal(anchor['pose']['yaw'] + currenttf['yaw'] - oldtf['yaw'])
            processed = [p for p in poses if p['pose_source_ns'] == stamp]
            if processed:
                bx, by = processed[0]['pose']['xyz'][:2]; byaw = processed[0]['pose']['yaw']
            near, selected, targethits = [], [], []
            for i, r in enumerate(scan.ranges):
                valid = math.isfinite(r) and scan.range_min < r < scan.range_max
                angle = offset['yaw'] + scan.angle_min + i * scan.angle_increment
                x = offset['x'] + r * math.cos(angle) if valid else None
                y = offset['y'] + r * math.sin(angle) if valid else None
                if i in first_indices:
                    selected.append({'beam_index': i, 'range': r if math.isfinite(r) else repr(r),
                                     'Karto_eligible': valid})
                if not valid or math.hypot(x, y) > .35: continue
                wx = bx + math.cos(byaw) * x - math.sin(byaw) * y
                wy = by + math.sin(byaw) * x + math.cos(byaw) * y
                origin = firstmap['origin']; ox, oy = origin['xyz'][:2]; a = origin['yaw']
                xx, yy = wx - ox, wy - oy
                column = math.floor((math.cos(a) * xx + math.sin(a) * yy) / firstmap['resolution'] + .5)
                rr = math.floor((-math.sin(a) * xx + math.cos(a) * yy) / firstmap['resolution'] + .5)
                point = {'beam_index': i, 'range': r, 'body_xy': [x, y],
                  'body_bearing_rad': math.atan2(y, x), 'map_xy_estimate': [wx, wy],
                  'map_bearing_rad': normal(byaw + math.atan2(y, x)),
                  'first_map_karto_index': [rr, column],
                  'within_original_base_collision_XY': -.1965 <= x <= .0685 and -.1325 <= y <= .1325}
                near.append(point)
                if (rr, column) in original_cells: targethits.append(point)
            trace.append({'scan_source_ns': stamp, 'scan_reference': ref(row),
              'received_public_processed_pose_same_source': bool(processed),
              'near_eligible_count': len(near), 'near_body_points': near,
              'first_accepted_near_beam_indices_values': selected,
              'same_first_map_occupied_cell_estimated_hits': targethits,
              'map_base_estimate_xy_yaw': [bx, by, byaw],
              'map_base_estimate_scope': 'actual same-stamp public pose' if processed else
                'diagnostic last-public-correction plus nearest received odom TF; not actual accepted scan',
              'nearest_received_odom_TF': currenttf,
              'nearest_odom_source_delta_ns': currenttf['source_ns'] - stamp})
        after = [r for r in trace if r['scan_source_ns'] > first['pose_source_ns']]
        bodyhist = Counter(); maphist = Counter()
        for entry in trace:
            for p in entry['near_body_points']:
                bodyhist[str(math.floor((p['body_bearing_rad'] + math.pi) / (math.pi / 12)))] += 1
                maphist[str(math.floor((p['map_bearing_rad'] + math.pi) / (math.pi / 12)))] += 1
        initialtf = nearest(tf, first['pose_source_ns'])
        delta = {'max_translation_from_first_processed_odom_m': max(math.hypot(t['xy'][0] - initialtf['xy'][0],
                  t['xy'][1] - initialtf['xy'][1]) for t in tf),
                 'max_yaw_from_first_processed_odom_rad': max(abs(normal(t['yaw'] - initialtf['yaw'])) for t in tf)}
        result[robot] = {'first_accepted_source_ns': first['pose_source_ns'],
          'all_scanner_metadata_identical': True, 'raw_after_first_processed': len(after),
          'after_with_near_returns': sum(x['near_eligible_count'] > 0 for x in after),
          'after_without_near_returns': sum(x['near_eligible_count'] == 0 for x in after),
          'after_with_estimated_first_map100_cell_hits': sum(bool(x['same_first_map_occupied_cell_estimated_hits']) for x in after),
          'first_map_occupied_cells': [list(x) for x in sorted(original_cells)],
          'body_bearing_15degree_bin_counts': dict(bodyhist),
          'map_bearing_15degree_bin_counts_estimated': dict(maphist), 'odom_TF_motion': delta,
          'max_nearest_odom_source_difference_ns': max(abs(x['nearest_odom_source_delta_ns']) for x in trace),
          'latest_scan': trace[-1], 'trace': trace}
    inputs = {str(paths[0]): {'sha256': sha(binary), 'bytes': len(binary)},
              str(paths[1]): {'sha256': digest.hexdigest(), 'bytes': paths[1].stat().st_size},
              str(PRIOR): {'sha256': sha(priorraw), 'bytes': len(priorraw)}}
    assert inputs[str(paths[0])]['sha256'] == prior['inputs'][str(paths[0])]['sha256']
    assert inputs[str(paths[1])]['sha256'] == prior['inputs'][str(paths[1])]['sha256']
    for p in paths:
        assert stat(p) == before[str(p)] and sha(p.read_bytes()) == inputs[str(p)]['sha256']
    receipt = {'schema': 'mr3-v20-scan-return-persistence-v1', 'freeze': prior['freeze'],
      'robots': result, 'inputs': inputs, 'whole_files_SHA_stat_before_after_unchanged': True,
      'scope': 'Only recorded scan/TF/publicpose/map; no truth, ROS init, participant, native, control or source edits.',
      'limits': ['Unprocessed scan map coordinates are expressly estimates using nearest received odom TF, not hidden TF2 lookup or actual acceptance.',
        'Body collision XY membership is a two-dimensional nominal projection, not proof of the hit object/height.',
        'Persistent eligible close raw returns do not establish self-hit versus floor/environment or establish a production repair.'],
      'execution': {'argv': sys.argv, 'wall_seconds': time.monotonic() - started}, 'writers': 'STOP after summary/seal'}
    with OUT.open('x') as stream: stream.write(json.dumps(receipt, indent=2, allow_nan=False) + '\n')
    summary = {name: {k: v for k, v in r.items() if k not in ('trace', 'latest_scan')}
               for name, r in result.items()}
    print(json.dumps({'output': str(OUT), 'sha256': sha(OUT.read_bytes()), 'summary': summary,
                     'latest': {name: {'source_ns': r['latest_scan']['scan_source_ns'],
                       'near': r['latest_scan']['near_eligible_count'],
                       'same100hits_estimated': len(r['latest_scan']['same_first_map_occupied_cell_estimated_hits'])}
                       for name, r in result.items()}}))

if __name__ == '__main__': main()
