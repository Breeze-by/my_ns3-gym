"""Execute bounded offline checks; writes only /tmp and imports no production."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time


ROOT = Path("/home/zhuyulab/ns3-workspace")
OUT = Path("/tmp/mr3_p2a0_v18_stop_observer_consumer_checks_v1")
CONSUMER = Path("/tmp/mr3_independent_stop_observer_v1.py")
TESTS = Path("/tmp/mr3_independent_stop_observer_v1_tests.py")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    OUT.mkdir(exist_ok=True)
    env = os.environ.copy()
    env.update(PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1")
    sources = [CONSUMER, TESTS, Path(__file__)]
    before = {str(path): digest(path) for path in sources}
    results = []
    commands = [
        ("tests_final", ["/usr/bin/python3", str(TESTS), "-v"]),
        ("style_final", ["/usr/bin/python3", "-m", "flake8", "--max-line-length=99",
                         str(CONSUMER), str(TESTS)]),
        ("syntax_final", ["/usr/bin/python3", "-c",
                          "from pathlib import Path;"
                          "[compile(Path(p).read_bytes(),p,'exec') for p in "
                          + repr([str(CONSUMER), str(TESTS)]) + "];print('PASS')"]),
    ]
    for label, argv in commands:
        started = time.monotonic()
        run = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True)
        stdout, stderr = OUT / (label + ".stdout"), OUT / (label + ".stderr")
        stdout.write_bytes(run.stdout)
        stderr.write_bytes(run.stderr)
        results.append({"label": label, "argv": argv, "cwd": str(ROOT),
                        "exit_code": run.returncode, "wall_seconds": time.monotonic() - started,
                        "stdout": str(stdout), "stdout_sha256": digest(stdout),
                        "stderr": str(stderr), "stderr_sha256": digest(stderr)})
    # Real old record schema only: not a new native run or a complete consumer
    # verdict on V17. This solely checks release/effective_end adapters.
    path = ROOT / ("ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/"
                   "mr3_p2a0_20261017_v17_interface/worker0/episode001_open_101/transitions.jsonl")
    original_sha = digest(path)
    spec = importlib.util.spec_from_file_location("independent_stop_observer", CONSUMER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    bindings = {}
    records = list(module.line_rows(path, bindings))
    interval = module.transition_interval(records, records[0]["snapshot"]["epoch"])
    compatibility = {"passed": original_sha == digest(path), "source_path": str(path),
                     "sha256_before": original_sha, "sha256_after": digest(path),
                     "record_count": len(records), "actual_interval": interval,
                     "scope": "Only historical small transition schema compatibility. No new "
                     "native/formal/physical/matrix credit; no observer file was read."}
    compatibility_path = OUT / "real_transition_schema_compat_v1.json"
    compatibility_path.write_text(json.dumps(compatibility, indent=2) + "\n")
    after = {str(path): digest(path) for path in sources}
    result = {"schema": "mr3-stop-observer-consumer-offline-checks-v1",
              "passed": all(row["exit_code"] == 0 for row in results)
              and compatibility["passed"] and before == after,
              "commands": results,
              "environment": {key: env[key] for key in
                              ("PYTHONDONTWRITEBYTECODE", "PYTHONNOUSERSITE")},
              "source_before": before, "source_after": after,
              "compatibility": {"path": str(compatibility_path),
                                "sha256": digest(compatibility_path)},
              "scope": "CPU synthetic data and source/schema validation only. The 32-call "
              "synthetic positive fixture has deliberately short 1ms calls and gives no "
              "actual 32-second, physics, ROS or owned-process evidence.",
              "history": ["Initial26testsPASS retained as tests_execution_v1.json.",
                          "Initial style FAIL retained; formatting-only AST equality retained.",
                          "No simulator/ROS graph/process control or canonical writes."]}
    target = OUT / "checks_final_v1.json"
    target.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"passed": result["passed"], "receipt": str(target),
                      "source_sha256": after,
                      "commands": [{"label": row["label"], "exit_code": row["exit_code"]}
                                   for row in results]}))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
