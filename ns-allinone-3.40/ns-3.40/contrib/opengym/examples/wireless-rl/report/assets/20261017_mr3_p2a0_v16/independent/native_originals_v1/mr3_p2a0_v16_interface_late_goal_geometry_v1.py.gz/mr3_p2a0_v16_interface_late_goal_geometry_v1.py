"""Read-only later real returned GOAL availability, not a modified-fixture rollout."""
import ast
import hashlib
import json
import math
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
B = W / 'mr3_learning/benchmark.py'
EP = ROOT / ('ros2_ws/ros2-multi-robot-automap/log/mr3_p2a0/'
             'mr3_p2a0_20261017_v16_interface/worker0/episode001_open_101')
OUTPUT = Path('/tmp/mr3_p2a0_v16_interface_late_goal_geometry_v1.json')
started = time.monotonic()
raw = B.read_bytes()
transitions = (EP / 'transitions.jsonl').read_bytes()
freeze = 'ebe7d51bdb7bf9d77a28b77cfb4296876afb0100'
if raw != subprocess.check_output(['git', 'show', freeze + ':' + B.relative_to(ROOT).as_posix()], cwd=ROOT):
    raise ValueError('not freeze source')
node = next(node for node in ast.parse(raw).body if isinstance(node, ast.FunctionDef)
            and node.name == '_probe_nonapproaching_goal_action')
namespace = {'math': math}
exec(compile(ast.Module(body=[node], type_ignores=[]), str(B), 'exec'), namespace)
rows = []
for item in (json.loads(line) for line in transitions.splitlines()):
    snap = item['snapshot']
    elapsed = snap['task_elapsed_sec']
    if not 15 <= elapsed <= 28:
        continue
    own = snap['robots'][0]
    legal = sorted({action // 100 for action, valid in enumerate(snap['joint_action_mask'])
                    if valid and action // 100 < 8})
    eligible = [choice for choice in legal
                if namespace['_probe_nonapproaching_goal_action'](snap, choice * 100 + 88)]
    rows.append({'elapsed': elapsed, 'original_joint_tb1_GOAL_choices': legal,
                 'nonapproaching_tb1_choices_geometry_only': eligible,
                 'fresh': own['fresh'], 'valid': own['valid'], 'v': own['v'],
                 'navigation_phase': own['navigation']['phase'],
                 'accepted_goal_count': own['navigation']['accepted_goal_count'],
                 'elapsed_since_actual_initial_WAIT10': elapsed - 10.,
                 'hypothetical_new_goal5sec_commit_end': elapsed + 5.,
                 'seconds_to_original_final_WAIT28': 28. - elapsed})
sha = lambda payload: hashlib.sha256(payload).hexdigest()
result = {'schema': 'mr3-v16-later-returned-tb1-goal-geometry-v1',
          'passed': raw == B.read_bytes() and transitions == (EP / 'transitions.jsonl').read_bytes(),
          'scope': 'Diagnostic only on real returned inputs. Original fixture did not select a '
                   'late GOAL; no actor clock/mask/command changed, no counterfactual path '
                   'simulation. Geometry-only predicates are not Nav2 or guard-clear proof.',
          'source_sha256': sha(raw), 'transitions_sha256': sha(transitions), 'freeze': freeze,
          'source_before_after_stable': raw == B.read_bytes(), 'records': rows,
          'conclusion': 'Original interface GOAL availability returns only22s onward. A '
                        'bounded later selection opportunity could be evaluated separately '
                        'without weakening masks; this actual trace cannot prove new movement '
                        'or original A/B stop coverage. At22s a new5s commitment would finish27s '
                        'before original28s finalWAIT, but no new motion evidence is earned.',
          'tool_sha256': sha(Path(__file__).read_bytes()), 'wall_seconds': time.monotonic() - started}
with OUTPUT.open('x') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
print(json.dumps({'output': str(OUTPUT), 'sha256': sha(OUTPUT.read_bytes()),
                  'passed': result['passed'], 'late_opportunities': [row for row in rows if row['original_joint_tb1_GOAL_choices']]}, indent=2))
raise SystemExit(0 if result['passed'] else 1)
