"""One actual source-bound CPU round for the fixed V62 diagnostic candidate."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A = Path(__file__).resolve().parent
C = A / 'candidate'


def main():
    spec_path = A / 'artificial_cpu_spec_v1.json'
    spec = json.loads(spec_path.read_text())
    ros = ROOT / 'ros2_ws/ros2-multi-robot-automap'
    installed = Path('/opt/ros/humble/lib/python3.10/site-packages')
    sources = sorted(set([*C.glob('*.py'), C/'base_source_pins_v1.json', Path(__file__).resolve(), spec_path,
        *(W/'mr3_learning').glob('*.py'),
        *(ros/'src/multi_robot_exploration/multi_robot_exploration').glob('*.py'),
        ros/'scripts/mr3_env_worker.py',
        *[path for name in ('launch', 'launch_ros', 'ros2launch') for path in (installed/name).rglob('*.py')],
        W/'report/assets/20261019_mr3_p2a_v16/external_absence_v1.py']))
    freeze = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    if freeze != spec['repository_source_freeze']:
        raise ValueError('sealed current CPU freeze differs')
    snapshots = A / 'source_snapshots_v1'
    snapshots.mkdir(exist_ok=False)
    rows = []
    for ordinal, path in enumerate(sources):
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        row = dict(path=str(path), bytes=len(raw), sha256=digest)
        snapshot = snapshots / (str(ordinal).zfill(4)+'_'+digest+'_'+path.name)
        snapshot.open('xb').write(raw)
        row['snapshot'] = str(snapshot)
        if path.is_relative_to(ROOT):
            relative = str(path.relative_to(ROOT))
            if subprocess.check_output(['git', 'show', freeze+':'+relative], cwd=ROOT) != raw:
                raise ValueError('repository CPU source not in sealed current Git')
            row.update(kind='git_blob', freeze=freeze, relative_path=relative)
        else:
            row['kind'] = 'source_snapshot'
        rows.append(row)
    (A/'source_recovery_v1.json').open('x').write(json.dumps(
        dict(repository_source_freeze=freeze, sources=rows), indent=2)+'\n')
    sys.path.insert(0, str(C))
    import fixed_process_profile_v1 as core
    (A/'runner_identity_v1.json').open('x').write(json.dumps(core.identity(),indent=2)+'\n')
    argv = [sys.executable, '-B', '-m', 'mr3_learning.reach_execution', '--scope', 'cpu',
            '--output', str(C/'artificial_cpu_v1')]
    for path in sources:
        argv.extend(['--source', str(path)])
    argv.extend(['--', *spec['actual_argv']])
    env = dict(os.environ, PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1')
    env.pop('PYTHONPATH', None)
    env.pop('PYTHONHOME', None)
    return subprocess.call(argv, cwd=W, env=env)


if __name__ == '__main__':
    raise SystemExit(main())
