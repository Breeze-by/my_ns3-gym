"""Read-only exact two-wrapper dispatch change and pending plan hard-gate proof."""
import ast
import copy
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/zhuyulab/ns3-workspace')
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
A14 = W / 'report/assets/20261017_mr3_p2a0_v14'
A15 = W / 'report/assets/20261017_mr3_p2a0_v15'
DRAFT = Path('/tmp/mr3_p2a0_v15_matrix_draft_v1/independent')
OUTPUT = Path('/tmp/mr3_p2a0_v15_reset_wrapper_wiring_review_v1.json')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    observed = {}

    def read(path):
        raw = path.read_bytes()
        previous = observed.setdefault(str(path), sha(raw))
        assert previous == sha(raw), 'changed across reads: ' + str(path)
        return raw

    name = 'mr3_p2a0_v15_audit_stage.py'
    original = ast.parse(read(DRAFT / name))
    current = ast.parse(read(A15 / 'independent' / name))
    labels = {'angular_matrix_v1': 'mr3_independent_angular_reset_matrix_',
              'physics_matrix_v1': 'mr3_independent_physics_matrix_'}

    def calls(tree):
        return {node.args[0].value: node for node in ast.walk(tree)
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
                and node.func.id == 'standard' and node.args
                and isinstance(node.args[0], ast.Constant) and node.args[0].value in labels}

    old_calls, new_calls = calls(original), calls(current)
    assert set(old_calls) == set(new_calls) == set(labels)
    dispatch = {}
    for label, basename in labels.items():
        old, new = old_calls[label].args[1], new_calls[label].args[1]
        for path in (old, new):
            assert isinstance(path, ast.BinOp) and isinstance(path.op, ast.Div)
            assert isinstance(path.left, ast.Name) and path.left.id == 'ASSETS'
            assert isinstance(path.right, ast.Constant)
        expected_old = '20261017_mr3_p2a0_v8/independent/' + basename + 'v8.py'
        expected_new = '20261017_mr3_p2a0_v15/independent/' + basename + 'v15.py'
        assert old.right.value == expected_old and new.right.value == expected_new
        assert (W / 'report/assets' / expected_new).is_file()
        dispatch[label] = dict(previous=expected_old, current=expected_new)
        new_calls[label].args[1] = copy.deepcopy(old)
    assert ast.dump(current, include_attributes=False) == ast.dump(original, include_attributes=False)

    name = 'mr3_p2a0_v15_audit_stage_tests_v1.py'
    old_tests = ast.parse(read(DRAFT / name))
    new_tests = ast.parse(read(A15 / 'independent' / name))
    changed_constants = 0
    for node in ast.walk(new_tests):
        if isinstance(node, ast.Constant) and node.value == 'mr3_independent_physics_matrix_v15.py':
            node.value = 'mr3_independent_physics_matrix_v8.py'
            changed_constants += 1
    assert changed_constants == 2
    assert ast.dump(new_tests, include_attributes=False) == ast.dump(old_tests, include_attributes=False)

    old_plan = json.loads(read(A14 / 'predeclared_plan_v14.json'))
    plan_raw = read(A15 / 'predeclared_plan_v15.json')
    plan = json.loads(plan_raw)
    bindings = plan['independent_source_bindings']
    assert len(bindings) == len({row['path'] for row in bindings}) == 121
    for row in bindings:
        assert sha(read(ROOT / row['path'])) == row['sha256'], row['path']
    gates = ('unchanged_gates', 'physical_response_criteria', 'settled_turn_criteria',
             'angular_interface_criteria', 'angular_reset_criteria',
             'full_execution_model_failfast', 'pilot_budget_unchanged',
             'max_api_records', 'max_submitted_script_decisions', 'max_total_wall_seconds')
    for key in gates:
        assert plan[key] == old_plan[key], key
    assert [plan[key] for key in gates[-3:]] == [608, 596, 18000]
    for old, new in zip(old_plan['stages'], plan['stages']):
        assert old['stage'] == new['stage']
        for key in ('required_audits', 'required_audit_receipts'):
            expected = json.loads(json.dumps(old[key]).replace('v14', 'v15').replace('V14', 'V15'))
            assert new[key] == expected, (old['stage'], key)
    old_bindings = {row['path']: row['sha256'] for row in old_plan['independent_source_bindings']}
    by_path = {row['path']: row['sha256'] for row in bindings}
    changed_old = {path for path, digest in old_bindings.items() if by_path.get(path) != digest}
    assert len(old_bindings) - len(changed_old) == 103 and len(changed_old) == 2
    # Whole old A13/A14 tool source bytes are still exactly their listed old pins.
    old_tool_count = 0
    for row in old_plan['independent_source_bindings']:
        if '/report/assets/' in row['path']:
            assert by_path[row['path']] == row['sha256']
            old_tool_count += 1
    assert all(sha(Path(path).read_bytes()) == digest for path, digest in observed.items())
    result = dict(
        passed=True, scheduler_production_delta=dispatch, scheduler_fake_basename_changes=2,
        normalized_production_and_tests_ast_equal_original_promoted=True,
        current_binding_count=121, old_bindings_unchanged=103,
        authorized_changed_old_binding_paths=sorted(changed_old), immutable_old_tool_pins=old_tool_count,
        plan_sha256=sha(plan_raw), plan_readiness=plan['readiness'],
        hard_gate_keys_exactly_equal_a14=gates, mandatory_audit_and_receipt_sets_preserved=True,
        source_before=observed, source_after=observed,
        scope='Read-only pending-plan/wrapper-dispatch static proof; new metadata wrappers '
              'are selected, old gate/math/readers/receipts retained. No native/formal/publish '
              'or final source freeze/admission credit.')
    with OUTPUT.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('source_before', 'source_after')},
                     indent=2))


if __name__ == '__main__':
    main()
