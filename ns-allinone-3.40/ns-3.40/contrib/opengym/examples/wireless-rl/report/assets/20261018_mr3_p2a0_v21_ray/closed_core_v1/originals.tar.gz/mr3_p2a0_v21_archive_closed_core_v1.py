"""Preserve closed V21 coordinator receipts and independent closure review."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
import time

ROOT = Path('/home/zhuyulab/ns3-workspace')
TARGET = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v21_ray/closed_core_v1'
assert not TARGET.exists()
started = time.monotonic()
names = [
    'ray_source_preflight_v1.json', 'ray_parent_v1.log', 'ray_lifecycle_v1.jsonl',
    'ray_execution_v1.json', 'ray_recorder_config_v1.json', 'ray_recorder_ready_v1.json',
    'ray_recorder_stop_v1.json', 'ray_recorder_console_v1.log', 'ray_benchmark_console_v1.log',
    'ray_original_physical_review_v1.json', 'ray_original_physical4_console_v1.log',
    'ray_closed_small_review_v1.py', 'ray_closed_small_review_v1.json',
    'ray_closed_small_review_v1_execution_v1.json', 'ray_closed_small_review_v1.stdout.log',
    'ray_closed_small_review_v1.stderr.log', 'promote_closed_bytes_v1.py',
]
files = [Path('/tmp') / ('mr3_p2a0_v21_' + name) for name in names]
for directory in ('mr3_p2a0_v21_ray_live_witness', 'mr3_p2a0_v21_ray_first8_bounded_observation_v1'):
    files.extend(p for p in sorted((Path('/tmp') / directory).rglob('*')) if p.is_file())
files.append(Path(__file__))
files = sorted(set(files))
entries = []
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for path in files:
        before = path.stat()
        raw = path.read_bytes()
        name = str(path.relative_to('/tmp'))
        info = tarfile.TarInfo(name)
        info.size, info.mtime, info.mode = len(raw), 0, 0o644
        archive.addfile(info, io.BytesIO(raw))
        entries.append({'source': str(path), 'member': name, 'bytes': len(raw),
                        'sha256': hashlib.sha256(raw).hexdigest(),
                        'stat': [before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns]})
encoded = gzip.compress(buffer.getvalue(), compresslevel=6, mtime=0)
assert len(encoded) < 100000000
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(encoded))) as archive:
    assert archive.getnames() == [row['member'] for row in entries]
    for row in entries:
        raw = archive.extractfile(row['member']).read()
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
        p = Path(row['source'])
        after = p.stat()
        assert [after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns] == row['stat']
        assert hashlib.sha256(p.read_bytes()).hexdigest() == row['sha256']
TARGET.mkdir()
(TARGET / 'originals.tar.gz').write_bytes(encoded)
result = {'schema': 'mr3-v21-closed-core-custody-v1', 'freeze': '099a8eeaa00676f7e6e00d7f5ef51294aac5edcb',
          'scope': 'Original closed receipts, independent PID/closure review and bounded first8 observations; no regrading.',
          'archive': 'originals.tar.gz', 'archive_bytes': len(encoded),
          'archive_sha256': hashlib.sha256(encoded).hexdigest(),
          'original_count': len(entries), 'original_bytes': sum(x['bytes'] for x in entries), 'files': entries,
          'full_roundtrip_and_source_final_sha_stat_verified': True, 'wall_seconds': time.monotonic() - started}
(TARGET / 'manifest_v1.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('original_count', 'original_bytes', 'archive_bytes', 'archive_sha256', 'wall_seconds')}))
