"""Exact CPU-only execution receipt; no ROS/DDS/native child commands."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


HERE = Path(__file__).parent
CWD = Path('/home/zhuyulab/ns3-workspace')
ENV = {'PATH': '/usr/bin:/bin', 'PYTHONNOUSERSITE': '1',
       'PYTHONDONTWRITEBYTECODE': '1', 'LANG': 'C.UTF-8',
       'LC_ALL': 'C.UTF-8', 'TZ': 'UTC'}
SOURCES = sorted(HERE.glob('*.py'))


def hashes():
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in SOURCES}


def main():
    receipt = {'schema': 'mr3-v20-sensor-binding-correction-checks-v1',
               'start_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'cwd': str(CWD), 'environment': ENV,
               'source_before': hashes(), 'commands': [],
               'scope': 'CPU-only fixture and fake-child tests; no native, DDS, SDK, or actual admission.'}
    start = time.monotonic()
    commands = [
        ('real_fixture_tests01', ['/usr/bin/python3', '-B', str(HERE / 'mr3_p2a0_v20_sensor_runtime_binding_tests_v2.py'), '-v']),
        ('existing14_tests01', ['/usr/bin/python3', '-B', str(HERE / 'mr3_p2a0_v20_sensor_coordinator_tests_v1.py'), '-v']),
        ('fatal_style01', ['/usr/bin/python3', '-m', 'flake8',
                           *[str(path) for path in SOURCES], '--select=E9,F63,F7,F82']),
    ]
    for label, argv in commands:
        began = time.monotonic()
        output = subprocess.run(argv, cwd=CWD, env=ENV, capture_output=True, check=False)
        stdout = HERE / (label + '.stdout.log')
        stderr = HERE / (label + '.stderr.log')
        with stdout.open('xb') as stream:
            stream.write(output.stdout)
        with stderr.open('xb') as stream:
            stream.write(output.stderr)
        receipt['commands'].append({'label': label, 'argv': argv, 'exit_code': output.returncode,
                                    'wall_seconds': time.monotonic() - began,
                                    'stdout': {'path': str(stdout), 'sha256': hashlib.sha256(output.stdout).hexdigest()},
                                    'stderr': {'path': str(stderr), 'sha256': hashlib.sha256(output.stderr).hexdigest()}})
    receipt['source_after'] = hashes()
    receipt['source_stable'] = receipt['source_before'] == receipt['source_after']
    receipt['passed'] = receipt['source_stable'] and all(row['exit_code'] == 0 for row in receipt['commands'])
    receipt['wall_seconds'] = time.monotonic() - start
    receipt['end_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    path = HERE / 'checks_v2.json'
    with path.open('x') as stream:
        json.dump(receipt, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'passed': receipt['passed'], 'receipt': str(path),
                      'commands': [(row['label'], row['exit_code'], row['wall_seconds']) for row in receipt['commands']]}))
    return 0 if receipt['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
