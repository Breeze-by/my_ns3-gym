import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path('/home/zhuyulab/ns3-workspace')
ROS = ROOT / 'ros2_ws/ros2-multi-robot-automap'
A = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261018_mr3_p2a0_v21_ray'
sdk = A / 'offline/sdk'
assert not sdk.exists()
sdk.mkdir(parents=True)
manifest = Path('/tmp/mr3_p2a0_v21_ray_observer_manifest_final_v1.json')
archive = Path('/tmp/mr3_p2a0_v21_ray_observer_sealed_v1.tar.gz')
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == '574719665a161bd2b7079369e6a3cabdc2c982fbd8fb610c4194e3f897e93557'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == '248bed8f0d6698b7548ca3122597beab2e3e2baf2ca3ce529d3ce91e6a2a5f8d'
data = json.loads(manifest.read_text())
with tarfile.open(archive) as tar:
    for row in data['files']:
        raw = tar.extractfile(row['selected_relative']).read()
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
(sdk / 'source_manifest_v1.json').write_bytes(manifest.read_bytes())
(sdk / 'originals.tar.gz').write_bytes(archive.read_bytes())

target = A / 'offline/canonical_build'
assert not target.exists()
files = [p for p in Path('/tmp/mr3_p2a0_v21_canonical_build_v1').iterdir() if p.is_file()]
files += [Path('/tmp/mr3_p2a0_v21_canonical_build_v1.py'),
          Path('/tmp/mr3_p2a0_v21_archive_actual_binary_v1.py'),
          Path('/tmp/mr3_p2a0_v21_canonical_build_independent_review_v1.py'),
          Path('/tmp/mr3_p2a0_v21_canonical_build_independent_review_v1.json'),
          Path('/tmp/mr3_p2a0_v21_ray_source_independent_review_v1.py'),
          Path('/tmp/mr3_p2a0_v21_ray_source_independent_review_v1.json'),
          Path('/tmp/mr3_p2a0_v21_ray_observer_proposal_v2/factory_cpu.cpp'), Path(__file__)]
for name in ('flags.make', 'link.txt'):
    files.append(ROS / 'build/multi_robot/CMakeFiles/mr3_ray_provenance_observer.dir' / name)
entries = []
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as tar:
    for path in sorted(set(files)):
        before = path.stat()
        raw = path.read_bytes()
        member = 'tmp/' + str(path.relative_to('/tmp')) if path.is_relative_to('/tmp') else 'workspace/' + str(path.relative_to(ROOT))
        info = tarfile.TarInfo(member)
        info.size, info.mtime, info.mode = len(raw), 0, 0o644
        tar.addfile(info, io.BytesIO(raw))
        entries.append({'source': str(path), 'member': member, 'bytes': len(raw),
                        'sha256': hashlib.sha256(raw).hexdigest(),
                        'stat': [before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns]})
encoded = gzip.compress(buffer.getvalue(), compresslevel=6, mtime=0)
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(encoded))) as tar:
    assert tar.getnames() == [row['member'] for row in entries]
    for row in entries:
        assert hashlib.sha256(tar.extractfile(row['member']).read()).hexdigest() == row['sha256']
        path = Path(row['source'])
        value = path.stat()
        assert [value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns] == row['stat']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
target.mkdir()
(target / 'originals.tar.gz').write_bytes(encoded)
result = {'schema': 'mr3-v21-canonical-build-custody-v1',
          'scope': 'Actual canonical build, actual library factory/link readback, independent reviews and provenance. No native.',
          'files': entries, 'original_count': len(entries),
          'original_bytes': sum(row['bytes'] for row in entries),
          'archive': 'originals.tar.gz', 'archive_bytes': len(encoded),
          'archive_sha256': hashlib.sha256(encoded).hexdigest(),
          'full_roundtrip_and_source_final_sha_stat_verified': True}
(target / 'manifest_v1.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('original_count', 'original_bytes', 'archive_bytes', 'archive_sha256')}))
