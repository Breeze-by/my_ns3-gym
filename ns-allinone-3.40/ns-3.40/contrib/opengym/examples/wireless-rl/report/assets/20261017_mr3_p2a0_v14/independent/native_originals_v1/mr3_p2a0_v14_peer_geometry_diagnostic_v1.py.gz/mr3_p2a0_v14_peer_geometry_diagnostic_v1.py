"""Exact small same-input replay; no formal audit, ROS import or native process."""
import ast
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import struct
import subprocess
from types import SimpleNamespace

import numpy as np

ROOT = Path('/home/zhuyulab/ns3-workspace')
ROS = ROOT / 'ros2_ws/ros2-multi-robot-automap'
W = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
EP = ROS / 'log/mr3_p2a0/mr3_p2a0_20261017_v14_interface/worker0/episode001_open_101'
OUT = Path('/tmp/mr3_p2a0_v14_peer_geometry_diagnostic_v1')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def obj(value):
    return SimpleNamespace(**{k: obj(v) for k, v in value.items()}) if isinstance(value, dict) else value


def extract(path, names, namespace):
    tree = ast.parse(path.read_bytes())
    selected = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in names]
    require({node.name for node in selected} == set(names), 'missing exact pure function')
    tree.body = selected
    exec(compile(tree, str(path), 'exec'), namespace)


def main():
    OUT.mkdir(exist_ok=False)
    peer_path = ROS / 'src/multi_robot_exploration/multi_robot_exploration/peer_obstacles.py'
    control_path = peer_path.with_name('control.py')
    safety_path = peer_path.with_name('mr3_motion_safety.py')
    reader_path = W / ('report/assets/20261017_mr3_p2a0_v10/independent/'
                       'mr3_independent_control_phase_v1.py')
    source_paths = [peer_path, control_path, safety_path, reader_path]
    freeze = json.loads((EP / 'metadata.json').read_bytes())['freeze']
    sources = {}
    for path in source_paths:
        raw = path.read_bytes()
        frozen = subprocess.check_output(['git', 'show', freeze + ':' + str(path.relative_to(ROOT))], cwd=ROOT)
        require(raw == frozen, 'source is not exact native freeze')
        sources[str(path)] = {'sha256': sha(raw), 'bytes': len(raw), 'equals_freeze': True}
        (OUT / path.name).write_bytes(raw)
    require(sources[str(reader_path)]['sha256'] ==
            '04cd7d079c16004b20320868943bcdac899da7646304d30cbad0804d1a6ee8d3',
            'immutable A10 reader changed')
    spec = importlib.util.spec_from_file_location('frozen_independent_peer_geometry', reader_path)
    old = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(old)

    assignments = {n.targets[0].id: n.value for n in ast.parse(safety_path.read_bytes()).body
                   if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name)}
    speed = ast.literal_eval(assignments['COMMAND_SPEED_LIMIT'])
    radius = ast.literal_eval(assignments['BODY_RADIUS_M'])
    require(speed == .20 and radius == .25, 'native source constants differ')
    control_tree = ast.parse(control_path.read_bytes())
    alias = [node for node in control_tree.body if isinstance(node, ast.ImportFrom)
             and node.module == 'multi_robot_exploration.mr3_motion_safety']
    require(len(alias) == 1 and ('COMMAND_SPEED_LIMIT', 'PEER_SPEED_BOUND_MPS') in
            {(n.name, n.asname) for n in alias[0].names}, 'actual imported constant alias differs')
    namespace = {'math': math, 'np': np, 'PEER_BODY_RADIUS_M': radius,
                 'PEER_SPEED_BOUND_MPS': speed, 'PEER_GRID_MARGIN_M': .04, 'PEER_REACTION_SEC': .55}
    extract(control_path, ['peer_safety_radius', 'quaternion_yaw', 'transform_point_2d'], namespace)
    extract(peer_path, ['body_points'], namespace)

    raw = (EP / 'peer_phase.jsonl').read_bytes()
    lines = raw.splitlines()
    inputs, latest_match, selected, selected_lines = {}, None, {}, {}
    first_publication_line = None
    publication = None
    for index, line in enumerate(lines[:5544], 1):
        row = json.loads(line)
        value = row['payload']
        if row['kind'] in ('received_odom', 'received_tf'):
            inputs[row['kind'].split('_')[1], value['robot'], value['input_sequence']] = (index, row)
        elif row['kind'] == 'inputs_matched':
            latest_match = row
            selected, selected_lines = {}, {}
            for key, ref in value['inputs'].items():
                if key == 'bundle':
                    continue
                kind, robot = key.split(':')
                line_number, item = inputs[kind, robot, ref['input_sequence']]
                sample = item['payload']
                require(old.digest(sample['raw']) == ref['raw_sha256'] == sample['raw_sha256'] and
                        sample['received_wall_monotonic_ns'] == ref['received_wall_monotonic_ns'],
                        'exact selected side callback does not match ref')
                selected[kind, robot] = sample
                selected_lines[key] = {'line': line_number, 'raw_line_sha256': sha(lines[line_number - 1])}
        elif row['kind'] == 'obstacles_published':
            if first_publication_line is None:
                first_publication_line = index
            if index == 5544:
                publication = row
    require(publication is not None and latest_match['record_sequence'] == 5543,
            'requested publication/matching lines differ')
    require(first_publication_line == 5544, 'this was not the first controlled normal publication')
    require(latest_match['payload']['request']['request_id'] == publication['payload']['request_id'],
            'publication request differs')
    target = publication['clock_ns']
    expected = old.expected_outputs(selected, target)
    poses, stamps = {}, {}
    for robot in old.ROBOTS:
        odom = selected['odom', robot]['raw']
        tf = selected['tf', robot]['raw']
        actual = obj(odom)
        transform = obj(tf['transform'])
        x, y = namespace['transform_point_2d'](actual.pose.pose.position.x,
                                               actual.pose.pose.position.y, transform)
        heading = namespace['quaternion_yaw'](actual.pose.pose.orientation) + namespace['quaternion_yaw'](
            transform.rotation)
        poses[robot] = (x, y, heading)
        require(poses[robot] == old.peer_pose(odom, tf), 'production and reader pose numeric op order differs')
        os = odom['header']['stamp']
        ts = tf['header']['stamp']
        stamps[robot] = min(os['sec'] + os['nanosec'] / 1e9,
                            ts['sec'] + ts['nanosec'] / 1e9 - .2)
    results, all_fields = [], []
    for item in publication['payload']['publications']:
        key = item['robot'], item['kind']
        require(item['message_sha256'] == old.digest(item['payload']), 'actual metadata SHA mismatch')
        actual, original = item['payload'], expected[key]
        differences = {k: {'actual': actual.get(k), 'frozen_reader': original.get(k)}
                       for k in set(actual) | set(original)
                       if old.canonical(actual.get(k)) != old.canonical(original.get(k))}
        all_fields.append({'robot': item['robot'], 'kind': item['kind'], 'differences': differences})
        if item['kind'] != 'cloud':
            require(not differences, 'unexpected scan field difference')
            continue
        x, y, heading = poses[item['robot']]
        peers = []
        for other in old.ROBOTS:
            if other == item['robot']:
                continue
            dx, dy = poses[other][0] - x, poses[other][1] - y
            peers.append((math.cos(heading) * dx + math.sin(heading) * dy,
                          -math.sin(heading) * dx + math.cos(heading) * dy,
                          target / 1e9 - stamps[other]))
        namespace['PEER_SPEED_BOUND_MPS'] = .20
        points20 = namespace['body_points'](peers)
        namespace['PEER_SPEED_BOUND_MPS'] = .26
        points26 = namespace['body_points'](peers)
        require(sha(points20.tobytes()) == actual['data_sha256'] and len(points20) == actual['width'],
                'source production .20 replay did not exactly reproduce actual recorded cloud')
        require(sha(points26.tobytes()) == original['data_sha256'] and len(points26) == original['width'],
                'source production .26 replay did not exactly reproduce immutable reader')
        require(set(differences) == {'data_sha256', 'data_bytes', 'width', 'row_step'},
                'difference is not solely full cloud geometry data/count')
        results.append({'robot': item['robot'], 'peers': [
            {'relative_x': p[0], 'relative_y': p[1], 'source_age_sec': p[2],
             'radius_actual_command_20': .25 + .04 + .20 * (max(0., p[2]) + .55),
             'radius_frozen_26': .25 + .04 + .26 * (max(0., p[2]) + .55)} for p in peers],
            'actual_points': len(points20), 'original_points': len(points26),
            'actual_sha256': sha(points20.tobytes()), 'frozen_26_sha256': sha(points26.tobytes()),
            'production20_exact_actual_recorded_hash': True,
            'production26_exact_frozen_reader_hash': True})
    selected_raw = {kind + ':' + robot: value for (kind, robot), value in selected.items()}
    (OUT / 'selected_inputs.json').write_text(json.dumps(selected_raw, indent=2) + '\n')
    for number in sorted({5542, 5543, 5544} | {v['line'] for v in selected_lines.values()}):
        (OUT / ('peer_line_' + str(number) + '.json')).write_bytes(lines[number - 1] + b'\n')
    require(sha(raw) == sha((EP / 'peer_phase.jsonl').read_bytes()), 'native ledger changed')
    for path in source_paths:
        require(sha(path.read_bytes()) == sources[str(path)]['sha256'], 'source changed')
    result = {'schema': 'mr3-v14-peer-geometry-same-input-diagnostic-v1', 'passed': True,
              'scope': 'Diagnostic only; original peer/control formal FAIL is retained.',
              'freeze': freeze, 'episode': str(EP), 'native_ledger': str(EP / 'peer_phase.jsonl'),
              'native_ledger_sha256': sha(raw), 'native_ledger_rows': len(lines),
              'publication_line': 5544, 'publication_clock_ns': target,
              'first_controlled_publication': True, 'selected_callback_lines': selected_lines,
              'request_id': publication['payload']['request_id'],
              'source_bindings': sources, 'numpy_version': np.__version__,
              'all_six_payload_differences': all_fields, 'three_cloud_exact_replays': results,
              'established_cause': 'control.py aliases PEER_SPEED_BOUND_MPS to guard '
                                  'COMMAND_SPEED_LIMIT. The authorized guard command cap .26->.20 '
                                  'also changes the numerical peer_safety_radius used by body_points '
                                  'and grid_with_peers. Same selected raw callbacks reproduce actual '
                                  'cloud SHA/count exactly at .20 and frozen independent geometry '
                                  'SHA/count exactly at .26; this is a real dependency-driven '
                                  'envelope change, not a float/order or alternate-input mismatch.',
              'limits': ['Only this exact same-input first publication was replayed; no additional '
                         'formal whole-episode audit was executed.',
                         'Actual cloud data are bound by recorded payload SHA/count. Full raw DDS '
                         'PointCloud2 bytes are not independently archived here; generated replay '
                         'bytes exactly match those recorded hashes.',
                         'The shared constant also feeds grid_with_peers via peer_safety_radius; '
                         'no whole actor/candidate change quantification is claimed by this diagnostic.',
                         'Existing .50 body failure distance remains .25+.25; the changed radius '
                         'is the conservative navigation obstacle prediction envelope.'],
              'source_and_native_bytes_stable_before_after': True,
              'new_formal_or_ROS_or_native': 0}
    (OUT / 'review.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'passed': True, 'actual_reproduced_at_speed20': len(results),
                      'immutable_reproduced_at_speed26': len(results), 'output': str(OUT / 'review.json'),
                      'review_sha256': sha((OUT / 'review.json').read_bytes())}))


if __name__ == '__main__':
    main()
