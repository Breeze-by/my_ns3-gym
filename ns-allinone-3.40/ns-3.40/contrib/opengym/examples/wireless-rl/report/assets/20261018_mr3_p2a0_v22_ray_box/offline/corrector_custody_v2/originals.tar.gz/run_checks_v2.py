#!/usr/bin/python3
import ast
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import time

P=Path(__file__).resolve().parent
ROOT=Path('/home/zhuyulab/ns3-workspace')
ENV_KEYS=['PYTHONNOUSERSITE','PYTHONDONTWRITEBYTECODE','ROS_DOMAIN_ID','RMW_IMPLEMENTATION','FASTRTPS_DEFAULT_PROFILES_FILE','LD_LIBRARY_PATH']
def sha(b):return hashlib.sha256(b).hexdigest()
def inventory():
 return {str(p):dict(sha256=sha(p.read_bytes()),bytes=p.stat().st_size,mtime_ns=p.stat().st_mtime_ns,inode=p.stat().st_ino)
         for p in [P/'mr3_v22_corrector_custody_v2.py', P/'test_corrector_custody_race_v2.py',P/'baseline_race_tests_v1.py',
                   P/'mr3_v22_corrector_binding_v1.json',P/'race_patch_v2.json',
                   Path('/tmp/mr3_p2a0_v22_corrector_custody_proposal_v1/mr3_v22_corrector_custody_v1.py')]}
env=dict(os.environ,PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1')
before=inventory()
commands=[
 ('baseline_exact_close_counterexamples', ['/usr/bin/python3','-B',str(P/'baseline_race_tests_v1.py'),
  'CustodyTests.test_same_identity_becomes_zombie_after_maps_has_no_credit',
  'CustodyTests.test_prior_actual_mapping_survives_later_uncredited_close'],1),
 ('new_race_mutations', ['/usr/bin/python3','-B',str(P/'test_corrector_custody_race_v2.py'),'-v'],0),
 ('fatal_style', ['/usr/bin/python3','-m','flake8','--select=E9,F63,F7,F82',
  str(P/'mr3_v22_corrector_custody_v2.py'),str(P/'test_corrector_custody_race_v2.py')],0)]
results=[]
for name,argv,expected in commands:
 start=time.monotonic();cpu=resource.getrusage(resource.RUSAGE_CHILDREN)
 r=subprocess.run(argv,cwd=ROOT,env=env,capture_output=True)
 elapsed=time.monotonic()-start;end=resource.getrusage(resource.RUSAGE_CHILDREN)
 for stream,b in [('stdout',r.stdout),('stderr',r.stderr)]:
  (P/(name+'.'+stream+'.log')).write_bytes(b)
 results.append(dict(name=name,argv=argv,cwd=str(ROOT),env={k:env.get(k) for k in ENV_KEYS},exit_code=r.returncode,
  expected_exit_code=expected,wall_seconds=elapsed,cpu_seconds=(end.ru_utime+end.ru_stime)-(cpu.ru_utime+cpu.ru_stime),
  stdout_sha256=sha(r.stdout),stderr_sha256=sha(r.stderr),expectation_met=r.returncode==expected,
  stdout_tail=r.stdout.decode(errors='replace')[-1500:],stderr_tail=r.stderr.decode(errors='replace')[-3500:]))
patch=json.loads((P/'race_patch_v2.json').read_bytes())
new=(P/'mr3_v22_corrector_custody_v2.py').read_text();old=Path(patch['base_path']).read_text()
assert new.count(patch['new_exact_block'])==1 and new.replace(patch['new_exact_block'],patch['old_exact_block'],1)==old
for f in ['mr3_v22_corrector_custody_v2.py','test_corrector_custody_race_v2.py']:
 ast.parse((P/f).read_bytes(),filename=str(P/f))
after=inventory();assert before==after
report=dict(schema='mr3-v22-corrector-custody-race-checks-v2',passed=all(x['expectation_met'] for x in results),
 results=results,source_before=before,source_after=after,whole_bytes_inverse_to_v1=True,
 scope='Only eight new fake-/proc closing-race/mutation methods; old20 not rerun. Baseline two expected actual assertion FAILs preserved; no native/ROS/DDS/SDK.',
 no_source_or_gate_bypass=True)
(P/'checks_v2.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(passed=report['passed'],results=[{k:x[k] for k in ['name','exit_code','expected_exit_code','wall_seconds','expectation_met','stderr_tail']} for x in results]),indent=2))
raise SystemExit(0 if report['passed'] else 1)
