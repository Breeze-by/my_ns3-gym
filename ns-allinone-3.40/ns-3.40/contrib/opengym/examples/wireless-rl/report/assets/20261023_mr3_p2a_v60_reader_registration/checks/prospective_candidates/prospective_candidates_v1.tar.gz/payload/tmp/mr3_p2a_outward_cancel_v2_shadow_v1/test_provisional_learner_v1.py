"""Private shadow definition/metadata tests only; never a canonical audit."""
import importlib
import json
from pathlib import Path
import sys
import tempfile
from types import ModuleType, SimpleNamespace
import unittest
from unittest.mock import patch

ROOT=Path('/home/zhuyulab/ns3-workspace')
W=ROOT/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
OUT=Path(__file__).resolve().parent
SHADOW=OUT/'shadow'/W.relative_to(ROOT)/'mr3_learning'
sys.path.insert(0,str(W))
package=importlib.import_module('mr3_learning')


def load(name):
    path=SHADOW/(name+'.py')
    module=ModuleType('mr3_learning._shadow_'+name)
    module.__package__='mr3_learning'
    # Resolve unchanged immutable dependencies from the canonical tree. No
    # implementation source proof or formal source admission is claimed here.
    module.__file__=str(W/'mr3_learning'/path.name)
    exec(compile(path.read_text(),str(path),'exec'),module.__dict__)
    return module


reader=load('audit_reach_reset_workload')
with patch.object(package,'audit_reach_reset_workload',reader,create=True):
    full=load('audit_reach_preparation')


class ShadowFullReaderTests(unittest.TestCase):
    def fixture(self, *, motion=True, actual_probe=True):
        temporary=tempfile.TemporaryDirectory(prefix='mr3-shadow-v2-reader-')
        self.addCleanup(temporary.cleanup);root=Path(temporary.name)
        plan=root/'artificial_fixture_description.json'
        plan.write_text(json.dumps({'fixture_only':True,
            'reset_workload_reader_profile':reader.PROFILE_V2,
            'preparation_probe_version':reader.PROBE_VERSION_V2}))
        episode=root/'episode';episode.mkdir()
        metadata={'epoch':'synthetic','freeze':'a'*40,'safety_contract':'mr3-reach-v1',
            'execution_phase_protocol':'mr3-controlled-execution-phase-v2',
            'reset_handshake':'paused-controlled-state-peer-guard-storage-v2'}
        if actual_probe:metadata['preparation_probe_version']=reader.PROBE_VERSION_V2
        (episode/'metadata.json').write_text(json.dumps(metadata))
        (episode/'supervisor_metadata.json').write_text(json.dumps(metadata))
        (episode/'benchmark_metadata.json').write_text(json.dumps({'preparation_motion_probe':motion}))
        return root,plan,episode

    def test_v2_full_private_reader_has_only_unique_version_inverse(self):
        _,plan,_=self.fixture()
        with patch.object(package,'audit_reach_reset_workload',reader,create=True):
            private,proof=full.load_impl(plan)
        self.assertEqual(private.PREPARATION_PROBE_V6,reader.PROBE_VERSION_V2)
        self.assertTrue(proof['whole_source_inverse_equal'])
        self.assertEqual(proof['inverse_sha256'],full.SOURCE_SHA256)
        versions=[row for row in proof['literal_changes'] if 'outward-cancel' in row['before']]
        self.assertEqual(len(versions),1)
        self.assertIn(reader.PROBE_VERSION_V2,versions[0]['after'])

    def test_old_definition_only_helper_defaults_to_v1(self):
        root,_,_=self.fixture();path=root/'legacy_definition_fixture.json';path.write_text('{}')
        with patch.object(package,'audit_reach_reset_workload',reader,create=True):
            private,_=full.load_impl(path)
        self.assertEqual(private.PREPARATION_PROBE_V6,reader.PROBE_VERSION)

    def test_nonprobe_role_does_not_acquire_scripted_metadata_requirement(self):
        _,plan,episode=self.fixture(motion=False,actual_probe=False)
        called=[]
        private=SimpleNamespace(audit=lambda *args:(called.append(args) or {'passed':True,'errors':[]}))
        with patch.object(package,'audit_reach_reset_workload',reader,create=True), patch.object(full,'load_impl',return_value=(private,{})):
            result=full.audit(episode,ROOT,'a'*40,plan)
        self.assertTrue(result['passed']);self.assertEqual(len(called),1)
        self.assertNotIn('episode_probe_profiles',result)

    def test_probe_role_rejects_missing_or_mixed_actual_worker_supervisor_pair(self):
        _,plan,episode=self.fixture(motion=True,actual_probe=False)
        with patch.object(package,'audit_reach_reset_workload',reader,create=True), patch.object(full,'load_impl') as private:
            with self.assertRaises(ValueError):full.audit(episode,ROOT,'a'*40,plan)
            private.assert_not_called()
        metadata=json.loads((episode/'metadata.json').read_text());metadata['preparation_probe_version']=reader.PROBE_VERSION_V2
        (episode/'metadata.json').write_text(json.dumps(metadata))
        supervisor=dict(metadata,epoch='different');(episode/'supervisor_metadata.json').write_text(json.dumps(supervisor))
        with self.assertRaisesRegex(ValueError,'epoch differs'):
            reader.episode_probe_profiles(episode,'a'*40,workload_profile=reader.PROFILE_V2)


if __name__=='__main__':unittest.main(verbosity=2)
