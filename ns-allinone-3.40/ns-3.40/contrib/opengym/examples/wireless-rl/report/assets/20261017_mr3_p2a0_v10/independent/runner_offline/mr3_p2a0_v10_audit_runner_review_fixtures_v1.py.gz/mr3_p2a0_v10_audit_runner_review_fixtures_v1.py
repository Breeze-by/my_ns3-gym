"""No-native fixtures of real stage main; Git/subprocess are explicit test doubles."""
import ast
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path('/home/zhuyulab/ns3-workspace')
A10 = ROOT / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report/assets/20261017_mr3_p2a0_v10'
SOURCE = A10/'independent/mr3_p2a0_v10_audit_stage.py'
SOURCE_BYTES = SOURCE.read_bytes()
PLAN_BYTES = (A10/'predeclared_plan_v10.json').read_bytes()
OUT = Path(tempfile.mkdtemp(prefix='mr3_v10_audit_runner_fixture_'))
(OUT/'runner_source.py').write_bytes(SOURCE_BYTES)
(OUT/'plan_source.json').write_bytes(PLAN_BYTES)
FREEZE = 'a'*40
ROWS = []

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def case(name, stage='interface', mutation=None, expected=True):
    directory = OUT/name
    directory.mkdir()
    root = directory/'root'
    wireless = root/'wireless'
    assets = root/'assets'
    local = assets/'20261017_mr3_p2a0_v10/independent'
    local.mkdir(parents=True)
    wireless.mkdir()
    outputs = directory/'outputs'
    outputs.mkdir()
    run = root/'run'
    counts = {'interface':1,'terminal':2,'reset':8,'deadline':1}
    for index in range(counts[stage]):
        (run/f'worker{index//4}'/f'episode{index%4+1:03d}').mkdir(parents=True)
    plan = json.loads(PLAN_BYTES)
    for row in plan['stages']:
        label = row['stage']
        row['run_directory'] = str(run)
        row['required_audit_receipts'] = [str(outputs/Path(p).name) for p in row['required_audit_receipts']]
        for key in ('information','peer','control','settled_turn'):
            values = row[key+'_audit_command_template']
            values[2] = str(run)
            values[values.index('--output')+1] = str(outputs/Path(values[values.index('--output')+1]).name)
    tracked = root/'fixture_bound_source'
    tracked.write_bytes(b'explicit synthetic bound bytes\n')
    plan['independent_source_bindings'] = [{'path':str(tracked.relative_to(root)), 'sha256':sha(tracked.read_bytes())}]
    if mutation == 'hash':
        tracked.write_bytes(b'changed bound bytes\n')
    plan_path = local.parent/'predeclared_plan_v10.json'
    plan_path.write_text(json.dumps(plan))
    namespace = {'__name__':'runner_fixture', '__file__':str(SOURCE)}
    exec(compile(SOURCE_BYTES, str(SOURCE), 'exec'), namespace)
    namespace.update(ROOT=root, WIRELESS=wireless, ASSETS=assets, LOCAL=local)
    def fixture_path(value):
        return outputs if str(value) == '/tmp' else Path(value)
    namespace['Path'] = fixture_path
    calls = []
    def check_output(command, **kwargs):
        assert kwargs['cwd'] == root and kwargs['text'] is True
        if command == ['git','rev-parse','HEAD']:
            return ('b'*40 if mutation == 'freeze' else FREEZE)+'\n'
        assert command == ['git','status','--porcelain']
        return ' M changed\n' if mutation == 'dirty' else ''
    def run_command(command, **kwargs):
        assert kwargs['cwd'] == wireless
        assert kwargs['env']['PYTHONNOUSERSITE'] == '1'
        assert kwargs['env']['PYTHONDONTWRITEBYTECODE'] == '1'
        assert 'PYTHONPATH' not in kwargs['env']
        assert kwargs['stderr'] == subprocess.STDOUT
        calls.append(list(command))
        is_module = command[1:3] == ['-m','mr3_learning.audit_preparation']
        script = 'audit_preparation' if is_module else Path(command[1]).name
        if is_module:
            assert command[3] == str(run) and command[4:6] == ['--freeze',FREEZE]
        if script == 'mr3_independent_drive_trace_v5.py':
            assert command[command.index('--binary-proof')+1] == '/tmp/mr3_p2a0_v10_binaryproof.json'
        if script in ('mr3_independent_physics_review.py','mr3_independent_angular_interface_v1.py','mr3_p2a0_v4_independent_input_episode_review_v1.py'):
            assert '--freeze' not in command, 'immutable older CLI does not accept freeze'
        elif script != 'audit_preparation':
            assert command[command.index('--freeze')+1] == FREEZE
        if script == 'mr3_p2a0_v4_independent_input_episode_review_v1.py':
            assert command[2] == '--episode' and Path(command[3]).is_dir()
        if script == 'mr3_independent_physics_matrix_v8.py':
            raw = Path(command[command.index('--per-episode-report')+1])
            assert raw.exists() and json.loads(raw.read_text())['passed'] is False
        if script == 'mr3_v10_multiepoch_closure_binary_review_v1.py':
            prefix = command[command.index('--prefix')+1]
            assert prefix == 'mr3_p2a0_v10_'+stage
            assert command[command.index('--expected-episodes')+1] == str(counts[stage])
            assert ('--require-parameters' in command) == (stage == 'interface')
            for index in range(1, counts[stage]+1):
                assert (outputs/(prefix+f'_episode{index:03d}_fifo_phase_final.json')).exists()
            output = outputs/(prefix+'_closure_binary_review_v1.json')
        else:
            output = Path(command[command.index('--output')+1])
        assert not output.exists(), 'real runner must not overwrite old consumer output'
        passed, code = True, 0
        if stage == 'reset' and script == 'mr3_independent_physics_review.py':
            passed, code = False, 1  # Missing per-episode meaningful-stop coverage stays original FAIL.
        if mutation == 'pooled' and script == 'mr3_independent_physics_matrix_v8.py':
            passed, code = False, 1
        if mutation == 'leaf' and script == 'mr3_p2a0_v4_independent_input_episode_review_v1.py' and 'episode001' in str(output):
            passed, code = False, 1
        if mutation == 'nonzero' and script == 'mr3_independent_drive_trace_v5.py':
            code = 2  # A lying passed JSON cannot hide a failing exit.
        if mutation == 'typed' and script == 'mr3_independent_drive_trace_v5.py':
            passed = 1
        if not (mutation == 'missing' and script == 'mr3_independent_drive_trace_v5.py'):
            value = {'passed':passed, 'freeze':('b'*40 if mutation == 'wrong_receipt_freeze' and script == 'mr3_independent_drive_trace_v5.py' else FREEZE), 'fixture_only':True}
            output.write_text(json.dumps(value))
        kwargs['stdout'].write(json.dumps({'fixture_only':True,'argv':command})+'\n')
        return subprocess.CompletedProcess(command, code)
    namespace['subprocess'] = type('FakeSubprocess',(),{'check_output':staticmethod(check_output),'run':staticmethod(run_command),'STDOUT':subprocess.STDOUT})
    oldargv = sys.argv
    sys.argv = [str(SOURCE),stage,FREEZE]
    stdout = io.StringIO()
    exception = None
    try:
        with contextlib.redirect_stdout(stdout):
            code = namespace['main']()
    except AssertionError as error:
        exception = type(error).__name__+': '+str(error)
        code = None
    finally:
        sys.argv = oldargv
    (directory/'runner_stdout.jsonl').write_text(stdout.getvalue())
    result_path = outputs/('mr3_p2a0_v10_'+stage+'_audit_execution_v1.json')
    result = json.loads(result_path.read_text()) if result_path.exists() else None
    if mutation in ('hash','freeze','dirty'):
        assert exception is not None and not calls and result is None
        success = True
    else:
        assert exception is None
        assert bool(code == 0) is expected
        assert result['passed'] is expected
        if stage == 'reset':
            raw = next(c for c in result['commands'] if c['label'] == 'physical_per_episode_v1')
            pooled = next(c for c in result['commands'] if c['label'] == 'physics_matrix_v1')
            assert raw['passed'] is False and raw['returncode'] == 1 and raw['required_success'] is False
            assert pooled['required_success'] is True
            aggregate = json.loads((outputs/'mr3_p2a0_v10_reset_input_review_v1.json').read_text())
            assert len(aggregate['episodes']) == 8
        success = True
    ROWS.append({'name':name,'stage':stage,'mutation':mutation,'fixture_passed':success,'stage_passed':result['passed'] if result else None,'returncode':code,'exception':exception,'commands':len(calls),'directory':str(directory)})

for stage in ('interface','terminal','reset','deadline'):
    case('positive_'+stage,stage)
case('negative_reset_pooled','reset','pooled',False)
case('negative_reset_input_leaf','reset','leaf',False)
for kind in ('wrong_receipt_freeze','nonzero','typed','missing'):
    case('negative_'+kind,mutation=kind,expected=False)
for kind in ('hash','freeze','dirty'):
    case('rejected_'+kind,mutation=kind)
result = {'schema':'mr3-v10-stage-runner-independent-cli-fixtures-v1','passed':all(r['fixture_passed'] for r in ROWS),'source':str(SOURCE),'source_sha256':sha(SOURCE_BYTES),'plan_sha256':sha(PLAN_BYTES),'fixture_sha256':sha(Path(__file__).read_bytes()),'fixture_root':str(OUT),'cases':ROWS,'scope':'Actual unchanged runner main with explicit synthetic Git/source-file/subprocess test doubles; no consumer audit, ROS, simulator, native experiment, stage acceptance or task credit.'}
OUTPUT=Path('/tmp/mr3_p2a0_v10_audit_runner_fixtures_checks_v1.json')
with OUTPUT.open('x') as stream:
    stream.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
