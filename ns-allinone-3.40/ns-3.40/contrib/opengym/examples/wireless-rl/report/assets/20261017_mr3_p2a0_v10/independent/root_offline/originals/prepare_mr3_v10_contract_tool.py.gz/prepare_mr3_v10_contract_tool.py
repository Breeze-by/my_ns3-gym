from pathlib import Path

root=Path('/home/zhuyulab/ns3-workspace')
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
old=w/'report/assets/20261017_mr3_p2a0_v9/independent/mr3_p2a0_v9_contract_checks.py'
new=w/'report/assets/20261017_mr3_p2a0_v10/independent/mr3_p2a0_v10_contract_checks.py'
s=old.read_text().replace('Reviewed v9','Reviewed v10').replace('mr3-p2a0-v9','mr3-p2a0-v10').replace('d41485dfd93797026316806916e127eb5101f3b8','26534fae40409e266376baf0995fb15dc0223e4b')
s=s.replace('assert old_pins.keys() == new_pins.keys()', '''added = {audit.ROS + "src/multi_robot_exploration/multi_robot_exploration/" + n
         for n in ("mr3_control_phase.py", "mr3_motion_control.py")}
assert new_pins.keys() == old_pins.keys() | added''')
s=s.replace('for n in ("mr3_information.py",)', 'for n in ("mr3_information.py", "peer_obstacles.py", "motion_safety.py")')
s=s.replace('assert {p for p in new_pins if new_pins[p] != old_pins[p]} == allowed', '''assert {p for p in old_pins if new_pins[p] != old_pins[p]} == allowed
old_eval = pins(find(old_tree, "EVALUATOR_PHASE_PINS"))
new_eval = pins(find(new_tree, "EVALUATOR_PHASE_PINS"))
assert old_eval.keys() == new_eval.keys()
assert {p for p in old_eval if new_eval[p] != old_eval[p]} == {
    audit.ROS + "scripts/mr3_env_worker.py",
    audit.ROS + "src/multi_robot_exploration/multi_robot_exploration/task_evaluator.py"}''')
s=s.replace('"ENV_DOCUMENT_SHA256", "PREPARATION_RUNTIME_PINS", "EXECUTION_CONFIG_PINS"', '"ENV_DOCUMENT_SHA256", "EVALUATOR_PHASE_PINS", "PREPARATION_RUNTIME_PINS", "EXECUTION_CONFIG_PINS"')
s=s.replace('             audit.ROS + "src/multi_robot_exploration/multi_robot_exploration/motion_safety.py",\n','')
s=s.replace('"report/20261017_mr3_p2a0_v8.md", "report/20261017_mr3_p2a0_v9.md"', '"report/20261017_mr3_p2a0_v9.md", "report/20261017_mr3_p2a0_v10.md"')
assert not new.exists();new.write_text(s)
print('v10 explicit pin-change review tool created')
