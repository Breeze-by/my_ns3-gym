#include <gazebo/common/Plugin.hh>
#include <dlfcn.h>
#include <iostream>

int main(int argc, char **argv)
{
  if (argc != 2) return 2;
  void *handle = dlopen(argv[1], RTLD_NOW | RTLD_LOCAL);
  if (!handle) { std::cerr << dlerror() << '\n'; return 3; }
  using Factory = gazebo::SystemPlugin *(*)();
  const auto factory = reinterpret_cast<Factory>(dlsym(handle, "RegisterPlugin"));
  if (!factory) { std::cerr << dlerror() << '\n'; return 4; }
  auto *plugin = factory();
  const bool correct = plugin && plugin->GetType() == gazebo::SYSTEM_PLUGIN;
  std::cout << "{\"system_plugin_factory\":" << (correct ? "true" : "false")
            << ",\"load_called\":false,\"init_called\":false}"
            << '\n';
  delete plugin;
  dlclose(handle);
  return correct ? 0 : 1;
}
