"""Real finite fake CLI children only; no ROS, simulator or formal audit runs."""

import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch


SCRIPT = Path('/tmp/mr3_p2a0_v14_run_matrix_v1.py')
MODULE = importlib.util.spec_from_file_location('v14_matrix', SCRIPT)
matrix = importlib.util.module_from_spec(MODULE)
MODULE.loader.exec_module(matrix)

FAKE = '''import hashlib,json,sys,time
from pathlib import Path
TEMP=Path(TEMP_TOKEN)
A=Path(ASSET_TOKEN)
stage,freeze=sys.argv[1:]
planpath=A/'predeclared_plan_v14.json'
raw=planpath.read_bytes()
plan=json.loads(raw)
plan_sha=hashlib.sha256(raw).hexdigest()
spec=next(x for x in plan['stages'] if x['stage']==stage)
behavior=plan['fake_behavior']
prefix=TEMP/('mr3_p2a0_v14_'+stage)
role='launch' if 'launch_stage' in Path(__file__).name else 'audit'
def write(path,value):
 with path.open('x') as output:json.dump(value,output)
def proof(path):return {'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
time.sleep(.02)
if role=='launch':
 run=Path(spec['run_directory']);run.mkdir()
 success=behavior.get('launch_fail')!=stage
 summary=run/'benchmark_summary.json'
 write(summary,{'freeze':freeze,'passed':success})
 write(Path(str(prefix)+'_launch.json'),{'freeze':freeze,'stage':stage,'plan_sha256':plan_sha,
  'status':'completed','passed':success,'returncode':0 if success else 1,
  'within_wall_budget':True,'benchmark_summary':proof(summary),'wall_duration_sec':.02})
 if behavior.get('mutate_plan')==stage:planpath.write_text(raw.decode()+'\\n')
 if behavior.get('mutate_source')==stage:
  source=A/'independent/mr3_p2a0_v14_audit_stage.py'
  source.write_text(source.read_text()+'\\n# unexpected source mutation\\n')
 sys.exit(0 if success else 1)
else:
 success=behavior.get('audit_fail')!=stage
 leaves=[]
 for path in spec['required_audit_receipts']:
  path=Path(path)
  write(path,{'passed':success and behavior.get('false_leaf_cli0')!=stage,'freeze':freeze})
  leaves.append({**proof(path),'passed':success})
 write(Path(str(prefix)+'_audit_execution_v1.json'),{'freeze':freeze,'stage':stage,
  'plan_sha256':plan_sha,'passed':success,'all_submitted_jobs_finished':True,
  'runner_errors':[],'commands':[{'required_success':True,'passed':success,'returncode':0}],
  'receipts':leaves})
 sys.exit(0 if success else 1)
'''


class MatrixTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='mr3_v14_matrix_cpu_')
        self.addCleanup(self.temporary.cleanup)
        self.base = Path(self.temporary.name)
        self.root = self.base / 'repo'
        self.root.mkdir()
        self.temp = self.base / 'runtime'
        self.temp.mkdir()
        self.w = self.root / 'wireless'
        self.asset = self.w / 'assets'
        (self.asset / 'independent').mkdir(parents=True)
        self.plan = self.asset / 'predeclared_plan_v14.json'
        self.captured = io.StringIO()

    def tearDown(self):
        if not self.plan.exists():
            return
        evidence = Path('/tmp/mr3_p2a0_v14_matrix_controller_checks_v1/fixtures')
        evidence.mkdir(parents=True, exist_ok=True)
        index = 1
        while (evidence / (self._testMethodName + '_' + str(index))).exists():
            index += 1
        target = evidence / (self._testMethodName + '_' + str(index))
        target.mkdir()
        shutil.copytree(self.temp, target / 'runtime')
        shutil.copytree(self.asset, target / 'fake_assets')
        (target / 'controller_stdout.log').write_text(self.captured.getvalue())

    def prepare(self, **behavior):
        sources = []
        for operation in ('launch', 'audit'):
            path = self.asset / 'independent' / ('mr3_p2a0_v14_' + operation + '_stage.py')
            raw = FAKE.replace('TEMP_TOKEN', repr(str(self.temp))).replace(
                'ASSET_TOKEN', repr(str(self.asset)))
            path.write_text(raw)
            sources.append({'path': str(path.relative_to(self.root)),
                            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
        stages = [{'stage': stage, 'run_directory': str(self.temp / ('run_' + stage)),
                   'required_audit_receipts': [str(self.temp / (stage + '_formal.json'))]}
                  for stage in matrix.STAGES]
        self.plan.write_text(json.dumps({'schema': 'mr3-p2a0-predeclaration-v14',
            'readiness': {'status': 'ready', 'pending_bindings': []},
            'new_source_bindings_pending': [], 'stages': stages,
            'independent_source_bindings': sources, 'fake_behavior': behavior}))
        self.plan_before = self.plan.read_bytes()
        self.script_before = SCRIPT.read_bytes()
        subprocess.run(['git', 'init', '-q', '-b', 'main'], cwd=self.root, check=True)
        subprocess.run(['git', 'add', '.'], cwd=self.root, check=True)
        subprocess.run(['git', '-c', 'user.name=CPU fixture', '-c',
                        'user.email=cpu@example.invalid',
                        'commit', '-q', '-m', 'fake CLI fixture only'], cwd=self.root, check=True)
        self.freeze = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=self.root,
                                              text=True).strip()
        (self.temp / 'mr3_p2a0_v14_source_preflight.json').write_text(json.dumps({
            'passed': True, 'freeze': self.freeze,
            'plan_sha256': hashlib.sha256(self.plan_before).hexdigest()}))

    def run_main(self):
        with patch.multiple(matrix, ROOT=self.root, W=self.w, A=self.asset, TEMP=self.temp), \
                patch.object(sys, 'argv', [str(SCRIPT), self.freeze]), \
                contextlib.redirect_stdout(self.captured):
            return matrix.main()

    def ledger(self):
        return [json.loads(line) for line in
                (self.temp / 'mr3_p2a0_v14_remaining_matrix_v1.jsonl').read_text().splitlines()]

    def assert_closed(self):
        records = [row for row in self.ledger() if row['event'] == 'command_completed']
        self.assertTrue(records)
        for row in records:
            before, after = row['child_identity'], row['child_identity_after']
            self.assertIsNotNone(before)
            self.assertTrue(after is None or before['start_ticks'] != after['start_ticks'])
            self.assertIs(type(row['returncode']), int)
            self.assertRegex(row['console_sha256'], '^[0-9a-f]{64}$')
        self.assertEqual(SCRIPT.read_bytes(), self.script_before)

    def test_all_four_successes_require_eight_real_closed_cli_children(self):
        self.prepare()
        self.assertEqual(self.run_main(), 0)
        rows = self.ledger()
        self.assertEqual([(row['stage'], row['operation']) for row in rows
                          if row['event'] == 'command_completed'],
                         [(stage, operation) for stage in matrix.STAGES
                          for operation in ('launch', 'audit')])
        self.assertEqual([row['stage'] for row in rows if row['event'] == 'stage_passed'],
                         list(matrix.STAGES))
        self.assertEqual(rows[-1]['event'], 'matrix_complete')
        self.assertEqual(self.plan.read_bytes(), self.plan_before)
        self.assert_closed()

    def test_launch_failure_is_audited_once_then_later_stage_skips(self):
        self.prepare(launch_fail='reset')
        self.assertEqual(self.run_main(), 1)
        rows = self.ledger()
        self.assertEqual(rows[-1]['stage'], 'reset')
        self.assertEqual(rows[-1]['later_stages'], ['deadline'])
        self.assertEqual(sum(row.get('stage') == 'reset' and row.get('operation') == 'audit'
                             and row['event'] == 'command_completed' for row in rows), 1)
        self.assertFalse(any(row.get('stage') == 'deadline' for row in rows))
        self.assertEqual(self.plan.read_bytes(), self.plan_before)
        self.assert_closed()

    def test_audit_failure_does_not_launch_the_next_stage(self):
        self.prepare(audit_fail='terminal')
        self.assertEqual(self.run_main(), 1)
        rows = self.ledger()
        self.assertEqual(rows[-1]['stage'], 'terminal')
        self.assertFalse(any(row.get('stage') in ('reset', 'deadline') for row in rows))
        self.assert_closed()

    def test_cli_zero_and_positive_aggregate_cannot_hide_a_failed_actual_leaf(self):
        self.prepare(false_leaf_cli0='interface')
        self.assertEqual(self.run_main(), 1)
        row = self.ledger()[-1]
        self.assertTrue(row['native_ok'] and row['audit_ok'])
        self.assertIn('mandatory formal receipt failed', row['error'])
        self.assert_closed()

    def test_wait_exception_reaps_same_child_and_never_restores_pass(self):
        self.prepare()
        actual_popen = subprocess.Popen
        wrapped = []

        class WaitOnce:
            def __init__(self, child):
                self.child = child
                self.pid = child.pid
                self.calls = 0

            def wait(self):
                self.calls += 1
                if self.calls == 1:
                    raise KeyboardInterrupt('injected observer wait exception')
                return self.child.wait()

        def popen(argv, *args, **kwargs):
            child = actual_popen(argv, *args, **kwargs)
            if len(argv) > 1 and str(argv[1]).endswith('launch_stage.py') and not wrapped:
                wrapper = WaitOnce(child)
                wrapped.append(wrapper)
                return wrapper
            return child

        with patch.object(subprocess, 'Popen', side_effect=popen):
            self.assertEqual(self.run_main(), 1)
        self.assertGreaterEqual(wrapped[0].calls, 2)
        self.assertEqual(wrapped[0].child.returncode, 0)
        rows = self.ledger()
        launch = next(row for row in rows if row['event'] == 'command_completed'
                      and row['operation'] == 'launch')
        self.assertTrue(launch['errors'])
        self.assertFalse(rows[-1]['native_ok'])
        self.assertTrue(rows[-1]['audit_ok'])
        self.assert_closed()

    def test_source_or_plan_changes_block_audit_and_all_later_native(self):
        for key in ('mutate_source', 'mutate_plan'):
            with self.subTest(key=key):
                # Each subcase owns its own real fake repository/runtime directory.
                self.tearDown()
                self.setUp()
                self.prepare(**{key: 'interface'})
                self.assertEqual(self.run_main(), 1)
                rows = self.ledger()
                self.assertEqual([row['operation'] for row in rows
                                  if row['event'] == 'command_completed'], ['launch'])
                self.assertIn('changed during matrix', rows[-1]['error'])
                self.assert_closed()

    def test_an_existing_attempt_is_never_overwritten_or_retried(self):
        self.prepare()
        self.assertEqual(self.run_main(), 0)
        prior = (self.temp / 'mr3_p2a0_v14_remaining_matrix_v1.jsonl').read_bytes()
        with self.assertRaisesRegex(ValueError, 'already exists'):
            self.run_main()
        self.assertEqual((self.temp / 'mr3_p2a0_v14_remaining_matrix_v1.jsonl').read_bytes(), prior)
        self.assert_closed()


if __name__ == '__main__':
    unittest.main(verbosity=2)
