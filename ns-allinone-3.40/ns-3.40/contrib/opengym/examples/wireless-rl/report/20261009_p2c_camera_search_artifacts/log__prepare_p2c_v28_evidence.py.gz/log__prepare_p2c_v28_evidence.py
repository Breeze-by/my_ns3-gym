import ast,gzip,hashlib,json,re,subprocess
from pathlib import Path
from check_p2c_gate import launch_process_audit
from p2c_native_graph import native_tf_ingress_audit
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
parent='dffcb1fd05aba143dd267ab327706662dfdcb641'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def old(p):return subprocess.check_output(['git','show',f'{parent}:{p.relative_to(root)}'],cwd=root)
def archive(paths,name):
 dest=report/name;dest.mkdir();out=[]
 for p in sorted(set(paths)):
  q=dest/('__'.join(p.relative_to(r).parts)+'.gz')
  q.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0))
  assert gzip.decompress(q.read_bytes())==p.read_bytes()
  out.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(q.relative_to(report)),archive_sha256=sha(q)))
 return out
base=r/'log/p2c/20261009_p2c_v27';paths=list(base.glob('*/summary.json'));assert len(paths)==1
p=paths[0];s=load(p);d=s['result'];assert s['git_commit']==parent
assert not d['success'] and d['task_phase']=='RALLY' and d['termination_reason']=='timeout'
assert s['runner_returncode']==s['observer_returncode']==0
assert d['collision_events']==0 and not d['failed_robots']
assert all(v['battery_charge_count']==1 and v['battery_minimum_energy']>0 for v in d['robots'].values())
for n,h in s['evidence_sha256'].items():assert sha(p.parent/n)==h
gate=load(r/'log/p2c_v27_dev_forced2_gate.json');assert gate['status']=='FAIL'
audits=load(r/'log/p2c_v27_independent_audits.json');a=audits['dev_forced2']
assert all(v['status']=='PASS' for k,v in a.items() if k!='native_vs_gateway_frame_samples')
processes=launch_process_audit(p.parent);graph=native_tf_ingress_audit(load(p.parent/'native_graph.json'),2,True)
files=[x for x in base.rglob('*') if x.is_file() and x.suffix!='.pyc']
files += [r/'log'/n for n in ('check_p2c_v27_freeze.py','p2c_v27_freeze_check.json','p2c_v27_dev_forced2_runner.log','p2c_v27_dev_forced2_gate.json','p2c_v27_dev_forced2_gate.log','audit_p2c_v27_independent.py','p2c_v27_independent_audits.json','p2c_v27_independent_audits.log','peek_p2c_v27_tasks.py')]
failure=dict(status='FAIL',scope='First frozen development forced original; remaining cells never invoked',
 task_stack_frozen_commit=parent,original=s,strict_gate=gate,independent_audits=audits,
 launch_process_audit=processes,native_tf_graph_audit=graph,task_retries=0,
 all_owned_closed_before_edits=True,unrun=['other3 development','17 formal','both physical','917'],
 limitations='Healthy confirmation guard is retained, but first detection268s leaves too little time for the actual admitted rally travel. No elapsed-time causal attribution from different asynchronous originals; no backfill or relaxed horizon.',
 artifacts=archive(files,'20261009_p2c_v27_artifacts'))
(report/'20261009_p2c_v27_failed_development.json').write_text(json.dumps(failure,indent=2)+'\n')
(report/'20261009_p2c_v27_failed_development.md').write_text('''# P2C.1 v27 首原开发 FAIL

冻结dffcb1fd05aba143dd267ab327706662dfdcb641，强制二机原任务在268.0秒首次发现、270.4秒RALLY，300.2秒自然timeout；tb1最终仍距集合位7.013米，tb2误差0.04460米。两机各charge1，最低能量16.53536/6.94558，零接触/耗尽/failed机器人/任务期基础设施故障，owner与observer0，所有owned关闭后才编辑。原始summary/result/账本/地图/源/命令/环境/native图/metrics/关闭记录与SHA全部保留；strict首格FAIL，不将安全子门通过改作任务成功。

九类独立审计PASS：4闭合返航/3map预算/6pose租约/2local腿/2charger returns、120能量、27探索（10已知空间/17接续/2相对偏好/27局部可见偏好）、15AP返路否决、1完整集合选择；目标信息勘察0、healthy quiet0、确认间断后的恢复转向1、两前沿提前充电0。后3开发、17正式、两受控物理与917从未调用；无重试、回填、native300秒/5秒或TTL放宽。

当前已知空间兴趣来自历史位置两米圆盘，会抑制从未朝向相机的背面；该函数自身早已明确它不是视觉覆盖证明。新候选使用已交付位姿与实际朝向的历史视场，仍只是当前地图下的保守搜索偏好，不使用真实目标坐标、hidden队列、原生审计流或新radio包。它是新的独立算法，不把旧失败的时间差作为因果改进。

P3C.5已验收；P2C.1仍进行，无P4/ns-3/Wi-Fi/RL。
''')
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py'
scope=load(r/'log/p2c_v28_ast_scope.json');assert scope['changed_central']==['record_initial_search_visit','assign_idle_robots']
assert scope['changed_pure']==['known_space_search_candidates'] and scope['added_pure']==['camera_search_interest']
m=re.search(r'(\d+) passed in ([\d.]+)s',(r/'log/p2c_v28_full_components_optimized.log').read_text());assert m
b=re.search(r'4 packages finished \[([\d.]+)s\]',(r/'log/p2c_v28_build_optimized.log').read_text());assert b
source=load(r/'log/p2c_v28_source_optimized.json');runtime=load(r/'log/p2c_v28_visual_runtime_optimized.json')
assert source['status']==runtime['status']=='PASS' and runtime['control_sha256']==sha(control)
assert runtime['camera_search_audit']['camera_aware_visual_witnesses']==1
probe=load(r/'log/p2c_v28_camera_probe_optimized.json');assert probe['control_sha256']==sha(control)
assert all(load(r/'log'/n)['config']==load(r/'scripts'/cfg) for n,cfg in (
 ('p2c_v28_manifest.json','p2c_integration_manifest.json'),('p2c_v28_blackout_manifest.json','p2c_blackout_manifest.json')))
unchanged={}
for rel in ('src/multi_robot_exploration/multi_robot_exploration/battery_manager.py','src/multi_robot_exploration/multi_robot_exploration/tf_ingress_sampler.py','src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py','scripts/observe_p3b5.py','scripts/p2c_native_graph.py'):
 q=r/rel;assert old(q)==q.read_bytes();unchanged[rel]=sha(q)
qa=[q for q in (r/'log').glob('p2c_v28_*') if q.is_file() and q.suffix!='.pyc']
qa += [r/'log'/n for n in ('probe_p2c_v28_camera.py','probe_p2c_v28_camera_optimized.py','prepare_p2c_v28_evidence.py')]
components=dict(status='PASS',scope='Prospective delivered-heading current-map known-space search; no mission-success claim',
 parent_commit=parent,control_sha256=sha(control),ast_scope=scope,unchanged_from_parent=unchanged,
 functional_checks=int(m[1]),component_wall_sec=float(m[2]),directed_checks=88,directed_wall_sec=7.28,
 build_wall_sec=float(b[1]),source_audit=source,actual_ros_dds=runtime,synthetic_geometry_cpu_probe=probe,
 original_unoptimized_probe=load(r/'log/p2c_v28_camera_probe.json'),
 limits='Two-metre90degree sampled cones through current known-free grid only. Earlier map corrections and future actual perception remain uncertain. Current historical cone estimates never prove target absence or replace fresh navigation/return guards. Additional yaw-bin history may increase private read-only log size, not application CDR traffic. Synthetic CPU timings are not a worst-case task latency guarantee.',
 preparation_failure='First two-manifest metadata update encountered KeyError retained_failed_developments on physical manifest after integration file was written; corrected by setdefault, revalidated both. No task invocation.',
 unrun=['new4 development','new17 formal','new2 physical','917'],artifacts=archive(qa,'20261009_p2c_camera_search_artifacts'))
(report/'20261009_p2c_camera_search_components.json').write_text(json.dumps(components,indent=2)+'\n')
(report/'20261009_p2c_camera_search_components.md').write_text(f'''# P2C.1 v28 朝向感知搜索组件 PASS

v27首强制原任务发现268.0秒、300.2秒RALLYtimeout，安全子门通过而native失败，原始失败完整保留，其余任务未调用。新候选针对搜索中历史位置圆盘未考虑真实相机朝向的问题，只替换交替已知空间搜索的兴趣掩码：原始新鲜交付odom/TF各0..2秒，记录每0.5米/22.5度bin首次实际位置与yaw；在当前交付地图中按原2米/90度射线重建历史视场，occupied/unknown遮挡，优先补查其外已知自由空间。保持16个候选朝向、原alternation/有用接续/身体/完整返航预算/充电公平/全部TTL/native门限。没有检测前真实目标坐标、hidden状态、原生审计流或新应用包；历史视场估计不是物体不存在或完美感知的证明。

解析几何夹具验证前后朝向、墙/unknown遮挡、范围、无效源、去重、原始年龄与独立重建。240×240/.05米开放图，原位置圆盘抑制5021格，新90度视场抑制1284格并保留背面。首次实现全圆重建600合成view约2.529–2.556秒；缩至实际扇区并去除排序后约0.916–0.921秒。100view约0.153秒。射线从实际亚格位置出发，采样集合与初版略不同；这不是逐格数值等价、任务反事实或最坏延迟保证。两版源码、夹具、CPU输出都保留，只有优化版进入下一freeze。

88定向PASS7.28秒、{int(m[1])}完整功能PASS{float(m[2]):.2f}秒、四包{float(b[1]):.2f}秒、171保护/4授权/54协议、两manifest与actual ROS DDS PASS。DDS从隔离topic实际交付odom/TF，形成原yaw/source历史并经真实coordinator发布camera-aware visual witness，再独立重建；仍为合成地图且synthetic Nav2客户端。旧79候选数值/旧int64错误复现、target survey与quiet/lapsed检查继续保留。只改两个中央方法与已知候选函数、增加一个纯视场函数，其余71中央方法、原native energy/TF sampler/launch/physics/native completion字节保持；300秒/5秒与所有硬预算未放宽。

首声明更新因物理manifest没有retained_failed_developments字段出现KeyError，已setdefault修正并validate-only两份，不属于任务启动或重试。新all4/17正式/2物理须同clean pushed freeze；917未暴露。P3C.5已验收，无P4/ns-3/Wi-Fi/RL。
''')
note=f'2026-10-09 P2C.1 v28朝向感知已知空间搜索组件PASS待新冻结：v27首forced268.0s发现/270.4RALLY/300.2timeout，tb1仍7.013m，两机各charge1/最低6.94558/零接触耗尽failed任务期infra；9类审计PASS、27探索10补查/120能量/4closed return，原FAIL完整归档，其余3开发/17/2与917未调用。新用原fresh delivered pose/yaw/TF的0.5m/22.5deg历史，在当前known-free地图重建原2m/90deg相机扇区，保留未朝向背面；仅搜索偏好，不作目标不存在证明。88定向/{int(m[1])}全功能/四包{float(b[1]):.2f}s/171保护4授权54协议/actual DDS与两声明PASS；600合成view重建2.55→.92s，非任务/最坏保证。只2中央方法/1纯候选修改+1纯函数，其余71及native源/300s/5s/TTL/完整返航保持。新all4/17/2须clean pushed freeze，917未暴露；P3C.5已验收，无P4/ns-3/Wi-Fi/RL。报告20261009_p2c_camera_search_components.md和20261009_p2c_v27_failed_development.md。'
for q in (w/'AGENTS.md',w/'RESEARCH_PLAN.md',w/'IMPLEMENTATION_PLAN.md',r/'user_guide.md',r/'launch_commands.md'):
 first,rest=q.read_text().split('\n',1);q.write_text(first+'\n\n'+note+'\n'+rest)
q=root/'AGENTS.md';q.write_text(q.read_text().replace('## Current Handoff\n','## Current Handoff\n\n'+note+'\n',1))
with (w/'log.md').open('a') as f:
 f.write('\n\n## 2026-10-09 P2C.1 v27首原失败及v28朝向感知搜索\n\n'+note+'\n\n')
 f.write('dffcb1f commit/push0后独立check_p2c_v27_freeze.py PASS，source Humble+install/PYTHONNOUSERSITE=1/FastDDS UDPv4/taskset -c0-79；/usr/bin/python3 scripts/run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v27 --domain 210 --gazebo-port 20290 > log/p2c_v27_dev_forced2_runner.log。2026-10-09T02:46:38.459895..02:53:20.836313UTC，owner555758/observer555775 exit0；原268.0发现/300.2RALLYtimeout、两机charge1，check_p2c_gate.py --run-root log/p2c/20261009_p2c_v27 --development --cases dev_forced2 --output log/p2c_v27_dev_forced2_gate.json FAIL native success；audit_p2c_v27_independent.py九类PASS；ps核验owned owner/observer已关闭后才改源。其余3开发/17正式/2物理/917未启动，无重试/回填。全部raw/source/environment/命令/config/SHA/native图/metrics/关闭代码/失败traceback归档。\n\n')
 f.write('v28替换兴趣掩码并记录实际交付yaw，pytest -q test_camera_aware_search.py/test_initial_known_search.py/test_mission_search_diversity.py初87 PASS7.32s；actual DDS check_p2c_visual_runtime.py --output log/p2c_v28_visual_runtime.json/domain215 PASS；probe_p2c_v28_camera.py合成seed28/240x240/.05m/1,100,600view各3次，600约2.55s导致算法精简到真实扇区、亚格position投射及无需unique排序，初未优化源码/输出保留，不进task。首次manifest编辑第二physical无retained_failed_developments字段KeyError，setdefault修正后两validate-only PASS；不是任务调用。\n\n')
 f.write(f'优化后88定向PASS7.28s、全pytest功能三lint ignore{int(m[1])} PASS{float(m[2]):.2f}s、四包colcon build{float(b[1]):.2f}s；check_p2c_source.py --output log/p2c_v28_source_optimized.json PASS171/4/54；check_p2c_visual_runtime.py --output log/p2c_v28_visual_runtime_optimized.json/domain215实际DDS source保留/camera reader/quiet/survey PASS。run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v28 --domain210 --gazebo-port20290 --validate-only，以及--case physical_fault --manifest scripts/p2c_blackout_manifest.json --run-id 20261009_p2c_v28_physical --domain219 --gazebo-port20299 --validate-only；probe_p2c_v28_camera_optimized.py600view.916–.921s，100view.153s。精准原日志、两版源码/输入与输出有SHA压缩原件。新4/17/2须同推送冻结，当前未运行，917未暴露，无P4/ns-3/Wi-Fi/RL。\n')
print(json.dumps(dict(failure_artifacts=len(failure['artifacts']),component_artifacts=len(components['artifacts']),functional_checks=int(m[1]),build_sec=float(b[1]),scope=scope)))
