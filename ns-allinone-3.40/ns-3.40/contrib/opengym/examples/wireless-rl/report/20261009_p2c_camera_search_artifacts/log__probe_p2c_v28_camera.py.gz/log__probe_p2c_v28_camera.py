import hashlib,json,math,time
from pathlib import Path
import numpy as np
from multi_robot_exploration import control as c
grid=np.zeros((240,240),dtype='<i2');grid[:,120]=100;grid[100:141,120]=0
grid.setflags(write=False);rng=np.random.default_rng(28);rows=[]
for count in (1,100,600):
 views=[dict(position=list(rng.uniform(.5,11.5,2)),yaw=float(rng.uniform(-math.pi,math.pi))) for _ in range(count)]
 times=[]
 for _ in range(3):
  start=time.perf_counter();interest=c.camera_search_interest(grid,.05,(0.,0.),views);times.append(time.perf_counter()-start)
 rows.append(dict(synthetic_views=count,wall_sec=times,remaining_known_interest_cells=int(interest.sum())))
center=[6.025,6.025];open_grid=np.zeros((240,240),dtype='<i2')
old=c.known_search_interest(open_grid,.05,(0.,0.),[center])
new=c.camera_search_interest(open_grid,.05,(0.,0.),[dict(position=center,yaw=0.)])
result=dict(status='PASS',scope='Synthetic algorithm geometry and CPU probe, no historical actual camera trace or task counterfactual',
 seed=28,grid_shape=list(grid.shape),resolution=.05,history_benchmarks=rows,
 omnidirectional_visit_discounted_cells=int((~old).sum()),directional_cone_discounted_cells=int((~new).sum()),
 back_side_preserved=bool(new[120,100]),control_sha256=hashlib.sha256(Path(c.__file__).read_bytes()).hexdigest())
assert result['back_side_preserved'] and result['directional_cone_discounted_cells']<result['omnidirectional_visit_discounted_cells']
Path('log/p2c_v28_camera_probe.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
