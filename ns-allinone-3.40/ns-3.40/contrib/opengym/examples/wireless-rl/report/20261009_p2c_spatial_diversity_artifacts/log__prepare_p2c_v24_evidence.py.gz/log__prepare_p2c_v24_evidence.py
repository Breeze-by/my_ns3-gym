import ast,gzip,hashlib,json,re,subprocess
from pathlib import Path
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
parent='930d7a041b361a731883c469ed51d553710a97fc'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def old(p):return subprocess.check_output(['git','show',f'{parent}:{p.relative_to(root)}'],cwd=root)
def archive(paths,name):
    destination=report/name;destination.mkdir();rows=[]
    for p in sorted(set(paths)):
        out=destination/('__'.join(p.relative_to(r).parts)+'.gz');assert not out.exists()
        out.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0));assert gzip.decompress(out.read_bytes())==p.read_bytes()
        rows.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(out.relative_to(report)),archive_sha256=sha(out)))
    return rows
base=r/'log/p2c/20261009_p2c_v23';paths=list(base.glob('*/summary.json'));assert len(paths)==1
original=load(paths[0]);assert original['git_commit']==parent and original['case']=='dev_forced2'
assert original['runner_returncode']==original['observer_returncode']==0
assert not any(v for k,v in original.items() if k.endswith('_forced_shutdown'))
result=original['result'];assert not result['success'] and result['task_phase']=='RALLY' and result['collision_events']==0 and not result['failed_robots']
assert all(v['battery_charge_count']==1 and v['battery_minimum_energy']>0 for v in result['robots'].values())
for name,h in original['evidence_sha256'].items():assert sha(paths[0].parent/name)==h
gate=load(r/'log/p2c_v23_dev_forced2_gate.json');assert gate['status']=='FAIL'
independent=load(r/'log/p2c_v23_independent_audits.json')
assert all(v['status']=='PASS' for k,v in independent['dev_forced2'].items() if k!='native_vs_gateway_frame_samples')
time_diagnostic=load(r/'log/p2c_v23_rally_time_order_diagnostic.json');assert time_diagnostic['status']=='PASS'
diversity=load(r/'log/p2c_v23_spatial_diversity_diagnostic.json');assert diversity['status']=='PASS'
from check_p2c_gate import launch_process_audit
processes=launch_process_audit(paths[0].parent)
files=[p for p in base.rglob('*') if p.is_file() and p.suffix!='.pyc']
files += [r/'log'/n for n in ('p2c_v23_freeze_check.json','check_p2c_v23_freeze.py','p2c_v23_dev_forced2_runner.log',
    'p2c_v23_dev_forced2_gate.json','p2c_v23_dev_forced2_gate.log','audit_p2c_v23_independent.py',
    'p2c_v23_independent_audits.json','p2c_v23_independent_audits.log','p2c_v23_rally_assignment_input.json',
    'probe_p2c_v23_rally_time_order.py','p2c_v23_rally_time_order_diagnostic.json','p2c_v23_rally_time_order_diagnostic.log',
    'probe_p2c_v23_spatial_diversity.py','p2c_v23_diversity_input.json','p2c_v23_spatial_diversity_diagnostic.json','p2c_v23_spatial_diversity_diagnostic.log')]
failure=dict(status='FAIL',scope='First forced development original only',task_stack_frozen_commit=parent,
    original=original,strict_gate=gate,independent_audits=independent,launch_process_audit=processes,
    task_time_infrastructure_failures=0,task_retries=0,all_owned_closed_before_edits=True,
    conditional_time_order_trial=time_diagnostic,time_order_trial_adopted=False,conditional_diversity_trial=diversity,
    unrun=['other3 development','17 formal','both physical','917 first exposure'],
    artifacts=archive(files,'20261009_p2c_v23_artifacts'))
(report/'20261009_p2c_v23_failed_development.json').write_text(json.dumps(failure,indent=2)+'\n')
(report/'20261009_p2c_v23_failed_development.md').write_text('''# P2C.1 v23 首个强制原任务 FAIL

冻结 `930d7a041b361a731883c469ed51d553710a97fc` 的dev_forced2：228.2s检测、232.3s RALLY、原生timeout300.4s。截止时tb1距最终位1.5008m、仍以0.2598m/s移动，无原生完成或5秒保持证明；两机各charge1、最低16.311747，零接触/耗尽/机器人失效/任务期间子进程崩溃，外层owner/observer0自然关闭。任务后实际清理退出单独保留，不称每个子进程都优雅退出。strict FAIL和全部原始保留，其他三开发/17正式/两物理/917未调用，无重试、回填或原门槛放宽。

独立原输入检查PASS：5closed返航/3map预算/7pose租约/2本地腿/2charger return、122能量样本、24实际探索其中6补查/10接续/3相对折扣、一成功集合分配、完整native图。实际补查发布类型与朝向重建通过，工程证据不代替任务完成。两机合计探索39.1266m、集合9.9801m；后继集合行程未在时限内结束，不能把检测/89.47%覆盖当任务成功。

只读替代集合排序使用完整原AP分配输入：名义串行行程65.2442→64.9385s、最长11.6660→10.8574m，两者不是真实反事实完成时间；未采用该改动。只读空间均衡比较使用实际114.4s补查输入、25历史位置记录、原图/模型/排除/机体路径；115个完整预算足够的条件候选。平方根/线性两种有界折扣均改变条件排序，平方根首项由(5.3554,2.8065)/预算24.0917变为(2.3554,-0.2935)/预算18.6728，仍缺原全部在途预约，不声称该替代在原任务中可以实际派发或减少完成时间。选择较温和的平方根版本作为未来候选，集合排序保持。全部诊断脚本/输入/输出/SHA保留。

P3C.5已验收，无P4/ns-3/Wi-Fi/RL。
''')
checks=(r/'log/p2c_v24_full_components.log').read_text();m=re.search(r'(\d+) passed in ([\d.]+)s',checks);assert m and 'FAILED' not in checks
b=re.search(r'4 packages finished \[([\d.]+)s\]',(r/'log/p2c_v24_build.log').read_text());assert b
source=load(r/'log/p2c_v24_source.json');assert source['status']=='PASS'
runtime=load(r/'log/p2c_v24_visual_runtime.json');assert runtime['status']=='PASS' and runtime['mission_diversity_audit']['spatial_diversity_witnesses']==1
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py';assert runtime['control_sha256']==sha(control)
def methods(text):
    node=next(n for n in ast.parse(text).body if isinstance(n,ast.ClassDef) and n.name=='HeadquartersControl')
    return {n.name:ast.dump(n,include_attributes=False) for n in node.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
before=methods(old(control));after=methods(control.read_bytes());changed=[name for name,value in before.items() if value!=after[name]]
assert set(changed)=={'frontier_travel_preference','assign_idle_robots'},changed
old_functions={n.name:ast.dump(n) for n in ast.parse(old(control)).body if isinstance(n,ast.FunctionDef)}
new_functions={n.name:ast.dump(n) for n in ast.parse(control.read_bytes()).body if isinstance(n,ast.FunctionDef)}
assert all(value==new_functions[name] for name,value in old_functions.items()),'an existing pure geometry/assignment function changed'
unchanged={}
for rel in ('src/multi_robot_exploration/multi_robot_exploration/battery_manager.py',
    'src/multi_robot_exploration/multi_robot_exploration/tf_ingress_sampler.py',
    'src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py','scripts/observe_p3b5.py','scripts/p2c_native_graph.py'):
    p=r/rel;assert p.read_bytes()==old(p);unchanged[rel]=sha(p)
for n,c in (('p2c_v24_manifest.json','p2c_integration_manifest.json'),('p2c_v24_blackout_manifest.json','p2c_blackout_manifest.json')):
    assert load(r/'log'/n)['config']==load(r/'scripts'/c)
qa=[r/'log'/n for n in ('p2c_v24_directed.log','p2c_v24_directed_final.log','p2c_v24_full_components.log','p2c_v24_build.log',
    'p2c_v24_source.json','p2c_v24_source.log','p2c_v24_manifest.json','p2c_v24_blackout_manifest.json',
    'p2c_v24_visual_runtime.json','p2c_v24_visual_runtime.log','prepare_p2c_v24_evidence.py')]
components=dict(status='PASS',scope='Prospective bounded spatial-diversity components, not task completion',parent_commit=parent,
    functional_checks=int(m[1]),component_wall_sec=float(m[2]),build_wall_sec=float(b[1]),control_sha256=sha(control),source_audit=source,
    changed_central_methods=changed,preserved_central_methods=len(before)-len(changed),all_existing_pure_functions_ast_preserved=True,
    unchanged_from_parent=unchanged,actual_visual_dds=runtime,
    reused_actual_ap_snapshot_evidence='Constructor and all four snapshot callbacks unchanged; original v22 actual50-snapshot/TF-only DDS proof retained. New complete task graph still mandatory.',
    algorithm='Eight angular visit sectors around cached delivered static charger centroid, outside2m; max(.25,1/sqrt(1+count)) multiplies nominal frontier/known-search utility in complete object missions only.',
    hard_constraints='No changes to actual body/reservations/whole approach+qualified return/energy/source leases/charging/native300s/5s/Nav2/physics or original physical stimulus.',
    unrun=['new all4 development','new17 formal','new2 physical','917 first exposure'],
    artifacts=archive(qa,'20261009_p2c_spatial_diversity_artifacts'))
(report/'20261009_p2c_spatial_diversity_components.json').write_text(json.dumps(components,indent=2)+'\n')
(report/'20261009_p2c_spatial_diversity_components.md').write_text(f'''# P2C.1 v24 有界空间均衡搜索组件 PASS

v23首个强制原任务RALLY timeout300.4s，6真实补查与全部独立工程检查通过但未原生完成；原FAIL和所有输入保持。新完整对象任务在原名义效用上增加八方向的历史行走偏好：AP缓存交付静态充电点的均值为锚点，2m内中性，外部按已有0.5m历史位姿bin计数，以max(0.25,1/sqrt(1+count))作软折扣。最大四倍、始终正数；保留原两倍有用接续/更近且预算足够同伴偏好。历史行走绝不当真实视野覆盖、目标不存在、隐藏当前队列或新AP观测。缺失/无效静态模型不产生非有限排序；纯建图保持。

原所有硬能源、完整已知路径、机体、预约、源TTL、串行充电与实际派发检查不变；新增私有record可重建model anchor/history/source age/sector counts/factor/adjusted utility，无新增无线应用包。平方根与线性条件比较都改变排序，采用较温和平方根；原完整集合排序替代仅0.3057s名义串行变化，未采用。条件候选预算24.0917→18.6728只是同一保存状态的预算差，缺原全部在途预约，不是实际任务/能源/因果收益。

定向90PASS7.68s，补模型缺失/无效及双用途history一致性后94PASS8.22s；全{int(m[1])}PASS{float(m[2]):.2f}s、四包{float(b[1]):.2f}s、171保护/4已授权/54协议、普通/物理预声明PASS。实际DDS新完整battery/history偏好发布和独立reader PASS；原NumPy异常复现与79候选数值一致性仍PASS。两中央方法变更、其余{len(before)-len(changed)}方法及全部原纯几何/集合函数AST保持，native battery/sampler/launch/native图工具字节保持；实际AP50快照/TF重投影证明按相同constructor/callback AST保留。

新同提交4开发/17正式/2物理尚待冻结；917未暴露。原300秒/5秒/TTL/物理刺激保持，没有最优、最坏完成、硬件安全或Wi-Fi测量保证。P3C.5已验收，无P4/ns-3/Wi-Fi/RL。
''')
note=f'2026-10-09 P2C.1 v24空间均衡组件PASS、待新冻结任务：v23首forced检测228.2/RALLY232.3/timeout300.4，末tb1尚距目标1.5008m；两机各charge1/min16.311747/零接触耗尽机器人失效任务期infra，原FAIL保持。6补查/24探索/5closed return/122能量和源图审计PASS。新完整对象任务以交付静态充电点均值为锚，已有鲜位姿历史按8方向/2m外统计，用max(.25,1/sqrt(1+count))有限软折扣；不是视觉覆盖。条件115候选平方根/线性比较保留，采用温和平方根；集合排序交换试验未采用。{int(m[1])}功能/94定向/四包{float(b[1]):.2f}s/171保护4授权/54协议/actual完整偏好DDS/两manifest PASS，原纯几何集合/native battery/sampler/launch/TTL/300s/5s/所有硬派发保护保持。新4开发/17正式/2物理须clean pushed freeze，917未暴露，P3C.5已验收，无P4/ns-3/Wi-Fi/RL。报告20261009_p2c_spatial_diversity_components.md与20261009_p2c_v23_failed_development.md。'
for p in (w/'AGENTS.md',w/'RESEARCH_PLAN.md',w/'IMPLEMENTATION_PLAN.md',r/'user_guide.md',r/'launch_commands.md'):
    first,rest=p.read_text().split('\n',1);p.write_text(first+'\n\n'+note+'\n'+rest)
p=root/'AGENTS.md';p.write_text(p.read_text().replace('## Current Handoff\n','## Current Handoff\n\n'+note+'\n',1))
with (w/'log.md').open('a') as f:
    f.write('\n\n## 2026-10-09 P2C.1 v23首原任务FAIL与v24有界搜索均衡\n\n'+note+'\n\n')
    f.write('系统Python3/source Humble+install/PYTHONNOUSERSITE=1、FastRTPS/UDPv4、taskset -c0-79。930d7a0推送后独立clean freeze PASS，run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v23 --domain 210 --gazebo-port 20290；原RALLYtimeout300.4，无retry或回填，owner/observer自然0，全部关闭后才改源码。check_p2c_gate.py --run-root log/p2c/20261009_p2c_v23 --development --cases dev_forced2 --output log/p2c_v23_dev_forced2_gate.json FAIL；audit_p2c_v23_independent.py七类PASS（补查新旗标true），实际task-time launch exits PASS，cleanup退出另存。所有exact commands/配置/源和输入SHA见原summary与归档。\n\n')
    f.write('probe_p2c_v23_rally_time_order.py只读保存原分配并内存编译替代排序：名义串行65.2442→64.9385s，未采用；probe_p2c_v23_spatial_diversity.py原实际114.4s/25历史/115 funded-body-route候选比较sqrt与linear，采用sqrt，所有原输入/输出与局限保留。定向test_mission_search_diversity/test_initial_known_search/test_relative_frontier_travel90PASS7.68s，补模型无效/缺失与视觉history一致性94PASS8.22s；全pytest三lint ignore见组件数；四包colcon build/check_p2c_source/two run_p2c_tasks validate-only/actual check_p2c_visual_runtime domain215完整模型偏好DDS PASS。新4开发/17正式/2物理/917未启动，无任务/无线因果宣称。\n')
print(json.dumps(dict(failure_artifacts=len(failure['artifacts']),component_artifacts=len(components['artifacts']),checks=int(m[1]),build_sec=float(b[1]),preserved_methods=components['preserved_central_methods'])))
