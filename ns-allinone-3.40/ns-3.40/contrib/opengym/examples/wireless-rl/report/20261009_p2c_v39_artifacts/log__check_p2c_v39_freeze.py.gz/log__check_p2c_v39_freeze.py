import hashlib,json,os,subprocess
from pathlib import Path
from datetime import datetime,timezone
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
head=git('rev-parse','HEAD');upstream=git('rev-parse','@{u}')
assert head=='10860f4029fe26c1517bd550ff6251870693bf7b' and head==upstream,(head,upstream)
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
rows=[row for row in subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=root).decode().split('\0') if row]
assert len(rows)==14 and all(row[:3]=='?? ' and row[3:].startswith('260929_report/') for row in rows),rows
assert not (r/'log/p2c/20261009_p2c_v39').exists()
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py'
assert hashlib.sha256(control.read_bytes()).hexdigest()=='23dde5710f93eab940372e81b73f5bd2000638db1dd72711cf29d2c4f08a9471'
native=r/'src/multi_robot_exploration/multi_robot_exploration/battery_manager.py'
assert hashlib.sha256(native.read_bytes()).hexdigest()=='403809f4bc25f7c10c3a811afded2d3a1363e2a624fcd7fd851bde6609b99eee'
for p in (r/'log/p2c/20261009_p2c_v38').glob('*/summary.json'):
    old=json.loads(p.read_text())
    for key in ('owner_pid','observer_pid'):
        try:os.kill(old[key],0)
        except ProcessLookupError:pass
        else:raise AssertionError(('prior owned process live',key,old[key]))
result=dict(status='PASS',head=head,upstream=upstream,worktree_status=rows,checked_at_utc=datetime.now(timezone.utc).isoformat(),
    no_current_originals_before_first_launch=True,v38_all_owned_closed=True,control_sha256=hashlib.sha256(control.read_bytes()).hexdigest())
(r/'log/p2c_v39_freeze_check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status='PASS',head=head,user_untracked_files=14)))
