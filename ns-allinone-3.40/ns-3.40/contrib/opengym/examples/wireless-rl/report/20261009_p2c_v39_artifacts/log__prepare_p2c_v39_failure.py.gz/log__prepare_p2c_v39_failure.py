import collections, gzip, hashlib, json, os
from pathlib import Path
from datetime import datetime, timezone

root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
base=r/'log/p2c/20261009_p2c_v39';paths=list(base.glob('*/summary.json'));assert len(paths)==1
p=paths[0];s=json.loads(p.read_text());z=s['result'];freeze='10860f4029fe26c1517bd550ff6251870693bf7b'
assert s['git_commit']==freeze and s['case']=='dev_forced2' and not z['success']
assert z['collision_events']==0 and not z['failed_robots']
assert s['runner_returncode']==s['observer_returncode']==0
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
closure={}
for key in ('owner_pid','observer_pid'):
 try:os.kill(s[key],0)
 except ProcessLookupError:closure[key]=dict(pid=s[key],closed=True)
 else:raise AssertionError(('live',key))
closure['checked_at_utc']=datetime.now(timezone.utc).isoformat()
(r/'log/p2c_v39_closed_before_edit.json').write_text(json.dumps(closure,indent=2)+'\n')
for name,digest in s['evidence_sha256'].items():assert sha(p.parent/name)==digest
gate=json.loads((r/'log/p2c_v39_dev_forced2_gate.json').read_text());assert gate['status']=='FAIL'
audits=json.loads((r/'log/p2c_v39_independent_audits.json').read_text())
assert len(audits['dev_forced2'])==12 and all(v['status']=='PASS' for v in audits['dev_forced2'].values())
rows=[json.loads(line) for line in (p.parent/'ledger.jsonl').open()]
leases=collections.Counter(e['stage'] for e in rows if e.get('event')=='coordinator_planning_lease_expired')
snapshot_binding={}
snapshots=list((r/'log').glob('p2c_v39_dev_forced2_*snapshot.json'))
for q in snapshots:
 e=json.loads(q.read_text());assert any(x==e for x in rows)
 snapshot_binding[q.name]=dict(snapshot_sha256=sha(q),original_ledger_sha256=sha(p.parent/'ledger.jsonl'),ledger_index=e['ledger_index'])
files=[q for q in base.rglob('*') if q.is_file() and q.suffix!='.pyc']+snapshots
files += [r/'log'/name for name in ['check_p2c_v39_freeze.py','p2c_v39_freeze_check.json',
  'p2c_v39_dev_forced2_runner.log','p2c_v39_dev_forced2_gate.log','p2c_v39_dev_forced2_gate.json',
  'audit_p2c_v39_independent.py','p2c_v39_independent_audits.json','p2c_v39_independent_audits.log',
  'peek_p2c_v39_tasks.py','p2c_v39_closed_before_edit.json','prepare_p2c_v39_failure.py']]
assert all(q.exists() for q in files)
destination=report/'20261009_p2c_v39_artifacts';assert not destination.exists();destination.mkdir();artifacts=[]
for q in sorted(set(files)):
 a=destination/('__'.join(q.relative_to(r).parts)+'.gz');a.write_bytes(gzip.compress(q.read_bytes(),compresslevel=6,mtime=0))
 assert gzip.decompress(a.read_bytes())==q.read_bytes()
 artifacts.append(dict(source=str(q.relative_to(root)),source_sha256=sha(q),archive=str(a.relative_to(report)),archive_sha256=sha(a)))
out=dict(status='FAIL',scope='First required forced-development original failed; other3 development/formal17/physical2/917 not invoked',
 task_stack_frozen_commit=freeze,original=s,first_required_gate=gate,independent_audits=audits,
 all_owned_closed=closure,planning_lease_aborts=dict(leases),exact_snapshot_binding=snapshot_binding,
 task_retries=0,artifacts=artifacts)
(report/'20261009_p2c_v39_failed_development.json').write_text(json.dumps(out,indent=2)+'\n')

text=f"""# P2C.1 v39 首强制原任务 FAIL

冻结10860f4029fe26c1517bd550ff6251870693bf7b；原任务RALLY timeout300.4s，success=false、completion_time=null、无完整native保持证明。目标279.8s检测、295.9s进入RALLY；tb1/tb2最终位置误差1.527/4.750m。两机各charge1、最低7.955903940818573，零接触/耗尽/failed机器人/任务期基础设施失败/任务重试。owner700952/observer700971自然exit0并关闭，全strict FAIL；267 live/12独立原始审计PASS不能替代任务成功。其他3开发/17正式/2物理/917未调用。

新外圈边界采样确实参与一份实际集合分配；两份等待完整分配的失败输入同样保留。晚发现和来源租约计算弃置主导了本轮时间限制，不能用离线更低软返路风险声称实际任务更快。33份规划来源过期弃置中19candidate_generation/13candidate_budget/1route_admission，全部保留且原TTL无放宽。两份准确弃置原输入逐字ledger绑定，不是其后另采或重建的替代输入。

只读固定epoch/profile候选分析约.950–.984/1.482–1.564wall秒；原剩余来源窗口1.291/1.489sim秒，两个量单位不同并且sim/wall速度可能变化，不能直接换成原现场延迟或因果时间损失。原新鲜度等待明确保留，不替真实时序验证。profile显示完整known返航、候选预算和相对旅行偏好是主要成本，原几何cache已存在。后续候选只能优化计算排序与有证明的界，不绕过完整返路、body/路线、充电公平与原2/5/60s源租约。

所有原始结果、源/环境/命令/图/账本/安全输入SHA、strict traceback、独立检查和关闭证据见JSON/gzip。原300s/.35/.05/.1/5s与安全门不变；本轮失败不回填到任何旧成功。P2C.1未通过，P3C.5已验收，无P4/ns-3/Wi-Fi/RL。
"""
(report/'20261009_p2c_v39_failed_development.md').write_text(text)
heading='## 2026-10-09 P2C.1 v39 首强制开发原任务 FAIL'
assert heading not in (w/'log.md').read_text()
with (w/'log.md').open('a') as f:
 f.write('\n\n'+heading+'\n\n10860f4 commit/push0，check_p2c_v39_freeze.py PASS；Humble+install/PYTHONNOUSERSITE1/FastDDS UDPv4清profiles，taskset -c 0-79 /usr/bin/python3 scripts/run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v39 --domain 210 --gazebo-port 20290 > log/p2c_v39_dev_forced2_runner.log 2>&1。原launch/observer/config/case/source SHA保留。\n\n')
 f.write(f"RALLY timeout{z['elapsed_sim_time_sec']:.1f}s，detect279.8/rally295.9/completion=null；Nav2{z['nav_goal_count']}/各charge1/min{z['battery_minimum_energy']}，0contacts/exhaustion/failed/task-time infra/retry；owner{s['owner_pid']}/observer{s['observer_pid']} exit0/0闭合，所有原件SHA保持。check_p2c_gate.py --run-root log/p2c/20261009_p2c_v39 --development --cases dev_forced2 --output log/p2c_v39_dev_forced2_gate.json exit1/FAIL，267 live与12审计PASS不能代替任务成功。其他3dev/17formal/2physical/917未调用。\n\n")
 f.write('33 lease弃置19gen/13budget/1route；两份原输入逐字ledger绑定。实际1chosen/2failed集合分配均完整重建PASS；新采样参与，但探索晚发现无实测任务收益。profile_p2c_v40_forced_inputs.py固定epoch3cold .950–.984/1.482–1.564wall秒，sim来源剩余1.291/1.489sec不能直接当现场延迟或因果时间损失；原CPU/真实clock尚有余量风险。原保护/TTL/预算/刺激不变，后续只在实际输入上验证有证明的计算界，失败全部保留。\n')
print(json.dumps(dict(status='FAIL',originals=1,audits=12,artifacts=len(artifacts),owned_closed=True)))
