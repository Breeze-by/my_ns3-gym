import json,base64,zlib,numpy as np
from pathlib import Path
from scipy.ndimage import label
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from multi_robot_exploration import control as c
e=json.loads(Path('log/p2c_v38_native_no_route_snapshot.json').read_text());m=e['map_evidence'];g=np.frombuffer(zlib.decompress(base64.b64decode(m['grid'])),dtype='<i2').reshape(m['shape'])
res=m['resolution'];origin=m['origin'];pos=e['position'];home=e['home'];rad=e['charge_radius_m'];p=c.world_to_grid(*pos,res,*origin)
safe,distances,_=c.charging_route_field(g,res,origin,home,rad,{})
rows,cols=np.indices(g.shape);xs=origin[0]+(cols+.5)*res;ys=origin[1]+(rows+.5)*res
mask=(xs-home[0])**2+(ys-home[1])**2<=(rad-.2)**2
labels,num=label(g==0)
raw_connected=np.any((labels==labels[p])&mask)
components,count=label(safe);contact_seeds=safe&mask
out=dict(current_cell_value=int(g[p]),current_safe=bool(safe[p]),raw_free_4connected_to_contact=bool(raw_connected),
 safe_contact_seeds=int(np.count_nonzero(contact_seeds)),same_safe_component_has_contact=bool(np.any((components==components[p])&contact_seeds)),
 current_component_cells=int(np.count_nonzero(components==components[p])),home_contact_components=np.unique(components[contact_seeds]).tolist())
print(json.dumps(out))
fig,axs=plt.subplots(1,2,figsize=(13,6))
extent=(origin[0],origin[0]+g.shape[1]*res,origin[1],origin[1]+g.shape[0]*res)
axs[0].imshow(np.where(g<0,.5,np.where(g>0,0.,1.)),origin='lower',extent=extent,cmap='gray',vmin=0,vmax=1)
axs[0].set_title('Original local SLAM map')
display=np.zeros((*g.shape,3));display[g<0]=(.45,.45,.45);display[g==0]=(.9,.9,.9)
display[safe]=(0.6,0.75,0.95);display[(components==components[p])&safe]=(0.2,0.5,0.95);display[np.isfinite(distances)]=(0.2,.85,.4)
axs[1].imshow(display,origin='lower',extent=extent);axs[1].set_title('Blue: start component; green: charger reachable')
for ax in axs:
 ax.scatter(*pos,c='red',marker='x',s=70,label='failed tb1');ax.scatter(*home,c='orange',s=70,label='tb1 charger')
 ax.add_patch(plt.Circle(home,rad,color='orange',fill=False));ax.set_xlim(-5.5,7.);ax.set_ylim(-5.5,5.5);ax.set_aspect('equal');ax.legend(loc='lower right')
fig.tight_layout();fig.savefig('log/p2c_v39_return_connectivity.png',dpi=140);plt.close(fig)
Path('log/p2c_v39_return_connectivity.json').write_text(json.dumps(out,indent=2)+'\n')

