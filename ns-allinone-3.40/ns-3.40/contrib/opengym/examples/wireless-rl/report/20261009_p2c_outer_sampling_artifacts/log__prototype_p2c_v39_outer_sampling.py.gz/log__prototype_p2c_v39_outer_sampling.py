import ast,base64,dataclasses,hashlib,inspect,json,math,time,zlib
from pathlib import Path
import numpy as np
from scipy.ndimage import distance_transform_edt
from multi_robot_exploration import control as c
path=Path('log/p2c/20261009_p2c_v38/20261009_p2c_v38_dev_forced2/ledger.jsonl')
event=next(e for l in path.open() if (e:=json.loads(l)).get('event')=='coordinator_rally_assignment_chosen')
fixture=Path('log/p2c_v38_rally_assignment_input.json');assert json.loads(fixture.read_text())==event
def decode(s):return dict(data=np.frombuffer(zlib.decompress(base64.b64decode(s['grid'])),dtype='<i2').reshape(s['shape']),resolution=s['resolution'],origin=s['origin'])
base=c.rally_pose_candidates
def adaptive(raw_grid,resolution,origin,target,dense=False,stratified=False):
 result=base(raw_grid,resolution,origin,target,dense,stratified)
 if dense or stratified:return result
 safe=c.traversable_grid(raw_grid,resolution,c.RALLY_CLEARANCE_M);tc=c.world_to_grid(*target,resolution,*origin)
 seen={c.world_to_grid(p.x,p.y,resolution,*origin) for p in result};valid=set()
 def point(angle):
  return c.world_to_grid(target[0]+2.6*math.cos(angle),target[1]+2.6*math.sin(angle),resolution,*origin)
 def eligible(cell):
  r,k=cell
  return 0<=r<raw_grid.shape[0] and 0<=k<raw_grid.shape[1] and safe[cell] and c.has_known_line_of_sight(raw_grid,cell,tc)
 for i in range(24):
  if eligible(point(2*math.pi*i/24)):valid.add(i)
 for i in sorted(valid):
  for direction in (-1,1):
   if (i+direction)%24 in valid:continue
   for fraction in (1/3,2/3):
    cell=point(2*math.pi*(i+direction*fraction)/24)
    if cell in seen or not eligible(cell):continue
    seen.add(cell);x,y=c.grid_to_world(*cell,resolution,*origin)
    result.append(c.RallyPose(x,y,math.atan2(target[1]-y,target[0]-x)))
 return result
source=inspect.getsource(base);uniform=source.replace('range(24)','range(72)').replace('index / 24','index / 72')
scope=dict(vars(c));exec(compile(uniform,'<uniform216 prototype>','exec'),scope)
def full(raw_grid,resolution,origin,target,dense=False,stratified=False):return base(raw_grid,resolution,origin,target,dense,True)
def args():
 g=decode(event['planning_map']);return dict(raw_grid=g['data'],resolution=g['resolution'],origin=g['origin'],
  robot_positions=event['robot_positions'],target=event['target'],objective=event['objective'],
  battery_states=event['battery_states'],observer_robot=event['observer_robot'],current_positions=event['current_positions'],
  hold_sec=event['hold_sec'],return_maps={n:decode(v) for n,v in event['return_maps'].items()})
def exposures(answer,a):
 rows={}
 for name,pose in answer.items():
  st=a['battery_states'][name];lm=a['return_maps'].get(name);cache={}
  routes=c.qualified_return_candidates(a['raw_grid'],a['resolution'],a['origin'],(pose.x,pose.y),(st['charge_x'],st['charge_y']),st['charge_radius_m'],lm,cache)
  route=min((r for r in routes if r['qualified']),key=lambda r:(r['path_distance_m'],r['source']!='local'))
  geom=lm if route['source']=='local' else dict(data=a['raw_grid'] if route['source']=='delivered_fused' else cache['constrained_map']['grid'],resolution=a['resolution'],origin=a['origin'])
  known=geom['data']==0;clearance=np.full(known.shape,np.inf) if np.all(known) else distance_transform_edt(known,sampling=geom['resolution'])
  rows[name]=dict(full_return_m=route['path_distance_m'],exposure_m=c.return_route_clearance_exposure(route['route'],geom['resolution'],geom['origin'],clearance))
 return rows
rows={}
try:
 for label,fn in [('original72',base),('adaptive_boundary',adaptive),('uniform216',scope['rally_pose_candidates']),('full_boundary',full)]:
  c.rally_pose_candidates=fn;samples=[]
  for _ in range(3):
   a=args();start=time.perf_counter();answer=c.assign_rally_poses(**a);samples.append(time.perf_counter()-start)
  assert set(answer)==set(a['robot_positions'])
  if label=='original72':
   assert all(np.allclose(dataclasses.astuple(p),event['assignment'][n],rtol=0,atol=1e-8) for n,p in answer.items())
  rows[label]=dict(cold_wall_sec=samples,candidate_count=len(fn(a['raw_grid'],a['resolution'],a['origin'],a['target'])),
    assignment={n:dataclasses.asdict(p) for n,p in answer.items()},return_routes=exposures(answer,a))
  print(label,rows[label],flush=True)
finally:c.rally_pose_candidates=base
out=dict(status='PASS',scope='Exact saved AP assignment inputs, fixed source/conditional geometry only; no original clock/trajectory replay or causal mission guarantee',
 original_task_commit='56de2b91ca9f20c6608983a5c09a05a938a10d36',input_sha256=hashlib.sha256(fixture.read_bytes()).hexdigest(),event_time=event['event_time'],
 control_sha256=hashlib.sha256(Path(c.__file__).read_bytes()).hexdigest(),comparisons=rows)
Path('log/p2c_v39_outer_sampling_prototypes.json').write_text(json.dumps(out,indent=2)+'\n')

