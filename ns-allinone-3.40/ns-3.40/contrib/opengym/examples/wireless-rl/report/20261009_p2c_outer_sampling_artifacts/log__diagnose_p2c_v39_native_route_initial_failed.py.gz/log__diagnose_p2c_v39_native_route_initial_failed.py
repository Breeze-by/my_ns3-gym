import json,base64,zlib,numpy as np
from pathlib import Path
from multi_robot_exploration import control as c
e=json.loads(Path('log/p2c_v38_native_no_route_snapshot.json').read_text());out={}
for m in [e['map_evidence'],*[r.get('map_evidence',{}) for r in e['map_evidence'].get('route_candidates',[])]]:
 if not m.get('grid'):continue
 g=np.frombuffer(zlib.decompress(base64.b64decode(m['grid'])),dtype='<i2').reshape(m['shape'])
 p=c.world_to_grid(*e['position'],m['resolution'],*m['origin'])
 field=c.charging_route_field(g,m['resolution'],m['origin'],e['home'],e['charge_radius_m'],{})
 distance,route=c.known_return_route(g,m['resolution'],m['origin'],e['position'],e['home'],e['charge_radius_m'],{},True)
 out[m['source']]=dict(initial_cell=p,initial_value=int(g[p]),initial_safe=None if field is None else bool(field[0][p]),
  full_distance_m=distance,source_time=m['source_time'],clearance_m=float(c.obstacle_clearance_grid(g,m['resolution'])[p]),
  shape=m['shape'],origin=m['origin'])
print('candidate keys',[list(x) for x in e['map_evidence'].get('route_candidates',[])])
print(json.dumps(out));Path('log/p2c_v39_native_no_route_diagnosis.json').write_text(json.dumps(out,indent=2)+'\n')

