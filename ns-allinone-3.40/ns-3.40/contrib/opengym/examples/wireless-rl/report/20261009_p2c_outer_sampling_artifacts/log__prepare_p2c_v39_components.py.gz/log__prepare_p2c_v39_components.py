import ast,gzip,hashlib,json,re,subprocess
from pathlib import Path
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap';w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report';parent='56de2b91ca9f20c6608983a5c09a05a938a10d36'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def old(p):return subprocess.check_output(['git','show',parent+':'+str(p.relative_to(root))],cwd=root)
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py';native=r/'src/multi_robot_exploration/multi_robot_exploration/battery_manager.py'
assert old(native)==native.read_bytes()
runtime=load(r/'log/p2c_v39_rally_runtime.json');prototypes=load(r/'log/p2c_v39_outer_sampling_prototypes.json');source=load(r/'log/p2c_v39_source.json')
assert runtime['status']==prototypes['status']==source['status']=='PASS'
assert runtime['current_source_sha256']==sha(control)
full=re.search(r'(\d+) passed in ([\d.]+)s',(r/'log/p2c_v39_full_tests.log').read_text());assert full and int(full[1])==1428
recheck=re.search(r'(\d+) passed in ([\d.]+)s',(r/'log/p2c_v39_fixture_scope_recheck.log').read_text());assert recheck
build=re.search(r'4 packages finished \[([\d.]+)s\]',(r/'log/p2c_v39_build.log').read_text());assert build
for evidence,name in [('p2c_v39_manifest.log','p2c_integration_manifest.json'),('p2c_v39_blackout_manifest.log','p2c_blackout_manifest.json')]:
 current=load(r/'scripts'/name);assert load(r/'log'/evidence)['config']==current
 prior=json.loads(old(r/'scripts'/name))
 for key in ('cases','duration_sec','coverage_threshold','fault_seed','owner_shutdown_timeout_sec'):assert prior[key]==current[key]
unchanged={}
for rel in ('src/multi_robot_exploration/multi_robot_exploration/battery_manager.py','src/multi_robot_exploration/multi_robot_exploration/action_callbacks.py','src/multi_robot_exploration/multi_robot_exploration/tf_ingress_sampler.py','src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py','scripts/check_p2c_gate.py','scripts/observer_lifetime.py','scripts/observe_p3b5.py','scripts/p2c_native_graph.py','scripts/ros_smoke_test.py'):
 p=r/rel;assert old(p)==p.read_bytes();unchanged[rel]=sha(p)
files=[p for p in (r/'log').glob('*p2c_v39*') if p.is_file() and p.suffix!='.pyc' and p.name!='p2c_v39_prepare_components.log']
files += [r/'log/p2c_v38_native_no_route_snapshot.json',r/'log/p2c_v38_rally_assignment_input.json']
dest=report/'20261009_p2c_outer_sampling_artifacts';assert not dest.exists();dest.mkdir();artifacts=[]
for p in sorted(set(files)):
 q=dest/('__'.join(p.relative_to(r).parts)+'.gz');q.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0));assert gzip.decompress(q.read_bytes())==p.read_bytes()
 artifacts.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(q.relative_to(report)),archive_sha256=sha(q)))
out=dict(status='PASS',scope='Prospective bounded outer-ring sampling; original mission acceptance pending',parent_commit=parent,control_sha256=sha(control),native_sha256=sha(native),functional_checks=int(full[1]),functional_wall_sec=float(full[2]),fixture_scope_recheck_checks=int(recheck[1]),build_wall_sec=float(build[1]),source_audit=source,prototype_comparisons=prototypes,actual_dds_rally_witness=runtime,unchanged_from_parent=unchanged,initial_readonly_failures_retained=['diagnosis nonexistent clearance API','full_boundary prototype duplicate stratified argument'],limits=runtime['limits'],unrun=['new4 development','new17 formal','new2 physical','917'],artifacts=artifacts)
(report/'20261009_p2c_outer_sampling_components.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
text=f'''# P2C.1 v39 外圈可见边界自适应采样组件 PASS

v38冻结56de2b首forced原任务262.8s PARTIAL_COMPLETE、success=false、一个正电量tb1 FAILED；两机各charge1/min8.90048、0contacts/exhaustion/task-time infra/retry。全部原失败见20261009_p2c_v38_failed_development.md/.json。12原独立审计PASS不能抵消失败；其余3dev/17formal/2physical/917未调用。

保留原72候选及顺序，仅第一层集合提案对2.6m外圈24角度的可见/不可见邻接边界增加5/10度点。最多24有向交界×2=48新增，第一层上限120；全可见外圈不新增。每个新点仍需原0.45m端点净空与已知地图视线，原0.8m分离、完整qualified已知返航、当前地图占用veto、全往返能量/串行充电/observer与soft exposure目标保持。若该层没有完整可行分配，原最多464角边界层仍执行；dense返路修复与候选函数默认采样保持。停止在首个可行层仍牺牲跨层全局软目标最优性，不保证区域可行性穷尽或未来地图鲁棒。

四方法同一原AP输入对照：original72实际11有效点、adaptive13、uniform216为33、全边界55。原分配tb1在门洞内(-4.267,3.023)；adaptive把两机选到门洞外(-3.567,1.423)/(-4.667,1.473)，soft窄返路暴露合计1.614727613→0.666123834m。原三cold约.488–.504s、adaptive.499–.505、uniform.587–.598、全边界.711–.721。没有把样本wall时间当实时上界或单因素任务收益。代码修改后的另5cold中位原.4924/新.4824s，独立DDS接收的两份真实coordinator witness均按各自源码完整重建PASS，原source epochs保持。

之后2339.282s的原native地图仅用于离线压力检查：原tb1分配在该图无合格返路，adaptive两个假设位置在同图均有完整已知净空接触路径(3.708/5.049m)。它不是原机器人已经处在这些位置，不是轨迹反事实回放，也未作为未来地图输入进入选点。原门洞断开当前自由/安全单元仍无法返航；原始自由图连通但0.35m净空图断开。未配准静态SDF比较不能归因于同伴，未增加SLAM回波过滤或Gazebo真值感知输入。

新增15 meaningful checks覆盖可见窄弧补采、原前缀、全可见不增、原dense/stratified不变、12有占用/未知的随机图中净空/视线/唯一性/朝向/≤48界和图外目标。325定向PASS19.21s；全{int(full[1])}PASS{float(full[2]):.2f}s，测试替身只为新的可选keyword扩展，额外恢复无关lambda后test_control独立{int(recheck[1])}PASS。四包build{float(build[1]):.2f}s、171保护/4已有授权变化/54static、8中央+2native Future注册PASS。仅3纯集合函数AST变化，coordinator class/native/clock/TF/action桥与原Nav2/SLAM/物理字节保持；原300s/.35/.05/.1/5s和2/5/60s TTL未变。

初只读诊断调用不存在API及全边界prototype重复stratified参数的tracebacks保留，修正后全部比较成功；均不是任务调用/重试。所有输入/运行脚本/检查/manifest/失败与gzip SHA见JSON。新clean pushed freeze后先forced2原生COMPLETE及每机charge≥1，再另3开发；all4通过才同freeze17正式+2物理，917最后首次暴露。P2C.1尚未完成；P3C.5已验收，无P4/ns-3/Wi-Fi/RL。
'''
(report/'20261009_p2c_outer_sampling_components.md').write_text(text)
note=f'2026-10-09 P2C.1 v39外圈可见边界采样组件PASS待新原任务：v38 56de2b首forced PARTIAL262.8s/success=false/正电量tb1 FAILED，双机各charge1/min8.90048；零contact/exhaustion/task-time infra/retry、12审计PASS不能替代门禁。第一层保留原72并仅可见外圈交界加5/10度，最多48额外，120→原464后备；原净空/视线/分离/完整known返路/预算与soft目标保持。四方法原输入11→13候选、软返路暴露1.615→.666，实际DDS两算法独立重建PASS；离线CPU/后时刻地图压力不作因果或未来保证。{int(full[1])}功能/四包{float(build[1]):.2f}s/171保护54协议PASS，3纯函数改动、所有class/native/时钟/TF/Nav2/SLAM字节保持。新4→17+2同clean pushed freeze待验证，917未暴露；P3C.5已验收，无P4/ns3/Wi-Fi/RL。报告20261009_p2c_outer_sampling_components.md及20261009_p2c_v38_failed_development.md；旧pending为历史。'
for p in (w/'AGENTS.md',w/'RESEARCH_PLAN.md',w/'IMPLEMENTATION_PLAN.md',r/'user_guide.md',r/'launch_commands.md'):
 lines=p.read_text().splitlines();assert lines[2].startswith('2026-10-09 P2C.1 v38');lines[2]=note;p.write_text('\n'.join(lines)+'\n')
p=root/'AGENTS.md';s=p.read_text();start=s.index('2026-10-09 P2C.1 v38');end=s.index('\n',start);p.write_text(s[:start]+note+s[end:])
with (w/'log.md').open('a') as f:
 f.write('\n\n## 2026-10-09 P2C.1 v39 四采样比较与外圈边界候选组件\n\n'+note+'\n\n')
 f.write('Humble+install/PYTHONNOUSERSITE1/FastDDS UDPv4清profiles，taskset -c 0-79 /usr/bin/python3 log/prototype_p2c_v39_outer_sampling.py保存原AP输入；首full分支重复stratified只读参数错误保留并修正，3cold四方法比较PASS。ROS_DOMAIN_ID219 /usr/bin/python3 log/check_p2c_v39_rally_runtime.py实际两份coordinator producer/独立DDS consumer与源码版本完整rally_audit PASS，5cold实际选择/epochs/后时刻map压力仅条件检查。\n\n')
 f.write(f'pytest -q test_adaptive_rally_sampling.py/test_progressive_rally.py/test_rally_return_exposure.py/test_rally_observer_parking.py/test_control.py（路径src/multi_robot_exploration/test/）325PASS19.21s；完整 /usr/bin/python3 -m pytest -q src/multi_robot_exploration/test scripts --ignore=src/multi_robot_exploration/test/test_copyright.py --ignore=src/multi_robot_exploration/test/test_flake8.py --ignore=src/multi_robot_exploration/test/test_pep257.py {int(full[1])}PASS{float(full[2]):.2f}s；恢复无关测试替身扩展后test_control.py {int(recheck[1])}PASS{float(recheck[2]):.2f}s。colcon build --symlink-install --packages-select multi_robot_interfaces multi_robot_exploration merge_map multi_robot {float(build[1]):.2f}s；check_p2c_source.py --output log/p2c_v39_source.json PASS。\n\n')
 f.write('run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v39 --domain 210 --gazebo-port 20290 --validate-only 与 --manifest scripts/p2c_blackout_manifest.json --case physical_fault --run-id 20261009_p2c_v39_physical --domain 219 --gazebo-port 20299 --validate-only均PASS、没有新任务。原cases/300s/TTL/刺激/native安全/其他源码保持；新同freeze4→17+2待验证，917未调用；domain222/master11345未操作。\n')
print(json.dumps(dict(status='PASS',checks=int(full[1]),control_sha256=sha(control),artifacts=len(artifacts))))
