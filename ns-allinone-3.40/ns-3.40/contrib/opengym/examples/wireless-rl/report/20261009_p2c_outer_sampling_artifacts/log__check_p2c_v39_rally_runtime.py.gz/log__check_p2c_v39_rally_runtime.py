import ast,base64,dataclasses,hashlib,json,statistics,subprocess,sys,time,types,zlib
from pathlib import Path
import numpy as np
import rclpy
from rclpy.executors import SingleThreadedExecutor
from rclpy.node import Node
from std_msgs.msg import String
from multi_robot_exploration import control as c
import check_p2c_gate as gate
root=Path('/home/zhuyulab/ns3-workspace');parent='56de2b91ca9f20c6608983a5c09a05a938a10d36'
source_path=Path(c.__file__).resolve();before=subprocess.check_output(['git','show',parent+':'+str(source_path.relative_to(root))],cwd=root,text=True)
old=types.ModuleType('multi_robot_exploration.frozen56_control');old.__package__='multi_robot_exploration';sys.modules[old.__name__]=old
exec(compile(before,'<frozen56 control>','exec'),old.__dict__)
e=json.loads(Path('log/p2c_v38_rally_assignment_input.json').read_text());native=json.loads(Path('log/p2c_v38_native_no_route_snapshot.json').read_text())
def decode(m):return dict(data=np.frombuffer(zlib.decompress(base64.b64decode(m['grid'])),dtype='<i2').reshape(m['shape']),resolution=m['resolution'],origin=m['origin'])
def arguments():
 m=decode(e['planning_map']);return dict(raw_grid=m['data'],resolution=m['resolution'],origin=m['origin'],robot_positions=e['robot_positions'],target=e['target'],objective=e['objective'],battery_states=e['battery_states'],observer_robot=e['observer_robot'],current_positions=e['current_positions'],hold_sec=e['hold_sec'],return_maps={n:decode(m) for n,m in e['return_maps'].items()})
comparisons={};answers={}
for label,module in [('frozen56',old),('candidate39',c)]:
 samples=[]
 for _ in range(5):
  a=arguments();start=time.perf_counter();answer=module.assign_rally_poses(**a);samples.append(time.perf_counter()-start)
 answers[label]=answer
 if label=='frozen56':assert all(np.allclose(dataclasses.astuple(p),e['assignment'][n],atol=1e-8,rtol=0) for n,p in answer.items())
 late=decode(native['map_evidence']);late_routes={}
 for n,p in answer.items():
  st=e['battery_states'][n];distance,route=c.known_return_route(late['data'],late['resolution'],late['origin'],(p.x,p.y),(st['charge_x'],st['charge_y']),st['charge_radius_m'],{},True)
  late_routes[n]=distance
 comparisons[label]=dict(cold_wall_sec=samples,median_wall_sec=statistics.median(samples),assignment={n:dataclasses.asdict(p) for n,p in answer.items()},later_original_map_conditional_contact_m=late_routes)
print('comparisons',comparisons,flush=True)
assert comparisons['frozen56']['later_original_map_conditional_contact_m']['tb1'] is None
assert all(v is not None for v in comparisons['candidate39']['later_original_map_conditional_contact_m'].values())
def definitions(text):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(text).body if isinstance(n,(ast.ClassDef,ast.FunctionDef))}
a,b=definitions(before),definitions(source_path.read_text());changed=[n for n in a if a[n]!=b[n]]
assert changed==['rally_pose_candidates','assign_rally_poses','_assign_rally_poses'] and a.keys()==b.keys(),changed
output=Path('log/p2c_v39_rally_runtime.json');assert not output.exists()
rclpy.init(args=['--ros-args','-p','use_sim_time:=true','-p','robot_count:=2','-p','enable_battery:=true','-p','auto_save_map:=false'])
coordinator=receiver=None;executor=SingleThreadedExecutor();received=[];audits={}
try:
 coordinator=c.HeadquartersControl();receiver=Node('p2c39_rally_witness_receiver')
 for timer in coordinator.timers:timer.cancel()
 for node in (coordinator,receiver):executor.add_node(node)
 subscription=receiver.create_subscription(String,coordinator.consumed_publisher.topic_name,lambda message:received.append(json.loads(message.data)),10)
 deadline=time.monotonic()+10.
 while coordinator.consumed_publisher.get_subscription_count()!=1 and time.monotonic()<deadline:executor.spin_once(timeout_sec=.02)
 assert coordinator.consumed_publisher.get_subscription_count()==1
 a=arguments();coordinator.map_data=a['raw_grid'];coordinator.source_map_data=decode(e['source_map'])['data'];coordinator.resolution=a['resolution'];coordinator.origin=a['origin']
 coordinator.map_received_at=e['planning_map']['source_time'];coordinator.robot_positions=e['current_positions'];coordinator.target=e['target'];coordinator.battery_states=e['battery_states'];coordinator.target_observing_robot=e['observer_robot']
 coordinator.robot_map_received_at={n:m['source_time'] for n,m in e['return_maps'].items()};coordinator.robot_maps=a['return_maps'];coordinator.now=lambda:e['event_time'];coordinator.input_freshness_details=lambda:e['inputs']
 for i,(label,module) in enumerate([('frozen56',old),('candidate39',c)],1):
  coordinator.record_rally_assignment(a['robot_positions'],a['return_maps'],comparisons[label]['median_wall_sec'],answers[label],e['event_time'])
  deadline=time.monotonic()+5.
  while len(received)<i and time.monotonic()<deadline:executor.spin_once(timeout_sec=.02)
  assert len(received)==i
  gate.control=module;audits[label]=gate.rally_assignment_audit(received[-1:]);assert audits[label]['status']=='PASS'
  assert all(m['source_time']==e['inputs'][key]['source_time'] for key,m in received[-1]['inputs'].items())
 result=dict(status='PASS',scope='Actual coordinator DDS producer/independent receiver with exact historical delivered geometry and fixed epoch; pure proposal/recording test, no action or Gazebo motion',parent_commit=parent,parent_source_sha256=hashlib.sha256(before.encode()).hexdigest(),current_source_sha256=hashlib.sha256(source_path.read_bytes()).hexdigest(),input_sha256=hashlib.sha256(Path('log/p2c_v38_rally_assignment_input.json').read_bytes()).hexdigest(),late_native_map_sha256=hashlib.sha256(Path('log/p2c_v38_native_no_route_snapshot.json').read_bytes()).hexdigest(),changed_functions=changed,comparisons=comparisons,independent_audits=audits,received_witnesses=received,limits='Later original map is an offline stress check only, never a future-map input to candidate selection. Neither offline risk nor fixed-epoch CPU/DDS establishes causal task gain, future robustness or worst-case completion.')
 output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status='PASS',actual_dds_witnesses=len(received),changed_functions=changed)))
finally:
 gate.control=c;executor.shutdown()
 for node in (coordinator,receiver):
  if node is not None:node.destroy_node()
 rclpy.shutdown()
