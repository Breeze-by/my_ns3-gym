import json, sys, types
from pathlib import Path
from multi_robot_exploration import control
import test_exploration_resume as fixtures

path = Path('src/multi_robot_exploration/multi_robot_exploration/control.py')
source = path.read_text()
needle = "                assignment = (resolve_search_gain(assignment, self.map_data, self.resolution, search_gain_cache)"
insert = '''                key = (robot_name, assignment.x, assignment.y)
                if key not in route_proposals:
                    blocked = [p for peer, p in self.robot_positions.items()
                               if peer != robot_name and p is not None]
                    route_proposals[key] = plan_rally_leg(
                        RallyPose(assignment.x, assignment.y, 0.), self.map_data,
                        self.resolution, self.origin, self.robot_positions[robot_name],
                        MAX_NAVIGATION_LEG_M, blocked_positions=blocked,
                        clearance_m=PATH_CLEARANCE_M, visible_only=True,
                        route_cache=route_caches[robot_name])
                admitted = reserve_rally_prefix(route_proposals[key], reservations)
                if admitted is None:
                    diagnostics['rejected_routes'] += 1
                    return None
                if math.dist(self.robot_positions[robot_name], (admitted[0].x, admitted[0].y)) <= NAVIGATION_POSITION_TOLERANCE_M:
                    diagnostics['stationary_candidates'] += 1
                    return None
'''
assert source.count(needle) == 1
source = source.replace(needle, insert+needle)
needle = '            route_caches = {name: {} for name in idle_positions}\n'
assert source.count(needle) == 1
source = source.replace(needle, needle+'            route_proposals = {}\n')
start = source.index('                plan = plan_rally_leg(', source.index('    def assign_idle_robots(self):'))
end = source.index('                admitted = reserve_rally_prefix', start)
source = source[:start]+'''                plan = route_proposals[name, assignment.x, assignment.y]
'''+source[end:]
module = types.ModuleType('multi_robot_exploration.p2c_v36_prefix_first_prototype')
module.__package__ = 'multi_robot_exploration'; sys.modules[module.__name__] = module
exec(compile(source, '<route first prototype>', 'exec'), module.__dict__)
script = Path('log/profile_p2c_v35_expired.py').read_text()
script = script.replace('from multi_robot_exploration import control', '')
script = script.replace('p2c_v35_', 'p2c_v36_prefix_first_')
script = script.replace("path = Path(f'log/p2c_v36_prefix_first_{case}_expired_snapshot.json')",
                        "path = Path(f'log/p2c_v35_{case}_expired_snapshot.json')")
fixtures.control = module
exec(compile(script, '<conditional frozen expiry inputs>', 'exec'), {'control': module})
old = json.loads(Path('log/p2c_v35_expired_profiles.json').read_text())
new = json.loads(Path('log/p2c_v36_prefix_first_expired_profiles.json').read_text())
for case in old:
    assert old[case]['result']['sent'] == new[case]['result']['sent'], case
    assert old[case]['result']['choices'] == new[case]['result']['choices'], case
print('Exact selected goals/headings/preferences/required-energy match on all three expired snapshots')
