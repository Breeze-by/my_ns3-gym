import ast, hashlib, json, statistics, subprocess, time
from pathlib import Path
from multi_robot_exploration import control
from test_exploration_route_bound import REFERENCE, conditional_assignment, reference_functions

old = reference_functions()['assign_idle_robots']
output = {}
for case, event in REFERENCE['snapshots'].items():
    samples = {'frozen_v35': [], 'candidate_v36': []}; expected = None
    for repeat in range(5):
        sequence = [('frozen_v35', old), ('candidate_v36', control.HeadquartersControl.assign_idle_robots)]
        if repeat % 2: sequence.reverse()
        for label, assign in sequence:
            control.visibility_ray_projections.cache_clear(); control.known_search_sector_table.cache_clear()
            start = time.perf_counter(); result = conditional_assignment(event, assign)
            samples[label].append(time.perf_counter()-start)
            if expected is None: expected = result
            assert result == expected, (case, label, 'goal/heading/preference/full-energy changed')
    output[case] = dict(exact_conditional_selection_equal=True,
        input_sha256=hashlib.sha256(json.dumps(event, sort_keys=True).encode()).hexdigest(),
        original_lease_slack_sec=event['source_deadline_sec']-event['planning_started_at_sec'],
        selected_robot_names=[row[0] for row in expected['sent']],
        timing={k:dict(cold_wall_sec=v, median_wall_sec=statistics.median(v)) for k,v in samples.items()})
    print(case, {k:statistics.median(v) for k,v in samples.items()}, flush=True)
root = Path('/home/zhuyulab/ns3-workspace')
path = Path('src/multi_robot_exploration/multi_robot_exploration/control.py')
source = path.read_text()
parent = subprocess.check_output(['git','show','7d9709b:'+str(path.resolve().relative_to(root))], cwd=root, text=True)
def definitions(s):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b = definitions(parent), definitions(source)
changed = [n for n in a if a[n]!=b[n]]; added = [n for n in b if n not in a]
assert changed == ['plan_rally_leg','HeadquartersControl'] and added == ['exploration_prefix_can_move'], (changed, added)
classes = [next(n for n in ast.parse(s).body if isinstance(n,ast.ClassDef) and n.name=='HeadquartersControl') for s in (parent, source)]
methods = [{n.name:ast.dump(n,include_attributes=False) for n in cls.body if isinstance(n,ast.FunctionDef)} for cls in classes]
changed_methods = [n for n in methods[0] if methods[0][n]!=methods[1][n]]
assert list(methods[0])==list(methods[1]) and changed_methods==['assign_idle_robots'], changed_methods
result = dict(status='PASS', parent_commit=REFERENCE['commit'], control_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
    scope='Five paired interleaved cold computations on exact retained abandoned inputs; source epoch fixed; not real-time replay, mission effect or worst-case bound',
    changed_pure=changed[:-1], added=added, changed_methods=changed_methods, comparisons=output)
Path('log/p2c_v36_final_comparisons.json').write_text(json.dumps(result,indent=2)+'\n')
