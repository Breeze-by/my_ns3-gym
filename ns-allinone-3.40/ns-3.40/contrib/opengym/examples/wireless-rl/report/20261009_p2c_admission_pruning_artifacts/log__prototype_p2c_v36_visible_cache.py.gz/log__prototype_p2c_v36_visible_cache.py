from pathlib import Path

base = Path('log/prototype_p2c_v36_stationary_first.py').read_text()
needle = "module = types.ModuleType('multi_robot_exploration.p2c_v36_stationary_first_prototype')"
insert = '''old = """        for candidate in reversed(route):
            direct = tuple(_line_cells(start, candidate))
            if all(traversable[cell] for cell in direct):
                waypoint, route = candidate, direct
                break
"""
new = """        visibility = route_cache.setdefault('visibility', {})
        for candidate in reversed(route):
            direct = None
            if candidate not in visibility:
                if len(visibility) >= 2048:
                    visibility.clear()
                direct = tuple(_line_cells(start, candidate))
                visibility[candidate] = all(traversable[cell] for cell in direct)
            if visibility[candidate]:
                waypoint, route = candidate, (direct if direct is not None else tuple(_line_cells(start, candidate)))
                break
"""
assert source.count(old) == 1
source = source.replace(old, new)
'''
assert base.count(needle) == 1
base = base.replace(needle, insert+needle).replace('p2c_v36_stationary_first', 'p2c_v36_visible_cache')
exec(compile(base, '<stationary pruning and exact visibility cache>', 'exec'))
