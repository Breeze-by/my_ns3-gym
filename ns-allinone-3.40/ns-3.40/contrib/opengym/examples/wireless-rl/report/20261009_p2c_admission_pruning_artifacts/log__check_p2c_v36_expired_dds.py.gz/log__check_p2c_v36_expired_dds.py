import hashlib, json, math, time
from pathlib import Path
import rclpy
from rclpy.node import Node
from rclpy.executors import SingleThreadedExecutor
from std_msgs.msg import String
from geometry_msgs.msg import PoseStamped
from multi_robot_exploration import control
from test_exploration_route_bound import REFERENCE, conditional_assignment
from check_p2c_gate import exploration_travel_audit, planning_lease_audit

rclpy.init(args=['--ros-args','-p','robot_count:=3','-p','use_sim_time:=true',
    '-p','enable_battery:=true','-p','enable_rally:=true','-p','auto_save_map:=false'])
coordinator = receiver = None
executor = SingleThreadedExecutor(); received = []; results = {}
try:
    coordinator = control.HeadquartersControl(); receiver = Node('p2c_expired_input_witness_receiver')
    for timer in coordinator.timers: timer.cancel()
    executor.add_node(coordinator); executor.add_node(receiver)
    receiver.create_subscription(String, coordinator.consumed_publisher.topic_name,
        lambda message: received.append(json.loads(message.data)), 20)
    deadline = time.monotonic()+10.
    while coordinator.consumed_publisher.get_subscription_count()!=1 and time.monotonic()<deadline:
        executor.spin_once(timeout_sec=.02)
    assert coordinator.consumed_publisher.get_subscription_count()==1
    for case, event in REFERENCE['snapshots'].items():
        first = len(received); selected = []
        def admit(fixture):
            for key, value in vars(fixture).items():
                if key not in ('consumed_publisher','get_logger','send_goal'):
                    setattr(coordinator,key,value)
            coordinator.return_distance_caches={};coordinator.return_map_veto_at={}
            coordinator.exploration_travel_choices={};coordinator.frontier_geometry_cache=None
            def sink(name, assignment):
                assert type(assignment) is control.Assignment and type(assignment.viewpoint) is control.Viewpoint
                selected.append((name,assignment))
                pose=PoseStamped();pose.pose.position.x=assignment.navigation_x;pose.pose.position.y=assignment.navigation_y
                yaw=assignment.navigation_yaw or 0.;pose.pose.orientation.z=math.sin(yaw/2.);pose.pose.orientation.w=math.cos(yaw/2.)
                kind='initial_visual_search' if coordinator.initial_search_goals.get(name,False) else 'exploration'
                coordinator.record_navigation_decision(name,kind,pose)
            coordinator.send_goal=sink
            control.HeadquartersControl.assign_idle_robots(coordinator)
            fixture.exploration_travel_choices=coordinator.exploration_travel_choices
        conditional_assignment(event,admit)
        assert selected
        deadline=time.monotonic()+10.
        while sum(e.get('event')=='coordinator_navigation_decision' for e in received[first:])<len(selected) and time.monotonic()<deadline:
            executor.spin_once(timeout_sec=.02)
        rows=received[first:]
        assert sum(e.get('event')=='coordinator_navigation_decision' for e in rows)==len(selected)
        audit=exploration_travel_audit(rows,True,True,True,True,True,True,True)
        leases=planning_lease_audit(rows)
        results[case]=dict(status='PASS',actual_normal_assignments=len(selected),independent_audit=audit,
                           leases=leases,received_events=rows)
    source=Path(control.__file__)
    out=dict(status='PASS',control_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        scope='Actual isolated ROS central producer/DDS consumer on exact saved abandoned inputs; fixed original epoch and synthetic goal sink, no original trajectory, live-clock bound or Nav2 motion',cases=results)
    Path('log/p2c_v36_expired_dds.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({n:{k:v for k,v in e.items() if k!='received_events'} for n,e in results.items()}))
finally:
    executor.shutdown()
    for node in (coordinator,receiver):
        if node is not None:node.destroy_node()
    rclpy.shutdown()
