import json, sys, types
from pathlib import Path
from multi_robot_exploration import control
import test_exploration_resume as fixtures

source = Path(control.__file__).read_text()
needle = '''                if reservations:
                    key = (robot_name, assignment.x, assignment.y)
'''
replacement = '''                if reservations:
                    field = route_caches[robot_name].get('field')
                    if field is not None:
                        _, start, escape, _ = field
                        if start is None or any(routes_conflict(
                                (grid_to_world(*escape[0], self.resolution, *self.origin),), reserved)
                                for reserved in reservations):
                            diagnostics['rejected_routes'] += 1
                            return None
                    key = (robot_name, assignment.x, assignment.y)
'''
assert source.count(needle)==1; source=source.replace(needle,replacement)
module=types.ModuleType('multi_robot_exploration.p2c_v36_reserved_start_prototype')
module.__package__='multi_robot_exploration';sys.modules[module.__name__]=module
exec(compile(source,'<reserved initial route point pruning>','exec'),module.__dict__)
script=Path('log/profile_p2c_v35_expired.py').read_text().replace('from multi_robot_exploration import control','')
script=script.replace('p2c_v35_', 'p2c_v36_reserved_start_').replace(
    "path = Path(f'log/p2c_v36_reserved_start_{case}_expired_snapshot.json')",
    "path = Path(f'log/p2c_v35_{case}_expired_snapshot.json')")
fixtures.control=module
exec(compile(script,'<actual saved frozen inputs>', 'exec'),{'control':module})
old=json.loads(Path('log/p2c_v35_expired_profiles.json').read_text())
new=json.loads(Path('log/p2c_v36_reserved_start_expired_profiles.json').read_text())
for case in old:
    assert old[case]['result']['sent']==new[case]['result']['sent'],case
    assert old[case]['result']['choices']==new[case]['result']['choices'],case
print('Exact original goals/headings/preferences/full budget match all three inputs')
