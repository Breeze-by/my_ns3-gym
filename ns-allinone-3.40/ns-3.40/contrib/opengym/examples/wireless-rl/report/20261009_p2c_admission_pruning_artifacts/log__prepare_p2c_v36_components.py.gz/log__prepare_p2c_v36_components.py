import gzip, hashlib, json, re, subprocess
from pathlib import Path

root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
parent='7d9709b907f2f38f1252eee8ae4fb53c42f3cc13'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py'
comparison=load(r/'log/p2c_v36_final_comparisons.json')
assert comparison['status']=='PASS' and comparison['control_sha256']==sha(control)
source=load(r/'log/p2c_v36_source_final.json');assert source['status']=='PASS'
full=re.search(r'(\d+) passed in ([\d.]+)s',(r/'log/p2c_v36_full_tests.log').read_text())
assert full and int(full[1])==1376
build=re.search(r'4 packages finished \[([\d.]+)s\]',(r/'log/p2c_v36_build.log').read_text());assert build
runtime={k:load(r/'log'/n) for k,n in [
 ('clock','p2c_v36_clock_runtime_final.json'),('native_future','p2c_v36_native_future_runtime.json'),
 ('visual','p2c_v36_visual_runtime.json'),('mapping_dds','p2c_v36_lazy_gain_dds.json'),
 ('visual_gain_dds','p2c_v36_lazy_visual_dds.json'),('rally_dds','p2c_v36_rally_dds.json'),
 ('expired_inputs_dds','p2c_v36_expired_dds.json')]}
assert all(v['status']=='PASS' for v in runtime.values())
for k,v in runtime.items():
 if k!='native_future':assert v['control_sha256']==sha(control),(k,'source binding')
original=load(r/'log/p2c_v35_independent_audits.json')
reaudit=load(r/'log/p2c_v36_previous_original_audits.json')
assert original==reaudit and all(len(rows)==12 and all(v['status']=='PASS' for v in rows.values()) for rows in reaudit.values())
for saved,name in [('p2c_v36_manifest.json','p2c_integration_manifest.json'),('p2c_v36_blackout_manifest.json','p2c_blackout_manifest.json')]:
 current=load(r/'scripts'/name);assert load(r/'log'/saved)['config']==current
 old=json.loads(subprocess.check_output(['git','show',parent+':'+str((r/'scripts'/name).relative_to(root))],cwd=root))
 for key in ('cases','duration_sec','coverage_threshold','fault_seed','owner_shutdown_timeout_sec'):assert old[key]==current[key],key
unchanged={}
for rel in ('src/multi_robot_exploration/multi_robot_exploration/battery_manager.py','src/multi_robot_exploration/multi_robot_exploration/action_callbacks.py','src/multi_robot_exploration/multi_robot_exploration/tf_ingress_sampler.py','src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py','scripts/observer_lifetime.py','scripts/observe_p3b5.py','scripts/p2c_native_graph.py','scripts/check_p2c_gate.py','scripts/ros_smoke_test.py','scripts/check_p2c_visual_runtime.py'):
 p=r/rel;assert subprocess.check_output(['git','show',parent+':'+str(p.relative_to(root))],cwd=root)==p.read_bytes();unchanged[rel]=sha(p)
files=[p for p in (r/'log').glob('*p2c_v36*') if p.is_file() and p.suffix!='.pyc']
files += [r/'src/multi_robot_exploration/test/fixtures/p2c_v35_route_pricing_reference.json']
destination=report/'20261009_p2c_admission_pruning_artifacts';assert not destination.exists();destination.mkdir();artifacts=[]
for p in sorted(set(files)):
 q=destination/('__'.join(p.relative_to(r).parts)+'.gz');q.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0))
 assert gzip.decompress(q.read_bytes())==p.read_bytes()
 artifacts.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(q.relative_to(report)),archive_sha256=sha(q)))
errors=[
 'Initial targeted command named a nonexistent clock test twice: argument/file errors, no tests or tasks started; exact existing test_live_planning_clock then used.',
 'Initial two new fixtures incorrectly assumed a0.1m position tolerance and insufficient separation; corrected fixtures use original0.02m tolerance and1.8m route-separation threshold. No production constants changed.',
 'First full1372PASS/3FAIL included those initial fixtures plus real redundant low-energy planning regression40calls. Precheck narrowed to actual/provisional reservations; original20candidate≤2planning test unchanged and passes.',
 'Intermediate full1375PASS and six ROS checks retained separately; further exact common-start pruning then final1376PASS/seven actual ROS checks performed, each source-bound.',
 'Existing immutable clock/source evidence overwrite correctly rejected; final filenames used and all initial records retained.',
 'Physical validate-only initially used unsupported --config instead of --manifest; parser exit2 before any task; corrected original stimulus passes.'
]
out=dict(status='PASS',scope='Prospective P2C.1 exact admission pruning components; no new mission acceptance',
 parent_commit=parent,control_sha256=sha(control),functional_checks=int(full[1]),functional_wall_sec=float(full[2]),
 build_wall_sec=float(build[1]),source_audit=source,actual_ros=runtime,fixed_source_comparison=comparison,
 previous_original_reaudit=reaudit,unchanged_from_parent=unchanged,preparation_errors=errors,
 unrun=['new4 development','new17 formal','new2 physical','917'],
 limits='Fixed exact abandoned callback inputs and epochs; paired CPU and isolated DDS are not original full-history/live-clock replay, worst-case latency, causal mission gain or Wi-Fi evidence.',artifacts=artifacts)
(report/'20261009_p2c_admission_pruning_components.json').write_text(json.dumps(out,indent=2)+'\n')
text='''# P2C.1 v36 精确准入剪枝组件 PASS

v35冻结7d9709b四个原开发任务整体FAIL：forced200.7s原生COMPLETE、各机器人charge1；lab/rooms EXPLORE timeout300.4/300.3，corridors FOUND timeout300.1、296.2s才检测。四格0接触/耗尽/failed/infra/retry，48独立子门PASS不能替代完整开发成功。原owner/observer自然关闭后才修改，完整原件与严格失败见20261009_p2c_v35_failed_development.md/.json。正式17/物理2/917未调用；旧成功不回填新冻结。

此次用三份精确原ledger弃置行重建完整callback输入，覆盖三机器人混合mapping/visual状态、原地图与本地return grids、source stamps、访问/朝向历史、resume/charge/goals/routes。原固定epoch计算约2.4/3.5/2.4秒，超过原剩余source lease约1.34/1.59/1.41秒；每轮多数昂贵预算最后才因accepted reservation而失败。

新算法保持原稳定贪心顺序和所有硬准入：有实际或临时预留路线时，先生成同body-masked field的原短腿；只在所有当前及未来可能有效前缀都不可用时，才跳过准确gain和完整价格。新增预留只能使第一次冲突向前移动：任一冲突之前仍可能满足原0.75m前缀位移且超过原0.02m位置容差的点都会被保留，故不会因当前终点近乎原地而丢失后续有效前缀。最终仍执行原真实reservation、动态机体、完整body路长/qualified contact return、能量和来源复核。没有预留时沿用原价格流程，保留低电量20候选≤2次完整规划的充电公平性回归。

同field的每条路线均从原escape[0]开始；该点一旦与已有预留冲突，任何候选都无法保留非空前缀，可共用这个不可行证据。不会从真实机器人坐标替代原栅格逃离点。视线布尔结果只在同immutable field内缓存，最多2048条，不保存/简化路径、不续租或保存能量可行决策。原visible-only逐格Bresenham、局部占用veto、全部返回顶点与朝向相同。

测试冻结7d原assign_idle_robots和plan_rally_leg源码与SHA，不以新实现生成期待结果。三份原弃置输入的派发、yaw、相对/多样性偏好、完整储备预算逐项相同；12种随机种子×40条曲线检查false上界在增加任一新预留后仍不会隐藏有效前缀；回环终点反例保留中间有效前缀；8图×24目标逐点路径/朝向与原函数相同，覆盖body与escape。精确布尔memo有界，原充电/真实时钟弃置测试保持。所有私有bound都不进入Nav2、charging forecast或native safety。

| 原弃置输入 | v35中位wall秒 | v36中位wall秒 | 原source剩余秒 |
|---|---|---|---|
'''
for case,row in comparison['comparisons'].items():
 text+=f"| {case} | {row['timing']['frozen_v35']['median_wall_sec']:.5f} | {row['timing']['candidate_v36']['median_wall_sec']:.5f} | {row['original_lease_slack_sec']:.5f} |\n"
text+='\n五轮交错cold/每轮新map和geometry cache，原来源epoch不前进，条件goal sink；不是原history回放或现场callback/最坏时限。初预检查仅None/终点半径检查没有明显普遍改善；任意有效前缀上界及公共起点判断才减少冗余预算。完整保留各原型、首失败检查和中间已通过版本，不只报最快样本。\n\n'
text+=f"最终{int(full[1])}功能PASS/{float(full[2]):.2f}s，四包build{float(build[1]):.2f}s，171protected/4既授权/54static与8中央+2native Future注册PASS；七项实际ROS含原clock/Future/视场、普通mapping/visual与两组progressive rally producer-consumer，以及三份原弃置输入的实际中央publisher/独立DDS reader，共三个准确任务witness。源SHA全部绑定；固定原时刻和合成goal sink，无Gazebo/Nav2运动或真实时限保证。v35原48审计细节完全保持，完整strict仍FAIL。\n\n"
text+='原native battery/action dispatcher/TF/launch/observer/strict reader byte保持；仅control纯plan_rally_leg和assign_idle_robots改变，增加必要前缀上界助手。原300s/5s真实保持、2/5/60s来源TTL、原生储备/能量/SLAM/Nav2/physics/case/真实断网刺激均未改。下一clean pushed freeze先forced原生且每机charge≥1，再其他开发；四格通过才17正式+2物理，917最后首次暴露。P2C.1仍未完成；P3C.5已验收，无P4/ns-3/Wi-Fi/RL。\n'
(report/'20261009_p2c_admission_pruning_components.md').write_text(text)
note=f'2026-10-09 P2C.1 v36精确准入剪枝组件PASS待新原任务：v35 7d9709b四原dev整体FAIL(仅forced200.7 COMPLETE/每机charge1，lab/rooms EXPLOREtimeout300.4/300.3，corr FOUNDtimeout300.1)，0安全/infra/retry、48子门PASS且owned关闭；原件保留。三份真实弃置输入采用必要有效前缀/公共escape起点剪枝和2048布尔视线cache，原稳定派发/yaw/完整能量保持；充电20候选≤2规划原回归保持。{int(full[1])}功能/四包{float(build[1]):.2f}s/171保护54协议/七实际ROS PASS；五交错cold约2.38→.76、3.29→.65、2.23→.60wall秒，条件组件非真实时限/任务因果。新4→17+2同clean pushed freeze待验证，917未暴露；P3C.5已验收，无P4/ns3/Wi-Fi/RL。报告20261009_p2c_admission_pruning_components.md与20261009_p2c_v35_failed_development.md；旧pending说明为历史。'
for p in (w/'AGENTS.md',w/'RESEARCH_PLAN.md',w/'IMPLEMENTATION_PLAN.md',r/'user_guide.md',r/'launch_commands.md'):
 lines=p.read_text().splitlines();assert lines[2].startswith('2026-10-09 P2C.1 v35');lines[2]=note;p.write_text('\n'.join(lines)+'\n')
p=root/'AGENTS.md';s=p.read_text();start=s.index('2026-10-09 P2C.1 v35');end=s.index('\n',start);p.write_text(s[:start]+note+s[end:])
with (w/'log.md').open('a') as f:
 f.write('\n\n## 2026-10-09 P2C.1 v36 精确准入剪枝组件\n\n'+note+'\n\n')
 f.write('Humble+install/PYTHONNOUSERSITE=1/FastDDS UDPv4清旧profiles，所有Python与colcon用taskset -c0-79；profile_p2c_v35_expired.py固定epoch实测→prototype_p2c_v36_route_first/prefix_first/stationary_first/visible_cache/admission_bound/reserved_start.py，各脚本/结果/失败保留。完整三输入cold5对照compare_p2c_v36_components.py（交错顺序）exit0、原目标/yaw/偏好/full energy同；源AST仅plan_rally_leg与assign_idle_robots、增加exploration_prefix_can_move。首仅None/check每点半径改善不足；任意前缀上界减少冗余价，进一步公共起点将31/9/18规划调用替代原270/561/243。上述条件计算不是端到端因果。\n\n')
 f.write('首定向两个不存在clock文件命令exit4、无tests/tasks；原fixture错用0.1m tolerance与不足1.8m separation，纠正为实际0.02m及更远loop，无生产门限改变。首target25PASS2FAIL；首full1372PASS3FAIL/80.13s含两个旧fixture和真实40规划calls回归；收窄到有reservation时预检查，原20候选≤2规划test没改，67PASS13.23s与full1375PASS78.69s。增加公共原escape起点剪枝后68定向PASS13.23s，最终full pytest src/multi_robot_exploration/test scripts --ignore copyright/flake8/pep257 '+str(int(full[1]))+'PASS/'+str(float(full[2]))+'s；四包colcon '+str(float(build[1]))+'s；check_p2c_source.py --output log/p2c_v36_source_final.json PASS171/4/54。两个immutable output overwrite拒绝保留，改final文件；physical --config错误exit2仅解析，纠正--manifest validate-only PASS。\n\n')
 f.write('实际ROS domains220 clock_runtime_final、221 native_future、215 visual_runtime、214 log/check_p2c_v36_lazy_gain_dds.py、216 lazy_visual_dds、217 rally_dds、218 expired_dds全部PASS及source绑定；前三使用scripts/check_p2c_*_runtime.py --output对应log/p2c_v36_*.json，后三fixture新实际publisher/consumer无Nav2/Gazebo/真实时界。audit_p2c_v36_previous_originals.py四原48详细判断相同，旧整组FAIL保持。run_p2c_tasks --case dev_forced2 --run-id20261009_p2c_v36 --domain210 --gazebo-port20290 --validate-only，与--manifest scripts/p2c_blackout_manifest.json --case physical_fault --run-id20261009_p2c_v36_physical --domain219 --gazebo-port20299 --validate-only均PASS；没有启动任务。全部原生/TTL/源包/case/物理刺激未改，P2C未完成；新4/17/2/917待本commit/push和cleanfreeze，domain222/master11345未操作。\n')
print(json.dumps(dict(status='PASS',artifacts=len(artifacts),checks=int(full[1]),control_sha256=sha(control))))
