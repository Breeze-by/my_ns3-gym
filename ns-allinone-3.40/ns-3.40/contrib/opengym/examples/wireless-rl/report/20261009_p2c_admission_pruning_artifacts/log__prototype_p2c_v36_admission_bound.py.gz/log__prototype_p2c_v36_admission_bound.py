from pathlib import Path

base = Path('log/prototype_p2c_v36_route_first.py').read_text()
base = base.replace("                if route_proposals[key][0] is None:\n                    diagnostics['rejected_routes'] += 1\n                    return None\n", "                if not exploration_prefix_can_move(route_proposals[key], self.robot_positions[robot_name], reservations):\n                    diagnostics['rejected_routes'] += 1\n                    return None\n")
needle = "module = types.ModuleType('multi_robot_exploration.p2c_v36_route_first_prototype')"
insert = '''helper = """
def exploration_prefix_can_move(plan, position, reservations):
    pose, route = plan
    if pose is None or not route:
        return False
    for index, point in enumerate(route):
        if any(routes_conflict((point,), reserved) for reserved in reservations):
            return False
        if (index and math.dist(route[0], point) >= .75
                and math.dist(position, point) > NAVIGATION_POSITION_TOLERANCE_M):
            return True
    return math.dist(position, (pose.x, pose.y)) > NAVIGATION_POSITION_TOLERANCE_M
"""
source += helper
old = """        for candidate in reversed(route):
            direct = tuple(_line_cells(start, candidate))
            if all(traversable[cell] for cell in direct):
                waypoint, route = candidate, direct
                break
"""
new = """        visibility = route_cache.setdefault('visibility', {})
        for candidate in reversed(route):
            direct = None
            if candidate not in visibility:
                if len(visibility) >= 2048:
                    visibility.clear()
                direct = tuple(_line_cells(start, candidate))
                visibility[candidate] = all(traversable[cell] for cell in direct)
            if visibility[candidate]:
                waypoint, route = candidate, (direct if direct is not None else tuple(_line_cells(start, candidate)))
                break
"""
assert source.count(old) == 1
source = source.replace(old, new)
'''
assert base.count(needle) == 1
base = base.replace(needle, insert+needle).replace('p2c_v36_route_first', 'p2c_v36_admission_bound')
exec(compile(base, '<exact useful prefix upper bound>', 'exec'))
