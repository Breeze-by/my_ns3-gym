import gzip,hashlib,json,os,subprocess
from pathlib import Path
from datetime import datetime,timezone
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
base=r/'log/p2c/20261009_p2c_v30';paths=list(base.glob('*/summary.json'));assert len(paths)==1
summary=json.loads(paths[0].read_text());assert summary['git_commit']=='c12db66cf666779978dd74b315a9e92b080f4a11'
assert summary['runner_returncode']==summary['observer_returncode']==0
closure={}
for key in ('owner_pid','observer_pid'):
    try:os.kill(summary[key],0)
    except ProcessLookupError:closure[key]=dict(pid=summary[key],closed=True)
    else:raise AssertionError(('owned process still live',key,summary[key]))
closure['checked_at_utc']=datetime.now(timezone.utc).isoformat()
closure['task_processes_before_edit']=subprocess.check_output(['ps','-eo','pid,ppid,args'],text=True)
(r/'log/p2c_v30_closed_before_edit.json').write_text(json.dumps(closure,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name,digest in summary['evidence_sha256'].items():assert sha(paths[0].parent/name)==digest
gate=json.loads((r/'log/p2c_v30_dev_forced2_gate.json').read_text());assert gate['status']=='FAIL'
audits=json.loads((r/'log/p2c_v30_independent_audits.json').read_text())
assert all(v['status']=='PASS' for v in audits['dev_forced2'].values())
files=[p for p in base.rglob('*') if p.is_file() and p.suffix!='.pyc']
files += [p for p in (r/'log').glob('*p2c_v30*') if p.is_file() and p.suffix!='.pyc' and 'eof' not in p.name]
destination=report/'20261009_p2c_v30_artifacts';destination.mkdir();artifacts=[]
for p in sorted(set(files)):
    q=destination/('__'.join(p.relative_to(r).parts)+'.gz')
    q.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0));assert gzip.decompress(q.read_bytes())==p.read_bytes()
    artifacts.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(q.relative_to(report)),archive_sha256=sha(q)))
output=dict(status='FAIL',scope='First clean frozen development original; remaining cells never invoked',
    task_stack_frozen_commit=summary['git_commit'],original=summary,strict_gate=gate,independent_audits=audits,
    all_owned_closed_before_edits=closure,task_retries=0,unrun=['other3 development','17 formal','both physical','917'],
    geometry_profile=json.loads((r/'log/p2c_v30_geometry_profile.json').read_text()),
    assignment_profile=json.loads((r/'log/p2c_v30_assignment_profile.json').read_text()),
    interpretation='130 abandoned plans bind unchanged original sources. Stage candidate_budget means between candidate budgets, not necessarily generation. Held early delivered snapshot CPU profile is not task replay or a worst-case bound. No radio-capacity inference.',
    artifacts=artifacts)
(report/'20261009_p2c_v30_failed_development.json').write_text(json.dumps(output,indent=2)+'\n')
(report/'20261009_p2c_v30_failed_development.md').write_text('''# P2C.1 v30 首原开发 FAIL

冻结 c12db66cf666779978dd74b315a9e92b080f4a11，2026-10-09T04:38:50.476495..04:45:31.658417UTC。强制二机原任务300.2秒EXPLORE timeout，只有tb1的一次探索导航成功，未发现目标/无charge；总路径0.77429m，最低能量11.2649506，零接触/耗尽/failed机器人，owner592550/observer592567退出0，严格首格FAIL。其余3开发、17正式、2物理与917从未调用，无重试/回填。全部原始源/参数/命令/环境/结果/账本/地图/metrics/实际native图/关闭证据和SHA压缩保留。

十二项独立检查PASS，包括原生返航/能量、完整预算和探索证据、规划租约、图与任务期进程；实际只有1探索证据、2已闭合无局部导航的返航触发、121能量快照，零真实charger returns，不将稀少路径上的审核通过改作安全充分验证或任务成功。130次弃置过期规划中128次在candidate_budget、2次在candidate_generation；全部deadline由原始交付source+原TTL重建，未续租。candidate_budget是预算循环检查点，不能仅凭阶段名归因于候选生成。

任务关闭后对唯一实际导航记录内211×253/.05m原交付地图做只读CPU分析：前沿准备0.1512s、已知空间候选约0.1503s；完整条件调度0.648s，33预算/132返路查询中返路约0.392s，9次圆盘膨胀约0.265s。这是固定原始输入/固定计价瞬间的计算样本，没有原始完整历史回放或真实Nav2派发，不是任务反事实、最坏计算时限或通信容量结论。后续优化应维持逐格障碍几何、返航路线/预算、真实clock与原2秒位姿租约，避免把CPU等待隐含到旧clock。

Gazebo world原文件自带1996.381秒起始state，任务horizon仍相对evaluator start2075.382秒的300秒；未改变physics。P3C.5已验收，P2C.1未通过；无P4/ns-3/Wi-Fi/RL。
''')
with (w/'log.md').open('a') as f:
    f.write('\n\n## 2026-10-09 P2C.1 v30 首强制原任务及只读计算诊断\n\n')
    f.write('c12db66 clean push0后独立check_p2c_v30_freeze.py PASS；Humble+in-repo install/PYTHONNOUSERSITE=1/FastDDS UDPv4，taskset -c0-79 /usr/bin/python3 scripts/run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v30 --domain 210 --gazebo-port 20290 > log/p2c_v30_dev_forced2_runner.log 2>&1。04:38:50.476495..04:45:31.658417UTC自然结束，owner592550/observer5925670。300.2s EXPLORE timeout，仅1导航/0charge/0检测/最低11.2649506/零接触耗尽failed机器人。check_p2c_gate.py --run-root log/p2c/20261009_p2c_v30 --development --cases dev_forced2 --output log/p2c_v30_dev_forced2_gate.json FAIL native success；audit_p2c_v30_independent.py十二项PASS/130过期规划/121能量/1探索，未将子门改作任务成功。其余3开发/17/2/917未调用。\n\n')
    f.write('所有owned关闭后，profile_p2c_v30_geometry.py和profile_p2c_v30_assignment.py对保存的2078.682s唯一导航事件中实际交付地图211x253/.05m只读cProfile，无机器人派发、无输入续租/历史回放；完整条件调度0.648s/33预算/132返路/9圆盘膨胀，其中返路0.392s与膨胀0.265s。sim起始来自原world state1996.381，evaluator start2075.382/elapsed300.2，physics未改；domain222/master11345未操作。首错误只读sed路径run_p2c_v28_independent_audits.py不存在exit2，rg发现实际audit_p2c_v28_independent.py后重新读取；不属于任务启动。保存原FAIL、gate traceback、全部原始SHA、独立审计、profile输入/程序/输出和closed-before-edit。无P4/ns3/Wi-Fi/RL。\n')
print(json.dumps(dict(status='FAIL',failure_archives=len(artifacts),owned_closed=True,expired=130)))
