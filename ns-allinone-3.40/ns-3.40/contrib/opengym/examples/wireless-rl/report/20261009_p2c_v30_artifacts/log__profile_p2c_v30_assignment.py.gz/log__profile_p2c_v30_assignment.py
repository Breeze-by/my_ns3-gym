import cProfile,json,pstats,time,traceback
from pathlib import Path
from test_exploration_resume import conditional_snapshot_node
from multi_robot_exploration import control

e=json.loads(Path('log/p2c_v30_planning_snapshot.json').read_text())['event']
node,sent=conditional_snapshot_node(e,{})
node.robot_states={name:'idle' for name in node.robot_states}
node.enable_rally=True;node.initial_search_next={};node.initial_search_visits={};node.initial_search_views={}
node.target_search_visits=[];node.exploration_travel_choices={};node.frontier_charge_lookahead=None
profile=cProfile.Profile();started=time.perf_counter();error=None
try:profile.runcall(control.HeadquartersControl.assign_idle_robots,node)
except Exception:error=traceback.format_exc()
elapsed=time.perf_counter()-started
profile.dump_stats('log/p2c_v30_assignment.prof')
with open('log/p2c_v30_assignment_profile.txt','w') as f:
    pstats.Stats(profile,stream=f).strip_dirs().sort_stats('cumulative').print_stats(45)
Path('log/p2c_v30_assignment_profile.json').write_text(json.dumps(dict(
    scope='Held original delivered snapshot computation only; fixed evaluation epoch, no actual robot dispatch, not counterfactual task replay',
    profiled_wall_sec=elapsed,error=error,sent=[dict(robot=n,target=[a.x,a.y],navigation=[a.navigation_x,a.navigation_y]) for n,a in sent]),indent=2)+'\n')
print(elapsed,error,sent)
