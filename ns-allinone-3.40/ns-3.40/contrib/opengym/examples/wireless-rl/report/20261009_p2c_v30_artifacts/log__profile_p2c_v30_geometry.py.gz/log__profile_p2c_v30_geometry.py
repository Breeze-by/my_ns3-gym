import base64,cProfile,json,pstats,time,zlib
from pathlib import Path
import numpy as np
from multi_robot_exploration import control

snapshot=json.loads(Path('log/p2c_v30_planning_snapshot.json').read_text())
e=snapshot['event'];m=e['planning_map']
grid=np.frombuffer(zlib.decompress(base64.b64decode(m['grid'])),dtype='<i2').reshape(m['shape'])
resolution=m['resolution'];origin=m['origin'];positions=e['robot_positions']
outputs={};prepared=None;fields={}
def measure(name,call):
    profile=cProfile.Profile();started=time.perf_counter()
    result=profile.runcall(call);elapsed=time.perf_counter()-started
    profile.dump_stats('log/p2c_v30_'+name+'.prof')
    with open('log/p2c_v30_'+name+'_profile.txt','w') as f:
        pstats.Stats(profile,stream=f).strip_dirs().sort_stats('cumulative').print_stats(22)
    outputs[name]=dict(profiled_wall_sec=elapsed)
    print(name,round(elapsed,4),flush=True)
    return result
prepared=measure('prepare_frontier',lambda:control.prepare_frontier_data(grid,resolution))
outputs['prepare_frontier'].update(groups=len(prepared[0]),viewpoints=sum(map(len,prepared[2].values())))
for name,position in positions.items():
    fields[name]=measure('distance_'+name,lambda:control.exploration_distance_field(grid,prepared[1],resolution,origin,position))
    for refine in (False,True):
        candidates,diagnostics=measure('candidates_'+name+('_refine' if refine else ''),lambda:control.robot_candidate_assignments(
            grid,resolution,origin,name,position,(),prepared,
            blocked_positions=[p for n,p in positions.items() if n!=name] if refine else None,
            distance_field=fields[name]))
        outputs['candidates_'+name+('_refine' if refine else '')].update(diagnostics)
    known=measure('known_search_'+name,lambda:control.known_space_search_candidates(
        grid,resolution,origin,name,position,list(positions.values()),(),
        [p for n,p in positions.items() if n!=name],face_interest=True,camera_views=[]))
    outputs['known_search_'+name]['candidates']=len(known)
Path('log/p2c_v30_geometry_profile.json').write_text(json.dumps(dict(
    scope='Read-only CPU profile of one saved original delivered map; no task replay, no fresh inputs, no dispatch',
    snapshot='log/p2c_v30_planning_snapshot.json',shape=list(grid.shape),results=outputs),indent=2)+'\n')
