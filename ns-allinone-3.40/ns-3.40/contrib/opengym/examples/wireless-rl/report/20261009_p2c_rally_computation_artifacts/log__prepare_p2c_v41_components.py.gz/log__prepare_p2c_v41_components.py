import ast,gzip,hashlib,json,re,subprocess
from pathlib import Path
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap';w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report';parent='d70b277c853cc736c40b535a9d3551a0c99b0950'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def old(p):return subprocess.check_output(['git','show',parent+':'+str(p.relative_to(root))],cwd=root)
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py';native=r/'src/multi_robot_exploration/multi_robot_exploration/battery_manager.py'
compare=load(r/'log/p2c_v41_final_rally_comparisons.json');runtime=load(r/'log/p2c_v41_rally_runtime.json');source=load(r/'log/p2c_v41_source.json');prototypes=load(r/'log/p2c_v41_rally_computation_prototypes.json')
assert all(x['status']=='PASS' for x in (compare,runtime,source,prototypes))
assert compare['control_sha256']==runtime['control_sha256']==sha(control) and len(compare['comparisons'])==8 and runtime['actual_witnesses']==6
full=re.search(r'(\d+) passed in ([\d.]+)s',(r/'log/p2c_v41_full_tests.log').read_text());assert full and int(full[1])==1484
targeted=re.search(r'(\d+) passed in ([\d.]+)s',(r/'log/p2c_v41_targeted_tests.log').read_text());assert targeted and int(targeted[1])==40
build=re.search(r'4 packages finished \[([\d.]+)s\]',(r/'log/p2c_v41_build.log').read_text());assert build
for evidence,name in [('p2c_v41_manifest.log','p2c_integration_manifest.json'),('p2c_v41_blackout_manifest.log','p2c_blackout_manifest.json')]:
 current=load(r/'scripts'/name);assert load(r/'log'/evidence)['config']==current
 prior=json.loads(old(r/'scripts'/name))
 for key in ('cases','duration_sec','coverage_threshold','fault_seed','owner_shutdown_timeout_sec'):assert prior[key]==current[key]
 assert current['candidate_parent_commit']==parent and '20261009_p2c_v40_failed_development.json' in current['retained_failed_developments']
unchanged={}
for rel in ('src/multi_robot_exploration/multi_robot_exploration/battery_manager.py','src/multi_robot_exploration/multi_robot_exploration/action_callbacks.py','src/multi_robot_exploration/multi_robot_exploration/tf_ingress_sampler.py','src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py','scripts/check_p2c_gate.py','scripts/observer_lifetime.py','scripts/observe_p3b5.py','scripts/p2c_native_graph.py','scripts/ros_smoke_test.py'):
 p=r/rel;assert old(p)==p.read_bytes();unchanged[rel]=sha(p)
def defs(text):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(text).body if isinstance(n,(ast.ClassDef,ast.FunctionDef))}
a,b=defs(old(control).decode()),defs(control.read_text());assert a.keys()==b.keys();changed=[n for n in a if a[n]!=b[n]];assert changed==['assign_rally_poses','_assign_rally_poses']
fixture=r/'src/multi_robot_exploration/test/fixtures/p2c_v40_rally_computation_reference.json';f=load(fixture);binding=[]
for case in f['cases']:
 ledger=r/case['original_ledger'];assert sha(ledger)==case['ledger_sha256'];assert any(json.loads(line)==case['event'] for line in ledger.open())
 binding.append(dict(name=case['name'],ledger_sha256=sha(ledger),ledger_index=case['ledger_index']))
files=[p for p in (r/'log').glob('*p2c_v41*') if p.is_file() and p.suffix!='.pyc' and p.name!='p2c_v41_prepare_components.log']
dest=report/'20261009_p2c_rally_computation_artifacts';assert not dest.exists();dest.mkdir();artifacts=[]
for p in sorted(set(files)):
 q=dest/('__'.join(p.relative_to(r).parts)+'.gz');q.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0));assert gzip.decompress(q.read_bytes())==p.read_bytes()
 artifacts.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(q.relative_to(report)),archive_sha256=sha(q)))
out=dict(status='PASS',scope='Prospective equivalent rally computation; new mission integration pending',parent_commit=parent,
 control_sha256=sha(control),native_sha256=sha(native),changed_functions=changed,unchanged_from_parent=unchanged,
 full_suite_checks=int(full[1]),functional_wall_sec=float(full[2]),targeted_checks=int(targeted[1]),targeted_wall_sec=float(targeted[2]),build_wall_sec=float(build[1]),
 source_audit=source,actual_dds_rally=runtime,final_comparisons=compare,prototypes=prototypes,fixture_sha256=sha(fixture),original_binding=binding,
 limits='Targeted geometric failures are faster; existing feasible inputs are almost unchanged and rooms remains above2wall seconds. Fixed epoch CPU/DDD does not replay live clocks/history, guarantee causal native success or a worst-case deadline. Native, central state machine, actual safety and all source leases remain unchanged.',
 unrun=['new4 development','new17 formal','new2 physical','917'],artifacts=artifacts)
(report/'20261009_p2c_rally_computation_components.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
table='\n'.join('|'+name+'|'+f"{row['comparisons']['frozen_d70']['median_wall_sec']:.5f}"+'|'+f"{row['comparisons']['candidate41']['median_wall_sec']:.5f}"+'|' for name,row in compare['comparisons'].items())
text=f"""# P2C.1 v41 单次求解几何复用与约束优先核验组件 PASS

v40冻结d70b277首forced原生FAILED192.8s/insufficient_rally_poses，118.7s发现、无RALLY/native保持；两机各charge1/min14.95501，0接触耗尽机器人失效/任务期infra/retry。原任务strict FAIL，12独立审计PASS仍不是成功，其他3dev/17formal/2physical/917未调用。全部原数据和37附件见20261009_p2c_v40_failed_development.md/.json。

本轮在准确首/末失败输入上比较原算法、仅共享几何、仅约束优先和二者组合，5次paired cold；四种完整输出完全相同。首输入中位1.229/.750/.767/.450s，末1.185/.727/.728/.439s；一份实际可行输入约.490/.493/.487/.491s，组合不加速。仅二者组合合入，并增加不可变来源门禁。

复用仅存在于一次assign_rally_poses的两个原采样层：原安全图、每机起点和充电中心距离场、既有合格返路memo、软净空场。只有bytes拥有的不可变融合图及全部本地图满足门禁才跨层共享；可写数组和可写父数组的只读view逐层重建，每个公开提案新建缓存。预算、充电等待、分配、源戳不缓存，所有原current/end完整返路、local占据veto、body/route、observer/充电/cap/等待/稳定tie仍完整计算；原几何memo128位置与末段2048节点上限保持。

按本地已知终点较少的机器人优先构建完整能量选项，是失败检测的计算顺序偏好；本地图unknown/missing不拒绝融合合格路径。原分支搜索顺序、候选域72+外边界≤48→464、同一次第一完整可行层及所有硬准入不变。源码仅两个纯函数变化；中央类、native电池、clock/action/TF/Nav2/SLAM/物理字节保持。

最终源码八组原始ledger绑定输入，各5paired cold，全部位置/yaw完整提案与冻结d70相同：

| 原输入 | 原中位wall秒 | 新中位wall秒 |
|---|---:|---:|
{table}

两份几何失败有明显CPU改善，六份可行输入基本持平；部分略慢，房间仍约2.3wall秒。wall量不是sim源期限，也不是原现场因果对照；不能宣称普遍加速或硬时限/任务成功。

21新增检查覆盖8实际输入、不可变/可变/可写父数组只读view、两层中途地图变动、未知/缺本地图仍有合格融合候选，以及新提案改变地图/原点/位置/home/energy/mode后重新核验。40定向PASS{float(targeted[2]):.2f}s，1484完整PASS{float(full[2]):.2f}s，四包build{float(build[1]):.2f}s，171保护/4已授权变化/54static/8中央+2native Future注册PASS。

真实coordinator→独立DDS receiver共6份witness，覆盖一份不可行、二机/三机可行输入的新旧提案，独立读者逐格还原与源戳完全一致；仅fixed AP epochs，未运行Nav2动作或Gazebo任务。两份manifest validate-only PASS，全部38历史失败cohort索引补齐，原case/300s/owner120s/TTL/5s和物理刺激不变。

下一次clean pushed freeze仍须先forced严格native COMPLETE且每机charge≥1，再其余3dev；all4过才同freeze17formal+2physical，917最后首次暴露。组件PASS不等于新任务栈验收；P2C.1尚未完成，P3C.5已验收，无P4/ns-3/Wi-Fi/RL。
"""
(report/'20261009_p2c_rally_computation_components.md').write_text(text)
note=f'2026-10-09 P2C.1 v41集合计算组件PASS待新原任务：v40 d70b277首forced FAILED192.8/insufficient_rally_poses，detect118.7/无RALLY，各charge1/min14.95501；0contact/exhaustion/failed/task-time infra/retry，12审计PASS不替任务成功。四计算法对照后合入单次提案两层不可变几何复用+本地已知终点较少者优先核验；只计算排序、不删未知融合候选/不缓存预算源戳，原全返路/硬门/分支tie保持。八ledger原输入5cold完整输出相同，两失败CPU约1.21/1.23→.45/.46s，其余六近持平、rooms仍约2.3s；无普遍/因果/最坏保证。1484功能/40定向/四包{float(build[1]):.2f}s/171保护54static与6实际DDS witness PASS。仅2纯函数变化，native/中央class字节保持；新4→17+2同freeze待验证，38失败索引补齐，917未暴露。P3C.5已验收，无P4/ns3/Wi-Fi/RL。报告20261009_p2c_rally_computation_components.md与20261009_p2c_v40_failed_development.md；旧pending为历史。'
for p in (w/'AGENTS.md',w/'RESEARCH_PLAN.md',w/'IMPLEMENTATION_PLAN.md',r/'user_guide.md',r/'launch_commands.md'):
 lines=p.read_text().splitlines();assert lines[2].startswith('2026-10-09 P2C.1 v40');lines[2]=note;p.write_text('\n'.join(lines)+'\n')
p=root/'AGENTS.md';s=p.read_text();start=s.index('2026-10-09 P2C.1 v40');end=s.index('\n',start);p.write_text(s[:start]+note+s[end:])
with (w/'log.md').open('a') as f:
 f.write('\n\n## 2026-10-09 P2C.1 v41 集合计算四候选与原输出等价优化\n\n'+note+'\n\n')
 f.write('Humble+install/PYTHONNOUSERSITE1/FastDDS UDPv4清profiles，log/prototype_p2c_v41_rally_computation.py 原/共享几何/约束优先/组合，3原输入各5paired cold完整输出相同；log/prepare_p2c_v41_rally_fixture.py八输入逐字绑定原ledger SHA/index、冻结d70两函数；log/compare_p2c_v41_rally_final.py 最终八输入各5paired cold proposal位置/yaw完全相同，两个失败约1.21/1.23→.45/.46秒，其余近持平含少量退化/rooms2.3秒，非live sim时延/任务因果或最坏证明。\n\n')
 f.write(f'/usr/bin/python3 -m pytest -q src/multi_robot_exploration/test/test_rally_computation.py src/multi_robot_exploration/test/test_progressive_rally.py src/multi_robot_exploration/test/test_adaptive_rally_sampling.py {int(targeted[1])}PASS{float(targeted[2]):.2f}s；/usr/bin/python3 -m pytest -q src/multi_robot_exploration/test scripts --ignore=src/multi_robot_exploration/test/test_copyright.py --ignore=src/multi_robot_exploration/test/test_flake8.py --ignore=src/multi_robot_exploration/test/test_pep257.py {int(full[1])}PASS{float(full[2]):.2f}s；colcon build --symlink-install --packages-select multi_robot_interfaces multi_robot_exploration merge_map multi_robot 四包{float(build[1]):.2f}s。\n\n')
 f.write('check_p2c_source.py --output log/p2c_v41_source.json PASS；ROS_DOMAIN_ID219 log/check_p2c_v41_rally_runtime.py 6真实DDS witness/3原输入两算法独立source与分配重建PASS、无Nav2动作或Gazebo。run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v41 --domain 210 --gazebo-port 20290 --validate-only以及--manifest scripts/p2c_blackout_manifest.json --case physical_fault --run-id 20261009_p2c_v41_physical --domain 219 --gazebo-port 20299 --validate-only PASS/no任务。全部38历史failed cohort索引补齐，不删除原数据或从异算法挑成功；原300s/5s/TTL/预算和物理刺激不变，clean pushed新4→17+2待验证，917仍未暴露。\n')
print(json.dumps(dict(status='PASS',checks=int(full[1]),control_sha256=sha(control),artifacts=len(artifacts))))

