import base64,dataclasses,hashlib,inspect,json,statistics,time,types,zlib
from pathlib import Path
import numpy as np
from multi_robot_exploration import control as c
def transform(source, shared, constrained_first):
    if shared:
        source=source.replace('    for stratified in (False, True):', '    geometry_cache = {}  # Private to this one complete proposal.\n    for stratified in (False, True):',1)
        source=source.replace('hold_sec, return_maps, stratified)', 'hold_sec, return_maps, stratified, geometry_cache)',1)
        source=source.replace('    stratified=True,\n):','    stratified=True,\n    geometry_cache=None,\n):',1)
        original='''    traversable = traversable_grid(
        raw_grid, resolution, clearance_m=RALLY_PATH_CLEARANCE_M
    )
    options = {}'''
        replacement='''    geometry_cache = {} if geometry_cache is None else geometry_cache
    if "traversable" not in geometry_cache:
        geometry_cache["traversable"] = traversable_grid(
            raw_grid, resolution, clearance_m=RALLY_PATH_CLEARANCE_M)
    traversable = geometry_cache["traversable"]
    approach_fields = geometry_cache.setdefault("approach_fields", {})
    options = {}'''
        assert source.count(original)==1;source=source.replace(original,replacement,1)
        begin=source.index('        start = world_to_grid(',source.index('def _assign_rally_poses'))
        end=source.index('        reachable = []',begin)
        body=source[begin:end]
        source=source[:begin]+'''        if name not in approach_fields:
'''+''.join('    '+line+'\n' for line in body.rstrip().splitlines())+'''            approach_fields[name] = (distances, escape_distance)
        distances, escape_distance = approach_fields[name]
'''+source[end:]
        begin=source.index('                home_start, escape = navigation_start_route(')
        end=source.index('                return_exposures[name] = {}',begin)
        source=source[:begin]+'''                home_fields = geometry_cache.setdefault("home_fields", {})
                if name not in home_fields:
                    home_start, escape = navigation_start_route(
                        raw_grid, traversable, world_to_grid(*home, resolution, *origin),
                        max(1, math.ceil(.6 / resolution)))
                    home_distances = path_distance_grid(traversable, home_start)
                    home_escape = sum(math.dist(a, b) for a, b in zip(escape, escape[1:]))
                    home_fields[name] = (home_distances, home_escape)
                home_distances, home_escape = home_fields[name]
                modes[name] = mode
                charge_times[name] = duration
                return_cache = geometry_cache.setdefault("return_caches", {}).setdefault(name, {})
                clearance_fields = geometry_cache.setdefault("clearance_fields", {}).setdefault(name, {})
'''+source[end:]
    if constrained_first:
        old='''            for name in names:
                state = battery_states[name]'''
        new='''            def local_known_options(name):
                # Ordering only: local unknown cells do not veto fused routes.
                geometry = (return_maps or {}).get(name)
                if geometry is None:
                    return len(options[name]), name
                try:
                    known = 0
                    for _, index in options[name]:
                        pose = candidates[index]
                        cell = world_to_grid(pose.x, pose.y, geometry["resolution"], *geometry["origin"])
                        grid = geometry["data"]
                        known += (0 <= cell[0] < grid.shape[0] and 0 <= cell[1] < grid.shape[1]
                                  and grid[cell] == 0)
                    return known, name
                except (KeyError, TypeError, ValueError, ZeroDivisionError, AttributeError):
                    return len(options[name]), name
            for name in sorted(names, key=local_known_options):
                state = battery_states[name]'''
        assert source.count(old)==1;source=source.replace(old,new,1)
    return source
source=inspect.getsource(c.assign_rally_poses)+'\n'+inspect.getsource(c._assign_rally_poses)
def variant(shared,order):
    scope=dict(vars(c));text=transform(source,shared,order);exec(compile(text,'<rally computation prototype>','exec'),scope)
    return scope['assign_rally_poses'],text
def decode(s):return dict(data=np.frombuffer(zlib.decompress(base64.b64decode(s['grid'])),dtype='<i2').reshape(s['shape']),resolution=s['resolution'],origin=s['origin'])
def arguments(e):
 m=decode(e['planning_map']);return dict(raw_grid=m['data'],resolution=m['resolution'],origin=m['origin'],robot_positions=e['robot_positions'],target=e['target'],objective=e['objective'],battery_states=e['battery_states'],observer_robot=e['observer_robot'],current_positions=e['current_positions'],hold_sec=e['hold_sec'],return_maps={n:decode(v) for n,v in e['return_maps'].items()})
ledger=Path('log/p2c/20261009_p2c_v40/20261009_p2c_v40_dev_forced2/ledger.jsonl')
failed=[e for line in ledger.open() if (e:=json.loads(line)).get('event')=='coordinator_rally_assignment_failed']
events={'v40_first':failed[0],'v40_last':failed[-1],'v38_chosen':json.loads(Path('log/p2c_v38_rally_assignment_input.json').read_text())}
variants={'original':variant(False,False),'shared_geometry':variant(True,False),'constraint_first':variant(False,True),'both':variant(True,True)}
results={}
for name,e in events.items():
 rows={label:[] for label in variants};baseline=None
 for repeat in range(5):
  labels=list(variants);labels=labels if repeat%2==0 else labels[::-1]
  for label in labels:
   fn,_=variants[label];a=arguments(e);start=time.perf_counter();answer=fn(**a);wall=time.perf_counter()-start
   actual={n:dataclasses.asdict(p) for n,p in answer.items()}
   if baseline is None:baseline=actual
   assert actual==baseline,(name,label,actual,baseline)
   rows[label].append(wall)
 results[name]=dict(input_sha256=hashlib.sha256(json.dumps(e,sort_keys=True).encode()).hexdigest(),assignment=baseline,
   comparisons={label:dict(cold_wall_sec=times,median_wall_sec=statistics.median(times)) for label,times in rows.items()})
 print(name,{k:v['median_wall_sec'] for k,v in results[name]['comparisons'].items()},flush=True)
Path('log/p2c_v41_rally_computation_prototypes.json').write_text(json.dumps(dict(status='PASS',scope='Fixed original AP inputs; equal complete proposals, CPU samples only',comparisons=results),indent=2)+'\n')
Path('log/p2c_v41_combined_rally_functions.py').write_text(variants['both'][1])

