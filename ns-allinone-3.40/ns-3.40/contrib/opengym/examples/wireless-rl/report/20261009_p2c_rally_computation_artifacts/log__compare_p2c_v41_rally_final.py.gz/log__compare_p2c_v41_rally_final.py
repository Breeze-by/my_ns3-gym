import ast,dataclasses,hashlib,json,statistics,subprocess,time
from pathlib import Path
import test_rally_computation as reference
from multi_robot_exploration import control as c
out={};outputs=Path('log/p2c_v41_final_rally_comparisons.json');assert not outputs.exists()
for case in reference.REFERENCE['cases']:
 rows={'frozen_d70':[],'candidate41':[]};expected=None
 for repeat in range(5):
  methods=[('frozen_d70',reference.original_assign),('candidate41',c.assign_rally_poses)]
  if repeat%2:methods.reverse()
  for name,fn in methods:
   args=reference.saved_arguments(case['event']);start=time.perf_counter();answer=fn(**args);elapsed=time.perf_counter()-start
   result={n:dataclasses.asdict(p) for n,p in answer.items()}
   if expected is None:expected=result
   assert result==expected,(case['name'],name,result,expected)
   rows[name].append(elapsed)
 out[case['name']]=dict(original_ledger_sha256=case['ledger_sha256'],original_ledger_index=case['ledger_index'],assignment=expected,comparisons={n:dict(cold_wall_sec=t,median_wall_sec=statistics.median(t)) for n,t in rows.items()})
 print(case['name'],{n:statistics.median(t) for n,t in rows.items()},flush=True)
root=Path('/home/zhuyulab/ns3-workspace');path=Path(c.__file__).resolve();original=subprocess.check_output(['git','show','d70b277c853cc736c40b535a9d3551a0c99b0950:'+str(path.relative_to(root))],cwd=root,text=True)
def definitions(source):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(source).body if isinstance(n,(ast.ClassDef,ast.FunctionDef))}
a,b=definitions(original),definitions(path.read_text());assert a.keys()==b.keys();changed=[n for n in a if a[n]!=b[n]];assert changed==['assign_rally_poses','_assign_rally_poses']
outputs.write_text(json.dumps(dict(status='PASS',scope='Eight original AP input epochs, five paired cold proposals; no original trajectory/clock replay or causal task claim',control_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),parent_commit=reference.REFERENCE['reference_commit'],parent_source_sha256=reference.REFERENCE['reference_source_sha256'],changed_functions=changed,comparisons=out),indent=2)+'\n')

