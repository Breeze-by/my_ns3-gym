import dataclasses,hashlib,json,time,types
from pathlib import Path
import rclpy
from rclpy.node import Node
from rclpy.executors import SingleThreadedExecutor
from std_msgs.msg import String
from multi_robot_exploration import control as c
import check_p2c_gate as gate
import test_rally_computation as reference
output=Path('log/p2c_v41_rally_runtime.json');assert not output.exists()
rclpy.init(args=['--ros-args','-p','use_sim_time:=true','-p','robot_count:=3','-p','enable_battery:=true','-p','auto_save_map:=false'])
coordinator=receiver=None;executor=SingleThreadedExecutor();received=[];audits=[]
try:
 coordinator=c.HeadquartersControl();receiver=Node('p2c41_rally_witness_receiver')
 for timer in coordinator.timers:timer.cancel()
 for node in (coordinator,receiver):executor.add_node(node)
 subscription=receiver.create_subscription(String,coordinator.consumed_publisher.topic_name,lambda m:received.append(json.loads(m.data)),10)
 deadline=time.monotonic()+10.
 while coordinator.consumed_publisher.get_subscription_count()!=1 and time.monotonic()<deadline:executor.spin_once(timeout_sec=.02)
 assert coordinator.consumed_publisher.get_subscription_count()==1
 for case in (reference.REFERENCE['cases'][0],reference.REFERENCE['cases'][2],reference.REFERENCE['cases'][4]):
  e=case['event'];a=reference.saved_arguments(e)
  coordinator.map_data=a['raw_grid'];coordinator.source_map_data=reference.decode(e['source_map'])['data'];coordinator.resolution=a['resolution'];coordinator.origin=a['origin'];coordinator.map_self_return_cells=e['self_return_cells']
  coordinator.map_received_at=e['planning_map']['source_time'];coordinator.robot_positions=e['current_positions'];coordinator.target=e['target'];coordinator.battery_states=e['battery_states'];coordinator.target_observing_robot=e['observer_robot'];coordinator.rally_assignment_objective=e['objective']
  coordinator.robot_map_received_at={n:g['source_time'] for n,g in e['return_maps'].items()};coordinator.robot_maps=a['return_maps'];coordinator.now=lambda:e['event_time'];coordinator.input_freshness_details=lambda:e['inputs']
  expected=None
  for label,fn,module in [('frozen_d70',reference.original_assign,types.SimpleNamespace(**reference.scope)),('candidate41',c.assign_rally_poses,c)]:
   start=time.perf_counter();answer=fn(**a);wall=time.perf_counter()-start
   actual={n:dataclasses.asdict(p) for n,p in answer.items()}
   if expected is None:expected=actual
   assert expected==actual
   coordinator.rally_assignment_audit_at=-float('inf')
   count=len(received)
   coordinator.record_rally_assignment(a['robot_positions'],a['return_maps'],wall,answer or None,e['event_time'])
   deadline=time.monotonic()+5.
   while len(received)==count and time.monotonic()<deadline:executor.spin_once(timeout_sec=.02)
   assert len(received)==count+1
   gate.control=module;audit=gate.rally_assignment_audit(received[-1:]);assert audit['status']=='PASS'
   assert received[-1]['inputs']==e['inputs']
   audits.append(dict(case=case['name'],method=label,actual_dds_witness_index=count,wall_sec=wall,result=actual,audit=audit))
 result=dict(status='PASS',scope='Actual coordinator DDS producer and independent receiver; fixed saved AP epochs, complete proposals and independent reader, no Nav2 action/Gazebo task or live-latency claim',parent_commit=reference.REFERENCE['reference_commit'],control_sha256=hashlib.sha256(Path(c.__file__).read_bytes()).hexdigest(),reference_fixture_sha256=hashlib.sha256((Path(reference.__file__).parent/'fixtures/p2c_v40_rally_computation_reference.json').read_bytes()).hexdigest(),actual_witnesses=len(received),comparisons=audits,received_witnesses=received)
 output.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(dict(status='PASS',actual_dds_witnesses=len(received),conditional_inputs=3)))
finally:
 gate.control=c;executor.shutdown()
 for node in (coordinator,receiver):
  if node is not None:node.destroy_node()
 rclpy.shutdown()

