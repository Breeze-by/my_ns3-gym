import json
from pathlib import Path

def tail_rows(path):
 if not path.exists():return []
 with path.open('rb') as f:
  f.seek(0,2);size=f.tell();f.seek(max(0,size-2000000));rows=f.read().splitlines()
 if size>2000000:rows=rows[1:]
 out=[]
 for row in rows:
  try:out.append(json.loads(row))
  except json.JSONDecodeError:pass
 return out
for d in sorted(Path('log/p2c/20261009_p2c_v34').glob('*')):
 rows=tail_rows(d/'ledger.jsonl');safety=tail_rows(d/'safety_events.jsonl');latest=rows[-1] if rows else {}
 info=dict(case=d.name,phase=latest.get('task_phase'),sim_time=latest.get('event_time'),summary_exists=(d/'summary.json').exists())
 decisions=[e for e in rows if e.get('event')=='coordinator_navigation_decision']
 if decisions:info['last_goal']={k:decisions[-1].get(k) for k in ('event_time','robot','kind','requested_position')}
 visual=[e for e in decisions if 'initial_search_views' in e.get('travel_preference',{})]
 if visual:
  info['last_camera_goal']={k:visual[-1].get(k) for k in ('event_time','robot','requested_position','requested_yaw')}
  info['last_camera_goal']['delivered_history_views']=len(visual[-1]['travel_preference']['initial_search_views'])
 energies={}
 for e in safety:
  data=e.get('data')
  if isinstance(data,str):
   try:data=json.loads(data)
   except json.JSONDecodeError:continue
  if isinstance(data,dict) and data.get('event')=='energy_accounting':energies[data['robot']]={k:data.get(k) for k in ('sim_time','mode','energy','odom_source_time','frame_source_time')}
 info['native_energy']=energies
 print(json.dumps(info))
