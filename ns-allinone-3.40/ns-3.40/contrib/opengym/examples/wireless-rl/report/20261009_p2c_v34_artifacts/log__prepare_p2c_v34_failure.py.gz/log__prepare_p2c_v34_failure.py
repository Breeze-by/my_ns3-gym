import gzip, hashlib, json, os, collections
from pathlib import Path
from datetime import datetime, timezone

root = Path('/home/zhuyulab/ns3-workspace')
r = root / 'ros2_ws/ros2-multi-robot-automap'
w = root / 'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
report = w / 'report'
base = r / 'log/p2c/20261009_p2c_v34'
paths = sorted(base.glob('*/summary.json'))
assert len(paths) == 4
freeze = '08fe5f770f92fa2189b7c7d725491a56ec00ca2a'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

originals, closure, leases = {}, {}, {}
for p in paths:
    s = json.loads(p.read_text())
    assert s['git_commit'] == freeze
    result = s['result']
    assert result['collision_events'] == 0 and not result['failed_robots']
    assert s['runner_returncode'] == s['observer_returncode'] == 0
    c = s['case']
    originals[c] = s
    closure[c] = {}
    for key in ('owner_pid', 'observer_pid'):
        try:
            os.kill(s[key], 0)
        except ProcessLookupError:
            closure[c][key] = dict(pid=s[key], closed=True)
        else:
            raise AssertionError(('owned process still live', c, key, s[key]))
    for name, digest in s['evidence_sha256'].items():
        assert sha(p.parent / name) == digest
    counts = collections.Counter()
    for line in (p.parent / 'ledger.jsonl').open():
        e = json.loads(line)
        if e.get('event') == 'coordinator_planning_lease_expired':
            counts[e['stage']] += 1
    leases[c] = dict(counts)
assert [c for c, s in originals.items() if s['result']['success']] == ['dev_forced2']
closure['checked_at_utc'] = datetime.now(timezone.utc).isoformat()
(r / 'log/p2c_v34_closed_before_edit.json').write_text(json.dumps(closure, indent=2) + '\n')
gate = json.loads((r / 'log/p2c_v34_development_gate.json').read_text())
forced = json.loads((r / 'log/p2c_v34_dev_forced2_gate.json').read_text())
assert gate['status'] == 'FAIL' and forced['status'] == 'PASS'
audits = json.loads((r / 'log/p2c_v34_independent_audits.json').read_text())
assert len(audits) == 4 and all(len(rows) == 12 and all(v['status'] == 'PASS' for v in rows.values()) for rows in audits.values())
files = [p for p in base.rglob('*') if p.is_file() and p.suffix != '.pyc']
names = ['check_p2c_v34_freeze.py', 'p2c_v34_freeze_check.json', 'p2c_v34_development_gate.json',
         'p2c_v34_development_gate.log', 'p2c_v34_dev_forced2_gate.json', 'p2c_v34_dev_forced2_gate.log',
         'audit_p2c_v34_independent.py', 'p2c_v34_independent_audits.json', 'p2c_v34_independent_audits.log',
         'peek_p2c_v34_tasks.py', 'p2c_v34_closed_before_edit.json',
         'p2c_v34_dev_lab101_rally_snapshot.json', 'p2c_v34_dev_corridors303_rally_snapshot.json',
         'p2c_v34_rooms_first_decision.json', 'prepare_p2c_v34_failure.py']
files += [r / 'log' / n for n in names]
files += list((r / 'log').glob('p2c_v34_dev*_runner.log'))
assert len(list((r / 'log').glob('p2c_v34_dev*_runner.log'))) == 4
assert all(p.exists() for p in files)
destination = report / '20261009_p2c_v34_artifacts'
assert not destination.exists()
destination.mkdir()
artifacts = []
for p in sorted(set(files)):
    q = destination / ('__'.join(p.relative_to(r).parts) + '.gz')
    q.write_bytes(gzip.compress(p.read_bytes(), compresslevel=6, mtime=0))
    assert gzip.decompress(q.read_bytes()) == p.read_bytes()
    artifacts.append(dict(source=str(p.relative_to(root)), source_sha256=sha(p),
                          archive=str(q.relative_to(report)), archive_sha256=sha(q)))
output = dict(status='FAIL', scope='Four same-freeze development originals; 17 formal/2 physical/917 never invoked',
              task_stack_frozen_commit=freeze, originals=originals, strict_gate=gate,
              first_forced_gate=forced, independent_audits=audits, all_owned_closed_before_edit=closure,
              planning_lease_aborts=leases, task_retries=0, artifacts=artifacts)
(report / '20261009_p2c_v34_failed_development.json').write_text(json.dumps(output, indent=2) + '\n')
text = '# P2C.1 v34 四开发原任务 FAIL\n\n'
text += '冻结08fe5f770f92fa2189b7c7d725491a56ec00ca2a，control SHA0c6e30ac77a34d90cd224a82f696d9737c1bd5b4773f4bdf10ac494f4be3ec95。首强制原生/严格PASS后才调用其余三格；四个owner/observer自然退出0，均已关闭。原任务未重试或回填；17正式/2物理/917未调用。\n\n'
text += '| 原格 | 原生结果 | 检测/集合秒 | Nav2 | 总charge | min energy |\n|---|---|---|---|---|---|\n'
for c, s in originals.items():
    z = s['result']
    duration = z['completion_time_sec'] if z['success'] else z['elapsed_sim_time_sec']
    text += f"| {c} | {z['task_phase']} {z['termination_reason']} {duration:.1f} | {z['time_to_detect_sec']}/{z['time_to_rally_sec']} | {z['nav_goal_count']} | {z['battery_total_charges']} | {z['battery_minimum_energy']:.10f} |\n"
text += '\n四格0接触/耗尽/failed机器人/infra/retry。forced两机各charge1，原生5.4秒保持、55样本、最大间隔.1秒；其成功不可代替整组门禁。每格十二类独立return/energy/lookahead/AP veto/rally重建/repair/探索/target survey/朝向/lease/进程/nativeTF子门PASS，strict开发整组仍FAIL。\n\n'
text += 'lease弃置forced3generation；lab10(5generation2budget3route)；corr10(5generation1budget3route1dispatch)；rooms147(44generation43budget60route)。lab62/corr35选位可由原输入重建，但计算使来源过期，不能据选位存在声称RALLY成功。只读原输入profile/替代算法试验与原实时任务分开，不是完整历史回放、最坏时限或因果收益证据。rooms首成功交付图约.18秒的静态条件计算尚不能解释后续停滞。保留原300秒、2/5/60秒TTL和5秒真实保持；P2C.1未完成，P3C.5已验收，无P4/ns-3/Wi-Fi/RL。\n'
(report / '20261009_p2c_v34_failed_development.md').write_text(text)
heading = '## 2026-10-09 P2C.1 v34 四开发原任务 FAIL'
assert heading not in (w / 'log.md').read_text()
entry = '\n\n' + heading + '\n\n'
entry += '08fe5f7 commit/push0 → check_p2c_v34_freeze.py PASS后，Humble+install/PYTHONNOUSERSITE=1/FastDDS UDPv4/清旧profiles，taskset -c 0-79 /usr/bin/python3 scripts/run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v34 --domain 210 --gazebo-port 20290 > log/p2c_v34_dev_forced2_runner.log 2>&1。首强制严格checker PASS(exit0)后，其他三格同冻结、同环境和run-id，分别替换case/domain/port为dev_lab101/211/20291、dev_rooms202/212/20292、dev_corridors303/213/20293，各自重定向log/p2c_v34_<case>_runner.log。\n\n'
for c, s in originals.items():
    z = s['result']
    entry += f"{c}: {z['task_phase']}/{z['termination_reason']} elapsed={z['elapsed_sim_time_sec']:.1f}, completion={z['completion_time_sec']}, detect={z['time_to_detect_sec']}, rally={z['time_to_rally_sec']}, Nav2={z['nav_goal_count']}, charges={z['battery_total_charges']}, min={z['battery_minimum_energy']}, owner={s['owner_pid']}/observer={s['observer_pid']} exit0/0; lease={leases[c]}。\n\n"
entry += '全部owned关闭后才修改；0接触耗尽failed/infra/retry。check_p2c_gate.py --run-root log/p2c/20261009_p2c_v34 --development --output log/p2c_v34_development_gate.json exit1/FAIL；audit_p2c_v34_independent.py逐格十二子门PASS。原始完整命令/配置/source/evidence SHA/closure见report/20261009_p2c_v34_failed_development.md/.json和gzip旁证。17正式/2物理/917未调用，不能拼凑回填未来冻结。\n\n'
entry += '只读profile_p2c_v35_rally.py原最后选位重算一致，lab1.724/corr4.926秒，原实际3.214/6.526wall秒、2.3/5.1sim秒。后缀原型仍选位一致约1.621/4.091秒；profile_p2c_v35_ring.py旧三圈原型完整有解约.837/1.370秒，改变名义选择，尚非实时/完整任务/全候选最优。初后缀原型包名导入失败后修正，traceback保留；一次提前读取未完成strict文件FileNotFoundError、只读缺文件命令失败、首次failure准备脚本嵌套引号SyntaxError及未找到脚本exit2均保留为工具准备错误，无任务调用。profile_p2c_v35_rooms.py实际首图固定时间all-idle条件~.177→.171秒，6budget/2rays/等价；profile_p2c_v35_visual.py同图合成heading历史~.267→.282秒，32→29rays/7budget，等价但未构成改善。晚期视觉比较另录。原native/TTL不放宽，P2C.1仍未通过；无P4/ns3/Wi-Fi/RL。\n'
with (w / 'log.md').open('a') as f:
    f.write(entry)
print(json.dumps(dict(status='FAIL', artifacts=len(artifacts), cases=4, independent_checks=48,
                      owned_closed=True, lease_aborts=leases)))
