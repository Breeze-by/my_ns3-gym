import hashlib,json,os,subprocess
from pathlib import Path
from datetime import datetime,timezone
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
head=git('rev-parse','HEAD');upstream=git('rev-parse','@{u}')
assert head=='08fe5f770f92fa2189b7c7d725491a56ec00ca2a' and head==upstream,(head,upstream)
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
rows=[row for row in subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=root).decode().split('\0') if row]
assert len(rows)==14 and all(row[:3]=='?? ' and row[3:].startswith('260929_report/') for row in rows),rows
assert not (r/'log/p2c/20261009_p2c_v34').exists()
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py'
assert hashlib.sha256(control.read_bytes()).hexdigest()=='0c6e30ac77a34d90cd224a82f696d9737c1bd5b4773f4bdf10ac494f4be3ec95'
old=json.loads((r/'log/p2c/20261009_p2c_v33/20261009_p2c_v33_dev_forced2/summary.json').read_text())
for key in ('owner_pid','observer_pid'):
    try:os.kill(old[key],0)
    except ProcessLookupError:pass
    else:raise AssertionError(('prior owned process live',key,old[key]))
result=dict(status='PASS',head=head,upstream=upstream,worktree_status=rows,checked_at_utc=datetime.now(timezone.utc).isoformat(),
    no_prior_v34_original=True,v33_owned_closed=True,control_sha256=hashlib.sha256(control.read_bytes()).hexdigest())
(r/'log/p2c_v34_freeze_check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status='PASS',head=head,user_untracked_files=14)))
