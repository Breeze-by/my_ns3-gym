import gzip,hashlib,json,os
from pathlib import Path
from datetime import datetime,timezone
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
base=r/'log/p2c/20261009_p2c_v33';paths=list(base.glob('*/summary.json'));assert len(paths)==1
s=json.loads(paths[0].read_text());result=s['result'];assert s['git_commit']=='24e1e27bbb4ada0df1ae9a6a5b42e692c958b916'
assert not result['success'] and result['task_phase']=='FOUND' and result['nav_goal_count']==13 and result['battery_total_charges']==2
assert result['collision_events']==0 and not result['failed_robots'] and s['runner_returncode']==s['observer_returncode']==0
closure={}
for key in ('owner_pid','observer_pid'):
    try:os.kill(s[key],0)
    except ProcessLookupError:closure[key]=dict(pid=s[key],closed=True)
    else:raise AssertionError(('owned process still live',key,s[key]))
closure['checked_at_utc']=datetime.now(timezone.utc).isoformat()
(r/'log/p2c_v33_closed_before_edit.json').write_text(json.dumps(closure,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name,digest in s['evidence_sha256'].items():assert sha(paths[0].parent/name)==digest
gate=json.loads((r/'log/p2c_v33_dev_forced2_gate.json').read_text());assert gate['status']=='FAIL'
audits=json.loads((r/'log/p2c_v33_independent_audits.json').read_text());assert all(v['status']=='PASS' for v in audits['dev_forced2'].values())
files=[p for p in base.rglob('*') if p.is_file() and p.suffix!='.pyc']
names=('check_p2c_v33_freeze.py','p2c_v33_freeze_check.json','p2c_v33_dev_forced2_runner.log','p2c_v33_dev_forced2_gate.json','p2c_v33_dev_forced2_gate.log',
    'audit_p2c_v33_independent.py','p2c_v33_independent_audits.json','p2c_v33_independent_audits.log','peek_p2c_v33_tasks.py','p2c_v33_closed_before_edit.json',
    'prepare_p2c_v33_failure.py')
files += [r/'log'/name for name in names]
files += [p for p in (r/'log').glob('*p2c_v34*') if p.is_file()]
files.append(r/'log/p2c_v33_two_robot_computation.json')
destination=report/'20261009_p2c_v33_artifacts';destination.mkdir();artifacts=[]
for p in sorted(set(files)):
    q=destination/('__'.join(p.relative_to(r).parts)+'.gz');q.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0))
    assert gzip.decompress(q.read_bytes())==p.read_bytes()
    artifacts.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(q.relative_to(report)),archive_sha256=sha(q)))
output=dict(status='FAIL',scope='First frozen development original; remaining3/17/2/917 never invoked',original=s,strict_gate=gate,
    independent_audits=audits,all_owned_closed_before_edit=closure,task_retries=0,
    limitations='87 abandoned plans:41 candidate budgets/46 routes; median available original lease slack about1.30s. The first original found target at291.4s but never entered RALLY. No radio bottleneck or worst-case bound.',artifacts=artifacts)
(report/'20261009_p2c_v33_failed_development.json').write_text(json.dumps(output,indent=2)+'\n')
(report/'20261009_p2c_v33_failed_development.md').write_text('# P2C.1 v33 首强制原任务 FAIL\n\n冻结24e1e27bbb4ada0df1ae9a6a5b42e692c958b916，首dev_forced2自然FOUND timeout300.0秒，291.4秒检测、未进入RALLY；13个实际Nav2，双机各charge1/min11.4660094044/0接触耗尽failed机器人/0infra/retry。owner617175/observer617193均退出0并已关闭。strict门限FAIL，其余3开发/17正式/2物理/917从未调用；不回填或放宽原native/TTL。\n\n十二独立子门PASS：4闭合return triggers、2地图预算、5位姿租约、1local腿、2charger、121energy、10探索（2视觉4接续）、2target survey、1AP local地图veto、2失败集合分配重建、quiet1。87原lease弃置：41budget/46route，已观察planning开始原租约余量中位约1.30sim秒，结束检查在约1.35..1.4秒。此计数减少不是单因素因果证据或最坏时限界。\n\n只读固定早期双机交付图条件计算中位约.394秒、4次预算；对同source的v32约.673秒/108预算，选择和预算证据相同。该条件节点并非原实时owner/路径历史回放。profile中prepare_frontier_data约.262/总.412秒，157次visible ray约.194秒。下一步先试等价批量计算，不盲目声称前沿算法收益；无新候选任务。P3C.5已验收，P2C.1未完成；无P4/ns-3/Wi-Fi/RL。\n')
with (w/'log.md').open('a') as f:f.write('\n\n## 2026-10-09 P2C.1 v33 首强制原任务 FAIL\n\n24e1e27 commit/push0、check_p2c_v33_freeze.py PASS后，Humble+install/PYTHONNOUSERSITE=1/FastDDS UDPv4、清旧profiles、taskset -c0-79 /usr/bin/python3 scripts/run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v33 --domain210 --gazebo-port20290 > log/p2c_v33_dev_forced2_runner.log 2>&1。FOUND timeout300.0/检测291.4/RALLYnull/13Nav2/两机各charge1/min11.4660094044/0接触耗尽failed/owner617175 observer617193 exit0。check_p2c_gate.py --run-root log/p2c/20261009_p2c_v33 --development --cases dev_forced2 --output log/p2c_v33_dev_forced2_gate.json exit1 strict native success；audit_p2c_v33_independent.py12子门PASS/4closed return/2map/5pose/1local/2charger/121energy/10探索2visual4resume/2survey/1APveto/2failed allocation rebuilt/87lease(41budget46route)。所有owned关闭后才修改，余3/17/2/917未启动，原失败不重跑回填。\n\n只读profile_p2c_v34_two_robot.py提取原2089.582交付图，固定epoch/双idle条件（非实际owner历史），v32约.673s/108budget vsv33约.394s/4budget/选择证据相同；实际profile总.412s/prepare.262/157visible ray.194。benchmark_p2c_v34_batch_rays.py尝试1/2/4/8/16/32批量，逐候选gain与原相同；仅独立CPU条件样本，不是任务/最坏界。P3C.5已验收/P2C.1未完成，无P4/ns3/Wi-Fi/RL。\n')
print(json.dumps(dict(status='FAIL',artifacts=len(artifacts),expired=87,owned_closed=True)))
