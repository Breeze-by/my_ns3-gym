import hashlib,json,os,subprocess
from pathlib import Path
from datetime import datetime,timezone
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
head=git('rev-parse','HEAD');upstream=git('rev-parse','@{u}')
assert head=='24e1e27bbb4ada0df1ae9a6a5b42e692c958b916' and head==upstream,(head,upstream)
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
rows=[row for row in subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=root).decode().split('\0') if row]
assert len(rows)==14 and all(row[:3]=='?? ' and row[3:].startswith('260929_report/') for row in rows),rows
assert not (r/'log/p2c/20261009_p2c_v33').exists()
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py'
assert hashlib.sha256(control.read_bytes()).hexdigest()=='3f498b96929dcd7d4587e013a48bb2a6b2300254e24e430744b2f994e81ced3e'
old=json.loads((r/'log/p2c/20261009_p2c_v32/20261009_p2c_v32_dev_forced2/summary.json').read_text())
for key in ('owner_pid','observer_pid'):
    try:os.kill(old[key],0)
    except ProcessLookupError:pass
    else:raise AssertionError(('prior owned process live',key,old[key]))
result=dict(status='PASS',head=head,upstream=upstream,worktree_status=rows,checked_at_utc=datetime.now(timezone.utc).isoformat(),
    no_prior_v33_original=True,v32_owned_closed=True,control_sha256=hashlib.sha256(control.read_bytes()).hexdigest())
(r/'log/p2c_v33_freeze_check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status='PASS',head=head,user_untracked_files=14)))
