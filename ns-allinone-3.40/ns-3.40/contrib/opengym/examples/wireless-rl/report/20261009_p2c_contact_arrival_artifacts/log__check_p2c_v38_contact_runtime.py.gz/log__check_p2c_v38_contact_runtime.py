import hashlib,json,time,types,subprocess,sys
from pathlib import Path
import rclpy
from rclpy.node import Node
from rclpy.task import Future
from rclpy.executors import SingleThreadedExecutor
from std_msgs.msg import String
from action_msgs.msg import GoalStatus
from multi_robot_exploration import battery_manager as current
source_path='ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/multi_robot_exploration/battery_manager.py'
old_source=subprocess.check_output(['git','show','73fb1606d4976c7d3300fcd1c85105e12bab7297:'+source_path],text=True)
old=types.ModuleType('frozen_contact_probe');old.__file__=current.__file__;old.__package__='multi_robot_exploration';sys.modules[old.__name__]=old
exec(compile(old_source,'<frozen73 contact entry>','exec'),old.__dict__)
rclpy.init(args=['--ros-args','-p','robot_name:=contact_probe','-p','use_sim_time:=false'])
results=[]
try:
 for cls,label in ((old.BatteryManager,'frozen_outer_cancel'),(current.BatteryManager,'candidate_finish_contact')):
  node=cls();node.timer.cancel();reader=Node('contact_independent_reader');executor=SingleThreadedExecutor()
  executor.add_node(node);executor.add_node(reader);states=[]
  reader.create_subscription(String,'/contact_probe/battery_state',lambda m:states.append(json.loads(m.data)),10)
  limit=time.monotonic()+10.
  while node.state_publisher.get_subscription_count()<1 and time.monotonic()<limit:executor.spin_once(timeout_sec=.01)
  assert node.state_publisher.get_subscription_count()>=1
  node.now=lambda:11.;node.last_odom_time=11.;node.map_tf_source_time=11.;node.map_position=(node.charge_x+.3,node.charge_y)
  node.mode='RETURNING';node.mode_started_at=10.;node.return_no_route_since=None;node.return_audit_start=None
  node.return_stage='charger';node.return_attempts=1;node.linear_speed=0.;node.angular_speed=0.
  node.return_goal_pending=True;response=Future(executor=executor);done=Future(executor=executor);cancels=[]
  handle=types.SimpleNamespace(accepted=True,cancel_goal_async=lambda:cancels.append(True),get_result_async=lambda:done)
  node.defer_action_done_callback(response,node.return_goal_response)
  response.set_result(handle)
  limit=time.monotonic()+5.
  while node.return_goal_pending and time.monotonic()<limit:executor.spin_once(timeout_sec=.01)
  assert node.return_goal_handle is handle
  node.begin_charging();before=dict(mode=node.mode,cancels=len(cancels),charge_count=node.charge_count)
  node.publish_state()
  limit=time.monotonic()+5.
  while not any(s.get('mode')==before['mode'] for s in states) and time.monotonic()<limit:executor.spin_once(timeout_sec=.01)
  assert any(s.get('mode')==before['mode'] for s in states)
  done.set_result(types.SimpleNamespace(status=GoalStatus.STATUS_SUCCEEDED))
  limit=time.monotonic()+5.
  while node.return_goal_handle is not None and time.monotonic()<limit:executor.spin_once(timeout_sec=.01)
  assert node.return_goal_handle is None and node.mode=='CHARGING' and node.charge_count==0 and node.charge_stable_started_at is None
  node.update_charging(11.);assert node.charge_stable_started_at==11. and node.charge_count==0
  results.append(dict(label=label,before_result=before,after_result_mode=node.mode,charge_count=node.charge_count,energy=node.energy,
   original_contact_radius_m=node.charge_radius,original_charge_duration_sec=node.charge_duration,received_modes=sorted(set(s['mode'] for s in states))))
  node.shutdown_requested=True;executor.shutdown();node.destroy_node();reader.destroy_node()
 assert results[0]['before_result']['mode']=='CHARGING' and results[0]['before_result']['cancels']==1
 assert results[1]['before_result']['mode']=='RETURNING' and results[1]['before_result']['cancels']==0
 out=dict(status='PASS',native_source_sha256=hashlib.sha256(Path(current.__file__).read_bytes()).hexdigest(),
  reference_source_sha256=hashlib.sha256(old_source.encode()).hexdigest(),scope='Actual native nodes, real deferred Future response/results and independent DDS state receiver; synthetic accepted handle/fixed source time, no Nav2/Gazebo motion or parking benefit claim',cases=results)
 Path('log/p2c_v38_contact_runtime.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
finally:rclpy.shutdown()

