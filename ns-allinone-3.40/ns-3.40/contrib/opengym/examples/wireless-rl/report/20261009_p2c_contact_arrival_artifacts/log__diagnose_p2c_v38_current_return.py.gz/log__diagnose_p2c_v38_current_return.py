import json, math, dataclasses
from pathlib import Path
from multi_robot_exploration import control as c
from test_exploration_resume import conditional_snapshot_node
e=json.loads(Path('log/p2c_v37_dev_forced2_candidate_budget_expired_snapshot.json').read_text());d=e['diagnostic_inputs']
n,sent=conditional_snapshot_node(dict(d,inputs=e['inputs_at_start'],event_time=e['planning_started_at_sec']),d['exploration_resume_intents'].copy())
n.robot_states=d['robot_states'].copy();n.battery_modes=d['battery_modes'].copy()
out={}
for name in n.robot_positions:
 pos=n.robot_positions[name];state=n.battery_states[name];home=tuple(state[q] for q in ('charge_x','charge_y'))
 local=c.HeadquartersControl.delivered_return_maps(n).get(name)
 rows=c.qualified_return_candidates(n.map_data,n.resolution,n.origin,pos,home,state['charge_radius_m'],local,{})
 info=dict(position=pos,home=home,contact_distance=math.dist(pos,home),rows=[{k:v for k,v in row.items() if k!='route'} for row in rows])
 geometries={'planning':dict(data=n.map_data,resolution=n.resolution,origin=n.origin),'local':local}
 for source,g in geometries.items():
  if g is None:continue
  raw=g['data'];initial=c.world_to_grid(*pos,g['resolution'],*g['origin'])
  info[source]=dict(shape=raw.shape,initial_cell=initial,initial_value=int(raw[initial]),resolution=g['resolution'])
  field=c.charging_route_field(raw,g['resolution'],g['origin'],home,state['charge_radius_m'],{})
  if field is not None:info[source].update(initial_safe=bool(field[0][initial]),initial_distance=float(field[1][initial]))
 out[name]=info
Path('log/p2c_v38_current_return_diagnosis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))

