import ast,gzip,hashlib,json,re,subprocess
from pathlib import Path
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap';w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
parent='73fb1606d4976c7d3300fcd1c85105e12bab7297'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
native=r/'src/multi_robot_exploration/multi_robot_exploration/battery_manager.py'
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py'
def oldbytes(p):return subprocess.check_output(['git','show',parent+':'+str(p.relative_to(root))],cwd=root)
assert oldbytes(control)==control.read_bytes()
before=ast.parse(oldbytes(native));after=ast.parse(native.read_text())
def methods(t):
 cl=next(n for n in t.body if isinstance(n,ast.ClassDef) and n.name=='BatteryManager')
 return {n.name:ast.dump(n) for n in cl.body if isinstance(n,ast.FunctionDef)}
a,b=methods(before),methods(after);changed=[name for name in a if a[name]!=b[name]]
assert changed==['begin_charging'] and a.keys()==b.keys(),changed
source=load(r/'log/p2c_v38_source.json');assert source['status']=='PASS'
full=re.search(r'(\d+) passed in ([\d.]+)s',(r/'log/p2c_v38_full_tests.log').read_text());assert full and int(full[1])==1413
build=re.search(r'4 packages finished \[([\d.]+)s\]',(r/'log/p2c_v38_build.log').read_text());assert build
runtime=load(r/'log/p2c_v38_contact_runtime.json');future=load(r/'log/p2c_v38_native_future_runtime.json')
assert runtime['status']==future['status']=='PASS' and runtime['native_source_sha256']==future['current_source_sha256']==sha(native)
for file,name in [('p2c_v38_manifest.log','p2c_integration_manifest.json'),('p2c_v38_blackout_manifest.log','p2c_blackout_manifest.json')]:
 saved=json.loads((r/'log'/file).read_text());current=load(r/'scripts'/name);assert saved['config']==current
 prior=json.loads(oldbytes(r/'scripts'/name))
 for key in ('cases','duration_sec','coverage_threshold','fault_seed','owner_shutdown_timeout_sec'):assert prior[key]==current[key]
unchanged={}
for rel in ('src/multi_robot_exploration/multi_robot_exploration/action_callbacks.py','src/multi_robot_exploration/multi_robot_exploration/tf_ingress_sampler.py','src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py','scripts/check_p2c_gate.py','scripts/observer_lifetime.py','scripts/observe_p3b5.py','scripts/p2c_native_graph.py','scripts/ros_smoke_test.py'):
 p=r/rel;assert oldbytes(p)==p.read_bytes();unchanged[rel]=sha(p)
files=[p for p in (r/'log').glob('*p2c_v38*') if p.is_file() and p.suffix!='.pyc' and p.name!='p2c_v38_prepare_components.log']
dest=report/'20261009_p2c_contact_arrival_artifacts';assert not dest.exists();dest.mkdir();artifacts=[]
for p in sorted(set(files)):
 q=dest/('__'.join(p.relative_to(r).parts)+'.gz');q.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0))
 assert gzip.decompress(q.read_bytes())==p.read_bytes()
 artifacts.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(q.relative_to(report)),archive_sha256=sha(q)))
out=dict(status='PASS',scope='Prospective native contact waypoint arrival; mission acceptance pending',
 parent_commit=parent,native_sha256=sha(native),control_sha256=sha(control),changed_native_methods=changed,
 functional_checks=int(full[1]),functional_wall_sec=float(full[2]),build_wall_sec=float(build[1]),
 source_audit=source,actual_contact_future_dds=runtime,actual_native_serial_future=future,unchanged_from_parent=unchanged,
 diagnosis=load(r/'log/p2c_v38_current_return_diagnosis.json'),
 conditional_previous_inputs=load(r/'log/p2c_v38_forced_profile_expired_profiles.json'),
 limits='Independent fixed-time DDS/Future tests are not Gazebo/Nav2 physical parking or causal task proof. Nav2 positional tolerance and fresh local-map occupancy can still block later admission. Existing unknown/occupied return rejection is preserved.',
 unrun=['new4 development','new17 formal','new2 physical','917'],artifacts=artifacts)
(report/'20261009_p2c_contact_arrival_components.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
text=f"""# P2C.1 v38 完成已接受接触航段组件 PASS

v37冻结73fb160首forced原任务EXPLORE timeout300.1s、目标未确认；两机各charge1、最低8.340687732012016，零接触/耗尽/failed/任务期infra/retry。owner/observer自然exit0且原件SHA保持；277 live/12独立审计PASS不能替代任务成功。完整原记录见20261009_p2c_v37_failed_development.md/.json；其他3dev/17formal/2physical/917未调用。

准确保存输入显示tb2充电后位置(.2859,-.2568)距其home(0,.45)约.7624m，小于原.8m接触半径，但原本地SLAM当前单元100、融合图0；local veto与constrained_fused均正确拒绝。物理无碰撞不证明地图障碍的来源，不允许凭此清除占用或绕开返航预算。native原返航已接受目标(.273755673,-.076247627)，却进入外侧半径就取消，实际return_finished cancellation_count1。当前地图阻塞是具体限制；“提前停车导致后续阻塞”是待新原任务验证的解释。

改动仅native begin_charging：return request pending或handle仍在时继续RETURNING，不因进入外侧半径取消已预算的航段；原result处理清除owner后才进入原CHARGING，仍需原静止/稳定持续时长。没有新增目标或更深接触点；原完全已知地图返路、radius.8、储备/进展watchdog/返航总120/180s/charge60s、native pose/TF2s/地图5s、能量计量/源龄/native completion300s/.35/.05/.1/5s均保持。失败/无进展仍取消一次并持有handle至result。所有control源码与纯几何/预算byte保持。

新增5checks：pending/accepted/同时pending+accepted三类不能充电或取消；原SUCCEEDED清除handle后进入CHARGING且不提前启动稳定计时；接触边等待仍遵守原reserve floor、失败取消owner不丢失。相关104PASS3.87s，全{int(full[1])}PASS{float(full[2]):.2f}s，四包build{float(build[1]):.2f}s、171保护/4授权/54static与8中央+2native Future注册PASS。

实际ROS原73/new native两节点、真实deferred Future响应/结果、独立DDS state receiver对照：旧版结果前CHARGING/cancel1，新版RETURNING/cancel0，结果后均CHARGING/charge0/energy40；原radius.8/charge6s仍相同。新native序列化Future回归也PASS；控制器未改，无需重做旧控制器八类source-bound对照，相关完整tests仍通过。隔离固定epoch/合成accepted handle不含Nav2/Gazebo运动，不能证明实际停车或任务收益。

最后两份原弃置输入约.8/.7秒仍超过.50/.30秒source剩余，且原known return在occupied当前位置不可用；继续保留该性能/地图限制。目标完成后的Nav2位置容差和本地SLAM占用仍可能阻止探索，不保证端点本身被实际到达或本地map误差已修复。下一clean pushed freeze先新forced原生及每机charge≥1，之后另3开发；all4过才17正式+2物理，917最后首次暴露。所有case/物理刺激不变，P2C.1尚未完成；P3C.5已验收，无P4/ns-3/Wi-Fi/RL。
"""
(report/'20261009_p2c_contact_arrival_components.md').write_text(text)
note=f'2026-10-09 P2C.1 v38接触航段自然结束组件PASS待新原任务：v37 73fb160首forced EXPLOREtimeout300.1/未检测/两机各charge1/min8.34069，0安全/task-time infra/retry，277live与12审计PASS不替代任务成功。tb2外半径内提前取消后停在fresh local占用单元100，AP veto正确；因果仍待验证。仅native begin_charging等待原pending/accepted航段结果，再原稳定计时；原radius/TTL/储备/超时/物理与control源码保持。{int(full[1])}功能/四包{float(build[1]):.2f}s/171保护54协议/实际native Future+独立DDS与串行回归PASS。Nav2容差/占用仍可能阻止接续，新4→17+2同clean pushed freeze待验证，917未暴露；P3C.5已验收，无P4/ns3/Wi-Fi/RL。报告20261009_p2c_contact_arrival_components.md与20261009_p2c_v37_failed_development.md；旧pending说明为历史。'
for p in (w/'AGENTS.md',w/'RESEARCH_PLAN.md',w/'IMPLEMENTATION_PLAN.md',r/'user_guide.md',r/'launch_commands.md'):
 lines=p.read_text().splitlines();assert lines[2].startswith('2026-10-09 P2C.1 v37');lines[2]=note;p.write_text('\n'.join(lines)+'\n')
p=root/'AGENTS.md';s=p.read_text();start=s.index('2026-10-09 P2C.1 v37');end=s.index('\n',start);p.write_text(s[:start]+note+s[end:])
with (w/'log.md').open('a') as f:
 f.write('\n\n## 2026-10-09 P2C.1 v38 native接触航段自然结束组件\n\n'+note+'\n\n')
 f.write('Humble+install/PYTHONNOUSERSITE1/FastDDS UDPv4清profiles，taskset -c 0-79；pytest -q src/multi_robot_exploration/test/test_charge_contact_arrival.py test_return_budget.py test_battery_manager.py（后三路径同目录）104PASS3.87s；full /usr/bin/python3 -m pytest -q src/multi_robot_exploration/test scripts --ignore=src/multi_robot_exploration/test/test_copyright.py --ignore=src/multi_robot_exploration/test/test_flake8.py --ignore=src/multi_robot_exploration/test/test_pep257.py '+str(int(full[1]))+'PASS/'+str(float(full[2]))+'s。colcon build --symlink-install --packages-select multi_robot_interfaces multi_robot_exploration merge_map multi_robot '+str(float(build[1]))+'s；check_p2c_source.py --output log/p2c_v38_source.json PASS171/4/54。\n\n')
 f.write('ROS_DOMAIN_ID219 /usr/bin/python3 log/check_p2c_v38_contact_runtime.py实际旧73/new native deferred Future与独立DDS，旧CHARGING/cancel1→newRETURNING/cancel0，结果后原stable timer/charge0/energy40；221 scripts/check_p2c_native_future_runtime.py --output log/p2c_v38_native_future_runtime.json actual序列化回归PASS。控制器byte保持329719...、native只有begin_charging改变，所有其他函数/预算/TTL/物理/刺激保持；条件fixed epoch不是实际Nav2停车因果。run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v38 --domain 210 --gazebo-port 20290 --validate-only与--manifest scripts/p2c_blackout_manifest.json --case physical_fault --run-id 20261009_p2c_v38_physical --domain 219 --gazebo-port 20299 --validate-only均PASS，无任务。新4→17+2同clean pushed freeze待原生验证，917未暴露；domain222/master11345未操作。\n')
print(json.dumps(dict(status='PASS',checks=int(full[1]),native_sha256=sha(native),artifacts=len(artifacts))))

