import ast,gzip,hashlib,json,re,subprocess
from pathlib import Path
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
parent='89ee853151d45ae5dbe604f00ccafa8b522c7eb9'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def old(p):return subprocess.check_output(['git','show',f'{parent}:{p.relative_to(root)}'],cwd=root)
def archive(paths,name):
    destination=report/name;destination.mkdir();rows=[]
    for p in sorted(set(paths)):
        out=destination/('__'.join(p.relative_to(r).parts)+'.gz');assert not out.exists()
        out.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0))
        assert gzip.decompress(out.read_bytes())==p.read_bytes()
        rows.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(out.relative_to(report)),archive_sha256=sha(out)))
    return rows
base=r/'log/p2c/20261009_p2c_v22';paths=list(base.glob('*/summary.json'));assert len(paths)==1
original=load(paths[0]);assert original['git_commit']==parent and original['case']=='dev_forced2'
assert original['runner_returncode']==original['observer_returncode']==0
assert not any(v for k,v in original.items() if k.endswith('_forced_shutdown'))
result=original['result'];assert not result['success'] and result['task_phase']=='EXPLORE' and result['collision_events']==0 and not result['failed_robots']
assert [v['battery_charge_count'] for v in result['robots'].values()]==[1,0]
for name,h in original['evidence_sha256'].items():assert sha(paths[0].parent/name)==h
gate=load(r/'log/p2c_v22_dev_forced2_original_gate.json');assert gate['status']=='FAIL'
process=load(r/'log/p2c_v22_launch_process_audit.json');assert process['status']=='FAIL' and 'control-33' in process['error']
independent=load(r/'log/p2c_v22_independent_audits.json')
assert all(v['status']=='PASS' for k,v in independent['dev_forced2'].items() if k!='native_vs_gateway_frame_samples')
files=[p for p in base.rglob('*') if p.is_file() and p.suffix!='.pyc']
files += [r/'log'/n for n in ('p2c_v22_freeze_check.json','check_p2c_v22_freeze.py','p2c_v22_dev_forced2_runner.log',
    'p2c_v22_dev_forced2_original_gate.json','p2c_v22_dev_forced2_original_gate.log','p2c_v22_launch_process_audit.json',
    'audit_p2c_v22_independent.py','p2c_v22_independent_audits.json','p2c_v22_independent_audits.log')]
failure=dict(status='FAIL',scope='First original forced development task only',task_stack_frozen_commit=parent,
    original=original,strict_gate=gate,independent_audits=independent,task_child_process_audit=process,
    task_time_infrastructure_failures=1,task_retries=0,all_owned_closed_before_edits=True,
    cause='Actual known-space grid group was NumPy int64; first visual witness failed json.dumps, coordinator exited1 before owned shutdown. Outer owner/observer exit0 do not mean zero task-time infrastructure failure.',
    unrun=['other3 development','17 formal','both physical','917 first exposure'],
    artifacts=archive(files,'20261009_p2c_v22_artifacts'))
(report/'20261009_p2c_v22_failed_development.json').write_text(json.dumps(failure,indent=2)+'\n')
(report/'20261009_p2c_v22_failed_development.md').write_text('''# P2C.1 v22 首个真实补查派发 FAIL

冻结 `89ee853151d45ae5dbe604f00ccafa8b522c7eb9` 的dev_forced2：真实补查目标group35680在私有导航决策JSON中仍为NumPy int64，序列化抛TypeError、control退出1。原launch第223行在第227行owned SIGINT之前，属于一次任务期间基础设施失败；外层owner/observer最终0自然关闭不能掩盖该失败。原EXPLORE timeout300.4s，无检测/集合/原生完成，充电次数1/0、最低11.548989，零接触/耗尽/机器人失效。其他三开发、17正式、两物理和917未调用，无重试或回填。

原strict gate FAIL及trace完整保留，未来只读子进程退出检查对同原launch单独重读也FAIL。独立输入检查仍PASS：3closed返航/2map预算/4pose租约/1本地腿/1charger return、121能量样本、两条原普通探索；第一条补查在JSON发布之前崩溃，没有有效私有补查记录，不能声称算法任务已验证或两机器人强制充电通过。原数据与命令/配置/源码/输入SHA、完整图、trace无损归档。

未来修复仅把候选网格行列转为Python int，不改坐标、收益、成本、能源、源龄、净空、Nav2、300s/5s或物理刺激。增加实际发布入口及DDS接收/独立读者验证，不使用通用JSON默认转换来掩盖类型错误。失败原格不重新运行替代。P3C.5已验收，无P4/ns-3/Wi-Fi/RL。
''')
checks=(r/'log/p2c_v23_full_components.log').read_text();m=re.search(r'(\d+) passed in ([\d.]+)s',checks);assert m and 'FAILED' not in checks
b=re.search(r'4 packages finished \[([\d.]+)s\]',(r/'log/p2c_v23_build.log').read_text());assert b
source=load(r/'log/p2c_v23_source.json');assert source['status']=='PASS'
runtime=load(r/'log/p2c_v23_visual_runtime_final.json');assert runtime['status']=='PASS' and runtime['numeric_candidate_equality'] and runtime['candidates_compared']==79
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py';assert runtime['control_sha256']==sha(control)
def methods(text):
    node=next(n for n in ast.parse(text).body if isinstance(n,ast.ClassDef) and n.name=='HeadquartersControl')
    return {n.name:ast.dump(n,include_attributes=False) for n in node.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
before=methods(old(control));after=methods(control.read_bytes());assert before==after
unchanged={}
for rel in ('src/multi_robot_exploration/multi_robot_exploration/battery_manager.py',
    'src/multi_robot_exploration/multi_robot_exploration/tf_ingress_sampler.py',
    'src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py','scripts/observe_p3b5.py','scripts/p2c_native_graph.py'):
    p=r/rel;assert p.read_bytes()==old(p);unchanged[rel]=sha(p)
for n,c in (('p2c_v23_manifest.json','p2c_integration_manifest.json'),('p2c_v23_blackout_manifest.json','p2c_blackout_manifest.json')):
    assert load(r/'log'/n)['config']==load(r/'scripts'/c)
qa=[r/'log'/n for n in ('p2c_v23_publication_before_fix.log','p2c_v23_publication_after_fix.log','p2c_v23_full_components.log',
    'p2c_v23_build.log','p2c_v23_source.json','p2c_v23_source.log','p2c_v23_manifest.json','p2c_v23_blackout_manifest.json',
    'p2c_v23_visual_runtime.json','p2c_v23_visual_runtime.log','p2c_v23_visual_runtime_final.json','p2c_v23_visual_runtime_final.log',
    'prepare_p2c_v23_evidence.py')]
components=dict(status='PASS',scope='Prospective integer-publication and launch-reader components only',parent_commit=parent,
    functional_checks=int(m[1]),component_wall_sec=float(m[2]),build_wall_sec=float(b[1]),control_sha256=sha(control),
    source_audit=source,unchanged_from_parent=unchanged,preserved_central_methods=len(before),actual_visual_dds=runtime,
    reused_actual_ap_snapshot_evidence='v22 actual ROS DDS50-snapshot/TF-only probe; all central method ASTs including constructor and callbacks identical.',
    publication_regression='Before fix1FAIL2.00s reproduces int64 TypeError through real generator/coordinator publication; after fix1PASS1.54s with independent reader.',
    task_process_reader='Task-time nonzero child exit before owned SIGINT fails; original post-task cleanup exit codes retained separately without claiming graceful cleanup.',
    unrun=['newall4 development','new17 formal','new2 physical','917 first exposure'],
    artifacts=archive(qa,'20261009_p2c_visual_publication_artifacts'))
(report/'20261009_p2c_visual_publication_components.json').write_text(json.dumps(components,indent=2)+'\n')
(report/'20261009_p2c_visual_publication_components.md').write_text(f'''# P2C.1 v23 整数发布与任务子进程检查组件 PASS

v22首个真实补查的NumPy int64组编号导致control任务期间退出1，原FAIL和原始记录保留。候选坐标入口仅转为标准Python整数。全部{len(before)}中央方法AST、本地battery/sampler/launch与native图工具字节保持；真实DDS逐字段比较79候选数值不变，旧冻结候选在同一实际发布入口复现异常，未来候选真实接收且独立补查/完整路径读者PASS。原预算、源TTL、300秒/5秒、安全、物理刺激不变。

新增发布边界回归旧1FAIL2.00s→修复1PASS1.54s；全功能{int(m[1])}PASS{float(m[2]):.2f}s、四包{float(b[1]):.2f}s、171保护4授权/54协议、普通及物理预声明PASS。新增launch原日志读者严格区分任务期间崩溃和owned停止后的清理退出；后者保留实际exit code，不称子进程都自然退出。原外层exit0不再足以掩盖任务期崩溃。AP50快照/TF重投影与native完整图实际DDS证明按相同方法/源码SHA保留；新原任务仍须实际完整图。

新同提交4开发/17正式/2物理尚待新冻结。917未暴露；组件结果不是任务完成、因果收益、Wi-Fi测量或硬件安全证明。P3C.5已验收，无P4/ns-3/Wi-Fi/RL。
''')
note=f'2026-10-09 P2C.1 v23发布边界组件PASS、待新冻结：v22首forced原EXPLORE timeout300.4/charge1与0/最低11.548989/零接触耗尽机器人失效，但control因NumPy int64 JSON异常在任务期间退出1，infra1严格FAIL，外层0不掩盖；其余格与917未跑，原始/trace保留。未来仅标准化候选编号类型，79候选数值一致，真实DDS旧异常复现/新发布+独立读者PASS，{int(m[1])}功能/四包{float(b[1]):.2f}s/171保护4授权/54协议/两manifest PASS。{len(before)}中央方法AST/native battery/sampler/launch/图工具保持；新读者任务期子进程非零即FAIL，停止后清理退出另记。新4开发/17正式/2物理须clean pushed freeze，原300s/5s/TTL/物理保持；P3C.5已验收，无P4/ns-3/Wi-Fi/RL。报告20261009_p2c_visual_publication_components.md与20261009_p2c_v22_failed_development.md。'
for p in (w/'AGENTS.md',w/'RESEARCH_PLAN.md',w/'IMPLEMENTATION_PLAN.md',r/'user_guide.md',r/'launch_commands.md'):
    first,rest=p.read_text().split('\n',1);p.write_text(first+'\n\n'+note+'\n'+rest)
p=root/'AGENTS.md';p.write_text(p.read_text().replace('## Current Handoff\n','## Current Handoff\n\n'+note+'\n',1))
with (w/'log.md').open('a') as f:
    f.write('\n\n## 2026-10-09 P2C.1 v22任务期崩溃FAIL与v23整数发布补强\n\n'+note+'\n\n')
    f.write('ROS工作区/source Humble+install/PYTHONNOUSERSITE=1/系统Python3/RMW FastRTPS+UDPv4。89ee853 push与独立clean freeze通过后，taskset0-79 run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v22 --domain210 --gazebo-port20290。任务原300.4s超时，中央任务期间JSON TypeError/exit1，tb1charge1/tb2charge0，owner/observer最终0；原strict checker --development --cases dev_forced2 FAIL，独立七类budget/native/path只读检查PASS，未来launch_process_audit原launch重读FAIL。所有owned关闭后才修复；无任务重试/回填，其他3dev/17formal/2physical/917未启动。全部exact runner/observer/launch commands、配置/SHA与trace在原summary及无损归档。\n\n')
    f.write('test_initial_known_search.py -k real_known_candidate旧1FAIL33deselected2.00s/修复1PASS33deselected1.54s；全pytest同三lint ignore，1088PASS79.21s；四包colcon build；check_p2c_source.py与两个manifest validate-only；check_p2c_visual_runtime.py隔离domain215两次实际DDS（最终加79候选数值一致性），原NumPy异常期望复现/新消息接收独立reader PASS，均无任务/无线测量。全部输出在20261009_p2c_visual_publication_components.json。\n')
print(json.dumps(dict(failure_artifacts=len(failure['artifacts']),component_artifacts=len(components['artifacts']),checks=int(m[1]),build_sec=float(b[1]),preserved_central_methods=len(before))))
