import base64,json,math,zlib
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from multi_robot_exploration import control as c

path=next(Path('log/p2c/20261009_p2c_v23').glob('*/ledger.jsonl'))
event=next(e for line in path.open() if (e:=json.loads(line)).get('event')=='coordinator_navigation_decision'
    and e.get('kind')=='initial_visual_search' and e['robot']=='tb2' and e['travel_preference']['target'][0]>4.)
fixture=Path('log/p2c_v23_diversity_input.json');assert not fixture.exists();fixture.write_text(json.dumps(event,indent=2)+'\n')
def decode(s):return dict(data=np.frombuffer(zlib.decompress(base64.b64decode(s['grid'])),dtype='<i2').reshape(s['shape']),resolution=s['resolution'],origin=s['origin'])
maps={key:decode(s) for key,s in [('planning',event['planning_map']),('source',event['source_map']),*event['return_maps'].items()]}
g=maps['planning'];states=event['battery_states'];f=event['travel_preference'];name=event['robot'];visits=f['initial_search_visits']
node=SimpleNamespace(enable_battery=True,enable_rally=False,now=lambda:event['event_time'],map_data=g['data'],resolution=g['resolution'],origin=g['origin'],
    map_received_at=event['planning_map']['source_time'],source_map_data=maps['source']['data'],map_self_return_cells=event['self_return_cells'],
    robot_positions=event['robot_positions'],battery_states=states,battery_modes={n:s['mode'] for n,s in states.items()},
    robot_maps={n:maps[n] for n in event['return_maps']},robot_map_received_at={n:s['source_time'] for n,s in event['return_maps'].items()},
    robot_odom_received_at={n:event['inputs'][n+'/pose_state']['source_time'] for n in f['eligible_robot_names']},
    robot_tf_received_at={n:event['inputs'][n+'/frame_state']['source_time'] for n in f['eligible_robot_names']})
mask=c.traversable_grid(g['data'],g['resolution'],c.PATH_CLEARANCE_M)
fields={n:c.exploration_distance_field(g['data'],mask,g['resolution'],g['origin'],event['robot_positions'][n]) for n in f['eligible_robot_names']}
blocked=[p for n,p in event['robot_positions'].items() if n!=name and p is not None]
actual=c.exploration_distance_field(g['data'],c.block_dynamic_positions(mask,g['resolution'],g['origin'],blocked),g['resolution'],g['origin'],event['current_position'])
rows=[];routes={}
for utility,n,group,a in c.known_space_search_candidates(g['data'],g['resolution'],g['origin'],name,event['current_position'],
        [*[v['position'] for v in visits],*[p for p in event['robot_positions'].values() if p is not None]],f['excluded_targets'],blocked,face_interest=True):
    cell=c.world_to_grid(a.x,a.y,g['resolution'],*g['origin']);distance=float(actual[cell])
    if not math.isfinite(distance):continue
    cost=c.HeadquartersControl.exploration_required_energy(node,name,distance,(a.x,a.y))
    plan=c.plan_rally_leg(c.RallyPose(a.x,a.y,a.navigation_yaw),g['data'],g['resolution'],g['origin'],event['current_position'],
        c.MAX_NAVIGATION_LEG_M,blocked_positions=blocked,clearance_m=c.PATH_CLEARANCE_M,visible_only=True,route_cache=routes)
    if cost is None or cost>=states[name]['energy'] or plan is None:continue
    preference=c.HeadquartersControl.frontier_travel_preference(node,name,a,fields)
    resume=c.interrupted_frontier_is_useful(a,f.get('resume_intent'),1.)
    score=c.frontier_scheduling_score(utility*preference['factor'],resume)
    d=c.mission_search_diversity((a.x,a.y),states,visits);index=d['target_sector']
    linear=1. if index is None else max(.25,1./(1.+d['sector_counts'][index]))
    rows.append(dict(target=[a.x,a.y],gain=a.viewpoint.information_gain,required_energy=cost,planned_distance_m=distance,
        original_score=score,sqrt_score=score*d['factor'],linear_score=score*linear,
        sqrt_factor=d['factor'],linear_factor=linear,sector=index,sector_counts=d['sector_counts']))
assert rows
out=dict(status='PASS',scope='Actual complete visual-visit snapshot, current delivered grids/models/exclusions/body paths; missing original in-flight route reservations. Conditional ranking, no original-task counterfactual.',
    event_time=event['event_time'],current_position=event['current_position'],current_energy=states[name]['energy'],original_selected=f['target'],
    visits=len(visits),funded_body_route_candidates=len(rows),top={k:sorted(rows,key=lambda row:-row[k])[:3] for k in ('original_score','sqrt_score','linear_score')})
Path('log/p2c_v23_spatial_diversity_diagnostic.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
