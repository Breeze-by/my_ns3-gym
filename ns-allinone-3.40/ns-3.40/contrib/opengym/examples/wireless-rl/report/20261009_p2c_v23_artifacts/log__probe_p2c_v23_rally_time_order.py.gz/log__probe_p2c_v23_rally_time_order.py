import ast,base64,hashlib,inspect,json,math,time,zlib
from dataclasses import asdict
from pathlib import Path
import numpy as np
from multi_robot_exploration import control as c

path=Path('log/p2c/20261009_p2c_v23/20261009_p2c_v23_dev_forced2/ledger.jsonl')
event=next(e for line in path.open() if (e:=json.loads(line)).get('event')=='coordinator_rally_assignment_chosen')
fixture=Path('log/p2c_v23_rally_assignment_input.json');assert not fixture.exists();fixture.write_text(json.dumps(event,indent=2)+'\n')
def decode(s):return dict(data=np.frombuffer(zlib.decompress(base64.b64decode(s['grid'])),dtype='<i2').reshape(s['shape']),resolution=s['resolution'],origin=s['origin'])
g=decode(event['planning_map']);local={name:decode(s) for name,s in event['return_maps'].items()}
source=inspect.getsource(c.assign_rally_poses)
old='score = (observer_charge, len(needed), exposure_bound, time_bound, -observer_headroom, *score)'
new='score = (observer_charge, len(needed), time_bound, exposure_bound, -observer_headroom, *score)'
leaf='score = (*score[:3], score[3] + parked_peer_delay(needed), *score[4:])'
assert source.count(old)==source.count(leaf)==1
proposed=source.replace(old,new).replace(leaf,'score = (*score[:2], score[2] + parked_peer_delay(needed), *score[3:])')
scope=dict(vars(c));exec(compile(ast.parse(proposed),'<read-only proposed time-first score>','exec'),scope)
args=dict(raw_grid=g['data'],resolution=g['resolution'],origin=g['origin'],robot_positions=event['robot_positions'],
    target=event['target'],objective=event['objective'],battery_states=event['battery_states'],
    observer_robot=event['observer_robot'],current_positions=event['current_positions'],hold_sec=event['hold_sec'],return_maps=local)
rows={}
mask=c.traversable_grid(g['data'],g['resolution'],c.PATH_CLEARANCE_M)
fields={name:c.exploration_distance_field(g['data'],mask,g['resolution'],g['origin'],position) for name,position in event['robot_positions'].items()}
for name,fn in (('original_exposure_first',c.assign_rally_poses),('proposed_time_first',scope['assign_rally_poses'])):
    start=time.perf_counter();answer=fn(**args);wall=time.perf_counter()-start
    assert set(answer)==set(event['robot_positions'])
    distances={robot:float(fields[robot][c.world_to_grid(pose.x,pose.y,g['resolution'],*g['origin'])]) for robot,pose in answer.items()}
    rows[name]=dict(assignment={robot:asdict(pose) for robot,pose in answer.items()},
        nominal_approach_distance_m=distances,nominal_serial_approach_sec=sum(distance/event['battery_states'][robot]['nominal_speed_mps'] for robot,distance in distances.items()),
        largest_nominal_approach_m=max(distances.values()),wall_sec=wall)
for robot,pose in rows['original_exposure_first']['assignment'].items():
    assert np.allclose([pose[k] for k in ('x','y','yaw')],event['assignment'][robot],rtol=0,atol=1e-8)
out=dict(status='PASS',scope='Exact saved AP assignment inputs; conditional nominal selection, no counterfactual mission time/safety guarantee',
    original_event_time=event['event_time'],task_commit='930d7a041b361a731883c469ed51d553710a97fc',input_sha256=hashlib.sha256(fixture.read_bytes()).hexdigest(),
    original_source_sha256=hashlib.sha256(Path(c.__file__).read_bytes()).hexdigest(),cases=rows)
Path('log/p2c_v23_rally_time_order_diagnostic.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
