import json,subprocess
from pathlib import Path
from datetime import datetime,timezone
root=Path('/home/zhuyulab/ns3-workspace')
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
head=git('rev-parse','HEAD');upstream=git('rev-parse','@{u}')
assert head==upstream,(head,upstream)
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
status=git('status','--short','--untracked-files=all').splitlines()
assert len(status)==14 and all(row.startswith(('?? 260929_report/','?? "260929_report/')) for row in status),status
assert not (root/'ros2_ws/ros2-multi-robot-automap/log/p2c/20261009_p2c_v23').exists()
result=dict(status='PASS',head=head,upstream=upstream,worktree_status=status,checked_at_utc=datetime.now(timezone.utc).isoformat())
Path('log/p2c_v23_freeze_check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status='PASS',head=head,user_untracked_files=14)))
