import base64,cProfile,hashlib,json,pstats,time,zlib
from pathlib import Path
import numpy as np
import importlib.util,sys
spec=importlib.util.spec_from_file_location('multi_robot_exploration.p2c_v35_ring_prototype_control', 'log/p2c_v35_ring_prototype_control.py')
control=importlib.util.module_from_spec(spec);sys.modules[spec.name]=control;spec.loader.exec_module(control)

results={}
for case in ('dev_lab101','dev_corridors303'):
    p=Path('log/p2c_v34_'+case+'_rally_snapshot.json');e=json.loads(p.read_text());geometry={}
    for key,s in [('planning',e['planning_map']),*e['return_maps'].items()]:
        geometry[key]=dict(data=np.frombuffer(zlib.decompress(base64.b64decode(s['grid'])),dtype='<i2').reshape(s['shape']),
            resolution=s['resolution'],origin=s['origin'])
    grid=geometry.pop('planning')
    def compute():
        return control.assign_rally_poses(grid['data'],grid['resolution'],grid['origin'],e['robot_positions'],e['target'],
            objective=e['objective'],battery_states=e['battery_states'],observer_robot=e['observer_robot'],
            current_positions=e['current_positions'],hold_sec=e['hold_sec'],return_maps=geometry)
    begin=time.perf_counter();result=compute();wall=time.perf_counter()-begin
    actual={n:[v.x,v.y,v.yaw] for n,v in result.items()}
    assert set(actual)==set(e['assignment'])
    poses=control.rally_pose_candidates(grid['data'],grid['resolution'],grid['origin'],e['target'])
    assert all(any(np.allclose(actual[n], [p.x,p.y,p.yaw],atol=1e-8,rtol=0) for p in poses) for n in actual)
    assert all(np.linalg.norm(np.asarray(actual[a][:2])-np.asarray(actual[b][:2])) >= control.RALLY_MIN_SEPARATION_M for i,a in enumerate(actual) for b in list(actual)[i+1:])
    profile=cProfile.Profile();profile.runcall(compute)
    with Path('log/p2c_v35_'+case+'_ring_prototype_profile.txt').open('w') as f:
        pstats.Stats(profile,stream=f).strip_dirs().sort_stats('cumulative').print_stats(40)
    results[case]=dict(original_wall_sec=e['computation_wall_sec'],original_sim_sec=e['computation_completed_at_sec']-e['event_time'],
        read_only_wall_sec=wall,coarse_full_assignment=True,coarse_candidate_count=len(poses),assignment=actual,original_assignment=e['assignment'],source_snapshot_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
Path('log/p2c_v35_ring_prototype_profile.json').write_text(json.dumps(dict(scope='Read-only unchanged original assignment input; no task/history replay or clock bound',results=results),indent=2)+'\n')
print(json.dumps(results))
