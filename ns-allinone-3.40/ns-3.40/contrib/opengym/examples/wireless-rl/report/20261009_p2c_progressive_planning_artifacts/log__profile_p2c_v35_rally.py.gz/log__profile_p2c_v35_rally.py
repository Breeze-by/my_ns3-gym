import base64,cProfile,hashlib,json,pstats,time,zlib
from pathlib import Path
import numpy as np
from multi_robot_exploration import control

results={}
for case in ('dev_lab101','dev_corridors303'):
    p=Path('log/p2c_v34_'+case+'_rally_snapshot.json');e=json.loads(p.read_text());geometry={}
    for key,s in [('planning',e['planning_map']),*e['return_maps'].items()]:
        geometry[key]=dict(data=np.frombuffer(zlib.decompress(base64.b64decode(s['grid'])),dtype='<i2').reshape(s['shape']),
            resolution=s['resolution'],origin=s['origin'])
    grid=geometry.pop('planning')
    def compute():
        return control.assign_rally_poses(grid['data'],grid['resolution'],grid['origin'],e['robot_positions'],e['target'],
            objective=e['objective'],battery_states=e['battery_states'],observer_robot=e['observer_robot'],
            current_positions=e['current_positions'],hold_sec=e['hold_sec'],return_maps=geometry)
    begin=time.perf_counter();result=compute();wall=time.perf_counter()-begin
    actual={n:[v.x,v.y,v.yaw] for n,v in result.items()}
    assert all(np.allclose(actual[n],e['assignment'][n],atol=1e-8,rtol=0) for n in actual) and set(actual)==set(e['assignment'])
    profile=cProfile.Profile();profile.runcall(compute)
    with Path('log/p2c_v35_'+case+'_rally_profile.txt').open('w') as f:
        pstats.Stats(profile,stream=f).strip_dirs().sort_stats('cumulative').print_stats(40)
    results[case]=dict(original_wall_sec=e['computation_wall_sec'],original_sim_sec=e['computation_completed_at_sec']-e['event_time'],
        read_only_wall_sec=wall,choices_equal=True,source_snapshot_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
Path('log/p2c_v35_rally_profile.json').write_text(json.dumps(dict(scope='Read-only unchanged original assignment input; no task/history replay or clock bound',results=results),indent=2)+'\n')
print(json.dumps(results))
