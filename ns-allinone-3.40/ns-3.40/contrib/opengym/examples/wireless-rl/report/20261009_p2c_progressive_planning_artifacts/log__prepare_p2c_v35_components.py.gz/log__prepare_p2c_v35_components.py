import gzip,hashlib,json,re,subprocess
from pathlib import Path

root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
parent='08fe5f770f92fa2189b7c7d725491a56ec00ca2a'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py'
comparison=load(r/'log/p2c_v35_final_comparisons.json')
assert comparison['status']=='PASS' and comparison['control_sha256']==sha(control)
source=load(r/'log/p2c_v35_source.json');assert source['status']=='PASS'
full=re.search(r'(\d+) passed in ([\d.]+)s',(r/'log/p2c_v35_full_components.log').read_text());assert full and int(full[1])==1348
build=re.search(r'4 packages finished \[([\d.]+)s\]',(r/'log/p2c_v35_build.log').read_text());assert build
runtime={k:load(r/'log'/n) for k,n in [
 ('clock','p2c_v35_clock_runtime.json'),('native_future','p2c_v35_native_future_runtime.json'),
 ('visual','p2c_v35_visual_runtime.json'),('lazy_mapping_dds','p2c_v35_lazy_gain_dds.json'),
 ('lazy_visual_dds','p2c_v35_lazy_visual_dds.json'),('progressive_rally_dds','p2c_v35_rally_dds.json')]}
assert all(v['status']=='PASS' for v in runtime.values())
for k,v in runtime.items():
 if k!='native_future':assert v['control_sha256']==sha(control)
original=load(r/'log/p2c_v34_independent_audits.json');reaudit=load(r/'log/p2c_v35_previous_original_audits.json')
assert original==reaudit and all(len(rows)==12 and all(v['status']=='PASS' for v in rows.values()) for rows in reaudit.values())
for saved,name in [('p2c_v35_manifest.json','p2c_integration_manifest.json'),('p2c_v35_blackout_manifest.json','p2c_blackout_manifest.json')]:
 current=load(r/'scripts'/name);assert load(r/'log'/saved)['config']==current
 old=json.loads(subprocess.check_output(['git','show',parent+':'+str((r/'scripts'/name).relative_to(root))],cwd=root))
 for key in ('cases','duration_sec','coverage_threshold','fault_seed','owner_shutdown_timeout_sec'):assert old[key]==current[key],key
unchanged={}
for rel in ('src/multi_robot_exploration/multi_robot_exploration/battery_manager.py','src/multi_robot_exploration/multi_robot_exploration/action_callbacks.py','src/multi_robot_exploration/multi_robot_exploration/tf_ingress_sampler.py','src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py','scripts/observer_lifetime.py','scripts/observe_p3b5.py','scripts/p2c_native_graph.py','scripts/check_p2c_gate.py','scripts/ros_smoke_test.py','scripts/check_p2c_visual_runtime.py'):
 p=r/rel;assert subprocess.check_output(['git','show',parent+':'+str(p.relative_to(root))],cwd=root)==p.read_bytes();unchanged[rel]=sha(p)
files=[p for p in (r/'log').glob('*p2c_v35*') if p.is_file() and p.suffix!='.pyc']
files += [r/'src/multi_robot_exploration/test/fixtures/p2c_v34_return_route_reference.json']
destination=report/'20261009_p2c_progressive_planning_artifacts';assert not destination.exists();destination.mkdir();artifacts=[]
for p in sorted(set(files)):
 q=destination/('__'.join(p.relative_to(r).parts)+'.gz');q.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0))
 assert gzip.decompress(q.read_bytes())==p.read_bytes()
 artifacts.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(q.relative_to(report)),archive_sha256=sha(q)))
limits='Fixed delivered inputs/epochs and conditional owners only. Progressive first-feasible rings do not preserve the global464 soft-cost optimum. No original full-history replay, actual callback/clock bound, CPU worst case, task causal effect, hidden AP state or Wi-Fi bottleneck claim.'
errors=[
 'First component report preparation had an unterminated prose string SyntaxError before any files changed; corrected preparation and initial script/trace retained.',
 'Initial suffix prototype relative import failed before computation; corrected module package; traceback retained.',
 'First full component run1344PASS/1FAIL: child disappeared while test-only /proc reader raised ProcessLookupError. Reader now treats only FileNotFoundError/ProcessLookupError as vanished, PermissionError remains visible; production lifetime binding unchanged.',
 'First visual DDS synthetic goal sink labelled visual choice as ordinary exploration, so independent correct reader rejected its gain. Corrected sink to the same production kind selection; no production code/reader weakened; initial script/log retained.',
 'An initial failure archive preparation had nested quote SyntaxError and missing-script exit2; corrected preparation did not start or retry tasks.'
]
output=dict(status='PASS',scope='Prospective P2C.1 progressive planning components, no mission acceptance',parent_commit=parent,
 control_sha256=sha(control),functional_checks=int(full[1]),functional_wall_sec=float(full[2]),build_wall_sec=float(build[1]),
 source_audit=source,actual_ros=runtime,fixed_source_comparison=comparison,previous_original_reaudit=reaudit,
 unchanged_from_parent=unchanged,preparation_errors=errors,unrun=['new4 development','new17 formal','new2 physical','917'],
 limits=limits,artifacts=artifacts)
(report/'20261009_p2c_progressive_planning_components.json').write_text(json.dumps(output,indent=2)+'\n')
medians={name:{k:v['median_wall_sec'] for k,v in row['timing'].items()} for name,row in comparison['comparisons'].items()}
text='''# P2C.1 v35 分层集合与惰性视觉规划组件 PASS

v34冻结08fe5f7的四个原开发任务整体FAIL：forced269.7秒COMPLETE且每机charge1；lab77.5秒、corridors82.4秒已检测，却FOUND timeout300.1/300.4且RALLY未进入；rooms EXPLORE timeout300.3、仅一个Nav2。四格0接触/耗尽/failed/infra/retries，48独立子门PASS，不能替代原生成功。全部owner/observer退出0、关闭后才修改。17正式/2物理/917从未调用；旧原格不重跑或回填，完整原始证据见20261009_p2c_v34_failed_development.md/.json。

先实测等价后缀原型，原完整464名义选位保持，但corridors静态输入仍约4.1秒；于是显式改变候选策略：先使用原72个三圈样本，找不到完整可行分配才扩展到原0.4米bin angular代表、最多464。每层仍执行原known-free/LOS/.45米endpoint/.8米分离，以及完整contact return、observer保护、charge/wait/cap预算、soft exposure/parked-body评分。第一层有解即停止，所以放弃跨全部464的软成本最优性；没有宣称穷尽联合可行或最坏时限。后续实际每条导航仍原body/route/TTL/完整预算检查。测试专门覆盖粗层分离无解、粗层完整返航能量不可行、双层无解和粗层有解但细层软成本更好时的明确取舍。

共享reverse predecessor树的公共返航后缀只保存原逐点路径，不简化；field已有内容/shape/resolution/origin/home/radius校验，变更会清缓存。缓存最多2048节点、每个共享tuple最多2048原顶点，包括长迷宫约束；contact-connected mask仅同field复用。不缓存source/header/能量或可行决策。冻结v34原known_return_route源码以SHA夹具独立重算八随机图共768起点，精确距离、每个顶点与不可行结果相同；可变alias/content/home变化、长路径与邻起点后缀命中减少重复生成通过。连续局部占用veto及物理安全代码没有修改。

已知空间/视觉候选先用同一当前interest矩形数量作私有SearchGainBound；竞争时计算原360射线/16yaw准确gain/yaw，再回到原稳定budget heap。输出恢复普通Viewpoint/Assignment，任何预算、Nav2或充电forecast都不使用上界。候选池须先证明至少一个准确positive gain；全零仍返回原空池并走原mapping fallback。八随机种子×两类interest验证全部候选、准确朝向与排序等价，实际保留晚期14heading/5visit条件输入保持原派发、偏好和预算；同一admission/充电context使用同一地图/历史缓存，不能续租或跨源。

过期proposal已不可逆弃置后，既有private consumed audit每phase/stage最多每30sim秒保存冻结callback的交付图、source stamps、机器人状态与访问/朝向历史，补足rooms弃置现场。该数据只供只读诊断，不进入规划/通信准入/本地安全，没有增加应用网络packet或延长TTL。测试对有/无rally状态、map解码、原时间戳、限频和零派发/owner保持通过；同步审计仍有有限计算开销，不能当实时界。

''' 
text += '| 固定输入条件 | v34中位wall秒 | v35中位wall秒 | 关系 |\n|---|---|---|---|\n'
for name,row in medians.items():
 relation='派发/朝向/偏好/预算逐项相同' if name in ('early2','rooms3','late_visual') else '与冻结旧优化器限制到同三圈候选的完整解相同，跨464选择改变'
 text+=f"| {name} | {row['frozen_v34']:.5f} | {row['candidate_v35']:.5f} | {relation} |\n"
text+='\n普通early2几乎持平，rooms首图略慢，尚不能证明后续停滞原因；不把所有条件写成提速。映射/视觉五cold、集合三cold，固定真实保存图/epoch与条件owner，不是原history或真实时钟界。集合lab/corr从约1.63/4.83降到.78/1.32秒的组件样本，仍必须在新完整原任务验证。\n\n'
text+=f"1348功能检查PASS{float(full[2]):.2f}秒，四包build{float(build[1]):.2f}秒，171保护/4授权/54静态协议/8中央+2native Future注册PASS；实际隔离ROS domains220 clock、221 native Future、215原视场、214两个普通mapping Assignment、216一个准确visual Assignment、217两组三机分层集合publisher/独立consumer PASS，全部绑定本source SHA。后四类使用保存的固定交付输入/合成goal sink，没有真实Nav2/Gazebo运动或时钟界。初visual sink错误kind触发正确独立reader FAIL，修正为生产同标签后PASS；原脚本/trace保留，reader与task代码没为此改动。首全功能1344PASS/1FAIL仅测试读取消失/proc ESRCH，修正两个明确不存在异常并验证权限错误仍可见；生产observer_lifetime未改，六定向和完整全量PASS。\n\n"
text+='''旧四原任务48子门结果和细节逐项保持：old rally_assignment由其08fe冻结源码重建，其余reader/native geometry使用当前等价助手重审；不是把旧完整464记录套到新分层策略。Native battery/Future dispatcher/TF sampler/launch/observer/strict gate/视觉reader byte保持；类仅__init__添加限频状态、assign_idle_robots与既有forecast解析改变，三pure函数修改、三private定义增加。原300秒/.35米/.05mps/.1radps/5秒保持与2/5/60秒TTL/SLAM/Nav2/physics、全部case和真实断网刺激保持。

P2C.1未完成。下一新clean pushed freeze仍先forced2原生COMPLETE、每机charge≥1，再其余三个开发；全四通过才进入17正式+2物理，917最后首次暴露。P3C.5已验收；无P4/ns-3/Wi-Fi/RL。\n'''
(report/'20261009_p2c_progressive_planning_components.md').write_text(text)
note=f'2026-10-09 P2C.1 v35分层集合/惰性视觉组件PASS待新原任务：v34 08fe5f7四原dev整体FAIL(仅forced269.7 COMPLETE/每机charge1，lab/corr FOUNDtimeout300.1/300.4，rooms EXPLOREtimeout300.3)，0安全/infra/retry、48独立子门PASS且全部owned关闭；原件保留。新三圈完整可行则停止/无解才原angular扩展，明确放弃跨464软最优；精确原返航后缀bounded2048/逐点路径与原TTL预算，视觉interest上界准确16yaw解析后才价格/派发，过期现场30s限频只读保存。1348功能/四包{float(build[1]):.2f}s/171保护54协议/六实际ROS PASS。静态late视觉约.329→.250、集合lab1.626→.781/corr4.833→1.318wall秒；early持平/rooms首图略慢，非真实时界或任务因果。新4→17+2同clean pushed freeze未验证，917未暴露；P3C.5已验收，无P4/ns3/Wi-Fi/RL。报告20261009_p2c_progressive_planning_components.md与20261009_p2c_v34_failed_development.md。'
for p in (w/'AGENTS.md',w/'RESEARCH_PLAN.md',w/'IMPLEMENTATION_PLAN.md',r/'user_guide.md',r/'launch_commands.md'):
 first,rest=p.read_text().split('\n',1);p.write_text(first+'\n\n'+note+'\n'+rest)
p=root/'AGENTS.md';p.write_text(p.read_text().replace('## Current Handoff\n','## Current Handoff\n\n'+note+'\n',1))
with (w/'log.md').open('a') as f:
 f.write('\n\n## 2026-10-09 P2C.1 v35 分层集合/惰性视觉组件\n\n'+note+'\n\n')
 f.write('Prospective parent08fe5f7；profile_p2c_v35_suffix.py公共后缀旧选择相同但corr4.091s；profile_p2c_v35_ring.py新三圈完整有解约lab.837/corr1.370s、软选择改变；明确声明渐进层次折中。profile_p2c_v35_rooms.py首真实图conditional all-idle~.177→.171s无明显改善；profile_p2c_v35_visual.py同图合成heading条件~.267→.282s更慢；晚期真实14heading/5visit用profile_p2c_v35_late_visual.py固定条件~.308→.254s且选择/偏好/预算同。最终compare_p2c_v35_components.py独立编译08fe：early2 .222→.220、rooms3 .175→.190、late .329→.250、lab1.626→.781、corr4.833→1.318wall中位，mapping/visual五cold/集合三cold；集合等于旧优化器限制同三圈候选，不是全464等价。所有脚本/CPU失败原型保留，无其任务。\n\n')
 f.write('Humble+install/PYTHONNOUSERSITE1/FastDDS UDPv4清profiles；pytest新suffix/progressive/search+liveclock/exposure50PASS4.86s，diagnostic/search/frontier35PASS4.45s；完整pytest src/multi_robot_exploration/test scripts --ignore copyright/flake8/pep257 首1344PASS1FAIL69.31s(/proc process vanished ESRCH)，只改test_observer_lifetime.running明确异常并加权限失败仍可见，6定向PASS后完整1348PASS70.86s。colcon build四包5.20s；check_p2c_source.py --output log/p2c_v35_source.json171/4/54/8+2 PASS；dev_forced2/run-id20261009_p2c_v35/domain210/port20290与physical_fault/p2c_blackout_manifest/run-id20261009_p2c_v35_physical/domain219/port20299 --validate-only PASS，无任务。\n\n')
 f.write('实际ROS隔离domain220 clock_runtime、221 native_future、215 visual_runtime、214 log/check_p2c_v35_lazy_gain_dds.py两个普通Assignment、216 log/check_p2c_v35_lazy_visual_dds.py一个visual普通Assignment、217 log/check_p2c_v35_rally_dds.py两组三机完整分层选择皆PASS；以taskset0-79 /usr/bin/python3运行，输出对应log/p2c_v35_*_runtime.log/json。首次visual synthetic sink错误把visual记为exploration，正确consumer拒绝gain；保留初脚本/trace，仅修夹具为生产同kind后PASS，未改reader/生产/物理标准。真实DDS但固定输入/合成goal sink，无Nav2/Gazebo运动或clock时界。audit_p2c_v35_previous_originals.py旧48子门细节相同，原rally bind08fe源码/其他新等价助手；原四严格FAIL不改变。新4/17/2/917未启动，先本次commit/push0+clean freeze再首强制；原300s/5s保持/native/TTL/physics/cases/physical刺激不改，domain222/master11345未操作。\n')
print(json.dumps(dict(status='PASS',archives=len(artifacts),functional_checks=int(full[1]),control_sha256=sha(control),medians=medians)))
