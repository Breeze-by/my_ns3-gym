import ast,base64,cProfile,dataclasses,hashlib,json,pstats,statistics,subprocess,sys,time,types,zlib
from pathlib import Path
import numpy as np
import test_exploration_resume as fixtures
from multi_robot_exploration import control

root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
path=r/'src/multi_robot_exploration/multi_robot_exploration/control.py'
parent='08fe5f770f92fa2189b7c7d725491a56ec00ca2a'
source=subprocess.check_output(['git','show',parent+':'+str(path.relative_to(root))],cwd=root,text=True)
old=types.ModuleType('multi_robot_exploration.p2c_v34_reference');old.__package__='multi_robot_exploration';sys.modules[old.__name__]=old
exec(compile(source,'<08fe5f7 frozen control>','exec'),old.__dict__)
def serial(value):
 return json.loads(json.dumps(value,default=lambda x:dataclasses.asdict(x) if dataclasses.is_dataclass(x) else x.tolist()))

def conditional(module,e,visual):
 fixtures.control=module;node,sent=fixtures.conditional_snapshot_node(e,{})
 node.input_robot_names=lambda:e['travel_preference']['eligible_robot_names'];node.robot_maps.setdefault('tb1',None)
 node.robot_states={name:'idle' for name in node.battery_states};node.enable_rally=True
 node.initial_search_next={e['robot']:True} if visual else {};node.rally_charge_requested={'tb1':e['event_time']} if visual else {}
 node.initial_search_visits={i:v for i,v in enumerate(e['travel_preference'].get('initial_search_visits',[]))}
 node.initial_search_views={i:v for i,v in enumerate(e['travel_preference'].get('initial_search_views',[]))}
 node.successful_exploration_legs={e['robot']:1};node.target_search_visits=[]
 node.exploration_travel_choices={};node.frontier_charge_lookahead=None
 counters=dict(budget=0,ray=0);original_budget=node.exploration_battery_factor;original_ray=module.visible_unknown_gain
 def budget(*a,**kw):counters['budget']+=1;return original_budget(*a,**kw)
 def ray(*a,**kw):counters['ray']+=1;return original_ray(*a,**kw)
 node.exploration_battery_factor=budget;module.visible_unknown_gain=ray
 try:module.HeadquartersControl.assign_idle_robots(node)
 finally:module.visible_unknown_gain=original_ray
 return serial(dict(sent=sent,choices=node.exploration_travel_choices,budget_times=node.exploration_budget_times)),counters

output={}
for name,file,visual in [('early2','p2c_v33_two_robot_computation.json',False),
                        ('rooms3','p2c_v34_rooms_first_decision.json',False),
                        ('late_visual','p2c_v31_actual_planning_snapshot.json',True)]:
 e=json.loads((r/'log'/file).read_text())['event'];expected=None;timings={}
 for label,module in [('frozen_v34',old),('candidate_v35',control)]:
  samples=[]
  for _ in range(5):
   module.visibility_ray_projections.cache_clear();module.known_search_sector_table.cache_clear()
   start=time.perf_counter();result,counters=conditional(module,e,visual);samples.append(time.perf_counter()-start)
   if expected is None:expected=result
   assert result==expected,(name,label,'assignment/heading/preference/budget changed')
  timings[label]=dict(cold_wall_sec=samples,median_wall_sec=statistics.median(samples),counts=counters)
  profile=cProfile.Profile();profile.runcall(conditional,module,e,visual)
  with (r/f'log/p2c_v35_final_{name}_{label}_profile.txt').open('w') as f:pstats.Stats(profile,stream=f).strip_dirs().sort_stats('cumulative').print_stats(30)
 output[name]=dict(equal=True,input_sha256=hashlib.sha256((r/'log'/file).read_bytes()).hexdigest(),timing=timings)
fixtures.control=control
for case in ('dev_lab101','dev_corridors303'):
 p=r/'log'/('p2c_v34_'+case+'_rally_snapshot.json');e=json.loads(p.read_text());maps={}
 for key,s in [('planning',e['planning_map']),*e['return_maps'].items()]:
  maps[key]=dict(data=np.frombuffer(zlib.decompress(base64.b64decode(s['grid'])),dtype='<i2').reshape(s['shape']),resolution=s['resolution'],origin=s['origin'])
 grid=maps.pop('planning')
 def solve(module):
  return module.assign_rally_poses(grid['data'],grid['resolution'],grid['origin'],e['robot_positions'],e['target'],
   objective=e['objective'],battery_states=e['battery_states'],observer_robot=e['observer_robot'],
   current_positions=e['current_positions'],hold_sec=e['hold_sec'],return_maps=maps)
 timings={}
 for label,module in [('frozen_v34',old),('candidate_v35',control)]:
  samples=[];chosen=None
  for _ in range(3):
   start=time.perf_counter();result=solve(module);samples.append(time.perf_counter()-start)
   actual={n:[p.x,p.y,p.yaw] for n,p in result.items()}
   if chosen is None:chosen=actual
   assert actual==chosen and set(actual)==set(e['assignment'])
  timings[label]=dict(cold_wall_sec=samples,median_wall_sec=statistics.median(samples),assignment=chosen)
 assert all(np.allclose(timings['frozen_v34']['assignment'][n],e['assignment'][n],atol=1e-8,rtol=0) for n in e['assignment'])
 original_candidates=old.rally_pose_candidates
 old.rally_pose_candidates=lambda raw,res,origin,target,dense,stratified:original_candidates(raw,res,origin,target,False,False)
 try:restricted={n:[p.x,p.y,p.yaw] for n,p in solve(old).items()}
 finally:old.rally_pose_candidates=original_candidates
 assert restricted==timings['candidate_v35']['assignment']
 output[case]=dict(scope='Progressive coarse solution equals independently frozen optimizer on identical old-ring subset; whole464 soft optimum is deliberately not preserved',
  coarse_reference_equal=True,input_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),timing=timings)

def definitions(s):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=definitions(source),definitions(path.read_text());changed=[n for n in a if a[n]!=b[n]];added=[n for n in b if n not in a]
assert changed==['known_space_search_candidates','known_return_route','assign_rally_poses','HeadquartersControl'],changed
assert added==['SearchGainBound','resolve_search_gain','_assign_rally_poses'],added
classes=[next(n for n in ast.parse(s).body if isinstance(n,ast.ClassDef) and n.name=='HeadquartersControl') for s in (source,path.read_text())]
methods=[{n.name:ast.dump(n,include_attributes=False) for n in cls.body if isinstance(n,ast.FunctionDef)} for cls in classes]
changed_methods=[n for n in methods[0] if methods[0][n]!=methods[1][n]]
assert list(methods[0])==list(methods[1]) and changed_methods==['__init__','frontier_lookahead_budget','assign_idle_robots'],changed_methods
result=dict(status='PASS',scope='Retained delivered inputs, fixed epochs and conditional owners only; no original full-history replay, actual clock/callback bound or causal mission effect',
 parent_commit=parent,control_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),comparisons=output,changed_pure=changed[:-1],added=added,changed_methods=changed_methods)
(r/'log/p2c_v35_final_comparisons.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({n:{'equal':v.get('equal',v.get('coarse_reference_equal')),'medians':{k:z['median_wall_sec'] for k,z in v['timing'].items()}} for n,v in output.items()}))
