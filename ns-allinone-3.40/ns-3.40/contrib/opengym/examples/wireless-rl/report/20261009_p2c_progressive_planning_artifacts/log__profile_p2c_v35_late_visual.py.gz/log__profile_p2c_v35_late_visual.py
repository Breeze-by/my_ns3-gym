import ast,cProfile,dataclasses,hashlib,json,pstats,subprocess,sys,time,types
from pathlib import Path
import test_exploration_resume as fixtures
import importlib.util
spec=importlib.util.spec_from_file_location('multi_robot_exploration.p2c_v35_lazy_search_prototype_control', 'log/p2c_v35_lazy_search_prototype_control.py')
control=importlib.util.module_from_spec(spec);sys.modules[spec.name]=control;spec.loader.exec_module(control)

root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
path=r/'src/multi_robot_exploration/multi_robot_exploration/control.py'
source=subprocess.check_output(['git','show','08fe5f770f92fa2189b7c7d725491a56ec00ca2a:'+str(path.relative_to(root))],cwd=root,text=True)
baseline=types.ModuleType('multi_robot_exploration.p2c_v31_lookup_baseline');baseline.__package__='multi_robot_exploration';baseline.__file__=str(path)
sys.modules[baseline.__name__]=baseline;exec(compile(source,str(path),'exec'),baseline.__dict__)
e=json.loads((r/'log/p2c_v31_actual_planning_snapshot.json').read_text())['event']
def serial(value):
    return json.loads(json.dumps(value,default=lambda x:dataclasses.asdict(x) if dataclasses.is_dataclass(x) else x.tolist()))
def conditional(module):
    fixtures.control=module;node,sent=fixtures.conditional_snapshot_node(e,{})
    node.input_robot_names=lambda:e['travel_preference']['eligible_robot_names'];node.robot_maps.setdefault('tb1',None)
    node.robot_states={name:'idle' for name in node.robot_states};node.enable_rally=True
    node.initial_search_next={e['robot']:True};node.rally_charge_requested={'tb1':e['event_time']}
    node.initial_search_visits={i:v for i,v in enumerate(e['travel_preference']['initial_search_visits'])}
    node.initial_search_views={i:v for i,v in enumerate(e['travel_preference']['initial_search_views'])}
    node.successful_exploration_legs={e['robot']:1};node.target_search_visits=[]
    node.exploration_travel_choices={};node.frontier_charge_lookahead=None
    original_budget=node.exploration_battery_factor;count=[0]
    def priced(*args,**kwargs):
        count[0]+=1;return original_budget(*args,**kwargs)
    node.exploration_battery_factor=priced
    module.HeadquartersControl.assign_idle_robots(node)
    budget_calls[(module.__name__)]=count[0]
    return serial(dict(sent=sent,choices=node.exploration_travel_choices,budget_times=node.exploration_budget_times))
outputs={};reference=None;budget_calls={}
for label,module in [('frozen_v34',baseline),('lazy_search_prototype',control)]:
    wall=[]
    for repeat in range(3):
        if label=='lazy_search_prototype':
            control.visibility_ray_projections.cache_clear();control.known_search_sector_table.cache_clear()
        start=time.perf_counter();result=conditional(module);wall.append(time.perf_counter()-start)
        if reference is None:reference=result
        assert result==reference,(label,'assignment/budget evidence changed')
    profile=cProfile.Profile();result=profile.runcall(conditional,module)
    with (r/f'log/p2c_v35_late_visual_{label}_profile.txt').open('w') as f:pstats.Stats(profile,stream=f).strip_dirs().sort_stats('cumulative').print_stats(35)
    outputs[label]=dict(cold_wall_sec=wall,assignment_and_budget_equal=True,budget_calls=budget_calls[module.__name__])
fixtures.control=control
output=dict(status='PASS',scope='Saved actual late visual input; fixed-time conditional node, no actual dispatch or full history replay',timing=outputs)
(r/'log/p2c_v35_late_visual_comparison.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output))
