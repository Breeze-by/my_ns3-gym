import subprocess,sys,types
import check_p2c_gate as gate
root='/home/zhuyulab/ns3-workspace'
source=subprocess.check_output(['git','show','08fe5f770f92fa2189b7c7d725491a56ec00ca2a:ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/multi_robot_exploration/control.py'],cwd=root,text=True)
frozen=types.ModuleType('multi_robot_exploration.p2c_v34_frozen');frozen.__package__='multi_robot_exploration';sys.modules[frozen.__name__]=frozen
exec(compile(source,'<08fe5f7 frozen control>','exec'),frozen.__dict__)
# Old assignments are reconstructed by their original frozen algorithm.
# All unchanged reader/native geometry checks use the new prospective helpers.
gate.control.assign_rally_poses=frozen.assign_rally_poses
import json,traceback
from pathlib import Path
from check_p2c_gate import (return_audit,energy_audit,lookahead_audit,ap_return_veto_audit,
    rally_assignment_audit,rally_repair_audit,exploration_travel_audit,target_survey_audit,
    observer_heading_audit,planning_lease_audit,launch_process_audit)
from p2c_native_graph import native_tf_ingress_audit
base=Path('log/p2c/20261009_p2c_v34');outputs={}
for p in sorted(base.glob('*/summary.json')):
    row=json.loads(p.read_text());d=p.parent;records=[json.loads(line) for line in (d/'ledger.jsonl').open()]
    calls={'native_return':lambda:return_audit(d/'safety_events.jsonl',True,True),
        'native_energy':lambda:energy_audit(d/'safety_events.jsonl',row['result'],True),
        'lookahead':lambda:lookahead_audit(records,True,True),'ap_return_veto':lambda:ap_return_veto_audit(records),
        'rally_assignment':lambda:rally_assignment_audit(records),'rally_repair':lambda:rally_repair_audit(records),
        'exploration_travel':lambda:exploration_travel_audit(records,True,True,True,True,True,True,True),
        'target_survey':lambda:target_survey_audit(records,True,3.,.35,True),
        'observer_heading':lambda:observer_heading_audit(records,True,3.,.35),
        'planning_leases':lambda:planning_lease_audit(records),
        'launch_processes':lambda:launch_process_audit(d),
        'native_tf_graph':lambda:native_tf_ingress_audit(json.loads((d/'native_graph.json').read_text()),row['result']['robot_count'],True)}
    out={}
    for name,call in calls.items():
        try:out[name]=call()
        except Exception as error:out[name]=dict(status='FAIL',error=repr(error),traceback=traceback.format_exc())
    outputs[row['case']]=out
Path('log/p2c_v35_previous_original_audits.json').write_text(json.dumps(outputs,indent=2)+'\n')
print(json.dumps({c:{n:{k:v for k,v in e.items() if k not in ('returns','robots','computation_wall_sec','post_task_cleanup_exits')} for n,e in out.items()} for c,out in outputs.items()}))

assert all(v['status']=='PASS' for out in outputs.values() for v in out.values())
original=json.loads(Path('log/p2c_v34_independent_audits.json').read_text())
assert outputs==original, [(c,n) for c,rows in outputs.items() for n,v in rows.items() if v!=original[c][n]]
print('PASS: all48 original judgments/details retained; frozen original assignment code bound')
