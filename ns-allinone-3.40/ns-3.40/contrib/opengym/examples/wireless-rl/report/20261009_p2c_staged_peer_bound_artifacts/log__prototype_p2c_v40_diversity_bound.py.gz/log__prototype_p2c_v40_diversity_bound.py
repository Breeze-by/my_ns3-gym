import ast,dataclasses,hashlib,inspect,json,statistics,textwrap,time
from pathlib import Path
from types import SimpleNamespace
import test_exploration_resume as fixtures
from multi_robot_exploration import control as c
source=textwrap.dedent(inspect.getsource(c.HeadquartersControl.assign_idle_robots))
source=source.replace('        factor_bounds = {}','        diversity_bounds = {}\n        factor_bounds = {}')
needle='            return None if assignment is None else (assignment.utility, robot_name, group_id, assignment)'
replacement='''            if assignment is None:
                return None
            if not search and getattr(self, 'enable_rally', False) and getattr(self, 'enable_battery', False):
                key = (robot_name, assignment.x, assignment.y)
                if key not in diversity_bounds:
                    diversity = mission_search_diversity((assignment.x, assignment.y), self.battery_states,
                        list((getattr(self, 'initial_search_visits', None) or {}).values()),
                        self.map_data, self.resolution, self.origin)
                    diversity_bounds[key] = 1. if diversity is None else diversity['factor']
            return assignment.utility, robot_name, group_id, assignment'''
assert source.count(needle)==1;source=source.replace(needle,replacement)
needle2="item[1], item[3].x, item[3].y, item[3].path_distance_m],"
assert source.count(needle2)==1;source=source.replace(needle2,"item[1], item[3].x, item[3].y, item[3].path_distance_m]\n                    * diversity_bounds.get((item[1], item[3].x, item[3].y), 1.),")
Path('log/p2c_v40_diversity_method_prototype.txt').write_text(source)
namespace=dict(vars(c));exec(compile(source,'<private diversity-bound prototype>','exec'),namespace);prototype=namespace['assign_idle_robots'];original=c.HeadquartersControl.assign_idle_robots
out={}
for stage in ['candidate_generation','candidate_budget']:
 path=Path(f'log/p2c_v39_dev_forced2_{stage}_expired_snapshot.json');expired=json.loads(path.read_text());d=expired['diagnostic_inputs'];e={**d,'inputs':expired['inputs_at_start'],'event_time':expired['planning_started_at_sec']}
 def run(fn):
  node,sent=fixtures.conditional_snapshot_node(e,d['exploration_resume_intents'].copy());node.robot_states=d['robot_states'].copy();requests=[]
  node.exploration_charge_budgets={};node.charge_request_publishers={n:SimpleNamespace(publish=lambda msg:requests.append(json.loads(msg.data))) for n in d['battery_states']}
  for key in ['battery_modes','initial_search_next','target_search_visits','successful_exploration_legs','rally_charge_requested','goal_routes']:
   setattr(node,key,d[key].copy())
  node.active_exclusions=lambda:d['exclusions'];node.enable_rally=d['enable_rally'];node.initial_search_visits=dict(enumerate(d['initial_search_visits']));node.initial_search_views=dict(enumerate(d['initial_search_views']))
  node.goal_targets={n:None if a is None else c.Assignment(**{**a,'viewpoint':c.Viewpoint(**a['viewpoint'])}) for n,a in d['goal_targets'].items()}
  counts={};wrapped={name:getattr(c,name) for name in ['known_return_route','resolve_frontier_gain','resolve_search_gain','plan_rally_leg']}
  for name,f in wrapped.items():
   def call(*a,f=f,name=name,**kw):counts[name]=counts.get(name,0)+1;return f(*a,**kw)
   setattr(c,name,call)
  try:fn(node)
  finally:
   for name,f in wrapped.items():setattr(c,name,f)
  return dict(sent=json.loads(json.dumps(sent,default=dataclasses.asdict)),requests=requests,choices=node.exploration_travel_choices,budget_times=getattr(node,'exploration_budget_times',{})),counts
 samples={'frozen39':[],'prototype':[]};expected=None;counts={}
 for repeat in range(5):
  seq=[('frozen39',original),('prototype',prototype)]
  if repeat%2:seq.reverse()
  for label,fn in seq:
   c.visibility_ray_projections.cache_clear();c.known_search_sector_table.cache_clear();start=time.perf_counter();answer,counter=run(fn);samples[label].append(time.perf_counter()-start)
   if expected is None:expected=answer
   assert answer==expected,(stage,label,'changed actual choice/charges/budgets/epochs')
   counts[label]=counter
 out[stage]=dict(input_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),original_slack_sec=expired['source_deadline_sec']-expired['planning_started_at_sec'],exact_conditional_results_equal=True,timing={k:dict(cold_wall_sec=v,median_wall_sec=statistics.median(v)) for k,v in samples.items()},calls=counts)
 print(stage,out[stage],flush=True)
Path('log/p2c_v40_diversity_bound_prototypes.json').write_text(json.dumps(dict(status='PASS',scope='two exact abandoned inputs, fixed epochs only; no original timing/history/mission proof',comparisons=out),indent=2)+'\n')
