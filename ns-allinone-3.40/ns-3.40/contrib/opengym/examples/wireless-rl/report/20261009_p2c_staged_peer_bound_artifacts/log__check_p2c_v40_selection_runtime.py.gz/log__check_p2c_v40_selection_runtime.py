import dataclasses,hashlib,json,math,time
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import rclpy
from rclpy.executors import SingleThreadedExecutor
from rclpy.node import Node
from rclpy.task import Future
from std_msgs.msg import String
from multi_robot_exploration import control as c
from test_exploration_resume import conditional_snapshot_node
from test_staged_peer_bound import REFERENCE,reference_assign
from test_candidate_battery_bound import conditional_charge
from check_p2c_gate import exploration_travel_audit
output=Path('log/p2c_v40_selection_runtime.json');assert not output.exists()
rclpy.init(args=['--ros-args','-p','use_sim_time:=true','-p','robot_count:=2','-p','enable_battery:=true','-p','enable_rally:=true','-p','auto_save_map:=false'])
receiver=Node('p2c40_selection_receiver');executor=SingleThreadedExecutor();executor.add_node(receiver);received=[];node=None;results={}
subscription=receiver.create_subscription(String,'/gateway/consumed',lambda message:received.append(json.loads(message.data)),10)
try:
 for stage,event in REFERENCE['snapshots'].items():
  node=c.HeadquartersControl()
  for timer in node.timers:timer.cancel()
  executor.add_node(node)
  # Subscribe to the actual private producer path, independent of any task.
  if subscription.topic_name!=node.consumed_publisher.topic_name:
   receiver.destroy_subscription(subscription)
   subscription=receiver.create_subscription(String,node.consumed_publisher.topic_name,lambda message:received.append(json.loads(message.data)),10)
  deadline=time.monotonic()+10.
  while node.consumed_publisher.get_subscription_count()!=1 and time.monotonic()<deadline:executor.spin_once(timeout_sec=.02)
  assert node.consumed_publisher.get_subscription_count()==1
  d=event['diagnostic_inputs'];e={**d,'inputs':event['inputs_at_start'],'event_time':event['planning_started_at_sec']}
  fixture,_=conditional_snapshot_node(e,d['exploration_resume_intents'].copy())
  for key,value in vars(fixture).items():
   if not callable(value) and key!='consumed_publisher':setattr(node,key,value)
  node.now=lambda:e['event_time']
  for key in ['robot_states','battery_modes','initial_search_next','target_search_visits','successful_exploration_legs','rally_charge_requested','goal_routes']:
   setattr(node,key,d[key].copy())
  node.initial_search_visits=dict(enumerate(d['initial_search_visits']));node.initial_search_views=dict(enumerate(d['initial_search_views']))
  node.goal_targets={n:None if a is None else c.Assignment(**{**a,'viewpoint':c.Viewpoint(**a['viewpoint'])}) for n,a in d['goal_targets'].items()}
  node.active_exclusions=lambda:d['exclusions'];node.enable_rally=d['enable_rally'];node.map_height,node.map_width=node.map_data.shape
  futures=[];sent=[]
  def action(goal,feedback_callback=None):
   sent.append(dict(x=goal.pose.pose.position.x,y=goal.pose.pose.position.y,z=goal.pose.pose.orientation.z,w=goal.pose.pose.orientation.w))
   future=Future(executor=executor);futures.append(future);return future
  for name in node.robot_nav_clients:node.robot_nav_clients[name]=SimpleNamespace(server_is_ready=lambda:True,send_goal_async=action)
  assert node.fresh_robot_inputs()
  planning_matches_original=np.array_equal(node.map_data,fixture.map_data)
  # Compare the frozen allocator on the same actual, freshly derived map.
  actual_event=json.loads(json.dumps(event));actual_event['diagnostic_inputs']['planning_map']=c.grid_audit_evidence(node.map_data,node.resolution,node.origin,'ap_delivered_planning_map',node.map_received_at,None)
  actual_event['diagnostic_inputs']['self_return_cells']=node.map_self_return_cells
  expected=conditional_charge(actual_event,reference_assign());assert expected['sent']
  beginning=len(received);node.assign_idle_robots()
  deadline=time.monotonic()+10.
  while len([x for x in received[beginning:] if x.get('event')=='coordinator_navigation_decision'])<len(expected['sent']) and time.monotonic()<deadline:executor.spin_once(timeout_sec=.02)
  messages=[x for x in received[beginning:] if x.get('event')=='coordinator_navigation_decision']
  assert len(messages)==len(expected['sent'])==len(futures)
  assert node.exploration_travel_choices==expected['choices']
  for message,(name,assignment) in zip(messages,expected['sent']):
   assert message['robot']==name
   assert np.allclose(message['requested_position'],[assignment['navigation_x'],assignment['navigation_y']],rtol=0,atol=1e-8)
  audit=exploration_travel_audit(messages,True,True,True,True,True,True,True);assert audit['status']=='PASS'
  results[stage]=dict(status='PASS',actual_action_requests=len(futures),actual_dds_decisions=len(messages),planning_map_matches_original=planning_matches_original,frozen_choice_equal=True,audit=audit,witnesses=messages)
  executor.remove_node(node);node.destroy_node();node=None
 out=dict(status='PASS',scope='Actual coordinator selection/freshness/recording/serialized Future registration and independent DDS receiver, exact saved AP inputs at fixed epochs; synthetic pending action client without Nav2 motion',control_sha256=hashlib.sha256(Path(c.__file__).read_bytes()).hexdigest(),reference_commit=REFERENCE['commit'],results=results,limits='No physical task, original trajectory/clock replay, causal mission benefit or timing upper bound')
 output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:{n:v for n,v in x.items() if n not in ('witnesses',)} for k,x in results.items()}))
finally:
 executor.shutdown()
 if node is not None:node.destroy_node()
 receiver.destroy_node();rclpy.shutdown()
