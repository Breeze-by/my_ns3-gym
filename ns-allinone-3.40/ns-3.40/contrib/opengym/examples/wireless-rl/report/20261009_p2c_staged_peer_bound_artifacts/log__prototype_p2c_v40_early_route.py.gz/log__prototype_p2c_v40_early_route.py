import inspect,json,textwrap,time,statistics,hashlib,dataclasses
from pathlib import Path
from types import SimpleNamespace
import test_exploration_resume as fixtures
from multi_robot_exploration import control as c
original=c.HeadquartersControl.assign_idle_robots;source=textwrap.dedent(inspect.getsource(original))
assert source.count('            if reservations:')==1
source=source.replace('            if reservations:', '''            if reservations or (getattr(self, 'enable_battery', False)
                    and factor_bounds[robot_name, assignment.x, assignment.y,
                                      assignment.path_distance_m] >= 1.):''')
Path('log/p2c_v40_early_route_method_prototype.txt').write_text(source);namespace=dict(vars(c));exec(compile(source,'<private early route-bound prototype>','exec'),namespace);prototype=namespace['assign_idle_robots']
harness=Path('log/prototype_p2c_v40_diversity_bound.py').read_text();body=harness[harness.index('out={}') :].replace("Path('log/p2c_v40_diversity_bound_prototypes.json')","Path('log/p2c_v40_early_route_prototypes.json')")
exec(compile(body,'<conditional saved-input early-route comparison>','exec'))
