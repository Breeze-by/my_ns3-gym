import inspect,json,textwrap,time,statistics,hashlib,dataclasses
from pathlib import Path
from types import SimpleNamespace
import test_exploration_resume as fixtures
from multi_robot_exploration import control as c
original=c.HeadquartersControl.assign_idle_robots;source=textwrap.dedent(inspect.getsource(original))
needle='''                if not exploration_prefix_can_move(route_proposals[key],
                        self.robot_positions[robot_name], reservations):'''
replacement='''                if active_explorers + len(plans) >= max_concurrent - 1:
                    admitted = reserve_rally_prefix(route_proposals[key], reservations)
                    can_move = (admitted is not None and math.dist(self.robot_positions[robot_name],
                        (admitted[0].x, admitted[0].y)) > NAVIGATION_POSITION_TOLERANCE_M)
                else:
                    can_move = exploration_prefix_can_move(route_proposals[key],
                        self.robot_positions[robot_name], reservations)
                if not can_move:'''
assert source.count(needle)==1;source=source.replace(needle,replacement)
Path('log/p2c_v40_last_slot_method_prototype.txt').write_text(source);namespace=dict(vars(c));exec(compile(source,'<private last-slot route admission prototype>','exec'),namespace);prototype=namespace['assign_idle_robots']
harness=Path('log/prototype_p2c_v40_diversity_bound.py').read_text();body=harness[harness.index('out={}') :].replace("Path('log/p2c_v40_diversity_bound_prototypes.json')","Path('log/p2c_v40_last_slot_prototypes.json')")
exec(compile(body,'<conditional saved-input last-slot comparison>','exec'))
