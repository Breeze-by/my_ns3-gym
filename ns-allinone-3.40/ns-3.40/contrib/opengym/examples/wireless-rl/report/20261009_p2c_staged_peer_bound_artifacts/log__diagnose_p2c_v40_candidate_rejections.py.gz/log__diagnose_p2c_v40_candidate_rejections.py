import collections,json
from pathlib import Path
from multi_robot_exploration import control as c
from test_candidate_battery_bound import conditional_charge
out={}
for stage in ['candidate_generation','candidate_budget']:
 e=json.loads(Path(f'log/p2c_v39_dev_forced2_{stage}_expired_snapshot.json').read_text());counts=collections.Counter();examples=[]
 oldfactor=c.HeadquartersControl.exploration_battery_factor;oldreserve=c.reserve_rally_prefix;oldrequired=c.HeadquartersControl.exploration_required_energy
 def required(self,*a,**kw):
  r=oldrequired(self,*a,**kw);counts['energy_none' if r is None else 'energy_priced']+=1
  return r
 def factor(self,*a,**kw):
  r=oldfactor(self,*a,**kw);counts['factor_zero' if r<=0 else 'factor_unfunded' if r<1 else 'factor_funded']+=1
  if len(examples)<5 and r<=0:examples.append(dict(robot=a[0],distance=a[1],target=a[2]))
  return r
 def reserve(*a,**kw):
  r=oldreserve(*a,**kw);counts['prefix_none' if r is None else 'prefix_available']+=1
  if r is not None:
   pose,route=r
   if __import__('math').dist(route[0],(pose.x,pose.y))<=c.NAVIGATION_POSITION_TOLERANCE_M:counts['prefix_stationary']+=1
  return r
 c.HeadquartersControl.exploration_battery_factor=factor;c.HeadquartersControl.exploration_required_energy=required;c.reserve_rally_prefix=reserve
 try:actual=conditional_charge(e,c.HeadquartersControl.assign_idle_robots)
 finally:c.HeadquartersControl.exploration_battery_factor=oldfactor;c.HeadquartersControl.exploration_required_energy=oldrequired;c.reserve_rally_prefix=oldreserve
 out[stage]=dict(counts=dict(counts),factor_zero_examples=examples,pending=e['diagnostic_inputs']['rally_charge_requested'],robot_states=e['diagnostic_inputs']['robot_states'])
print(json.dumps(out,indent=2));Path('log/p2c_v40_candidate_rejections.json').write_text(json.dumps(out,indent=2)+'\n')
