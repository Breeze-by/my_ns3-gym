import ast,copy,inspect,json,textwrap,time,statistics,hashlib,dataclasses
from pathlib import Path
from types import SimpleNamespace
import test_exploration_resume as fixtures
from multi_robot_exploration import control as c
original=c.HeadquartersControl.assign_idle_robots
method=ast.parse(Path('log/p2c_v40_peer_bound_method_prototype.txt').read_text()).body[0]
loop=next(n for n in ast.walk(method) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='refine')
refine=next(n for n in loop.body if isinstance(n,ast.FunctionDef) and n.name=='refine_candidate_gain')
proof=next(n for n in refine.body if isinstance(n,ast.If) and ast.unparse(n.test).startswith("not search and getattr(self, 'enable_battery'"))
new=copy.deepcopy(refine);new.name='refine_travel_bound';new.body=copy.deepcopy(refine.body[:4])+[copy.deepcopy(proof),ast.Return(value=ast.Name(id='raw',ctx=ast.Load()))]
refine.body.remove(proof);loop.body.insert(loop.body.index(refine),new)
for n in ast.walk(method):
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='lazy_priority_candidates':
  k=next(k for k in n.keywords if k.arg=='refine_bound');k.value=ast.Tuple(elts=[ast.Name(id='refine_travel_bound',ctx=ast.Load()),ast.Name(id='refine_candidate_gain',ctx=ast.Load())],ctx=ast.Load())
ast.fix_missing_locations(method);method_source=ast.unparse(method);Path('log/p2c_v40_staged_bounds_method_prototype.txt').write_text(method_source+'\n')
lazy=textwrap.dedent(inspect.getsource(c.lazy_priority_candidates))
lazy=lazy.replace('    heap = []',"    refinements = () if refine_bound is None else (refine_bound,) if callable(refine_bound) else tuple(refine_bound)\n    fully_priced = len(refinements) + 1\n    heap = []")
lazy=lazy.replace('if stage == 2:', 'if stage == fully_priced:').replace('if stage == 0 and refine_bound is not None:', 'if stage < len(refinements):').replace('result = refine_bound(candidate)', 'result = refinements[stage](candidate)').replace('(-bound, index, 1, result)','(-bound, index, stage + 1, result)').replace('(-score, index, 2, result)','(-score, index, fully_priced, result)')
Path('log/p2c_v40_staged_bounds_lazy_prototype.txt').write_text(lazy)
namespace=dict(vars(c));exec(compile(lazy,'<ordered cheap proofs then exact gain>','exec'),namespace);exec(compile(ast.Module(body=[method],type_ignores=[]),'<private staged peer bound method>','exec'),namespace);prototype=namespace['assign_idle_robots']
harness=Path('log/prototype_p2c_v40_diversity_bound.py').read_text();body=harness[harness.index('out={}') :].replace("Path('log/p2c_v40_diversity_bound_prototypes.json')","Path('log/p2c_v40_staged_bounds_prototypes.json')")
exec(compile(body,'<conditional saved-input staged bound comparison>','exec'))
