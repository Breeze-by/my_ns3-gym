import ast,gzip,hashlib,json,re,subprocess
from pathlib import Path
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap';w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report';parent='10860f4029fe26c1517bd550ff6251870693bf7b'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def old(p):return subprocess.check_output(['git','show',parent+':'+str(p.relative_to(root))],cwd=root)
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py';native=r/'src/multi_robot_exploration/multi_robot_exploration/battery_manager.py';assert old(native)==native.read_bytes()
compare=load(r/'log/p2c_v40_final_comparisons.json');runtime=load(r/'log/p2c_v40_selection_runtime.json');clock=load(r/'log/p2c_v40_clock_runtime.json');source=load(r/'log/p2c_v40_source.json')
assert all(x['status']=='PASS' for x in (compare,runtime,clock,source)) and len(compare['comparisons'])==8
assert compare['control_sha256']==runtime['control_sha256']==clock['control_sha256']==sha(control)
full=re.search(r'(\d+) passed in ([\d.]+)s',(r/'log/p2c_v40_full_tests.log').read_text());assert full and int(full[1])==1462
extra=re.search(r'(\d+) passed in ([\d.]+)s',(r/'log/p2c_v40_final_bound_tests.log').read_text());assert extra and int(extra[1])==35
build=re.search(r'4 packages finished \[([\d.]+)s\]',(r/'log/p2c_v40_build.log').read_text());assert build
for evidence,name in [('p2c_v40_manifest.log','p2c_integration_manifest.json'),('p2c_v40_blackout_manifest.log','p2c_blackout_manifest.json')]:
 current=load(r/'scripts'/name);assert load(r/'log'/evidence)['config']==current
 prior=json.loads(old(r/'scripts'/name))
 for key in ('cases','duration_sec','coverage_threshold','fault_seed','owner_shutdown_timeout_sec'):assert prior[key]==current[key]
unchanged={}
for rel in ('src/multi_robot_exploration/multi_robot_exploration/battery_manager.py','src/multi_robot_exploration/multi_robot_exploration/action_callbacks.py','src/multi_robot_exploration/multi_robot_exploration/tf_ingress_sampler.py','src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py','scripts/check_p2c_gate.py','scripts/observer_lifetime.py','scripts/observe_p3b5.py','scripts/p2c_native_graph.py','scripts/ros_smoke_test.py'):
 p=r/rel;assert old(p)==p.read_bytes();unchanged[rel]=sha(p)
prototypes={name:load(r/'log'/('p2c_v40_'+name+'_prototypes.json')) for name in ('diversity_bound','safe_suffix','field_cache','early_route','last_slot','peer_bound','staged_bounds','combined_bounds')};assert all(p['status']=='PASS' for p in prototypes.values())
files=[p for p in (r/'log').glob('*p2c_v40*') if p.is_file() and p.suffix!='.pyc' and p.name!='p2c_v40_prepare_components.log']
files += [r/'log'/('p2c_v39_dev_forced2_'+stage+'_expired_snapshot.json') for stage in ('candidate_generation','candidate_budget')]
dest=report/'20261009_p2c_staged_peer_bound_artifacts';assert not dest.exists();dest.mkdir();artifacts=[]
for p in sorted(set(files)):
 q=dest/('__'.join(p.relative_to(r).parts)+'.gz');q.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0));assert gzip.decompress(q.read_bytes())==p.read_bytes()
 artifacts.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(q.relative_to(report)),archive_sha256=sha(q)))
out=dict(status='PASS',scope='Prospective exact staged candidate sorting; mission acceptance pending',parent_commit=parent,control_sha256=sha(control),native_sha256=sha(native),full_suite_checks=int(full[1]),additional_check_after_full_suite=1,unique_functional_checks=int(full[1])+1,functional_wall_sec=float(full[2]),final_peer_bound_checks=int(extra[1]),build_wall_sec=float(build[1]),source_audit=source,actual_dds_selection=runtime,actual_clock=clock,comparisons=compare,prototypes=prototypes,unchanged_from_parent=unchanged,initial_readonly_failures_retained=['diversity prototype indentation error before any comparison'],limits='CPU improves only selected recorded inputs; some historical cells regress. Prototype compiled globals bypass some temporary instrumentation wrappers, so prototype call counters are not valid comparative cost attribution. Exact fixed-epoch selections do not replay original timing/history or prove causal mission/physical worst-case success.',unrun=['new4 development','new17 formal','new2 physical','917'],artifacts=artifacts)
(report/'20261009_p2c_staged_peer_bound_components.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
text=f'''# P2C.1 v40 分阶段同伴预算排序界组件 PASS

v39冻结10860f4首forced原任务RALLY timeout300.4s，检测279.8/RALLY295.9s；双机各charge1、最低7.95590、零接触/耗尽/failed/任务期infra/retry。267 live与12独立审计PASS不能抵消任务失败；其余3dev/17formal/2physical/917未调用，全部原数据见20261009_p2c_v39_failed_development.md/.json。

这次先比较八个计算候选：空间历史折扣界、完全安全末段veto复用、距离场LRU、提前航段界、最后并发槽的精确前缀检查、同伴预算界、分阶段同伴界、同伴加历史组合界。前五个在两份原输入上没有稳定实质收益，未合入；LRU的cold样本无命中，不代表所有warm场景都无用。组合历史没有证明优于较简洁的同伴界方案，未合入。所有源码/输入/失败/样本保留，首prototype缩进解析错误发生在任何计算/任务前并保留。

采用有顺序的精确branch-and-bound：先用单条完整本地已知接触返路证明同伴资金，再解原精确gain，最后原全部预算/相对距离/空间偏好定价。自己的local返路是qualified候选之一，距离上界不小于所有qualified候选的最小距离；按原最大合法map5s/pose2s源龄定价，严格energy>upper时该同伴在本冻结租约内必能通过原名义预算。仅用这样已证明的同伴子集计算relative_travel_factor上界；未证明、不新鲜、缺本地图/完整返路或无效状态一律保留中性1，不丢候选。原已知全返路/原真实body路线完整预算、充电公平/全部池与lookahead、原stable greedy并列顺序与来源弃置保护均执行。这个upper budget从不进入实际命令或native能量许可。

八组准确历史AP输入各5次交错cold对照，全部实际选择/朝向/充电意图/预算/source epoch一致。v39两个中位.9409→.7397/1.4841→1.3858wall秒，v35corridors.6022→.5249；v35lab.7636→.8287、rooms.6671→.6919，v36三个低电量输入.8732/.8792/.8819→.8894/.9000/.9203，计算退化明确保留。该算法不是普遍加速保证，sim剩余来源时间不能直接与wall样本等同；prototype采用独立globals，部分临时计数wrapper被绕过，因此不把prototype调用计数当作跨算法成本证据。

新34checks与既有相关127PASS39.83s；完整{int(full[1])}PASS{float(full[2]):.2f}s；追加来源在资金证明中到期仍撤销全部临时命令的检查后，35专门检查PASS{float(extra[2]):.2f}s，独立合计{int(full[1])+1}。验证12随机稳定排序/并列、8地图×16合法源龄下本地预算证明覆盖全部qualified最小返路、无效/未负担/本地unknown但融合可负担回退、可写地图改变重建、每级不得扩大上界、第二级拒绝不定价以及原弃置输入实际等价。四包build{float(build[1]):.2f}s，171保护/4原授权变化/54static、8中央+2native Future注册PASS。

实际两个coordinator原fresh checks/选择/发布/序列化Future注册与独立DDS receiver：准确原地图均一致，3真实决策请求/3接收witness各自完整travel/预算/源龄审计PASS，frozen39选择完全相同；仅动作客户端是pending合成Future，无Nav2运动或Gazebo任务。实际独立DDS时钟/互斥普通状态/序列化action检查PASS，来源过期未被阻塞状态回调掩盖。源码仅lazy_priority_candidates、assign_idle_robots变化和新增local_peer_funded_for_lease；其余class方法/native/clock/TF/action/Nav2/SLAM/物理字节不变。原300s/.35/.05/.1/5s与2/5/60s TTL未放宽。

新clean pushed freeze先forced完整native及每机charge≥1，再另3dev；all4过才同freeze17formal+2physical，917最后首次暴露。组件改善仍未证明任务成功或真实最坏完成；P2C.1尚未完成，P3C.5已验收，无P4/ns-3/Wi-Fi/RL。
'''
(report/'20261009_p2c_staged_peer_bound_components.md').write_text(text)
note=f'2026-10-09 P2C.1 v40分阶段预算排序界组件PASS待新原任务：v39 10860f4首forced RALLYtimeout300.4/detect279.8/rally295.9，各charge1/min7.95590；0contact/exhaustion/failed/task-time infra/retry，267live/12审计PASS不替代任务成功。八计算候选比较，仅合入完整本地返路+最坏合法5/2s源龄的资金证明→精确gain→完整价格，证明失败中性回退、全部池/stable ties/真实body返路预算/充电公平/源TTL保持。八原输入5cold选择/预算完全等价，部分CPU提高而lab/rooms/低电量稍退化；无普遍提速/任务因果保证。{int(full[1])}完整+1追加源过期/{float(build[1]):.2f}s四包/171保护54static、3实际DDS选择和真实clock PASS。native/其他class/Nav2/SLAM字节保持，新4→17+2同freeze待验证，917未暴露；P3C.5已验收，无P4/ns3/Wi-Fi/RL。报告20261009_p2c_staged_peer_bound_components.md与20261009_p2c_v39_failed_development.md；旧pending为历史。'
for p in (w/'AGENTS.md',w/'RESEARCH_PLAN.md',w/'IMPLEMENTATION_PLAN.md',r/'user_guide.md',r/'launch_commands.md'):
 lines=p.read_text().splitlines();assert lines[2].startswith('2026-10-09 P2C.1 v39');lines[2]=note;p.write_text('\n'.join(lines)+'\n')
p=root/'AGENTS.md';s=p.read_text();start=s.index('2026-10-09 P2C.1 v39');end=s.index('\n',start);p.write_text(s[:start]+note+s[end:])
with (w/'log.md').open('a') as f:
 f.write('\n\n## 2026-10-09 P2C.1 v40 八计算候选比较与分阶段同伴预算界\n\n'+note+'\n\n')
 f.write('Humble+install/PYTHONNOUSERSITE1/FastDDS UDPv4清profiles，taskset -c 0-79 /usr/bin/python3；log/profile_p2c_v40_forced_inputs.py 三cold与cProfile准确弃置输入；依次log/prototype_p2c_v40_{diversity_bound,safe_suffix,field_cache,early_route,last_slot,peer_bound,staged_bounds,combined_bounds}.py（每个实际调用脚本均留档）两输入5paired cold固定epochs，全部conditional选择等价；前五无稳定收益/组合未证明更优，只有staged peer合入。首diversity缩进只读解析错误保留，修正后再比较；无任务或重试。log/compare_p2c_v40_final.py 最终源码八准确输入5paired cold、全部command/预算/充电/source相同且三改善五略退化；不当作全history/live clock或任务因果。\n\n')
 f.write(f'pytest -q test_staged_peer_bound.py/test_lazy_priority.py/test_candidate_battery_bound.py/test_exploration_route_bound.py（src/multi_robot_exploration/test/）127PASS39.83s；完整 /usr/bin/python3 -m pytest -q src/multi_robot_exploration/test scripts --ignore=src/multi_robot_exploration/test/test_copyright.py --ignore=src/multi_robot_exploration/test/test_flake8.py --ignore=src/multi_robot_exploration/test/test_pep257.py {int(full[1])}PASS{float(full[2]):.2f}s；新增证明中source到期检查后test_staged_peer_bound.py35PASS{float(extra[2]):.2f}s。四包colcon build --symlink-install --packages-select multi_robot_interfaces multi_robot_exploration merge_map multi_robot {float(build[1]):.2f}s；check_p2c_source.py --output log/p2c_v40_source.json PASS。\n\n')
 f.write('ROS_DOMAIN_ID217 scripts/check_p2c_clock_runtime.py --output log/p2c_v40_clock_runtime.json实际DDS/clock与互斥普通state+action PASS；219 log/check_p2c_v40_selection_runtime.py实际coordinator fresh input/selector→3 synthetic pending action request/独立DDS witness→完整travel审计PASS，原map和冻结39选择相同。重复coordinator名的rosout warning保留，无实际任务；fixed epoch不作实际Nav2/clock latency收益。run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v40 --domain 210 --gazebo-port 20290 --validate-only与--manifest scripts/p2c_blackout_manifest.json --case physical_fault --run-id 20261009_p2c_v40_physical --domain 219 --gazebo-port 20299 --validate-only PASS/no任务；新4→17+2同freeze仍待验证，917未运行，domain222/master11345未操作。\n')
print(json.dumps(dict(status='PASS',checks=int(full[1])+1,control_sha256=sha(control),artifacts=len(artifacts))))
