import ast,hashlib,json,statistics,subprocess,time
from pathlib import Path
from multi_robot_exploration import control as c
from test_staged_peer_bound import REFERENCE as fresh,reference_assign
from test_candidate_battery_bound import REFERENCE as charge,conditional_charge
from test_exploration_route_bound import REFERENCE as travel,conditional_assignment
old=reference_assign();root=Path('/home/zhuyulab/ns3-workspace');p=Path(c.__file__).resolve();before=subprocess.check_output(['git','show',fresh['commit']+':'+str(p.relative_to(root))],cwd=root,text=True)
original_lazy=next(n for n in ast.parse(before).body if isinstance(n,ast.FunctionDef) and n.name=='lazy_priority_candidates')
exec(compile(ast.Module(body=[original_lazy],type_ignores=[]),'<10860f4 lazy priority>','exec'),old.__globals__)
rows=[('v39_'+n,e,conditional_charge) for n,e in fresh['snapshots'].items()]+[('v36_'+n,e,conditional_charge) for n,e in charge['snapshots'].items()]+[('v35_'+n,e,conditional_assignment) for n,e in travel['snapshots'].items()];output={}
for name,event,conditional in rows:
 samples={'frozen39':[],'candidate40':[]};answer=None
 for repeat in range(5):
  sequence=[('frozen39',old),('candidate40',c.HeadquartersControl.assign_idle_robots)]
  if repeat%2:sequence.reverse()
  for label,fn in sequence:
   c.visibility_ray_projections.cache_clear();c.known_search_sector_table.cache_clear();start=time.perf_counter();actual=conditional(event,fn);samples[label].append(time.perf_counter()-start)
   if answer is None:answer=actual
   assert actual==answer,(name,label,'changed actual choices/charges/budgets/epochs')
 output[name]=dict(exact_conditional_results_equal=True,input_sha256=hashlib.sha256(json.dumps(event,sort_keys=True).encode()).hexdigest(),timing={k:dict(cold_wall_sec=v,median_wall_sec=statistics.median(v)) for k,v in samples.items()})
 print(name,{k:statistics.median(v) for k,v in samples.items()},flush=True)
def defs(s):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=defs(before),defs(p.read_text());changed=[n for n in a if a[n]!=b[n]];added=[n for n in b if n not in a];assert changed==['lazy_priority_candidates','HeadquartersControl'] and added==['local_peer_funded_for_lease'],(changed,added)
classes=[next(n for n in ast.parse(s).body if isinstance(n,ast.ClassDef) and n.name=='HeadquartersControl') for s in [before,p.read_text()]];methods=[{n.name:ast.dump(n,include_attributes=False) for n in cls.body if isinstance(n,ast.FunctionDef)} for cls in classes];changed_methods=[n for n in methods[0] if methods[0][n]!=methods[1][n]];assert changed_methods==['assign_idle_robots'] and methods[0].keys()==methods[1].keys()
out=dict(status='PASS',parent_commit=fresh['commit'],control_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),scope='Exact original saved inputs and five paired cold conditional epochs; no trajectory/live clock/causal mission/worst-case proof',changed_functions=['lazy_priority_candidates'],added=added,changed_methods=changed_methods,comparisons=output)
Path('log/p2c_v40_final_comparisons.json').write_text(json.dumps(out,indent=2)+'\n')
