import inspect,json,textwrap,time,statistics,hashlib,dataclasses,math
from pathlib import Path
from types import SimpleNamespace
import test_exploration_resume as fixtures
from multi_robot_exploration import control as c
original=c.HeadquartersControl.assign_idle_robots;source=textwrap.dedent(inspect.getsource(original))
source=source.replace('        factor_bounds = {}','        travel_bounds = {}\n        factor_bounds = {}')
needle='            return None if assignment is None else (assignment.utility, robot_name, group_id, assignment)'
replacement='''            if assignment is None:
                return None
            if not search and getattr(self, 'enable_battery', False):
                peers = []
                cell = world_to_grid(assignment.x, assignment.y, self.resolution, *self.origin)
                local_maps = HeadquartersControl.delivered_return_maps(self)
                caches = getattr(self, 'return_distance_caches', {})
                self.return_distance_caches = caches
                for peer, distances in travel_fields.items():
                    if peer == robot_name or distances is None or peer not in local_maps:
                        continue
                    distance = float(distances[cell])
                    if not math.isfinite(distance) or distance >= assignment.path_distance_m:
                        continue
                    state = self.battery_states[peer]
                    try:
                        if state['mode'] != 'ACTIVE':
                            continue
                        home = (float(state['charge_x']), float(state['charge_y']))
                        radius = float(state.get('charge_radius_m', .8))
                        geometry = local_maps[peer]
                        cache = caches.setdefault(peer, {}).setdefault('local', {})
                        current, _ = known_return_route(geometry['data'], geometry['resolution'], geometry['origin'], self.robot_positions[peer], home, radius, cache)
                        endpoint, _ = known_return_route(geometry['data'], geometry['resolution'], geometry['origin'], (assignment.x, assignment.y), home, radius, cache)
                        if current is None or endpoint is None:
                            continue
                        model = (float(state.get('move_cost_per_m', 1.)), float(state.get('idle_cost_per_sec', .02)), float(state.get('return_path_factor', 2.)), float(state.get('nominal_speed_mps', .18)), float(state.get('return_safety_margin', 8.)), float(state.get('return_recovery_wait_sec', RETURN_RECOVERY_WAIT_SEC)), STATE_TTL_SEC['fused_map_snapshot'], STATE_TTL_SEC['pose_state'])
                        upper = max(battery_assignment_required_energy(distance, endpoint, *model), battery_assignment_required_energy(0., current, *model))
                        if math.isfinite(upper) and float(state['energy']) > upper:
                            peers.append(distance)
                    except (KeyError, TypeError, ValueError, ZeroDivisionError):
                        continue
                travel_bounds[robot_name, assignment.x, assignment.y] = relative_travel_factor(assignment.path_distance_m, peers)
                if not lease_current('candidate_generation'):
                    scoring_aborted = True
                    return None
            return assignment.utility, robot_name, group_id, assignment'''
assert source.count(needle)==1;source=source.replace(needle,replacement)
needle2="item[1], item[3].x, item[3].y, item[3].path_distance_m],"
assert source.count(needle2)==1;source=source.replace(needle2,"item[1], item[3].x, item[3].y, item[3].path_distance_m]\n                    * travel_bounds.get((item[1], item[3].x, item[3].y), 1.),")
Path('log/p2c_v40_peer_bound_method_prototype.txt').write_text(source);namespace=dict(vars(c));exec(compile(source,'<private funded-local peer bound>','exec'),namespace);prototype=namespace['assign_idle_robots']
harness=Path('log/prototype_p2c_v40_diversity_bound.py').read_text();body=harness[harness.index('out={}') :].replace("Path('log/p2c_v40_diversity_bound_prototypes.json')","Path('log/p2c_v40_peer_bound_prototypes.json')")
exec(compile(body,'<conditional saved-input peer-bound comparison>','exec'))
