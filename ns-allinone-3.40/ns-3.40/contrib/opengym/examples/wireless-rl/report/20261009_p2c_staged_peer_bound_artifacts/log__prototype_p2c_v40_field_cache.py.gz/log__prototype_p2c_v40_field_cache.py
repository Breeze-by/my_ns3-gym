import inspect,json,textwrap,time,statistics,hashlib,dataclasses
from pathlib import Path
from functools import lru_cache
from types import SimpleNamespace
import numpy as np
import test_exploration_resume as fixtures
from multi_robot_exploration import control as c
original=c.path_distance_grid
@lru_cache(maxsize=16)
def cached(mask,shape,start,pred,goal):
 grid=np.frombuffer(mask,dtype=np.bool_).reshape(shape)
 goals=None if goal is None else np.frombuffer(goal,dtype=np.bool_).reshape(shape)
 out=original(grid,start,pred,goals);rows=out if pred else (out,)
 for a in rows:a.flags.writeable=False
 return out

def prototype(traversable,start,return_predecessors=False,goal_mask=None):
 if (traversable.dtype!=np.bool_ or traversable.size>262144 or
     (goal_mask is not None and (goal_mask.dtype!=np.bool_ or goal_mask.shape!=traversable.shape))):
  return original(traversable,start,return_predecessors,goal_mask)
 result=cached(traversable.tobytes(),traversable.shape,None if start is None else tuple(start),return_predecessors,None if goal_mask is None else goal_mask.tobytes())
 return tuple(a.copy() for a in result) if return_predecessors else result.copy()
harness=Path('log/prototype_p2c_v40_diversity_bound.py').read_text();body=harness[harness.index('out={}') :]
body=body.replace("('prototype',prototype)","('prototype',original_assign)").replace("('frozen39',original)","('frozen39',original_assign)")
body=body.replace('start=time.perf_counter();answer,counter=run(fn)',"cached.cache_clear();c.path_distance_grid=prototype if label=='prototype' else original;start=time.perf_counter();answer,counter=run(fn)")
body=body.replace("Path('log/p2c_v40_diversity_bound_prototypes.json')","Path('log/p2c_v40_field_cache_prototypes.json')")
body=body.replace('counts[label]=counter','counts[label]={**counter,\'field_cache\':cached.cache_info()._asdict()}')
original_assign=c.HeadquartersControl.assign_idle_robots
try:exec(compile(body,'<conditional saved-input field cache>','exec'))
finally:c.path_distance_grid=original;cached.cache_clear()
