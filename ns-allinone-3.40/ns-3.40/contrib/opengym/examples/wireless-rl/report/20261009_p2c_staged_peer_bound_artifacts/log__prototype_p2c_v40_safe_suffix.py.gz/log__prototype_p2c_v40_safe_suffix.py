import inspect,json,textwrap,time,statistics,hashlib
from pathlib import Path
from multi_robot_exploration import control as c
source=textwrap.dedent(inspect.getsource(c.route_respects_known_obstacles))
needle='    points = np.asarray(route, dtype=float)'
block='''    safe_segments = None
    if cache is not None and immutable_grid(raw_grid):
        identity = (resolution, *origin, clearance_m)
        memo = cache.setdefault('safe_veto_segments', {})
        if memo.get('snapshot') is not raw_grid or memo.get('geometry') != identity:
            memo.clear()
            memo.update(snapshot=raw_grid, geometry=identity, segments=set())
        safe_segments = memo['segments']
        original_route = tuple(tuple(point) for point in route)
        cutoff = len(original_route) - 1
        while cutoff > 0 and (original_route[cutoff-1], original_route[cutoff]) in safe_segments:
            cutoff -= 1
        route = original_route[:cutoff+1]
    points = np.asarray(route, dtype=float)'''
assert source.count(needle)==1;source=source.replace(needle,block)
needle2='    return not np.any(invalid_escape)'
block2='''    valid = not np.any(invalid_escape)
    if safe_segments is not None and np.all(safe):
        if len(safe_segments) + len(route) - 1 > 2048:
            safe_segments.clear()
        safe_segments.update(zip(route, route[1:]))
    return valid'''
assert source.count(needle2)==1;source=source.replace(needle2,block2);Path('log/p2c_v40_safe_suffix_function_prototype.txt').write_text(source)
namespace=dict(vars(c));exec(compile(source,'<private safe-veto suffix prototype>','exec'),namespace);prototype=namespace['route_respects_known_obstacles'];original=c.route_respects_known_obstacles
# Reuse the exact saved input/conditional-result benchmark harness, with
# this geometric implementation replacing only the continuous local veto.
harness=Path('log/prototype_p2c_v40_diversity_bound.py').read_text();start=harness.index('out={}');body=harness[start:]
body=body.replace("('prototype',prototype)","('prototype',original_assign)").replace("('frozen39',original)","('frozen39',original_assign)")
body=body.replace('start=time.perf_counter();answer,counter=run(fn)',"c.route_respects_known_obstacles=prototype if label=='prototype' else original;start=time.perf_counter();answer,counter=run(fn)")
body=body.replace("Path('log/p2c_v40_diversity_bound_prototypes.json')","Path('log/p2c_v40_safe_suffix_prototypes.json')")
from types import SimpleNamespace
import dataclasses
import test_exploration_resume as fixtures
original_assign=c.HeadquartersControl.assign_idle_robots
try:exec(compile(body,'<conditional saved-input safe-suffix comparison>','exec'))
finally:c.route_respects_known_obstacles=original
