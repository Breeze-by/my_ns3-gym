import ast,gzip,hashlib,json,re,subprocess
from pathlib import Path
from check_p2c_gate import launch_process_audit
from p2c_native_graph import native_tf_ingress_audit
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
parent='b2b038c615af9fb728e90f7a57c150e936a9bce5'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def old(p):return subprocess.check_output(['git','show',f'{parent}:{p.relative_to(root)}'],cwd=root)
def archive(paths,name):
 dest=report/name;dest.mkdir();out=[]
 for p in sorted(set(paths)):
  q=dest/('__'.join(p.relative_to(r).parts)+'.gz')
  q.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0))
  assert gzip.decompress(q.read_bytes())==p.read_bytes()
  out.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(q.relative_to(report)),archive_sha256=sha(q)))
 return out
base=r/'log/p2c/20261009_p2c_v28';paths=list(base.glob('*/summary.json'));assert len(paths)==4
originals=[];processes={};graphs={}
for p in paths:
 s=load(p);d=s['result'];assert s['git_commit']==parent and s['observer_returncode']==0
 assert d['collision_events']==0 and not d['failed_robots']
 assert all(v['battery_minimum_energy']>0 for v in d['robots'].values())
 for n,h in s['evidence_sha256'].items():assert sha(p.parent/n)==h
 originals.append(s)
 processes[s['case']]=launch_process_audit(p.parent)
 graphs[s['case']]=native_tf_ingress_audit(load(p.parent/'native_graph.json'),d['robot_count'],True)
room=next(s for s in originals if s['case']=='dev_rooms202')
assert room['result']['success'] and room['runner_returncode']==1
room_log=base/'20261009_p2c_v28_dev_rooms202/runner.log'
assert 'json.decoder.JSONDecodeError' in room_log.read_text() and 'wait_for_evaluation' in room_log.read_text()
gate=load(r/'log/p2c_v28_development_gate.json');assert gate['status']=='FAIL'
first_gate=load(r/'log/p2c_v28_dev_forced2_gate.json');assert first_gate['status']=='PASS'
audits=load(r/'log/p2c_v28_independent_audits.json')
assert audits['dev_corridors303']['native_return']['status']=='FAIL'
assert 'unclosed return prediction' in audits['dev_corridors303']['native_return']['error']
files=[x for x in base.rglob('*') if x.is_file() and x.suffix!='.pyc']
files += [r/'log'/n for n in ('check_p2c_v28_freeze.py','p2c_v28_freeze_check.json','p2c_v28_dev_forced2_runner.log','p2c_v28_dev_lab101_runner.log','p2c_v28_dev_rooms202_runner.log','p2c_v28_dev_corridors303_runner.log','p2c_v28_dev_forced2_gate.json','p2c_v28_dev_forced2_gate.log','p2c_v28_development_gate.json','p2c_v28_development_gate.log','audit_p2c_v28_independent.py','p2c_v28_independent_audits.json','p2c_v28_independent_audits.log','peek_p2c_v28_tasks.py')]
failure=dict(status='FAIL',scope='Four original development cells; no formal/physical/917 invocation',
 task_stack_frozen_commit=parent,originals=originals,strict_gate=gate,first_forced_gate=first_gate,
 independent_audits=audits,launch_process_audits=processes,native_tf_graph_audits=graphs,task_retries=0,
 all_owned_closed_before_edits=True,unrun=['17 formal','both physical','917'],
 limitations='Forced native272.6 passes. Rooms native220.4 is retained technical FAIL from an in-progress JSON read; no repair of original. Lab RALLY300.3 and corridors EXPLORE300.4 timeout; corridors tb1 return remains unclosed at native cutoff. Repeated ideal charge requests expired before tx; actual DDS separately demonstrates frozen coordinator clock during long state callbacks. This is not a wireless-capacity observation or single-factor task-effect proof.',
 artifacts=archive(files,'20261009_p2c_v28_artifacts'))
(report/'20261009_p2c_v28_failed_development.json').write_text(json.dumps(failure,indent=2)+'\n')
(report/'20261009_p2c_v28_failed_development.md').write_text('''# P2C.1 v28 四原开发 FAIL

冻结b2b038c615af9fb728e90f7a57c150e936a9bce5，先强制二机后其余三机原始场景。forced原生COMPLETE272.6秒、两机各charge1、最低6.60844，严格首格PASS；rooms原生COMPLETE220.4秒，但同一owner读取刚创建而未完成的result JSON，JSONDecodeError、runner1，仍保留技术FAIL。lab发现252.1/RALLY270.5/300.3秒timeout；corridors直到300.4秒EXPLOREtimeout、tb3charge1，tb1最终RETURNING，其返航预测未在截止前闭合，独立native-return审计FAIL。所有原任务零接触/耗尽/failed机器人，observer0，另外三runner0。原来4个结果与源、命令、环境、DDS图、账本、metrics、清理状态和失败traceback全部原样归档。17正式、两受控物理、917均未执行，无重试或回填。

其余八类AP/能量/探索/勘察/朝向独立审计全部PASS；不得以其代替任务或未闭合返航门禁。corridors原账本存在生成304.1秒/截止314.1秒的charge request，实际gateway在314.8秒接收时已过期，ideal条件下也无法传输。AP旧时钟/价格输入留在304.1秒。这提示中央回调计算与时钟更新耦合，随后隔离DDS实验证明机制；不是Wi-Fi容量瓶颈。没有从不同异步运行的完成时间差推断相机搜索收益。

P3C.5已获用户验收；本独立P2C.1补强仍未完成，无P4/ns-3/Wi-Fi/RL。
''')
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py'
unchanged={}
for rel in ('src/multi_robot_exploration/multi_robot_exploration/battery_manager.py','src/multi_robot_exploration/multi_robot_exploration/tf_ingress_sampler.py','src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py','scripts/observe_p3b5.py','scripts/p2c_native_graph.py'):
 q=r/rel;assert old(q)==q.read_bytes();unchanged[rel]=sha(q)
m=re.search(r'(\d+) passed in ([\d.]+)s',(r/'log/p2c_v29_full_components_final.log').read_text());assert m
b=re.search(r'4 packages finished \[([\d.]+)s\]',(r/'log/p2c_v29_build.log').read_text());assert b
source=load(r/'log/p2c_v29_source.json');clock=load(r/'log/p2c_v29_clock_runtime_final.json');visual=load(r/'log/p2c_v29_visual_runtime.json')
assert source['status']==clock['status']==visual['status']=='PASS'
assert clock['control_sha256']==visual['control_sha256']==sha(control)
assert all(load(r/'log'/n)['config']==load(r/'scripts'/cfg) for n,cfg in (
 ('p2c_v29_manifest.json','p2c_integration_manifest.json'),('p2c_v29_blackout_manifest.json','p2c_blackout_manifest.json')))
for cfg in ('p2c_integration_manifest.json','p2c_blackout_manifest.json'):
 now=load(r/'scripts'/cfg);previous=json.loads(old(r/'scripts'/cfg))
 assert now['cases']==previous['cases']
 for key in ('duration_sec','coverage_threshold','owner_shutdown_timeout_sec','native_pose_contract','ap_pose_budget_contract'):
  assert now[key]==previous[key]
 if 'return_staging' in previous:assert now['return_staging']==previous['return_staging']
qa=[q for q in (r/'log').glob('p2c_v29_*') if q.is_file() and q.suffix!='.pyc']
qa += [r/'log'/'prepare_p2c_v29_evidence.py']
components=dict(status='PASS',scope='Prospective central live clock, source-bound lease and read-only result polling; no mission-success claim',
 parent_commit=parent,control_sha256=sha(control),unchanged_from_parent=unchanged,
 functional_checks=int(m[1]),component_wall_sec=float(m[2]),targeted_checks=110,targeted_wall_sec=8.10,
 build_wall_sec=float(b[1]),source_audit=source,actual_dds_clock=clock,actual_dds_visual_survey=visual,
 preserved_failures=['Original clock fixture missing __package__; corrected DDS publisher inherited global use_sim_time and subscribed to clock; fixed with use_global_arguments=False. Neither was a task.',
 'Initial targeted command wrong filename/no tests; first corrected targeted92PASS/1FAIL original freshness fixture stale; next102PASS/2FAIL new delayed candidate fixture omitted diagnostics; corrected110PASS.',
 'First full1171PASS/36FAIL legacy geometry fixtures missing now/source interface and legacy evidence lacked full TTL/source fields. Static fixture leases added without changing geometry assertions; historical evidence keeps its original contract, new manifest requires complete epochs/leases.'],
 limits='Only clock callback can run concurrently with central task state. Original source leases and energy equations remain; computations may now be discarded on actual expiry, which is safe but not a task-efficiency guarantee. Controlled0.6s blocked-callback clock probe is not a CPU benchmark; actual DDS survey uses synthetic map/action client. Native energy/TF/physics/Nav2/evaluator bytes remain unchanged. Pricing provenance does not renew any input.',
 unrun=['new4 development','new17 formal','new2 physical','917'],artifacts=archive(qa,'20261009_p2c_live_clock_artifacts'))
(report/'20261009_p2c_live_clock_components.json').write_text(json.dumps(components,indent=2)+'\n')
(report/'20261009_p2c_live_clock_components.md').write_text(f'''# P2C.1 v29 中央实时时钟及租约组件 PASS

v28四原开发FAIL完整保留：强制272.6秒原生完成/两charge且首格严格PASS；rooms220.4秒原生完成但结果写入竞争导致runner1；lab300.3秒RALLY、corridors300.4秒EXPLOREtimeout，corridors末端返航未闭合。没有任务重试或回填。隔离真实DDS复现中央时钟机制：原single worker与只增two workers在0.6秒受控阻塞回调内，外部clock1.1→4.1而AP仍1.1，旧源假定新鲜；只将TimeSource现有clock订阅移到独立互斥回调组并使用two workers，AP完成时4.1，原source1.1过期。普通状态回调三种方案均未并发；原clock best-effort/depth1/唯一订阅保持。这个实验不声称真实CPU耗时、任务收益或无线测量。

新候选在候选生成/预算/路线/最终派发前检查原始source截止，并在提前充电/目标勘察/完整集合计划之后重新验证；过期或clock reset丢弃计算结果，不占用动作owner、不重写源时间。捕获rank/price/dispatch各自时刻，私有证据使用同一明确时刻重算各源年龄，所有预算系数和2/5/60秒TTL保持。旧cohort按原schema读取；新声明必须提供完整price/rank/source/TTL，严格审计同时拒绝未来计算、源后造时与到派发时已过期输入。关闭前停止新准入、取消timer并等待已有executor回调。result reader只对原producer尚未完成JSON作原有deadline内只读轮询，完整错误对象/producer退出/timeout仍FAIL；不改evaluator或任务期时限。

110定向PASS8.10秒；最终{int(m[1])}完整功能PASS{float(m[2]):.2f}秒；四包{float(b[1]):.2f}秒；171保护/4授权/54协议、两manifest、actual DDS clock和camera/survey/quiet/lapsed PASS。原初夹具/参数错误以及1171PASS/36FAIL完整日志保留，修复测试数据且几何断言不变。native battery、TF sampler、launch、observer、native graph全部相对b2字节一致；case参数/物理stimulus/300秒/5秒/关闭grace/安全门限不变。

这是安全时间语义修复，尚不能证明任务300秒通过。新同clean pushed freeze的4开发→17正式/2物理尚待；917未暴露，P3C.5已验收，无P4/ns-3/Wi-Fi/RL。
''')
note=f'2026-10-09 P2C.1 v29 live clock组件PASS待新冻结：v28四原FAIL，forced272.6 native/eachcharge1严格首格PASS；rooms220.4 native但未完成JSON读取runner1；labRALLY300.3/corridorsEXPLORE300.4，corridors未闭合return FAIL；全部失败原样归档。actual DDS证明旧single/只增two worker clock卡在1.1，新clock独立互斥组two worker在计算期间更新至4.1，原source1.1按2s到期，state仍串行/QoS保持。新规划租约checkpoint与charge/survey/rally完成后重查，price/rank/dispatch原source独立绑定；result只读有界轮询不改native。110定向/{int(m[1])}全功能/四包{float(b[1]):.2f}s/171保护4授权54协议/两声明/实际DDS PASS，原fixture失败保留。原300s/5s/2-5-60s/完整返回预算/native源/物理刺激保持。新4/17/2须同clean pushed freeze；917未暴露，P3C.5已验收，无P4/ns-3/Wi-Fi/RL。报告20261009_p2c_live_clock_components.md和20261009_p2c_v28_failed_development.md。'
for q in (w/'AGENTS.md',w/'RESEARCH_PLAN.md',w/'IMPLEMENTATION_PLAN.md',r/'user_guide.md',r/'launch_commands.md'):
 first,rest=q.read_text().split('\n',1);q.write_text(first+'\n\n'+note+'\n'+rest)
q=root/'AGENTS.md';q.write_text(q.read_text().replace('## Current Handoff\n','## Current Handoff\n\n'+note+'\n',1))
with (w/'log.md').open('a') as f:
 f.write('\n\n## 2026-10-09 P2C.1 v28四原失败及v29时钟租约补强\n\n'+note+'\n\n')
 for s in originals:
  f.write(f"原{s['case']}，freeze{parent}，{s['started_at_utc']}..{s['finished_at_utc']}，owner{s['owner_pid']}/observer{s['observer_pid']}，runner{s['runner_returncode']}/observer{s['observer_returncode']}，config/seed/profile见完整原summary；精确命令：`{' '.join(s['command'])}`；原结果{json.dumps({k:s['result'].get(k) for k in ('task_phase','success','completion_time_sec','elapsed_sim_time_sec','time_to_detect_sec','time_to_rally_sec','collision_events','battery_minimum_energy')})}。\n\n")
 f.write('b2 push exit0后独立freeze check PASS，再先dev_forced2/domain210/20290；严格首格PASS后单独检查源码clean，再三个dev domains211/212/213 ports20291/20292/20293。all4后strict gate FAIL/9类独立审计如报告，所有owner/observer关闭后才修改。17正式/两物理/917未调用。原JSON race/未闭合return完整保留。\n\n')
 f.write('v29新clock隔离DDS check_p2c_clock_runtime.py：首original-only冻结exec缺package ImportError；修正后probe publisher继承global use_sim_time造成额外clock订阅count fixture FAIL；use_global_arguments=False修正，old单/双与new双完整DDS PASS。初log/p2c_v29_clock_runtime.json SHA038de...为中途仅clock版；最终log/p2c_v29_clock_runtime_final.json绑定最终sourceSHA，两版区分。完整对应日志/输入/程序都归档。\n\n')
 f.write(f'QA Humble+install/PYTHONNOUSERSITE=1/PYTHONPATH source/test/scripts：初targeted文件名错无测试；92PASS/1FAIL旧夹具原source矛盾；102PASS/2FAIL新延迟夹具缺diagnostic；修正110PASS8.10s。首full1171PASS/36FAIL100.33s由geometry fixture缺now/input方法和旧evidence缺TTL/source完整字段；补静态原source，reader历史合同保持、新cohort必须epochs/leases。最终完整pytest三lint ignore{int(m[1])}PASS{float(m[2]):.2f}s、四包colcon{float(b[1]):.2f}s、check_p2c_source.py --output log/p2c_v29_source.json PASS171/4/54。实际DDS ROS_DOMAIN_ID216 clock与215 visual/survey/heading PASS，原clockBE1未增加应用流；新metadata两validate-only与917/stimulus字段一致性PASS。所有命令原输出见SHA gzip。下一新freeze all4/17/2未运行，不把componentPASS称taskPASS。\n')
print(json.dumps(dict(failure_artifacts=len(failure['artifacts']),component_artifacts=len(components['artifacts']),functional_checks=int(m[1]),build_sec=float(b[1]))))
