import gzip,hashlib,json,os,shutil
from datetime import datetime,timezone
from pathlib import Path
r=Path.cwd();root=r.parents[1];w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
run=r/'log/p2c/20261009_p2c_return_ready';freeze='593b5dda923293ab855d4dca98baa0a3345ba051'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
paths=sorted(run.glob('*/summary.json'));assert len(paths)==2;originals=[];closed=[]
for p in paths:
    row=load(p);assert row['git_commit']==freeze
    for key in ('owner_pid','observer_pid','physics_pid','staging_pid'):
        assert not Path('/proc',str(row[key])).exists();closed.append(dict(role=key,pid=row[key],closed=True))
    for name,digest in row['evidence_sha256'].items():assert sha(p.parent/name)==digest
    originals.append(row)
ideal=next(p.parent for p in paths if load(p)['case']=='physical_ideal')
staging=[json.loads(line) for line in (ideal/'staging.jsonl').open()]
native=[]
for index,line in enumerate((ideal/'safety_events.jsonl').open()):
    event=json.loads(line);data=event.get('data')
    if not isinstance(data,dict):continue
    if event['topic'] not in ('/tb1/battery_state','/tb1/battery_return_audit'):continue
    if data.get('sim_time',data.get('stamp_sec',0))>2078:continue
    if event['topic'].endswith('battery_state') or data.get('event') in ('return_started','return_route_recovered','return_finished'):
        native.append(dict(original_row_index=index,event=event))
ledger=[]
for index,line in enumerate((ideal/'ledger.jsonl').open()):
    event=json.loads(line)
    if (2076<=event.get('event_time',0)<=2077 and event.get('recipient')=='tb1'
            and event.get('correlation_id')==1 and event['event'] in ('accepted','command_accepted','navigation_outcome')):
        ledger.append(dict(original_row_index=index,event=event))
assert not any(e['event']['event']=='command_accepted' for e in ledger)
assert any(e['event'].get('status')==6 for e in ledger)
proof=dict(scope='Original source/receipt chronology; local priority refusal consistent with startup state competition, not costmap-only readiness',
    safety_sha256=sha(ideal/'safety_events.jsonl'),ledger_sha256=sha(ideal/'ledger.jsonl'),native=native,gateway=ledger,
    first_tb1_staging=next(e for e in staging if e['event']=='staging_requested' and e['robot']=='tb1'))
(r/'log/p2c_return_ready_startup_competition.json').write_text(json.dumps(proof,indent=2)+'\n')
destination=report/'20261009_p2c_return_ready_failed_artifacts';assert not destination.exists();destination.mkdir();artifacts=[]
files=[p for p in run.rglob('*') if p.is_file()]+[p for p in (r/'log').glob('*p2c_return_ready*') if p.is_file()]+[Path(__file__)]
for p in sorted(set(files)):
    q=destination/('__'.join(p.relative_to(r).parts)+'.gz')
    with p.open('rb') as source,q.open('wb') as target:
        with gzip.GzipFile(fileobj=target,mode='wb',mtime=0,compresslevel=6) as packed:shutil.copyfileobj(source,packed)
    assert hashlib.sha256(gzip.decompress(q.read_bytes())).hexdigest()==sha(p)
    artifacts.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(q.relative_to(report)),archive_sha256=sha(q)))
gate=load(r/'log/p2c_return_ready_final_reader_gate.json');fault=load(r/'log/p2c_return_ready_fault_final_audit.json')
assert gate['status']=='FAIL' and fault['status']=='PASS'
out=dict(status='FAIL',scope='Second independent supplemental physical pair; not main mission/TDI',freeze=freeze,
    original_source_config=originals[0]['config'],originals=originals,gate=gate,fault_independent=fault,
    startup_competition=proof,closure=dict(time_utc=datetime.now(timezone.utc).isoformat(),owned=closed),task_retries=0,artifacts=artifacts)
(report/'20261009_p2c_return_ready_failed.json').write_text(json.dumps(out,indent=2)+'\n')
(report/'20261009_p2c_return_ready_failed.md').write_text('''# P2C.1 第二独立受控返航对子 FAIL

冻结593b5dda923293ab855d4dca98baa0a3345ba051，两个新原格20261009_p2c_return_ready；原地理刺激、50秒准备/60..250秒blackout/62..248秒物理窗口、300秒任务和native/TTL保持。原对子723a844失败不回填，本对子也不计任务成功或TDI。

故障格两机在2096.182/2096.782秒到准备位，2246.182秒都已实际充电；每机charge1/min12.473829231068056/0接触耗尽失效，native EXPLOREtimeout300.1秒。全294live协议/graph/原生能量/实际窗口Nav2运动和准备就绪审核独立PASS。全部owned关闭exit0，无升级清理或重试。

理想格两台实际costmap已新鲜且覆盖准备位，第一条准备仍在2076.582秒以tb1 status6失败；后来RALLYtimeout300秒、tb1正电量失效/两机各charge1/min16.962944851041364/0接触耗尽，原安全门因此仍FAIL，不能把准备失败与后续安全失败隐藏。仅stager1，其余0，均已关闭。地图就绪不是充分准备条件，也不能保证全任务安全。

准确原数据表明tb1原生在2076.282秒先发布ACTIVE heartbeat，后在同一sim时刻因启动missing pose触发RETURNING；2077.182恢复。准备器2076.382看到交付battery源2076.282的ACTIVE，局部网关记录该命令的downlink接受，未记录command_accepted，立即结果6。这与本地优先安全拒绝一致。完整原安全行/账本行/源码、交付源龄和现有状态边界均保留；不是无线损伤，也不应为通过而取消本地安全保护。

首只读就绪审核把2091.1820000000002与2091.182当不同时刻，错误报缺前序记录；修复为1ns浮点等价容差，仅就绪/指令先后比较，原map2秒/状态5秒TTL未改。43定向通过；同原数据故障PASS、对子仍FAIL。初误报与traceback全部保留。下一适配仅在原交付状态中等待至少两个不同源时刻、间隔至少原0.5秒heartbeat的连续ACTIVE记录；仍须新冻结、两新原格，不使用原生隐藏状态或改变原刺激。

主v41完整任务仍FAIL；四开发/17正式/同源2物理和917尚未通过/首次调用。P3C.5已验收，无P4/ns-3/Wi-Fi/RL。
''')
with (w/'log.md').open('a') as f:
    f.write('\n\n## 2026-10-09 P2C.1 第二独立受控返航对子 FAIL\n\n593b5dd commit/push0与check_p2c_return_ready_freeze.py PASS；Humble+install/PYTHONNOUSERSITE1/FastDDS UDPv4清profiles，taskset -c 0-79 /usr/bin/python3 scripts/run_p2c_tasks.py --manifest scripts/p2c_blackout_manifest.json --case physical_ideal/physical_fault --run-id 20261009_p2c_return_ready --domain218/219 --gazebo-port20298/20299，各log/p2c_return_ready_physical_*_runner.log。两原native RALLY300/EXPLORE300.1均successfalse、各机charge1，ideal FAILEDtb1/min16.96294/stager1，fault0failed/min12.47383/全部0，0contact/exhaustion/retry/升级清理。完整UTC/PID/source/evidence SHA见20261009_p2c_return_ready_failed.json，全部owned闭合后才改读者或源码。\n\n')
    f.write('check_p2c_blackout initial gate/fault audit FAIL因原双浮点clock换算差2.3e-13秒；仅1ns先后等价修复，43定向PASS1.46s，新的同数据fault294live/准备/source/62..248实际Nav2运动/能量完整独立PASS，pair因理想tb1FAILED严格FAIL。所有初输出保留。准确原tb1 native2076.282 ACTIVE heartbeat随后RETURNING、2077.182恢复，准备2076.382使用同stamp交付ACTIVE；downlink accepted但无command_accepted、status6符合本地安全拒绝。下一只等待交付ACTIVE稳定，不改本地保护/native/task/源TTL/50s/blackout刺激；新freeze与两新原格必需。\n')
print(json.dumps(dict(status='FAIL',originals=2,fault_independent='PASS',artifacts=len(artifacts),owned_closed=True)))
