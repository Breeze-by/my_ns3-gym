import hashlib,json,os,subprocess
from datetime import datetime,timezone
from pathlib import Path
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
def git(*a):return subprocess.check_output(['git',*a],cwd=root,text=True).strip()
head=git('rev-parse','HEAD');assert head==git('rev-parse','@{u}')=='723a844e54e6f28501d59fc4ed2785f5f2d65592'
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
rows=[x for x in subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=root,text=True).split('\0') if x]
assert len(rows)==14 and all(x[:3]=='?? ' and x[3:].startswith('260929_report/') for x in rows)
run='20261009_p2c_return_characterization';assert not (r/'log/p2c'/run).exists()
manifest=r/'scripts/p2c_blackout_manifest.json';config=json.loads(manifest.read_text());frozen=json.loads(git('show',head+':'+str(manifest.relative_to(root))))
assert config==frozen and set(config['cases'])=={'physical_ideal','physical_fault'}
assert config['purpose']=='Unchanged controlled physical return/charging pair; supplemental safety only, excluded from mission success and TDI.'
prior=json.loads((r/'log/p2c/20261009_p2c_v41/20261009_p2c_v41_dev_forced2/summary.json').read_text());assert not prior['result']['success']
for key in ('owner_pid','observer_pid'):
 try:os.kill(prior[key],0)
 except ProcessLookupError:pass
 else:raise AssertionError(('old owned process still live',key,prior[key]))
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py';assert hashlib.sha256(control.read_bytes()).hexdigest()=='eb94e9407586ebfbc666d1340b56eabb010e51db443c13bbbca0df961490163d'
out=dict(status='PASS',declared_at_utc=datetime.now(timezone.utc).isoformat(),head=head,scope='Independent supplemental physical return/charge characterization under the already frozen two-cell stimulus; original v41 mission FAIL retained. Never substitutes for main4 development/17 formal acceptance',run_id=run,cases=list(config['cases']),frozen_manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),config=config,no_retry=True,retain_both_even_if_failure=True,uninvoked=['remaining3 v41 dev','formal17','917'],control_sha256=hashlib.sha256(control.read_bytes()).hexdigest())
(r/'log/p2c_return_characterization_predeclaration.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status='PASS',head=head,scope='supplemental physical pair only')))

