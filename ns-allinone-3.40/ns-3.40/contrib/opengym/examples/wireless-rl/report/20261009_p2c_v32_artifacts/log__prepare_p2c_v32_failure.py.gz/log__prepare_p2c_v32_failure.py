import gzip,hashlib,json,os
from pathlib import Path
from datetime import datetime,timezone
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
base=r/'log/p2c/20261009_p2c_v32';paths=list(base.glob('*/summary.json'));assert len(paths)==1
s=json.loads(paths[0].read_text());result=s['result'];assert s['git_commit']=='0972eec6561b92efb55b195a07b0716d3aca114b'
assert not result['success'] and result['task_phase']=='EXPLORE' and result['nav_goal_count']==6 and result['battery_total_charges']==2
assert result['collision_events']==0 and not result['failed_robots'] and s['runner_returncode']==s['observer_returncode']==0
closure={}
for key in ('owner_pid','observer_pid'):
    try:os.kill(s[key],0)
    except ProcessLookupError:closure[key]=dict(pid=s[key],closed=True)
    else:raise AssertionError(('owned process still live',key,s[key]))
closure['checked_at_utc']=datetime.now(timezone.utc).isoformat()
(r/'log/p2c_v32_closed_before_edit.json').write_text(json.dumps(closure,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name,digest in s['evidence_sha256'].items():assert sha(paths[0].parent/name)==digest
gate=json.loads((r/'log/p2c_v32_dev_forced2_gate.json').read_text());assert gate['status']=='FAIL'
audits=json.loads((r/'log/p2c_v32_independent_audits.json').read_text());assert all(v['status']=='PASS' for v in audits['dev_forced2'].values())
files=[p for p in base.rglob('*') if p.is_file() and p.suffix!='.pyc']
names=('check_p2c_v32_freeze.py','p2c_v32_freeze_check.json','p2c_v32_dev_forced2_runner.log','p2c_v32_dev_forced2_gate.json','p2c_v32_dev_forced2_gate.log',
    'audit_p2c_v32_independent.py','p2c_v32_independent_audits.json','p2c_v32_independent_audits.log','peek_p2c_v32_tasks.py','p2c_v32_closed_before_edit.json',
    'prepare_p2c_v32_failure.py')
files += [r/'log'/name for name in names]
destination=report/'20261009_p2c_v32_artifacts';destination.mkdir();artifacts=[]
for p in sorted(set(files)):
    q=destination/('__'.join(p.relative_to(r).parts)+'.gz');q.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0))
    assert gzip.decompress(q.read_bytes())==p.read_bytes()
    artifacts.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(q.relative_to(report)),archive_sha256=sha(q)))
output=dict(status='FAIL',scope='First frozen development original; remaining3/17/2/917 never invoked',original=s,strict_gate=gate,
    independent_audits=audits,all_owned_closed_before_edit=closure,task_retries=0,
    limitations='125 abandoned plans:96 candidate budgets/11 routes/15 dispatches/3 generation. Complete candidate budget pass remains too expensive for original2s leases. No radio bottleneck or worst-case bound.',artifacts=artifacts)
(report/'20261009_p2c_v32_failed_development.json').write_text(json.dumps(output,indent=2)+'\n')
(report/'20261009_p2c_v32_failed_development.md').write_text('# P2C.1 v32 首原开发 FAIL\n\n冻结0972eec6561b92efb55b195a07b0716d3aca114b，2026-10-09T05:33:25.613406..05:40:06.743930UTC。强制二机原任务300.0秒EXPLORE timeout，无目标发现；6个实际Nav2 goal（5中央探索/1本地返航）、两机各charge1，最低13.4646764，零接触/耗尽/failed机器人，owner609588/observer609606退出0，所有owned关闭后才编辑。严格首格FAIL，后3开发/17正式/2物理/917从未调用，无重试/回填/原300秒、5秒或TTL放宽。全部原始结果/source/config/command/environment/ledger/metrics/native图/关闭和SHA归档。\n\n十二独立检查PASS：4闭合返航/2地图预算/5位姿租约/1local腿/2charger returns、120能量、5探索（3视觉补查/3接续）证据。125次规划因原source+TTL到期而弃置，其中candidate_budget96/route_admission11/dispatch15/candidate_generation3。只读组件提速不等于任务通过；这也不是远端断网返航或硬件保证。\n\n当前完整候选集先逐个预算核验，再进行派发，仍使多个初步有效候选随同后续预算计算一起过期。下一候选可用原utility与最高continuation倍率作安全上界，按上界逐步完成原能量/relative/diversity评分，只有已核验候选优先级超过所有未核验上界时才进入同一route/body/full-budget/lease派发路径。固定source/epoch应与原greedy顺序及选择一致；真实输入仍必须新冻结任务验证，不续租、不把未核验候选派发或丢失请求回填。\n\nP3C.5已验收，P2C.1未完成；无P4/ns-3/Wi-Fi/RL。\n')
with (w/'log.md').open('a') as f:
    f.write('\n\n## 2026-10-09 P2C.1 v32 首强制原任务 FAIL\n\n0972eec commit/push0后check_p2c_v32_freeze.py PASS；Humble+install/PYTHONNOUSERSITE=1/FastDDS UDPv4/taskset -c0-79 /usr/bin/python3 scripts/run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v32 --domain210 --gazebo-port20290 > log/p2c_v32_dev_forced2_runner.log 2>&1。05:33:25.613406..05:40:06.743930UTC，300.0s EXPLORE timeout/6实际Nav2(5探索1local返航)/两机各charge1/min13.4646764/零接触耗尽failed；owner609588/observer609606 exit0。strict check_p2c_gate.py --run-root log/p2c/20261009_p2c_v32 --development --cases dev_forced2 --output log/p2c_v32_dev_forced2_gate.json FAIL native success；audit_p2c_v32_independent.py12子门PASS/4closed return/2map预算/5pose/2charger/120energy/5探索3视觉3接续/125租约弃置(96budget/11route/15dispatch/3generation)。其他3/17/2/917从未调用，所有owned关闭后才修改，原始FAIL与SHA压缩保留，不重试回填/阈值放宽。下一候选拟按原评分上界逐步核验，保持原同greedy固定输入优先级与完整body/return/energy/source guards；尚无该候选任务结果，P2C.1未完成，无P4/ns3/Wi-Fi/RL。\n')
print(json.dumps(dict(status='FAIL',artifacts=len(artifacts),expired=125,owned_closed=True)))
