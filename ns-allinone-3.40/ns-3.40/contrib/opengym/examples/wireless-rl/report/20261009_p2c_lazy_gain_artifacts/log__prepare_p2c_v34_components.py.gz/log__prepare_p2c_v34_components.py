import gzip,hashlib,json,re,statistics,subprocess
from pathlib import Path

root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
parent='24e1e27bbb4ada0df1ae9a6a5b42e692c958b916'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py'
comparison=load(r/'log/p2c_v34_lazy_gain_lookup_comparison.json');assert comparison['status']=='PASS' and comparison['control_sha256']==sha(control)
source=load(r/'log/p2c_v34_source.json');assert source['status']=='PASS'
runtime={key:load(r/'log'/name) for key,name in [('clock','p2c_v34_clock_runtime.json'),('native_future','p2c_v34_native_future_runtime.json'),('visual','p2c_v34_visual_runtime.json'),('lazy_gain_dds','p2c_v34_lazy_gain_dds.json')]}
assert all(v['status']=='PASS' for v in runtime.values())
for key in ('clock','visual','lazy_gain_dds'):assert runtime[key]['control_sha256']==sha(control)
full=re.search(r'(\d+) passed in ([\d.]+)s',(r/'log/p2c_v34_full_components.log').read_text());assert full and int(full[1])==1309
build=re.search(r'4 packages finished \[([\d.]+)s\]',(r/'log/p2c_v34_build.log').read_text());assert build
for saved,name in [('p2c_v34_manifest_corrected.json','p2c_integration_manifest.json'),('p2c_v34_blackout_manifest.json','p2c_blackout_manifest.json')]:
    current=load(r/'scripts'/name);assert load(r/'log'/saved)['config']==current
    old=json.loads(subprocess.check_output(['git','show',parent+':'+str((r/'scripts'/name).relative_to(root))],cwd=root))
    for key in ('cases','duration_sec','coverage_threshold','fault_seed','owner_shutdown_timeout_sec'):assert old[key]==current[key],key
old=load(r/'log/p2c_v33_independent_audits.json');reaudit=load(r/'log/p2c_v34_previous_original_audits.json')
for name,data in reaudit['dev_forced2'].items():assert data['status']==old['dev_forced2'][name]['status']=='PASS'
unchanged={}
for rel in ('src/multi_robot_exploration/multi_robot_exploration/battery_manager.py','src/multi_robot_exploration/multi_robot_exploration/action_callbacks.py','src/multi_robot_exploration/multi_robot_exploration/tf_ingress_sampler.py','src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py','scripts/observe_p3b5.py','scripts/p2c_native_graph.py','scripts/check_p2c_gate.py','scripts/ros_smoke_test.py','scripts/check_p2c_visual_runtime.py'):
    p=r/rel;assert subprocess.check_output(['git','show',parent+':'+str(p.relative_to(root))],cwd=root)==p.read_bytes();unchanged[rel]=sha(p)
batch=load(r/'log/p2c_v34_batch_ray_benchmark.json');assert batch['exact_gains']
files=[p for p in (r/'log').glob('*p2c_v34*') if p.is_file() and p.suffix!='.pyc']
files += [r/'src/multi_robot_exploration/test/fixtures/p2c_v33_two_robot_computation.json']
destination=report/'20261009_p2c_lazy_gain_artifacts';destination.mkdir();artifacts=[]
for p in sorted(set(files)):
    q=destination/('__'.join(p.relative_to(r).parts)+'.gz');q.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0))
    assert gzip.decompress(q.read_bytes())==p.read_bytes()
    artifacts.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(q.relative_to(report)),archive_sha256=sha(q)))
timing=comparison['timing'];before=statistics.median(timing['frozen_v33']['cold_wall_sec']);after=statistics.median(timing['candidate_v34']['cold_wall_sec'])
output=dict(status='PASS',scope='Prospective exact lazy frontier gain components; no mission acceptance',parent_commit=parent,control_sha256=sha(control),functional_checks=int(full[1]),functional_wall_sec=float(full[2]),build_wall_sec=float(build[1]),source_audit=source,actual_ros=runtime,fixed_source_comparison=comparison,previous_original_reaudit=reaudit,unchanged_from_parent=unchanged,rejected_batch_ray_cpu=batch,
    preparation_errors=['First generic-context cache patch landed in a separate eager method, removed before testing; only two intended central methods changed.',
        'Two-stage expiry test146PASS/1FAIL expected candidate_budget, but new earlier candidate_generation revoked the same provisional plan. Updated exact stage, all ownership assertions retained.',
        'First validate-only command omitted spaces in --domain210/--gazebo-port20290, argparse exit2/no task; corrected proper arguments.'],
    unrun=['new4 development','new17 formal','new2 physical','917'],
    limits='Source values/epochs and conditional two-idle ownership are fixed for comparisons. No original full-history replay, actual callback latency, CPU worst-case, causal task effect, hidden AP data or Wi-Fi bottleneck claim.',artifacts=artifacts)
(report/'20261009_p2c_lazy_gain_components.json').write_text(json.dumps(output,indent=2)+'\n')
note=f'2026-10-09 P2C.1 v34两级惰性前沿gain组件PASS待新冻结：24e1e27首强制FOUNDtimeout300.0/检测291.4/13Nav2/两机各charge1/87原lease弃置，strict FAIL原件保留，余3/17/2/917未调用。批量射线157cell五样本更慢(.391..929vs.183s)已拒绝无task。新原几何采样+矩形unknown收益上界→竞争时准确ray gain重入heap→原budget评分，真实目标与充电top3均准确gain/原稳定顺序，bounds从不派发；完整raw forecast/source/TTL/native保持。1309功能/四包{float(build[1]):.2f}s/171保护4授权54协议/实际ROS含2中央普通Assignment发布消费PASS。原早期交付双idle固定条件ray157→21/budget4→4/cold中位{before:.3f}→{after:.3f}s，导航偏好预算相同，非任务/最坏界。新4→17+2同clean pushed freeze未验证，917未暴露；P3C.5已验收，无P4/ns-3/Wi-Fi/RL。报告20261009_p2c_lazy_gain_components.md与20261009_p2c_v33_failed_development.md。'
(report/'20261009_p2c_lazy_gain_components.md').write_text(f'''# P2C.1 v34 两级惰性前沿收益组件 PASS

v33首强制原任务24e1e27自然FOUND timeout300.0秒/检测291.4秒/RALLY未进入，13Nav2、两机各charge1、最低11.4660094、零接触/耗尽/failed/infra/retries。全部owned关闭后才修改；十二独立子门PASS不能代替任务成功，87次原租约弃置完整保留，后3开发/17正式/2物理/917未运行。

先实测批量射线1/2/4/8/16/32 chunk：157个原前沿单元gain逐项相同，但五次中位约.391/.439/.612/.824/.890/.929秒，原逐点.183秒。该方法更慢，拒绝进入任务版本；原脚本/输出保留，无其任务。当前上界不是改善地图分辨率、视场范围或放宽阻挡。

原frontier几何采样仅依赖矩形unknown integral分数、距离、LOS和原spacing，不依赖最终ray gain。因此先按完全相同的采样顺序生成私有ViewpointGainBound/AssignmentGainBound，矩形unknown数是原射线实际unknown集的上界。竞争到优先级顶部时计算原精确ray gain和原reuse factor/utility，重入heap；再竞争胜出才计算完整return预算与relative/diversity评分。必须重入gain上界再做预算，避免把收益已下降候选多做预算（首组件试型ray21但budget26，最终两级ray21/budget4）。固定source/epoch下yield顺序与完整稳定greedy相同，实际所有动作仍原body/route/完整预算/source门限。

私有上界只保存在规划context，准确解析后恢复原Viewpoint/Assignment类型与数值；普通任务/本地安全/通信数据结构不变。只缓存同一不可变source数组的前沿几何，源替换或mutable alias不得复用；准确ray cache属于同一map/admission/充电context，无source/header/age或能量续租。完整raw候选池保留给原two-frontier forecast，以同样惰性准确gain实现原稳定排序、gain>200、half-utility、组/空间分离与最多三候选规则。实际已有原充电夹具和真实交付图的eager/deferred forecast路径及预算逐项相同。

十二随机地图验证几何/顺序/矩形上界/准确gain/带reuse的全部候选与排序相同，十二种子200候选两级稳定排序、失败界、竞争预算不提前计算、source替换与实际样本少于半数rays、派发普通类型/准确gain通过。首stage夹具146PASS/1FAIL仅因新增gain检查提前在candidate_generation撤销而旧断言期待candidate_budget；保持所有无导航/charge/live owner断言，更新准确stage后完整1309PASS{float(full[2]):.2f}秒。首validate-only错用连写domain参数exit2，无task，修正两清单PASS。generic patch误落其他方法的cache block在任何任务前移除，AST比较只两中央方法改变。

原2089.582秒交付map/固定epoch/两个idle的条件完整调度（不重放原owner和路径历史）五cold中位{before:.5f}→{after:.5f}秒，157→21 ray、4→4预算、导航/旅行偏好/预算证据逐项相同。四包{float(build[1]):.2f}秒、171保护/4授权/54协议/8+2 Future检查、actual ROS clock/native Future/原视场20数值79候选/独立发布消费PASS。新增domain214实际ROS中央assign_idle_robots用保留静态交付输入与合成goal sink，两个正常Assignment经实际DDS记录发布并独立重建原完整旅行/收益/预算/source证据；这是组件而非真实Nav2/Gazebo运动或clock时界。Native battery/共享Future/TF sampler/launch/观察器/严格gate与读者/视场validator相对24e1e27字节保持。旧v33十二子门只读重审PASS、原任务FAIL不回填。

P2C.1未完成。新4开发→17正式+2物理仍需同clean pushed freeze，先强制双机native COMPLETE且各charge≥1。917未暴露，P3C.5已验收，无P4/ns-3/Wi-Fi/RL。组件提速没有最坏界或任务因果收益证明。
''')
for p in (w/'AGENTS.md',w/'RESEARCH_PLAN.md',w/'IMPLEMENTATION_PLAN.md',r/'user_guide.md',r/'launch_commands.md'):
    first,rest=p.read_text().split('\n',1);p.write_text(first+'\n\n'+note+'\n'+rest)
p=root/'AGENTS.md';p.write_text(p.read_text().replace('## Current Handoff\n','## Current Handoff\n\n'+note+'\n',1))
with (w/'log.md').open('a') as f:
    f.write('\n\n## 2026-10-09 P2C.1 v34 两级惰性frontier gain组件\n\n'+note+'\n\n')
    f.write('Humble+install/PYTHONNOUSERSITE=1/FastDDS UDPv4清旧profiles；benchmark_p2c_v34_batch_rays.py157cell逐gain相同但全部chunk更慢，拒绝；新私有bounds/default eager接口与original geometry保持。pytest定向119PASS5.36s、gain/preparation16PASS2.83s、两级定向146PASS1FAIL6.35s仅旧stage名称与新更早expiry断言差异，修正exact stage后完整pytest src/multi_robot_exploration/test scripts三lint ignore1309PASS73.38s；gain含eager/deferred forecast15PASS2.50s。compare_p2c_v34_lazy_gain.py独立编译24e1e27、固定2089.582交付图/双idle条件，先试ray21/budget26约.276s，完整两级ray21/budget4约.224s，对冻原ray157/budget4约.387s，原导航/偏好/预算逐项相同；不是原episode回放/真实callback/任务因果或最坏界。\n\n')
    f.write(f'colcon build四包{float(build[1]):.2f}s；check_p2c_source.py --output log/p2c_v34_source.json171/4/54/8+2 PASS。首run_p2c_tasks.py validate-only错参数--domain210/--gazebo-port20290 argparse exit2无task，改--domain 210 --gazebo-port 20290的dev_forced2/run-id20261009_p2c_v34及physical_fault --manifest scripts/p2c_blackout_manifest.json/run-id20261009_p2c_v34_physical --domain 219 --gazebo-port 20299均validate-only PASS。domain220 check_p2c_clock_runtime.py --output log/p2c_v34_clock_runtime.json、221 native_future --output log/p2c_v34_native_future_runtime.json、215 visual --output log/p2c_v34_visual_runtime.json、214 log/check_p2c_v34_lazy_gain_dds.py --固定保留输入/合成goal sink及实际ROS publisher/consumer均PASS绑定最终source；后者2普通Assignment/独立收益/旅行/预算/lease审核，无真实Nav2/Gazebo。audit_p2c_v34_previous_originals.py旧v33十二子门仍PASS且strict任务FAIL。新4/17/2/917未启动，先commit/push exit0/clean freeze再首强制；不续租/放宽native/物理门限/回填原失败，domain222/master11345未操作。\n')
print(json.dumps(dict(status='PASS',functional_checks=int(full[1]),archives=len(artifacts),before=before,after=after,control_sha256=sha(control))))
