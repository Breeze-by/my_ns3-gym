import ast,cProfile,dataclasses,hashlib,json,pstats,subprocess,sys,time,types
from pathlib import Path
import test_exploration_resume as fixtures
from multi_robot_exploration import control

root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
path=r/'src/multi_robot_exploration/multi_robot_exploration/control.py'
source=subprocess.check_output(['git','show','24e1e27bbb4ada0df1ae9a6a5b42e692c958b916:'+str(path.relative_to(root))],cwd=root,text=True)
baseline=types.ModuleType('multi_robot_exploration.p2c_v31_lookup_baseline');baseline.__package__='multi_robot_exploration';baseline.__file__=str(path)
sys.modules[baseline.__name__]=baseline;exec(compile(source,str(path),'exec'),baseline.__dict__)
e=json.loads((r/'log/p2c_v33_two_robot_computation.json').read_text())['event']
def serial(value):
    return json.loads(json.dumps(value,default=lambda x:dataclasses.asdict(x) if dataclasses.is_dataclass(x) else x.tolist()))
def conditional(module):
    fixtures.control=module;node,sent=fixtures.conditional_snapshot_node(e,{})
    node.input_robot_names=lambda:e['travel_preference']['eligible_robot_names'];node.robot_maps.setdefault('tb1',None)
    node.robot_states={name:'idle' for name in node.robot_states};node.enable_rally=True
    node.initial_search_next={};node.rally_charge_requested={}
    node.initial_search_visits={}
    node.initial_search_views={}
    node.successful_exploration_legs={e['robot']:1};node.target_search_visits=[]
    node.exploration_travel_choices={};node.frontier_charge_lookahead=None
    original_budget=node.exploration_battery_factor;count=[0]
    original_rays=module.visible_unknown_gain;ray_count=[0]
    def ray(*args,**kwargs):
        ray_count[0]+=1;return original_rays(*args,**kwargs)
    module.visible_unknown_gain=ray
    def priced(*args,**kwargs):
        count[0]+=1;return original_budget(*args,**kwargs)
    node.exploration_battery_factor=priced
    module.HeadquartersControl.assign_idle_robots(node)
    budget_calls[(module.__name__)]=count[0];ray_calls[module.__name__]=ray_count[0]
    module.visible_unknown_gain=original_rays
    return serial(dict(sent=sent,choices=node.exploration_travel_choices,budget_times=node.exploration_budget_times))
outputs={};reference=None;budget_calls={};ray_calls={}
for label,module in [('frozen_v33',baseline),('candidate_v34',control)]:
    wall=[]
    for repeat in range(5):
        if label=='candidate_v34':
            control.visibility_ray_projections.cache_clear();control.known_search_sector_table.cache_clear()
        start=time.perf_counter();result=conditional(module);wall.append(time.perf_counter()-start)
        if reference is None:reference=result
        assert result==reference,(label,'assignment/budget evidence changed')
    profile=cProfile.Profile();result=profile.runcall(conditional,module)
    with (r/f'log/p2c_v34_lazy_gain_{label}_profile.txt').open('w') as f:pstats.Stats(profile,stream=f).strip_dirs().sort_stats('cumulative').print_stats(35)
    outputs[label]=dict(cold_wall_sec=wall,assignment_and_budget_equal=True,budget_calls=budget_calls[module.__name__],ray_calls=ray_calls[module.__name__])
fixtures.control=control
functions=lambda tree:{n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=functions(ast.parse(source)),functions(ast.parse(path.read_text()))
changed=[name for name in a if a[name]!=b[name]];added=[name for name in b if name not in a]
assert changed==['frontier_viewpoints','lazy_priority_candidates','prepare_frontier_data','robot_candidate_assignments','HeadquartersControl'] and added==['ViewpointGainBound','AssignmentGainBound','resolve_frontier_gain'],(changed,added)
old_class=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='HeadquartersControl')
new_class=next(n for n in ast.parse(path.read_text()).body if isinstance(n,ast.ClassDef) and n.name=='HeadquartersControl')
a_methods={n.name:ast.dump(n,include_attributes=False) for n in old_class.body if isinstance(n,ast.FunctionDef)}
b_methods={n.name:ast.dump(n,include_attributes=False) for n in new_class.body if isinstance(n,ast.FunctionDef)}
assert list(a_methods)==list(b_methods) and [name for name in a_methods if a_methods[name]!=b_methods[name]]==['frontier_lookahead_budget','assign_idle_robots']
output=dict(status='PASS',scope='Late original delivered map/history fixed-source computation only, no real dispatch or causal task result',
    baseline_commit='24e1e27bbb4ada0df1ae9a6a5b42e692c958b916',control_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
    changed_pure_functions=[name for name in changed if name!='HeadquartersControl'],added_pure_functions=added,changed_central_methods=['frontier_lookahead_budget','assign_idle_robots'],
    original_snapshot='log/p2c_v33_two_robot_computation.json',timing=outputs,comparison_result=reference)
(r/'log/p2c_v34_lazy_gain_lookup_comparison.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({k:v for k,v in output.items() if k!='comparison_result'}))
