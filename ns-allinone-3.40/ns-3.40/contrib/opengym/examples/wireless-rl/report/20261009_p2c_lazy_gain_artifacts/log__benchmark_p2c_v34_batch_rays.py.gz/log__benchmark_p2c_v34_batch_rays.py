import json,time
from pathlib import Path
import numpy as np
from multi_robot_exploration import control
from test_exploration_resume import conditional_snapshot_node

def batch(grid,starts,radius,chunk_size):
    starts=np.asarray(starts,dtype=int).reshape(-1,2);height,width=grid.shape
    gains=np.zeros(len(starts),dtype=int)
    row_projection,column_projection=control.visibility_ray_projections(radius)
    for offset in range(0,len(starts),chunk_size):
        cells=starts[offset:offset+chunk_size]
        valid=(cells[:,0]>=0)&(cells[:,0]<height)&(cells[:,1]>=0)&(cells[:,1]<width)
        valid_indices=np.flatnonzero(valid)
        valid[valid_indices]&=grid[tuple(cells[valid_indices].T)]==0
        rows=np.rint(cells[:,0,None,None]+row_projection).astype(int)
        columns=np.rint(cells[:,1,None,None]+column_projection).astype(int)
        inside=(rows>=0)&(rows<height)&(columns>=0)&(columns<width)
        np.clip(rows,0,height-1,out=rows);np.clip(columns,0,width-1,out=columns)
        values=grid[rows,columns]
        visible=np.logical_and.accumulate(inside&(values<control.OCCUPIED_THRESHOLD),axis=2)
        selected=np.nonzero(visible&(values<0)&valid[:,None,None])
        hits=np.zeros((len(cells),height*width),dtype=bool)
        hits[selected[0],rows[selected]*width+columns[selected]]=True
        gains[offset:offset+len(cells)]=np.count_nonzero(hits,axis=1)
    return gains

e=json.loads(Path('log/p2c_v33_two_robot_computation.json').read_text())['event'];node,_=conditional_snapshot_node(e,{})
grid=node.map_data;data=control.prepare_frontier_data(grid,node.resolution)
starts=[(v.row,v.column) for group in data[2].values() for v in group]
radius=control.INFORMATION_RADIUS_M/node.resolution
reference=[control.visible_unknown_gain(grid,c,radius) for c in starts]
output={}
for chunk in [1,2,4,8,16,32]:
    wall=[]
    for repeat in range(5):
        begin=time.perf_counter();result=batch(grid,starts,radius,chunk);wall.append(time.perf_counter()-begin)
        assert result.tolist()==reference,(chunk,'math changed')
    output[str(chunk)]=wall
wall=[]
for repeat in range(5):
    begin=time.perf_counter();actual=[control.visible_unknown_gain(grid,c,radius) for c in starts];wall.append(time.perf_counter()-begin)
    assert actual==reference
output['original']=wall
Path('log/p2c_v34_batch_ray_benchmark.json').write_text(json.dumps(dict(scope='Conditional original delivered frontier ray CPU only; no task',cells=len(starts),exact_gains=True,timing=output),indent=2)+'\n')
print(json.dumps(dict(cells=len(starts),median_sec={k:float(np.median(v)) for k,v in output.items()})))
