import base64,copy,hashlib,json,math,zlib
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock
from builtin_interfaces.msg import Time
from multi_robot_exploration import control as c
from check_p2c_gate import target_survey_audit
source=Path('log/p2c_v24_rally_contexts_original.json');event=json.loads(source.read_text())[0]
def decode(s):return dict(data=__import__('numpy').frombuffer(zlib.decompress(base64.b64decode(s['grid'])),dtype='<i2').reshape(s['shape']),resolution=s['resolution'],origin=s['origin'])
g=decode(event['planning_map']);original=decode(event['source_map']);names=list(event['current_positions'])
def node():
 n=SimpleNamespace(map_data=g['data'],source_map_data=original['data'],resolution=g['resolution'],origin=g['origin'],target=event['target'],
  robot_positions=copy.deepcopy(event['current_positions']),battery_states=copy.deepcopy(event['battery_states']),battery_modes={name:event['battery_states'][name]['mode'] for name in names},
  robot_maps={name:decode(s) for name,s in event['return_maps'].items()},robot_map_received_at={name:s['source_time'] for name,s in event['return_maps'].items()},
  robot_odom_received_at={name:event['inputs'][name+'/pose_state']['source_time'] for name in names},robot_tf_received_at={name:event['inputs'][name+'/frame_state']['source_time'] for name in names},
  battery_state_received_at={name:event['inputs'][name+'/battery_state']['source_time'] for name in names},
  map_received_at=event['planning_map']['source_time'],target_received_source_time=event['inputs']['headquarters/target_detection']['source_time'],map_self_return_cells=event['self_return_cells'],
  now=lambda:event['event_time'],get_clock=lambda:SimpleNamespace(now=lambda:SimpleNamespace(to_msg=lambda:Time(sec=int(event['event_time'])))),
  task_state='FOUND',enable_battery=True,message_freshness_timeout_sec=5.,target_view_distance=3.,target_observing_robot=event['observer_robot'],
  rally_charge_requested={},rally_leg_routes=dict.fromkeys(names,()),rally_goal_handles=dict.fromkeys(names),rally_goal_pending=dict.fromkeys(names,False),
  survey_goal_handle=None,survey_goal_pending=False,survey_attempts=0,rally_position_tolerance=.35,goal_timeout_sec=60.,num_robots=len(names),rally_max_retries=2,
  robot_nav_clients={name:Mock() for name in names},survey_goal_response=Mock(),fail_task=Mock(),fresh_robot_inputs=lambda:True,fresh_target=lambda:True)
 n.input_robot_names=lambda:names;n.participating_robots=lambda:names
 n.input_freshness_details=lambda:c.HeadquartersControl.input_freshness_details(n)
 n.exploration_battery_factor=lambda *args:c.HeadquartersControl.exploration_battery_factor(n,*args)
 n.send_survey_goal=lambda *args:c.HeadquartersControl.send_survey_goal(n,*args)
 events=[];n.consumed_publisher=SimpleNamespace(publish=lambda msg:events.append(json.loads(msg.data)))
 n.record_navigation_decision=lambda *args:c.HeadquartersControl.record_navigation_decision(n,*args)
 return n,events
old,old_events=node();observer=event['observer_robot'];pose=c.rally_survey_pose(g['data'],g['resolution'],g['origin'],old.robot_positions[observer],event['target'])
assert old.send_survey_goal(observer,pose)
old_e=next(e for e in old_events if e.get('kind')=='target_survey')
assert __import__('numpy').allclose(old_e['requested_position'],[-4.083699147855081,2.205444388417087],rtol=0,atol=1e-8)
new,new_events=node();assert c.HeadquartersControl.survey_target_frontiers(new,new.robot_positions)
new_e=next(e for e in new_events if e.get('kind')=='target_information_survey')
audit=target_survey_audit([new_e],True,3.)
out=dict(status='PASS',scope='Exact saved first failed assignment AP state, unchanged old survey prefix rebuilt; prospective selection+body/visible-prefix/whole-return admission with synthetic action clients only; no actual counterfactual mission or causal benefit',
 original_commit='8bd34917d37ec44c0920e56e98a861a42ccd66d0',input_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),control_sha256=hashlib.sha256(Path(c.__file__).read_bytes()).hexdigest(),
 original_survey_prefix=old_e,proposed_survey_prefix=new_e,independent_audit=audit)
Path('log/p2c_v24_survey_admission_diagnostic.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(status='PASS',old_endpoint=old_e['requested_position'],new_endpoint=new_e['requested_position'],choice=new_e['target_survey_selection'],independent_audit=audit)))
