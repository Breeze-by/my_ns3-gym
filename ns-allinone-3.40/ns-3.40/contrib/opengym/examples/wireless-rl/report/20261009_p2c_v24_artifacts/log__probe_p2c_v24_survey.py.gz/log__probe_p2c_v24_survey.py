import base64,hashlib,json,math,time,zlib
from pathlib import Path
from dataclasses import asdict
import numpy as np
from multi_robot_exploration import control as c
p=Path('log/p2c_v24_rally_contexts_original.json');events=json.loads(p.read_text())
def decode(s):return dict(data=np.frombuffer(zlib.decompress(base64.b64decode(s['grid'])),dtype='<i2').reshape(s['shape']),resolution=s['resolution'],origin=s['origin'])
output=[]
for event in events:
 g=decode(event['planning_map']);target=event['target'];rows=[];start=time.perf_counter()
 frontier=c.prepare_frontier_data(g['data'],g['resolution'])
 old=[]
 for name,position in event['current_positions'].items():
  pose=c.rally_survey_pose(g['data'],g['resolution'],g['origin'],position,target)
  old.append(dict(robot=name,pose=None if pose is None else asdict(pose)))
  options,_=c.robot_candidate_assignments(g['data'],g['resolution'],g['origin'],name,position,frontier_data=frontier,blocked_positions=[q for other,q in event['current_positions'].items() if other!=name])
  for _,_,group,a in options:
   v=a.viewpoint
   cells=c.visible_unknown_gain(g['data'],(v.row,v.column),c.INFORMATION_RADIUS_M/g['resolution'],return_cells=True)
   y,x=np.divmod(cells,g['data'].shape[1]);wx=(x+.5)*g['resolution']+g['origin'][0];wy=(y+.5)*g['resolution']+g['origin'][1]
   gain=int(np.count_nonzero((wx-target[0])**2+(wy-target[1])**2<=3.**2))
   if not gain or math.dist(position,(a.x,a.y))<=.35:continue
   score=gain/(1+a.path_distance_m)
   rows.append(dict(robot=name,target=[a.x,a.y],gain=gain,distance_m=a.path_distance_m,score=score,group=int(group)))
 rows.sort(key=lambda e:(-e['score'],e['distance_m'],e['robot'],*e['target']))
 output.append(dict(event_time=event['event_time'],assignment=event['assignment'],positions=event['current_positions'],original_nearest=old,ranked_alternatives=rows[:12],conditional_candidates=len(rows),wall_sec=time.perf_counter()-start))
out=dict(status='PASS',scope='Original delivered map/body/path inputs only; ranked alternatives are not yet energy/reservation-admitted or actual task counterfactual',source_sha256=hashlib.sha256(Path(c.__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),states=output)
Path('log/p2c_v24_survey_diagnostic.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
