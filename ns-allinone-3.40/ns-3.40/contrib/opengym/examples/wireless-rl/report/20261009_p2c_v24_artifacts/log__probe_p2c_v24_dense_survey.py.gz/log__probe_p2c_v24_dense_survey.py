import base64,json,math,time,zlib
from pathlib import Path
import numpy as np
from multi_robot_exploration import control as c
source=Path('log/p2c_v24_rally_contexts_original.json');events=json.loads(source.read_text());outputs=[]
for event in events:
 s=event['planning_map'];raw=np.frombuffer(zlib.decompress(base64.b64decode(s['grid'])),dtype='<i2').reshape(s['shape']);res=s['resolution'];origin=s['origin'];target=event['target'];start=time.perf_counter()
 endpoint=c.traversable_grid(raw,res,c.ROBOT_CLEARANCE_M);route_mask=c.traversable_grid(raw,res,c.PATH_CLEARANCE_M)
 rows,columns=np.indices(raw.shape);xs=(columns+.5)*res+origin[0];ys=(rows+.5)*res+origin[1]
 region=(xs-target[0])**2+(ys-target[1])**2<=(3.-.35)**2
 stride=max(1,math.ceil(.25/res));region &= (rows%stride==0)&(columns%stride==0)
 gains={};ranked=[]
 for name,position in event['current_positions'].items():
  blocked=[p for other,p in event['current_positions'].items() if other!=name]
  mask=c.block_dynamic_positions(route_mask,res,origin,blocked)
  safe=c.block_dynamic_positions(endpoint,res,origin,blocked)
  field=c.exploration_distance_field(raw,mask,res,origin,position)
  if field is None:continue
  for r,col in np.argwhere(safe&region&np.isfinite(field)):
   p=c.grid_to_world(r,col,res,*origin)
   if math.dist(position,p)<=.35:continue
   cell=(int(r),int(col))
   if cell not in gains:
    cells=c.visible_unknown_gain(raw,cell,2./res,return_cells=True);cy,cx=np.divmod(cells,raw.shape[1]);wx=(cx+.5)*res+origin[0];wy=(cy+.5)*res+origin[1]
    gains[cell]=int(np.count_nonzero((wx-target[0])**2+(wy-target[1])**2<=9.))
   gain=gains[cell]
   if gain:ranked.append(dict(robot=name,target=list(p),gain=gain,distance_m=float(field[cell]),utility=gain/(1+float(field[cell]))))
 ranked.sort(key=lambda e:(-e['utility'],e['distance_m'],e['robot'],*e['target']))
 outputs.append(dict(event_time=event['event_time'],ranked=ranked[:8],candidates=len(ranked),wall_sec=time.perf_counter()-start))
out=dict(status='PASS',scope='Coarse .25m target-band known-free endpoint/body/path ranking, still unadmitted full return/reservations and not actual task counterfactual',states=outputs)
Path('log/p2c_v24_dense_survey_diagnostic.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
