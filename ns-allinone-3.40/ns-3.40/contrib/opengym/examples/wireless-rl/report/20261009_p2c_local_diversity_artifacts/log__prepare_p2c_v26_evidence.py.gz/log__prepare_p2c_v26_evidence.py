import ast,gzip,hashlib,json,re,subprocess
from pathlib import Path
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap';w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
parent='47a75f9c0a92ba38c8835aec6d0e90a918b6446a'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def old(p):return subprocess.check_output(['git','show',f'{parent}:{p.relative_to(root)}'],cwd=root)
def archive(paths,name):
 destination=report/name;destination.mkdir();rows=[]
 for p in sorted(set(paths)):
  out=destination/('__'.join(p.relative_to(r).parts)+'.gz');assert not out.exists()
  out.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0));assert gzip.decompress(out.read_bytes())==p.read_bytes()
  rows.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(out.relative_to(report)),archive_sha256=sha(out)))
 return rows
base=r/'log/p2c/20261009_p2c_v25';paths=list(base.glob('*/summary.json'));assert len(paths)==1
original=load(paths[0]);result=original['result'];assert original['git_commit']==parent
assert original['runner_returncode']==original['observer_returncode']==0
assert not result['success'] and result['task_phase']=='RALLY' and not result['failed_robots'] and result['collision_events']==0
assert all(row['battery_charge_count']==1 and row['battery_minimum_energy']>0 for row in result['robots'].values())
for name,h in original['evidence_sha256'].items():assert sha(paths[0].parent/name)==h
gate=load(r/'log/p2c_v25_dev_forced2_gate.json');assert gate['status']=='FAIL'
independent=load(r/'log/p2c_v25_independent_audits.json')
assert all(v['status']=='PASS' for k,v in independent['dev_forced2'].items() if k!='native_vs_gateway_frame_samples')
from check_p2c_gate import launch_process_audit
from p2c_native_graph import native_tf_ingress_audit
processes=launch_process_audit(paths[0].parent);graph=native_tf_ingress_audit(load(paths[0].parent/'native_graph.json'),2,True)
frames=independent['dev_forced2']['native_vs_gateway_frame_samples']
tf_stats={name:dict(samples=len(rows),initial_missing=sum(v['native_age_sec'] is None for v in rows),stale=sum(v['native_age_sec'] is not None and v['native_age_sec']>2. for v in rows),maximum_valid_age_sec=max(v['native_age_sec'] for v in rows if v['native_age_sec'] is not None)) for name,rows in frames.items()}
comparisons={}
for name in ('competition','competition_1','competition_2','competition_3','radius_fixed','radius_early','occlusion','local_diversity'):
 p=r/'log'/f'p2c_v25_{name}_diagnostic.json';comparisons[name]=load(p);assert comparisons[name]['status']=='PASS'
files=[p for p in base.rglob('*') if p.is_file() and p.suffix!='.pyc']
files += [r/'log'/name for name in ('check_p2c_v25_freeze.py','p2c_v25_freeze_check.json','p2c_v25_dev_forced2_runner.log','p2c_v25_dev_forced2_gate.json','p2c_v25_dev_forced2_gate.log','audit_p2c_v25_independent.py','p2c_v25_independent_audits.json','p2c_v25_independent_audits.log','p2c_v25_early_maps.png')]
for pattern in ('probe_p2c_v25_competition*','p2c_v25_competition*','probe_p2c_v25_radius*','p2c_v25_radius*','probe_p2c_v25_occlusion*','p2c_v25_occlusion*','probe_p2c_v25_local_diversity*','p2c_v25_local_diversity*'):files+=list((r/'log').glob(pattern))
failure=dict(status='FAIL',scope='First forced development original only',task_stack_frozen_commit=parent,original=original,strict_gate=gate,independent_audits=independent,launch_process_audit=processes,native_tf_graph_audit=graph,native_tf_sample_summary=tf_stats,
 task_time_infrastructure_failures=0,task_retries=0,all_owned_closed_before_edits=True,post_task_shutdown_escalation_retained=True,
 conditional_trials=comparisons,shared_score_pool_adopted=False,larger_frontier_radius_adopted=False,occlusion_interest_adopted=False,
 prospective_local_diversity_adopted_with_original_near_home_neutral_region=True,
 limitations='Trials omit original in-flight reservations and do not recreate the original task counterfactual. The four visual points stay the same under shared scoring; radius trials add no candidates; the occlusion-interest variant mostly changes gains/yaw, not destinations. None is claimed faster.',
 unrun=['other3 development','17 formal','both physical','917 first exposure'],artifacts=archive(files,'20261009_p2c_v25_artifacts'))
(report/'20261009_p2c_v25_failed_development.json').write_text(json.dumps(failure,indent=2)+'\n')
(report/'20261009_p2c_v25_failed_development.md').write_text('''# P2C.1 v25 首个强制原任务 FAIL

冻结47a75f9c0a92ba38c8835aec6d0e90a918b6446a。原dev_forced2在270.4秒检测、284.2秒RALLY，300秒原生超时，tb2仍距集合点2.7516米。两机各charge1、最低14.188054，零接触/耗尽/failed机器人/任务期子进程崩溃；owner与observer退出0。初始化有原Nav2 lifecycle恢复，停止后lifecycle_manager-32升级SIGTERM→SIGKILL并以-9退出，原日志保留：外层0不代表每个子进程优雅关闭。本轮没有任务重试/回填/阈值放宽。其余三开发、17正式、两物理和917均未调用。

八类独立读者PASS：5闭合返航触发、4map预算、7pose租约、2本地腿/2charger returns；这些不是受控远端断网证明。120原生能量样本、27探索（含4视觉补查）、14接续、8相对偏好、27空间偏好、4AP返路否决、1集合分配及native graph/任务期进程审计PASS。新v25目标信息勘察实际执行0次，不能声称本原任务验证该分支；它也没有改变发现前的搜索代码。

只读比较全部保留：四份原视觉补查状态使用共享时间代价并合并已知/映射候选，四个首选均未变，未采用；七份原映射状态将视点半径0.8扩大到1.4/2.0米，无新增候选，部分端点小幅移动，未采用；四份原视觉状态使用遮挡感知访问圆盘，多数目的地不变，未采用。首半径程序误取只在视觉记录有的initial_search_visits键而KeyError，保留原错误，修正为同一保存事件中的mission_spatial_diversity.visits后另存输出，未启动任务。

地图及局部密度比较揭示当前全局角扇区将墙隔开的房间合并：105.8秒实际保存状态，原排序选西南完整路径4.285126米/预算22.280431；仅改软偏好的条件排序选另一个当前合法前沿视点(-4.074736,2.642469)，完整路径2.707918米/预算21.043203。比较保留当前交付图/模型/源龄/动态身体/完整去返预算，不包含原在途路线预约，不是原任务反事实或因果收益。前瞻v26保留原2米home-neutral范围，只把范围外全局方向计数替换为2米内当前已知视线的访问位置计数，其他硬约束不变。

P3C.5已验收；P2C.1仍须新冻结完整任务证据，无P4/ns-3/Wi-Fi/RL。
''')
text=(r/'log/p2c_v26_full_components.log').read_text();m=re.search(r'(\d+) passed in ([\d.]+)s',text);assert m and 'FAILED' not in text
b=re.search(r'4 packages finished \[([\d.]+)s\]',(r/'log/p2c_v26_build.log').read_text());assert b
source=load(r/'log/p2c_v26_source.json');runtime=load(r/'log/p2c_v26_visual_runtime.json');assert source['status']==runtime['status']=='PASS'
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py';assert runtime['control_sha256']==sha(control)
def methods(data):
 cl=next(n for n in ast.parse(data).body if isinstance(n,ast.ClassDef) and n.name=='HeadquartersControl')
 return {n.name:ast.dump(n,include_attributes=False) for n in cl.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
before=methods(old(control));after=methods(control.read_bytes());changed=[k for k,v in before.items() if after[k]!=v];assert changed==['frontier_travel_preference'],changed
pure=lambda data:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(data).body if isinstance(n,ast.FunctionDef)}
old_pure=pure(old(control));new_pure=pure(control.read_bytes());assert old_pure.keys()==new_pure.keys()
changed_pure=[k for k,v in old_pure.items() if new_pure[k]!=v];assert changed_pure==['mission_search_diversity']
unchanged={}
for rel in ('src/multi_robot_exploration/multi_robot_exploration/battery_manager.py','src/multi_robot_exploration/multi_robot_exploration/tf_ingress_sampler.py','src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py','scripts/observe_p3b5.py','scripts/p2c_native_graph.py'):
 p=r/rel;assert old(p)==p.read_bytes();unchanged[rel]=sha(p)
for n,cfg in (('p2c_v26_manifest.json','p2c_integration_manifest.json'),('p2c_v26_blackout_manifest.json','p2c_blackout_manifest.json')):assert load(r/'log'/n)['config']==load(r/'scripts'/cfg)
qa=[r/'log'/n for n in ('p2c_v26_directed.log','p2c_v26_full_components.log','p2c_v26_build.log','p2c_v26_source.json','p2c_v26_source.log','p2c_v26_manifest.json','p2c_v26_blackout_manifest.json','p2c_v26_visual_runtime.json','p2c_v26_visual_runtime.log','prepare_p2c_v26_evidence.py')]
components=dict(status='PASS',scope='Prospective local known-visible visit preference, not native task success',parent_commit=parent,functional_checks=int(m[1]),component_wall_sec=float(m[2]),directed_checks=99,build_wall_sec=float(b[1]),control_sha256=sha(control),source_audit=source,actual_ros_dds=runtime,
 changed_central_methods=changed,preserved_central_methods=len(before)-1,changed_existing_pure_functions=changed_pure,all_other_pure_geometry_rally_functions_ast_preserved=True,unchanged_from_parent=unchanged,
 algorithm='Original delivered static-charger centroid2m neutral zone retained. Outside it, count history positions within2m of a candidate only when a current known-free grid line connects them; unknown, occupied, outside-map and farther history do not discount it. Positive max(.25,1/sqrt(1+count)) factor, original2x useful continuation/relative funded-peer factor/full body route+qualified return+energy+leases/reservations retained.',
 limitations='Current-map sight is not original camera coverage or absence of a target. Historical0.5m sampling, bounded heuristic, no optimality/worst-case completion or causal speed guarantee. Real DDS proof uses synthetic grids/action client, not Nav2 motion.',
 unrun=['new all4 development','new17 formal','new2 physical','917 first exposure'],artifacts=archive(qa,'20261009_p2c_local_diversity_artifacts'))
(report/'20261009_p2c_local_diversity_components.json').write_text(json.dumps(components,indent=2)+'\n')
(report/'20261009_p2c_local_diversity_components.md').write_text(f'''# P2C.1 v26 局部可见访问偏好组件 PASS

v25首forced原任务FAIL及全部输入/失败/未采用方案独立保留。共享评分、扩大半径、遮挡感知圆盘的实际保存状态比較均未取得可靠目的地改善，未采用。全局角扇区偏好会合并墙后不同房间：105.8秒条件状态在同原候选/预算中，局部可见密度选出2.707918米/21.043203视点，原角向偏好选择4.285126米/22.280431。缺原在途预约且无轨迹反事实，不称任务收益。

新算法沿用已有AP交付位姿历史、原静态home中心/2米中性区、原有限平方根折扣；范围外只统计候选2米内且当前已知自由直线可见的访问位置。墙/unknown隔开的另一区域不共享计数；越界历史跳过，有限正折扣不取消或放松任何路线。当前地图视线与经过位置只是偏好，绝不视为90度相机历史覆盖。所有实际私有旁录保留原map/历史源龄，加可见历史索引、半径、中性标志和factor；独立读者从同保存图重建，篡改即FAIL。删除不再使用的八扇区常量。

{int(m[1])}完整功能PASS{float(m[2]):.2f}秒，99定向PASS7.75秒，四包{float(b[1]):.2f}秒，171保护文件/4授权源/54协议、两声明validate-only与actual DDS/domain215发布及独立读者PASS。DDS是合成图与synthetic action client，不是Nav2运动；全部known-space候选数值/旧int64失败复现及原target勘察检查保留。仅改变一个纯偏好函数和一个中央调用方法，其余{len(before)-1}中央方法及全部其他纯几何/集合/已知补查/目标勘察函数AST保持；native battery/sampler/launch/observer/native图字节保持，因此原callback/AP50快照/TF重投影证据依原作用范围保留。

新all4开发/17正式/2物理须clean pushed freeze后执行；917未暴露。原300秒/5秒保持/位置与速度门限/TTL/安全/物理均未放宽。P3C.5已验收；无P4/ns-3/Wi-Fi/RL。
''')
note=f'2026-10-09 P2C.1 v26局部可见密度组件PASS、待新冻结任务：v25首forced检测270.4/RALLY284.2/native timeout300、两机各charge1/min14.188054/零接触耗尽机器人失效任务期infra，原FAIL保留；停止后lifecycle子进程SIGKILL/-9原样记录，外层0不称全子进程优雅关闭。27探索/4视觉/14接续/120能量/5closed return/native图与八类独立审计PASS，v25目标信息勘察0实际记录。四原视觉共享评分首选全同、七原映射扩大半径无新增候选、圆盘遮挡版本目的地多未变，均不采用。105.8s原交付状态局部可见偏好条件2.707918m/预算21.043203，原4.285126m/22.280431；缺原在途预约，不称因果收益。保留原home2m中性区，范围外统计候选2m内当前已知视线访问位置，max(.25,1/sqrt(1+count))；完整去返/源龄/身体/预约/300s/5s原样。{int(m[1])}功能/99定向/四包{float(b[1]):.2f}s/171保护4授权54协议/actual DDS两声明PASS。新4开发/17正式/2物理须clean pushed freeze，917未暴露，P3C.5已验收，无P4/ns-3/Wi-Fi/RL。报告20261009_p2c_local_diversity_components.md与20261009_p2c_v25_failed_development.md。'
for p in (w/'AGENTS.md',w/'RESEARCH_PLAN.md',w/'IMPLEMENTATION_PLAN.md',r/'user_guide.md',r/'launch_commands.md'):
 first,rest=p.read_text().split('\n',1);p.write_text(first+'\n\n'+note+'\n'+rest)
p=root/'AGENTS.md';p.write_text(p.read_text().replace('## Current Handoff\n','## Current Handoff\n\n'+note+'\n',1))
with (w/'log.md').open('a') as f:
 f.write('\n\n## 2026-10-09 P2C.1 v25原任务失败及v26局部可见偏好\n\n'+note+'\n\n')
 f.write('ROS环境系统Python3/source Humble+install/PYTHONNOUSERSITE=1/FastRTPS-UDPv4/taskset -c0-79。47a75f9推送后check_p2c_v25_freeze.py独立PASS；run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v25 --domain 210 --gazebo-port 20290；owner及observer0，native RALLYtimeout300，post-SIGINT lifecycle_manager-32升级SIGTERM/SIGKILL/-9，完整原启动与清理记录保留，全部owned关闭后才修改。check_p2c_gate --run-root log/p2c/20261009_p2c_v25 --development --cases dev_forced2 --output log/p2c_v25_dev_forced2_gate.json FAIL，audit_p2c_v25_independent.py八类PASS。无任务重试/回填，其余格与917未调用。\n\n')
 f.write('只读probe_p2c_v25_competition.py及_1/_2/_3四原视觉共享评分比较，首选均不变；probe_p2c_v25_radius.py KeyError原错误保留，另存radius_fixed.py五状态、radius_early.py两状态，.8/1.4/2.0m均未新增候选；probe_p2c_v25_occlusion.py四原视觉比较目的地基本相同，均未采用。probe_p2c_v25_local_diversity.py五原映射状态比较全局角向/局部known-visible密度，105.8s完整预算与路径改善仅条件排名，未含原在途预约；最终保留原near-home中性区。early_maps.png以真实输入绘制并view_image检查。所有程序/原输入/输出/错误gzip与SHA保持。\n\n')
 f.write('v26 directed pytest test_mission_search_diversity.py/test_initial_known_search.py/test_relative_frontier_travel.py：99 PASS7.75s；完整pytest功能范围三lint ignore1143 PASS92.70s，colcon build四包；check_p2c_source --output log/p2c_v26_source.json；run_p2c_tasks --case dev_forced2 --run-id20261009_p2c_v26 --domain210 --gazebo-port20290 --validate-only与--manifest scripts/p2c_blackout_manifest.json --case physical_fault --run-id20261009_p2c_v26_physical --domain219 --gazebo-port20299 --validate-only；check_p2c_visual_runtime --output log/p2c_v26_visual_runtime.json实际DDS/domain215+synthetic action client全部PASS。前瞻all4/17/2原任务尚未调用，需新clean pushed freeze。全部精确argv、输出与源码SHA在组件/失败机读报告和压缩原件，无P4/ns-3/Wi-Fi/RL。\n')
print(json.dumps(dict(failure_artifacts=len(failure['artifacts']),component_artifacts=len(components['artifacts']),functional_checks=int(m[1]),build_sec=float(b[1]),preserved_methods=len(before)-1,native_tf_stats=tf_stats)))
