import collections, gzip, hashlib, json, os
from pathlib import Path
from datetime import datetime, timezone

root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
base=r/'log/p2c/20261009_p2c_v40';paths=list(base.glob('*/summary.json'));assert len(paths)==1
p=paths[0];s=json.loads(p.read_text());z=s['result'];freeze='d70b277c853cc736c40b535a9d3551a0c99b0950'
assert s['git_commit']==freeze and s['case']=='dev_forced2' and not z['success']
assert z['collision_events']==0 and not z['failed_robots']
assert s['runner_returncode']==s['observer_returncode']==0
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
closure={}
for key in ('owner_pid','observer_pid'):
 try:os.kill(s[key],0)
 except ProcessLookupError:closure[key]=dict(pid=s[key],closed=True)
 else:raise AssertionError(('live',key))
closure['checked_at_utc']=datetime.now(timezone.utc).isoformat()
(r/'log/p2c_v40_closed_before_edit.json').write_text(json.dumps(closure,indent=2)+'\n')
for name,digest in s['evidence_sha256'].items():assert sha(p.parent/name)==digest
gate=json.loads((r/'log/p2c_v40_dev_forced2_gate.json').read_text());assert gate['status']=='FAIL'
audits=json.loads((r/'log/p2c_v40_independent_audits.json').read_text())
assert len(audits['dev_forced2'])==12 and all(v['status']=='PASS' for v in audits['dev_forced2'].values())
rows=[json.loads(line) for line in (p.parent/'ledger.jsonl').open()]
leases=collections.Counter(e['stage'] for e in rows if e.get('event')=='coordinator_planning_lease_expired')
for e in rows:
 if e.get('event') == 'coordinator_planning_lease_expired':
  q=r/'log'/f"p2c_v40_dev_forced2_{e['stage']}_expired_snapshot.json"
  assert not q.exists();q.write_text(json.dumps(e,indent=2)+'\n')
snapshot_binding={}
snapshots=list((r/'log').glob('p2c_v40_dev_forced2_*snapshot.json'))
for q in snapshots:
 e=json.loads(q.read_text());assert any(x==e for x in rows)
 snapshot_binding[q.name]=dict(snapshot_sha256=sha(q),original_ledger_sha256=sha(p.parent/'ledger.jsonl'),ledger_index=e['ledger_index'])
files=[q for q in base.rglob('*') if q.is_file() and q.suffix!='.pyc']+snapshots
files += [r/'log'/name for name in ['check_p2c_v40_freeze.py','p2c_v40_freeze_check.json',
  'p2c_v40_dev_forced2_runner.log','p2c_v40_dev_forced2_gate.log','p2c_v40_dev_forced2_gate.json',
  'audit_p2c_v40_independent.py','p2c_v40_independent_audits.json','p2c_v40_independent_audits.log',
  'peek_p2c_v40_tasks.py','p2c_v40_closed_before_edit.json','prepare_p2c_v40_failure.py']]
files += [r/'log'/name for name in ('diagnose_p2c_v41_rally_failure.py','p2c_v41_rally_failure_diagnosis.json','p2c_v41_rally_failure_diagnosis.log','p2c_v41_rally_failure_profile.txt')]
assert all(q.exists() for q in files)
destination=report/'20261009_p2c_v40_artifacts';assert not destination.exists();destination.mkdir();artifacts=[]
for q in sorted(set(files)):
 a=destination/('__'.join(q.relative_to(r).parts)+'.gz');a.write_bytes(gzip.compress(q.read_bytes(),compresslevel=6,mtime=0))
 assert gzip.decompress(a.read_bytes())==q.read_bytes()
 artifacts.append(dict(source=str(q.relative_to(root)),source_sha256=sha(q),archive=str(a.relative_to(report)),archive_sha256=sha(a)))
out=dict(status='FAIL',scope='First required forced-development original failed; other3 development/formal17/physical2/917 not invoked',
 task_stack_frozen_commit=freeze,original=s,first_required_gate=gate,independent_audits=audits,
 all_owned_closed=closure,planning_lease_aborts=dict(leases),exact_snapshot_binding=snapshot_binding,
 task_retries=0,artifacts=artifacts)
(report/'20261009_p2c_v40_failed_development.json').write_text(json.dumps(out,indent=2)+'\n')

text="""# P2C.1 v40 首强制原任务 FAIL

冻结 d70b277c853cc736c40b535a9d3551a0c99b0950。原任务在192.8秒以FAILED/mission_failed/insufficient_rally_poses自然结束，目标118.7秒发现，未进入RALLY，success=false、completion_time=null、native保持证明=null。两机各charge1、最低14.95501051806788；零接触/耗尽/failed机器人/任务期基础设施失败/任务重试。owner713329/observer713349自然exit0/0并确认关闭。首强制strict FAIL，12独立审计PASS：4返航触发/4地图/6来源租约/2本地腿/2充电返回、78原生能量、8探索/3接续/1相机搜索、12完整集合失败重建、2规划来源弃置、图和任务进程通过；不能代替完整成功。其他3开发/17正式/2远端物理/917未调用。

两份探索弃置原输入逐字绑定原账本，2次1generation/1budget；集合阶段有12份完整失败输入，0份选中分配、0份实际目标补查命令。固定epoch首/末两输入均显示两机器人当前位置有合格完整返路，但tb2所有首层终点无合格接触返路；该机器人对应13/57个首层/分层终点在其本地图均unknown，不是可删的真实障碍。融合路线仍需原本地图障碍veto，不得以地图未知直接拒绝所有融合路线，也不得以欧氏距离替代缺失路径。

只读末输入三次cold完整两层求解1.265/1.246/1.233wall秒，原实际求解约1.820/1.899wall秒；现场source有效期与sim时钟同时受负载影响，两者不是因果对照。profile有18路径距离场/358完整接触路线查询；同一callback两个采样层重复几何，后续仅可验证几何复用，预算/源戳/障碍/导航准入保持独立复查。发现更早不构成v40优化的单因素收益，同seed异步轨迹不相同。原完整结果、命令/source/env/graph/ledger/native SHA、gate错误、关闭和诊断均在JSON/gzip保留。

P3C.5已验收。P2C.1新完整集成仍未通过，原300秒/.35/.05/.1/5秒、源TTL和物理规则不变；未进入P4/ns-3/Wi-Fi/RL，917仍未暴露。
"""
(report/'20261009_p2c_v40_failed_development.md').write_text(text)
heading='## 2026-10-09 P2C.1 v40 首强制开发原任务 FAIL'
assert heading not in (w/'log.md').read_text()
with (w/'log.md').open('a') as f:
 f.write('\n\n'+heading+'\n\nd70b277 commit/push0；check_p2c_v40_freeze.py PASS，Humble+install/PYTHONNOUSERSITE1/FastDDS UDPv4清profiles，taskset -c 0-79 /usr/bin/python3 scripts/run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v40 --domain 210 --gazebo-port 20290 > log/p2c_v40_dev_forced2_runner.log 2>&1。2026-10-09T11:38:28.796855+00:00到11:43:18.964261+00:00，owner713329/observer713349 exit0/0且闭合。\n\n192.8s native FAILED/insufficient_rally_poses，detect118.7、rally/completion/nativeproof=null；两机各charge1/min14.95501051806788、Nav2总10，0接触耗尽机器人失效/task-time infra/retry。check_p2c_gate.py --run-root log/p2c/20261009_p2c_v40 --development --cases dev_forced2 --output log/p2c_v40_dev_forced2_gate.json exit1/FAIL；audit_p2c_v40_independent.py 12PASS不替代任务成功。其他3/17/2/917未调用。\n\n2lease弃置原输入逐字ledger绑定，12原集合失败全部重建PASS。diagnose_p2c_v41_rally_failure.py只读固定epoch首/末原输入：两个当前均有完整返路，远侧tb2终点无合格返路，0实际补查。三cold1.265/1.246/1.233wall秒；profile18距离场/358接触路径，来源窗口sim单位不能转为现场因果损失。所有原件/失败/命令/SHA闭合证据保留，原硬门不变。\n')
print(json.dumps(dict(status='FAIL',originals=1,audits=12,artifacts=len(artifacts),owned_closed=True)))
