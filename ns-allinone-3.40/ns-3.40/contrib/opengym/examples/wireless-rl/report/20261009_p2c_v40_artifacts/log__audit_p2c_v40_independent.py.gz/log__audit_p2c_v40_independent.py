import json,traceback
from pathlib import Path
from check_p2c_gate import (return_audit,energy_audit,lookahead_audit,ap_return_veto_audit,
    rally_assignment_audit,rally_repair_audit,exploration_travel_audit,target_survey_audit,
    observer_heading_audit,planning_lease_audit,launch_process_audit)
from p2c_native_graph import native_tf_ingress_audit
base=Path('log/p2c/20261009_p2c_v40');outputs={}
for p in sorted(base.glob('*/summary.json')):
    row=json.loads(p.read_text());d=p.parent;records=[json.loads(line) for line in (d/'ledger.jsonl').open()]
    calls={'native_return':lambda:return_audit(d/'safety_events.jsonl',True,True),
        'native_energy':lambda:energy_audit(d/'safety_events.jsonl',row['result'],True),
        'lookahead':lambda:lookahead_audit(records,True,True),'ap_return_veto':lambda:ap_return_veto_audit(records),
        'rally_assignment':lambda:rally_assignment_audit(records),'rally_repair':lambda:rally_repair_audit(records),
        'exploration_travel':lambda:exploration_travel_audit(records,True,True,True,True,True,True,True),
        'target_survey':lambda:target_survey_audit(records,True,3.,.35,True),
        'observer_heading':lambda:observer_heading_audit(records,True,3.,.35),
        'planning_leases':lambda:planning_lease_audit(records),
        'launch_processes':lambda:launch_process_audit(d),
        'native_tf_graph':lambda:native_tf_ingress_audit(json.loads((d/'native_graph.json').read_text()),row['result']['robot_count'],True)}
    out={}
    for name,call in calls.items():
        try:out[name]=call()
        except Exception as error:out[name]=dict(status='FAIL',error=repr(error),traceback=traceback.format_exc())
    outputs[row['case']]=out
Path('log/p2c_v40_independent_audits.json').write_text(json.dumps(outputs,indent=2)+'\n')
print(json.dumps({c:{n:{k:v for k,v in e.items() if k not in ('returns','robots','computation_wall_sec','post_task_cleanup_exits')} for n,e in out.items()} for c,out in outputs.items()}))
