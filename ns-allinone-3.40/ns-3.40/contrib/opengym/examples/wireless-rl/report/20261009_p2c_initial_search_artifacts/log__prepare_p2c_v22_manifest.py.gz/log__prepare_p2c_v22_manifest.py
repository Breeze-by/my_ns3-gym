import json
from pathlib import Path
from datetime import datetime,timezone

for name in ('p2c_integration_manifest.json','p2c_blackout_manifest.json'):
    path=Path('scripts')/name
    config=json.loads(path.read_text())
    config['predeclared_at_utc']=datetime.now(timezone.utc).isoformat()
    config['candidate_parent_commit']='7f616791d2e16da3e91f2fa05da3a2da46751d9c'
    config['initial_known_space_search']={
        'scope':'Complete object mission (enable_rally true) only; pure mapping and existing target reacquisition behavior stay unchanged.',
        'alternation':'Successful full mapping viewpoint enables one known-space purpose; successful full known-space viewpoint returns to mapping. Short prefixes and safety charging preserve the current purpose; ordinary navigation failure returns to mapping.',
        'history':'Only original delivered odometry and map-to-odom sources each0..2s old at recording; first position per0.5m world bin. Historical2m visit discs are search preferences, never proof of camera coverage or object absence.',
        'view':'Current known-free visible interest in a90-degree sector;16 deterministic headings. Occupied and unknown cells block sight; selected heading retained at the final Nav2 endpoint.',
        'admission':'Original0.45m endpoint/0.35m known-free route, body masks, accepted reservations, current source TTLs, full approach+qualified contact return+reaction/wait reserve and charging fairness. Empty known-space candidate set falls back to ordinary mapping; unfunded candidates request original serial charging.',
        'inputs':'Existing gateway delivered maps/poses/models only; no ground-truth target, hidden camera, native audit stream or new application packet.',
        'evidence':'Private initial_visual_search witnesses retain delivered grids, positions, source leases, historical visit inputs, sector gain/yaw, full travel/energy and scheduling score; reader reconstructs them. Complete cohort must exercise at least one such witness.',
        'limits':'Heuristic bounded current-map search preference, not exhaustive visual coverage, optimality, hardware safety or worst-case completion guarantee.'}
    path.write_text(json.dumps(config,indent=2)+'\n')
