import gzip,hashlib,json,re,subprocess,ast
from pathlib import Path

root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
parent='7f616791d2e16da3e91f2fa05da3a2da46751d9c'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def old_bytes(p):return subprocess.check_output(['git','show',f'{parent}:{p.relative_to(root)}'],cwd=root)
def archive(paths,name):
    d=report/name;d.mkdir();rows=[]
    for p in sorted(set(paths)):
        assert p.is_file(),p
        out=d/('__'.join(p.relative_to(r).parts)+'.gz');assert not out.exists()
        out.write_bytes(gzip.compress(p.read_bytes(),mtime=0));assert gzip.decompress(out.read_bytes())==p.read_bytes()
        rows.append(dict(source=str(p.relative_to(root)),archive=str(out.relative_to(report)),source_sha256=sha(p),archive_sha256=sha(out)))
    return rows

base=r/'log/p2c/20261009_p2c_v21';originals=[load(p) for p in sorted(base.glob('*/summary.json'))]
assert len(originals)==4 and all(s['git_commit']==parent for s in originals)
for s in originals:
    assert s['runner_returncode']==s['observer_returncode']==0
    assert not any(v for k,v in s.items() if k.endswith('_forced_shutdown'))
    result=s['result'];assert result['collision_events']==0 and not result['failed_robots']
    assert all(v['battery_minimum_energy']>0 for v in result['robots'].values())
    for name,h in s['evidence_sha256'].items():assert sha(Path(s['result_path']).parent/name)==h
gate=load(r/'log/p2c_v21_development_gate.json');assert gate['status']=='FAIL'
assert [e['case'] for e in gate['errors']]==['dev_lab101']
first_failure=load(r/'log/p2c_v21_dev_forced2_original_reader_gate.json');assert first_failure['status']=='FAIL'
first_repair=load(r/'log/p2c_v21_dev_forced2_gate.json');assert first_repair['status']=='PASS'
current_repair=load(r/'log/p2c_v21_dev_forced2_checked_in_reader_gate.json');assert current_repair['status']=='PASS'
independent=load(r/'log/p2c_v21_independent_audits.json');frame_stats={};totals={}
for case,out in independent.items():
    assert all(e['status']=='PASS' for n,e in out.items() if n!='native_vs_gateway_frame_samples')
    frame_stats[case]={}
    for robot,rows in out['native_vs_gateway_frame_samples'].items():
        ages=[v['native_age_sec'] for v in rows if v['native_age_sec'] is not None]
        assert ages and min(ages)>=0 and max(ages)<=2.
        frame_stats[case][robot]=dict(samples=len(ages),missing_initial_sources=len(rows)-len(ages),stale_samples=0,maximum_source_age_sec=max(ages))
    for name,a in out.items():
        if name=='native_vs_gateway_frame_samples':continue
        for key,value in a.items():
            if type(value) is int:totals[name+'/'+key]=totals.get(name+'/'+key,0)+value
old_reader=r/'log/p2c_v21_original_check_p2c_gate.py';old_reader.write_bytes(old_bytes(r/'scripts/check_p2c_gate.py'))
paths=[p for p in base.rglob('*') if p.is_file() and p.suffix!='.pyc']
paths += [p for p in (r/'log').glob('*p2c_v21*') if p.is_file() and p.suffix in ('.json','.log','.py')]
failure=dict(status='FAIL',scope='All four original development tasks',task_stack_frozen_commit=parent,
    originals=originals,strict_gate=gate,initial_reader_failure=first_failure,
    zero_based_read_only_repair=first_repair,prospective_checked_in_reader_replay=current_repair,
    independent_audits=independent,audit_totals=totals,native_tf_samples=frame_stats,
    all_owned_closed_before_edits=True,task_retries=0,
    correction='forced central COMPLETE238.3s was not native completion; original authoritative native completion248.5s is used.',
    unrun=['17 formal originals','both physical originals','917 first exposure'],
    causal_limit='Independent async development results and sparse conditional snapshots do not establish single-factor causal gains. Historical positions are preferences, never visual coverage proof.',
    artifacts=archive(paths,'20261009_p2c_v21_artifacts'))
(report/'20261009_p2c_v21_failed_development.json').write_text(json.dumps(failure,indent=2)+'\n')
(report/'20261009_p2c_v21_failed_development.md').write_text('''# P2C.1 v21 四原开发 FAIL

同冻结 `7f616791d2e16da3e91f2fa05da3a2da46751d9c` 的四个原任务自然关闭：forced2原生COMPLETE248.5s、rooms202121.6s、corridors303228.6s；lab101在288.8s才检测，FOUNDtimeout300.0s，无RALLY或原生保持证明。强制两机各charge1，四格最低能源14.18518/31.48742/33.04657/22.40906（forced/rooms/corridors/lab），零接触、耗尽、机器人失效、基础设施失败或整轮重试。正式17格、两物理断网和917未运行。中央238.3s COMPLETE曾被误称为forced原生完成；此处明确更正为实际原生248.5s，原记录不改。

首forced技术读者误把frontier group索引限定为1起点，实际当前观测位group0；原FAIL和trace保留。任务期间只用带原源码SHA守卫的忽略目录内存读取器更正为0起点，十一读取器反例测试及相同forced原数据复审PASS。四原完整修正门禁仍FAIL，仅lab原生任务失败；未来checked-in读者更正后同forced重读也PASS。不重跑或回填任务，不延长300s/5s/TTL。旧读者原字节、修复脚本和证据均无损归档。

四格独立能源/返航/前瞻/实际路径/集合分配/完整native图审计通过：16closed返航触发、5map预算、20pose租约、4本地腿、5charger returns、493能源旁录、3真实两前沿前瞻、50探索/24接续/5相对折扣。已有TF源的能源旁录全部满足2s源龄；精确逐机数量、启动未就绪样本和最大值见JSON，不把启动无源当有效姿态。已具备可审计安全/路径证据，但晚检测仍导致任务失败。这些返航检查不能替代尚未运行的远端物理断网对。

失败后的只读条件诊断使用lab实际交付地图/位姿/模型，发现若干已知空间补查候选可达且预算充足；实际目标格仍未知。该诊断缺完整原访问史、排除历史和预约，不能声称原任务反事实收益或已知目标漏检。两次诊断脚本接口错误和修正输出完整保留。P3C.5已验收；无P4/ns-3/Wi-Fi/RL。
''')

checks=(r/'log/p2c_v22_full_components.log').read_text();match=re.search(r'(\d+) passed in ([\d.]+)s',checks);assert match and 'FAILED' not in checks
built=re.search(r'4 packages finished \[([\d.]+)s\]',(r/'log/p2c_v22_build.log').read_text());assert built
source=load(r/'log/p2c_v22_source.json');assert source['status']=='PASS'
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py'
runtime=load(r/'log/p2c_v22_snapshot_runtime.json');assert runtime['status']=='PASS' and runtime['current_control_sha256']==sha(control)
for n,c in (('p2c_v22_manifest.json','p2c_integration_manifest.json'),('p2c_v22_blackout_manifest.json','p2c_blackout_manifest.json')):
    assert load(r/'log'/n)['config']==load(r/'scripts'/c)
unchanged={}
for rel in ('src/multi_robot_exploration/multi_robot_exploration/battery_manager.py',
    'src/multi_robot_exploration/multi_robot_exploration/tf_ingress_sampler.py',
    'src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py',
    'scripts/observe_p3b5.py','scripts/p2c_native_graph.py'):
    p=r/rel;assert p.read_bytes()==old_bytes(p);unchanged[rel]=sha(p)
def methods(data):
    tree=ast.parse(data);node=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='HeadquartersControl')
    return {n.name:ast.dump(n,include_attributes=False) for n in node.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
before=methods(old_bytes(control));after=methods(control.read_bytes())
changed=[name for name,value in before.items() if value!=after[name]]
assert set(changed)=={'__init__','robot_odom_callback','assign_idle_robots','record_navigation_decision','send_goal','finish_goal'},changed
qa_paths=[r/'log'/n for n in ('p2c_v22_directed_final.log','p2c_v22_directed_repaired.log','p2c_v22_full_components.log',
    'p2c_v22_build.log','p2c_v22_source.json','p2c_v22_source.log','p2c_v22_manifest.json','p2c_v22_blackout_manifest.json',
    'p2c_v22_snapshot_runtime.json','p2c_v22_snapshot_runtime.log','prepare_p2c_v22_manifest.py','prepare_p2c_v22_evidence.py')]
components=dict(status='PASS',scope='Prospective v22 components, not task integration',parent_commit=parent,
    algorithm='Alternating current frontiers and known-space90-degree views from delivered-position visit preferences',
    functional_checks=int(match[1]),component_wall_sec=float(match[2]),build_wall_sec=float(built[1]),source_audit=source,
    control_sha256=sha(control),unchanged_from_parent=unchanged,changed_central_methods=changed,
    preserved_central_methods=len(before)-len(changed),actual_ap_dds=runtime,
    native_graph_proof_reused_from_same_source='v21 actual DDS complete-graph/missing-battery/AP-leak counterexamples; observer and reader identical bytes; new task complete graphs still required.',
    initial_directed_failure='1 failed382passed: final view heading dropped by coordinated Assignment; repaired397passed with source/heading/energy forgery checks.',
    unrun=['new all4 development','new17 formal','new2 physical','917 first exposure'],
    hard_constraints='Native300s/.35m/.05mps/.1radps/5s; original TTLs/SLAM/Nav2/physics/energy margins/no episode retry retained.',
    manifest=load(r/'scripts/p2c_integration_manifest.json'),physical_manifest=load(r/'scripts/p2c_blackout_manifest.json'),
    artifacts=archive(qa_paths,'20261009_p2c_initial_search_artifacts'))
(report/'20261009_p2c_initial_search_components.json').write_text(json.dumps(components,indent=2)+'\n')
(report/'20261009_p2c_initial_search_components.md').write_text(f'''# P2C.1 v22 前沿与已知空间交替补查组件 PASS

上一冻结四开发三原生COMPLETE/一lab晚检测超时，完整FAIL和所有原始数据保留。新算法只在enable_rally的完整对象任务中，完成完整当前前沿后安排一次已知空间补查，再返回前沿探索。历史交付位姿按0.5m保留一次、2m邻域只作搜索偏好；每次用当前已知自由图的可见兴趣选择16个90度朝向之一。未知/障碍阻断视线，不能从位姿代理证明真实视野、目标不存在或视觉覆盖率。纯建图及已有目标重获行为保持。

补查仍经原0.45m终点/0.35m完整自由路径、机体、预约、最大odom/TF源龄、完整去返与等待/反应预算、串行充电；短前缀和充电保留当前目的，原导航失败回到建图。最终朝向保留到Nav2请求。私有ledger可独立重建历史源龄、sector gain/yaw、完整成本与调度分数，不是新增AP隐藏信息/应用包。全cohort须实际执行至少一条补查。

定向首1FAIL382PASS发现协调Assignment丢朝向，修正后397PASS。全功能{int(match[1])}PASS、四包build{float(built[1]):.2f}s、171保护/4已授权源码和54协议、实际AP DDS及普通/物理预声明检查PASS。六个中央方法变更，其余{len(before)-len(changed)}方法AST、本地battery/sampler/launch与只读native图工具字节保持；完整native图DDS组件证明按相同源SHA保留，新任务仍须保存其实际完整图。独立同提交新4开发/17正式/2物理尚未运行；917未暴露。原300秒/5秒保持/TTL/物理刺激不变，无最优/最坏完成/硬件保证。P3C.5已验收，无P4/ns-3/Wi-Fi/RL。
''')

note=f'2026-10-09 P2C.1 v22前沿＋已知空间补查组件PASS、待新冻结任务：v21四原3COMPLETE（forced248.5/rooms121.6/corr228.6）/lab288.8晚检测FOUNDtimeout300，零接触耗尽机器人失效，完整FAIL及0起点读者错误/只读修复保留；中央forced238.3不能称原生完成。新enable_rally完整任务在全观测位成功后交替已知自由90度补查与前沿，只用原交付位姿历史偏好，绝不称视觉覆盖或已知目标；原0.45终点/.35路线/机体预约/完整去返能源/TTL/300s/5s保持，纯建图原行为不变。{int(match[1])}功能/397定向/四包{float(built[1]):.2f}s/171保护4授权/54协议/actual AP DDS/两manifest PASS，native battery/sampler/launch/图工具字节保持。新4开发/17正式/2物理须clean pushed freeze；917未暴露，P3C.5已验收，无P4/ns-3/Wi-Fi/RL。报告20261009_p2c_initial_search_components.md与20261009_p2c_v21_failed_development.md。'
for p in (w/'AGENTS.md',w/'RESEARCH_PLAN.md',w/'IMPLEMENTATION_PLAN.md',r/'user_guide.md',r/'launch_commands.md'):
    content=p.read_text();first,rest=content.split('\n',1);p.write_text(first+'\n\n'+note+'\n'+rest)
p=root/'AGENTS.md';content=p.read_text();marker='## Current Handoff\n';assert marker in content
p.write_text(content.replace(marker,marker+'\n'+note+'\n',1))
with (w/'log.md').open('a') as f:
    f.write('\n\n## 2026-10-09 P2C.1 v21 四原FAIL与v22交替补查组件\n\n'+note+'\n\n')
    f.write('所有ROS命令在仓库ROS workspace，以系统Python3/PYTHONNOUSERSITE=1/source Humble与install、RMW FastRTPS/UDPv4运行。v21 clean pushed freeze7f61679后run_p2c_tasks --case dev_forced2/dev_lab101/dev_rooms202/dev_corridors303 --run-id 20261009_p2c_v21，domain210..213/Gazebo20290..20293；exact owner/observer commands、源/manifest/输入SHA和自然退出在原summary及无损归档。全部原任务关闭后才更改checked-in源码。首旧读者命令check_p2c_gate --run-root log/p2c/20261009_p2c_v21 --development --cases dev_forced2 FAIL，忽略目录p2c_v21_zero_based_reader.py带原SHA守卫修复0起点重读PASS；全4修复读者门禁FAIL仅lab。test_p2c_v21_zero_based_reader.py11PASS2.94s；未来checked-in修复对同forced原数据PASS。独立audit_p2c_v21_independent.py七类检查全部PASS。probe_p2c_v21_known_space脚本两次AttributeError/TypeError只读失败与最终条件诊断保留，不是模拟器重试。\n\n')
    f.write('v22 test_initial_known_search/test_exploration_resume/test_relative_frontier_travel/test_control 定向首1FAIL382PASS27.28s（协调丢yaw），修正397PASS27.52s；全pytest -q src/multi_robot_exploration/test scripts --ignore三lint文件见功能数；colcon build --symlink-install --packages-select multi_robot_interfaces multi_robot_exploration merge_map multi_robot；check_p2c_source.py --output log/p2c_v22_source.json；check_p2c_snapshot_runtime.py --output log/p2c_v22_snapshot_runtime.json；run_p2c_tasks.py普通dev_forced2与--manifest scripts/p2c_blackout_manifest.json physical_fault各--validate-only，未启动Gazebo。全部输出/脚本/参数/SHA在组件报告；新原任务未开始。\n')
print(json.dumps(dict(failure_artifacts=len(failure['artifacts']),component_artifacts=len(components['artifacts']),audit_totals=totals,native_tf_valid_samples=sum(e['samples'] for x in frame_stats.values() for e in x.values()),native_tf_missing_initial=sum(e['missing_initial_sources'] for x in frame_stats.values() for e in x.values()),components=int(match[1]),build_sec=float(built[1]),preserved_methods=components['preserved_central_methods']),indent=2))
