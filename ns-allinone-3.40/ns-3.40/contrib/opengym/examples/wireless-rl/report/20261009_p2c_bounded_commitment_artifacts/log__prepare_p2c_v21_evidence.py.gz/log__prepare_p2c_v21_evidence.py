import gzip,hashlib,json,re,subprocess
from pathlib import Path

root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
parent='c5b0f5ea149fde7376d1b045412c3865bc654ec6'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def archive(paths,name):
 d=report/name;d.mkdir();rows=[]
 for p in sorted(set(paths)):
  assert p.is_file(),p
  out=d/('__'.join(p.relative_to(r).parts)+'.gz')
  assert not out.exists()
  out.write_bytes(gzip.compress(p.read_bytes(),mtime=0));assert gzip.decompress(out.read_bytes())==p.read_bytes()
  rows.append(dict(source=str(p.relative_to(root)),archive=str(out.relative_to(report)),source_sha256=sha(p),archive_sha256=sha(out)))
 return rows
base=r/'log/p2c/20261009_p2c_v20';originals=[load(p) for p in base.glob('*/summary.json')];assert len(originals)==1
s=originals[0];assert s['git_commit']==parent and s['case']=='dev_forced2'
assert s['runner_returncode']==s['observer_returncode']==0 and not any(v for k,v in s.items() if k.endswith('_forced_shutdown'))
result=s['result'];assert not result['success'] and result['task_phase']=='RALLY' and result['termination_reason']=='timeout'
assert result['collision_events']==0 and not result['failed_robots'] and all(v['battery_charge_count']==1 and v['battery_minimum_energy']>0 for v in result['robots'].values())
for name,h in s['evidence_sha256'].items():assert sha(Path(s['result_path']).parent/name)==h
independent=load(r/'log/p2c_v20_independent_audits.json');audits=independent['dev_forced2']
assert all(e['status']=='PASS' for n,e in audits.items() if n!='native_vs_gateway_frame_samples')
frame_stats={}
for robot,rows in audits['native_vs_gateway_frame_samples'].items():
 ages=[v['native_age_sec'] for v in rows if v['native_age_sec'] is not None]
 assert len(ages)==60 and max(ages)<2.
 frame_stats[robot]=dict(samples=len(ages),stale_samples=sum(v>2. for v in ages),maximum_source_age_sec=max(ages))
gate=load(r/'log/p2c_v20_dev_forced2_gate.json');assert gate['status']=='FAIL'
ingress=load(r/'log/p2c_v20_native_ingress_audit.json');assert ingress['status']=='FAIL'
paths=[p for p in base.rglob('*') if p.is_file() and p.suffix!='.pyc']
paths += [r/'log'/n for n in ('p2c_v20_freeze_check.json','p2c_v20_dev_forced2_runner.log','p2c_v20_dev_forced2_gate.json','p2c_v20_dev_forced2_gate.log','p2c_v20_independent_audits.json','p2c_v20_independent_audits.log','audit_p2c_v20_independent.py','p2c_v20_native_ingress_audit.json')]
failure=dict(status='FAIL',scope='First forced development original only',task_stack_frozen_commit=parent,
 originals=originals,strict_gate=gate,independent_audits=independent,native_ingress_audit=ingress,native_tf_samples=frame_stats,
 all_owned_closed_before_edits=True,task_retries=0,unrun=['other3 development originals','17 formal originals','both physical originals','917 first exposure'],
 causal_limit='Saved conditional snapshot lacks original exclusions/reservations/history; no counterfactual task gain or TF-fix causal attribution.',
 artifacts=archive(paths,'20261009_p2c_v20_artifacts'))
(report/'20261009_p2c_v20_failed_development.json').write_text(json.dumps(failure,indent=2)+'\n')
(report/'20261009_p2c_v20_failed_development.md').write_text('''# P2C.1 v20 首个强制充电原任务 FAIL

冻结 `c5b0f5ea149fde7376d1b045412c3865bc654ec6`，dev_forced2原生RALLY timeout300.3s：277.9s检测、280.4s集合，无COMPLETE或5s原生保持证明。两机器人各充电一次，最低14.159669，零接触/耗尽/机器人失效；owner与observer0自然关闭。严格门禁FAIL完整保留，其他三开发/17正式/两物理/917未调用，无重试、回填或门槛放宽。

全部独立原输入检查PASS：4返航触发closed、2map预算/5pose租约/1local导航腿/2charger return，121能源旁录、20AP返路否决、1成功集合分配、26实际探索/17接续/2相对路径折扣。两个机器人各60份5s能源旁录无TF过期，最大源龄0.199/0.213s；补充actual graph审计FAIL：原启动图缺tb2/battery_manager，不能替代完整native绑定证明。原图不改；新候选增加只读完整图旁录，缺图仍FAIL。这些工程证据不代替原生任务完成，也不是独立远端断网返航证明。

原2237.982s交付快照中的接续探索收益26.8323、名义/实际路径11.4167m、完整能源预算36.9336；原2272.082s接续收益31.4167、路径4.1671m、预算22.1925。低收益旧意图当时有绝对排序优先级；有限2倍偏好是下一候选改变，不修改原运行。保存的组件快照只能支持条件排序/预算判断，缺原全部排除历史与预约，不能作为原任务反事实或异步任务时间的单因素收益。全部命令、源/配置/SHA、原结果/账本/图/native/live及失败trace无损归档见JSON。P3C.5已验收，无P4/ns-3/Wi-Fi/RL。
''')
checks=(r/'log/p2c_v21_full_components_final.log').read_text();match=re.search(r'(\d+) passed in ([\d.]+)s',checks);assert match and 'FAILED' not in checks
built=re.search(r'4 packages finished \[([\d.]+)s\]',(r/'log/p2c_v21_build.log').read_text());assert built
source=load(r/'log/p2c_v21_source.json');assert source['status']=='PASS'
control=r/'src/multi_robot_exploration/multi_robot_exploration/control.py'
runtime=load(r/'log/p2c_v21_snapshot_runtime.json');assert runtime['status']=='PASS' and runtime['current_control_sha256']==sha(control)
for n,c in (('p2c_v21_manifest_final.json','p2c_integration_manifest.json'),('p2c_v21_blackout_manifest_final.json','p2c_blackout_manifest.json')):
 assert load(r/'log'/n)['config']==load(r/'scripts'/c)
identity=load(r/'log/p2c_v21_method_identity.json');assert identity['status']=='PASS'
graph_runtime=load(r/'log/p2c_v21_native_graph_runtime.json');assert graph_runtime['status']=='PASS'
assert graph_runtime['observer_sha256']==sha(r/'scripts/observe_p3b5.py') and graph_runtime['reader_sha256']==sha(r/'scripts/p2c_native_graph.py')
paths=[r/'log'/n for n in ('p2c_v21_directed.log','p2c_v21_directed_final.log','p2c_v21_full_components.log','p2c_v21_full_components_final.log','p2c_v21_graph_directed.log','p2c_v21_build.log','p2c_v21_source.json','p2c_v21_source.log','p2c_v21_snapshot_runtime.json','p2c_v21_snapshot_runtime.log','p2c_v21_manifest.json','p2c_v21_blackout_manifest.json','p2c_v21_method_identity.json','p2c_v21_manifest_final.json','p2c_v21_blackout_manifest_final.json','p2c_v21_native_graph_runtime.json','p2c_v21_native_graph_runtime.log','p2c_v21_native_graph_runtime.graph.json','p2c_v21_native_graph_runtime.events.jsonl','prepare_p2c_v21_evidence.py')]
component=dict(status='PASS',scope='Bounded continuation components only; new tasks pending',parent=parent,
 functional_checks=int(match[1]),component_seconds=float(match[2]),four_package_build_seconds=float(built[1]),
 continuation_weight=2.,method_identity=identity,source_audit=source,actual_ap_runtime=runtime,actual_graph_runtime=graph_runtime,
 source_sha256={str(p.relative_to(root)):sha(p) for p in (control,r/'scripts/check_p2c_gate.py',r/'scripts/p2c_native_graph.py',r/'scripts/observe_p3b5.py',r/'scripts/run_p3c5_audit.py',r/'scripts/p2c_integration_manifest.json',r/'scripts/p2c_blackout_manifest.json',r/'src/multi_robot_exploration/test/fixtures/p2c_v20_low_value_continuation.json')},
 native_constants_and_physical_stimulus_unchanged=True,holdout917_unexposed=True,
 required_next=['New clean pushed freeze','All4 new development originals','17 formal originals','Both new physical originals at same formal commit'],
 artifacts=archive(paths,'20261009_p2c_bounded_commitment_artifacts'))
(report/'20261009_p2c_bounded_commitment_components.json').write_text(json.dumps(component,indent=2)+'\n')
handoff=f'2026-10-09 P2C.1 v21有限接续组件PASS、待新冻结任务：v20首forced原RALLY timeout300.3/检测277.9/两机各charge1/min14.159669/零接触耗尽机器人失效，strict FAIL与全部原输入保留；4closed返航/121能量/26探索17接续重建PASS；旧启动图缺tb2电池节点的native绑定审计FAIL原样保留，各60native TF样本零过期。新有用接续仅2倍效用，不再绝对优先，仍原1.2m/gain200与20%/完整机体预约能源TTL准入。独立读者补重建group/base/reuse/weight/score，有限条件快照更高收益选择非因果任务结果。{match[1]}功能/四包{built[1]}s/171保护4授权/54协议/actual AP DDS/两manifest/actual完整native图DDS反例PASS，70其他中央方法AST/native battery/sampler/launch保持。新4开发/17正式/2物理待clean pushed freeze，917未暴露；P3C.5已验收，无P4/ns-3/Wi-Fi/RL。报告20261009_p2c_bounded_commitment_components.md及20261009_p2c_v20_failed_development.md。'
(report/'20261009_p2c_bounded_commitment_components.md').write_text(f'''# P2C.1 v21 有限前沿接续评分

组件PASS，任务门禁仍待新冻结原始批次。v20 forced超时FAIL和全部历史失败保留，不重用旧成功格。新候选仅改变普通探索候选排序：在当前已交付地图中仍有用、距离旧意图≤1.2m、gain>max(200,20%旧gain)、完整能源可负担的接续候选，评分为原adjusted_utility的2倍。其他候选为原评分，收益明显更高的新前沿可以替代旧意图；原成功短前缀记忆、普通失败清理、真正到位清理及充电公平机制保持。

原名义路径效用/近同伴软折扣保留，实际派发仍重新检查完整机体绕行、已接受导航预约、全程往返能源、源TTL与原短腿。排序用名义utility，不能视为真实导航时间预测或全局最优。追加私有group id/size、原排除点、base utility、有限权重和最终score，读者从交付地图重建frontier group/gain/nominal distance，再核验reuse/base/relative factor/weight/score；同时篡改base和score、伪造group/exclusions等坏例拒绝。该旁录不是新增AP观测或无线消息；未保留所有原候选与历史，故不宣称原时刻全局最大选择已证明。

103探索定向PASS13.14s（初102PASS8.91s保留），追加完整图采集检查，完整{match[1]}PASS{match[2]}s、四包{built[1]}s、171保护/4授权/54协议与actual AP DDS/domain221 PASS；普通/物理manifest validate-only未启动Gazebo。旧启动图在原required application集合发现后即捕获，未要求native节点。新可选只读observer待全部原生电池消息与完整原required节点/TF端点可见才另存native_graph.json；不延迟任务或更新源时间，原启动图保持。源摘要绑定observer/helper，缺图或未知来源仍FAIL。除assign_idle_robots，70其他中央方法AST、整个native电池、TF入口与launch逐字节保持。保存v20原交付地图的条件夹具中，新评分选择更高收益且完整预算合格的新前沿，旧v18有价值接续夹具仍通过；均非完整原始history/reservation反事实，更不代替任务成功。

需要新clean pushed freeze后先全部4开发；通过后同提交17正式、两原物理远端断网返航，917最后首次暴露。300s/.35m/.05mps/.1radps/5s、所有TTL、SLAM/Nav2、物理模型与旧50/60..250/62..248/1.1m/.5m刺激保持。P3C.5用户已验收，P4/ns-3/Wi-Fi/RL未开始。源码/验证/无损SHA附件见JSON。
''')
for p,anchor in ((root/'AGENTS.md','## Current Handoff\n'),(w/'AGENTS.md','# wireless-rl Codex Memory\n')):
 t=p.read_text();assert anchor in t;p.write_text(t.replace(anchor,anchor+'\n'+handoff+'\n',1))
for p in (w/'IMPLEMENTATION_PLAN.md',w/'RESEARCH_PLAN.md',r/'user_guide.md',r/'launch_commands.md'):
 t=p.read_text();line,rest=t.split('\n',1);p.write_text(line+'\n\n'+handoff+'\n'+rest)
(w/'log.md').open('a').write(f'''

### 2026-10-09 P2C.1 v20 forced original FAIL / v21 bounded continuation components

- v20 clean pushedfreeze `{parent}`; ROS Humble canonical workspace/system Python, PYTHONNOUSERSITE1/PYTHONPATH source+test+scripts/FastDDS UDPv4/unset profiles. Exact `taskset -c 0-79 /usr/bin/python3 scripts/run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v20 --domain 210 --gazebo-port 20290 > log/p2c_v20_dev_forced2_runner.log 2>&1`: original RALLY timeout300.3/detect277.9/rally280.4/eachcharge1/min14.159669240/0contacts exhaustion failedrobots, owner/observer0 natural. No other3 development/17formal/2physical/917, no task retry/backfill, no tracked edits until original closed.
- Strict `taskset -c 0-79 /usr/bin/python3 scripts/check_p2c_gate.py --run-root "$PWD/log/p2c/20261009_p2c_v20" --development --cases dev_forced2 --output log/p2c_v20_dev_forced2_gate.json > log/p2c_v20_dev_forced2_gate.log 2>&1` FAIL native success assertion retained. Read-only `taskset -c 0-79 /usr/bin/python3 log/audit_p2c_v20_independent.py > log/p2c_v20_independent_audits.log 2>&1` all7 independent PASS:4closed returns/2map5pose1local/121energy/20APveto/1chosenrally/26exploration17resume2discount. NativeTF60samples each max.199/.213 no stale. Frozen graph `native_tf_ingress_audit(json.loads(graph.read_text()),2,True)` FAIL missingtb2/battery_manager; complete native binding unproved, original unchanged; new optional read-only complete graph capture is source-bound, output log/p2c_v20_native_ingress_audit.json. One auxiliary read attempted nonexistent result key phase_time_sec (KeyError); no data/helper/task mutation or experiment start.
- v21 finite2x continuation replaces absolute resume ranking, original useful/funded/body/accepted routes/source/energy guards and all native/physical constants preserved; adds reconstructable private group/reuse/base/weight/score. Only central assign_idle_robots differs;70other methodsAST/native battery SHA `{identity['unchanged_native_battery_sha256']}`/sampler/launch unchanged. Saved2237.982s delivered snapshot only conditional inputs (not full original history/reservations), no causal task improvement claim.
- `taskset -c 0-79 /usr/bin/python3 -m pytest -q src/multi_robot_exploration/test/test_exploration_resume.py src/multi_robot_exploration/test/test_relative_frontier_travel.py src/multi_robot_exploration/test/test_exploration_charging.py > log/p2c_v21_directed_final.log 2>&1`103PASS13.14s; earlier102PASS8.91s retained. Final full same pytest src/multi_robot_exploration/test scripts with --ignore copyright/flake8/pep257 files >log/p2c_v21_full_components_final.log {match[1]}PASS{match[2]}s. `colcon build --symlink-install --packages-select multi_robot_interfaces multi_robot_exploration merge_map multi_robot > log/p2c_v21_build.log 2>&1` four packages{built[1]}s. `/usr/bin/python3 scripts/check_p2c_source.py --output log/p2c_v21_source.json > log/p2c_v21_source.log 2>&1` PASS171protected/4scoped/54protocol.
- `taskset -c 0-79 /usr/bin/python3 scripts/check_p2c_snapshot_runtime.py --output log/p2c_v21_snapshot_runtime.json > log/p2c_v21_snapshot_runtime.log 2>&1`actualAPDDSdomain221 PASS. `/usr/bin/python3 scripts/run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v21_validate --domain210 --gazebo-port20290 --validate-only > log/p2c_v21_manifest.json` and same --manifest scripts/p2c_blackout_manifest.json --case physical_fault --run-id 20261009_p2c_v21_physical_validate --domain219 --port20299 >log/p2c_v21_blackout_manifest.json PASS/no simulator start. Both manifests prospectively predeclare2x and parentc5; scenarios/horizon/grace/physical stimulus unchanged.
- Supplemental `taskset -c 0-79 /usr/bin/python3 scripts/check_p2c_native_graph_runtime.py --output log/p2c_v21_native_graph_runtime.json > log/p2c_v21_native_graph_runtime.log 2>&1` actual DDS/domain216 synthetic endpoint PASS:missing native node/AP leak rejected, complete source-preserving graph captured. New optional observer graph command/helper/observer digests bound to originals; original early graph and FAIL retained. New scripts/test_p2c_native_tf_ingress.py missing-node negatives and graph directed checks >log/p2c_v21_graph_directed.log PASS. Final normal/physical validate-only paths *_final.json include optional graph observer args; no task launch.
- `/usr/bin/python3 log/prepare_p2c_v21_evidence.py`: v20 failed raw and independent/current component inputs losslessly gzip/SHA archived; component PASS does not complete all4dev/17formal/2physical.917 unexposed. P3C.5 accepted, noP4/ns-3/Wi-Fi/RL.
''')
print(json.dumps(dict(failed_artifacts=len(failure['artifacts']),component_artifacts=len(component['artifacts']),functional_checks=component['functional_checks'])))
