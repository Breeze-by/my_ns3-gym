"""Actual DDS readiness adapter checks; no Gazebo, task goals or safety claim."""
import hashlib,json,os,sys,time
from pathlib import Path
import rclpy
from rclpy.action import ActionServer
from rclpy.node import Node
from rclpy.parameter import Parameter
from nav2_msgs.action import NavigateToPose
from nav_msgs.msg import OccupancyGrid
from rosgraph_msgs.msg import Clock
import stage_p2c_return_probe as wrapper

directory=Path('log/p2c_return_readiness_runtime');directory.mkdir(exist_ok=False)
config=Path('scripts/p2c_blackout_manifest.json').resolve()
sys.argv=[str(Path(wrapper.__file__).resolve()),'--config',str(config),
    '--output',str(directory/'staging.jsonl'),'--owner-pid',str(os.getpid())]
checks=[]
def original_main():
    # Exercise the exact function-local import used by the immutable fixture.
    from rclpy.action import ActionClient
    rclpy.init()
    node=Node('p2c_readiness_component',parameter_overrides=[Parameter('use_sim_time',value=True)])
    servers=[ActionServer(node,NavigateToPose,f'/gateway/{robot}/navigate_to_pose',
        lambda handle:NavigateToPose.Result()) for robot in ('tb1','tb2')]
    clients=[ActionClient(node,NavigateToPose,f'/gateway/{robot}/navigate_to_pose') for robot in ('tb1','tb2')]
    clocks=node.create_publisher(Clock,'/clock',10)
    publishers=[node.create_publisher(OccupancyGrid,f'/{robot}/global_costmap/costmap',1) for robot in ('tb1','tb2')]
    clock=Clock();clock.clock.sec=100
    message=OccupancyGrid();message.header.frame_id='map';message.header.stamp.sec=100
    message.info.width=message.info.height=100;message.info.resolution=.1
    message.info.origin.orientation.w=1.;message.data=[0]*10000
    def observe(label,expected,publish=True):
        deadline=time.monotonic()+3.
        while time.monotonic()<deadline:
            clocks.publish(clock)
            if publish:
                for publisher in publishers:publisher.publish(message)
            rclpy.spin_once(node,timeout_sec=.02)
        actual=[client.server_is_ready() for client in clients]
        assert actual==[expected]*2,(label,actual)
        checks.append(dict(label=label,actual=actual,clock=clock.clock.sec,map_stamp=message.header.stamp.sec))
    try:
        observe('missing map',False,publish=False)
        observe('startup default bounds omit original negative stage pose',False)
        message.info.origin.position.x=message.info.origin.position.y=-5.
        observe('valid actual DDS costmap and action servers',True)
        message.header.stamp.sec=101
        observe('future map is unavailable',False)
        message.header.stamp.sec=100;clock.clock.sec=103
        observe('stale map is unavailable',False)
        return 0
    finally:
        for client in clients:client.destroy()
        for server in servers:server.destroy()
        node.destroy_node();rclpy.shutdown()

original=wrapper.original.main;wrapper.original.main=original_main
try:assert wrapper.main()==0
finally:wrapper.original.main=original
out=dict(status='PASS',scope=__doc__,domain=os.environ['ROS_DOMAIN_ID'],checks=checks,
    wrapper_sha256=hashlib.sha256(Path(wrapper.__file__).read_bytes()).hexdigest(),
    unchanged_base_sha256=hashlib.sha256(Path(wrapper.original.__file__).read_bytes()).hexdigest(),
    readiness_sha256=hashlib.sha256((directory/'nav2_readiness.jsonl').read_bytes()).hexdigest())
Path('log/p2c_return_readiness_runtime.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
