import gzip,hashlib,json,re,subprocess
from pathlib import Path
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
parent='723a844e54e6f28501d59fc4ed2785f5f2d65592'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
full=re.search(r'(\d+) passed in ([\d.]+)s',(r/'log/p2c_return_readiness_full_tests.log').read_text());assert full
targeted=re.search(r'(\d+) passed in ([\d.]+)s',(r/'log/p2c_return_readiness_targeted_final_tests.log').read_text());assert targeted and int(targeted[1])==93
build=re.search(r'4 packages finished \[([\d.]+)s\]',(r/'log/p2c_return_readiness_build.log').read_text());assert build
runtime=load(r/'log/p2c_return_readiness_runtime.json');source=load(r/'log/p2c_return_readiness_source.json')
assert runtime['status']==source['status']=='PASS' and len(runtime['checks'])==5
wrapper=r/'scripts/stage_p2c_return_probe.py';base=r/'scripts/stage_p3b5_return_probe.py'
assert runtime['wrapper_sha256']==sha(wrapper) and runtime['unchanged_base_sha256']==sha(base)
held={}
for rel in ('src/multi_robot_exploration/multi_robot_exploration/control.py',
            'src/multi_robot_exploration/multi_robot_exploration/battery_manager.py',
            'src/multi_robot_exploration/multi_robot_exploration/tf_ingress_sampler.py',
            'src/multi_robot/launch/gazebo_multirobot_mapping_with_nav2.launch.py',
            'scripts/stage_p3b5_return_probe.py','scripts/observe_p3b5_return_physics.py'):
    p=r/rel;old=subprocess.check_output(['git','show',parent+':'+str(p.relative_to(root))],cwd=root)
    assert old==p.read_bytes();held[rel]=sha(p)
for label in ('ideal','fault'):
    row=load(r/f'log/p2c_return_readiness_{label}_declaration.json')
    config=load(r/'scripts/p2c_blackout_manifest.json');assert row['config']==config
    assert str(wrapper) in row['staging_command'] and row['staging_content_sha256']==sha(wrapper)
    assert config['staging_base_content_sha256']==sha(base)
    command=row['command'];assert command[command.index('--evaluation-duration')+1]=='300'
    assert '--enable-return-probe-pause' in command
files=[p for p in (r/'log').glob('*p2c_return_readiness*') if p.is_file()]
files.extend(p for p in (r/'log/p2c_return_readiness_runtime').rglob('*') if p.is_file())
files.append(Path(__file__))
destination=report/'20261009_p2c_return_readiness_artifacts';assert not destination.exists();destination.mkdir();artifacts=[]
for p in sorted(set(files)):
    q=destination/('__'.join(p.relative_to(r).parts)+'.gz')
    q.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0));assert gzip.decompress(q.read_bytes())==p.read_bytes()
    artifacts.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(q.relative_to(report)),archive_sha256=sha(q)))
out=dict(status='PASS',scope='Prospective preparation adapter and read-only reader; new physical originals pending',
    parent_commit=parent,full_suite_checks=int(full[1]),full_suite_wall_sec=float(full[2]),
    targeted_checks=int(targeted[1]),targeted_wall_sec=float(targeted[2]),build_wall_sec=float(build[1]),
    actual_dds=runtime,source_audit=source,unchanged_task_and_stimulus=held,artifacts=artifacts)
(report/'20261009_p2c_return_readiness_components.json').write_text(json.dumps(out,indent=2)+'\n')
(report/'20261009_p2c_return_readiness_components.md').write_text(f'''# P2C.1 原生准备就绪与读者修复组件 PASS

独立原对子723a844理想准备Nav2 ABORTED/exit1，故整体FAIL；故障原格独立实际返航审核PASS。两份原数据、读者null相机和相对路径绑定错误均保留在20261009_p2c_return_characterization_failed.md/.json。主v41 PARTIAL279.1也仍为FAIL，不回填。

新stage_p2c_return_probe.py仅在准备器边界适配原stage_p3b5_return_probe.py的函数内ActionClient导入，退出必恢复。原准备器/物理观察器及全部任务control/native/TF/launch字节与723a844完全相同。每次原网关短腿前等待真实Nav2全局costmap：map坐标、有限完整无旋转、原source header不未来且年龄≤2秒、范围包含两个原准备位置。只验证导航装置就绪，原received map/pose/TF/battery source TTL、known-free路径和机体安全仍由原准备器检查；Nav2地图不会进入AP观察、能量许可或无线模型。

原Nav2配置发布完整全局costmap（0.5Hz），未改参数。缺图/默认范围/未来/过期都会等待，原50秒准备期限内仍未准备则FAIL；abort无重试。每次就绪日志保留原stamp/范围/shape，独立读者核对每条原staging_requested前实际就绪；新run必须冻结wrapper与原base SHA，legacy原证据仍用原准备器审核。

真实ROS/DDS domain220的两个真实gateway ActionServer与costmap/clock publisher验证5情形：缺图false、默认范围false、有效true、未来false、过期false。没有发送Nav2动作、没有Gazebo/真实移动，不代替独立新两原格。

93定向PASS{float(targeted[2]):.2f}s，完整{int(full[1])}PASS{float(full[2]):.2f}s，四包build{float(build[1]):.2f}s，171保护文件/4已有授权变化/54静态协议与原native/constants/Future约束PASS；两manifest command validate-only一致。源/原source绑定和全部组件输出见JSON/gzip。

本提交后需新clean pushed freeze，独立run-id20261009_p2c_return_ready的ideal/fault原格，分别domain218/219与Gazebo20298/20299。所有失败保留；即使受控对子PASS，完整P2C.1B仍需新4开发→同源17正式+2物理，不改变300秒/5秒/源TTL，不复用接受的P3C.5任务作为当前基线。917尚未执行，无P4/ns-3/Wi-Fi/RL。
''')
note=f'2026-10-09 P2C.1当前完整集成FAIL：v41冻结723a844首forced PARTIAL279.1/success=false/tb2正电量失路，双机各charge1，0接触/耗尽/任务期infra；12审计PASS不替代任务成功。独立安全原对子也FAIL（ideal准备ABORTED，fault实际返航独立PASS）。新Nav2准备就绪适配和只读null/路径读者修复{int(full[1])}功能/93定向/四包{float(build[1]):.2f}s/171保护54协议/实际DDS5情形PASS，任务/native/原准备刺激字节不变；新两原格待clean pushed freeze。40个有主任务版本共76原任务不能跨版本汇总成功率；余3开发/17正式/917未调用。P3C.5已验收，无P4/ns-3/Wi-Fi/RL。报告20261009_p2c_v41_failed_development.md、20261009_p2c_return_characterization_failed.md、20261009_p2c_return_readiness_components.md；旧pending记录为历史。'
for p in (root/'AGENTS.md',w/'AGENTS.md',w/'RESEARCH_PLAN.md',w/'IMPLEMENTATION_PLAN.md',r/'user_guide.md',r/'launch_commands.md'):
    lines=p.read_text().splitlines();indices=[i for i,line in enumerate(lines) if line.startswith('2026-10-09 P2C.1 v41')]
    assert len(indices)==1,(p,indices);lines[indices[0]]=note;p.write_text('\n'.join(lines)+'\n')
with (w/'log.md').open('a') as f:
    f.write('\n\n## 2026-10-09 P2C.1 新准备就绪适配组件 PASS\n\n'+note+'\n\n')
    f.write(f'Humble+install/PYTHONNOUSERSITE1/FastDDS UDPv4清profiles；/usr/bin/python3 -m pytest -q scripts/test_p2c_staging_readiness.py scripts/test_p2c_blackout.py scripts/test_p3c5_gate.py src/multi_robot_exploration/test/test_observer_healthy_confirmation.py 93PASS{float(targeted[2]):.2f}s。相同完整功能命令（排除copyright/flake8/pep257）{int(full[1])}PASS{float(full[2]):.2f}s，四包colcon build --symlink-install --packages-select multi_robot_interfaces multi_robot_exploration merge_map multi_robot {float(build[1]):.2f}s。check_p2c_source.py --output log/p2c_return_readiness_source.json PASS；ROS_DOMAIN_ID220 log/check_p2c_return_readiness_runtime.py 真实DDS双ActionServer/costmap/clock5情形PASS，无Gazebo或导航请求。两个run_p2c_tasks --manifest scripts/p2c_blackout_manifest.json --case physical_ideal/physical_fault --run-id20261009_p2c_return_ready --domain218/219 --gazebo-port20298/20299 --validate-only PASS；未启动新任务。原stage_p3b5/physics/control/native/TF/launch bytes和原case/50s准备/60..250断网/62..248/.5m/1.1m刺激保持。下一新对子须clean pushed freeze，主任务FAIL保持。\n')
print(json.dumps(dict(status='PASS',checks=int(full[1]),build_sec=float(build[1]),artifacts=len(artifacts))))
