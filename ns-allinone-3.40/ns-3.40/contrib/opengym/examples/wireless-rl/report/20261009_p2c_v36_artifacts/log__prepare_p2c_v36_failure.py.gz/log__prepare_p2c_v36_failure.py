import collections, gzip, hashlib, json, os
from pathlib import Path
from datetime import datetime, timezone

root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
base=r/'log/p2c/20261009_p2c_v36';paths=list(base.glob('*/summary.json'));assert len(paths)==1
p=paths[0];s=json.loads(p.read_text());z=s['result'];freeze='7a7fde63f0be9e75ce6e3f59899c956c709dd0b2'
assert s['git_commit']==freeze and s['case']=='dev_forced2' and not z['success']
assert z['collision_events']==0 and not z['failed_robots']
assert s['runner_returncode']==s['observer_returncode']==0
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
closure={}
for key in ('owner_pid','observer_pid'):
 try:os.kill(s[key],0)
 except ProcessLookupError:closure[key]=dict(pid=s[key],closed=True)
 else:raise AssertionError(('live',key))
closure['checked_at_utc']=datetime.now(timezone.utc).isoformat()
(r/'log/p2c_v36_closed_before_edit.json').write_text(json.dumps(closure,indent=2)+'\n')
for name,digest in s['evidence_sha256'].items():assert sha(p.parent/name)==digest
gate=json.loads((r/'log/p2c_v36_dev_forced2_gate.json').read_text());assert gate['status']=='FAIL'
audits=json.loads((r/'log/p2c_v36_independent_audits.json').read_text())
assert len(audits['dev_forced2'])==12 and all(v['status']=='PASS' for v in audits['dev_forced2'].values())
rows=[json.loads(line) for line in (p.parent/'ledger.jsonl').open()]
leases=collections.Counter(e['stage'] for e in rows if e.get('event')=='coordinator_planning_lease_expired')
snapshot_binding={}
snapshots=list((r/'log').glob('p2c_v36_dev_forced2_*snapshot.json'))
for q in snapshots:
 e=json.loads(q.read_text());assert any(x==e for x in rows)
 snapshot_binding[q.name]=dict(snapshot_sha256=sha(q),original_ledger_sha256=sha(p.parent/'ledger.jsonl'),ledger_index=e['ledger_index'])
files=[q for q in base.rglob('*') if q.is_file() and q.suffix!='.pyc']+snapshots
files += [r/'log'/name for name in ['check_p2c_v36_freeze.py','p2c_v36_freeze_check.json',
  'p2c_v36_dev_forced2_runner.log','p2c_v36_dev_forced2_gate.log','p2c_v36_dev_forced2_gate.json',
  'audit_p2c_v36_independent.py','p2c_v36_independent_audits.json','p2c_v36_independent_audits.log',
  'peek_p2c_v36_tasks.py','p2c_v36_task_diagnosis.json','p2c_v36_closed_before_edit.json','prepare_p2c_v36_failure.py']]
assert all(q.exists() for q in files)
destination=report/'20261009_p2c_v36_artifacts';assert not destination.exists();destination.mkdir();artifacts=[]
for q in sorted(set(files)):
 a=destination/('__'.join(q.relative_to(r).parts)+'.gz');a.write_bytes(gzip.compress(q.read_bytes(),compresslevel=6,mtime=0))
 assert gzip.decompress(a.read_bytes())==q.read_bytes()
 artifacts.append(dict(source=str(q.relative_to(root)),source_sha256=sha(q),archive=str(a.relative_to(report)),archive_sha256=sha(a)))
out=dict(status='FAIL',scope='First required forced-development original failed; other3 development/formal17/physical2/917 not invoked',
 task_stack_frozen_commit=freeze,original=s,first_required_gate=gate,independent_audits=audits,
 all_owned_closed=closure,planning_lease_aborts=dict(leases),exact_snapshot_binding=snapshot_binding,
 task_retries=0,artifacts=artifacts)
(report/'20261009_p2c_v36_failed_development.json').write_text(json.dumps(out,indent=2)+'\n')
text='''# P2C.1 v36 首强制原任务 FAIL

冻结7a7fde63f0be9e75ce6e3f59899c956c709dd0b2，control SHAbf09ab831a02c6f069aa354d82234715849c23a32e096d94e158cb3d4345dd28。首required forced2在249.9秒确认目标、251.7秒进入RALLY，300.4秒仍未原生完成；success=false、completion_time=null、native_rally_hold_proof=null。28个原生Nav2计数，中央22次探索(10mapping/12visual)+5rally；二者是不同采样/路径计数，不能混为同一数字。两机各charge1，最低6.940767563292112，零接触/耗尽/failed机器人/任务时子进程失败；owner/observer自然exit0并已关闭。

中央完整选位耗时.809wall/.7sim秒，本次选位计算已完成；tb2检测时在另一侧，原RALLY只剩约48秒。原控制下51次planning lease弃置(29generation/19budget/3route)仍存在，原输入显示两机空闲、tb1约73/tb2约8能量、87条预测朝向历史；固定epoch重建会请求tb2充电，但全轮约2.4秒超过原1.3–1.5秒剩余lease。它是条件计算瓶颈证据，不是原轨迹唯一因果。

十二独立native return/energy/charge/AP veto/探索/集合/来源/进程/nativeTF审计PASS，首required strict仍FAIL；后三dev和正式17/真实物理2/917从未调用。原task300秒、真实5秒保持、所有源TTL与安全门限不放宽；无任务重试或原成功回填。任务结束后的两个Nav2 lifecycle manager按原launch关闭升级至SIGKILL，退出-9；原日志完整保留。此为post-task child cleanup，不能写成全部ROS children自然干净退出；原owner/observer退出0，task-time child exit审计PASS。

P2C.1仍未完成；P3C.5已验收，无P4/ns-3/Wi-Fi/RL。下一候选须重新clean pushed freeze并从新首强制原任务开始。所有完整命令/source/evidence SHA与原ledger逐字snapshot绑定见JSON与gzip旁证。
'''
(report/'20261009_p2c_v36_failed_development.md').write_text(text)
heading='## 2026-10-09 P2C.1 v36 首强制开发原任务 FAIL';assert heading not in (w/'log.md').read_text()
with (w/'log.md').open('a') as f:
 f.write('\n\n'+heading+'\n\n7a7fde6 commit/push0，check_p2c_v36_freeze.py PASS：Humble+install/PYTHONNOUSERSITE1/FastDDS UDPv4清profiles，taskset -c 0-79 /usr/bin/python3 scripts/run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v36 --domain 210 --gazebo-port 20290 > log/p2c_v36_dev_forced2_runner.log 2>&1。原完整launch/observer/configuration命令在summary/manifest。\n\n')
 f.write(f"原生RALLY timeout300.4；detect249.9/rally251.7/COMPLETE=null，Nav2{z['nav_goal_count']}/每机charge1/min{z['battery_minimum_energy']}，0接触耗尽failed/task-time child failure/infra/retry。owner{s['owner_pid']}/observer{s['observer_pid']} exit0/0且关闭；两个post-task lifecycle manager -9原日志保留，不称所有child自然关闭。其他3dev/17formal/2physical/917未调用。\n\n")
 f.write('check_p2c_gate.py --run-root log/p2c/20261009_p2c_v36 --development --cases dev_forced2 --output log/p2c_v36_dev_forced2_gate.json exit1/FAIL，12独立audit PASS。lease51(29gen19budget3route)。只读实际选位.809wall/.7sim，已不是本次未能及时进入RALLY的原因。原弃置输入87views/两机idle、约73/8能量，profile_p2c_v37_forced_inputs.py固定epoch完整请求tb2charge预算15.29/15.35，cold约2.4s/204planning/819return calls；初fixture漏exploration_charge_budgets属性失败保留，补齐原transport属性后exit0。prototype_p2c_v37_battery_bounds.py只按当前位置hold预算7.5<E7.8–8.6，所有候选upper仍1，约2.4s未改善，原决策完全同；作为无效原型保留，不声称提速。报告20261009_p2c_v36_failed_development.md/.json；源TTL/300s/5s/安全保持，无P4/ns-3/Wi-Fi/RL。\n')
print(json.dumps(dict(status='FAIL',originals=1,audits=12,artifacts=len(artifacts),owned_closed=True)))
