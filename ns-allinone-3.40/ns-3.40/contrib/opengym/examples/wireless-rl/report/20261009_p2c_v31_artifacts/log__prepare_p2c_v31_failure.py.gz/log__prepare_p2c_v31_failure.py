import gzip,hashlib,json,os
from pathlib import Path
from datetime import datetime,timezone
root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
base=r/'log/p2c/20261009_p2c_v31';paths=list(base.glob('*/summary.json'));assert len(paths)==1
s=json.loads(paths[0].read_text());result=s['result'];assert s['git_commit']=='f455c2ee299501a61301318d61a4fd3ce8ad9fb2'
assert not result['success'] and result['task_phase']=='EXPLORE' and result['nav_goal_count']==3 and result['battery_total_charges']==1
assert result['collision_events']==0 and not result['failed_robots'] and s['runner_returncode']==s['observer_returncode']==0
closure={}
for key in ('owner_pid','observer_pid'):
    try:os.kill(s[key],0)
    except ProcessLookupError:closure[key]=dict(pid=s[key],closed=True)
    else:raise AssertionError(('owned process still live',key,s[key]))
closure['checked_at_utc']=datetime.now(timezone.utc).isoformat()
(r/'log/p2c_v31_closed_before_edit.json').write_text(json.dumps(closure,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name,digest in s['evidence_sha256'].items():assert sha(paths[0].parent/name)==digest
gate=json.loads((r/'log/p2c_v31_dev_forced2_gate.json').read_text());assert gate['status']=='FAIL'
audits=json.loads((r/'log/p2c_v31_independent_audits.json').read_text());assert all(v['status']=='PASS' for v in audits['dev_forced2'].values())
files=[p for p in base.rglob('*') if p.is_file() and p.suffix!='.pyc']
names=('check_p2c_v31_freeze.py','p2c_v31_freeze_check.json','p2c_v31_dev_forced2_runner.log','p2c_v31_dev_forced2_gate.json','p2c_v31_dev_forced2_gate.log',
    'audit_p2c_v31_independent.py','p2c_v31_independent_audits.json','p2c_v31_independent_audits.log','peek_p2c_v31_tasks.py','p2c_v31_closed_before_edit.json',
    'p2c_v31_actual_planning_snapshot.json','profile_p2c_v31_actual_snapshot.py','p2c_v31_actual_assignment.prof','p2c_v31_actual_assignment_profile.txt',
    'p2c_v31_actual_assignment_profile.json','p2c_v31_actual_assignment_profile.log','p2c_v31_actual_assignment_profile_corrected.log','prepare_p2c_v31_failure.py')
files += [r/'log'/name for name in names]
destination=report/'20261009_p2c_v31_artifacts';destination.mkdir();artifacts=[]
for p in sorted(set(files)):
    q=destination/('__'.join(p.relative_to(r).parts)+'.gz');q.write_bytes(gzip.compress(p.read_bytes(),compresslevel=6,mtime=0))
    assert gzip.decompress(q.read_bytes())==p.read_bytes()
    artifacts.append(dict(source=str(p.relative_to(root)),source_sha256=sha(p),archive=str(q.relative_to(report)),archive_sha256=sha(q)))
output=dict(status='FAIL',scope='First frozen development original; remaining3/17/2/917 never invoked',original=s,strict_gate=gate,
    independent_audits=audits,all_owned_closed_before_edit=closure,task_retries=0,
    late_geometry_profile=json.loads((r/'log/p2c_v31_actual_assignment_profile.json').read_text()),
    fixture_correction='First late-map conditional fixture returned at input readiness because missing unconsulted tb1 map; corrected input robot set to saved eligible tb2, retained initial zero-output log. Not actual task replay.',
    limitations='Early-map .213s sample did not bound later geometry/visual workload. Late fixed snapshot1.222s includes265 rays/89 visual poses. No proof of executor starvation or radio bottleneck; clock2/5s source guards retained.',artifacts=artifacts)
(report/'20261009_p2c_v31_failed_development.json').write_text(json.dumps(output,indent=2)+'\n')
(report/'20261009_p2c_v31_failed_development.md').write_text('''# P2C.1 v31 首原开发 FAIL

冻结f455c2ee299501a61301318d61a4fd3ce8ad9fb2，2026-10-09T05:03:03.584645..05:09:46.340748UTC。强制二机原任务300.3秒EXPLORE timeout，3次实际导航、tb1充电一次/10秒恢复ACTIVE80、tb2未充电；最低能量10.1691345、零接触/耗尽/failed机器人，owner600990/observer601008退出0。全部owned关闭后才修改。严格首格FAIL，后3开发/17正式/2物理/917从未调用，无重试/回填/原300秒、5秒或TTL放宽。

十二独立检查PASS：3已闭合返航触发/1charger return/0local导航腿、121能量快照、3探索证据含1相机兴趣补查、1AP返路否决；135次规划在candidate_budget因原source+TTL过期弃置。任务未发现目标，子门PASS不替代任务或实际远端断网返航验证。全部原始结果/source/config/command/environment/ledger/metrics/native图/关闭和SHA归档。

早期地图固定快照0.213秒不是后期负载界。2165.882秒实际补查事件提供212×253交付图及14历史view/5visit；任务关闭后固定source/epoch、tb1 pending charge、eligible tb2的条件调度cProfile1.222秒，265次visible_unknown_gain累计0.491秒，前沿准备0.394秒，89 known_search_view/已知候选0.349秒，368返路查询0.356秒。几何选择复现同一tb2目标(-.6079968,-.2142553)，但没有原始全历史或真实派发，不是任务反事实。初条件夹具因未咨询tb1图缺失在ready处返回0秒，后依据保存的eligible集合修正，原零输出日志保留。没有ROS执行器饥饿或Wi-Fi瓶颈的证明；下一步应优化已测重复射线/视场计算，不凭空改时钟或物理模型。

P3C.5已验收，P2C.1未完成；无P4/ns-3/Wi-Fi/RL。
''')
with (w/'log.md').open('a') as f:
    f.write('\n\n## 2026-10-09 P2C.1 v31 首强制原任务 FAIL\n\n')
    f.write('f455c2e commit/push0，独立check_p2c_v31_freeze.py PASS后Humble+install/PYTHONNOUSERSITE=1/FastDDS UDPv4/taskset -c0-79 /usr/bin/python3 scripts/run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v31 --domain210 --gazebo-port20290 > log/p2c_v31_dev_forced2_runner.log 2>&1。05:03:03.584645..05:09:46.340748UTC，300.3s EXPLORE timeout/3nav/tb1charge1(10s)/tb2charge0/min10.1691345/零接触耗尽failed；owner600990/observer601008 exit0。strict check_p2c_gate.py --run-root log/p2c/20261009_p2c_v31 --development --cases dev_forced2 --output log/p2c_v31_dev_forced2_gate.json FAIL native success；audit_p2c_v31_independent.py12checks PASS、135lease-expired/121energy/3explore/1actualcamera/1veto，0local return腿不能代替远端证明。其余3/17/2/917从未启动。\n\n')
    f.write('所有owned关闭后profile_p2c_v31_actual_snapshot.py固定实际2165.882s地图/14view/5visit/eligible tb2及pending tb1进行条件CPU分析，首夹具其他图未咨询且缺失在all_ready处返回零；按保存eligible集合修正后1.222s/265射线/89视场/368返路且同目标，无真实派发/源续租，不称任务回放或最坏界。读取本机Humble rclpy TimeSource/Executor/CallbackGroup源探索线程假说，未做执行器、时钟、DDS速率或physics变化；没有饥饿因果证明。原FAIL全部SHA压缩保留。下一新候选须重新验证与pushedfreeze，TTL/native保持，P4/ns3/Wi-Fi/RL未执行。\n')
print(json.dumps(dict(status='FAIL',artifacts=len(artifacts),expired=135,owned_closed=True)))
