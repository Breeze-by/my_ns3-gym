import ast
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import subprocess
import time

import numpy as np
from scipy import ndimage
from multi_robot_exploration import control as c

reference = '7ff90332d0ad977c4ef94a6a5964404101731737'
path = 'ros2_ws/ros2-multi-robot-automap/src/multi_robot_exploration/multi_robot_exploration/control.py'
source = subprocess.check_output(['git', 'show', reference+':'+path], text=True)
functions = [n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef)
             and n.name in ('assign_rally_poses', 'rally_pose_candidates')]
scope = dict(vars(c))
exec(compile(ast.Module(body=functions, type_ignores=[]), '<frozen v13 choices>', 'exec'), scope)
raw = np.zeros((200,200), dtype=np.int16)
raw[100:104,:] = 100
raw[100:104,92:108] = 0
positions = dict(tb1=(4.525,4.475), tb2=(5.475,4.475))
home = (5.05,3.05)
states = {n: dict(mode='ACTIVE', energy=80., capacity=100., charge_target_fraction=.8,
    charge_x=home[0], charge_y=home[1], charge_radius_m=.8,
    idle_cost_per_sec=.02, move_cost_per_m=1., return_path_factor=2.,
    nominal_speed_mps=.18, return_safety_margin=8., charge_duration_sec=6.) for n in positions}
geometry = dict(data=raw, resolution=.05, origin=(0.,0.))
args = dict(raw_grid=raw, resolution=.05, origin=(0.,0.), robot_positions=positions,
    current_positions=positions, target=(5.05,7.), battery_states=states,
    return_maps={n: geometry for n in positions}, observer_robot='tb1')
clearance = ndimage.distance_transform_edt(raw == 0, sampling=.05)
rows = {}
for label, fn in (('frozen_v13_policy', scope['assign_rally_poses']), ('current_v14_policy', c.assign_rally_poses)):
    start = time.perf_counter()
    answer = fn(**args)
    wall = time.perf_counter()-start
    assert set(answer) == set(positions)
    exposure = {}
    for name, pose in answer.items():
        route = min((r for r in c.qualified_return_candidates(raw,.05,(0.,0.),
            (pose.x,pose.y),home,.8,geometry) if r['qualified']), key=lambda r:r['path_distance_m'])
        exposure[name] = c.return_route_clearance_exposure(route['route'],.05,(0.,0.),clearance)
    rows[label] = dict(assignment={n:asdict(p) for n,p in answer.items()},
        home_side_robots=sum(p.y<4.6 for p in answer.values()), return_exposure_m=exposure,
        wall_sec=wall, candidate_count=len((scope['rally_pose_candidates'] if label.startswith('frozen')
            else lambda *a: c.rally_pose_candidates(*a,False,True))(raw,.05,(0.,0.),(5.05,7.))))
assert rows['frozen_v13_policy']['home_side_robots'] == 1
assert rows['current_v14_policy']['home_side_robots'] == 2
assert sum(rows['current_v14_policy']['return_exposure_m'].values()) < sum(rows['frozen_v13_policy']['return_exposure_m'].values())
output = Path('log/p2c_v14_choice_comparison.json')
assert not output.exists()
result = dict(status='PASS', scope='Constructed visible doorway, frozen choice policy with current exact geometry; not an original task callback or mission counterfactual',
    reference_commit=reference, reference_control_sha256=hashlib.sha256(source.encode()).hexdigest(),
    current_control_sha256=hashlib.sha256(Path(c.__file__).read_bytes()).hexdigest(),
    fixture=dict(shape=raw.shape,resolution=.05,origin=(0.,0.),wall_rows=(100,104),door_columns=(92,108),
        target=args['target'],positions=positions,home=home,battery_states=states), cases=rows)
output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
