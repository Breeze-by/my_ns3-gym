import collections, gzip, hashlib, json, os
from pathlib import Path
from datetime import datetime, timezone

root=Path('/home/zhuyulab/ns3-workspace');r=root/'ros2_ws/ros2-multi-robot-automap'
w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl';report=w/'report'
base=r/'log/p2c/20261009_p2c_v37';paths=list(base.glob('*/summary.json'));assert len(paths)==1
p=paths[0];s=json.loads(p.read_text());z=s['result'];freeze='73fb1606d4976c7d3300fcd1c85105e12bab7297'
assert s['git_commit']==freeze and s['case']=='dev_forced2' and not z['success']
assert z['collision_events']==0 and not z['failed_robots']
assert s['runner_returncode']==s['observer_returncode']==0
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
closure={}
for key in ('owner_pid','observer_pid'):
 try:os.kill(s[key],0)
 except ProcessLookupError:closure[key]=dict(pid=s[key],closed=True)
 else:raise AssertionError(('live',key))
closure['checked_at_utc']=datetime.now(timezone.utc).isoformat()
(r/'log/p2c_v37_closed_before_edit.json').write_text(json.dumps(closure,indent=2)+'\n')
for name,digest in s['evidence_sha256'].items():assert sha(p.parent/name)==digest
gate=json.loads((r/'log/p2c_v37_dev_forced2_gate.json').read_text());assert gate['status']=='FAIL'
audits=json.loads((r/'log/p2c_v37_independent_audits.json').read_text())
assert len(audits['dev_forced2'])==12 and all(v['status']=='PASS' for v in audits['dev_forced2'].values())
rows=[json.loads(line) for line in (p.parent/'ledger.jsonl').open()]
leases=collections.Counter(e['stage'] for e in rows if e.get('event')=='coordinator_planning_lease_expired')
snapshot_binding={}
snapshots=list((r/'log').glob('p2c_v37_dev_forced2_*snapshot.json'))
for q in snapshots:
 e=json.loads(q.read_text());assert any(x==e for x in rows)
 snapshot_binding[q.name]=dict(snapshot_sha256=sha(q),original_ledger_sha256=sha(p.parent/'ledger.jsonl'),ledger_index=e['ledger_index'])
files=[q for q in base.rglob('*') if q.is_file() and q.suffix!='.pyc']+snapshots
files += [r/'log'/name for name in ['check_p2c_v37_freeze.py','p2c_v37_freeze_check.json',
  'p2c_v37_dev_forced2_runner.log','p2c_v37_dev_forced2_gate.log','p2c_v37_dev_forced2_gate.json',
  'audit_p2c_v37_independent.py','p2c_v37_independent_audits.json','p2c_v37_independent_audits.log',
  'peek_p2c_v37_tasks.py','p2c_v37_task_diagnosis.json','p2c_v37_closed_before_edit.json','prepare_p2c_v37_failure.py']]
assert all(q.exists() for q in files)
destination=report/'20261009_p2c_v37_artifacts';assert not destination.exists();destination.mkdir();artifacts=[]
for q in sorted(set(files)):
 a=destination/('__'.join(q.relative_to(r).parts)+'.gz');a.write_bytes(gzip.compress(q.read_bytes(),compresslevel=6,mtime=0))
 assert gzip.decompress(a.read_bytes())==q.read_bytes()
 artifacts.append(dict(source=str(q.relative_to(root)),source_sha256=sha(q),archive=str(a.relative_to(report)),archive_sha256=sha(a)))
out=dict(status='FAIL',scope='First required forced-development original failed; other3 development/formal17/physical2/917 not invoked',
 task_stack_frozen_commit=freeze,original=s,first_required_gate=gate,independent_audits=audits,
 all_owned_closed=closure,planning_lease_aborts=dict(leases),exact_snapshot_binding=snapshot_binding,
 task_retries=0,artifacts=artifacts)
(report/'20261009_p2c_v37_failed_development.json').write_text(json.dumps(out,indent=2)+'\n')

text=f"""# P2C.1 v37 首强制原任务 FAIL

冻结73fb1606d4976c7d3300fcd1c85105e12bab7297，control SHA3297194381fe74d095625c27a71c2838f754c4fc081f69b4556b91453dc7407b。原任务EXPLORE timeout{z['elapsed_sim_time_sec']:.1f}s，未确认目标；success=false、completion_time=null、native_rally_hold_proof=null。原生Nav2计数{z['nav_goal_count']}，中央25决策(19mapping/6visual)；两机各charge1、最低{z['battery_minimum_energy']}，零接触/耗尽/failed机器人/任务期infra/retry，owner/observer exit0且已关闭。全strict FAIL、277 live和12独立审计PASS不能代替任务成功。其余3dev/17formal/2physical/917未调用。

62次来源租约弃置(47candidate_generation/15candidate_budget)全部保留。tb2充电后停在(.2859,-.2568)，距自己充电点(0,.45)约.7624m，小于原.8m接触半径。原本地SLAM地图将当前位置单元标为100；融合图单元0/接触距离0，但连续本地障碍校验拒绝该融合路线，constrained_fused也无路线。不能为了放行改写占用或放松已知返航保护。这是被交付地图限制的真实决策，不证明物理墙体存在，也不证明其由某一动态障碍唯一导致。

原tb2返航从(.376,-1.423)于2159.582发送已规划接触目标(.273755673,-.076247627)，但进入原半径后提前取消，return_finished记录cancellation_count1。后半程只有tb1继续大幅探索；tb1/tb2真实路径分别36.38865/7.80898m。最后两份准确弃置输入的固定epoch完整计算约.79–.83/.68–.70wall秒，超过当时仅.502/.303秒剩余租约，且按原几何完整重建仍无法为tb2派发。条件CPU不是原时钟/完整history回放或唯一任务因果。

所有source/command/graph/ledger/安全原始数据和严格失败、准确snapshot逐字原ledger绑定与12详细检查见JSON/gzip。原300s/5s、2/5/60s TTL、占用/储备门槛未放宽。后续候选仅让已接受接触航段结束再进入CHARGING；可能仍受Nav2位置容差与地图占用影响，必须重新clean pushed freeze及新原任务验证。P2C.1未完成；P3C.5已验收，无P4/ns-3/Wi-Fi/RL。
"""
(report/'20261009_p2c_v37_failed_development.md').write_text(text)
heading='## 2026-10-09 P2C.1 v37 首强制开发原任务 FAIL'
assert heading not in (w/'log.md').read_text()
with (w/'log.md').open('a') as f:
 f.write('\n\n'+heading+'\n\n73fb160 commit/push0，check_p2c_v37_freeze.py PASS；Humble+install/PYTHONNOUSERSITE1/FastDDS UDPv4清profiles，taskset -c 0-79 /usr/bin/python3 scripts/run_p2c_tasks.py --case dev_forced2 --run-id 20261009_p2c_v37 --domain 210 --gazebo-port 20290 > log/p2c_v37_dev_forced2_runner.log 2>&1。原launch/observer/config/case/source SHA全部保留。\n\n')
 f.write(f"EXPLORE timeout{z['elapsed_sim_time_sec']:.1f}s，detect/rally/completion=null；Nav2{z['nav_goal_count']}/两机各charge1/min{z['battery_minimum_energy']}、0contacts/exhaustion/failed/task-time infra/retry。owner{s['owner_pid']}/observer{s['observer_pid']} exit0/0闭合且所有原件SHA保持。check_p2c_gate.py --run-root log/p2c/20261009_p2c_v37 --development --cases dev_forced2 --output log/p2c_v37_dev_forced2_gate.json exit1/FAIL，277 live+12独立审计PASS。其他3dev/17formal/2physical/917未调用。\n\n")
 f.write('实际62 lease弃置(47gen15budget)，25中央派发/6visual/13resume。tb2在距自己home.762m处提前取消原已规划接触腿，充电后fresh local current cell100，融合cell0但local veto拒绝，非能量不足；不清占用/不声称物理障碍或单因素因果。最后两个原弃置snapshot逐字ledger绑定；profile_p2c_v38_forced_inputs.py固定epoch3cold完整计算.79–.83/.68–.70超过原.502/.303来源剩余sec，122/91plan和3return；条件原算法同样不派发tb2，不代表history/live-clock回放。diagnose_p2c_v38_current_return.py精确source格/return candidates重建；首读safety string为空JSON解析错误只读命令失败、修正跳过非JSON数据，不是任务重试。v37原失败完全保留；新候选不更改原期限/TTL/物理刺激/充电半径/安全门，native接触提前取消待独立验证。\n')
print(json.dumps(dict(status='FAIL',originals=1,audits=12,artifacts=len(artifacts),owned_closed=True)))
