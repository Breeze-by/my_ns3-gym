import gzip,hashlib,json,shutil
from pathlib import Path
r=Path.cwd();root=r.parents[1];report=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl/report'
p=report/'20261009_p2c_strengthening_review.json';d=json.loads(p.read_text())
rows=[a for a in d['artifacts'] if hashlib.sha256((root/a['source']).read_bytes()).hexdigest()!=a['source_sha256']]
assert len(rows)==1 and rows[0]['source'].endswith('/log/p2c_strengthening_prepare_review.log')
row=rows[0];q=report/row['archive'];old=q.with_name(q.name.replace('.log.gz','_initial_empty.log.gz'))
assert not old.exists();shutil.copy2(q,old)
erratum=dict(scope='Derived generator stdout finalized after capture; all original task/ledger/physics inputs unchanged',
    source=row['source'],initial_archive=str(old.relative_to(report)),initial_archive_sha256=row['archive_sha256'],
    initial_source_sha256=row['source_sha256'],initial_validation='AssertionError on generator stdout source hash; dependent copy stopped without experiment')
source=root/row['source'];q.write_bytes(gzip.compress(source.read_bytes(),compresslevel=6,mtime=0))
row['source_sha256']=hashlib.sha256(source.read_bytes()).hexdigest();row['archive_sha256']=hashlib.sha256(q.read_bytes()).hexdigest()
erratum.update(final_source_sha256=row['source_sha256'],final_archive_sha256=row['archive_sha256'])
d['derived_output_erratum']=erratum;p.write_text(json.dumps(d,indent=2)+'\n')
(report/'20261009_p2c_strengthening_provenance_erratum.json').write_text(json.dumps(erratum,indent=2)+'\n')
(r/'log/p2c_strengthening_provenance_initial_failure.log').write_text('Final derived artifact validation AssertionError: only log/p2c_strengthening_prepare_review.log changed from empty to finalized stdout after self-capture. Dependent copy failed FileNotFoundError because the failed validation did not write final_provenance. Both failures occurred after all experiment owners closed. Original task evidence unchanged.\n')
with (report/'20261009_p2c_strengthening_review.md').open('a') as stream:
    stream.write('\n最终派生归档校验发现生成器自身stdout在归档时仍为空、生成结束后才写完；初验证正确拒绝了source SHA不一致，后续copy因无证明文件停止。仅将已结束生成器的完整stdout重新归档，初空归档/SHA、错误说明和修正见20261009_p2c_strengthening_provenance_erratum.json。原任务/地图/账本/物理数据未改；完整复核结果见20261009_p2c_strengthening_final_provenance.json。\n')
print(json.dumps(erratum))
