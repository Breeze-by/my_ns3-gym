import hashlib,json,socket,subprocess
from datetime import datetime,timezone
from pathlib import Path
root=Path('/home/zhuyulab/ns3-workspace');r=Path.cwd()
freeze='609ba9d72850c6e41a2a3d0ee524d4d4e9720602'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==freeze
assert subprocess.check_output(['git','rev-parse','@{u}'],text=True).strip()==freeze
dirty=[p for p in subprocess.check_output(['git','status','--porcelain','-z','--untracked-files=all']).split(b'\0')
       if p and not p.startswith(b'?? 260929_report/')]
assert not dirty,dirty
config=r/'scripts/p2c_blackout_manifest.json'
frozen=subprocess.check_output(['git','show',freeze+':'+str(config.relative_to(root))],cwd=root)
assert config.read_bytes()==frozen
declaration=json.loads(frozen)
assert declaration['staging_apparatus_script']=='stage_p2c_return_probe.py'
assert declaration['nav2_staging_readiness']['delivered_active_span_sec_min']==.5
for source,field in [('stage_p2c_return_probe.py','staging_apparatus_content_sha256'),
                     ('stage_p3b5_return_probe.py','staging_base_content_sha256')]:
    assert hashlib.sha256((r/'scripts'/source).read_bytes()).hexdigest()==declaration[field]
assert not (r/'log/p2c/20261009_p2c_return_stable').exists()
for port in (20298,20299):
    with socket.socket() as connection:assert connection.connect_ex(('127.0.0.1',port))!=0,('used Gazebo port',port)
closed=[]
for run in ('20261009_p2c_v41','20261009_p2c_return_characterization','20261009_p2c_return_ready'):
    for path in (r/'log/p2c'/run).glob('*/summary.json'):
        row=json.loads(path.read_text())
        for key in ('owner_pid','observer_pid','staging_pid','physics_pid'):
            if key in row:
                assert not Path('/proc',str(row[key])).exists()
                closed.append(row[key])
out=dict(status='PASS',checked_at_utc=datetime.now(timezone.utc).isoformat(),freeze=freeze,
    supplemental_scope=declaration['purpose'],all_two_originals_required_even_if_failure=True,
    task_retry=0,prior_owned_closed=closed,config_sha256=hashlib.sha256(frozen).hexdigest(),
    main_integration_status='FAIL; independent safety pair cannot backfill main',
    isolated_domains=[218,219],isolated_gazebo_ports=[20298,20299],domain222_untouched=True)
Path('log/p2c_return_stable_freeze.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
