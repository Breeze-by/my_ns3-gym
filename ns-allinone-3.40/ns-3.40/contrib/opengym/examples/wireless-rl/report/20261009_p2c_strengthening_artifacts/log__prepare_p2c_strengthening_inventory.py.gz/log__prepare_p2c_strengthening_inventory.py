"""Read-only development inventory; different versions are never pooled tests."""
import collections,hashlib,json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

r=Path.cwd();rows=json.loads((r/'log/p2c_v41_historical_task_inventory.json').read_text())['rows']
p=r/'log/p2c/20261009_p2c_v41/20261009_p2c_v41_dev_forced2/summary.json'
s=json.loads(p.read_text());z=s['result']
rows.append(dict(version=41,case=s['case'],freeze=s['git_commit'],phase=z['task_phase'],success=z['success'],
    elapsed=z['elapsed_sim_time_sec'],reason=z['failure_reason'],failed_robots=z['failed_robots'],contacts=z['collision_events'],
    charges={n:v['battery_charge_count'] for n,v in z['robots'].items()},owner_returncode=s['runner_returncode'],
    observer_returncode=s['observer_returncode'],summary=str(p.relative_to(r))))
for row in rows:
    path=r/row['summary'];original=json.loads(path.read_text());result=original['result']
    assert original['git_commit']==row['freeze'] and original['case']==row['case']
    assert result['task_phase']==row['phase'] and result['success']==row['success']
    row.update(summary_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        failure_penalized_mission_time_sec=result['elapsed_sim_time_sec']
            if result['success'] and original['runner_returncode']==original['observer_returncode']==0 else 300.,
        battery_minimum_energy=result['battery_minimum_energy'],
        original_completion_time_sec=result['completion_time_sec'],
        scope='development original; not a replicate of any other source version')
assert len(rows)==76 and len({row['version'] for row in rows})==40
out=dict(scope=__doc__,main_originals=76,actual_task_source_versions=40,
    phases=dict(collections.Counter(row['phase'] for row in rows)),
    failed_robot_originals=[{k:row[k] for k in ('version','case','failed_robots','battery_minimum_energy','summary_sha256')}
        for row in rows if row['failed_robots']],
    summary_owner_nonzero=[{k:row[k] for k in ('version','case','owner_returncode','summary_sha256')}
        for row in rows if row['owner_returncode']],
    zero_energy_originals=[{k:row[k] for k in ('version','case','battery_minimum_energy','summary_sha256')}
        for row in rows if row['battery_minimum_energy']<=0],
    total_contact_events=sum(row['contacts'] for row in rows),
    limitations='Do not pool a success rate, causal time difference or CI across changing sources. Owner0 does not prove no task-time subprocess fault. Supplemental physical originals are excluded.',rows=rows)
(r/'log/p2c_strengthening_inventory.json').write_text(json.dumps(out,indent=2)+'\n')
fig,axes=plt.subplots(2,2,figsize=(12,6.4),sharex=True,sharey=True)
for axis,case in zip(axes.flat,('dev_forced2','dev_lab101','dev_rooms202','dev_corridors303')):
    subset=[row for row in rows if row['case']==case]
    for row in subset:
        success=row['success'] and row['owner_returncode']==row['observer_returncode']==0
        color='#198066' if success else ('#c17b00' if row['owner_returncode'] else '#bf4242')
        marker='o' if success else ('D' if row['phase']=='PARTIAL_COMPLETE' else 'x')
        axis.scatter(row['version'],row['failure_penalized_mission_time_sec'],s=32,color=color,marker=marker)
    axis.axhline(300,color='#888888',linewidth=.7,linestyle='--')
    axis.set_title(case.replace('dev_',''),loc='left',fontsize=11)
    axis.set_xlim(0,42);axis.set_ylim(70,320);axis.grid(alpha=.15)
    axis.set_xlabel('Source version (not paired trials)');axis.set_ylabel('Failure-penalized mission time (s)')
fig.suptitle('P2C.1: 76 development originals across 40 task-source versions',fontsize=14)
fig.text(.5,.01,'Green: native COMPLETE with owner/observer 0 | red x: failure/timeout | diamond: partial | amber: owner failure\nFailures receive 300 s; raw partial completion is retained. No pooled success rate or causal algorithm claim.',
         ha='center',fontsize=9)
fig.tight_layout(rect=[0,.08,1,.94]);fig.savefig(r/'log/p2c_strengthening_development.png',dpi=160);plt.close(fig)
print(json.dumps({k:v for k,v in out.items() if k!='rows'}))
