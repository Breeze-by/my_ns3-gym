import collections,json
from pathlib import Path
for directory in sorted(Path('log/p2c/20261009_p2c_return_stable').glob('*')):
    output={'case':directory.name}
    p=directory/'summary.json'
    if p.exists():
        row=json.loads(p.read_text());z=row['result']
        output.update(closed=True,phase=z['task_phase'],success=z['success'],elapsed=z['elapsed_sim_time_sec'],
            min_energy=z['battery_minimum_energy'],failed=z['failed_robots'],contacts=z['collision_events'],
            charges={n:v['battery_charge_count'] for n,v in z['robots'].items()},
            children={k:v for k,v in row.items() if k.endswith('_returncode') or k.endswith('_forced_shutdown')})
    else:output['closed']=False
    for name in ('staging','nav2_readiness'):
        p=directory/(name+'.jsonl')
        if p.exists():
            rows=[]
            for line in p.open():
                try:rows.append(json.loads(line))
                except json.JSONDecodeError:pass
            selected=[row for row in rows if name=='nav2_readiness' or row['event'] in
                ('staged','both_charged','fixture_failed','stage_deadline','staging_requested')]
            output[name]=[{k:v for k,v in e.items() if k not in ('inputs','batteries')}
                          for e in selected[-3:]]
    print(json.dumps(output))
