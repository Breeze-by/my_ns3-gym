import gzip,hashlib,json,re
from pathlib import Path
r=Path.cwd();root=r.parents[1];w=root/'ns-allinone-3.40/ns-3.40/contrib/opengym/examples/wireless-rl'
p=w/'report/20261009_p2c_strengthening_review.json';d=json.loads(p.read_text())
assert d['status']==d['full_integration_status']=='FAIL'
assert d['controlled_physical_pair_status']=='PASS' and d['current_components']['full_suite_checks']==1527
assert d['inventory']['main_originals']==76
for row in d['component_report_bindings']:
    assert hashlib.sha256((w/'report'/row['report']).read_bytes()).hexdigest()==row['sha256']
for a in d['artifacts']:
    source=root/a['source'];archive=w/'report'/a['archive']
    assert hashlib.sha256(source.read_bytes()).hexdigest()==a['source_sha256'],source
    assert hashlib.sha256(archive.read_bytes()).hexdigest()==a['archive_sha256'],archive
    assert hashlib.sha256(gzip.decompress(archive.read_bytes())).hexdigest()==a['source_sha256'],archive
md=w/'report/20261009_p2c_strengthening_review.md'
for target in re.findall(r'\]\(([^)]+)\)',md.read_text()):
    if not target.startswith(('https://','http://')):assert (md.parent/target.split('#')[0]).resolve().exists(),target
remaining=[]
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():continue
    try:
        env=(proc/'environ').read_bytes().split(b'\0')
        if b'ROS_DOMAIN_ID=218' in env or b'ROS_DOMAIN_ID=219' in env:remaining.append(int(proc.name))
    except (PermissionError,FileNotFoundError,ProcessLookupError):pass
assert not remaining,remaining
out=dict(status='PASS',main_integration='FAIL',controlled_pair='PASS',functional_checks=1527,
    artifacts_verified=len(d['artifacts']),links_verified=True,domains218219_no_live_processes=True,
    final_report_json_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
    final_report_markdown_sha256=hashlib.sha256(md.read_bytes()).hexdigest())
(r/'log/p2c_strengthening_final_provenance.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
