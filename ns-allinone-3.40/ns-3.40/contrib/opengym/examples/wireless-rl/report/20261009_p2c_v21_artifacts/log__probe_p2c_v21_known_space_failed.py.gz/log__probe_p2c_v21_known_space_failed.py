import base64,json,math,zlib
from pathlib import Path
from types import SimpleNamespace
from multi_robot_exploration import control as c
p=Path("log/p2c/20261009_p2c_v21/20261009_p2c_v21_dev_lab101/ledger.jsonl")
events=[]
for line in p.open():
 e=json.loads(line)
 if e.get("event")=="coordinator_navigation_decision" and e.get("kind")=="exploration":events.append(e)
e=next(e for e in events if e["robot"]=="tb2" and abs(e["event_time"]-2288.382)<1e-7)
maps={}
for key,s in [("planning",e["planning_map"]),("source",e["source_map"]),*e["return_maps"].items()]:
 maps[key]=dict(data=__import__("numpy").frombuffer(zlib.decompress(base64.b64decode(s["grid"])),dtype="<i2").reshape(s["shape"]),resolution=s["resolution"],origin=s["origin"])
g=maps["planning"];visited=[]
for prior in events:
 if prior["event_time"]>e["event_time"]:break
 for position in prior["robot_positions"].values():
  if position is not None and all(math.dist(position,p)>.5 for p in visited):visited.append(position)
states=e["battery_states"]
node=SimpleNamespace(enable_battery=True,now=lambda:e["event_time"],map_data=g["data"],resolution=g["resolution"],origin=g["origin"],map_received_at=e["planning_map"]["source_time"],source_map_data=maps["source"]["data"],map_self_return_cells=e["self_return_cells"],robot_positions=e["robot_positions"],battery_states=states,robot_maps={name:maps[name] for name in e["return_maps"]},robot_map_received_at={name:s["source_time"] for name,s in e["return_maps"].items()},robot_odom_received_at={name:e["inputs"][name+"/pose_state"]["source_time"] for name in states},robot_tf_received_at={name:e["inputs"][name+"/frame_state"]["source_time"] for name in states})
blocked=[p for n,p in e["robot_positions"].items() if n!="tb2" and p is not None]
rows=[]
for utility,name,group,a in c.known_space_search_candidates(g["data"],g["resolution"],g["origin"],"tb2",e["robot_positions"]["tb2"],visited,blocked=blocked):
 cost=c.HeadquartersControl.exploration_required_energy(node,name,a.path_distance_m,(a.x,a.y))
 plan=c.plan_rally_leg(g["data"],g["resolution"],g["origin"],e["robot_positions"]["tb2"],c.RallyPose(a.x,a.y,0.),blocked,c.MAX_NAVIGATION_LEG_M,visible_only=True,route_clearance_m=c.PATH_CLEARANCE_M)
 if cost is not None and cost<states[name]["energy"] and plan is not None:
  rows.append(dict(target=[a.x,a.y],gain=a.viewpoint.information_gain,utility=utility,distance_m=a.path_distance_m,required_energy=cost,request=[plan[0].x,plan[0].y]))
rows.sort(key=lambda r:r["utility"],reverse=True)
target_cell=c.world_to_grid(-4.,4.,g["resolution"],*g["origin"])
out=dict(scope="Conditional actual delivered snapshot; only sparse navigation-decision positions, missing original full history/exclusions/reservations. No counterfactual task result.",event_time=e["event_time"],current_position=e["robot_positions"]["tb2"],current_energy=states["tb2"]["energy"],target_cell_known_value=int(g["data"][target_cell]),selected_original=e["travel_preference"],visited=visited,feasible_known_candidates=len(rows),top=rows[:8])
Path("log/p2c_v21_known_space_diagnostic.json").write_text(json.dumps(out,indent=2)+"\n");print(json.dumps(out))
