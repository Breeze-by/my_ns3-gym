import base64,copy,json,zlib
from pathlib import Path
import pytest
import numpy as np
import p2c_v21_zero_based_reader
from check_p2c_gate import exploration_travel_audit
from multi_robot_exploration import control as c
from test_relative_frontier_travel import travel_event

@pytest.mark.parametrize("corruption",[None,"weight","score","base_and_score","negative_group","upper_group","group_size","exclusions","missing"])
def test_corrected_reader_keeps_forgery_rejections(corruption):
 e=travel_event(unknown=True);f=e["travel_preference"]
 grid=np.frombuffer(zlib.decompress(base64.b64decode(e["planning_map"]["grid"])),dtype="<i2").reshape(e["planning_map"]["shape"])
 groups=c.frontier_groups(grid)
 f.update(frontier_group_id=0,frontier_group_size=len(groups[0]),excluded_targets=[],resume_intent=[*f["target"],f["information_gain"]],continuation_weight=2.)
 f["base_utility"]=c.exploration_utility(f["information_gain"],f["frontier_group_size"],f["own_nominal_distance_m"])
 f["adjusted_utility"]=f["base_utility"]*f["factor"];f["scheduling_score"]=2.*f["adjusted_utility"]
 if corruption=="weight":f["continuation_weight"]=10.
 if corruption=="score":f["scheduling_score"]+=1.
 if corruption=="base_and_score":
  f["base_utility"]*=2.;f["adjusted_utility"]*=2.;f["scheduling_score"]*=2.
 if corruption=="negative_group":f["frontier_group_id"]=-1
 if corruption=="upper_group":f["frontier_group_id"]=len(groups)
 if corruption=="group_size":f["frontier_group_size"]+=1
 if corruption=="exclusions":f["excluded_targets"]=[f["target"]]
 if corruption=="missing":f.pop("scheduling_score")
 if corruption is None:assert exploration_travel_audit([e],True,True,True)["bounded_commitment_required"]
 else:
  with pytest.raises((AssertionError,KeyError)):exploration_travel_audit([e],True,True,True)

@pytest.mark.parametrize("positive",[False,True])
def test_actual_original_zero_and_positive_group_indices(positive):
 ledger=next(Path("log/p2c/20261009_p2c_v21").glob("*/ledger.jsonl"))
 for line in ledger.open():
  e=json.loads(line)
  if e.get("event")=="coordinator_navigation_decision" and e.get("kind")=="exploration" and (e["travel_preference"]["frontier_group_id"]>0)==positive:
   assert exploration_travel_audit([e],True,True,True)["executed_frontier_witnesses"]==1;break
 else:raise AssertionError("required original group not present")
